#!/usr/bin/env python3
"""
Interactive passphrase generator (repeat and quit)

Run without flags to enter interactive mode: it generates a passphrase,
then prompts to generate another or quit. Use --once to generate a single passphrase and exit.

This variant adds a cross-platform TTS option that uses system-provided tools
(no pip, no PIL). You can enable TTS at startup with --tts and toggle it at runtime
by pressing 't' (or typing 't' then Enter) while in the interactive loop.
"""

import secrets
import string
import argparse
import sys
import subprocess
import shutil
from typing import List

# Large default wordlist (truncated for brevity here; replace or extend as needed)
DEFAULT_WORDS = [
"apple","river","stone","garden","paper","cloud","ocean","forest","silver","gold",
"quiet","bright","shadow","ember","willow","sage","harbor","meadow","copper","maple",
"sunset","dawn","dusk","breeze","mountain","valley","island","prairie","cliff","canyon",
"pine","cedar","spruce","birch","oak","elm","rose","lily","violet","daisy",
"orchid","fern","moss","pebble","brook","stream","lagoon","bay","shore","beach",
"sand","pearl","coral","tide","wave","current","sail","anchor","lighthouse","trail",
"path","bridge","arch","tower","gate","castle","cottage","hut","barn","field",
"orchard","vine","grape","olive","citrus","berry","hearth","flame","spark","coal",
"ash","smoke","mist","fog","rain","storm","thunder","lightning","sunbeam","horizon",
"sky","azure","indigo","pearl","opal","jade","onyx","amber","ruby","sapphire",
"quartz","crystal","gem","jewel","treasure","chest","map","compass","star","planet",
"orbit","comet","meteor","galaxy","nebula","cosmos","space","rocket","voyage","journey",
"quest","odyssey","wander","roam","explore","discover","harvest","sow","plant","grow",
"bloom","sprout","root","seed","leaf","branch","trunk","grove","gardenia","sparrow",
"robin","wren","falcon","eagle","owl","chorus","melody","harmony","tune","rhythm",
"verse","lyric","poem","prose","story","tale","legend","myth","saga","chronicle",
"memoir","diary","letter","note","script","stage","scene","actor","author","painter",
"sculptor","artist","craft","forge","smith","weaver","tailor","needle","thread","loom",
"canvas","palette","brush","ink","quill","novel","chapter","page","bookmark","library",
"archive","record","tome","atlas","maplewood","cedarwood","pinecone","acorn","nut","vineyard",
"greenhouse","sunflower","marigold","lavender","thyme","rosemary","basil","mint","parsley","clover",
"butterfly","moth","beetle","ant","bee","wasp","dragonfly","ladybug","caterpillar","silk",
"quilt","blanket","pillow","camp","cabin","shelter","campfire","lantern","torch","candle",
"mirror","window","pane","glass","lens","prism","spectrum","rainbow","hue","shade",
"tone","tint","sketch","draft","blueprint","plan","design","engine","gear","cog",
"lever","pulley","axle","wheel","factory","mill","anvil","hammer","chisel","saw",
"nail","screw","bolt","hinge","latch","lock","key","door","threshold","porch",
"veranda","balcony","terrace","patio","courtyard","lane","alley","market","bazaar","vendor",
"merchant","trader","coin","ledger","bank","vault","safe","purse","wallet","satchel",
"bag","crate","box","parcel","package","bundle","scroll","seal","stamp","post",
"signal","flag","banner","crest","emblem","badge","token","medal","honor","crown",
"throne","scepter","knight","squire","minstrel","bard","poet","scribe","scholar","sage",
"mentor","guide","teacher","student","apprentice","artisan","builder","mason","carpenter","brick",
"mural","fresco","mosaic","tile","pavement","road","highway","junction","harvestmoon","fullmoon",
"newmoon","crescent","eclipse","solstice","equinox"
]

SYMBOLS = "!@#$%^&*()-_=+[]{};:,.<>/?"

# ---------------------------
# Cross-platform TTS helpers (with debug)
# ---------------------------
def _run_cmd(cmd: List[str], debug: bool = False) -> bool:
    """Run command list, return True on success, False otherwise. When debug=True, print stdout/stderr."""
    try:
        if debug:
            print(f"# Running: {cmd}", file=sys.stderr)
            proc = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if proc.stdout:
                print(proc.stdout, file=sys.stderr)
            if proc.stderr:
                print(proc.stderr, file=sys.stderr)
        else:
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except subprocess.CalledProcessError as e:
        if debug:
            print(f"# Command failed with exit {e.returncode}", file=sys.stderr)
            if hasattr(e, "stdout") and e.stdout:
                print(e.stdout, file=sys.stderr)
            if hasattr(e, "stderr") and e.stderr:
                print(e.stderr, file=sys.stderr)
        return False
    except FileNotFoundError:
        if debug:
            print("# Command not found", file=sys.stderr)
        return False
    except Exception as e:
        if debug:
            print(f"# Exception running command: {e}", file=sys.stderr)
        return False

def speak(text: str, debug: bool = False) -> bool:
    """
    Cross-platform TTS without external Python packages.
    Returns True if speech was attempted successfully, False otherwise.
    When debug=True, prints diagnostic output to stderr.
    """
    if not text:
        return False

    platform = sys.platform

    # macOS: use `say`
    if platform == "darwin":
        if shutil.which("say"):
            return _run_cmd(["say", text], debug)
        if debug:
            print("# macOS 'say' not found", file=sys.stderr)
        return False

    # Windows: try Windows PowerShell (Windows PowerShell uses .NET Framework) and COM fallback
    if platform.startswith("win"):
        # Escape single quotes by doubling them for PowerShell single-quoted string
        safe = text.replace("'", "''")
        ps_system_speech = (
            "Add-Type -AssemblyName System.Speech;"
            f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            f"$s.Speak('{safe}');"
        )
        ps_sapi_com = f"$voice = New-Object -ComObject SAPI.SpVoice; $voice.Speak('{safe}');"

        # Prefer 'powershell' (Windows PowerShell). If not present, try 'pwsh' then fallback to COM.
        if shutil.which("powershell"):
            if _run_cmd(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_system_speech], debug):
                return True
            if _run_cmd(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_sapi_com], debug):
                return True
        if shutil.which("pwsh"):
            # pwsh (PowerShell Core) may not support System.Speech; try COM fallback first
            if _run_cmd(["pwsh", "-NoProfile", "-Command", ps_sapi_com], debug):
                return True
            if _run_cmd(["pwsh", "-NoProfile", "-Command", ps_system_speech], debug):
                return True

        if debug:
            print("# Windows TTS backends tried and failed", file=sys.stderr)
        return False

    # Linux / other Unix: try espeak, then spd-say
    if shutil.which("espeak"):
        return _run_cmd(["espeak", text], debug)
    if shutil.which("spd-say"):
        return _run_cmd(["spd-say", text], debug)

    if debug:
        print("# No TTS backend found (say, powershell/pwsh, espeak, spd-say)", file=sys.stderr)
    return False

def tts_probe_available() -> bool:
    """Quick probe to detect if any known TTS backend is available on this system."""
    platform = sys.platform
    if platform == "darwin":
        return bool(shutil.which("say"))
    if platform.startswith("win"):
        # presence of powershell/pwsh indicates we can attempt TTS; actual success depends on voice availability
        return bool(shutil.which("powershell") or shutil.which("pwsh"))
    return bool(shutil.which("espeak") or shutil.which("spd-say"))

# ---------------------------
# Passphrase generator
# ---------------------------
def load_wordlist(path: str) -> List[str]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            words = [line.strip() for line in f if line.strip()]
        if not words:
            raise ValueError("Wordlist file is empty.")
        return words
    except Exception as e:
        raise RuntimeError(f"Failed to load wordlist: {e}")

def choose_words(words: List[str], count: int, capitalize: bool) -> List[str]:
    chosen = [secrets.choice(words) for _ in range(count)]
    if capitalize:
        chosen = [w.capitalize() if secrets.randbelow(2) else w for w in chosen]
    return chosen

def insert_random_chars(pass_chars: List[str], chars: str, count: int):
    """Insert `count` characters chosen from `chars` into random positions of pass_chars list."""
    if count <= 0:
        return
    for _ in range(count):
        ch = secrets.choice(chars)
        pos = secrets.randbelow(len(pass_chars) + 1)  # allow insertion at ends
        pass_chars.insert(pos, ch)

def generate_passphrase(
    wordlist: List[str],
    word_count: int = 4,
    separator: str = "-",
    min_digits: int = 0,
    min_symbols: int = 0,
    capitalize: bool = False,
    insert_inside_words: bool = False
) -> str:
    if word_count < 1:
        raise ValueError("word_count must be >= 1")
    if min_digits < 0 or min_symbols < 0:
        raise ValueError("min_digits and min_symbols must be >= 0")

    words = choose_words(wordlist, word_count, capitalize)

    # Build base tokens (either characters for inside insertion or tokens for joining)
    if insert_inside_words:
        base = []
        for i, w in enumerate(words):
            base.extend(list(w))
            if i < len(words) - 1:
                # expand separator into characters for consistent insertion behavior
                base.extend(list(separator))
    else:
        base = []
        for i, w in enumerate(words):
            base.append(w)
            if i < len(words) - 1:
                base.append(separator)

    # Insert required digits and symbols
    if min_digits > 0:
        insert_random_chars(base, string.digits, min_digits)
    if min_symbols > 0:
        insert_random_chars(base, SYMBOLS, min_symbols)

    return "".join(base)

def parse_args():
    p = argparse.ArgumentParser(description="Interactive word-based passphrase generator.")
    p.add_argument("-w", "--words", type=int, default=4, help="Number of words in passphrase (default 4)")
    p.add_argument("-s", "--separator", type=str, default="-", help="Separator between words (default '-')")
    p.add_argument("--min-digits", type=int, default=0, help="Minimum number of digits to include (default 0)")
    p.add_argument("--min-symbols", type=int, default=0, help="Minimum number of symbols to include (default 0)")
    p.add_argument("--capitalize", action="store_true", help="Randomly capitalize some words")
    p.add_argument("--wordlist", type=str, default=None, help="Path to a custom wordlist file (one word per line)")
    p.add_argument("--insert-inside-words", action="store_true", help="Allow digits/symbols to be inserted inside words (not just between)")
    p.add_argument("--tts", action="store_true", help="Start with TTS enabled (can toggle at runtime with 't')")
    p.add_argument("--tts-debug", action="store_true", help="Show TTS debug output (prints commands and errors to stderr)")
    p.add_argument("--once", action="store_true", help="Generate one passphrase and exit (non-interactive)")
    return p.parse_args()

def interactive_loop(args, words):
    try:
        # Track runtime TTS state separately from the startup flag
        tts_enabled = bool(args.tts)
        tts_available = tts_probe_available() if tts_enabled else tts_probe_available()  # probe regardless so toggle can work
        if args.tts and not tts_available:
            print("(TTS backend not available on this system or not found on PATH.)", file=sys.stderr)

        # Show quick instructions including toggle key
        print("Interactive mode. Press Enter to generate another, 't' to toggle TTS, or 'q' to quit.")

        while True:
            # FORCE two-word passphrase regardless of --words
            passphrase = generate_passphrase(
                wordlist=words,
                word_count=2,
                separator=args.separator,
                min_digits=args.min_digits,
                min_symbols=args.min_symbols,
                capitalize=args.capitalize,
                insert_inside_words=args.insert_inside_words
            )
            # append a random single digit to the end
            passphrase = passphrase + secrets.choice(string.digits)
            print("\n" + passphrase + "\n")
            # Speak if enabled and available; use debug flag if provided
            if tts_enabled and tts_available:
                ok = speak(passphrase, debug=args.tts_debug)
                if not ok:
                    # If speak fails at runtime, inform user and avoid repeated attempts
                    print("(TTS attempted but failed to play audio. Run with --tts-debug for details.)", file=sys.stderr)
                    tts_available = False

            # Prompt: Enter to repeat, 't' to toggle, 'q' to exit
            try:
                resp = input("Press Enter to generate another, 't' to toggle TTS, or 'q' to quit: ").strip().lower()
            except EOFError:
                print("\nExiting.")
                break

            if resp in ("q", "quit"):
                print("Goodbye.")
                break

            if resp == "t":
                # Toggle TTS state
                tts_enabled = not tts_enabled
                status = "enabled" if tts_enabled else "disabled"
                print(f"TTS {status}.")
                # If enabling, re-check availability and attempt a short spoken confirmation
                if tts_enabled:
                    tts_available = tts_probe_available()
                    if not tts_available:
                        print("(TTS backend not available on this system or not found on PATH.)", file=sys.stderr)
                    else:
                        # speak a short confirmation; ignore failure but show debug if requested
                        ok = speak("Text to speech enabled", debug=args.tts_debug)
                        if not ok:
                            print("(TTS enabled but playback failed. Run with --tts-debug for details.)", file=sys.stderr)
                continue

            # any other input (including empty) repeats (generate another)
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting.")

def main():
    args = parse_args()
    # Basic CLI validation
    if args.words < 1:
        print("Error: --words must be >= 1", file=sys.stderr)
        sys.exit(2)
    if args.min_digits < 0 or args.min_symbols < 0:
        print("Error: --min-digits and --min-symbols must be >= 0", file=sys.stderr)
        sys.exit(2)

    try:
        if args.wordlist:
            words = load_wordlist(args.wordlist)
        else:
            words = DEFAULT_WORDS

        if args.once:
            # Non-interactive single generation — FORCE two-word passphrase regardless of --words
            passphrase = generate_passphrase(
                wordlist=words,
                word_count=2,
                separator=args.separator,
                min_digits=args.min_digits,
                min_symbols=args.min_symbols,
                capitalize=args.capitalize,
                insert_inside_words=args.insert_inside_words
            )
            # append a random single digit to the end
            passphrase = passphrase + secrets.choice(string.digits)
            print(passphrase)
            if args.tts:
                if not tts_probe_available():
                    print("# TTS backend not available on this system.", file=sys.stderr)
                else:
                    if not speak(passphrase, debug=args.tts_debug):
                        print("# TTS attempted but failed to play audio. Run with --tts-debug for details.", file=sys.stderr)
            return

        # Interactive mode (default)
        interactive_loop(args, words)

    except Exception as e:
        print("Error:", e, file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
