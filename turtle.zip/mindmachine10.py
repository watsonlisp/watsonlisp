"""
mind_machine_two_leds_controls_extended_visual_freq_sound_off_by_default.py
Two-LED mind machine with interactive controls, keyboard shortcuts, Save As, color pickers,
sound off by default (no WAV generation when muted), separate visual frequency controls.
Preview length set to 30 seconds.
Safety: do not use if you have epilepsy or photosensitivity.
"""

import sys
import math
import wave
import struct
import time
import tempfile
import os
import subprocess
import platform
import threading
import tkinter as tk
from tkinter import ttk, colorchooser, filedialog, messagebox

# ---------------- DEFAULT CONFIG ----------------
SAMPLE_RATE = 44100
DEFAULT_DURATION = 60.0
DEFAULT_CARRIER = 440.0
DEFAULT_TARGET = 10.0            # audio binaural target (Hz)
DEFAULT_VISUAL_FREQ = 10.0       # visual oscillation frequency (Hz)
DEFAULT_VOLUME = 0.20
DEFAULT_ISOCHRONIC = True
OUTPUT_FILENAME = "mind_machine_two_leds_controls.wav"
# Visual defaults
LED_SIZE = 220
LED_GAP = 120
LED_EDGE_MS = 8.0
LED_BASELINE = 0.02
# ------------------------------------------------

def smooth_pulse_envelope(t, target, phase_offset=0.0, duty=0.5, edge_ms=6.0):
    """Raised-cosine pulse envelope for time t (seconds)."""
    if target <= 0.0:
        return 1.0
    period = 1.0 / target
    edge = max(1e-6, edge_ms / 1000.0)
    phase = ((t / period) + phase_offset) % 1.0
    on_start = 0.0
    on_end = duty
    edge_frac = min(0.45, edge / period)
    if phase >= on_start and phase < on_start + edge_frac:
        x = (phase - on_start) / edge_frac
        return 0.5 * (1 - math.cos(math.pi * x))
    if phase >= on_end - edge_frac and phase < on_end:
        x = (on_end - phase) / edge_frac
        return 0.5 * (1 - math.cos(math.pi * x))
    if phase >= on_start + edge_frac and phase < on_end - edge_frac:
        return 1.0
    return 0.0

def make_stereo_binaural_wav(filename, duration, fs, carrier, target, volume, isochronic, edge_ms=LED_EDGE_MS):
    """Generate stereo binaural WAV. Left/right carriers offset by target/2."""
    n_samples = int(fs * max(0.0, float(duration)))
    left_freq = carrier - target / 2.0
    right_freq = carrier + target / 2.0
    max_amp = 32767
    fade_ms = 80.0
    fade_samples = int(fs * (fade_ms / 1000.0))
    block = []
    block_size = 4096
    with wave.open(filename, 'wb') as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(fs)
        for i in range(n_samples):
            t = i / fs
            l = math.sin(2.0 * math.pi * left_freq * t)
            r = math.sin(2.0 * math.pi * right_freq * t)
            if isochronic and target > 0.0:
                env = smooth_pulse_envelope(t, target, phase_offset=0.0, duty=0.5, edge_ms=edge_ms)
                l *= env; r *= env
            if i < fade_samples:
                gain = (i / fade_samples); l *= gain; r *= gain
            elif i > n_samples - fade_samples:
                gain = ((n_samples - i) / fade_samples); l *= gain; r *= gain
            li = int(max(-1.0, min(1.0, l * volume)) * max_amp)
            ri = int(max(-1.0, min(1.0, r * volume)) * max_amp)
            block.append(struct.pack('<hh', li, ri))
            if len(block) >= block_size:
                wf.writeframes(b''.join(block)); block = []
        if block:
            wf.writeframes(b''.join(block))

def play_wav_platform(filename):
    """Start playback asynchronously. Returns (method, handle)."""
    plat = sys.platform
    try:
        if plat.startswith('win'):
            import winsound
            winsound.PlaySound(filename, winsound.SND_FILENAME | winsound.SND_ASYNC)
            return ('winsound', None)
        elif plat == 'darwin':
            proc = subprocess.Popen(['afplay', filename], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return ('popen', proc)
        else:
            for cmd in (['paplay', filename], ['aplay', filename], ['ffplay', '-nodisp', '-autoexit', filename]):
                try:
                    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return ('popen', proc)
                except FileNotFoundError:
                    continue
    except Exception:
        pass
    return (None, None)

def stop_playback(player_tuple):
    method, handle = player_tuple
    if method == 'winsound':
        try:
            import winsound
            winsound.PlaySound(None, winsound.SND_PURGE)
        except Exception:
            pass
    elif method == 'popen' and handle is not None:
        try:
            handle.terminate()
        except Exception:
            try: handle.kill()
            except Exception: pass

def rgb_to_hex(rgb):
    return '#{:02x}{:02x}{:02x}'.format(*rgb)

class TwoLedApp:
    def __init__(self, root):
        self.root = root
        root.title("Two-LED Mind Machine - Controls")
        self.player = (None, None)
        self.audio_thread = None
        self.visual_running = False
        self.fullscreen = False
        self.stop_flag = threading.Event()
        self.visual_paused = False
        self.current_wav_path = None

        # Parameters (tk variables)
        self.target_var = tk.DoubleVar(value=DEFAULT_TARGET)         # audio target (Hz)
        self.visual_freq_var = tk.DoubleVar(value=DEFAULT_VISUAL_FREQ)  # visual frequency (Hz)
        self.sync_visual_to_audio_var = tk.BooleanVar(value=False)   # if True, visuals follow audio target
        self.volume_var = tk.DoubleVar(value=DEFAULT_VOLUME)
        self.duration_var = tk.DoubleVar(value=DEFAULT_DURATION)
        self.phase_var = tk.DoubleVar(value=0.5)
        self.iso_var = tk.BooleanVar(value=DEFAULT_ISOCHRONIC)
        self.carrier_var = tk.DoubleVar(value=DEFAULT_CARRIER)
        self.left_color = (255, 160, 60)
        self.right_color = (120, 200, 255)
        self.baseline_var = tk.DoubleVar(value=LED_BASELINE)
        # Sound toggle variable: OFF by default
        self.sound_on_var = tk.BooleanVar(value=False)

        # Layout: controls frame on top, canvas below
        ctrl = ttk.Frame(root, padding=8)
        ctrl.pack(side='top', fill='x')

        # Row 1 controls
        ttk.Label(ctrl, text="Audio Target Hz").grid(row=0, column=0, sticky='w')
        ttk.Scale(ctrl, from_=0.5, to=40.0, variable=self.target_var, orient='horizontal', length=200).grid(row=0, column=1, sticky='w')
        ttk.Label(ctrl, textvariable=self._fmt_var(self.target_var, "{:.2f} Hz")).grid(row=0, column=2, padx=8)

        ttk.Label(ctrl, text="Visual Freq Hz").grid(row=0, column=3, sticky='w')
        ttk.Scale(ctrl, from_=0.5, to=60.0, variable=self.visual_freq_var, orient='horizontal', length=200).grid(row=0, column=4, sticky='w')
        ttk.Label(ctrl, textvariable=self._fmt_var(self.visual_freq_var, "{:.2f} Hz")).grid(row=0, column=5, padx=8)

        # Row 2 controls
        ttk.Checkbutton(ctrl, text="Sync visuals to audio target", variable=self.sync_visual_to_audio_var).grid(row=1, column=0, columnspan=2, sticky='w')
        ttk.Label(ctrl, text="Volume").grid(row=1, column=2, sticky='w')
        ttk.Scale(ctrl, from_=0.0, to=1.0, variable=self.volume_var, orient='horizontal', length=200).grid(row=1, column=3, sticky='w')
        ttk.Label(ctrl, textvariable=self._fmt_var(self.volume_var, "{:.2f}")).grid(row=1, column=4, padx=8)

        # Row 3 controls
        ttk.Label(ctrl, text="Duration (s)").grid(row=2, column=0, sticky='w')
        ttk.Scale(ctrl, from_=5, to=600, variable=self.duration_var, orient='horizontal', length=200).grid(row=2, column=1, sticky='w')
        ttk.Label(ctrl, textvariable=self._fmt_var(self.duration_var, "{:.0f} s")).grid(row=2, column=2, padx=8)

        ttk.Label(ctrl, text="Phase Spread").grid(row=2, column=3, sticky='w')
        ttk.Scale(ctrl, from_=0.0, to=1.0, variable=self.phase_var, orient='horizontal', length=200).grid(row=2, column=4, sticky='w')
        ttk.Label(ctrl, textvariable=self._fmt_var(self.phase_var, "{:.2f}")).grid(row=2, column=5, padx=8)

        # Row 4 controls
        ttk.Checkbutton(ctrl, text="Isochronic (audio)", variable=self.iso_var).grid(row=3, column=0, sticky='w')
        ttk.Label(ctrl, text="Carrier Hz").grid(row=3, column=1, sticky='w')
        ttk.Scale(ctrl, from_=100.0, to=1000.0, variable=self.carrier_var, orient='horizontal', length=200).grid(row=3, column=2, sticky='w')
        ttk.Label(ctrl, textvariable=self._fmt_var(self.carrier_var, "{:.0f} Hz")).grid(row=3, column=3, padx=8)

        # Row 5: color pickers and baseline
        ttk.Button(ctrl, text="Left Color", command=self.pick_left_color).grid(row=4, column=0, sticky='w', pady=6)
        self.left_preview = tk.Canvas(ctrl, width=24, height=16, highlightthickness=0)
        self.left_preview.grid(row=4, column=1, sticky='w')
        self.left_preview.create_rectangle(0,0,24,16, fill=rgb_to_hex(self.left_color), outline='')

        ttk.Button(ctrl, text="Right Color", command=self.pick_right_color).grid(row=4, column=2, sticky='w')
        self.right_preview = tk.Canvas(ctrl, width=24, height=16, highlightthickness=0)
        self.right_preview.grid(row=4, column=3, sticky='w')
        self.right_preview.create_rectangle(0,0,24,16, fill=rgb_to_hex(self.right_color), outline='')

        ttk.Label(ctrl, text="Baseline").grid(row=4, column=4, sticky='w')
        ttk.Scale(ctrl, from_=0.0, to=0.5, variable=self.baseline_var, orient='horizontal', length=200).grid(row=4, column=5, sticky='w')

        # Row 6: sound toggle and buttons
        ttk.Checkbutton(ctrl, text="Sound On", variable=self.sound_on_var, command=self.toggle_sound).grid(row=5, column=0, sticky='w', pady=(6,0))
        btn_frame = ttk.Frame(ctrl)
        btn_frame.grid(row=5, column=1, columnspan=5, sticky='e', pady=(6,0))
        self.preview_btn = ttk.Button(btn_frame, text="Preview 30s (P)", command=self.preview)
        self.preview_btn.pack(side='left', padx=4)
        self.play_btn = ttk.Button(btn_frame, text="Generate & Play", command=self.generate_and_play)
        self.play_btn.pack(side='left', padx=4)
        self.save_btn = ttk.Button(btn_frame, text="Save As...", command=self.save_as)
        self.save_btn.pack(side='left', padx=4)
        self.stop_btn = ttk.Button(btn_frame, text="Stop (Esc)", command=self.stop_session, state='disabled')
        self.stop_btn.pack(side='left', padx=4)
        self.full_btn = ttk.Button(btn_frame, text="Toggle Fullscreen", command=self.toggle_fullscreen)
        self.full_btn.pack(side='left', padx=4)
        ttk.Label(btn_frame, text="  Shortcuts: P=Preview  Space=Pause visuals  S=Save As  M=Toggle Sound").pack(side='left', padx=8)

        # Canvas for LEDs
        self.canvas = tk.Canvas(root, bg='black', highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)
        self.root.update_idletasks()
        self._create_leds()

        # Bindings
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.bind('<Escape>', lambda e: self.stop_session())
        root.bind('<space>', lambda e: self.toggle_visual_pause())
        root.bind('<p>', lambda e: self.preview())
        root.bind('<P>', lambda e: self.preview())
        root.bind('<s>', lambda e: self.save_as())
        root.bind('<S>', lambda e: self.save_as())
        root.bind('<m>', lambda e: self._toggle_sound_shortcut())
        root.bind('<M>', lambda e: self._toggle_sound_shortcut())

    def _fmt_var(self, var, fmt):
        s = tk.StringVar()
        def update(*_):
            try:
                s.set(fmt.format(var.get()))
            except Exception:
                s.set(str(var.get()))
        var.trace_add('write', update)
        update()
        return s

    def _create_leds(self):
        sw = self.root.winfo_width() or self.root.winfo_screenwidth()
        sh = self.root.winfo_height() or self.root.winfo_screenheight()
        total_w = LED_SIZE * 2 + LED_GAP
        cx = sw // 2 - total_w // 2
        cy = sh // 2 - LED_SIZE // 2
        self.left_pos = (cx, cy)
        self.right_pos = (cx + LED_SIZE + LED_GAP, cy)
        self.canvas.delete('all')
        self.left_id = self.canvas.create_oval(self.left_pos[0], self.left_pos[1],
                                               self.left_pos[0] + LED_SIZE, self.left_pos[1] + LED_SIZE,
                                               fill=rgb_to_hex((0,0,0)), outline='')
        self.right_id = self.canvas.create_oval(self.right_pos[0], self.right_pos[1],
                                                self.right_pos[0] + LED_SIZE, self.right_pos[1] + LED_SIZE,
                                                fill=rgb_to_hex((0,0,0)), outline='')

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        self.root.attributes('-fullscreen', self.fullscreen)
        self.root.after(50, self._create_leds)

    def pick_left_color(self):
        c = colorchooser.askcolor(color=rgb_to_hex(self.left_color), title="Choose left LED color")
        if c and c[0]:
            self.left_color = tuple(int(x) for x in c[0])
            self.left_preview.create_rectangle(0,0,24,16, fill=rgb_to_hex(self.left_color), outline='')

    def pick_right_color(self):
        c = colorchooser.askcolor(color=rgb_to_hex(self.right_color), title="Choose right LED color")
        if c and c[0]:
            self.right_color = tuple(int(x) for x in c[0])
            self.right_preview.create_rectangle(0,0,24,16, fill=rgb_to_hex(self.right_color), outline='')

    def preview(self):
        if self.audio_thread and self.audio_thread.is_alive():
            return
        params = self._current_params()
        params['duration'] = 30.0
        self._start_session(params)

    def generate_and_play(self):
        if self.audio_thread and self.audio_thread.is_alive():
            return
        params = self._current_params()
        self._start_session(params)

    def save_as(self):
        # Ask user for path and generate WAV there (no playback)
        params = self._current_params()
        path = filedialog.asksaveasfilename(defaultextension='.wav', filetypes=[('WAV files','*.wav')], initialfile=OUTPUT_FILENAME)
        if not path:
            return
        # generate in background to avoid blocking UI
        def gen():
            try:
                make_stereo_binaural_wav(path,
                                        duration=params['duration'],
                                        fs=SAMPLE_RATE,
                                        carrier=params['carrier'],
                                        target=params['target'],
                                        volume=params['volume'],
                                        isochronic=params['isochronic'],
                                        edge_ms=LED_EDGE_MS)
                self.root.after(0, lambda: messagebox.showinfo("Saved", f"WAV saved to:\n{path}"))
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to save WAV:\n{e}"))
        threading.Thread(target=gen, daemon=True).start()

    def _current_params(self):
        return {
            'duration': float(self.duration_var.get()),
            'carrier': float(self.carrier_var.get()),
            'target': float(self.target_var.get()),
            'visual_freq': float(self.visual_freq_var.get()),
            'sync_visual_to_audio': bool(self.sync_visual_to_audio_var.get()),
            'volume': float(self.volume_var.get()),
            'isochronic': bool(self.iso_var.get()),
            'phase_spread': float(self.phase_var.get()),
            'left_color': self.left_color,
            'right_color': self.right_color,
            'baseline': float(self.baseline_var.get()),
        }

    def _start_session(self, params):
        """
        Start a visual session. WAV generation is performed only if sound is enabled.
        If sound is disabled, visuals start immediately and no WAV is generated.
        """
        self.preview_btn.config(state='disabled'); self.play_btn.config(state='disabled'); self.save_btn.config(state='disabled')
        self.stop_btn.config(state='normal')
        self.stop_flag.clear()
        tmpdir = tempfile.gettempdir()
        filename = os.path.join(tmpdir, OUTPUT_FILENAME)

        # Clear current wav path unless we will generate one
        self.current_wav_path = None

        def gen_and_play():
            # Generate WAV only if sound is enabled at the moment the session starts.
            if self.sound_on_var.get():
                try:
                    make_stereo_binaural_wav(filename,
                                            duration=params['duration'],
                                            fs=SAMPLE_RATE,
                                            carrier=params['carrier'],
                                            target=params['target'],
                                            volume=params['volume'],
                                            isochronic=params['isochronic'],
                                            edge_ms=LED_EDGE_MS)
                    # remember generated file path so toggling sound on later can reuse it
                    self.current_wav_path = filename
                except Exception as e:
                    print("Error generating WAV:", e)
                    self.root.after(0, self._session_ended)
                    return
                # start playback
                self.player = play_wav_platform(filename)
            else:
                # Sound is off: do not generate WAV and do not start playback
                self.player = (None, None)
                self.current_wav_path = None

            # Start visuals regardless of sound
            self.visual_running = True
            self.visual_paused = False
            self._visual_start_time = time.time()
            # store visual params separately so visuals can use independent frequency
            self._visual_params = params
            self._visual_update()

            # Wait for duration or stop
            start = time.time()
            while time.time() - start < params['duration']:
                if self.stop_flag.is_set():
                    break
                time.sleep(0.1)

            # Stop playback if any, and end visuals
            stop_playback(self.player)
            self.visual_running = False
            self.root.after(0, self._session_ended)

        self.audio_thread = threading.Thread(target=gen_and_play, daemon=True)
        self.audio_thread.start()

    def toggle_sound(self):
        """
        Called when the Sound On checkbox is toggled.
        If a session is running and sound is turned off, stop playback and do NOT generate WAV.
        If a session is running and sound is turned on, generate the WAV (if not present) and start playback.
        """
        on = bool(self.sound_on_var.get())

        # If no session running, nothing to do now; WAV will be generated when session starts.
        if not self.visual_running and not (self.audio_thread and self.audio_thread.is_alive()):
            return

        # If turning sound off during a running session: stop playback and ensure no WAV is generated further.
        if not on:
            stop_playback(self.player)
            self.player = (None, None)
            self.current_wav_path = None
            return

        # If turning sound on during a running session: generate WAV (in background) and start playback.
        if on:
            # If we already have a generated WAV file, just start playback.
            if self.current_wav_path and os.path.exists(self.current_wav_path):
                if not (self.player and self.player[0]):
                    self.player = play_wav_platform(self.current_wav_path)
                return

            # Otherwise generate WAV in background and play when ready
            tmpdir = tempfile.gettempdir()
            filename = os.path.join(tmpdir, OUTPUT_FILENAME)

            def gen_then_play():
                try:
                    # Use the same visual params if available, otherwise current UI params
                    params = getattr(self, '_visual_params', self._current_params())
                    make_stereo_binaural_wav(filename,
                                            duration=params['duration'],
                                            fs=SAMPLE_RATE,
                                            carrier=params['carrier'],
                                            target=params['target'],
                                            volume=params['volume'],
                                            isochronic=params['isochronic'],
                                            edge_ms=LED_EDGE_MS)
                    self.current_wav_path = filename
                    # start playback if visuals still running
                    if self.visual_running:
                        self.player = play_wav_platform(filename)
                except Exception as e:
                    print("Error generating WAV after enabling sound:", e)

            threading.Thread(target=gen_then_play, daemon=True).start()

    def _toggle_sound_shortcut(self):
        # keyboard shortcut handler for M
        self.sound_on_var.set(not self.sound_on_var.get())
        self.toggle_sound()

    def _visual_update(self):
        if not self.visual_running:
            return
        if self.visual_paused:
            # keep scheduling while paused so resume works
            self.root.after(100, self._visual_update)
            return

        elapsed = time.time() - self._visual_start_time
        params = self._visual_params

        # Determine which frequency visuals should use
        visual_target = params['target'] if params.get('sync_visual_to_audio') else params.get('visual_freq', DEFAULT_VISUAL_FREQ)

        left_phase = -params['phase_spread'] / 2.0
        right_phase = params['phase_spread'] / 2.0

        env_l = smooth_pulse_envelope(elapsed, visual_target, phase_offset=left_phase, duty=0.5, edge_ms=LED_EDGE_MS) if params['isochronic'] else 1.0
        env_r = smooth_pulse_envelope(elapsed, visual_target, phase_offset=right_phase, duty=0.5, edge_ms=LED_EDGE_MS) if params['isochronic'] else 1.0

        b_l = params.get('baseline', LED_BASELINE) + (1.0 - params.get('baseline', LED_BASELINE)) * env_l
        b_r = params.get('baseline', LED_BASELINE) + (1.0 - params.get('baseline', LED_BASELINE)) * env_r

        lc = params.get('left_color', (255,160,60)); rc = params.get('right_color', (120,200,255))
        lr = int(lc[0] * b_l); lg = int(lc[1] * b_l); lb = int(lc[2] * b_l)
        rr = int(rc[0] * b_r); rg = int(rc[1] * b_r); rb = int(rc[2] * b_r)

        self.canvas.itemconfig(self.left_id, fill=rgb_to_hex((lr, lg, lb)))
        self.canvas.itemconfig(self.right_id, fill=rgb_to_hex((rr, rg, rb)))

        if self.visual_running:
            self.root.after(16, self._visual_update)

    def toggle_visual_pause(self):
        # Space toggles visual pause/resume (audio continues where it is)
        if not self.visual_running:
            return
        self.visual_paused = not self.visual_paused
        # if resuming, adjust start time so visuals continue smoothly
        if not self.visual_paused:
            self._visual_start_time += (time.time() - getattr(self, '_pause_time', time.time()))
        else:
            self._pause_time = time.time()

    def stop_session(self):
        self.stop_flag.set()
        stop_playback(self.player)
        self.player = (None, None)
        self.visual_running = False
        self._session_ended()

    def _session_ended(self):
        self.preview_btn.config(state='normal'); self.play_btn.config(state='normal'); self.save_btn.config(state='normal')
        self.stop_btn.config(state='disabled')
        self.canvas.itemconfig(self.left_id, fill=rgb_to_hex((0,0,0)))
        self.canvas.itemconfig(self.right_id, fill=rgb_to_hex((0,0,0)))

    def on_close(self):
        self.stop_session()
        time.sleep(0.05)
        try:
            self.root.destroy()
        except Exception:
            pass

def main():
    root = tk.Tk()
    app = TwoLedApp(root)
    root.mainloop()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrupted by user. Exiting.")
