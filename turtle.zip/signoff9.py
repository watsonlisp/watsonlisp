import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import os
import sys
import tempfile
import wave
import struct
import math
import subprocess
import time
import shutil

# ---------- Tone parameters ----------
FREQ_HZ = 800.0
WAV_DUR_S = 2.0
VOLUME = 0.5
SR = 44100

# ---------- Platform audio ----------
try:
    import winsound
    _HAS_WINSOUND = True
except Exception:
    _HAS_WINSOUND = False

# ---------- File search ----------
COMMON_NAMES = [
    "testpattern.png", "test_pattern.png", "test-pattern.png",
    "testpattern.gif", "test_pattern.gif", "test-pattern.gif",
    "testpattern.ppm", "testpattern.pgm"
]

def find_testpattern(start_dir="."):
    """Search start_dir and subdirs for common test pattern filenames.
    Returns the first matching path or None."""
    # First check exact common names (case-insensitive)
    lower_common = {name.lower(): name for name in COMMON_NAMES}
    for root, dirs, files in os.walk(start_dir):
        for f in files:
            if f.lower() in lower_common:
                return os.path.join(root, f)
    # Next: any file containing 'test' and 'pattern' in name
    for root, dirs, files in os.walk(start_dir):
        for f in files:
            name = f.lower()
            if "test" in name and "pattern" in name:
                return os.path.join(root, f)
    # Next: any file containing 'testpattern' substring
    for root, dirs, files in os.walk(start_dir):
        for f in files:
            if "testpattern" in f.lower():
                return os.path.join(root, f)
    return None

# ---------- WAV generation ----------
def generate_wav(path, freq=FREQ_HZ, duration=WAV_DUR_S, vol=VOLUME, sr=SR):
    n = int(sr * duration)
    max_amp = int(32767 * vol)
    with wave.open(path, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        frames = bytearray()
        for i in range(n):
            t = i / sr
            s = int(max_amp * math.sin(2.0 * math.pi * freq * t))
            frames += struct.pack('<h', s)
        wf.writeframes(bytes(frames))

def find_player():
    if sys.platform == "darwin" and shutil.which("afplay"):
        return ["afplay"]
    if shutil.which("paplay"):
        return ["paplay"]
    if shutil.which("aplay"):
        return ["aplay"]
    return None

# ---------- Tone worker ----------
def tone_worker(stop_event, freq=FREQ_HZ, duration=WAV_DUR_S):
    wav_path = None
    try:
        # Windows: use PlaySound loop if available
        if _HAS_WINSOUND:
            # generate wav to ensure consistent tone
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
            tmp.close()
            wav_path = tmp.name
            generate_wav(wav_path, freq, duration, VOLUME, SR)
            try:
                winsound.PlaySound(wav_path, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP)
            except Exception:
                # fallback to repeated Beep
                ms = int(duration * 1000)
                while not stop_event.is_set():
                    try:
                        winsound.Beep(int(freq), ms)
                    except Exception:
                        break
                return
            while not stop_event.is_set():
                time.sleep(0.1)
            try:
                winsound.PlaySound(None, winsound.SND_PURGE)
            except Exception:
                pass
            return

        # Non-Windows: generate wav and loop-play via system player
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
        tmp.close()
        wav_path = tmp.name
        generate_wav(wav_path, freq, duration, VOLUME, SR)
        player = find_player()
        if not player:
            # no player available; keep thread alive but silent
            while not stop_event.is_set():
                time.sleep(0.2)
            return

        proc = None
        while not stop_event.is_set():
            try:
                proc = subprocess.Popen(player + [wav_path])
                while proc.poll() is None and not stop_event.is_set():
                    time.sleep(0.1)
                if proc.poll() is None:
                    proc.terminate()
                    try:
                        proc.wait(timeout=0.5)
                    except Exception:
                        proc.kill()
            except FileNotFoundError:
                break
            except Exception:
                break
        if proc and proc.poll() is None:
            try:
                proc.terminate()
            except Exception:
                pass

    finally:
        if wav_path and os.path.exists(wav_path):
            try:
                os.remove(wav_path)
            except Exception:
                pass

# ---------- GUI ----------
def main():
    root = tk.Tk()
    root.title("Test Pattern with Continuous Tone")

    # Try to auto-find testpattern in current directory tree
    found = find_testpattern(os.getcwd())
    if found:
        image_path = found
    else:
        # fallback: ask user
        image_path = filedialog.askopenfilename(
            title="Select test pattern image",
            filetypes=[("Image files", "*.png *.gif *.ppm *.pgm"), ("All files", "*.*")]
        )
        if not image_path:
            messagebox.showinfo("No image", "No image selected. Exiting.")
            root.destroy()
            return

    # Load image and keep persistent reference
    try:
        root.img = tk.PhotoImage(file=image_path)
    except Exception as e:
        messagebox.showerror("Load error", f"Failed to load image: {e}")
        root.destroy()
        return

    tk.Label(root, image=root.img).pack(expand=True)

    status = tk.Label(root, text="", anchor="w")
    status.pack(fill="x")
    if _HAS_WINSOUND:
        status.config(text=f"Audio: Windows PlaySound loop. Image: {os.path.basename(image_path)}")
    else:
        player = find_player()
        if player:
            status.config(text=f"Audio: using system player ({player[0]}). Image: {os.path.basename(image_path)}")
        else:
            status.config(text=f"Audio: no system player found; tone may be unavailable. Image: {os.path.basename(image_path)}")

    # Start tone thread
    stop_event = threading.Event()
    t = threading.Thread(target=tone_worker, args=(stop_event, FREQ_HZ, WAV_DUR_S), daemon=True)
    t.start()

    def on_close():
        stop_event.set()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()

if __name__ == "__main__":
    main()
