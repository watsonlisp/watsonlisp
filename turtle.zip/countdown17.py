#!/usr/bin/env python3
"""
film_countdown_very_short_tone.py

High-resolution film-style countdown GUI (tkinter) with:
- thin rotating arm
- very large center numbers (no leading zero)
- a very short non-blocking pure tone played once per rotation,
  emitted when the arm is at 12 o'clock (top).

For best cross-platform sound, install:
    pip install simpleaudio numpy
"""
import math
import sys
import time
import threading
import tkinter as tk
from tkinter import simpledialog, font

# Prefer simpleaudio + numpy for cross-platform synthesis
try:
    import simpleaudio as sa
    import numpy as np
    SIMPLEAUDIO_AVAILABLE = True
except Exception:
    SIMPLEAUDIO_AVAILABLE = False

# -------------------------
# Configurable parameters
# -------------------------
FPS = 60
SECONDS_PER_NUMBER = 1.0
ARM_THICKNESS_RATIO = 0.005
DIAL_PADDING_RATIO = 0.08
NUMBER_SCALE = 0.75
BG_COLOR = "#d0d0d0"
DIAL_COLOR = "#2b2b2b"
ARM_COLOR = "#111111"
NUMBER_COLOR = "#000000"
TICK_COLOR = "#444444"

# Pure tone parameters
TONE_FREQ_HZ = 1200        # frequency of the pure sine tone
TONE_DURATION_MS = 25      # very short, snappy pulse
TONE_VOLUME = 0.35         # 0.0..1.0
SAMPLE_RATE = 44100

# -------------------------
# Tone playback helper (pure sine tone)
# -------------------------
def play_computer_tone_nonblocking(freq_hz=TONE_FREQ_HZ, duration_ms=TONE_DURATION_MS,
                                   volume=TONE_VOLUME, master=None):
    """
    Play a very short pure sine 'computer' tone without blocking the GUI thread.
    Uses simpleaudio+numpy if available; otherwise falls back to the Tk bell invoked
    on the main thread (via master.after) or the terminal bell.
    """
    def _tk_bell_fallback(m):
        try:
            tk_root = m if m is not None else tk._default_root
            if tk_root is not None:
                try:
                    tk_root.after(0, tk_root.bell)
                    return
                except Exception:
                    pass
            sys.stdout.write('\a'); sys.stdout.flush()
        except Exception:
            sys.stdout.write('\a'); sys.stdout.flush()

    def _play():
        try:
            if SIMPLEAUDIO_AVAILABLE:
                # ensure a minimum audible duration
                duration_s = max(0.001, duration_ms / 1000.0)
                n_samples = max(1, int(SAMPLE_RATE * duration_s))
                t = np.linspace(0, duration_s, n_samples, False)

                # Pure sine tone (clean tone rather than a pre-recorded wav)
                wave = np.sin(2 * np.pi * float(freq_hz) * t)

                # very short attack/release envelope (~1.5-3 ms) to avoid clicks
                env_attack = max(1, int(0.0015 * SAMPLE_RATE))
                env_release = max(1, int(0.003 * SAMPLE_RATE))
                if env_attack + env_release >= len(wave):
                    env = np.linspace(0.0, 1.0, len(wave))
                else:
                    env = np.ones_like(wave)
                    env[:env_attack] = np.linspace(0.0, 1.0, env_attack)
                    env[-env_release:] = np.linspace(1.0, 0.0, env_release)
                wave *= env

                # scale to 16-bit PCM
                audio = (wave * (32767 * float(volume))).astype(np.int16)
                try:
                    sa.play_buffer(audio, 1, 2, SAMPLE_RATE)
                except Exception:
                    _tk_bell_fallback(master)
                return

            # fallback: try Tk bell (on main thread) or terminal bell
            _tk_bell_fallback(master)

        except Exception:
            _tk_bell_fallback(master)

    t = threading.Thread(target=_play, daemon=True)
    t.start()

# -------------------------
# GUI countdown class
# -------------------------
class HighResCountdown:
    def __init__(self, master, start_value):
        self.master = master
        self.start_value = max(0, int(start_value))
        self.current = self.start_value
        self.running = False

        self.canvas = tk.Canvas(master, bg=BG_COLOR, highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas.bind("<Configure>", self.on_resize)

        self.frame_interval = int(1000 / FPS)
        self.frames_per_number = max(1, int(FPS * SECONDS_PER_NUMBER))
        self.frame_index = 0
        self._last_tick_number = None

        self.width = 800
        self.height = 600
        self.cx = self.width // 2
        self.cy = self.height // 2
        self.radius = min(self.width, self.height) // 2 - 20

        initial_font_size = max(12, int(self.radius * NUMBER_SCALE / 1.2))
        self.number_font = font.Font(family="Helvetica", size=initial_font_size, weight="bold")

        self.running = True
        self._after_id = None
        self.schedule_frame()

    def on_resize(self, event):
        self.width = max(100, event.width)
        self.height = max(100, event.height)
        self.cx = self.width // 2
        self.cy = self.height // 2
        min_dim = min(self.width, self.height)
        self.radius = int((min_dim / 2) * (1 - DIAL_PADDING_RATIO))
        font_size = max(12, int(self.radius * NUMBER_SCALE / 1.2))
        self.number_font.configure(size=font_size)
        self.draw_frame()

    def schedule_frame(self):
        self.draw_frame()
        if self.running:
            self._after_id = self.master.after(self.frame_interval, self.advance_frame)

    def advance_frame(self):
        self.frame_index += 1
        if self.frame_index >= self.frames_per_number:
            self.frame_index = 0
            self.current -= 1
            if self.current < 0:
                self.running = False
                self.finish_sequence()
                return
        self.schedule_frame()

    def draw_frame(self):
        self.canvas.delete("all")
        cx, cy, r = self.cx, self.cy, self.radius
        self.canvas.create_oval(cx - r, cy - r, cx + r, cy + r, outline=DIAL_COLOR, width=max(2, int(r*0.02)))

        ticks = 12
        for i in range(ticks):
            ang = 2 * math.pi * (i / ticks)
            x1 = cx + (r - r*0.06) * math.cos(ang)
            y1 = cy - (r - r*0.06) * math.sin(ang)
            x2 = cx + r * math.cos(ang)
            y2 = cy - r * math.sin(ang)
            self.canvas.create_line(x1, y1, x2, y2, fill=TICK_COLOR, width=max(1, int(r*0.01)))

        # t goes 0..1 across the frames for the current number
        t = (self.frame_index / max(1, self.frames_per_number))

        # Angle: rotate clockwise. Offset so t==0 corresponds to 12 o'clock (top).
        # Using angle = -2*pi*t + pi/2 makes t==0 -> angle=pi/2 (pointing up).
        angle = -2 * math.pi * t + math.pi / 2

        arm_len = r * 0.95
        x_end = cx + arm_len * math.cos(angle)
        y_end = cy - arm_len * math.sin(angle)
        thickness = max(1, int(min(self.width, self.height) * ARM_THICKNESS_RATIO))
        self.canvas.create_line(cx+1, cy+1, x_end+1, y_end+1, fill="#888888", width=thickness+1, capstyle=tk.ROUND)
        self.canvas.create_line(cx, cy, x_end, y_end, fill=ARM_COLOR, width=thickness, capstyle=tk.ROUND)

        hub_r = max(3, int(thickness * 1.2))
        self.canvas.create_oval(cx - hub_r, cy - hub_r, cx + hub_r, cy + hub_r, fill=ARM_COLOR, outline="")

        txt = str(self.current) if self.current >= 0 else "0"
        self.canvas.create_text(cx, cy, text=txt, font=self.number_font, fill=NUMBER_COLOR)

        # play tone once per rotation when the arm is at 12 o'clock
        # We trigger when frame_index == 0 and ensure we don't double-trigger for the same number.
        if self.frame_index == 0 and self._last_tick_number != self.current:
            self._last_tick_number = self.current
            play_computer_tone_nonblocking(master=self.master)

    def finish_sequence(self):
        def cadence_and_show():
            for _ in range(3):
                play_computer_tone_nonblocking(master=self.master)
                time.sleep(0.18)
            play_computer_tone_nonblocking(master=self.master)
            self.current = 0
            self.frame_index = 0
            self.master.after(0, self.draw_frame)
        t = threading.Thread(target=cadence_and_show, daemon=True)
        t.start()

    def stop(self):
        self.running = False
        if self._after_id:
            self.master.after_cancel(self._after_id)
            self._after_id = None

# -------------------------
# Run the app
# -------------------------
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Film Countdown — Pure Tone at 12 o'clock")

    try:
        root.state('zoomed')
    except Exception:
        try:
            root.attributes('-zoomed', True)
        except Exception:
            pass

    try:
        start_val = simpledialog.askinteger("Start value", "Enter starting number (e.g., 10):", parent=root, minvalue=0)
        if start_val is None:
            root.destroy()
            sys.exit(0)
    except Exception:
        start_val = 10

    app = HighResCountdown(root, start_val)

    def on_close():
        app.stop()
        root.destroy()
    root.protocol("WM_DELETE_WINDOW", on_close)

    root.mainloop()
