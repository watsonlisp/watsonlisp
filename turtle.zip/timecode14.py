#!/usr/bin/env python3
"""
timecode_slate_controls_below_white_copylog.py
Timecode slate with:
- Clack bar above the display (full width)
- Controls below on a white panel
- Red seven-seg digits, stdlib clack sound
- Clack log viewer with Copy Selected, Copy All, Ctrl+C, and double-click copy
No external packages required.
"""

import sys
import os
import math
import wave
import struct
import tempfile
import threading
import subprocess
import time
import shutil
import csv
import io

try:
    import tkinter as tk
    from tkinter import ttk, messagebox
except Exception:
    raise SystemExit("tkinter is required to run this program.")

# -------------------------
# Stdlib-only clack player
# -------------------------
def play_clack():
    def _write_temp_wav(path, duration=0.04, fs=44100):
        n_samples = int(fs * duration)
        freq = 1200.0
        max_amp = 32767
        with wave.open(path, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(fs)
            for i in range(n_samples):
                t = i / fs
                sine = 0.6 * math.sin(2.0 * math.pi * freq * t)
                env = math.exp(-40.0 * t)
                noise_val = (os.urandom(1)[0] / 255.0) * 2.0 - 1.0
                noise = 0.4 * noise_val * env
                sample = sine + noise
                val = int(max(-1.0, min(1.0, sample)) * max_amp)
                wf.writeframes(struct.pack('<h', val))

    def _cleanup(path, delay=0.8):
        time.sleep(delay)
        try:
            os.remove(path)
        except Exception:
            pass

    if sys.platform.startswith("win"):
        try:
            import winsound
            try:
                winsound.Beep(1200, 30)
                winsound.Beep(800, 40)
                return
            except Exception:
                pass
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
            tmp.close()
            _write_temp_wav(tmp.name)
            try:
                winsound.PlaySound(tmp.name, winsound.SND_FILENAME | winsound.SND_ASYNC)
            except Exception:
                try:
                    root = tk.Tk(); root.withdraw(); root.bell(); root.destroy()
                except Exception:
                    pass
            threading.Thread(target=_cleanup, args=(tmp.name,), daemon=True).start()
            return
        except Exception:
            pass

    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    tmp.close()
    try:
        _write_temp_wav(tmp.name)
        played = False
        for player in ("afplay", "paplay", "aplay"):
            if shutil.which(player):
                try:
                    subprocess.run([player, tmp.name], check=False)
                    played = True
                    break
                except Exception:
                    played = False
        if not played:
            try:
                root = tk.Tk(); root.withdraw(); root.bell(); root.destroy()
            except Exception:
                pass
    finally:
        threading.Thread(target=_cleanup, args=(tmp.name,), daemon=True).start()

# -------------------------
# Seven-segment display
# -------------------------
SEGMENTS = {
    0: (1,1,1,1,1,1,0),
    1: (0,1,1,0,0,0,0),
    2: (1,1,0,1,1,0,1),
    3: (1,1,1,1,0,0,1),
    4: (0,1,1,0,0,1,1),
    5: (1,0,1,1,0,1,1),
    6: (1,0,1,1,1,1,1),
    7: (1,1,1,0,0,0,0),
    8: (1,1,1,1,1,1,1),
    9: (1,1,1,1,0,1,1),
}

class SevenSegDisplay:
    def __init__(self, canvas, x, y, size=40, color_on="#ff3333", color_off="#220000", gap=6):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.size = max(8, int(size))
        self.color_on = color_on
        self.color_off = color_off
        self.gap = max(2, int(gap))
        self.segs = []
        self._create_segments()

    def _create_segments(self):
        for s in self.segs:
            try:
                self.canvas.delete(s)
            except Exception:
                pass
        self.segs = []
        s = self.size
        g = self.gap
        x = self.x
        y = self.y
        self.segs.append(self.canvas.create_polygon(x+g, y, x+s-g, y, x+s-2*g, y+g, x+2*g, y+g, fill=self.color_off, outline=""))
        self.segs.append(self.canvas.create_polygon(x+s-g, y, x+s, y+g, x+s, y+s-g, x+s-2*g, y+s-2*g, fill=self.color_off, outline=""))
        self.segs.append(self.canvas.create_polygon(x+s-2*g, y+s-2*g, x+s, y+s-g, x+s, y+2*s-g, x+s-2*g, y+2*s-2*g, fill=self.color_off, outline=""))
        self.segs.append(self.canvas.create_polygon(x+g, y+2*s, x+s-g, y+2*s, x+s-2*g, y+2*s-g, x+2*g, y+2*s-g, fill=self.color_off, outline=""))
        self.segs.append(self.canvas.create_polygon(x, y+s-g, x+g, y+s-2*g, x+g, y+2*s-2*g, x, y+2*s-g, fill=self.color_off, outline=""))
        self.segs.append(self.canvas.create_polygon(x, y+g, x+g, y+2*g, x+g, y+s-2*g, x, y+s-g, fill=self.color_off, outline=""))
        self.segs.append(self.canvas.create_polygon(x+2*g, y+s-g, x+s-2*g, y+s-g, x+s-3*g, y+s, x+3*g, y+s, fill=self.color_off, outline=""))

    def show(self, digit):
        pattern = SEGMENTS.get(digit, (0,0,0,0,0,0,0))
        for seg_id, on in zip(self.segs, pattern):
            self.canvas.itemconfig(seg_id, fill=self.color_on if on else self.color_off)

    def move_to(self, x, y, size=None, gap=None):
        self.x = x
        self.y = y
        if size is not None:
            self.size = max(8, int(size))
        if gap is not None:
            self.gap = max(2, int(gap))
        self._create_segments()

# -------------------------
# Main application
# -------------------------
class TimecodeSlate:
    def __init__(self, root):
        self.root = root
        root.title("Timecode Slate — Copyable Log")
        root.configure(bg="#111")

        # State
        self.fps = tk.IntVar(value=24)
        self.drop_frame = tk.BooleanVar(value=False)
        self.running = False
        self.start_time = None
        self.offset = 0.0
        self.locked_time = None

        # Metadata
        self.scene = tk.IntVar(value=1)
        self.take = tk.IntVar(value=1)
        self.roll = tk.StringVar(value="A")
        self.start_tc = tk.StringVar(value="00:00:00:00")
        self.clack_log = []

        # Measured FPS tracking
        self.measured_fps = 0.0
        self._fps_count = 0
        self._fps_last_time = time.perf_counter()

        # Canvas (top)
        self.canvas = tk.Canvas(root, width=980, height=360, bg="#050505", highlightthickness=0)
        self.canvas.pack(padx=12, pady=(12,6), fill="both", expand=True)

        self.digits = []
        self.colon_ids = []
        self.meta_text = None
        self.clapper_base = None
        self.clapper_top = None

        self._layout_static_items()
        self.canvas.bind("<Configure>", lambda e: self._layout_dynamic_items())
        self.canvas.bind("<Button-1>", self.on_clack)
        root.bind("<space>", lambda e: self.on_clack(None))

        # Controls frame (below canvas) with white background
        controls = tk.Frame(root, bg="white", bd=1, relief="flat")
        controls.pack(fill="x", padx=12, pady=(6,12))

        # Left column: Scene/Take/Roll/StartTC/FPS (tk widgets so background is white)
        left = tk.Frame(controls, bg="white")
        left.pack(side="left", padx=12, pady=12)
        tk.Label(left, text="Scene:", bg="white", fg="black").grid(row=0, column=0, sticky="w", padx=(0,6))
        tk.Spinbox(left, from_=0, to=9999, textvariable=self.scene, width=8, bg="white", fg="black", relief="groove").grid(row=0, column=1, sticky="w")
        tk.Label(left, text="Take:", bg="white", fg="black").grid(row=1, column=0, sticky="w", padx=(0,6))
        tk.Spinbox(left, from_=0, to=9999, textvariable=self.take, width=8, bg="white", fg="black", relief="groove").grid(row=1, column=1, sticky="w")
        tk.Label(left, text="Roll:", bg="white", fg="black").grid(row=2, column=0, sticky="w", padx=(0,6))
        tk.Entry(left, textvariable=self.roll, width=12, bg="white", fg="black", relief="groove").grid(row=2, column=1, sticky="w")
        tk.Label(left, text="Start TC:", bg="white", fg="black").grid(row=3, column=0, sticky="w", padx=(0,6))
        start_entry = tk.Entry(left, textvariable=self.start_tc, width=12, bg="white", fg="black", relief="groove"); start_entry.grid(row=3, column=1, sticky="w")
        start_entry.bind("<Return>", lambda e: self.set_start_from_input())
        tk.Label(left, text="FPS (set):", bg="white", fg="black").grid(row=4, column=0, sticky="w", pady=(6,0))
        tk.Spinbox(left, from_=1, to=120, textvariable=self.fps, width=6, bg="white", fg="black", relief="groove").grid(row=4, column=1, sticky="w", pady=(6,0))
        tk.Checkbutton(left, text="Drop Frame", variable=self.drop_frame, bg="white").grid(row=5, column=0, columnspan=2, sticky="w", pady=(6,0))

        # Middle column: quick increment buttons
        mid = tk.Frame(controls, bg="white")
        mid.pack(side="left", padx=12, pady=12)
        tk.Button(mid, text="Next Take", command=self.next_take, bg="white").grid(row=0, column=0, pady=2, padx=4)
        tk.Button(mid, text="Prev Take", command=self.prev_take, bg="white").grid(row=1, column=0, pady=2, padx=4)
        tk.Button(mid, text="Next Scene", command=self.next_scene, bg="white").grid(row=0, column=1, pady=2, padx=4)
        tk.Button(mid, text="Prev Scene", command=self.prev_scene, bg="white").grid(row=1, column=1, pady=2, padx=4)
        tk.Button(mid, text="Reset Take to 1", command=self.reset_take, bg="white").grid(row=2, column=0, columnspan=2, pady=4)

        # Right column: playback and log + measured FPS label
        right = tk.Frame(controls, bg="white")
        right.pack(side="right", padx=12, pady=12)
        tk.Button(right, text="Start", command=self.start, bg="white").grid(row=0, column=0, padx=4)
        tk.Button(right, text="Stop", command=self.stop, bg="white").grid(row=0, column=1, padx=4)
        tk.Button(right, text="Reset", command=self.reset, bg="white").grid(row=0, column=2, padx=4)
        tk.Button(right, text="Set Start", command=self.set_start_from_input, bg="white").grid(row=1, column=0, columnspan=3, pady=(6,0))
        tk.Button(right, text="Show Log", command=self.show_log, bg="white").grid(row=2, column=0, columnspan=3, pady=(6,0))
        self.measured_fps_label = tk.Label(right, text="Measured FPS: 0.0", bg="white", fg="black", font=("Helvetica", 10))
        self.measured_fps_label.grid(row=3, column=0, columnspan=3, pady=(8,0))

        # traces to update meta text
        self.scene.trace_add("write", lambda *a: self.update_meta_text())
        self.take.trace_add("write", lambda *a: self.update_meta_text())
        self.roll.trace_add("write", lambda *a: self.update_meta_text())
        self.fps.trace_add("write", lambda *a: self.update_meta_text())

        self.update_loop()

    # Layout helpers
    def _layout_static_items(self):
        self.clapper_base = self.canvas.create_rectangle(0, 10, 100, 44, fill="#333", outline="#555")
        self.clapper_top = self.canvas.create_rectangle(0, -26, 100, 8, fill="#666", outline="#888")
        self.meta_text = self.canvas.create_text(680, 120, text=self._meta_string(), fill="#ddd", anchor="nw", font=("Helvetica", 14))

    def _clear_digits(self):
        for d in self.digits:
            for seg in getattr(d, "segs", []):
                try:
                    self.canvas.delete(seg)
                except Exception:
                    pass
        self.digits = []
        for cid in self.colon_ids:
            try:
                self.canvas.delete(cid)
            except Exception:
                pass
        self.colon_ids = []

    def _layout_dynamic_items(self):
        self.canvas.update_idletasks()
        cw = max(300, self.canvas.winfo_width())
        ch = max(220, self.canvas.winfo_height())
        left_margin = 20
        right_margin = 20
        num_digits = 8
        colon_extra = 3 * 18
        available = cw - left_margin - right_margin - colon_extra
        spacing = 8
        total_spacing = (num_digits - 1) * spacing
        digit_size = max(18, int((available - total_spacing) / num_digits))
        digit_y = int(ch * 0.28)
        self._clear_digits()
        x = left_margin
        for i in range(num_digits):
            seg = SevenSegDisplay(self.canvas, x, digit_y, size=digit_size, color_on="#ff3333", color_off="#220000", gap=max(4, digit_size//10))
            self.digits.append(seg)
            x += digit_size + spacing
            if i in (1,3,5):
                dot_x = x - (spacing // 2) + 6
                top_dot = self.canvas.create_oval(dot_x-4, digit_y + digit_size//2 - 6, dot_x+4, digit_y + digit_size//2 - 2, fill="#ff3333", outline="")
                bot_dot = self.canvas.create_oval(dot_x-4, digit_y + digit_size//2 + 18, dot_x+4, digit_y + digit_size//2 + 22, fill="#ff3333", outline="")
                self.colon_ids.extend([top_dot, bot_dot])
                x += 12
        self.canvas.coords(self.meta_text, cw - 260, digit_y - 30)
        # clack bar spans digits area
        cl_left = left_margin
        cl_right = cw - right_margin
        base_top = 10
        base_bottom = base_top + 34
        self.canvas.coords(self.clapper_base, cl_left, base_top, cl_right, base_bottom)
        top_top = base_top - 46
        top_bottom = base_top - 12
        self.canvas.coords(self.clapper_top, cl_left, top_top, cl_right, top_bottom)

    # Metadata helpers
    def _meta_string(self):
        return f"Scene: {self.scene.get():d}   Take: {self.take.get():d}   Roll: {self.roll.get()}   FPS(set): {self.fps.get():d}"

    def update_meta_text(self):
        self.canvas.itemconfig(self.meta_text, text=self._meta_string())

    # Scene/Take helpers
    def next_take(self): self.take.set(self.take.get() + 1)
    def prev_take(self):
        if self.take.get() > 0: self.take.set(self.take.get() - 1)
    def reset_take(self): self.take.set(1)
    def next_scene(self): self.scene.set(self.scene.get() + 1)
    def prev_scene(self):
        if self.scene.get() > 0: self.scene.set(self.scene.get() - 1)

    # Timecode helpers
    def parse_timecode(self, s):
        try:
            parts = s.strip().split(":")
            if len(parts) != 4: return 0.0
            h, m, sec, f = map(int, parts)
            return ((h * 3600) + (m * 60) + sec) + (f / max(1, self.fps.get()))
        except Exception:
            return 0.0

    def seconds_to_timecode(self, seconds):
        fps = max(1, self.fps.get())
        total_frames = int(round(seconds * fps))
        frames = total_frames % fps
        secs = (total_frames // fps) % 60
        mins = (total_frames // (fps * 60)) % 60
        hours = total_frames // (fps * 3600)
        return hours, mins, secs, frames

    def format_timecode(self, h, m, s, f):
        return f"{h:02d}:{m:02d}:{s:02d}:{f:02d}"

    def update_display_digits(self, seconds):
        if not self.digits:
            self._layout_dynamic_items()
        h, m, s, f = self.seconds_to_timecode(seconds)
        tc_str = f"{h:02d}{m:02d}{s:02d}{f:02d}"
        for i, ch in enumerate(tc_str):
            digit = int(ch)
            if i < len(self.digits):
                self.digits[i].show(digit)
        self.update_meta_text()

    # Playback controls
    def start(self):
        if not self.running:
            if self.offset == 0.0 and self.start_tc.get().strip():
                self.offset = self.parse_timecode(self.start_tc.get())
            self.running = True
            self.start_time = time.perf_counter() - self.offset
            self.locked_time = None

    def stop(self):
        if self.running:
            self.running = False
            self.offset = time.perf_counter() - self.start_time
            self.locked_time = None

    def reset(self):
        self.running = False
        self.start_time = None
        self.offset = 0.0
        self.locked_time = None
        self.update_display_digits(0.0)

    def set_start_from_input(self):
        self.offset = self.parse_timecode(self.start_tc.get())
        if self.running:
            self.start_time = time.perf_counter() - self.offset

    def get_current_seconds(self):
        if self.running and self.start_time is not None:
            return time.perf_counter() - self.start_time
        else:
            return self.offset

    # Clack handling
    def on_clack(self, event):
        current = self.get_current_seconds()
        self.locked_time = current
        threading.Thread(target=play_clack, daemon=True).start()
        self.animate_clapper()
        h, m, s, f = self.seconds_to_timecode(current)
        tc = self.format_timecode(h, m, s, f)
        self.start_tc.set(tc)
        entry = {
            "scene": int(self.scene.get()),
            "take": int(self.take.get()),
            "roll": self.roll.get(),
            "timecode": tc,
            "wall_ts": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        }
        self.clack_log.append(entry)

    def animate_clapper(self):
        base_coords = self.canvas.coords(self.clapper_base)
        top_coords = self.canvas.coords(self.clapper_top)
        if not base_coords or not top_coords:
            return
        travel = (base_coords[1] - top_coords[3]) + 18
        steps = 8
        def step(i):
            if i < steps:
                dy = int(travel / (steps/2)) if i < steps/2 else -int(travel / (steps/2))
                self.canvas.move(self.clapper_top, 0, dy)
                self.root.after(25, lambda: step(i+1))
            else:
                cl_left, base_top, cl_right, base_bottom = base_coords
                self.canvas.coords(self.clapper_top, cl_left, base_top - 46, cl_right, base_top - 12)
        step(0)

    # Log viewer with copy functionality
    def show_log(self):
        win = tk.Toplevel(self.root)
        win.title("Clack Log")
        win.geometry("760x420")

        frame = tk.Frame(win)
        frame.pack(fill="both", expand=True, padx=8, pady=8)

        cols = ("Scene", "Take", "Roll", "Timecode", "Wall Timestamp")
        tree = ttk.Treeview(frame, columns=cols, show="headings", height=14, selectmode="extended")
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=130, anchor="center")
        tree.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

        # populate
        for e in self.clack_log:
            tree.insert("", "end", values=(e["scene"], e["take"], e["roll"], e["timecode"], e["wall_ts"]))

        # copy helpers
        def rows_to_csv(rows):
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow(cols)
            for r in rows:
                writer.writerow(r)
            return output.getvalue()

        def get_selected_rows():
            sel = tree.selection()
            rows = []
            for iid in sel:
                rows.append(tree.item(iid, "values"))
            return rows

        def copy_selected():
            rows = get_selected_rows()
            if not rows:
                messagebox.showinfo("Copy Selected", "No rows selected.")
                return
            text = rows_to_csv(rows)
            win.clipboard_clear()
            win.clipboard_append(text)
            # keep window on top briefly to show action
            win.update()
            messagebox.showinfo("Copied", f"Copied {len(rows)} row(s) to clipboard.")

        def copy_all():
            # copy entire log
            rows = [ (e["scene"], e["take"], e["roll"], e["timecode"], e["wall_ts"]) for e in self.clack_log ]
            if not rows:
                messagebox.showinfo("Copy All", "Log is empty.")
                return
            text = rows_to_csv(rows)
            win.clipboard_clear()
            win.clipboard_append(text)
            win.update()
            messagebox.showinfo("Copied", f"Copied {len(rows)} row(s) to clipboard.")

        # Buttons
        btn_frame = tk.Frame(win)
        btn_frame.pack(fill="x", padx=8, pady=(0,8))
        copy_sel_btn = tk.Button(btn_frame, text="Copy Selected", command=copy_selected)
        copy_sel_btn.pack(side="left", padx=6)
        copy_all_btn = tk.Button(btn_frame, text="Copy All", command=copy_all)
        copy_all_btn.pack(side="left", padx=6)
        close_btn = tk.Button(btn_frame, text="Close", command=win.destroy)
        close_btn.pack(side="right", padx=6)

        # Double-click copies that row
        def on_double_click(event):
            item = tree.identify_row(event.y)
            if item:
                vals = tree.item(item, "values")
                text = rows_to_csv([vals])
                win.clipboard_clear()
                win.clipboard_append(text)
                messagebox.showinfo("Copied", "Copied 1 row to clipboard.")
        tree.bind("<Double-1>", on_double_click)

        # Ctrl+C binding to copy selected
        def on_ctrl_c(event=None):
            copy_selected()
            return "break"
        tree.bind_all("<Control-c>", on_ctrl_c)
        tree.bind_all("<Control-C>", on_ctrl_c)

    # Main loop (also measures FPS)
    def update_loop(self):
        # FPS measurement
        self._fps_count += 1
        now = time.perf_counter()
        elapsed = now - self._fps_last_time
        if elapsed >= 1.0:
            self.measured_fps = self._fps_count / elapsed
            self._fps_count = 0
            self._fps_last_time = now
            try:
                self.measured_fps_label.config(text=f"Measured FPS: {self.measured_fps:.1f}")
            except Exception:
                pass

        if self.locked_time is not None:
            self.update_display_digits(self.locked_time)
            frame_duration = 1.0 / max(1, self.fps.get())
            self.root.after(int(frame_duration * 1000), self.clear_lock)
        else:
            seconds = self.get_current_seconds()
            self.update_display_digits(seconds)
        self.root.after(16, self.update_loop)

    def clear_lock(self):
        self.locked_time = None

if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("1000x620")
    app = TimecodeSlate(root)
    root.mainloop()
