#!/usr/bin/env python3
"""
EAS Test GUI — speak the message first, then play the beeps.
- Blue background, big yellow message
- TTS (replace "broadcast" if desired) is spoken fully before tones start
- In-memory WAV generation and synchronous playback per repeat
- No pip required
"""

import sys
import io
import wave
import struct
import math
import tempfile
import time
import shutil
import subprocess
import platform
import threading
import tkinter as tk
from tkinter import font

IS_WINDOWS = platform.system() == "Windows"
PLAYER_CANDIDATES_STDIN = ["ffplay", "aplay", "play", "mplayer"]
PLAYER_CANDIDATES_FALLBACK = ["afplay"]
SAMPLE_RATE = 22050
SAMPLE_WIDTH = 2
MAX_AMPLITUDE = 32767

# -------------------------
# TTS utilities (no pip)
# -------------------------
def find_tts_engine():
    if IS_WINDOWS:
        return "powershell"
    if shutil.which("say"):
        return "say"
    if shutil.which("spd-say"):
        return "spd-say"
    if shutil.which("espeak"):
        return "espeak"
    if shutil.which("festival"):
        return "festival"
    return None

def tts_speak(text, verbose=False):
    """Blocking TTS call. Returns True if attempted."""
    engine = find_tts_engine()
    if engine is None:
        if verbose:
            print("[diag] No TTS engine found; printing phrase instead.")
            print(text)
        return False
    try:
        if IS_WINDOWS and engine == "powershell":
            safe = text.replace("'", "''")
            cmd = [
                "powershell",
                "-NoProfile",
                "-Command",
                "Add-Type -AssemblyName System.Speech; "
                "(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{}')".format(safe)
            ]
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            return True
        elif engine == "say":
            subprocess.run(["say", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            return True
        elif engine == "spd-say":
            subprocess.run(["spd-say", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            return True
        elif engine == "espeak":
            subprocess.run(["espeak", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            return True
        elif engine == "festival":
            p = subprocess.Popen(["festival", "--tts"], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            p.communicate(input=text.encode("utf-8"))
            return True
    except Exception as e:
        if verbose:
            print("[diag] TTS failed:", e)
    return False

# -------------------------
# Audio generation & playback (in-memory)
# -------------------------
def make_pcm_samples(sequence, sample_rate=SAMPLE_RATE, volume=0.85):
    """sequence: list of (freq, duration) tuples. freq <= 0 => silence."""
    samples = []
    amp = int(MAX_AMPLITUDE * max(0.0, min(1.0, volume)))
    for freq, duration in sequence:
        n = int(sample_rate * max(0.0, duration))
        if n <= 0:
            continue
        if freq <= 0:
            samples.extend([0] * n)
            continue
        for i in range(n):
            t = i / sample_rate
            val = amp * math.sin(2.0 * math.pi * freq * t)
            samples.append(int(max(-MAX_AMPLITUDE, min(MAX_AMPLITUDE, val))))
    if not samples:
        return b""
    return struct.pack("<{}h".format(len(samples)), *samples)

def make_wav_bytes_from_pcm(pcm_bytes, sample_rate=SAMPLE_RATE, sampwidth=SAMPLE_WIDTH, nchannels=1):
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(nchannels)
        wf.setsampwidth(sampwidth)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm_bytes)
    return buf.getvalue()

def build_sequence_with_pauses(pattern, repeats=1, pause_between_items=0.12, pause_between_repeats=0.6):
    seq = []
    for r in range(max(1, int(repeats))):
        for i, (freq, dur) in enumerate(pattern):
            seq.append((freq, dur))
            if not (r == repeats - 1 and i == len(pattern) - 1):
                seq.append((0, pause_between_items))
        if r < repeats - 1:
            seq.append((0, pause_between_repeats))
    return seq

def find_stdin_player():
    for p in PLAYER_CANDIDATES_STDIN:
        if shutil.which(p):
            return p
    for p in PLAYER_CANDIDATES_FALLBACK:
        if shutil.which(p):
            return p
    return None

def play_wav_bytes_unix(player, wav_bytes, verbose=False):
    if player is None:
        if verbose:
            print("[diag] No player found; terminal bell fallback")
        sys.stdout.write("\a"); sys.stdout.flush()
        return False
    try:
        if player == "ffplay":
            cmd = [player, "-nodisp", "-autoexit", "-loglevel", "quiet", "-"]
            proc = subprocess.run(cmd, input=wav_bytes, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return proc.returncode == 0
        elif player == "aplay":
            cmd = [player, "-q", "-"]
            proc = subprocess.run(cmd, input=wav_bytes, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return proc.returncode == 0
        elif player == "play":
            cmd = [player, "-q", "-t", "wav", "-"]
            proc = subprocess.run(cmd, input=wav_bytes, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return proc.returncode == 0
        elif player == "mplayer":
            cmd = [player, "-really-quiet", "-"]
            proc = subprocess.run(cmd, input=wav_bytes, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return proc.returncode == 0
        elif player == "afplay":
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
            try:
                tmp.write(wav_bytes); tmp.flush(); tmp.close()
                proc = subprocess.run([player, tmp.name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return proc.returncode == 0
            finally:
                try: os.unlink(tmp.name)
                except Exception: pass
        else:
            cmd = [player, "-"]
            proc = subprocess.run(cmd, input=wav_bytes, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return proc.returncode == 0
    except Exception as e:
        if verbose:
            print("[diag] Playback error:", e)
        return False

def play_wav_bytes_windows(wav_bytes, verbose=False):
    try:
        import winsound
        winsound.PlaySound(wav_bytes, winsound.SND_MEMORY | winsound.SND_SYNC)
        return True
    except Exception as e:
        if verbose:
            print("[diag] winsound playback failed:", e)
        return False

# -------------------------
# Default pattern (same frequency)
# -------------------------
def default_same_freq_pattern(freq=853):
    return [(freq, 8.0), (freq, 0.25), (freq, 0.25), (freq, 0.25)]

# -------------------------
# GUI and control
# -------------------------
class EASGui:
    def __init__(self, root):
        self.root = root
        self.root.title("EAS Test")
        self.stop_event = threading.Event()
        self.player = None if IS_WINDOWS else find_stdin_player()
        self._build_ui()

    def _build_ui(self):
        self.root.configure(bg="#0033AA")
        pad = 12

        ctrl = tk.Frame(self.root, bg="#0033AA")
        ctrl.pack(side="top", fill="x", padx=pad, pady=(pad, 6))

        tk.Label(ctrl, text="Replace 'broadcast' with:", bg="#0033AA", fg="white").grid(row=0, column=0, sticky="w")
        self.replace_var = tk.StringVar()
        tk.Entry(ctrl, textvariable=self.replace_var, width=20).grid(row=0, column=1, padx=6)

        tk.Label(ctrl, text="Frequency Hz:", bg="#0033AA", fg="white").grid(row=0, column=2, sticky="w", padx=(10,0))
        self.freq_var = tk.StringVar(value="853")
        tk.Entry(ctrl, textvariable=self.freq_var, width=8).grid(row=0, column=3, padx=6)

        tk.Label(ctrl, text="Repeats:", bg="#0033AA", fg="white").grid(row=0, column=4, sticky="w", padx=(10,0))
        self.repeats_var = tk.StringVar(value="2")
        tk.Entry(ctrl, textvariable=self.repeats_var, width=6).grid(row=0, column=5, padx=6)

        tk.Label(ctrl, text="Pause item(s):", bg="#0033AA", fg="white").grid(row=1, column=0, sticky="w", pady=(6,0))
        self.pbi_var = tk.StringVar(value="0.12")
        tk.Entry(ctrl, textvariable=self.pbi_var, width=8).grid(row=1, column=1, padx=6, pady=(6,0))

        tk.Label(ctrl, text="Pause repeat(s):", bg="#0033AA", fg="white").grid(row=1, column=2, sticky="w", padx=(10,0), pady=(6,0))
        self.pbr_var = tk.StringVar(value="0.6")
        tk.Entry(ctrl, textvariable=self.pbr_var, width=8).grid(row=1, column=3, padx=6, pady=(6,0))

        btn_frame = tk.Frame(self.root, bg="#0033AA")
        btn_frame.pack(side="top", fill="x", padx=pad, pady=(6,6))
        start_btn = tk.Button(btn_frame, text="Start Test", command=self.start_test, bg="#0055FF", fg="white")
        start_btn.pack(side="left", padx=(0,8))
        stop_btn = tk.Button(btn_frame, text="Stop", command=self.stop_test, bg="#FF3333", fg="white")
        stop_btn.pack(side="left", padx=(0,8))
        diag_btn = tk.Button(btn_frame, text="Diagnostic", command=self.run_diagnostic)
        diag_btn.pack(side="left", padx=(0,8))

        self.message_frame = tk.Frame(self.root, bg="#0033AA")
        self.message_frame.pack(expand=True, fill="both", padx=pad, pady=(6,pad))
        self.message_label = tk.Label(self.message_frame, text="", bg="#0033AA", fg="#FFD700", wraplength=800, justify="center")
        big_font = font.Font(family="Helvetica", size=36, weight="bold")
        self.message_label.configure(font=big_font)
        self.message_label.pack(expand=True)

        footer = tk.Label(self.root, text="EAS Test - Press Start to run (TTS then tones)", bg="#0033AA", fg="white")
        footer.pack(side="bottom", pady=(0,8))

    def start_test(self):
        if hasattr(self, "worker") and getattr(self, "worker", None) and self.worker.is_alive():
            return
        self.stop_event.clear()
        repl = self.replace_var.get().strip()
        base = "This is a test of the emergency broadcast system"
        phrase = base.replace("broadcast", repl) if repl else base
        self.message_label.config(text=phrase.upper())
        try:
            freq = int(self.freq_var.get().strip() or "853")
        except Exception:
            freq = 853
        try:
            repeats = int(self.repeats_var.get().strip() or "1")
        except Exception:
            repeats = 1
        try:
            pbi = float(self.pbi_var.get().strip() or "0.12")
        except Exception:
            pbi = 0.12
        try:
            pbr = float(self.pbr_var.get().strip() or "0.6")
        except Exception:
            pbr = 0.6

        pattern = default_same_freq_pattern(freq=freq)
        # Worker thread: speak (blocking), then play repeats (blocking per repeat), GUI stays responsive
        self.worker = threading.Thread(target=self._tts_then_play_worker,
                                       args=(phrase, pattern, repeats, pbi, pbr),
                                       daemon=True)
        self.worker.start()

    def _tts_then_play_worker(self, phrase, pattern, repeats, pbi, pbr):
        # Speak first (blocking call). This ensures the spoken message finishes before tones start.
        tts_speak(phrase, verbose=True)
        # After TTS completes, play the pattern repeats (each repeat is built and played synchronously)
        for i in range(max(1, int(repeats))):
            if self.stop_event.is_set():
                break
            seq = build_sequence_with_pauses(pattern, repeats=1, pause_between_items=pbi, pause_between_repeats=0.0)
            pcm = make_pcm_samples(seq, sample_rate=SAMPLE_RATE, volume=0.85)
            wav = make_wav_bytes_from_pcm(pcm, sample_rate=SAMPLE_RATE)
            if IS_WINDOWS:
                play_wav_bytes_windows(wav, verbose=True)
            else:
                play_wav_bytes_unix(self.player, wav, verbose=True)
            # pause between repeats (allow stop)
            slept = 0.0
            while slept < pbr:
                if self.stop_event.is_set():
                    break
                time.sleep(0.05)
                slept += 0.05
        # Clear message when done
        self.message_label.config(text="")

    def stop_test(self):
        self.stop_event.set()
        if IS_WINDOWS:
            try:
                import winsound
                winsound.PlaySound(None, winsound.SND_PURGE)
            except Exception:
                pass
        self.message_label.config(text="")

    def run_diagnostic(self):
        tts_engine = find_tts_engine()
        player = None if IS_WINDOWS else find_stdin_player()
        info = f"TTS engine: {tts_engine}\nAudio player: {player}\nRunning short test..."
        self.message_label.config(text=info, fg="#FFFF99")
        tts_speak("This is a short diagnostic test.", verbose=True)
        seq = build_sequence_with_pauses([(1000, 0.5)], repeats=1, pause_between_items=0.0, pause_between_repeats=0.0)
        pcm = make_pcm_samples(seq, sample_rate=SAMPLE_RATE, volume=0.85)
        wav = make_wav_bytes_from_pcm(pcm, sample_rate=SAMPLE_RATE)
        if IS_WINDOWS:
            play_wav_bytes_windows(wav, verbose=True)
        else:
            play_wav_bytes_unix(player, wav, verbose=True)
        self.root.after(1500, lambda: self.message_label.config(text=""))

# -------------------------
# Helper functions used by GUI
# -------------------------
def default_same_freq_pattern(freq=853):
    return [(freq, 8.0), (freq, 0.25), (freq, 0.25), (freq, 0.25)]

def find_stdin_player():
    for p in PLAYER_CANDIDATES_STDIN:
        if shutil.which(p):
            return p
    for p in PLAYER_CANDIDATES_FALLBACK:
        if shutil.which(p):
            return p
    return None

# Reuse playback helpers defined above
def play_wav_bytes_windows(wav_bytes, verbose=False):
    try:
        import winsound
        if verbose:
            print("[diag] winsound PlaySound (blocking in thread)")
        winsound.PlaySound(wav_bytes, winsound.SND_MEMORY | winsound.SND_SYNC)
        return True
    except Exception as e:
        if verbose:
            print("[diag] winsound failed:", e)
        return False

def play_wav_bytes_unix(player, wav_bytes, verbose=False):
    return play_wav_bytes_unix_impl(player, wav_bytes, verbose)

def play_wav_bytes_unix_impl(player, wav_bytes, verbose=False):
    if player is None:
        if verbose:
            print("[diag] No player; terminal bell fallback")
        sys.stdout.write("\a"); sys.stdout.flush()
        return False
    try:
        if player == "ffplay":
            cmd = [player, "-nodisp", "-autoexit", "-loglevel", "quiet", "-"]
            proc = subprocess.run(cmd, input=wav_bytes, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return proc.returncode == 0
        elif player == "aplay":
            cmd = [player, "-q", "-"]
            proc = subprocess.run(cmd, input=wav_bytes, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return proc.returncode == 0
        elif player == "play":
            cmd = [player, "-q", "-t", "wav", "-"]
            proc = subprocess.run(cmd, input=wav_bytes, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return proc.returncode == 0
        elif player == "mplayer":
            cmd = [player, "-really-quiet", "-"]
            proc = subprocess.run(cmd, input=wav_bytes, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return proc.returncode == 0
        elif player == "afplay":
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
            try:
                tmp.write(wav_bytes); tmp.flush(); tmp.close()
                proc = subprocess.run([player, tmp.name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return proc.returncode == 0
            finally:
                try: os.unlink(tmp.name)
                except Exception: pass
        else:
            cmd = [player, "-"]
            proc = subprocess.run(cmd, input=wav_bytes, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return proc.returncode == 0
    except Exception as e:
        if verbose:
            print("[diag] Playback error:", e)
        return False

# -------------------------
# Run the GUI
# -------------------------
def main():
    root = tk.Tk()
    root.geometry("900x400")
    app = EASGui(root)
    root.mainloop()

if __name__ == "__main__":
    main()
