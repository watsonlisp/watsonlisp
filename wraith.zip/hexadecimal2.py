#!/usr/bin/env python3
import sys
import argparse
import re

print ("enter hexadecimal or text")

HEX_RE = re.compile(r'^(?:0x)?[0-9a-fA-F\s]+$')

def looks_like_hex(s: str) -> bool:
    cleaned = s.replace(' ', '').lower()
    if cleaned.startswith('0x'):
        cleaned = cleaned[2:]
    return bool(cleaned) and all(c in '0123456789abcdef' for c in cleaned) and len(cleaned) % 2 == 0

def text_to_hex(s: str) -> str:
    return s.encode('utf-8').hex()

def hex_to_text(h: str) -> str:
    cleaned = h.replace(' ', '').lower()
    if cleaned.startswith('0x'):
        cleaned = cleaned[2:]
    if len(cleaned) % 2 != 0:
        raise ValueError("Hex string must have an even number of digits.")
    return bytes.fromhex(cleaned).decode('utf-8')

def translate_auto(s: str) -> str:
    if looks_like_hex(s):
        return hex_to_text(s)
    else:
        return text_to_hex(s)

def main():
    parser = argparse.ArgumentParser(description="Translate text to hex and hex to text. Auto-detects input.")
    parser.add_argument('input', nargs='*', help="Text or hex to translate. If omitted, runs interactive mode.")
    parser.add_argument('--mode', choices=['auto','t2h','h2t'], default='auto', help="Force mode: auto, t2h, or h2t.")
    args = parser.parse_args()

    def process(s):
        try:
            if args.mode == 't2h':
                out = text_to_hex(s)
            elif args.mode == 'h2t':
                out = hex_to_text(s)
            else:
                out = translate_auto(s)
            print(out)
        except Exception as e:
            print("Error:", e, file=sys.stderr)

    if args.input:
        payload = " ".join(args.input)
        process(payload)
    else:
        try:
            while True:
                line = input("> ").strip()
                if not line:
                    continue
                if line.lower() in ('quit','exit'):
                    break
                process(line)
        except (EOFError, KeyboardInterrupt):
            print()

if __name__ == "__main__":
    main()
