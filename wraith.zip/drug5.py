#!/usr/bin/env python3
import random
import argparse
import platform
import subprocess
import shutil
import sys

PREFIXES = ["al","an","ar","bi","ce","cy","di","el","en","ex","fa","gi","ha","im","in","ka","le","mi","no","ol","pa","qu","ra","se","ta","ul","va","xi","ya","zo"]
MIDDLES  = ["ver","nex","taz","mox","lix","pru","syl","dri","fem","glen","horm","kine","luma","mida","nora","paxa","riva","sora","tiva","zema"]
SUFFIXES = ["mab","nib","vir","azole","pril","olol","statin","cillin","prazole","zepam","oxetine","tide","gliptin","setron","dronate"]

TEMPLATES = [
    lambda: random.choice(PREFIXES) + random.choice(MIDDLES) + random.choice(SUFFIXES),
    lambda: random.choice(PREFIXES) + random.choice(SUFFIXES),
    lambda: random.choice(PREFIXES) + random.choice(MIDDLES) + random.choice(MIDDLES) + random.choice(SUFFIXES),
    lambda: random.choice(PREFIXES) + random.choice(PREFIXES) + random.choice(MIDDLES) + random.choice(SUFFIXES),
]

def make_name():
    return random.choice(TEMPLATES)().capitalize()

def has_command(cmd):
    return shutil.which(cmd) is not None

def speak_text(text):
    system = platform.system()
    # macOS
    if system == "Darwin":
        if has_command("say"):
            subprocess.run(["say", text], check=False)
            return True
        return False
    # Linux / BSD
    if system in ("Linux", "FreeBSD"):
        if has_command("spd-say"):
            subprocess.run(["spd-say", text], check=False)
            return True
        if has_command("espeak"):
            subprocess.run(["espeak", text], check=False)
            return True
        return False
    # Windows
    if system == "Windows":
        # Use PowerShell's System.Speech.Synthesis
        # Escape single quotes by doubling them
        ps_text = text.replace("'", "''")
        ps_command = (
            "Add-Type -AssemblyName System.Speech; "
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            f"$s.Speak('{ps_text}');"
        )
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_command], check=False)
            return True
        except FileNotFoundError:
            return False
    return False

def interactive_one_by_one(seed=None, tts_enabled=False):
    if seed is not None:
        random.seed(seed)
    index = 0
    tts = bool(tts_enabled)
    try:
        while True:
            index += 1
            name = make_name()
            print(f"\n{name}  —  #{index}\n" + "-"*len(name))
            print(f"Text to Speech is {'ON' if tts else 'OFF'}")
            if tts:
                ok = speak_text(name)
                if not ok:
                    print("(TTS not available on this system; toggle will remain OFF until available.)")
                    tts = False
            cmd = input("Press Enter for next, type 't' to toggle TTS, or 'q' to quit: ").strip().lower()
            if cmd in ("q", "quit"):
                print("Goodbye.")
                break
            if cmd == "t":
                tts = not tts
                print(f"TTS toggled {'ON' if tts else 'OFF'}.")
                # If toggled on, attempt a short confirmation speak
                if tts:
                    if not speak_text(f"{name}"):
                        print("(Failed to start TTS; it has been turned OFF.)")
                        tts = False
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="One-at-a-time pharmaceutical-style name generator with runtime TTS toggle")
    parser.add_argument("-s", "--seed", type=int, default=None, help="Optional random seed for reproducible sequence")
    parser.add_argument("--tts", action="store_true", help="Start with TTS enabled if available")
    args = parser.parse_args()
    interactive_one_by_one(seed=args.seed, tts_enabled=args.tts)
