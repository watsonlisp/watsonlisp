#!/usr/bin/env python3
import random
import socket
import re
import time
import sys
import subprocess
import shutil

# ---------------------------
# TTS helpers (no pip needed)
# ---------------------------
def speak_text(text):
    """Speak a short text string using system TTS. Returns True if spoken."""
    text = str(text).strip()
    if not text:
        return False
    platform = sys.platform

    # macOS
    if platform == "darwin":
        if shutil.which("say"):
            try:
                subprocess.run(["say", text], check=False)
                return True
            except Exception:
                return False
        return False

    # Windows: PowerShell System.Speech, pass text via stdin
    if platform.startswith("win"):
        try:
            ps_script = (
                "Add-Type -AssemblyName System.Speech;"
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                "$s.Speak([Console]::In.ReadToEnd());"
            )
            proc = subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_script],
                input=text.encode("utf-8"),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
            return proc.returncode == 0
        except Exception:
            return False

    # Linux / other Unix
    if platform.startswith("linux") or platform.startswith("freebsd"):
        if shutil.which("espeak"):
            try:
                subprocess.run(["espeak", text], check=False)
                return True
            except Exception:
                pass
        if shutil.which("spd-say"):
            try:
                subprocess.run(["spd-say", text], check=False)
                return True
            except Exception:
                pass
        if shutil.which("flite"):
            try:
                subprocess.run(["flite", "-t", text], check=False)
                return True
            except Exception:
                pass
        return False

    return False

def speak_domains(domains, pause=0.18):
    """Speak each domain in the list one by one with a short pause."""
    if not domains:
        return False
    spoken_any = False
    for d in domains:
        to_say = d.replace(".", " dot ")
        ok = speak_text(to_say)
        if not ok:
            return spoken_any
        spoken_any = True
        time.sleep(pause)
    return spoken_any

# ---------------------------------------
# Expanded prefixes and suffixes (applied)
# ---------------------------------------
PREFIXES = [
    "get","try","my","the","go","best","top","shop","i","we","pro","ultra","super","mini",
    "mega","hyper","smart","easy","fast","quick","now","one","first","true","real","pure",
    "neo","alpha","beta","prime","core","live","open","cloud","home","local","global","eco",
    "green","bright","bold","fresh","new","next","wise","safe","secure","sync","link","join",
    "plus","max","micro","nano","meta","byte","bit","data","code","dev","build","maker",
    "craft","forge","studio","lab","labs","works","engine","logic","pulse","spark","flare",
    "shift","drift","loop","stack","grid","node","hub","nest","base","dock","port","route",
    "path","trail","field","zone","area","space","sphere","vista","peak","ridge","bridge",
    "lane","way","track","beat","wave","flow","flux","rise","boost","vault","box","crate",
    "kit","pack","bundle","market","mart","store","cart","shoppe","bazaar","corner","alley",
    "avenue","street","collective","union","guild","crew","tribe","clan","team","group",
    "club","circle","forum","talk","chat","buzz","news","daily","weekly","insight","guide",
    "coach","mentor","tutor","academy","school","camp","campus","clinic","care","health",
    "fit","well","zen","calm","mood","vibe","taste","flavor","bite","dish","plate","kitchen",
    "garden","farm","barn","dairy","meadow","pasture","roam","wander","nomad","pilot","captain",
    "chief","boss","central","atelier","works"
]

SUFFIXES = [
    "hub","site","app","online","world","zone","hq","co","net","io","dev","tech","labs","shop",
    "store","market","mart","space","cloud","media","press","news","daily","now","pro","plus",
    "one","studio","works","factory","forge","craft","design","designs","solutions","systems",
    "services","group","team","collective","network","link","connect","portal","center","centre",
    "base","core","box","crate","kit","pack","bundle","zone","land","isle","isles","island","bay",
    "harbor","harbour","dock","port","lane","way","path","trail","track","road","street","avenue",
    "alley","corner","house","home","nest","den","loft","attic","vault","bank","safe","boutique",
    "emporium","bazaar","marketplace","mall","plaza","square","circle","forum","talk","chat",
    "buzz","pulse","beat","wave","flow","flux","rise","boost","spark","sparkle","flare","glow",
    "shine","beam","light","bright","clear","pure","fresh","green","eco","earth","planet","orbit",
    "stellar","lunar","solar","astro","galaxy","byte","bit","data","stack","stacker","code",
    "coder","dev","engine","engineer","maker","makers","build","builder","builders","crafted",
    "techs","ology","logy","logic","mind","brain","intel","smart","wise","guru","guide","coach",
    "mentor","school","academy","camp","clinic","care","health","fit","well","vibe","mood","taste",
    "flavor","kitchen","dining","food","dish","bites","eats","grub","table","garden","farm","barn",
    "dairy","pet","paws","tails","wings","roam","nomad","wander","voyage","journey","trip","tour",
    "adventures","adventure","quest","finder","seek","seekr","scout","spot","tracker","watch",
    "watcher","guard","shield","armor","secure","sentry","pilot","captain","chief","boss","leader",
    "master","pro","expert","ninja","wizard","mage","hero","champ"
]

# Optional dedupe to ensure uniqueness
PREFIXES = list(dict.fromkeys(PREFIXES))
SUFFIXES = list(dict.fromkeys(SUFFIXES))

# ---------------------------------------
# Domain generation and checking logic
# ---------------------------------------
NUMBERS = ["", "1", "2", "3", "4", "5", "24", "360", "101", "202", "365"]
DEFAULT_TLDS = ["com", "net", "io", "co"]

def phonetic_variants(word):
    variants = set()
    if word.endswith("y"):
        variants.add(word[:-1] + "ie")
    if word.endswith("e"):
        variants.add(word[:-1])
    variants.add(word + "s")
    variants.add(word + "ly")
    variants.add(word + "er")
    variants.add(word + "o")
    return list(variants)

def clean_candidate(s):
    s = s.lower()
    s = re.sub(r"[^a-z0-9\-]", "", s)
    s = re.sub(r"\-+", "-", s).strip("-")
    return s

def generate_candidates(seed, max_candidates=5000):
    seed = seed.lower().strip()
    candidates = set()

    # prefix + seed + suffix combos
    for p in PREFIXES:
        for s in SUFFIXES:
            candidates.add(clean_candidate(f"{p}{seed}{s}"))
            candidates.add(clean_candidate(f"{p}-{seed}-{s}"))
    # seed + suffix and prefix + seed
    for s in SUFFIXES:
        candidates.add(clean_candidate(f"{seed}{s}"))
        candidates.add(clean_candidate(f"{seed}-{s}"))
    for p in PREFIXES:
        candidates.add(clean_candidate(f"{p}{seed}"))
        candidates.add(clean_candidate(f"{p}-{seed}"))
    # numbers
    for n in NUMBERS:
        candidates.add(clean_candidate(f"{seed}{n}"))
        candidates.add(clean_candidate(f"{seed}-{n}"))
    # phonetic variants
    for v in phonetic_variants(seed):
        candidates.add(clean_candidate(v))
        for s in SUFFIXES[:40]:
            candidates.add(clean_candidate(f"{v}{s}"))
    # extras and blends
    extras = ["tech", "shop", "labs", "works", "media", "space", "cloud", "zone", "hub", "net"]
    for e in extras:
        candidates.add(clean_candidate(f"{seed}{e}"))
        candidates.add(clean_candidate(f"{e}{seed}"))
    # reversed blends
    rev = seed[::-1]
    candidates.add(clean_candidate(seed + rev[:3]))
    candidates.add(clean_candidate(seed[:3] + rev))
    # random permutations to reach target
    pool = list(candidates)
    while len(pool) < max_candidates:
        a = random.choice(["", random.choice(PREFIXES)])
        b = random.choice(["", random.choice(SUFFIXES)])
        n = random.choice(NUMBERS)
        cand = clean_candidate(f"{a}{seed}{b}{n}")
        pool.append(cand)
        candidates.add(cand)
        if len(candidates) >= max_candidates:
            break

    final = [c for c in candidates if 3 <= len(c) <= 63]
    return list(final)[:max_candidates]

def domain_resolves(domain):
    try:
        socket.gethostbyname(domain)
        return True
    except Exception:
        return False

def find_domains(seed, tlds=None, limit=500):
    if tlds is None:
        tlds = DEFAULT_TLDS
    candidates = generate_candidates(seed, max_candidates=5000)
    random.shuffle(candidates)
    results = {"available": [], "taken": []}
    checked = 0
    for base in candidates:
        if checked >= limit:
            break
        for tld in tlds:
            domain = f"{base}.{tld}"
            if domain_resolves(domain):
                results["taken"].append(domain)
            else:
                results["available"].append(domain)
            checked += 1
            if checked >= limit:
                break
        time.sleep(0.002)
    return results

def pretty_print_results(results, show=500):
    print("\nLikely available domains (DNS did not resolve):")
    for d in results["available"][:show]:
        print("  ", d)
    print("\nLikely taken domains (DNS resolved):")
    for d in results["taken"][:show]:
        print("  ", d)

# ---------------------------
# Main interactive loop
# ---------------------------
def main():
    last_seed = None
    tts_enabled = True
    try:
        while True:
            seed = input("Enter a seed word for domain generation (or 'q' to quit): ").strip()
            if seed.lower() == 'q':
                print("Goodbye.")
                break
            if seed == "" and last_seed:
                seed = last_seed
                print(f"Reusing last seed '{seed}'.")
            elif seed == "":
                print("No seed provided. Please enter a word or 'q' to quit.")
                continue
            last_seed = seed

            tlds_input = input("Enter comma separated TLDs or press Enter for default (com,net,io,co): ").strip()
            tlds = [t.strip() for t in tlds_input.split(",")] if tlds_input else DEFAULT_TLDS

            try:
                limit_input = input("How many domains to check (default 200)? Press Enter for default: ").strip()
                limit = int(limit_input) if limit_input else 200
            except ValueError:
                print("Invalid number, using default 200.")
                limit = 200

            tts_choice = input(f"TTS is currently {'ON' if tts_enabled else 'OFF'}. Type 't' to toggle, Enter to keep: ").strip().lower()
            if tts_choice == 't':
                tts_enabled = not tts_enabled
                print(f"TTS turned {'ON' if tts_enabled else 'OFF'}.")

            print("Generating candidates and checking DNS. This may take a moment...")
            out = find_domains(seed, tlds=tlds, limit=limit)
            pretty_print_results(out, show=limit)

            # Speak all generated domains if TTS enabled
            if tts_enabled:
                all_domains = out["available"] + out["taken"]
                if all_domains:
                    print("\nSpeaking all generated domains now...")
                    spoken = speak_domains(all_domains, pause=0.18)
                    if not spoken:
                        print("TTS not available or failed. Domains were printed above.")
                else:
                    speak_text(f"No domains generated for {seed}.")

            action = input("\nPress Enter to generate again with the same seed, type 'n' for a new seed, or 'q' to quit: ").strip().lower()
            if action == 'q':
                print("Goodbye.")
                break
            if action == 'n':
                continue
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting.")

if __name__ == "__main__":
    main()
