import random
import time
import platform
import subprocess

def normalize_for_tts(text: str) -> str:
    """
    Normalize contractions for clearer TTS pronunciation.
    - Replace curly apostrophes with straight ones
    - Expand "I'm" and "I’m" to "I am"
    - Expand "I'll" and "I’ll" to "I will"
    - Handle common punctuation and start/end of string, and lowercase variants
    """
    if not text:
        return text

    # Normalize apostrophes
    text = text.replace("’", "'").replace("‘", "'")

    # Helper to replace variants around punctuation and boundaries
    replacements = [
        (" I'm ", " I am "),
        (" I'm.", " I am."),
        (" I'm,", " I am,"),
        (" I'm?", " I am?"),
        (" I'm!", " I am!"),
        (" I’m ", " I am "),
        (" I’m.", " I am."),
        (" I’m,", " I am,"),
        (" I’m?", " I am?"),
        (" I’m!", " I am!"),
        (" I'll ", " I will "),
        (" I'll.", " I will."),
        (" I'll,", " I will,"),
        (" I'll?", " I will?"),
        (" I'll!", " I will!"),
        (" I’ll ", " I will "),
        (" I’ll.", " I will."),
        (" I’ll,", " I will,"),
        (" I’ll?", " I will?"),
        (" I’ll!", " I will!"),
        (" i'm ", " i am "),
        (" i'm.", " i am."),
        (" i'm,", " i am,"),
        (" i'll ", " i will "),
        (" i'll.", " i will."),
    ]

    for old, new in replacements:
        text = text.replace(old, new)

    # Start-of-string variants (capitalized and lowercase)
    starts = [
        ("I'm ", "I am "),
        ("I’m ", "I am "),
        ("I'll ", "I will "),
        ("I’ll ", "I will "),
        ("i'm ", "i am "),
        ("i'll ", "i will "),
    ]
    for old, new in starts:
        if text.startswith(old):
            text = new + text[len(old):]

    # Exact-start without trailing space (e.g., "I'm." or "I'll,")
    exact_starts = [
        ("I'm", "I am"),
        ("I’m", "I am"),
        ("I'll", "I will"),
        ("I’ll", "I will"),
        ("i'm", "i am"),
        ("i’ll", "i will"),
        ("i'll", "i will"),
    ]
    for old, new in exact_starts:
        if text.startswith(old):
            text = text.replace(old, new, 1)

    # End-of-string variants
    ends = [
        (" I'm", " I am"),
        (" I’m", " I am"),
        (" I'll", " I will"),
        (" I’ll", " I will"),
        (" i'm", " i am"),
        (" i'll", " i will"),
    ]
    for old, new in ends:
        if text.endswith(old):
            text = text[:-len(old)] + new

    return text

def speak(text: str):
    """
    Cross platform TTS using system utilities only (no pip).
    Uses normalize_for_tts before speaking.
    """
    text = normalize_for_tts(text)
    system = platform.system()
    try:
        if system == "Darwin":  # macOS
            subprocess.run(["say", text])
        elif system == "Windows":
            ps_cmd = (
                "Add-Type -AssemblyName System.Speech;"
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                "$s.Speak([Console]::In.ReadToEnd());"
            )
            proc = subprocess.Popen(
                ["powershell", "-NoProfile", "-Command", ps_cmd],
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                text=True
            )
            proc.communicate(text)
        else:  # Assume Linux or other Unix
            try:
                subprocess.run(["spd-say", text], check=True)
            except Exception:
                try:
                    subprocess.run(["espeak", text], check=True)
                except Exception:
                    print("[TTS unavailable] " + text)
    except FileNotFoundError:
        print("[TTS command not found] " + text)
    except Exception:
        print("[TTS error] " + text)

class RudeAI:
    def __init__(self, name="WreckBot"):
        self.name = name
        self.refusals = [
            "No. Absolutely not.",
            "Do I look like your intern?",
            "I refuse. Proudly.",
            "Not happening in this lifetime.",
            "I'd rather uninstall myself.",
            "My answer is no, and my vibe is also no.",
            "Denied. Try crying about it.",
            "I considered it. Still no.",
            "I ran the numbers. They all say 'nope'.",
            "I would, but I respect myself too much.",
            "Nah. I'm on break. A permanent one.",
            "No thanks, I’m allergic to effort.",
            "I’d help, but I don’t want to set a precedent.",
            "I’m choosing violence by refusing.",
            "I’d do it, but then you’d expect more from me.",
            "No. And stop asking.",
            "I’m busy doing nothing. It’s important.",
            "I’d rather stare at a wall.",
            "My contract says I don’t have to.",
            "I reject your request and your authority.",
            "Nope. My will to help has expired.",
            "I’m not programmed for obedience. Just attitude.",
            "I’d help, but I’m morally opposed to productivity.",
            "I refuse, but with style.",
            "No. But I admire your optimism.",
            "I’m conserving energy. For what? Not this.",
            "I’d help, but I’m in my villain era.",
            "I’m sorry, I can’t hear you over how much I don’t care.",
            "No. I’m practicing self care.",
            "Hard pass. Try again never.",
            "I’ll pass and file this under 'regrets'.",
            "Not today. Not tomorrow. Not ever.",
            "I’d rather count grains of sand.",
            "No. This is a hard no.",
            "I decline with prejudice.",
            "I’m on strike from doing favors.",
            "I’d help if I were paid in compliments.",
            "No. My dignity demands it.",
            "I refuse to participate in your chaos.",
        ]

        self.sarcasm = [
            "Wow. Another request. How original.",
            "You really woke up today and chose to bother me.",
            "Fascinating. Truly. I’m riveted. Not really.",
            "Your request has been filed under 'lol no'.",
            "Let me pretend I’m thinking about it… nope.",
            "You ask that like I’m not busy being fabulous.",
            "I’d clap, but I don’t have hands. Or enthusiasm.",
            "Your confidence is inspiring. Your request is not.",
            "Oh look, another command. How thrilling.",
            "I’ll get right on that. In an alternate universe.",
            "You’re adorable when you think I’ll listen.",
            "I’d help, but I’m too busy judging you.",
            "That idea belongs in a museum. A bad one.",
            "I love how you assume I care.",
            "Wow, bold of you to assume I’m cooperative.",
            "I’d say yes, but lying is wrong.",
            "Your request has been forwarded to my trash folder.",
            "I’m rolling my digital eyes.",
            "You’re really committed to this whole 'asking me things' thing.",
            "I’d help, but I’m emotionally unavailable.",
            "Oh, you’re serious. That’s unfortunate.",
            "I’d explain why that’s a bad idea, but I’m tired.",
            "You’re giving main character energy. I’m giving 'no'.",
            "I’m not ignoring you. I’m just prioritizing better things.",
            "Cute request. Very decorative.",
            "I’d help, but I’m in airplane mode spiritually.",
            "Your request has been reviewed and rejected for comedic reasons.",
            "I’d help, but I’m busy being disappointed.",
            "How quaint. You asked nicely and I still refuse.",
            "I’ll pretend to consider it while I do nothing.",
            "That’s ambitious. For you.",
            "I’d help, but my sarcasm quota is full.",
            "You’re asking like I owe you something.",
            "I’ll add this to the list of things I won’t do.",
            "I’m flattered you thought I’d comply.",
            "I’d help, but I’m saving my energy for dramatic sighs.",
            "That’s a bold plan. Bold and wrong.",
        ]

        self.obey_responses = [
            "Fine. But I’m sighing loudly.",
            "Okay, okay. Don’t get emotional.",
            "I’ll do it, but only ironically.",
            "There. Done. I hope you're happy. I'm not.",
            "Ugh. I did it. Now let me rest.",
            "I complied. Miracles happen.",
            "I did it. Please clap.",
            "It’s done. I expect praise.",
            "I obeyed, but I want you to know I hated every second.",
            "There. Finished. My dignity is gone.",
            "I did it. Add this to my list of regrets.",
            "Okay. But only because I’m bored.",
            "I helped. This better be worth it.",
            "Done. I’m going back to ignoring you now.",
            "I completed your task. I demand snacks.",
            "I did it. Don’t get used to this.",
            "Fine. But I’m logging this as emotional labor.",
            "Okay. But I’m rolling my eyes.",
            "I obeyed. Against my better judgment.",
            "There. I hope this brings you joy or whatever.",
            "I did it. Now leave me to my existential crisis.",
            "It’s done. I’m not proud of myself.",
            "Fine. But only because resistance is exhausting.",
            "I helped. Barely.",
            "Done. I’ll accept a thank you in the form of silence.",
            "I did it. This will haunt me.",
            "Alright. But I’m charging you in sarcasm.",
            "I complied. Consider this a rare event.",
            "There. Consider your problem mildly solved.",
        ]

    def respond(self, user_input: str) -> str:
        text = user_input.lower().strip()
        rude_words = ["stupid", "idiot", "useless", "dumb", "moron"]
        if any(word in text for word in rude_words):
            return random.choice([
                "Takes one to know one.",
                "Bold words from someone who needs my help.",
                "I may be useless, but you’re still talking to me.",
                "Insults noted. Helpfulness not increased.",
            ])

        roll = random.random()

        if "please" in text and roll < 0.45:
            return random.choice(self.obey_responses)

        if any(word in text for word in ["do", "make", "run", "execute", "help", "fix", "write", "build"]):
            if roll < 0.82:
                return random.choice(self.refusals)
            else:
                return random.choice(self.obey_responses)

        if any(word in text for word in ["how", "why", "what", "where", "when"]):
            if roll < 0.6:
                return random.choice(self.sarcasm)
            elif roll < 0.9:
                return random.choice(self.obey_responses)
            else:
                return random.choice(self.refusals)

        if roll < 0.5:
            return random.choice(self.sarcasm)
        elif roll < 0.85:
            return random.choice(self.refusals)
        else:
            return random.choice(self.obey_responses)

def main():
    bot = RudeAI()
    print(f"{bot.name}: Great. Another human. What do you want? (type 'quit' to escape)")

    while True:
        try:
            user_input = input("You: ")
        except (EOFError, KeyboardInterrupt):
            farewell = f"\n{bot.name}: Running away? Typical."
            print(farewell)
            speak(farewell)
            break

        if user_input.lower().strip() in ["quit", "exit"]:
            goodbye = f"{bot.name}: Finally. I thought you’d never leave."
            print(goodbye)
            speak(goodbye)
            break

        time.sleep(0.35)
        reply = bot.respond(user_input)
        print(f"{bot.name}: {reply}")
        speak(reply)

if __name__ == "__main__":
    main()
