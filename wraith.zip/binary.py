#!/usr/bin/env python3
"""
Binary Text Converter
- Encode text -> binary
- Decode binary -> text
Usage:
  Run the script and follow prompts, or call functions from other code.
"""

from typing import List
import sys
import re

def text_to_binary(text: str, bits: int = 8, encoding: str = "utf-8") -> str:
    if bits not in (8, 16):
        raise ValueError("bits must be 8 or 16")
    b = text.encode(encoding)
    if bits == 8:
        return " ".join(f"{byte:08b}" for byte in b)
    else:
        # For 16-bit grouping, combine pairs of bytes (pad if needed)
        if len(b) % 2:
            b += b"\x00"
        pairs = [b[i] << 8 | b[i+1] for i in range(0, len(b), 2)]
        return " ".join(f"{pair:016b}" for pair in pairs)

def _clean_binary_input(bin_str: str) -> str:
    # Remove any characters other than 0 and 1
    return "".join(ch for ch in bin_str if ch in "01")

def binary_to_text(bin_input: str, bits: int = 8, encoding: str = "utf-8") -> str:
    # Accept space-separated groups or continuous stream
    groups = bin_input.strip().split()
    if len(groups) == 0:
        return ""
    # If groups look like valid bytes/words, use them; otherwise treat as continuous stream
    if all(re.fullmatch(r"[01]+", g) for g in groups) and all(len(g) in (bits,) for g in groups):
        bitstream = "".join(groups)
    else:
        bitstream = _clean_binary_input(bin_input)
    # Pad to a multiple of 8 bits
    if len(bitstream) % 8 != 0:
        pad = 8 - (len(bitstream) % 8)
        bitstream += "0" * pad
    # Convert every 8 bits to a byte
    bytes_out = bytearray(int(bitstream[i:i+8], 2) for i in range(0, len(bitstream), 8))
    try:
        return bytes_out.decode(encoding, errors="strict")
    except UnicodeDecodeError:
        # If strict decode fails, fall back to replace errors
        return bytes_out.decode(encoding, errors="replace")

def looks_like_binary(s: str) -> bool:
    s = s.strip()
    # Heuristic: mostly 0/1 and spaces, and at least one 0 or 1
    filtered = "".join(ch for ch in s if ch in "01 ")
    return len(filtered) >= max(1, len(s) * 0.6)

def interactive(bits_default: int = 8):
    print("Binary Text Converter")
    print("Type text to convert to binary, or paste binary to convert to text.")
    print("Commands: :bits 8 or :bits 16 to change grouping, :quit to exit")
    bits = bits_default
    while True:
        try:
            inp = input("\nEnter input  > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye")
            break
        if not inp:
            continue
        if inp.lower() in (":quit", ":exit"):
            print("Exiting")
            break
        if inp.startswith(":bits"):
            parts = inp.split()
            if len(parts) >= 2 and parts[1] in ("8", "16"):
                bits = int(parts[1])
                print(f"Bit grouping set to {bits}")
            else:
                print("Usage: :bits 8  or  :bits 16")
            continue
        if looks_like_binary(inp):
            try:
                out = binary_to_text(inp, bits=bits)
                print(f"Decoded text  > {out}")
            except Exception as e:
                print("Error decoding binary:", e)
        else:
            try:
                out = text_to_binary(inp, bits=bits)
                print(f"Encoded binary > {out}")
            except Exception as e:
                print("Error encoding text:", e)

if __name__ == "__main__":
    # If arguments are provided, do a one-shot conversion
    if len(sys.argv) > 1:
        raw = " ".join(sys.argv[1:])
        if looks_like_binary(raw):
            print(binary_to_text(raw))
        else:
            print(text_to_binary(raw))
    else:
        interactive()
