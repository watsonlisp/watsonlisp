# cereal_one_by_one_tts_updated.py
import random
import sys
import subprocess
import shutil

ADJECTIVES = [
    "Crunchy", "Frosted", "Golden", "Sugarcoated", "Velvet", "Crispy",
    "Toasted", "Honeyed", "Zesty", "Cocoa", "Buttery", "Nutty",
    "Wholesome", "Fluffy", "Silky", "Sparkling", "Glazed", "Sticky",
    "Tangy", "Smoky", "Caramelized", "Spiced", "Frosty", "Luscious",
    "Chewy", "Airy", "Puffy", "Rustic", "Vintage", "Radiant",
    "Mystic", "Galactic", "Solar", "Lunar", "Electric", "Neon",
    "Retro", "Classic", "Bold", "Gentle", "Sunny", "Breezy",
    "Midnight", "Velvetine", "Orchard", "Meadow", "Alpine", "Coastal",
    "Tropical", "Frostline", "Ember", "Aurora", "Whisper", "Dazzling",
    "Petite", "Mighty", "Jumbo", "Miniature", "Supreme", "Pure",
    "Earthy", "Herbal", "Blooming", "Festive"
]

CORES = [
    "Loops", "Flakes", "Puffs", "Bites", "Clusters", "Rings",
    "Squares", "Nuggets", "Twists", "Drops", "Crisps", "Shards",
    "Pellets", "Pebbles", "Stars", "Hearts", "Corns", "Grains",
    "Oats", "Bran", "Crisplets", "Chunks", "Rounds", "Wheels",
    "Spirals", "Strands", "Threads", "Bits", "Morsels", "Crumbles",
    "Cubes", "Poppers", "Minis", "Bombs", "Pockets", "Loaves",
    "Pyramids", "LoopsPlus", "O's", "Wheats"
]

FLAVORS = [
    "Choco", "Cocoa", "Berry", "Strawberry", "Blueberry", "Raspberry",
    "Banana", "Apple", "Maple", "Cinnamon", "Vanilla", "Caramel",
    "Honey", "Almond", "Peanut", "Hazelnut", "Coconut", "Pumpkin",
    "Ginger", "Molasses", "Toffee", "Marshmallow", "Citrus", "Lemon",
    "Orange", "Lime", "Mint", "Matcha", "Espresso", "Mocha",
    "Butterscotch", "Salted", "SeaSalt", "Yogurt", "BerryBurst",
    "Cherry", "Grape", "Pomegranate", "Fig", "Date", "Nutmeg",
    "Cardamom", "Saffron", "BerryCream", "Creamy", "Cheesecake",
    "BerrySwirl", "Tropical", "Pineapple", "Mango", "Papaya", "BerryZing"
]

TEXTURES = [
    "Crunch", "Crunchies", "Whirl", "Swirl", "Burst", "Pop",
    "Snap", "Crackle", "Munch", "Fluff", "Melt", "Crisp",
    "Chew", "Silken", "Dust", "Sprinkle", "Glaze", "Shimmer",
    "Crunchlet", "CrunchPop", "Fizz", "Sizzle", "Velvet", "Crinkle",
    "Ripple", "Rattle", "Tumble", "Whip", "Fold", "Layer",
    "Puff", "Bloom", "Bloomlet", "CrunchBurst", "Cloud", "Ribbon",
    "Ribboned", "Pebble", "CrunchWave", "Frost", "Glint"
]

SUFFIXES = [
    "Delights", "Surprise", "Magic", "Dreams", "Heaven", "Fusion",
    "Fiesta", "Galaxy", "Treasure", "Crunchies", "Bunch", "Bliss",
    "Joy", "Party", "Mix", "Medley", "CrunchMix", "Supreme",
    "Classic", "Minis", "CrunchFest", "Burst", "Blast", "Pop",
    "CrunchLand", "Kingdom", "Orchard", "Harvest", "Morning",
    "Sunrise", "Twilight", "Midnight", "Adventure", "Voyage",
    "Expedition", "Carnival", "Parade", "Secret", "Vault", "Wonder"
]

def make_name():
    pattern = random.choice([0, 1, 2, 3, 4])
    if pattern == 0:
        return f"{random.choice(ADJECTIVES)} {random.choice(FLAVORS)} {random.choice(CORES)}"
    if pattern == 1:
        return f"{random.choice(FLAVORS)} {random.choice(CORES)} {random.choice(SUFFIXES)}".strip()
    if pattern == 2:
        return f"{random.choice(ADJECTIVES)} {random.choice(CORES)} {random.choice(TEXTURES)}"
    if pattern == 3:
        return f"{random.choice(FLAVORS)} {random.choice(TEXTURES)}"
    if random.random() < 0.5:
        return f"{random.choice(ADJECTIVES)} {random.choice(CORES)}"
    return f"{random.choice(FLAVORS)}-{random.choice(TEXTURES)}"

def speak(text):
    """Cross-platform TTS using system commands only."""
    try:
        if sys.platform == "darwin":
            subprocess.run(["say", text], check=False)
            return True
        if sys.platform.startswith("win"):
            safe = text.replace("'", "''")
            ps_cmd = f"Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe}')"
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return True
        if shutil.which("espeak"):
            subprocess.run(["espeak", text], check=False)
            return True
        if shutil.which("spd-say"):
            subprocess.run(["spd-say", text], check=False)
            return True
        return False
    except Exception:
        return False

def interactive_one_by_one():
    print("Single Name Cereal Generator with TTS")
    print("Enter to generate, r to regenerate, t to toggle TTS, q to quit.")
    last = None
    tts_enabled = True

    while True:
        user = input(">>> ").strip().lower()
        if user == 'q':
            print("Goodbye.")
            break
        if user == 't':
            tts_enabled = not tts_enabled
            print("TTS is now", "ON" if tts_enabled else "OFF")
            continue
        if user == 'r' and last is not None:
            last = make_name()
            print(f"> {last}")
            if tts_enabled:
                ok = speak(last)
                if not ok:
                    print("TTS not available. Install espeak or spd-say on Linux, or enable macOS say or Windows PowerShell.")
            continue
        last = make_name()
        print(f"> {last}")
        if tts_enabled:
            ok = speak(last)
            if not ok:
                print("TTS not available. Type 't' to disable TTS or install a system TTS tool.")

if __name__ == "__main__":
    interactive_one_by_one()
