#!/usr/bin/env python3
"""
self_deprecate.py
Produce many responses (multiple quotes per batch, many batches) with interactive
repeat/quit controls, background quit-keyword, graceful interrupt handling, and
system TTS (on by default). After each batch, you can type:
  - r    : repeat immediately
  - q    : quit
  - <N>  : set the number of quotes for the next batch to N and continue
  - Enter: continue normal behavior (honors --delay, --batches, etc.)
No external Python packages required.
"""

from __future__ import annotations

import argparse
import random
import sys
import time
import signal
import subprocess
from datetime import datetime
from threading import Thread, Event
from typing import List, Optional

DEFAULT_QUOTES: List[str] = [
    "I have a PhD in overthinking and a minor in awkward exits.",
    "I'm proof that evolution sometimes takes a coffee break.",
    "I put the 'meh' in memorable.",
    "My life is a series of 'I meant to do that' moments.",
    "I have the social grace of a dropped casserole.",
    "I run on optimism and questionable decisions.",
    "My confidence arrives fashionably late and slightly confused.",
    "I am a limited edition of 'works sometimes'.",
    "I make plans like a spreadsheet with missing formulas.",
    "I have a talent for turning small tasks into epic sagas.",
    "My brain is a browser with 200 tabs and one frozen video.",
    "I am the human version of a participation trophy.",
    "I excel at being perfectly average in very specific ways.",
    "My to-do list is more of a suggestion box.",
    "I bring a unique blend of chaos and mild regret.",
    "I am an unpaid intern in the company of my own life.",
    "I have mastered the art of apologizing to inanimate objects.",
    "My life motto: 'We'll see how this goes.'",
    "I am a walking 'before' photo.",
    "I have the attention span of a distracted squirrel.",
    "I am the plot twist nobody asked for.",
    "I am a limited-time offer on self-improvement.",
    "I am the human equivalent of a buffering icon.",
    "I am a cautionary tale in three acts.",
    "I have a black belt in making things awkward.",
    "I am a collector of unfinished hobbies.",
    "I am the reason 'winging it' has a reputation.",
    "I am an expert at turning clarity into confusion.",
    "I am a master of accidental minimalism.",
    "I am a walking 'should have read the instructions' sign.",
    "I am proof that 'good enough' can be a lifestyle.",
    "I am a professional at misplacing my motivation.",
    "I am a limited-run model of 'almost competent'.",
    "I am the human version of a typo in a love letter.",
    "I am a one-person committee for questionable choices.",
    "I am a living demonstration of 'trial and error'.",
    "I am a specialist in awkward timing.",
    "I am a connoisseur of small, avoidable mistakes.",
    "I am a proud member of the 'I'll do it tomorrow' club.",
    "I am a walking footnote to better plans.",
    "I am a low-budget superhero with no origin story.",
    "I am a masterclass in humble mediocrity.",
    "I am the reason instructions come with pictures.",
    "I am a human sticky note: forgetful but persistent.",
    "I am a subtle reminder that perfection is exhausting.",
    "I am a living, breathing 'plot twist: me'.",
    "I am a temporary glitch in the system of life.",
    "I am a charmingly flawed prototype.",
    "I am a friendly warning label in human form.",
    "I am a walking 'did I do that?' moment.",
    "I am a limited edition of 'works in progress'.",
    "I am the result of optimistic planning and weak follow-through.",
    "I am a proud ambassador of the 'oops' economy.",
    "I am a human sticky note: important, then forgotten.",
    "I am a master of turning simple tasks into dramatic sagas.",
    "I am a living example of 'close enough for jazz'.",
    "I am a collector of almost-success stories.",
    "I am a walking 'I tried' badge with extra crumbs.",
    "I am a low-effort legend in my own lunchtime.",
    "I am a professional at making small things complicated.",
    "I am a charming disaster with a good heart.",
    "I am a walking 'note to self' that never gets read.",
    "I am a human reminder that plans are optional.",
    "I am a connoisseur of awkward silences and stale coffee.",
    "I am a limited-time offer on questionable judgment.",
    "I am a proud owner of a half-finished to-do list.",
    "I am a living tutorial on how not to multitask.",
    "I am a walking 'did I lock the door?' thought experiment.",
    "I am a humble servant to the altar of procrastination.",
    "I am a master of the art of plausible deniability.",
    "I am a walking 'I meant well' note.",
    "I am a human version of 'loading… please wait'.",
    "I am a collector of awkward memories and good intentions.",
    "I am a small miracle wrapped in mild chaos.",
    "I am a friendly reminder that everyone is improvising.",
    "I am a walking 'this seemed like a good idea at the time'.",
    "I am a proud graduate of the School of Last-Minute Decisions.",
    "I am a living example of 'it sounded better in my head'.",
    "I am a master of turning clarity into charming confusion.",
    "I am a walking 'oops, did I say that out loud?'",
    "I am a low-key legend in the field of almosts.",
    "I am a human sticky note: hopeful, then ignored.",
    "I am a connoisseur of tiny, avoidable catastrophes.",
    "I am a walking 'note to self: buy more sticky notes'.",
    "I am a humble specialist in accidental comedy.",
    "I am a living reminder that progress is messy.",
    "I am a proud member of the 'I tried my best' club.",
    "I am a walking 'I will fix it later' promise.",
    "I am a charmingly imperfect work in progress.",
    "I am a human footnote to better intentions.",
    "I am a small, persistent glitch with a smile.",
    "I am a living example of 'well, that happened'.",
    "I am a collector of 'almost' and 'not quite' moments.",
    "I am a walking 'I thought I had it under control' story."
]


def pick_quotes(quotes: List[str], count: int = 1) -> List[str]:
    if count <= 0:
        return []
    if count == 1:
        return [random.choice(quotes)]
    return random.sample(quotes, count) if count <= len(quotes) else random.choices(quotes, k=count)


def print_batch_with_ts(batch: List[str]) -> None:
    ts = datetime.now().isoformat(timespec="seconds")
    for q in batch:
        print(f"[{ts}] {q}", flush=True)


# ---------------------------
# TTS helpers (no external deps)
# ---------------------------
def _speak_system(text: str, rate: int = 0, voice: Optional[str] = None) -> None:
    """
    Try to speak `text` using system TTS tools without requiring pip packages.
    Blocks until the system TTS command completes.
    """
    if not text:
        return

    plat = sys.platform
    try:
        if plat == "darwin":
            cmd = ["say"]
            if voice:
                cmd += ["-v", voice]
            if rate:
                cmd += ["-r", str(rate)]
            cmd.append(text)
            subprocess.run(cmd, check=False)
            return

        if plat.startswith("win"):
            safe = text.replace("'", "''")
            rate_stmt = f"$s.Rate = {int(rate)};" if rate else ""
            ps_cmd = (
                "Add-Type -AssemblyName System.Speech;"
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                f"{rate_stmt}"
                f"$s.Speak('{safe}');"
            )
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return

        # Linux/Unix: try espeak then spd-say
        try:
            cmd = ["espeak"]
            if rate:
                cmd += ["-s", str(max(80, min(450, 175 + rate)))]
            cmd += [text]
            subprocess.run(cmd, check=False)
            return
        except FileNotFoundError:
            pass

        try:
            cmd = ["spd-say", text]
            subprocess.run(cmd, check=False)
            return
        except FileNotFoundError:
            pass

    except Exception:
        pass

    print("(TTS unavailable on this system or required command not found)", flush=True)


def speak_sync(text: str, rate: int = 0, voice: Optional[str] = None) -> None:
    """Speak synchronously (one-by-one). Blocks until speech finishes."""
    _speak_system(text, rate, voice)


def speak_async(text: str, rate: int = 0, voice: Optional[str] = None) -> None:
    """Run TTS in a background thread (may overlap)."""
    t = Thread(target=_speak_system, args=(text, rate, voice), daemon=True)
    t.start()


# ---------------------------
# CLI, prompt, and main loop
# ---------------------------
def stdin_watcher(stop_event: Event, quit_keyword: str) -> None:
    """Background watcher that sets stop_event when quit_keyword is typed (line-based)."""
    if not sys.stdin or sys.stdin.closed:
        return
    try:
        for raw in sys.stdin:
            if stop_event.is_set():
                break
            if raw.strip() == quit_keyword:
                stop_event.set()
                break
    except Exception:
        return


def install_signal_handlers(stop_event: Event) -> None:
    def handler(signum, frame):
        stop_event.set()
    try:
        signal.signal(signal.SIGINT, handler)
        signal.signal(signal.SIGTERM, handler)
    except Exception:
        pass


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Produce many quotes with repeat/quit controls and system TTS (on by default)."
    )
    p.add_argument("--count", "-c", type=int, default=5, help="Default quotes per batch (default 5)")
    p.add_argument("--batches", "-b", type=int, default=10, help="Number of batches to produce (default 10). Use 0 with --loop to run indefinitely")
    p.add_argument("--loop", "-l", action="store_true", help="Loop indefinitely until quit (overrides --batches unless batches>0)")
    p.add_argument("--delay", "-d", type=float, default=1.0, help="Delay seconds between batches (default 1.0)")
    p.add_argument("--quit-after", type=float, default=0.0, help="Auto stop after this many seconds (0 = disabled)")
    p.add_argument("--quit-on", type=str, default="", help="Typing this keyword on stdin will stop the run")
    p.add_argument("--prompt-mode", choices=("both", "repeat-only", "quit-only", "none"), default="both", help="Interactive prompt actions offered after each batch")
    p.add_argument("--no-prompt", action="store_true", help="Alias for --prompt-mode=none")
    p.add_argument("--seed", type=int, help="Random seed for reproducible output")
    # TTS options (no external packages)
    p.add_argument("--tts", dest="tts", action="store_true", help="Enable text-to-speech for each printed quote (uses system TTS tools)")
    p.add_argument("--no-tts", dest="tts", action="store_false", help="Disable text-to-speech")
    p.set_defaults(tts=True)  # TTS on by default
    p.add_argument("--tts-batch", action="store_true", help="Speak the entire batch as a single utterance instead of speaking each quote separately")
    p.add_argument("--async-tts", action="store_true", help="When speaking per-quote, run TTS in background threads (may overlap). By default TTS speaks one-by-one synchronously.")
    p.add_argument("--tts-rate", type=int, default=0, help="TTS rate adjustment (platform-dependent; positive/negative integer)")
    p.add_argument("--tts-voice", type=str, default="", help="Preferred voice name (platform-dependent; macOS 'say' supports -v)")
    args = p.parse_args(argv)
    if args.no_prompt:
        args.prompt_mode = "none"
    if args.count < 0 or args.batches < 0 or args.delay < 0 or args.quit_after < 0:
        p.error("Numeric arguments must be non-negative")
    return args


def interactive_prompt(prompt_mode: str, remaining: Optional[int]) -> Optional[str]:
    """
    Accepts:
      - 'r' to repeat immediately
      - 'q' to quit
      - a positive integer (e.g., '8') to set the next batch count
      - Enter to continue normal behavior
    Returns the raw response string or None if input not available.
    """
    if not sys.stdin or sys.stdin.closed or not sys.stdin.isatty():
        return None
    try:
        hint = f" [{remaining} batches left]" if remaining is not None else ""
        if prompt_mode == "both":
            resp = input(f"(r)epeat / (q)uit / <N> set count / (Enter to continue){hint}: ").strip().lower()
        elif prompt_mode == "repeat-only":
            resp = input(f"(r)epeat / <N> set count / (Enter to continue){hint}: ").strip().lower()
            if resp == "q":
                resp = ""
        elif prompt_mode == "quit-only":
            resp = input(f"(q)uit / <N> set count / (Enter to continue){hint}: ").strip().lower()
            if resp == "r":
                resp = ""
        else:
            return None
        return resp
    except EOFError:
        return None
    except KeyboardInterrupt:
        return "q"


def parse_count_input(resp: str, current_count: int) -> Optional[int]:
    """Return new count if resp is a valid positive integer, otherwise None."""
    if not resp:
        return None
    # allow plain digits or "set 10"
    if resp.isdigit():
        n = int(resp)
        return n if n >= 0 else None
    parts = resp.split()
    if len(parts) == 2 and parts[0] in ("set", "count") and parts[1].isdigit():
        n = int(parts[1])
        return n if n >= 0 else None
    return None


def main(argv: Optional[List[str]] = None) -> None:
    args = parse_args(argv)
    if args.seed is not None:
        random.seed(args.seed)

    quotes = list(DEFAULT_QUOTES)
    stop_event = Event()
    install_signal_handlers(stop_event)

    watcher: Optional[Thread] = None
    if args.quit_on:
        watcher = Thread(target=stdin_watcher, args=(stop_event, args.quit_on), daemon=True)
        watcher.start()
        if sys.stdout and sys.stdout.isatty():
            print(f"(Type '{args.quit_on}' + Enter to stop)", flush=True)

    start_time = time.time()
    produced_batches = 0
    target_batches: Optional[int] = None
    if args.loop:
        target_batches = None
    else:
        target_batches = args.batches if args.batches > 0 else 1

    current_count = max(0, args.count)

    try:
        # Single immediate batch if user requested 0 batches and not loop
        if not args.loop and args.batches == 0:
            batch = pick_quotes(quotes, current_count)
            print_batch_with_ts(batch)
            if args.tts:
                if args.tts_batch:
                    speak_sync("  ".join(batch), args.tts_rate, args.tts_voice or None)
                else:
                    for q in batch:
                        if args.async_tts:
                            speak_async(q, args.tts_rate, args.tts_voice or None)
                        else:
                            speak_sync(q, args.tts_rate, args.tts_voice or None)
            return

        while not stop_event.is_set():
            # stop if we've produced the requested number of batches
            if target_batches is not None and produced_batches >= target_batches:
                break

            # Select and print batch using current_count
            batch = pick_quotes(quotes, current_count)
            print_batch_with_ts(batch)

            # TTS: speak each quote one-by-one by default (synchronous unless --async-tts)
            if args.tts:
                if args.tts_batch:
                    if args.async_tts:
                        speak_async("  ".join(batch), args.tts_rate, args.tts_voice or None)
                    else:
                        speak_sync("  ".join(batch), args.tts_rate, args.tts_voice or None)
                else:
                    for q in batch:
                        if args.async_tts:
                            speak_async(q, args.tts_rate, args.tts_voice or None)
                        else:
                            speak_sync(q, args.tts_rate, args.tts_voice or None)

            produced_batches += 1

            # compute remaining for prompt hint
            remaining = None if target_batches is None else max(0, target_batches - produced_batches)

            # interactive prompt (if enabled)
            if args.prompt_mode != "none" and sys.stdin.isatty():
                resp = interactive_prompt(args.prompt_mode, remaining)
                if resp is None:
                    # no interactive input available; fall through
                    pass
                else:
                    resp = resp.strip().lower()
                    if resp == "q":
                        print("Quitting by user request.", flush=True)
                        break
                    if resp == "r":
                        # repeat immediately (do not sleep)
                        continue
                    # check if user entered a count
                    new_count = parse_count_input(resp, current_count)
                    if new_count is not None:
                        current_count = new_count
                        # if user set count to 0, next batch will print nothing (allowed)
                        continue
                    # otherwise treat as Enter/continue

            # check auto quit-after
            if args.quit_after and (time.time() - start_time) >= args.quit_after:
                print("Auto quit-after timeout reached.", flush=True)
                break

            # if we've reached target after printing, break
            if target_batches is not None and produced_batches >= target_batches:
                break

            # delay between batches, but wake early if stop_event set
            slept = 0.0
            while slept < args.delay and not stop_event.is_set():
                to_sleep = min(0.2, args.delay - slept)
                time.sleep(to_sleep)
                slept += to_sleep

    except KeyboardInterrupt:
        print("\nInterrupted by user. Exiting.", flush=True)
    finally:
        stop_event.set()
        if watcher and watcher.is_alive():
            watcher.join(timeout=1.0)


if __name__ == "__main__":
    main()
