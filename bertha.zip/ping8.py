#!/usr/bin/env python3
"""
Repeat ping loop with simple TTS using only system tools (no pip).
When a ping completes the script will attempt to parse round-trip stats
and speak them using system TTS.

Commands:
  - speak <text>                                : speak the provided text
  - speak approximate round trip times in milli-seconds
                                                : speak "Approximate round trip times in milliseconds" followed by parsed values
  - approximate                                  : speak "Approximate"
  - quit or q                                    : exit
Press Enter with no input to re-ping the last host.
"""

import platform
import shutil
import socket
import subprocess
import sys
import time
import re

def is_resolvable(host: str) -> bool:
    try:
        socket.gethostbyname(host)
        return True
    except Exception:
        return False

def get_ping_command(host: str, count: int = 4, timeout: int = 5):
    ping_cmd = shutil.which("ping")
    if not ping_cmd:
        return None
    system = platform.system().lower()
    if system == "windows":
        return [ping_cmd, "-n", str(count), "-w", str(timeout * 1000), host]
    else:
        return [ping_cmd, "-c", str(count), "-W", str(timeout), host]

def run_ping(host: str, count: int = 4, timeout: int = 5) -> (int, str):
    args = get_ping_command(host, count, timeout)
    if not args:
        return 2, "Ping command not found on this system."
    try:
        completed = subprocess.run(args, capture_output=True, text=True, timeout=(count * (timeout + 2)))
        output = (completed.stdout or "") + (completed.stderr or "")
        return completed.returncode, output
    except subprocess.TimeoutExpired:
        return 3, "Ping timed out."
    except Exception as e:
        return 4, f"Error running ping: {e}"

def tts_say(text: str):
    text = str(text)
    system = platform.system().lower()

    # macOS: say
    if system == "darwin":
        say = shutil.which("say")
        if say:
            try:
                subprocess.run([say, text])
                return
            except Exception:
                pass

    # Windows: PowerShell SAPI
    if system == "windows":
        pwsh = shutil.which("powershell") or shutil.which("pwsh")
        if pwsh:
            ps_cmd = (
                "Add-Type -AssemblyName System.Speech;"
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                "$s.Speak([Console]::In.ReadToEnd());"
            )
            try:
                subprocess.run([pwsh, "-NoProfile", "-Command", ps_cmd], input=text, text=True)
                return
            except Exception:
                pass

    # Linux: spd-say or espeak
    if system == "linux":
        spd = shutil.which("spd-say")
        if spd:
            try:
                subprocess.run([spd, text])
                return
            except Exception:
                pass
        espeak = shutil.which("espeak")
        if espeak:
            try:
                subprocess.run([espeak, text])
                return
            except Exception:
                pass

    # Fallback: print the text
    print("[TTS unavailable] " + text)

def parse_round_trip_stats(ping_output: str):
    """
    Parse common ping output formats and return a dict with keys:
      - min_ms, avg_ms, max_ms, mdev_ms (mdev or stddev if available)
    Returns None if parsing fails.
    Handles:
      - Linux/macOS: "rtt min/avg/max/mdev = 0.042/0.042/0.042/0.000 ms"
      - macOS variant: "round-trip min/avg/max/stddev = 0.042/0.042/0.042/0.000 ms"
      - Windows: "Minimum = 0ms, Maximum = 0ms, Average = 0ms"
    """
    out = ping_output or ""
    # Try Linux/macOS style: numbers separated by '/'
    m = re.search(r"(?:rtt|round-trip)[^=]*=\s*([0-9.]+)/([0-9.]+)/([0-9.]+)(?:/([0-9.]+))?\s*ms", out, re.IGNORECASE)
    if m:
        min_ms = m.group(1)
        avg_ms = m.group(2)
        max_ms = m.group(3)
        mdev_ms = m.group(4) if m.group(4) else None
        return {
            "min_ms": min_ms,
            "avg_ms": avg_ms,
            "max_ms": max_ms,
            "mdev_ms": mdev_ms
        }

    # Try Windows style: Minimum = 0ms, Maximum = 0ms, Average = 0ms
    m_win = re.search(r"Minimum\s*=\s*([0-9]+)ms.*Maximum\s*=\s*([0-9]+)ms.*Average\s*=\s*([0-9]+)ms", out, re.IGNORECASE | re.DOTALL)
    if m_win:
        min_ms = m_win.group(1)
        max_ms = m_win.group(2)
        avg_ms = m_win.group(3)
        return {
            "min_ms": min_ms,
            "avg_ms": avg_ms,
            "max_ms": max_ms,
            "mdev_ms": None
        }

    # Try another Windows ordering (Average first)
    m_win2 = re.search(r"Average\s*=\s*([0-9]+)ms.*Minimum\s*=\s*([0-9]+)ms.*Maximum\s*=\s*([0-9]+)ms", out, re.IGNORECASE | re.DOTALL)
    if m_win2:
        avg_ms = m_win2.group(1)
        min_ms = m_win2.group(2)
        max_ms = m_win2.group(3)
        return {
            "min_ms": min_ms,
            "avg_ms": avg_ms,
            "max_ms": max_ms,
            "mdev_ms": None
        }

    # If nothing matched, return None
    return None

def speak_round_trip_stats_from_output(output: str):
    stats = parse_round_trip_stats(output)
    if not stats:
        tts_say("Could not parse round trip times from ping output.")
        return

    # Build a clear spoken phrase
    parts = []
    # Prefer to speak average first as "approximate"
    if stats.get("avg_ms"):
        parts.append(f"average {stats['avg_ms']} milliseconds")
    if stats.get("min_ms"):
        parts.append(f"minimum {stats['min_ms']} milliseconds")
    if stats.get("max_ms"):
        parts.append(f"maximum {stats['max_ms']} milliseconds")
    if stats.get("mdev_ms"):
        parts.append(f"mdev {stats['mdev_ms']} milliseconds")

    phrase = "Approximate round trip times in milliseconds: " + ", ".join(parts)
    tts_say(phrase)

def handle_speak_command(arg_text: str):
    """
    Special handling for several spoken phrases:
      - If user asks 'speak approximate round trip times in milli-seconds'
        we will speak that phrase literally (kept for compatibility).
      - If user types 'speak stats' we will speak the last parsed ping stats (if available).
      - Otherwise speak the provided text as-is.
    """
    if not arg_text:
        print("Nothing to speak. Use: speak <text>")
        return

    normalized = arg_text.strip().lower()

    # explicit phrase variant
    if re.fullmatch(r"approximate\s+round\s+trip\s+times\s+in\s+milli-?seconds?", normalized):
        tts_say("Approximate round trip times in milliseconds")
        return

    # "speak stats" will attempt to speak the most recent ping stats stored globally
    if normalized == "stats":
        if MAIN_STATE.get("last_ping_output"):
            speak_round_trip_stats_from_output(MAIN_STATE["last_ping_output"])
        else:
            tts_say("No ping statistics available yet.")
        return

    # Generic speak: speak the text as provided
    tts_say(arg_text)

# Simple global state to keep last ping output for "speak stats"
MAIN_STATE = {
    "last_ping_output": None
}

def main():
    print("Ping app — type a hostname or IP and press Enter.")
    print("Commands:")
    print("  speak <text>                                - speak the provided text")
    print("  speak stats                                 - speak last ping round-trip stats (if available)")
    print("  speak approximate round trip times in milli-seconds")
    print("                                              - speak the phrase 'Approximate round trip times in milliseconds'")
    print("  approximate                                  - speak 'Approximate'")
    print("  quit or q                                    - exit")
    print("Press Enter with no input to re-ping the last host.")
    last_host = None

    while True:
        try:
            user = input("Host (or command): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            break

        if not user:
            if not last_host:
                print("No previous host to re-ping. Enter a host first.")
                continue
            host = last_host
            print(f"Re-pinging last host: {host}")
        else:
            cmd = user.strip()
            low = cmd.lower()
            if low in ("quit", "q"):
                print("Goodbye.")
                tts_say("Goodbye.")
                break
            if low == "approximate":
                tts_say("Approximate")
                continue
            if low.startswith("speak"):
                # Accept "speak" or "speak <text>"
                parts = cmd.split(None, 1)
                arg_text = parts[1] if len(parts) > 1 else ""
                handle_speak_command(arg_text)
                continue
            host = user
            last_host = host

        if len(host) > 255:
            print("Host input too long. Try again.")
            tts_say("Host input too long.")
            continue

        if not is_resolvable(host):
            msg = f"Host '{host}' could not be resolved. Check the hostname or IP."
            print(msg)
            tts_say(msg)
            continue

        print(f"Pinging {host} ...")
        code, output = run_ping(host)
        # store output for later "speak stats" command
        MAIN_STATE["last_ping_output"] = output

        if code == 0:
            summary = f"{host} is reachable."
            print(summary)
            # speak summary
            tts_say(summary)
            # attempt to parse and speak round-trip stats automatically
            speak_round_trip_stats_from_output(output)
        elif code == 2:
            summary = "Ping command not found on this system."
            print(summary)
            tts_say(summary)
        elif code == 3:
            summary = "Ping timed out."
            print(summary)
            tts_say(summary)
        else:
            summary = f"{host} is not reachable (return code {code})."
            print(summary)
            tts_say(summary)

        print("--- ping output start ---")
        print(output.strip())
        print("--- ping output end ---\n")

        time.sleep(0.2)

if __name__ == "__main__":
    main()
