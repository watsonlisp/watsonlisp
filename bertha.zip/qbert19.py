#!/usr/bin/env python3
"""
qbert_tk_mark_colors.py
Q*bert-like Tkinter game. Each tile you land on is permanently marked with a color.
When all tiles are touched the game briefly shows "YOU WIN", then automatically advances
to the next level and continues play. Movement is diagonal-only (q/e/z/c or arrow keys).
Opponents are present in every level and persist across level transitions.
Run: python qbert_tk_mark_colors.py
"""

import tkinter as tk
import random
import time

# --- Configuration ---
ROWS_START = 7
TILE_SIZE = 56
TILE_GAP = 6
TOP_OFFSET = 60
PLAYER_RADIUS = 16
ENEMY_SIZE = 20
MOVE_SPEED = 14            # base player move speed (pixels per frame)
ENEMY_BASE_SPEED = 2.0     # base enemy speed
FPS = 60
LIVES = 30                 # start with 30 lives (changed per request)
POINTS_FIRST_VISIT = 10
MAX_ROWS = 10
MAX_ENEMIES = 6

# Delay (seconds) to pause enemy movement after the player loses a life / respawns
RESPAWN_ENEMY_PAUSE = 1.2

# Default unvisited color
UNVISITED_COLOR = "#2a6fb2"

def random_pastel():
    """Return a random pastel hex color."""
    r = int((random.random() * 0.5 + 0.5) * 255)
    g = int((random.random() * 0.5 + 0.5) * 255)
    b = int((random.random() * 0.5 + 0.5) * 255)
    return f"#{r:02x}{g:02x}{b:02x}"

class Tile:
    def __init__(self, r, c, x, y, size):
        self.r = r
        self.c = c
        self.x = x
        self.y = y
        self.size = size
        self.visits = 0
        self.color = UNVISITED_COLOR
        self.rect_id = None
        self.text_id = None

class Enemy:
    def __init__(self, path, canvas, speed):
        self.path = path[:]      # list of (r,c)
        self.index = 0
        self.canvas = canvas
        self.speed = speed
        self.pos = None
        # store multiple canvas ids (body, eye1, eye2, pupils, tail)
        self.id = None

    def spawn_visual(self, x, y, color="#c33"):
        """Create a rounded enemy body with simple eyes. Store ids as a tuple."""
        self.pos = [x, y]
        # delete previous items if present
        if self.id:
            try:
                if isinstance(self.id, (list, tuple)):
                    for iid in self.id:
                        self.canvas.delete(iid)
                else:
                    self.canvas.delete(self.id)
            except:
                pass

        # body (oval)
        body = self.canvas.create_oval(x-ENEMY_SIZE/2, y-ENEMY_SIZE/2,
                                       x+ENEMY_SIZE/2, y+ENEMY_SIZE/2,
                                       fill=color, outline="#000", width=2)
        # left eye
        ex_off = ENEMY_SIZE * 0.18
        ey_off = -ENEMY_SIZE * 0.12
        eye_l = self.canvas.create_oval(x - ex_off - 4, y + ey_off - 4, x - ex_off, y + ey_off,
                                        fill="#fff", outline="#000")
        # right eye
        eye_r = self.canvas.create_oval(x + ex_off, y + ey_off - 4, x + ex_off + 4, y + ey_off,
                                        fill="#fff", outline="#000")
        # pupils
        pupil_l = self.canvas.create_oval(x - ex_off - 2, y + ey_off - 2, x - ex_off, y + ey_off,
                                          fill="#000")
        pupil_r = self.canvas.create_oval(x + ex_off, y + ey_off - 2, x + ex_off + 2, y + ey_off,
                                          fill="#000")

        # optional small tail/mark to give character (a tiny rectangle)
        tail = self.canvas.create_rectangle(x + ENEMY_SIZE/2 - 4, y - 2, x + ENEMY_SIZE/2 + 2, y + 2,
                                            fill="#000", outline="")

        self.id = (body, eye_l, eye_r, pupil_l, pupil_r, tail)

    def redraw(self):
        """Update all parts of the enemy visual to the current pos."""
        if self.pos is None or not self.id:
            return
        x, y = self.pos
        try:
            body, eye_l, eye_r, pupil_l, pupil_r, tail = self.id
            self.canvas.coords(body, x-ENEMY_SIZE/2, y-ENEMY_SIZE/2, x+ENEMY_SIZE/2, y+ENEMY_SIZE/2)
            ex_off = ENEMY_SIZE * 0.18
            ey_off = -ENEMY_SIZE * 0.12
            self.canvas.coords(eye_l, x - ex_off - 4, y + ey_off - 4, x - ex_off, y + ey_off)
            self.canvas.coords(eye_r, x + ex_off, y + ey_off - 4, x + ex_off + 4, y + ey_off)
            self.canvas.coords(pupil_l, x - ex_off - 2, y + ey_off - 2, x - ex_off, y + ey_off)
            self.canvas.coords(pupil_r, x + ex_off, y + ey_off - 2, x + ex_off + 2, y + ey_off)
            self.canvas.coords(tail, x + ENEMY_SIZE/2 - 4, y - 2, x + ENEMY_SIZE/2 + 2, y + 2)
        except Exception:
            # if anything fails, recreate visual
            self.spawn_visual(x, y, color="#c33")

class Game:
    def __init__(self, root):
        self.root = root
        self.rows = ROWS_START
        self.canvas_w = (MAX_ROWS * TILE_SIZE) + (MAX_ROWS * TILE_GAP) + 160
        self.canvas_h = TOP_OFFSET + MAX_ROWS * (TILE_SIZE + TILE_GAP) + 160
        self.canvas = tk.Canvas(root, width=self.canvas_w, height=self.canvas_h, bg="#111")
        self.canvas.pack()
        self.running = True
        self._last_time = time.time()
        self._win_pending = False
        # time until which enemies are paused (no movement) after respawn
        self.enemy_pause_until = 0.0
        self._setup_state()
        self.root.bind("<Key>", self.on_key)
        self._schedule_loop()

    def _setup_state(self):
        self._build_pyramid(self.rows)
        self.player_r = 0
        self.player_c = 0
        self.player_x, self.player_y = self._tile_center(0, 0)
        self.player_target = (self.player_x, self.player_y)
        self.player_id = None
        self.score = 0
        self.lives = LIVES
        self.level = 1
        self.enemies = []
        self.game_over = False
        self.controls_text_id = None
        self._create_ui()
        # ensure opponents are present from level 1 onward
        self._spawn_initial_enemies(2)
        self._mark_tile_on_land()  # mark starting tile

    def _build_pyramid(self, rows):
        self.rows = rows
        self.tiles = []
        for r in range(rows):
            cols = r + 1
            total_width = cols * TILE_SIZE + (cols - 1) * TILE_GAP
            start_x = (self.canvas_w - total_width) // 2
            row = []
            for c in range(cols):
                x = start_x + c * (TILE_SIZE + TILE_GAP)
                y = TOP_OFFSET + r * (TILE_SIZE + TILE_GAP)
                row.append(Tile(r, c, x, y, TILE_SIZE))
            self.tiles.append(row)

    def _tile_center(self, r, c):
        t = self.tiles[r][c]
        return (t.x + t.size/2, t.y + t.size/2)

    def _create_ui(self):
        """
        Draw tiles and UI. Preserve and redraw existing enemies so opponents remain present across levels.
        """
        # Save enemy positions and ids, then clear canvas and redraw everything
        enemy_states = []
        for e in getattr(self, "enemies", []):
            # store path, index, pos, speed
            enemy_states.append({
                "path": e.path[:],
                "index": e.index,
                "pos": list(e.pos) if e.pos else None,
                "speed": e.speed
            })
            # delete old visual if present (we will recreate)
            if e.id:
                try:
                    if isinstance(e.id, (list, tuple)):
                        for iid in e.id:
                            self.canvas.delete(iid)
                    else:
                        self.canvas.delete(e.id)
                except:
                    pass

        self.canvas.delete("all")

        # draw tiles as diamonds (isometric)
        for row in self.tiles:
            for t in row:
                cx = t.x + t.size/2
                cy = t.y + t.size/2
                half = t.size/2
                points = (cx, t.y, t.x + t.size, cy, cx, t.y + t.size, t.x, cy)
                # store polygon id
                t.rect_id = self.canvas.create_polygon(points, fill=t.color, outline="#000", width=2)
                # visits text (keep small and centered)
                t.text_id = self.canvas.create_text(cx, cy, text=str(t.visits) if t.visits > 0 else "",
                                                    fill="#000", font=("TkDefaultFont", 12))

        # UI text
        self.score_text = self.canvas.create_text(12, 12, anchor="nw", fill="#eee", font=("TkDefaultFont", 12),
                                                  text=f"Score: {self.score}")
        self.lives_text = self.canvas.create_text(12, 32, anchor="nw", fill="#eee", font=("TkDefaultFont", 12),
                                                  text=f"Lives: {self.lives}")
        self.level_text = self.canvas.create_text(12, 52, anchor="nw", fill="#eee", font=("TkDefaultFont", 12),
                                                  text=f"Level: {self.level}")

        # Controls legend (show control letters and arrow mapping)
        # Place on the top-right area
        controls_text = ("Controls:\n"
                         "Q = up-left    E = up-right\n"
                         "Z = down-left  C = down-right\n"
                         "Arrow keys also map to diagonals")
        # delete previous if present
        if self.controls_text_id:
            try:
                self.canvas.delete(self.controls_text_id)
            except:
                pass
        self.controls_text_id = self.canvas.create_text(self.canvas_w - 12, 12, anchor="ne",
                                                        fill="#ddd", font=("TkDefaultFont", 11),
                                                        text=controls_text)

        # player visual (draw at current player_x, player_y)
        self._draw_player_visual()

        # Recreate enemy objects and visuals from saved states so opponents persist across levels
        new_enemies = []
        for st in enemy_states:
            # ensure path is valid for current pyramid size; clamp path rows/cols if needed
            path = []
            for (r, c) in st["path"]:
                rr = min(r, self.rows - 1)
                cc = min(c, rr)
                path.append((rr, cc))
            speed = st.get("speed", ENEMY_BASE_SPEED + random.random() * 0.8)
            e = Enemy(path, self.canvas, speed)
            # if stored pos exists, use it; otherwise spawn at top
            if st.get("pos"):
                e.pos = st["pos"]
            else:
                e.pos = list(self._tile_center(0, 0))
                e.pos[1] -= TILE_SIZE
            # create visual using spawn_visual so id is a tuple
            e.spawn_visual(e.pos[0], e.pos[1], color="#c33")
            e.index = min(st.get("index", 0), len(e.path))
            new_enemies.append(e)

        # If there were no enemies saved (first run), keep existing self.enemies as is
        if new_enemies:
            self.enemies = new_enemies

    def _draw_player_visual(self):
        """Create or update the player visual as a small isometric character."""
        # delete previous player parts if present
        if self.player_id:
            try:
                if isinstance(self.player_id, (list, tuple)):
                    for pid in self.player_id:
                        self.canvas.delete(pid)
                else:
                    self.canvas.delete(self.player_id)
            except:
                pass

        px, py = self.player_x, self.player_y
        # main triangular body (pointing up)
        body = self.canvas.create_polygon(
            px, py - PLAYER_RADIUS,
            px - PLAYER_RADIUS, py + PLAYER_RADIUS,
            px + PLAYER_RADIUS, py + PLAYER_RADIUS,
            fill="#ff9f2c", outline="#000", width=2
        )
        # nose (small circle offset forward)
        nose = self.canvas.create_oval(px - 4, py - PLAYER_RADIUS - 6, px + 4, py - PLAYER_RADIUS + 2,
                                      fill="#ff6b00", outline="#000")
        # eyes (two small ovals)
        eye_l = self.canvas.create_oval(px - 8, py - 4, px - 4, py, fill="#fff", outline="#000")
        eye_r = self.canvas.create_oval(px + 4, py - 4, px + 8, py, fill="#fff", outline="#000")
        pupil_l = self.canvas.create_oval(px - 7, py - 3, px - 5, py - 1, fill="#000")
        pupil_r = self.canvas.create_oval(px + 5, py - 3, px + 7, py - 1, fill="#000")

        # store all player canvas ids so we can delete/redraw easily
        self.player_id = (body, nose, eye_l, eye_r, pupil_l, pupil_r)

    def _spawn_initial_enemies(self, count):
        # If enemies already exist, do not duplicate; ensure at least `count` enemies present
        while len(self.enemies) < count:
            self._add_enemy()

    def _random_path(self):
        r = 0
        c = 0
        path = [(0, 0)]
        while r < self.rows - 1:
            if random.random() < 0.5:
                c = c
            else:
                c = c + 1
            r += 1
            path.append((r, c))
        return path

    def _add_enemy(self):
        path = self._random_path()
        speed = ENEMY_BASE_SPEED + random.random() * 0.8
        e = Enemy(path, self.canvas, speed)
        x, y = self._tile_center(0, 0)
        e.spawn_visual(x, y, color="#c33")
        e.pos[1] -= TILE_SIZE  # spawn slightly above top tile
        # ensure enemy has a valid index within path
        e.index = 0
        self.enemies.append(e)

    def _mark_tile_on_land(self):
        """On landing: if first visit assign a persistent color; increment visits and update UI."""
        t = self.tiles[self.player_r][self.player_c]
        first = (t.visits == 0)
        t.visits += 1
        if first:
            t.color = random_pastel()
            if t.rect_id:
                try:
                    # polygon fill update
                    self.canvas.itemconfig(t.rect_id, fill=t.color)
                except:
                    pass
            self.score += POINTS_FIRST_VISIT
            self._update_ui()
        if t.text_id:
            try:
                self.canvas.itemconfig(t.text_id, text=str(t.visits))
            except:
                pass

    def _update_ui(self):
        self.canvas.itemconfig(self.score_text, text=f"Score: {self.score}")
        self.canvas.itemconfig(self.lives_text, text=f"Lives: {self.lives}")
        self.canvas.itemconfig(self.level_text, text=f"Level: {self.level}")

    def on_key(self, event):
        # ignore input while win animation pending or game over
        if self.game_over or self._win_pending:
            if self.game_over and event.keysym.lower() == "r":
                self._restart()
            return

        k = event.keysym.lower()
        # Diagonal-only movement: q/e/z/c and arrow keys mapped to diagonals
        if k == "q":
            self._move_up_left()
        elif k == "e":
            self._move_up_right()
        elif k == "z":
            self._move_down_left()
        elif k == "c":
            self._move_down_right()
        elif k == "up":
            if self.player_r > 0 and self.player_c > 0:
                self._move_up_left()
            elif self.player_r > 0:
                self._move_up_right()
        elif k == "down":
            if self.player_r < self.rows - 1 and self.player_c < self.player_r + 1:
                self._move_down_right()
            elif self.player_r < self.rows - 1:
                self._move_down_left()
        elif k == "left":
            if self.player_r > 0 and self.player_c > 0:
                self._move_up_left()
            elif self.player_r < self.rows - 1 and self.player_c > 0:
                self._move_down_left()
        elif k == "right":
            if self.player_r > 0 and self.player_c < self.player_r:
                self._move_up_right()
            elif self.player_r < self.rows - 1:
                self._move_down_right()

    # diagonal helpers
    def _move_up_left(self):
        if self.player_r > 0 and self.player_c > 0:
            self._move_player(-1, -1)

    def _move_up_right(self):
        if self.player_r > 0:
            self._move_player(-1, 0)

    def _move_down_left(self):
        if self.player_r < self.rows - 1:
            self._move_player(1, 0)

    def _move_down_right(self):
        if self.player_r < self.rows - 1 and self.player_c < self.player_r + 1:
            self._move_player(1, 1)

    def _move_player(self, dr, dc):
        nr = int(self.player_r + dr)
        nc = int(self.player_c + dc)
        if 0 <= nr < self.rows and 0 <= nc <= nr:
            self.player_r, self.player_c = nr, nc
            self.player_target = self._tile_center(nr, nc)

    def _update_player(self):
        tx, ty = self.player_target
        dx = tx - self.player_x
        dy = ty - self.player_y
        dist = (dx*dx + dy*dy) ** 0.5
        if dist > 1:
            step = MOVE_SPEED
            nx = self.player_x + dx / dist * step
            ny = self.player_y + dy / dist * step
            self.player_x, self.player_y = nx, ny
            # update visual position
            self._draw_player_visual()
        else:
            self.player_x, self.player_y = tx, ty
            self._draw_player_visual()
            self._mark_tile_on_land()

    def _update_enemies(self):
        """If enemies are paused due to respawn, skip advancing them but still update visuals."""
        now = time.time()
        paused = now < self.enemy_pause_until
        for e in self.enemies:
            if paused:
                # still update visual coords so they render at current pos, but do not advance path
                e.redraw()
                continue

            if e.index < len(e.path):
                r, c = e.path[e.index]
                # clamp r,c to current pyramid
                r = min(r, self.rows - 1)
                c = min(c, r)
                tx, ty = self._tile_center(r, c)
                dx = tx - e.pos[0]
                dy = ty - e.pos[1]
                dist = (dx*dx + dy*dy) ** 0.5
                if dist > 2:
                    step = e.speed
                    e.pos[0] += dx / dist * step
                    e.pos[1] += dy / dist * step
                else:
                    e.pos[0], e.pos[1] = tx, ty
                    e.index += 1
            else:
                if random.random() < 0.02:
                    e.path = self._random_path()
                    e.index = 0
            # update visual parts
            e.redraw()

    def _check_collisions(self):
        """Detect collisions; when player loses a life, pause enemies briefly while respawning."""
        now = time.time()
        invulnerable = now < getattr(self, "invulnerable_until", 0.0)

        if invulnerable:
            return

        for e in self.enemies:
            ex, ey = e.pos
            px, py = self.player_x, self.player_y
            d = ((ex-px)**2 + (ey-py)**2) ** 0.5
            if d < (PLAYER_RADIUS + ENEMY_SIZE/2) * 0.9:
                # collision occurred
                self.lives -= 1
                self._update_ui()
                # respawn player to top
                self.player_r, self.player_c = 0, 0
                self.player_x, self.player_y = self._tile_center(0, 0)
                self.player_target = (self.player_x, self.player_y)
                # pause enemies for a short time so player has a safe window after respawn
                self.enemy_pause_until = time.time() + RESPAWN_ENEMY_PAUSE
                # also make player invulnerable for the same short window to avoid immediate re-collision
                self.invulnerable_until = time.time() + RESPAWN_ENEMY_PAUSE
                # redraw player at respawn
                self._draw_player_visual()
                if self.lives <= 0:
                    self.game_over = True
                break  # handle one collision per tick

    def _all_touched(self):
        for row in self.tiles:
            for t in row:
                if t.visits == 0:
                    return False
        return True

    def _on_all_touched(self):
        """Called once when all tiles are touched. Show win message briefly, then automatically level up and continue."""
        if self._win_pending:
            return
        self._win_pending = True
        # show YOU WIN message
        self.canvas.delete("win")
        self.canvas.create_text(self.canvas_w//2, self.canvas_h//2 - 10,
                                text="YOU WIN!", fill="#7efc7e", font=("TkDefaultFont", 28), tags="win")
        self.canvas.create_text(self.canvas_w//2, self.canvas_h//2 + 24,
                                text="Advancing to next level...", fill="#eee", font=("TkDefaultFont", 12), tags="win2")
        # schedule immediate level up after a short delay (keeps flow)
        self.root.after(900, self._level_up_from_win)

    def _level_up_from_win(self):
        # remove win text
        self.canvas.delete("win")
        self.canvas.delete("win2")
        # increase global difficulty: slightly increase base enemy speed and player speed
        global ENEMY_BASE_SPEED, MOVE_SPEED
        ENEMY_BASE_SPEED += 0.25
        MOVE_SPEED = int(MOVE_SPEED * 1.05)
        # perform level up and resume play
        self._level_up()
        self._win_pending = False

    def _level_up(self):
        self.level += 1
        self.score += 100 * self.level
        # add an enemy if under limit (ensure opponents present in all levels)
        if len(self.enemies) < MAX_ENEMIES:
            self._add_enemy()
        # speed up existing enemies
        for e in self.enemies:
            e.speed += 0.25
        # grow pyramid up to a limit
        if self.rows < MAX_ROWS:
            self.rows = min(MAX_ROWS, self.rows + 1)
        # rebuild tiles and UI while preserving score/lives/level and preserving enemies
        self._build_pyramid(self.rows)
        self._create_ui()
        # reposition player to top
        self.player_r, self.player_c = 0, 0
        self.player_x, self.player_y = self._tile_center(0, 0)
        self.player_target = (self.player_x, self.player_y)
        # mark starting tile on new level
        self._mark_tile_on_land()
        self._update_ui()

    def _tick(self):
        if self.game_over:
            self.canvas.delete("gameover")
            self.canvas.create_text(self.canvas_w//2, self.canvas_h//2, text="GAME OVER\nPress R to restart",
                                    fill="#f66", font=("TkDefaultFont", 20), tags="gameover")
            return
        # normal updates
        self._update_player()
        self._update_enemies()
        self._check_collisions()
        # if all touched, trigger win sequence (which will level up and continue)
        if self._all_touched():
            self._on_all_touched()

    def _schedule_loop(self):
        now = time.time()
        elapsed = now - self._last_time
        if elapsed >= 1.0 / FPS:
            self._last_time = now
            self._tick()
        if self.running:
            self.root.after(8, self._schedule_loop)

    def _restart(self):
        for e in self.enemies:
            if e.id:
                try:
                    if isinstance(e.id, (list, tuple)):
                        for iid in e.id:
                            self.canvas.delete(iid)
                    else:
                        self.canvas.delete(e.id)
                except:
                    pass
        self.enemies.clear()
        self.rows = ROWS_START
        self._setup_state()

    def _random_path(self):
        r = 0
        c = 0
        path = [(0, 0)]
        while r < self.rows - 1:
            if random.random() < 0.5:
                c = c
            else:
                c = c + 1
            r += 1
            path.append((r, c))
        return path

def main():
    root = tk.Tk()
    root.title("Q*bert - mark tiles with color (opponents persist across levels)")
    game = Game(root)
    root.mainloop()

if __name__ == "__main__":
    main()
