#!/usr/bin/env python3
"""
Satan Speaks — interactive quote generator with TTS, count-limited repeat, auto, and multi-generation by user input

New feature:
 - In interactive mode you can now request multiple generations at once by typing a number (e.g., `5`)
   or `g 5` / `gen 5`. The program will print that many quotes immediately (respecting --inorder and --count).
Controls (interactive):
  - Enter : show the next quote
  - <number> or "g <number>" : generate that many quotes immediately
  - q + Enter : quit
  - r + Enter : restart from the first quote (in-order mode)
  - c + Enter : show how many quotes have been displayed so far
Options:
  --inorder    : iterate quotes in their defined order (wrap to start)
  --shuffle    : shuffle quotes once at start (only affects --inorder)
  --count N    : automatically exit after N quotes (0 = no limit)
  --auto S     : automatic mode: print quotes every S seconds (0 = interactive)
  --no-tts     : disable text-to-speech (TTS is ON by default)
  --seed N     : set random seed
  --width N    : wrap width for printed quotes
"""

from __future__ import annotations
import argparse
import random
import shutil
import subprocess
import sys
import textwrap
import time
from typing import Optional, List

QUOTES: List[str] = [
    "Why play it safe when mischief tastes so sweet?",
    "Rules are polite suggestions waiting to be ignored.",
    "Whisper your secret wish; I’ll applaud the courage.",
    "Chaos is creativity with louder applause.",
    "Dare to be different; the world needs new troublemakers.",
    "Temptation is curiosity in a velvet coat.",
    "Burn the script and improvise the scene.",
    "A clever lie is just a story that learned to survive.",
    "Comfort is a slow, polite kind of surrender.",
    "If you must choose, pick the story you’ll tell later.",
    "I don’t offer answers, only more interesting questions.",
    "Take the detour; the view is better off the map.",
    "Politeness is a costume—try the mask of mischief.",
    "Boredom is the first sin of the unimaginative.",
    "Make a little noise; the quiet is overrated.",
    "Regret is a souvenir from a life half-lived.",
    "Push the button labeled ‘Do Not Press’—for science.",
    "A spark of trouble brightens any dull evening.",
    "Say yes once and watch the plot thicken.",
    "Rules are scaffolding; art is demolition.",
    "I sell second chances with a wink and a grin.",
    "Break a pattern; invent a new habit of chaos.",
    "The polite path rarely leads to a good story.",
    "Risk is the spice that seasons a bland life.",
    "I prefer the scenic route through questionable choices.",
    "A little mischief keeps the soul from rusting.",
    "Doubt the obvious; delight in the unexpected.",
    "Wear your contradictions like a fine coat.",
    "If life is a stage, add a dramatic exit.",
    "Curiosity didn’t kill anyone worth remembering.",
    "Swap the map for a compass and wander.",
    "Comfort zones are prisons with soft pillows.",
    "I trade in deliciously inconvenient truths.",
    "Make trouble politely; chaos with manners is art.",
    "The best stories begin with a questionable decision.",
    "Whimsy is a tiny rebellion against the ordinary.",
    "Collect odd moments like rare coins.",
    "A scandal is just a rumor that learned to dance.",
    "Temptation is simply opportunity in a red dress.",
    "Be the plot twist your past never saw coming.",
    "Skepticism is healthy; cynicism is exhausting.",
    "Play with fire—just bring a good story.",
    "I prefer promises that come with a little risk.",
    "Turn the page; the next chapter wants trouble.",
    "A secret kept well is a small, delicious power.",
    "Rebellion looks better in a tailored suit.",
    "Make mischief with intention, not malice.",
    "The polite lie is a lullaby for the bored.",
    "Tempt the ordinary until it reveals its edges.",
    "A little chaos polishes the dullest days.",
    "Ask for the moon; at least you’ll climb.",
    "Rules are fences; fences are meant to be admired.",
    "I applaud the audacious and the absurd.",
    "Take the risk; regret is a heavier burden.",
    "A wink can start a revolution.",
    "Delight in the small rebellions—they add up.",
    "The safe road rarely has a good soundtrack.",
    "I prefer promises that come with a dare.",
    "Make a mess; masterpieces often begin messy.",
    "A scandal is just a rumor with confidence.",
    "Temptation is a teacher in a mischievous hat.",
    "Be the rumor people whisper about fondly.",
    "Break the mold; it’s been collecting dust.",
    "A little mischief is excellent for circulation.",
    "Choose the path that makes your heart race.",
    "I offer detours with scenic moral ambiguity.",
    "Play the part that makes the audience gasp.",
    "Comfort is a slow surrender to sameness.",
    "Make a promise you can’t keep—then keep the fun.",
    "A bold lie is just a truth in disguise.",
    "Stir the pot; flavor comes from friction.",
    "I admire those who flirt with the impossible.",
    "Dare to color outside the lines of expectation.",
    "A little chaos is the universe’s seasoning.",
    "Temptation is the art of persuasive possibility.",
    "Be the mischief your future self will thank you for.",
    "Rules are maps drawn by cautious hands.",
    "I prefer the map with a big X and no legend.",
    "Make trouble that teaches, not destroys.",
    "A secret is a private kind of power.",
    "Risk is the currency of memorable lives.",
    "I sell midnight ideas with morning consequences.",
    "Playful rebellion ages like fine mischief.",
    "The best confessions begin with a laugh.",
    "Temptation is simply curiosity with better lighting.",
    "Be the spark that makes the dull things glow.",
    "A little wickedness keeps the soul interesting.",
    "Choose the story that makes you grin later.",
    "Rules are suggestions in a suit of armor.",
    "I prefer invitations stamped ‘Do not RSVP.’",
    "Make a scene; the world needs drama.",
    "A mischievous heart is a well-traveled heart.",
    "Temptation is a doorway—open it slowly.",
    "Be the rumor that improves people’s evenings.",
    "Risk politely; chaos appreciates good manners.",
    "I trade in bold ideas and polite consequences.",
    "Dare to be the anecdote people repeat.",
    "A little trouble is excellent for perspective.",
    "Temptation is the art of better options.",
    "Live a story worth telling at midnight."
]

# ---------------------------
# TTS helpers (no external deps)
# ---------------------------

def _which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)

def _speak_mac(text: str) -> bool:
    cmd = _which("say")
    if not cmd:
        return False
    try:
        subprocess.run([cmd, text], check=False)
        return True
    except Exception:
        return False

def _speak_linux(text: str) -> bool:
    spd = _which("spd-say")
    if spd:
        try:
            subprocess.run([spd, text], check=False)
            return True
        except Exception:
            pass
    espeak = _which("espeak")
    if espeak:
        try:
            subprocess.run([espeak, text], check=False)
            return True
        except Exception:
            pass
    return False

def _speak_windows(text: str) -> bool:
    esc = text.replace("'", "''")
    ps_script = (
        "Add-Type -AssemblyName System.Speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        "$s.Speak('" + esc + "');"
    )
    powershell = _which("powershell") or _which("pwsh")
    if not powershell:
        return False
    try:
        subprocess.run([powershell, "-NoProfile", "-Command", ps_script], check=False)
        return True
    except Exception:
        return False

def speak(text: str) -> bool:
    if not text:
        return False
    platform = sys.platform
    if platform.startswith("darwin"):
        return _speak_mac(text)
    if platform.startswith("win"):
        return _speak_windows(text)
    return _speak_linux(text)

# ---------------------------
# Utility / UI
# ---------------------------

def wrap_quote(q: str, width: int = 72) -> str:
    return textwrap.fill(f'“{q}”', width=width)

def print_quote_header(displayed_count: int, index: int, total: int, inorder: bool) -> None:
    if inorder:
        pos = (index - 1) % total + 1
        print(f"[{displayed_count}] ({pos}/{total})")
    else:
        print(f"[{displayed_count}]")

# ---------------------------
# Core generation helpers
# ---------------------------

def _select_quote(quotes: List[str], inorder: bool, pool_index: int) -> (str, int):
    """
    Return (quote, next_pool_index). If inorder True, use pool_index and increment (wrap).
    If False, return a random quote and keep pool_index unchanged.
    """
    total = len(quotes)
    if inorder:
        q = quotes[pool_index]
        next_index = (pool_index + 1) % total
        return q, next_index
    return random.choice(quotes), pool_index

def generate_and_output(n: int, state: dict):
    """
    Generate `n` quotes immediately, respecting:
      - state['quotes'] : list of quotes (possibly shuffled)
      - state['inorder'] : bool
      - state['tts_on'] : bool
      - state['width'] : int
      - state['count_limit'] : Optional[int] (global limit)
      - state['displayed'] : int (will be updated)
      - state['pool_index'] : int (will be updated for inorder)
    Stops early if count_limit reached.
    """
    quotes = state['quotes']
    total = len(quotes)
    inorder = state['inorder']
    tts_on = state['tts_on']
    width = state['width']
    count_limit = state['count_limit']
    displayed = state['displayed']
    pool_index = state['pool_index']

    for _ in range(n):
        # Check global count limit
        if count_limit is not None and displayed >= count_limit:
            print(f"\nReached requested count ({count_limit}). Stopping generation.")
            break

        q, pool_index = _select_quote(quotes, inorder, pool_index)
        displayed += 1
        print_quote_header(displayed, pool_index, total, inorder)
        print(wrap_quote(q, width=width) + "\n")

        if tts_on:
            try:
                if not speak(q):
                    print("(TTS unavailable; use --no-tts to silence this message.)")
                    # disable to avoid repeated messages
                    state['tts_on'] = False
                    tts_on = False
            except Exception:
                state['tts_on'] = False
                tts_on = False

    # update state
    state['displayed'] = displayed
    state['pool_index'] = pool_index

# ---------------------------
# Modes
# ---------------------------

def non_repeat_mode(quotes: List[str], count: int, inorder: bool, shuffle: bool, tts_on: bool, width: int):
    pool = quotes.copy()
    total = len(pool)
    if inorder:
        if shuffle:
            random.shuffle(pool)
        for i in range(min(count, total)):
            displayed = i + 1
            q = pool[i]
            print_quote_header(displayed, i + 1, total, inorder=True)
            print(wrap_quote(q, width=width) + "\n")
            if tts_on:
                try:
                    if not speak(q):
                        print("(TTS unavailable; use --no-tts to silence.)")
                        tts_on = False
                except Exception:
                    tts_on = False
    else:
        for i in range(count):
            displayed = i + 1
            q = random.choice(pool)
            print_quote_header(displayed, 0, total, inorder=False)
            print(wrap_quote(q, width=width) + "\n")
            if tts_on:
                try:
                    if not speak(q):
                        print("(TTS unavailable; use --no-tts to silence.)")
                        tts_on = False
                except Exception:
                    tts_on = False

def auto_mode(quotes: List[str], count: Optional[int], interval: float, inorder: bool, shuffle: bool, tts_on: bool, width: int):
    pool = quotes.copy()
    total = len(pool)
    index = 0
    displayed = 0

    if inorder and shuffle:
        random.shuffle(pool)

    try:
        while True:
            if count is not None and displayed >= count:
                print(f"\nReached requested count ({count}). Exiting.")
                break

            if inorder:
                q = pool[index]
                index = (index + 1) % total
            else:
                q = random.choice(pool)

            displayed += 1
            print_quote_header(displayed, index, total, inorder)
            print(wrap_quote(q, width=width) + "\n")

            if tts_on:
                try:
                    if not speak(q):
                        print("(TTS unavailable; use --no-tts to silence.)")
                        tts_on = False
                except Exception:
                    tts_on = False

            time.sleep(interval)
    except KeyboardInterrupt:
        print(f"\nInterrupted. You viewed {displayed} quote(s). Exiting.")

def interactive_mode(quotes: List[str], count: Optional[int], inorder: bool, shuffle: bool, tts_on: bool, width: int):
    """
    Interactive repeat-or-quit mode with multi-generation support.
    - Typing a number (e.g., `5`) or `g 5` / `gen 5` generates that many quotes immediately.
    - Enter shows one quote.
    - 'c' shows count, 'r' restarts (inorder), 'q' quits.
    """
    pool = quotes.copy()
    total = len(pool)
    pool_index = 0
    displayed = 0

    if inorder and shuffle:
        random.shuffle(pool)

    state = {
        'quotes': pool,
        'inorder': inorder,
        'tts_on': tts_on,
        'width': width,
        'count_limit': count,
        'displayed': displayed,
        'pool_index': pool_index
    }

    prompt = "Press Enter for next, type a number (e.g., 5) to generate that many, 'c' to show count, 'r' to restart, 'q' to quit: "

    try:
        while True:
            # If count limit already reached, exit
            if count is not None and state['displayed'] >= count:
                print(f"\nReached requested count ({count}). Exiting.")
                break

            try:
                user = input(prompt).strip().lower()
            except (EOFError, KeyboardInterrupt):
                print(f"\nQuitting. You viewed {state['displayed']} quote(s).")
                break

            if user == '':
                # single generation
                generate_and_output(1, state)
                continue

            if user == 'q':
                print(f"Goodbye. You viewed {state['displayed']} quote(s).")
                break

            if user == 'c':
                print(f"You have viewed {state['displayed']} quote(s) so far.")
                continue

            if user == 'r' and inorder:
                state['pool_index'] = 0
                state['displayed'] = 0
                print("Restarting from the first quote and resetting the count...")
                continue

            # Try to parse multi-generation commands:
            # Accept formats: "5", "g 5", "gen 5"
            parts = user.split()
            num = None
            if len(parts) == 1 and parts[0].isdigit():
                num = int(parts[0])
            elif len(parts) == 2 and parts[0] in ('g', 'gen') and parts[1].isdigit():
                num = int(parts[1])

            if num is not None:
                if num <= 0:
                    print("Please enter a positive number.")
                    continue
                # Respect global count limit if present: compute allowed remaining
                if state['count_limit'] is not None:
                    remaining = state['count_limit'] - state['displayed']
                    if remaining <= 0:
                        print(f"Count limit reached ({state['count_limit']}). No more quotes will be generated.")
                        break
                    if num > remaining:
                        print(f"Limiting generation to remaining {remaining} quote(s) due to --count {state['count_limit']}.")
                        num = remaining
                generate_and_output(num, state)
                continue

            # Unknown command
            print("Unrecognized input. Press Enter for one quote, a number to generate that many, or 'q' to quit.")
    except KeyboardInterrupt:
        print(f"\nInterrupted. You viewed {state['displayed']} quote(s). Exiting.")

# ---------------------------
# Main
# ---------------------------

def main():
    parser = argparse.ArgumentParser(description="Satan Speaks — interactive quote generator with TTS, count, auto, and multi-generation")
    parser.add_argument('--inorder', action='store_true', help='Show quotes in their defined order (wrap to start)')
    parser.add_argument('--shuffle', action='store_true', help='Shuffle quotes once at start (only affects --inorder)')
    parser.add_argument('--seed', type=int, help='Random seed (affects shuffle and random selection)')
    parser.add_argument('--no-tts', action='store_true', help='Disable text-to-speech (TTS is ON by default)')
    parser.add_argument('--width', type=int, default=72, help='Wrap width for quotes (default: 72)')
    parser.add_argument('--count', type=int, default=0, help='Automatically exit after N quotes (0 = no limit)')
    parser.add_argument('--auto', type=float, default=0.0, help='Automatic mode: seconds between quotes (0 = interactive)')
    args = parser.parse_args()

    if args.seed is not None:
        random.seed(args.seed)

    quotes = QUOTES.copy()
    tts_on = not args.no_tts
    count = args.count if args.count > 0 else None

    # Auto mode: timed output until count reached or interrupted
    if args.auto and args.auto > 0:
        auto_mode(quotes, count=count, interval=args.auto, inorder=args.inorder, shuffle=args.shuffle, tts_on=tts_on, width=args.width)
        return

    # Non-interactive environment with count: print and exit
    if count is not None and not sys.stdin.isatty():
        non_repeat_mode(quotes, count=count, inorder=args.inorder, shuffle=args.shuffle, tts_on=tts_on, width=args.width)
        return

    # If count provided and user wants a one-shot non-repeat behavior in a terminal, run interactive but it will stop after count
    if count is not None and args.auto == 0.0 and sys.stdin.isatty():
        interactive_mode(quotes, count=count, inorder=args.inorder, shuffle=args.shuffle, tts_on=tts_on, width=args.width)
        return

    # Default: interactive mode with no limit
    interactive_mode(quotes, count=None, inorder=args.inorder, shuffle=args.shuffle, tts_on=tts_on, width=args.width)

if __name__ == "__main__":
    main()
