#!/usr/bin/env python3
"""
spreadsheet_app.py
Standalone spreadsheet program (no external packages) with large grid support.

- Default grid: 1000 rows x 100 columns (adjustable)
- Menu: File, Edit, Grid Size (set rows/cols)
- Insert/Delete rows/cols, editable header cells, formulas, CSV save/load, HTML export
- No external libraries; uses tkinter and standard library only

Run:
    python spreadsheet_app.py
"""

import csv
import json
import os
import re
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from typing import Dict, Tuple, Set, Any, List

# -------------------------
# Parser utilities
# -------------------------
CellCoord = Tuple[int, int]  # (row, col) 1-based (data area)
A1_RE = re.compile(r"([A-Za-z]+)(\d+)")
RANGE_RE = re.compile(r"([A-Za-z]+\d+):([A-Za-z]+\d+)")

def col_to_index(col: str) -> int:
    col = col.upper()
    n = 0
    for ch in col:
        n = n * 26 + (ord(ch) - ord('A') + 1)
    return n

def index_to_col(idx: int) -> str:
    s = ""
    while idx:
        idx, rem = divmod(idx - 1, 26)
        s = chr(ord('A') + rem) + s
    return s

def a1_to_coord(a1: str) -> CellCoord:
    m = A1_RE.fullmatch(a1)
    if not m:
        raise ValueError(f"Invalid A1 ref: {a1}")
    col = col_to_index(m.group(1))
    row = int(m.group(2))
    return (row, col)

def expand_range(a1_from: str, a1_to: str) -> List[CellCoord]:
    r1, c1 = a1_to_coord(a1_from)
    r2, c2 = a1_to_coord(a1_to)
    rows = range(min(r1, r2), max(r1, r2) + 1)
    cols = range(min(c1, c2), max(c1, c2) + 1)
    return [(r, c) for r in rows for c in cols]

# -------------------------
# Formula parser / evaluator
# -------------------------
class FormulaParser:
    def __init__(self, sheet):
        self.sheet = sheet

    def extract_references(self, text: str) -> Set[CellCoord]:
        refs = set()
        for m in A1_RE.finditer(text):
            try:
                refs.add(a1_to_coord(m.group(0)))
            except Exception:
                pass
        for m in RANGE_RE.finditer(text):
            try:
                for coord in expand_range(m.group(1), m.group(2)):
                    refs.add(coord)
            except Exception:
                pass
        return refs

    def _value_of(self, coord: CellCoord):
        val = self.sheet.values.get(coord, None)
        if val is None:
            text = self.sheet.cells.get(coord, "")
            if isinstance(text, str) and text.startswith("="):
                val = self.evaluate(text, coord)
            else:
                try:
                    val = float(text) if text != "" else 0
                    if isinstance(val, float) and val.is_integer():
                        val = int(val)
                except Exception:
                    val = text
            self.sheet.values[coord] = val
        return val

    def _range_values(self, a1_from: str, a1_to: str):
        coords = expand_range(a1_from, a1_to)
        vals = []
        for c in coords:
            v = self._value_of(c)
            if isinstance(v, (int, float)):
                vals.append(v)
        return vals

    def evaluate(self, text: str, this_coord: CellCoord = None):
        expr = text.lstrip("=")
        def fn_repl(m):
            fname = m.group(1).upper()
            arg = m.group(2)
            if ":" in arg:
                a, b = arg.split(":")
                return f"__fn_{fname}('{a}','{b}')"
            else:
                return f"__fn_{fname}('{arg}')"
        expr = re.sub(r"([A-Za-z]+)\s*\(\s*([A-Za-z0-9_:]+)\s*\)", fn_repl, expr)
        expr = re.sub(r"([A-Za-z]+\d+)", lambda m: f"__ref('{m.group(1)}')", expr)

        def __ref(a1):
            coord = a1_to_coord(a1)
            v = self._value_of(coord)
            return v if isinstance(v, (int, float)) else 0

        def __fn_SUM(a1, b=None):
            if b:
                vals = self._range_values(a1, b)
            else:
                vals = [__ref(a1)]
            return sum(vals)

        def __fn_AVERAGE(a1, b=None):
            if b:
                vals = self._range_values(a1, b)
            else:
                vals = [__ref(a1)]
            return sum(vals) / len(vals) if vals else 0

        def __fn_MIN(a1, b=None):
            if b:
                vals = self._range_values(a1, b)
            else:
                vals = [__ref(a1)]
            return min(vals) if vals else 0

        def __fn_MAX(a1, b=None):
            if b:
                vals = self._range_values(a1, b)
            else:
                vals = [__ref(a1)]
            return max(vals) if vals else 0

        def __fn_COUNT(a1, b=None):
            if b:
                vals = self._range_values(a1, b)
            else:
                v = __ref(a1)
                vals = [v] if v != 0 else []
            return len(vals)

        env = {
            "__ref": __ref,
            "__fn_SUM": __fn_SUM,
            "__fn_AVERAGE": __fn_AVERAGE,
            "__fn_MIN": __fn_MIN,
            "__fn_MAX": __fn_MAX,
            "__fn_COUNT": __fn_COUNT,
        }

        try:
            return eval(expr, {"__builtins__": None}, env)
        except Exception as e:
            raise RuntimeError(f"Eval error: {e}")

# -------------------------
# Core spreadsheet model
# -------------------------
class Sheet:
    def __init__(self, name: str):
        self.name = name
        self.cells: Dict[CellCoord, str] = {}   # raw text for data area (1-based)
        self.values: Dict[CellCoord, Any] = {}  # evaluated values
        self.deps: Dict[CellCoord, Set[CellCoord]] = {}    # cell -> dependents
        self.revdeps: Dict[CellCoord, Set[CellCoord]] = {} # cell -> dependencies
        self.parser = FormulaParser(self)
        self.col_headers: Dict[int, str] = {}
        self.row_headers: Dict[int, str] = {}

    def set_cell(self, r: int, c: int, text: str):
        coord = (r, c)
        self.cells[coord] = text
        self._update_dependencies(coord, text)
        self.recalculate_from(coord)

    def get_cell_text(self, r: int, c: int) -> str:
        return self.cells.get((r, c), "")

    def get_cell_value(self, r: int, c: int):
        return self.values.get((r, c), "")

    def set_col_header(self, c: int, text: str):
        if text == "":
            self.col_headers.pop(c, None)
        else:
            self.col_headers[c] = text

    def set_row_header(self, r: int, text: str):
        if text == "":
            self.row_headers.pop(r, None)
        else:
            self.row_headers[r] = text

    def get_col_header(self, c: int) -> str:
        return self.col_headers.get(c, "")

    def get_row_header(self, r: int) -> str:
        return self.row_headers.get(r, "")

    def _update_dependencies(self, coord: CellCoord, text: str):
        old = self.revdeps.get(coord, set())
        for dep in old:
            self.deps.get(dep, set()).discard(coord)
        self.revdeps[coord] = set()
        if isinstance(text, str) and text.startswith("="):
            refs = self.parser.extract_references(text)
            self.revdeps[coord] = refs
            for r in refs:
                self.deps.setdefault(r, set()).add(coord)
        else:
            self.revdeps[coord] = set()

    def recalculate_from(self, coord: CellCoord):
        to_visit = [coord]
        visited = set()
        while to_visit:
            cur = to_visit.pop(0)
            if cur in visited:
                continue
            visited.add(cur)
            text = self.cells.get(cur, "")
            if isinstance(text, str) and text.startswith("="):
                try:
                    val = self.parser.evaluate(text, cur)
                except Exception as e:
                    val = f"#ERR {e}"
            else:
                try:
                    val = float(text) if text != "" else ""
                    if isinstance(val, float) and val.is_integer():
                        val = int(val)
                except Exception:
                    val = text
            self.values[cur] = val
            for dep in self.deps.get(cur, set()):
                to_visit.append(dep)

class Workbook:
    def __init__(self):
        self.sheets: Dict[str, Sheet] = {}
        self.active: str = ""

    def add_sheet(self, name: str):
        s = Sheet(name)
        self.sheets[name] = s
        if not self.active:
            self.active = name
        return s

    def get_active_sheet(self) -> Sheet:
        return self.sheets[self.active]

# -------------------------
# Storage (CSV manifest + headers)
# -------------------------
MANIFEST = "workbook.manifest.json"
HEADERS_FILE = "headers.json"

def save_workbook(folder: str, workbook: Workbook):
    os.makedirs(folder, exist_ok=True)
    manifest = {"sheets": []}
    for name, sheet in workbook.sheets.items():
        fname = f"{name}.csv"
        path = os.path.join(folder, fname)
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            coords = list(sheet.cells.keys())
            max_row = max((r for r, c in coords), default=0)
            max_col = max((c for r, c in coords), default=0)
            for r in range(1, max_row + 1):
                row = []
                for c in range(1, max_col + 1):
                    row.append(sheet.cells.get((r, c), ""))
                writer.writerow(row)
        headers_path = os.path.join(folder, f"{name}.{HEADERS_FILE}")
        with open(headers_path, "w", encoding="utf-8") as hf:
            json.dump({"col_headers": sheet.col_headers, "row_headers": sheet.row_headers}, hf, indent=2)
        manifest["sheets"].append({"name": name, "file": fname, "headers": f"{name}.{HEADERS_FILE}"})
    with open(os.path.join(folder, MANIFEST), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

def load_workbook(folder: str) -> Workbook:
    path = os.path.join(folder, MANIFEST)
    if not os.path.exists(path):
        raise FileNotFoundError("Manifest not found")
    with open(path, "r", encoding="utf-8") as f:
        manifest = json.load(f)
    wb = Workbook()
    for s in manifest.get("sheets", []):
        name = s["name"]
        fname = s["file"]
        sheet = wb.add_sheet(name)
        csvpath = os.path.join(folder, fname)
        if os.path.exists(csvpath):
            with open(csvpath, "r", newline="", encoding="utf-8") as f:
                reader = csv.reader(f)
                for r_idx, row in enumerate(reader, start=1):
                    for c_idx, val in enumerate(row, start=1):
                        if val != "":
                            sheet.cells[(r_idx, c_idx)] = val
        headers_file = s.get("headers")
        if headers_file:
            headers_path = os.path.join(folder, headers_file)
            if os.path.exists(headers_path):
                with open(headers_path, "r", encoding="utf-8") as hf:
                    data = json.load(hf)
                    sheet.col_headers = {int(k): v for k, v in data.get("col_headers", {}).items()}
                    sheet.row_headers = {int(k): v for k, v in data.get("row_headers", {}).items()}
    return wb

def export_sheet_to_html(sheet: Sheet, out_html: str, title: str = None):
    coords = list(sheet.cells.keys())
    max_row = max((r for r, c in coords), default=0)
    max_col = max((c for r, c in coords), default=0)
    title = title or sheet.name
    with open(out_html, "w", encoding="utf-8") as f:
        f.write(f"<!doctype html>\n<html><head><meta charset='utf-8'><title>{title}</title>\n")
        f.write("<style>table{border-collapse:collapse}td,th{border:1px solid #999;padding:6px}</style>\n")
        f.write("</head><body>\n")
        f.write(f"<h2>{title}</h2>\n")
        f.write("<table>\n")
        f.write("<tr><th></th>")
        for c in range(1, max_col + 1):
            f.write(f"<th>{sheet.get_col_header(c) or index_to_col(c)}</th>")
        f.write("</tr>\n")
        for r in range(1, max_row + 1):
            f.write("<tr>")
            f.write(f"<th>{sheet.get_row_header(r) or str(r)}</th>")
            for c in range(1, max_col + 1):
                v = sheet.get_cell_value(r, c)
                f.write(f"<td>{'' if v is None else v}</td>")
            f.write("</tr>\n")
        f.write("</table>\n</body></html>")

# -------------------------
# GUI (tkinter) with large grid support
# -------------------------
class SpreadsheetApp:
    def __init__(self, rows=1000, cols=100):
        self.root = tk.Tk()
        self.root.title("Large Grid Spreadsheet")
        self.rows = rows
        self.cols = cols
        self.wb = Workbook()
        self.wb.add_sheet("Sheet1")
        self.active_sheet = self.wb.get_active_sheet()
        self._build_ui()

    def _build_ui(self):
        menubar = tk.Menu(self.root)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="New Sheet", command=self.new_sheet)
        filemenu.add_command(label="Open Workbook...", command=self.open_workbook)
        filemenu.add_command(label="Save Workbook...", command=self.save_workbook)
        filemenu.add_separator()
        filemenu.add_command(label="Export Sheet to HTML...", command=self.export_html)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=filemenu)

        editmenu = tk.Menu(menubar, tearoff=0)
        editmenu.add_command(label="Insert Row", command=self.insert_row)
        editmenu.add_command(label="Delete Row", command=self.delete_row)
        editmenu.add_separator()
        editmenu.add_command(label="Insert Column", command=self.insert_col)
        editmenu.add_command(label="Delete Column", command=self.delete_col)
        menubar.add_cascade(label="Edit", menu=editmenu)

        gridmenu = tk.Menu(menubar, tearoff=0)
        gridmenu.add_command(label="Set Grid Size...", command=self.set_grid_size)
        menubar.add_cascade(label="Grid", menu=gridmenu)

        self.root.config(menu=menubar)

        toolbar = tk.Frame(self.root)
        toolbar.pack(fill="x")
        tk.Button(toolbar, text="New Sheet", command=self.new_sheet).pack(side="left")
        tk.Button(toolbar, text="Recalc", command=self.recalc).pack(side="left")
        tk.Button(toolbar, text="Save", command=self.save_workbook).pack(side="left")
        tk.Button(toolbar, text="Grid Size", command=self.set_grid_size).pack(side="left")

        self._build_grid()
        status = tk.Frame(self.root)
        status.pack(fill="x")
        self.status_var = tk.StringVar(value=f"Grid: {self.rows} rows x {self.cols} cols")
        tk.Label(status, textvariable=self.status_var, anchor="w").pack(fill="x")

    def _build_grid(self):
        if hasattr(self, "grid"):
            self.grid.destroy()
        cols = [index_to_col(i) for i in range(1, self.cols + 1)]
        self.grid = ttk.Treeview(self.root, columns=cols, show="headings", height=min(40, self.rows))
        for col in cols:
            self.grid.heading(col, text=col)
            self.grid.column(col, width=100, anchor="w")
        self.grid.pack(fill="both", expand=True)
        # populate a reasonable number of rows for display; Treeview can hold many rows but UI may slow
        for r in range(1, self.rows + 1):
            if not self.grid.exists(str(r)):
                self.grid.insert("", "end", iid=str(r), values=tuple("" for _ in cols))
        self.grid.bind("<Double-1>", self.on_double_click)
        self._build_header_widgets()

    def _build_header_widgets(self):
        # simple header buttons above and left; rebuild if needed
        if hasattr(self, "top_header"):
            self.top_header.destroy()
        if hasattr(self, "left_header"):
            self.left_header.destroy()
        self.top_header = tk.Frame(self.root)
        self.top_header.pack(fill="x", before=self.grid)
        tl = tk.Label(self.top_header, text="", borderwidth=1, relief="raised", width=6)
        tl.pack(side="left")
        # only show first N column header buttons to avoid huge UI; full headers editable via dialog
        show_cols = min(self.cols, 20)
        for c in range(1, show_cols + 1):
            label = self.active_sheet.get_col_header(c) or index_to_col(c)
            btn = tk.Button(self.top_header, text=label, width=12, relief="raised",
                            command=lambda cc=c: self.edit_col_header(cc))
            btn.pack(side="left")
        self.left_header = tk.Frame(self.root)
        self.left_header.pack(side="left", anchor="n", before=self.grid)
        show_rows = min(self.rows, 40)
        left_frame = tk.Frame(self.left_header)
        left_frame.pack(side="left", anchor="n")
        for r in range(1, show_rows + 1):
            label = self.active_sheet.get_row_header(r) or str(r)
            btn = tk.Button(left_frame, text=label, width=6, relief="raised",
                            command=lambda rr=r: self.edit_row_header(rr))
            btn.pack(anchor="w")

    def edit_col_header(self, c: int):
        cur = self.active_sheet.get_col_header(c) or index_to_col(c)
        val = simpledialog.askstring("Edit Column Header", f"Header for column {index_to_col(c)}:", initialvalue=cur)
        if val is None:
            return
        self.active_sheet.set_col_header(c, val)
        self._build_header_widgets()

    def edit_row_header(self, r: int):
        cur = self.active_sheet.get_row_header(r) or str(r)
        val = simpledialog.askstring("Edit Row Header", f"Header for row {r}:", initialvalue=cur)
        if val is None:
            return
        self.active_sheet.set_row_header(r, val)
        self._build_header_widgets()

    def on_double_click(self, event):
        item = self.grid.identify_row(event.y)
        col = self.grid.identify_column(event.x)
        if not item or not col:
            return
        col_idx = int(col.replace("#", ""))
        r = int(item)
        self.edit_data_cell(r, col_idx)

    def edit_data_cell(self, r: int, c: int):
        bbox = self.grid.bbox(str(r), column=f"#{c}")
        if not bbox:
            return
        x, y, w, h = bbox
        gx = self.grid.winfo_rootx() - self.root.winfo_rootx() + x
        gy = self.grid.winfo_rooty() - self.root.winfo_rooty() + y
        entry = tk.Entry(self.root)
        entry.place(x=gx, y=gy, width=w, height=h)
        raw = self.active_sheet.get_cell_text(r, c)
        entry.insert(0, raw)
        def commit(event=None):
            val = entry.get()
            entry.destroy()
            self.active_sheet.set_cell(r, c, val)
            display = self.active_sheet.get_cell_value(r, c)
            self.grid.set(str(r), column=c - 1, value="" if display is None else str(display))
            self.status_var.set(f"Set {index_to_col(c)}{r} = {val}")
        entry.bind("<Return>", commit)
        entry.focus_set()

    def new_sheet(self):
        name = f"Sheet{len(self.wb.sheets) + 1}"
        self.wb.add_sheet(name)
        self.active_sheet = self.wb.get_active_sheet()
        self._build_grid()
        messagebox.showinfo("New sheet", f"Created {name}")

    def save_workbook(self):
        folder = filedialog.askdirectory(title="Select folder to save workbook")
        if folder:
            save_workbook(folder, self.wb)
            messagebox.showinfo("Saved", f"Workbook saved to {folder}")

    def open_workbook(self):
        folder = filedialog.askdirectory(title="Select workbook folder to open")
        if folder:
            try:
                wb = load_workbook(folder)
                self.wb = wb
                self.wb.active = next(iter(self.wb.sheets))
                self.active_sheet = self.wb.get_active_sheet()
                coords = list(self.active_sheet.cells.keys())
                max_row = max((r for r, c in coords), default=0)
                max_col = max((c for r, c in coords), default=0)
                if max_row > 0:
                    self.rows = max(self.rows, max_row)
                if max_col > 0:
                    self.cols = max(self.cols, max_col)
                self._build_grid()
                self.recalc()
                messagebox.showinfo("Loaded", f"Workbook loaded from {folder}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load workbook: {e}")

    def export_html(self):
        out = filedialog.asksaveasfilename(title="Export sheet to HTML", defaultextension=".html",
                                           filetypes=[("HTML files", "*.html"), ("All files", "*.*")])
        if out:
            export_sheet_to_html(self.active_sheet, out, title=self.active_sheet.name)
            messagebox.showinfo("Exported", f"Sheet exported to {out}")

    def recalc(self):
        for coord in list(self.active_sheet.cells.keys()):
            self.active_sheet.recalculate_from(coord)
        for r in range(1, min(self.rows, 1000) + 1):
            vals = []
            for c in range(1, min(self.cols, 200) + 1):
                v = self.active_sheet.get_cell_value(r, c)
                vals.append("" if v is None else str(v))
            if str(r) in self.grid.get_children():
                # only update visible subset for performance
                self.grid.item(str(r), values=vals + tuple("" for _ in range(max(0, self.cols - len(vals)))))
        self.status_var.set(f"Recalculated — Grid: {self.rows}x{self.cols}")

    def set_grid_size(self):
        r = simpledialog.askinteger("Grid Rows", "Number of rows (1 - 10000):", initialvalue=self.rows, minvalue=1, maxvalue=10000)
        if r is None:
            return
        c = simpledialog.askinteger("Grid Columns", "Number of columns (1 - 1000):", initialvalue=self.cols, minvalue=1, maxvalue=1000)
        if c is None:
            return
        self.rows = r
        self.cols = c
        # warn about performance
        if self.rows * self.cols > 200000:
            if not messagebox.askyesno("Large grid", f"You requested {self.rows}x{self.cols} ({self.rows*self.cols} cells). This may be slow. Continue?"):
                return
        self._build_grid()
        self.status_var.set(f"Grid set to {self.rows} rows x {self.cols} cols")

    # -------------------------
    # Row / Column editing (same as before)
    # -------------------------
    def insert_row(self):
        r = simpledialog.askinteger("Insert Row", "Insert before which row number?", minvalue=1, maxvalue=self.rows+1)
        if r is None:
            return
        new_cells = {}
        for (row, col), val in self.active_sheet.cells.items():
            if row >= r:
                new_cells[(row + 1, col)] = val
            else:
                new_cells[(row, col)] = val
        self.active_sheet.cells = new_cells
        new_row_headers = {}
        for row, label in self.active_sheet.row_headers.items():
            if row >= r:
                new_row_headers[row + 1] = label
            else:
                new_row_headers[row] = label
        self.active_sheet.row_headers = new_row_headers
        self.active_sheet.values.clear()
        self.active_sheet.deps.clear()
        self.active_sheet.revdeps.clear()
        self.rows += 1
        self._build_grid()
        self.recalc()

    def delete_row(self):
        r = simpledialog.askinteger("Delete Row", "Delete which row number?", minvalue=1, maxvalue=self.rows)
        if r is None:
            return
        new_cells = {}
        for (row, col), val in self.active_sheet.cells.items():
            if row == r:
                continue
            if row > r:
                new_cells[(row - 1, col)] = val
            else:
                new_cells[(row, col)] = val
        self.active_sheet.cells = new_cells
        new_row_headers = {}
        for row, label in self.active_sheet.row_headers.items():
            if row == r:
                continue
            if row > r:
                new_row_headers[row - 1] = label
            else:
                new_row_headers[row] = label
        self.active_sheet.row_headers = new_row_headers
        self.active_sheet.values.clear()
        self.active_sheet.deps.clear()
        self.active_sheet.revdeps.clear()
        self.rows = max(1, self.rows - 1)
        self._build_grid()
        self.recalc()

    def insert_col(self):
        c = simpledialog.askinteger("Insert Column", "Insert before which column number? (1 = A)", minvalue=1, maxvalue=self.cols+1)
        if c is None:
            return
        new_cells = {}
        for (row, col), val in self.active_sheet.cells.items():
            if col >= c:
                new_cells[(row, col + 1)] = val
            else:
                new_cells[(row, col)] = val
        self.active_sheet.cells = new_cells
        new_col_headers = {}
        for col, label in self.active_sheet.col_headers.items():
            if col >= c:
                new_col_headers[col + 1] = label
            else:
                new_col_headers[col] = label
        self.active_sheet.col_headers = new_col_headers
        self.active_sheet.values.clear()
        self.active_sheet.deps.clear()
        self.active_sheet.revdeps.clear()
        self.cols += 1
        self._build_grid()
        self.recalc()

    def delete_col(self):
        c = simpledialog.askinteger("Delete Column", "Delete which column number? (1 = A)", minvalue=1, maxvalue=self.cols)
        if c is None:
            return
        new_cells = {}
        for (row, col), val in self.active_sheet.cells.items():
            if col == c:
                continue
            if col > c:
                new_cells[(row, col - 1)] = val
            else:
                new_cells[(row, col)] = val
        self.active_sheet.cells = new_cells
        new_col_headers = {}
        for col, label in self.active_sheet.col_headers.items():
            if col == c:
                continue
            if col > c:
                new_col_headers[col - 1] = label
            else:
                new_col_headers[col] = label
        self.active_sheet.col_headers = new_col_headers
        self.active_sheet.values.clear()
        self.active_sheet.deps.clear()
        self.active_sheet.revdeps.clear()
        self.cols = max(1, self.cols - 1)
        self._build_grid()
        self.recalc()

    def run(self):
        self.root.mainloop()

# -------------------------
# Entry point
# -------------------------
def main():
    app = SpreadsheetApp(rows=1000, cols=100)
    app.run()

if __name__ == "__main__":
    main()
