#!/usr/bin/env python3
# Eyedropper with JPG support, full OBJECT_DB, and TTS speaking the closest match.
# No pip. Uses only standard library + OS tools.

import sys
import os
import math
import platform
import tempfile
import subprocess
import time
import tkinter as tk
from tkinter import filedialog, messagebox

PLATFORM = platform.system().lower()
IS_WINDOWS = PLATFORM.startswith("win")
IS_MAC = PLATFORM.startswith("darwin")
IS_LINUX = PLATFORM.startswith("linux")

# ---------- TTS ----------
def speak(text):
    system = platform.system().lower()

    if system.startswith("win"):
        try:
            subprocess.run([
                "powershell",
                "-Command",
                f"Add-Type -AssemblyName System.Speech;"
                f"$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                f"$speak.Speak('{text}');"
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

    elif system.startswith("darwin"):
        try:
            subprocess.run(["say", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

    else:
        try:
            subprocess.run(["espeak", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass


# ---------- Color math ----------
def srgb_to_linear_channel(c):
    c = float(c) / 255.0
    if c <= 0.04045:
        return c / 12.92
    return ((c + 0.055) / 1.055) ** 2.4

def rgb_to_linear(rgb):
    return [srgb_to_linear_channel(v) for v in rgb]

def linear_rgb_to_xyz(lrgb):
    r, g, b = lrgb
    X = r * 0.4124564 + g * 0.3575761 + b * 0.1804375
    Y = r * 0.2126729 + g * 0.7151522 + b * 0.0721750
    Z = r * 0.0193339 + g * 0.1191920 + b * 0.9503041
    return (X, Y, Z)

def xyz_to_lab(x, y, z):
    Xn, Yn, Zn = 0.95047, 1.00000, 1.08883
    def f(t):
        delta = 6/29
        if t > delta**3:
            return t ** (1/3)
        return t / (3 * delta**2) + 4/29
    fx, fy, fz = f(x / Xn), f(y / Yn), f(z / Zn)
    L = 116 * fy - 16
    a = 500 * (fx - fy)
    b = 200 * (fy - fz)
    return (L, a, b)

def srgb_to_lab(rgb):
    lin = rgb_to_linear(rgb)
    x, y, z = linear_rgb_to_xyz(lin)
    return xyz_to_lab(x, y, z)

def delta_e_cie76(lab1, lab2):
    return math.sqrt((lab1[0]-lab2[0])**2 + (lab1[1]-lab2[1])**2 + (lab1[2]-lab2[2])**2)

def euclidean_rgb(rgb1, rgb2):
    return math.sqrt(sum((a-b)**2 for a,b in zip(rgb1, rgb2)))

def rgb_to_hex(rgb):
    return "#{:02X}{:02X}{:02X}".format(*rgb)


# ---------- FULL OBJECT_DB ----------
OBJECT_DB = [
    ("Red Apple", (200, 30, 30)),
    ("Green Leaf", (40, 150, 40)),
    ("Blue Jeans", (40, 60, 140)),
    ("Yellow Banana", (240, 220, 80)),
    ("White Paper", (245, 245, 245)),
    ("Black Tire", (20, 20, 20)),
    ("Orange Cone", (230, 120, 30)),
    ("Sky Blue", (135, 206, 235)),
    ("Brick Red", (150, 50, 40)),
    ("Wood Brown", (160, 110, 70)),
    ("Lemon Yellow", (255, 250, 50)),
    ("Olive Green", (128, 128, 0)),
    ("Navy Blue", (10, 30, 80)),
    ("Magenta", (200, 20, 140)),
    ("Cyan", (0, 180, 200)),
    ("Lavender", (200, 160, 220)),
    ("Peach", (255, 200, 160)),
    ("Maroon", (128, 0, 32)),
    ("Teal", (0, 128, 128)),
    ("Mint", (170, 255, 195)),
    ("Coral", (255, 127, 80)),
    ("Salmon", (250, 128, 114)),
    ("Chocolate", (123, 63, 0)),
    ("Beige", (245, 245, 220)),
    ("Slate Gray", (112, 128, 144)),
    ("Charcoal", (54, 69, 79)),
    ("Gold", (212, 175, 55)),
    ("Silver", (192, 192, 192)),
    ("Bronze", (176, 141, 87)),
    ("Rose Pink", (255, 102, 178)),
    ("Forest Green", (34, 139, 34)),
    ("Grass Green", (124, 252, 0)),
    ("Moss", (138, 154, 91)),
    ("Ivory", (255, 255, 240)),
    ("Cream", (255, 253, 208)),
    ("Turquoise", (64, 224, 208)),
    ("Indigo", (75, 0, 130)),
    ("Plum", (142, 69, 133)),
    ("Mustard", (205, 171, 45)),
    ("Rust", (183, 65, 14)),
    ("Copper", (184, 115, 51)),
    ("Pewter", (150, 150, 160)),
    ("Skyline Blue", (100, 149, 237)),
    ("Denim", (21, 96, 189)),
    ("Khaki", (195, 176, 145)),
    ("Tan", (210, 180, 140)),
    ("Chestnut", (139, 69, 19)),
    ("Sapphire", (15, 82, 186)),
    ("Emerald", (80, 200, 120)),
    ("Ruby", (155, 17, 30)),
    ("Grape Purple", (111, 45, 168)),
    ("Bubblegum", (255, 105, 180)),
    ("Lime", (191, 255, 0)),
    ("Chartreuse", (127, 255, 0)),
    ("Periwinkle", (204, 204, 255)),
    ("Cornflower", (100, 149, 237)),
    ("Cocoa", (210, 105, 30)),
    ("Walnut", (121, 85, 72)),
    ("Sand", (194, 178, 128)),
    ("Concrete Gray", (142, 142, 142)),
    ("Asphalt", (64, 64, 64)),
    ("Pear Green", (209, 226, 49)),
    ("Pine", (1, 121, 111)),
    ("Seafoam", (159, 226, 191)),
    ("Ocean Deep", (0, 105, 148)),
    ("Sunset Orange", (255, 94, 77)),
    ("Flamingo", (252, 142, 172)),
    ("Mulberry", (197, 75, 140)),
    ("Berry", (165, 42, 42)),
    ("Cinnamon", (210, 105, 30)),
    ("Honey", (240, 200, 120)),
    ("Butter", (255, 243, 140)),
    ("Pale Blue", (175, 238, 238)),
    ("Steel Blue", (70, 130, 180)),
    ("Gunmetal", (42, 52, 57)),
    ("Olive Drab", (107, 142, 35)),
    ("Army Green", (75, 83, 32)),
    ("Sage", (188, 184, 138)),
    ("Mint Cream", (245, 255, 250)),
    ("Eggplant", (97, 64, 81)),
    ("Brick Orange", (203, 65, 11)),
    ("Tomato Red", (255, 99, 71)),
    ("Cranberry", (220, 20, 60)),
    ("Poppy", (227, 66, 52)),
    ("Sunflower", (255, 218, 68)),
    ("Daffodil", (255, 255, 49)),
    ("Mango", (255, 130, 67)),
    ("Papaya", (255, 239, 213)),
    ("Avocado", (86, 130, 3)),
    ("Cactus", (88, 141, 78)),
    ("Fern", (79, 121, 66)),
    ("Bark Brown", (101, 67, 33)),
    ("Mahogany", (192, 64, 0)),
    ("Latte", (181, 101, 29)),
    ("Espresso", (80, 50, 20)),
    ("Slate", (112, 128, 144)),
    ("Pebble", (150, 150, 140)),
    ("Fog", (220, 220, 220)),
    ("Cloud", (240, 248, 255)),
    ("Polar White", (250, 250, 250)),
    ("Onyx", (15, 15, 15)),
    ("Graphite", (34, 34, 34)),
    ("Neon Green", (57, 255, 20)),
    ("Neon Pink", (255, 20, 147)),
    ("Neon Orange", (255, 102, 0)),
    ("Electric Blue", (125, 249, 255)),
    ("Iris", (90, 79, 207)),
    ("Lilac", (200, 162, 200)),
    ("Wheat", (245, 222, 179)),
    ("Oatmeal", (222, 207, 185)),
    ("Pale Rose", (255, 228, 225)),
    ("Blush", (222, 93, 131)),
    ("Mauve", (224, 176, 255)),
    ("Cobalt", (0, 71, 171)),
    ("Azure", (0, 127, 255)),
    ("Cerulean", (42, 82, 190)),
    ("Pewter Blue", (139, 168, 183)),
    ("Sienna", (160, 82, 45)),
    ("Burnt Umber", (138, 51, 36)),
    ("Ochre", (204, 119, 34)),
    ("Pale Mint", (189, 252, 201)),
    ("Sea Glass", (152, 255, 255)),
    ("Midnight", (10, 10, 40)),
    ("Polar Blue", (176, 224, 230)),
    ("Ivory Black", (41, 36, 33)),
    ("Pearl", (234, 224, 200)),
    ("Champagne", (247, 231, 206)),
    ("Copper Red", (203, 109, 81)),
    ("Antique Gold", (201, 173, 96)),
    ("Lava", (207, 16, 32)),
    ("Slate Moss", (120, 130, 100)),
]

DB = [(name, rgb, srgb_to_lab(rgb)) for name, rgb in OBJECT_DB]


# ---------- JPG conversion ----------
def safe_temp_png():
    fd, tmp = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    return tmp

def convert_image_to_png(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".png", ".gif"):
        return path

    dst = safe_temp_png()

    if IS_MAC:
        try:
            subprocess.check_call(["sips", "-s", "format", "png", path, "--out", dst],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return dst
        except Exception:
            pass

    if IS_LINUX:
        try:
            subprocess.check_call(["convert", path, dst],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return dst
        except Exception:
            pass
        try:
            subprocess.check_call(["ffmpeg", "-y", "-i", path, dst],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return dst
        except Exception:
            pass

    if IS_WINDOWS:
        try:
            # Use PowerShell to convert via System.Drawing
            ps = (
                "Add-Type -AssemblyName System.Drawing;"
                f"$img=[System.Drawing.Image]::FromFile('{path}');"
                f"$img.Save('{dst}',[System.Drawing.Imaging.ImageFormat]::Png);"
                "$img.Dispose();"
            )
            subprocess.check_call(["powershell", "-NoProfile", "-Command", ps],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return dst
        except Exception:
            pass

    # last attempt: try ImageMagick convert on any platform
    try:
        subprocess.check_call(["convert", path, dst], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return dst
    except Exception:
        pass

    # failed
    try:
        if os.path.exists(dst):
            os.unlink(dst)
    except Exception:
        pass
    return None


# ---------- Windows eyedropper ----------
if IS_WINDOWS:
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass
        user32.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
        gdi32.GetPixel.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
        gdi32.GetPixel.restype = wintypes.COLORREF
    except Exception:
        IS_WINDOWS = False

def win_get_cursor():
    pt = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y

def win_get_pixel(x, y):
    hdc = user32.GetDC(0)
    c = gdi32.GetPixel(hdc, x, y)
    user32.ReleaseDC(0, hdc)
    if c == -1:
        return None
    r = c & 0xFF
    g = (c >> 8) & 0xFF
    b = (c >> 16) & 0xFF
    return (r, g, b)


# ---------- GUI ----------
class App:
    def __init__(self, root):
        self.root = root
        root.title("Eyedropper + JPG + TTS (No pip)")
        root.geometry("760x600")

        tk.Label(root, text="Pick a color from screen (Windows) or load an image (PNG/JPG/GIF).").pack(pady=8)

        btns = tk.Frame(root)
        btns.pack()
        tk.Button(btns, text="Pick From Screen", command=self.pick_screen, width=20).pack(side="left", padx=8)
        tk.Button(btns, text="Load Image", command=self.load_image, width=20).pack(side="left", padx=8)

        disp = tk.Frame(root)
        disp.pack(pady=12, fill="x")

        self.swatch = tk.Canvas(disp, width=180, height=180, bg="#FFFFFF", bd=1, relief="solid")
        self.swatch.pack(side="left", padx=20)

        info = tk.Frame(disp)
        info.pack(side="left", padx=12, anchor="n")
        self.rgb_label = tk.Label(info, text="RGB: -", anchor="w", width=36)
        self.hex_label = tk.Label(info, text="Hex: -", anchor="w", width=36)
        self.lab_label = tk.Label(info, text="Lab: -", anchor="w", width=36)
        self.rgb_label.pack(pady=4)
        self.hex_label.pack(pady=4)
        self.lab_label.pack(pady=4)

        self.out = tk.Text(root, width=92, height=20)
        self.out.pack(pady=8)
        self.out.configure(state="normal")

        self.temp_png = None
        self.photoimage = None

    def append(self, text):
        self.out.configure(state="normal")
        self.out.insert(tk.END, text + "\n")
        self.out.see(tk.END)
        self.out.configure(state="disabled")

    def pick_screen(self):
        if IS_WINDOWS:
            self.append("Move cursor to target and click to sample. Waiting for click...")
            self.root.withdraw()
            VK = 0x01
            # wait for press
            while True:
                if user32.GetAsyncKeyState(VK) & 0x8000:
                    break
                time.sleep(0.01)
            # wait for release
            while user32.GetAsyncKeyState(VK) & 0x8000:
                time.sleep(0.01)
            x, y = win_get_cursor()
            color = win_get_pixel(x, y)
            self.root.deiconify()
            if color:
                self.process(color)
            else:
                messagebox.showerror("Error", "Could not read pixel color.")
            return

        messagebox.showinfo("Not supported", "Screen eyedropper is supported only on Windows in this no-pip script. Use Load Image instead.")

    def load_image(self):
        path = filedialog.askopenfilename(title="Open image (PNG/JPG/GIF recommended)")
        if not path:
            return

        png = convert_image_to_png(path)
        if not png:
            messagebox.showerror("Error", "Could not convert image to PNG for sampling. Install ImageMagick/ffmpeg or provide a PNG/GIF.")
            return

        self.temp_png = png
        try:
            img = tk.PhotoImage(file=png)
        except Exception as e:
            messagebox.showerror("Error", f"tkinter cannot open the converted PNG: {e}")
            try:
                if self.temp_png and os.path.exists(self.temp_png) and self.temp_png != path:
                    os.unlink(self.temp_png)
            except Exception:
                pass
            self.temp_png = None
            return

        self.photoimage = img
        self.show_image_fullscreen(img, png)

    def show_image_fullscreen(self, photo, path):
        w = tk.Toplevel(self.root)
        w.title("Click to sample - press Esc to cancel")
        w.attributes("-fullscreen", True)
        w.attributes("-topmost", True)

        screen_w = w.winfo_screenwidth()
        screen_h = w.winfo_screenheight()
        img_w = photo.width()
        img_h = photo.height()

        # center image (no scaling to avoid complexity)
        x_off = max(0, (screen_w - img_w) // 2)
        y_off = max(0, (screen_h - img_h) // 2)

        canvas = tk.Canvas(w, width=screen_w, height=screen_h, highlightthickness=0)
        canvas.pack()
        canvas.create_rectangle(0, 0, screen_w, screen_h, fill="black", outline="")
        canvas.create_image(x_off, y_off, anchor="nw", image=photo)
        canvas.image = photo

        def on_click(event):
            x = event.x - x_off
            y = event.y - y_off
            if x < 0 or y < 0 or x >= img_w or y >= img_h:
                return
            try:
                col = photo.get(int(x), int(y))
                if isinstance(col, tuple):
                    r, g, b = col
                else:
                    s = col.lstrip('#')
                    r = int(s[0:2], 16); g = int(s[2:4], 16); b = int(s[4:6], 16)
            except Exception:
                messagebox.showerror("Error", "Could not read pixel from image.")
                w.destroy()
                return
            w.destroy()
            # cleanup temp if created
            if self.temp_png and os.path.exists(self.temp_png) and self.temp_png != path:
                try:
                    os.unlink(self.temp_png)
                except Exception:
                    pass
                self.temp_png = None
            self.process((r, g, b))

        def on_key(event):
            if event.keysym == "Escape":
                w.destroy()
                if self.temp_png and os.path.exists(self.temp_png):
                    try:
                        os.unlink(self.temp_png)
                    except Exception:
                        pass
                    self.temp_png = None

        canvas.bind("<Button-1>", on_click)
        w.bind("<Key>", on_key)
        w.focus_force()

    def process(self, rgb):
        r, g, b = rgb
        hexc = rgb_to_hex((r, g, b))
        self.append(f"Sampled sRGB: {r}, {g}, {b}   Hex: {hexc}")
        try:
            self.swatch.configure(bg=hexc)
        except Exception:
            self.swatch.delete("all")
            self.swatch.create_rectangle(0, 0, 180, 180, fill=hexc, outline="")

        self.rgb_label.config(text=f"RGB: {r}, {g}, {b}")
        self.hex_label.config(text=f"Hex: {hexc}")
        lab = srgb_to_lab((r, g, b))
        self.lab_label.config(text=f"Lab: {lab[0]:.1f}, {lab[1]:.1f}, {lab[2]:.1f}")

        # compute matches
        lab_sample = lab
        results = []
        for name, db_rgb, db_lab in DB:
            d_rgb = euclidean_rgb((r, g, b), db_rgb)
            d_lab = delta_e_cie76(lab_sample, db_lab)
            results.append((name, db_rgb, d_rgb, d_lab))
        results.sort(key=lambda x: x[3])

        self.append("Top matches (sorted by ΔE perceptual distance):")
        for name, db_rgb, d_rgb, d_lab in results[:12]:
            self.append(f"  {name}  RGB={db_rgb}  ΔE={d_lab:.2f}  RGB-dist={d_rgb:.1f}")

        # speak the best match
        if results:
            best_name, best_rgb, best_drgb, best_dlab = results[0]
            speak_text = f"The closest match is {best_name}."
            # speak asynchronously to avoid blocking UI too long
            try:
                # spawn a short-lived subprocess for TTS so UI remains responsive
                subprocess.Popen([sys.executable, "-c",
                                  "import subprocess,platform\n"
                                  f"system=platform.system().lower()\n"
                                  f"text={repr(speak_text)}\n"
                                  "import subprocess\n"
                                  "import sys\n"
                                  "if system.startswith('win'):\n"
                                  "    subprocess.run(['powershell','-Command',\"Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak('\"+text+\"');\"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n"
                                  "elif system.startswith('darwin'):\n"
                                  "    subprocess.run(['say', text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n"
                                  "else:\n"
                                  "    subprocess.run(['espeak', text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n"
                                  ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                # fallback: call speak() directly (may block briefly)
                speak(speak_text)

        self.append("-" * 80)


def main():
    root = tk.Tk()
    app = App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
