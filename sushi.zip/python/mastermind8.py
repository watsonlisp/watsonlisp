#!/usr/bin/env python3
"""
Mastermind GUI using tkinter.
Save as mastermind_gui.py and run: python3 mastermind_gui.py
"""

import tkinter as tk
from tkinter import messagebox
import random
from collections import Counter

SLOTS = 4
COLORS = [
    ('R', 'Red', '#d32f2f'),
    ('G', 'Green', '#388e3c'),
    ('Y', 'Yellow', '#fbc02d'),
    ('B', 'Blue', '#1976d2'),
    ('M', 'Magenta', '#8e24aa'),
    ('C', 'Cyan', '#0097a7'),
]
MAX_GUESSES = 10
CELL = 40
PADDING = 10
LEFT_MARGIN = 10
ROW_HEIGHT = 60

class MastermindGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Mastermind")
        self.secret = self.generate_secret()
        self.guess_row = []
        self.history = []
        self.current_row = 0

        canvas_width = LEFT_MARGIN + SLOTS * 60 + 300
        canvas_height = 60 + MAX_GUESSES * ROW_HEIGHT + 140
        self.canvas = tk.Canvas(root, width=canvas_width, height=canvas_height, bg='#222', highlightthickness=0)
        self.canvas.pack()

        self.create_color_buttons()
        self.draw_board()

        self.status = tk.Label(root, text="Make a guess", fg='white', bg='#222', font=('Helvetica', 12))
        self.status.place(x=10, y=canvas_height - 60)
        self.restart_btn = tk.Button(root, text="Restart", command=self.restart)
        self.restart_btn.place(x=200, y=canvas_height - 64)

    def generate_secret(self):
        return [random.choice([c[0] for c in COLORS]) for _ in range(SLOTS)]

    def create_color_buttons(self):
        x = 10
        y = 10
        for code, name, hexc in COLORS:
            btn = tk.Button(self.root, bg=hexc, width=3, command=lambda c=code: self.add_color(c))
            btn.place(x=x, y=y)
            tk.Label(self.root, text=code, bg='#222', fg='white').place(x=x+5, y=y+30)
            x += 50

        submit = tk.Button(self.root, text="Submit", command=self.submit_guess)
        submit.place(x=x+20, y=10)
        clear = tk.Button(self.root, text="Clear", command=self.clear_guess)
        clear.place(x=x+80, y=10)

    def draw_board(self):
        self.canvas.delete("all")
        # draw rows for guesses
        for r in range(MAX_GUESSES):
            for c in range(SLOTS):
                x0 = LEFT_MARGIN + c*60
                y0 = 60 + r*ROW_HEIGHT
                self.canvas.create_oval(x0, y0, x0+40, y0+40, fill='#444', outline='#666', tags=f"cell_{r}_{c}")

        # draw history
        for r, (guess, (black, white)) in enumerate(self.history):
            for c, ch in enumerate(guess):
                color = next(hexc for code, name, hexc in COLORS if code == ch)
                x0 = LEFT_MARGIN + c*60
                y0 = 60 + r*ROW_HEIGHT
                self.canvas.create_oval(x0, y0, x0+40, y0+40, fill=color, outline='')
            # feedback pegs
            fx = LEFT_MARGIN + SLOTS*60 + 20
            fy = 60 + r*ROW_HEIGHT
            for i in range(black):
                self.canvas.create_oval(fx + i*12, fy, fx + i*12 + 10, fy + 10, fill='black')
            for i in range(white):
                self.canvas.create_oval(fx + (black+i)*12, fy, fx + (black+i)*12 + 10, fy + 10, fill='white')
            # show total matches (black + white) as text
            matches = black + white
            self.canvas.create_text(fx + 80, fy + 8, text=f"Matches: {matches}", fill='white', anchor='w', font=('Helvetica', 10, 'bold'))

        # draw current guess
        for c in range(SLOTS):
            x0 = LEFT_MARGIN + c*60
            y0 = 60 + self.current_row*ROW_HEIGHT
            if c < len(self.guess_row):
                ch = self.guess_row[c]
                color = next(hexc for code, name, hexc in COLORS if code == ch)
                self.canvas.create_oval(x0, y0, x0+40, y0+40, fill=color, outline='')
            else:
                self.canvas.create_oval(x0, y0, x0+40, y0+40, fill='#333', outline='#666')

    def add_color(self, code):
        # normalize to uppercase single-letter token
        token = code.upper()
        if len(self.guess_row) < SLOTS:
            self.guess_row.append(token)
            self.draw_board()
            self.status.config(text=f"Selected: {''.join(self.guess_row)}")

    def clear_guess(self):
        """Clear button now restarts the entire game."""
        self.restart()
        self.status.config(text="Game restarted")

    def submit_guess(self):
        if len(self.guess_row) != SLOTS:
            self.status.config(text=f"Fill {SLOTS} pegs before submitting")
            return

        # Debug output to console for inspection
        print("DEBUG submit_guess()")
        print("  secret:", self.secret)
        print("  guess :", self.guess_row)

        black, white = self.score(self.secret, self.guess_row)
        matches = black + white
        print("  result: black =", black, "white =", white, "matches =", matches)

        self.history.append((list(self.guess_row), (black, white)))
        self.draw_board()

        # immediate status feedback including total matches
        self.status.config(text=f"Black: {black}, White: {white}, Matches: {matches} — Guesses: {len(self.history)}/{MAX_GUESSES}")

        # schedule end-of-game handling so canvas updates first
        # WIN ONLY IF ALL ARE IN CORRECT POSITIONS (black == SLOTS)
        if black == SLOTS:
            self.root.after(50, lambda: self.end_game(won=True))
            return
        if len(self.history) >= MAX_GUESSES:
            self.root.after(50, lambda: self.end_game(won=False))
            return

        self.current_row += 1
        self.guess_row = []

    def end_game(self, won: bool):
        """
        Show result dialog and then restart the game so play continues.
        """
        if won:
            msg = f"All {SLOTS} pegs in correct positions — you win! Cracked the code in {len(self.history)} guesses!"
        else:
            msg = f"Out of guesses. Secret was: {' '.join(self.secret)}"
        messagebox.showinfo("Mastermind", msg)
        self.restart()

    def score(self, secret, guess):
        """
        Robust scoring that handles duplicates correctly.
        Returns (black, white).
        """
        black = sum(s == g for s, g in zip(secret, guess))
        sc = Counter(secret)
        gc = Counter(guess)
        common = sum(min(sc[k], gc[k]) for k in sc)
        white = common - black
        return black, white

    def restart(self):
        self.secret = self.generate_secret()
        self.guess_row = []
        self.history = []
        self.current_row = 0
        self.status.config(text="Make a guess")
        self.draw_board()

def main():
    root = tk.Tk()
    root.configure(bg='#222')
    app = MastermindGUI(root)
    root.geometry("600x700")
    root.resizable(False, False)
    root.mainloop()

if __name__ == "__main__":
    main()
