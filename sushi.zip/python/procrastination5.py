#!/usr/bin/env python3
"""
Procrastination Quote Generator with robust TTS (no pip).
- Normalizes text to reduce quoting/encoding issues.
- Uses temporary files so PowerShell/espeak/say read UTF-8 files (avoids inline quoting).
- Captures and prints subprocess stderr for debugging.
- Remembers the last entered subject and uses it as the default on the next run.
"""

import random
import platform
import subprocess
import shlex
import sys
import os
import tempfile
import unicodedata
from shutil import which
from pathlib import Path

# --- Persisted last-subject file (home directory) ---
LAST_SUBJECT_FILE = Path.home() / ".procrastination_last_subject.txt"

# --- Full templates list (200 entries) ---
TEMPLATES = [
    "The {task} can wait. Your comfort cannot.",
    "If the {task} were truly urgent, it would send a calendar invite.",
    "The {task} isn’t going anywhere. Unfortunately. But still.",
    "Why rush the {task}? Let it age like fine laziness.",
    "Some say action is power, but avoiding the {task} is also a power move.",
    "The {task} can chill. You can chill. Everyone chills.",
    "You could do the {task}, or you could honor the sacred tradition of Not Today.",
    "The {task} will still be there tomorrow. And the next day. And forever.",
    "Ignoring the {task} builds character. Probably.",
    "The {task} doesn’t deserve your energy at this hour.",
    "Let the {task} marinate in the universe a little longer.",
    "Bold of the {task} to assume it gets done today.",
    "The {task} is optional. Your peace is not.",
    "Procrastination level: skipping the {task} with confidence.",
    "The {task} can wait. Your snack cannot.",
    "If the {task} mattered, it would do itself.",
    "You’re not avoiding the {task}. You’re strategically delaying it.",
    "The {task} is temporary. Procrastination is eternal.",
    "You deserve a break from even thinking about the {task}.",
    "The {task} will be easier later. Probably. Maybe. Hopefully.",
    "You’re not procrastinating the {task}. You’re prioritizing vibes.",
    "The {task} can wait while you contemplate existence.",
    "Doing the {task} now would ruin your streak of not doing it.",
    "The {task} is patient. Let it continue being patient.",
    "You’re not behind on the {task}. You’re fashionably late.",
    "The {task} is a tomorrow problem. And tomorrow is flexible.",
    "You could do the {task}, but the couch has claimed you.",
    "The {task} can wait. Inspiration cannot be rushed.",
    "Avoiding the {task} is self‑care. Probably.",
    "The {task} doesn’t spark joy. Therefore, delay it.",
    "You’re not avoiding the {task}. You’re giving it space.",
    "The {task} can wait until your energy respawns.",
    "You’ll get to the {task} eventually. Maybe.",
    "The {task} is not the boss of you.",
    "You’re not procrastinating. You’re pre‑relaxing before the {task}.",
    "The {task} can wait. Your brain has logged out.",
    "Doing the {task} now would interrupt your momentum of doing nothing.",
    "The {task} is overrated anyway.",
    "You’re not avoiding the {task}. You’re building suspense.",
    "The {task} can wait. Your imagination cannot.",
    "You deserve a moment before tackling the {task}. A long moment.",
    "The {task} will be there when destiny calls. Destiny is currently on break.",
    "You’re not skipping the {task}. You’re letting it mature.",
    "The {task} can wait. Your comfort zone is thriving.",
    "You’re not procrastinating. You’re optimizing your laziness.",
    "The {task} is a suggestion, not a command.",
    "You’ll get to the {task} when the universe aligns.",
    "The {task} can wait. Your thoughts are buffering.",
    "You’re not avoiding the {task}. You’re practicing patience.",
    "The {task} is not urgent. Your relaxation is.",
    "You’re not procrastinating. You’re creatively rescheduling the {task}.",
    "The {task} can wait. Your soul needs a breather.",
    "You’re not skipping the {task}. You’re prioritizing serenity.",
    "The {task} is fine. You’re fine. Everything’s fine.",
    "You’re not avoiding the {task}. You’re embracing the art of delay.",
    "The {task} can wait. Your brain is in airplane mode.",
    "You’re not procrastinating. You’re time‑shifting the {task}.",
    "The {task} is a future-you problem. Future-you is tough.",
    "You’re not avoiding the {task}. You’re letting it cool down.",
    "The {task} can wait. Your energy is on low battery.",
    "You’re not procrastinating. You’re pacing yourself.",
    "The {task} is not going anywhere. Sadly.",
    "You’re not avoiding the {task}. You’re practicing strategic laziness.",
    "The {task} can wait. Your comfort is non‑negotiable.",
    "You’re not procrastinating. You’re giving the {task} time to reflect.",
    "The {task} is optional until further notice.",
    "You’re not avoiding the {task}. You’re embracing the slow life.",
    "The {task} can wait. Your brain is on vacation.",
    "You’re not procrastinating. You’re spiritually unavailable for the {task}.",
    "The {task} is not urgent. Your snacks are.",
    "You’re not avoiding the {task}. You’re letting your motivation respawn.",
    "The {task} can wait. Your inner sloth demands it.",
    "You’re not procrastinating. You’re prioritizing horizontal thinking.",
    "The {task} is persistent. So is your avoidance.",
    "You’re not avoiding the {task}. You’re building anticipation.",
    "The {task} can wait. Your chill is sacred.",
    "You’re not procrastinating. You’re exploring alternatives to productivity.",
    "The {task} is not essential right now. Your comfort is.",
    "You’re not avoiding the {task}. You’re practicing mindful inaction.",
    "The {task} can wait. Your vibe is immaculate.",
    "You’re not procrastinating. You’re conserving energy for something mythical.",
    "The {task} is fine without you for now.",
    "You’re not avoiding the {task}. You’re observing it from a safe distance.",
    "The {task} can wait. Your brain is rebooting.",
    "You’re not procrastinating. You’re letting the {task} simmer.",
    "The {task} is patient. You are more patient.",
    "You’re not avoiding the {task}. You’re practicing selective effort.",
    "The {task} can wait. Your relaxation is legendary.",
    "You’re not procrastinating. You’re embracing the slow‑motion lifestyle.",
    "The {task} is not pressing. Your comfort is pressing.",
    "You’re not avoiding the {task}. You’re prioritizing inner peace.",
    "The {task} can wait. Your motivation is currently unavailable.",
    "You’re not procrastinating. You’re giving destiny a chance to intervene.",
    "The {task} is optional until your spirit says otherwise.",
    "You’re not avoiding the {task}. You’re practicing advanced lounging.",
    "The {task} can wait. Your couch has claimed you.",
    "You’re not procrastinating. You’re honoring the sacred pause.",
    "The {task} is not urgent. Your comfort zone is thriving.",
    "You’re not avoiding the {task}. You’re letting the universe decide.",
    "The {task} can wait. Your chill is unstoppable.",
    "The {task} can wait; the world will survive without it for now.",
    "Consider the {task} a suggestion, not a life mandate.",
    "The {task} is on the to-do list of tomorrow's you.",
    "You’re not ignoring the {task}; you’re giving it a dramatic entrance.",
    "The {task} will appreciate the suspense.",
    "Let the {task} bask in the glow of postponement.",
    "The {task} is practicing patience; join it.",
    "Delay is an art and the {task} is your canvas.",
    "The {task} is a background character in today’s story.",
    "You’re not avoiding the {task}; you’re curating your downtime.",
    "The {task} can wait while you collect your thoughts.",
    "The {task} is on standby. So are you.",
    "You’re not procrastinating; you’re prioritizing mental real estate over the {task}.",
    "The {task} will still be there after your nap.",
    "The {task} is a future plot twist, not a present obligation.",
    "You’re not avoiding the {task}; you’re letting it age gracefully.",
    "The {task} can wait. Your playlist cannot.",
    "You’re not procrastinating; you’re letting the {task} find its moment.",
    "The {task} is a guest; don’t rush to entertain it.",
    "You’re not avoiding the {task}; you’re saving it for a cinematic reveal.",
    "The {task} can wait. Your comfort is hosting a summit.",
    "You’re not procrastinating; you’re giving the {task} a dramatic pause.",
    "The {task} is on a coffee break. So are you.",
    "You’re not avoiding the {task}; you’re practicing strategic delay tactics.",
    "The {task} can wait. Your focus is on something more important: rest.",
    "You’re not procrastinating; you’re letting the {task} marinate.",
    "The {task} is a rumor until you decide otherwise.",
    "You’re not avoiding the {task}; you’re prioritizing low-effort joy.",
    "The {task} can wait. Your mood is the real deadline.",
    "You’re not procrastinating; you’re conserving creative energy for later.",
    "The {task} is a suggestion box entry, not an order.",
    "You’re not avoiding the {task}; you’re letting it find its own urgency.",
    "The {task} can wait. Your peace of mind is non-negotiable.",
    "You’re not procrastinating; you’re giving the {task} time to prove itself.",
    "The {task} is on the slow train to completion.",
    "You’re not avoiding the {task}; you’re honoring your current bandwidth.",
    "The {task} can wait. Your brain is on a scenic route.",
    "You’re not procrastinating; you’re letting the {task} develop character.",
    "The {task} is a future anecdote, not a present chore.",
    "You’re not avoiding the {task}; you’re choosing comfort over urgency.",
    "The {task} can wait. Your energy is a limited resource.",
    "You’re not procrastinating; you’re scheduling the {task} for a better mood.",
    "The {task} is optional until proven otherwise.",
    "You’re not avoiding the {task}; you’re giving yourself permission to pause.",
    "The {task} can wait. Your mental health has higher priority.",
    "You’re not procrastinating; you’re letting the {task} cool off.",
    "The {task} is a minor subplot in today’s narrative.",
    "You’re not avoiding the {task}; you’re choosing to savor the moment.",
    "The {task} can wait. Your relaxation is a strategic investment.",
    "You’re not procrastinating; you’re letting the {task} find its timing.",
    "The {task} is on the bench. Let it watch the game.",
    "You’re not avoiding the {task}; you’re giving it a respectful delay.",
    "The {task} can wait. Your focus is on being human.",
    "You’re not procrastinating; you’re allowing the {task} to ripen.",
    "The {task} is a whisper, not a shout.",
    "You’re not avoiding the {task}; you’re choosing to be gentle with yourself.",
    "The {task} can wait. Your joy is the priority.",
    "You’re not procrastinating; you’re letting the {task} find its own urgency.",
    "The {task} is a soft request, not a demand.",
    "You’re not avoiding the {task}; you’re honoring your current limits.",
    "The {task} can wait. Your downtime is sacred.",
    "You’re not procrastinating; you’re giving the {task} a scenic delay.",
    "The {task} is a future chapter, not today’s headline.",
    "You’re not avoiding the {task}; you’re choosing rest over rush.",
    "The {task} can wait. Your calm is priceless.",
    "You’re not procrastinating; you’re letting the {task} breathe.",
    "The {task} is a background hum, not an emergency siren.",
    "You’re not avoiding the {task}; you’re prioritizing small wins.",
    "The {task} can wait. Your comfort is a valid plan.",
    "You’re not procrastinating; you’re letting the {task} find its moment to shine.",
    "The {task} is a gentle nudge, not a shove.",
    "You’re not avoiding the {task}; you’re choosing to recharge first.",
    "The {task} can wait. Your peace is doing important work.",
    "You’re not procrastinating; you’re giving the {task} a respectful timeout.",
    "The {task} is a future you problem; future you is resilient.",
    "You’re not avoiding the {task}; you’re curating your energy like a pro.",
    "The {task} can wait. Your present comfort is a worthy cause.",
    "You’re not procrastinating; you’re letting the {task} simmer until it’s worth it.",
    "The {task} is a soft echo; respond when you’re ready.",
    "You’re not avoiding the {task}; you’re choosing to be kind to yourself.",
    "The {task} can wait. Your vibe is doing the heavy lifting.",
    "You’re not procrastinating; you’re giving the {task} time to become meaningful.",
    "The {task} is a suggestion for later, not a command for now.",
    "You’re not avoiding the {task}; you’re protecting your mental bandwidth.",
    "The {task} can wait. Your rest is a strategic advantage.",
    "You’re not procrastinating; you’re letting the {task} find its proper timing.",
    "The {task} is a future anecdote; enjoy the present chapter.",
    "You’re not avoiding the {task}; you’re honoring the art of delay.",
    "The {task} can wait. Your chill is a public service.",
    "You’re not procrastinating; you’re giving the {task} a dignified pause."
]

# --- Utilities ---

def normalize_text(s: str) -> str:
    """Normalize unicode, replace smart punctuation with ASCII equivalents."""
    if not s:
        return s
    s = s.replace("’", "'").replace("‘", "'")
    s = s.replace("“", '"').replace("”", '"')
    s = s.replace("—", "-").replace("–", "-")
    s = unicodedata.normalize("NFKC", s)
    return s

def is_command_available(cmd: str) -> bool:
    return which(cmd) is not None

def _write_temp_utf8(text: str, suffix: str = ".txt") -> str:
    fd, path = tempfile.mkstemp(suffix=suffix)
    os.close(fd)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return path

# --- Safe platform TTS implementations ---

def speak_mac_safe(text: str):
    path = _write_temp_utf8(text)
    cmd = ["say", "-f", path]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if proc.returncode != 0:
            print("say stderr:", proc.stderr, file=sys.stderr)
    finally:
        try:
            os.remove(path)
        except Exception:
            pass

def save_mac_safe(text: str, filename: str):
    path = _write_temp_utf8(text)
    cmd = ["say", "-o", filename, "-f", path]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if proc.returncode != 0:
        print("say save stderr:", proc.stderr, file=sys.stderr)
    try:
        os.remove(path)
    except Exception:
        pass

def speak_windows_safe(text: str):
    path = _write_temp_utf8(text)
    # PowerShell reads the file with Get-Content -Raw -Encoding UTF8 and speaks it
    ps_script = (
        "Add-Type -AssemblyName System.Speech; "
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        f"$text = Get-Content -Raw -Encoding UTF8 {shlex.quote(path)}; "
        "$s.Speak($text);"
    )
    cmd = ["powershell", "-NoProfile", "-Command", ps_script]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if proc.returncode != 0:
            print("PowerShell stderr:", proc.stderr, file=sys.stderr)
    finally:
        try:
            os.remove(path)
        except Exception:
            pass

def save_windows_safe(text: str, filename: str):
    path = _write_temp_utf8(text)
    ps_script = (
        "Add-Type -AssemblyName System.Speech; "
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        f"$s.SetOutputToWaveFile({shlex.quote(filename)}); "
        f"$text = Get-Content -Raw -Encoding UTF8 {shlex.quote(path)}; "
        "$s.Speak($text); $s.Dispose();"
    )
    cmd = ["powershell", "-NoProfile", "-Command", ps_script]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if proc.returncode != 0:
        print("PowerShell save stderr:", proc.stderr, file=sys.stderr)
    try:
        os.remove(path)
    except Exception:
        pass

def speak_linux_safe(text: str):
    # Prefer espeak with file input; fallback to spd-say
    if is_command_available("espeak"):
        path = _write_temp_utf8(text)
        cmd = ["espeak", "-f", path]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
            if proc.returncode != 0:
                print("espeak stderr:", proc.stderr, file=sys.stderr)
        finally:
            try:
                os.remove(path)
            except Exception:
                pass
    elif is_command_available("spd-say"):
        cmd = ["spd-say", text]
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if proc.returncode != 0:
            print("spd-say stderr:", proc.stderr, file=sys.stderr)
    else:
        raise RuntimeError("No TTS utility found (install espeak or spd-say)")

def save_linux_safe(text: str, filename: str):
    if is_command_available("espeak"):
        path = _write_temp_utf8(text)
        cmd = ["espeak", "-w", filename, "-f", path]
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if proc.returncode != 0:
            print("espeak save stderr:", proc.stderr, file=sys.stderr)
        try:
            os.remove(path)
        except Exception:
            pass
    else:
        raise RuntimeError("espeak not found; cannot save audio on this Linux system.")

# --- Dispatcher ---

def speak(text: str):
    text = normalize_text(text)
    system = platform.system()
    if system == "Darwin":
        speak_mac_safe(text)
    elif system == "Windows":
        speak_windows_safe(text)
    elif system == "Linux":
        speak_linux_safe(text)
    else:
        raise RuntimeError(f"Unsupported OS: {system}")

def save(text: str, filename: str):
    text = normalize_text(text)
    system = platform.system()
    os.makedirs(os.path.dirname(os.path.abspath(filename)) or ".", exist_ok=True)
    if system == "Darwin":
        save_mac_safe(text, filename)
    elif system == "Windows":
        save_windows_safe(text, filename)
    elif system == "Linux":
        save_linux_safe(text, filename)
    else:
        raise RuntimeError(f"Unsupported OS: {system}")

# --- Quote generation ---

def get_quote(task: str) -> str:
    task = (task or "").strip()
    if not task:
        task = "that thing"
    template = random.choice(TEMPLATES)
    return template.format(task=task)

# --- Last-subject persistence helpers ---

def load_last_subject() -> str | None:
    try:
        if LAST_SUBJECT_FILE.exists():
            return LAST_SUBJECT_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        pass
    return None

def save_last_subject(subject: str):
    try:
        LAST_SUBJECT_FILE.write_text(subject, encoding="utf-8")
    except Exception:
        pass

# --- CLI ---

def main():
    last_subject = load_last_subject()
    print("=== Procrastination Quote Generator (TTS, safe) ===")
    print("Platform:", platform.system())
    if last_subject:
        print(f"Last subject loaded: {last_subject}")

    while True:
        if last_subject:
            prompt = f"\nEnter a task or subject (or 'quit') [{last_subject}]: "
        else:
            prompt = "\nEnter a task or subject (or 'quit'): "

        user_input = input(prompt)
        # If user presses Enter with no input, use last_subject as default
        if not user_input.strip() and last_subject:
            subject = last_subject
        else:
            subject = user_input.strip()

        if subject.lower() in ("quit", "exit", "q"):
            print("Alright, go procrastinate responsibly.")
            break

        # Update and persist last_subject when user provides a non-empty subject
        if subject:
            last_subject = subject
            save_last_subject(last_subject)

        quote = get_quote(subject)
        print("\n" + quote + "\n")

        try:
            speak(quote)
        except Exception as e:
            print("TTS playback failed:", e, file=sys.stderr)
            save_choice = input("Save audio to file instead? (y/N): ").strip().lower()
            if save_choice == "y":
                default = os.path.join(tempfile.gettempdir(), "procrastination.wav")
                fname = input(f"Filename (default {default}): ").strip() or default
                try:
                    save(quote, fname)
                    print("Saved to:", fname)
                except Exception as se:
                    print("Save failed:", se, file=sys.stderr)

if __name__ == "__main__":
    main()
