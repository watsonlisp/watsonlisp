#!/usr/bin/env python3
"""
Interactive Random First + Middle + Last Name Generator with system TTS enabled by default.

Run without flags to use the interactive loop (type names or press Enter to randomize;
after each result you'll be asked to generate again or quit).

Run with flags to produce a single non-interactive result (useful for scripts).
Speech is enabled by default; pass --no-speak to disable speaking.
"""

import argparse
import random
import shutil
import subprocess
import sys
import traceback

FIRST_NAMES = [
    "Aaron","Abigail","Adam","Aiden","Alex","Alexa","Alice","Alyssa","Amelia","Andrew",
    "Anna","Anthony","Ariana","Asher","Ava","Benjamin","Blake","Brandon","Brenda","Brian",
    "Brianna","Caleb","Cameron","Caroline","Charles","Charlotte","Chloe","Christian","Christopher","Claire",
    "Daniel","David","Dylan","Eleanor","Elizabeth","Ella","Emily","Emma","Ethan","Evelyn",
    "Evan","Faith","Gabriel","Gavin","Grace","Hailey","Hannah","Harper","Henry","Hudson",
    "Isabella","Isaac","Jack","Jackson","Jacob","James","Jasmine","Jason","Jayden","John",
    "Jonathan","Jordan","Joseph","Joshua","Julia","Julian","Kaitlyn","Kayla","Kevin","Liam",
    "Lillian","Logan","Lucas","Lucy","Luke","Mackenzie","Madeline","Madison","Mason","Matthew",
    "Maya","Megan","Michael","Mila","Nathan","Nathaniel","Nicholas","Noah","Nora","Oliver",
    "Owen","Parker","Patrick","Penelope","Rachel","Ryan","Samantha","Samuel","Sarah","Savannah",
    "Scarlett","Sebastian","Sophia","Sophie","Thomas","Tyler","Victoria","William","Wyatt","Zoe"
]

MIDDLE_NAMES = [
    "Aaron","Abel","Adrian","Alan","Albert","Alex","Alexander","Alice","Allan","Amelia",
    "Andrew","Anne","Anthony","Arthur","Aubrey","Austin","Barbara","Beatrice","Benjamin","Blake",
    "Brandon","Brian","Brittany","Bruce","Caleb","Cameron","Carl","Caroline","Carter","Charles",
    "Charlotte","Chase","Chloe","Christian","Christopher","Claire","Cole","Colin","Connor","Daniel",
    "David","Dean","Derek","Diana","Dominic","Drew","Dylan","Edward","Eleanor","Eli",
    "Elijah","Elizabeth","Ella","Elliot","Emily","Emma","Eric","Ethan","Evelyn","Evan",
    "Faith","Felix","Finn","Gabriel","Gavin","George","Grace","Grant","Gregory","Hannah",
    "Harper","Harrison","Henry","Hudson","Ian","Isaac","Isabel","Isabella","Jack","Jackson",
    "Jacob","James","Jared","Jason","Jasper","Jay","Jeffrey","John","Jonathan","Joseph",
    "Joshua","Julia","Julian","Justin","Katherine","Kayla","Kenneth","Kevin","Kyle","Laura",
    "Lauren","Leah","Leon","Liam","Lillian","Logan","Lucas","Lucy","Luke","Madeline"
]

LAST_NAMES = [
    "Adams","Allen","Anderson","Bailey","Baker","Barnes","Bell","Bennett","Brooks","Brown",
    "Butler","Campbell","Carter","Clark","Cole","Collins","Cook","Cooper","Cox","Cruz",
    "Davis","Diaz","Edwards","Evans","Fisher","Flores","Foster","Garcia","Gonzalez","Graham",
    "Gray","Green","Griffin","Hall","Harris","Hayes","Henderson","Hernandez","Hill","Howard",
    "Hughes","Jackson","James","Jenkins","Johnson","Jones","Kelly","King","Lee","Lewis",
    "Long","Lopez","Martin","Martinez","Miller","Mitchell","Moore","Morgan","Morris","Murphy",
    "Myers","Nelson","Nguyen","Ortiz","Parker","Patterson","Perez","Perry","Peterson","Phillips",
    "Powell","Price","Ramirez","Reed","Reyes","Richardson","Rivera","Roberts","Robinson","Rodriguez",
    "Rogers","Ross","Russell","Sanchez","Sanders","Scott","Simmons","Smith","Stewart","Taylor",
    "Thomas","Thompson","Torres","Turner","Walker","Ward","Watson","White","Williams","Wilson",
    "Wood","Wright","Young","Zimmerman","Vasquez","Gomez","Mendoza","Ruiz","Silva","Murray"
]

def pick_name(pool, explicit_value, random_flag):
    """Return explicit_value, a random pick if random_flag, or None if undecided."""
    if explicit_value:
        return explicit_value
    if random_flag:
        return random.choice(pool)
    return None

def interactive_prompt(field_name, pool):
    """Prompt user to type a name or press Enter to randomize. Returns chosen name."""
    prompt = f"Type a {field_name} (or press Enter to randomize): "
    try:
        val = input(prompt).strip()
    except EOFError:
        return random.choice(pool)
    if val:
        return val
    return random.choice(pool)

def is_interactive_terminal():
    """Return True if running in an interactive terminal (not IDLE or redirected)."""
    try:
        return sys.stdin.isatty()
    except Exception:
        return False

def detect_system_tts():
    """
    Return a tuple (method, command)
    method: 'pyttsx3', 'windows', 'pwsh', 'mac', 'linux', or None
    command: command path or name
    """
    # Prefer pyttsx3 if already installed (do not install automatically)
    try:
        import pyttsx3  # type: ignore
        return "pyttsx3", None
    except Exception:
        pass

    if sys.platform.startswith("win"):
        pwsh_path = shutil.which("powershell.exe")
        if pwsh_path:
            return "windows", pwsh_path
        pwsh_core = shutil.which("pwsh")
        if pwsh_core:
            return "pwsh", pwsh_core
        return None, None

    if sys.platform.startswith("darwin"):
        return "mac", "say"

    for cmd in ("espeak", "spd-say", "festival"):
        if shutil.which(cmd):
            return "linux", cmd
    return None, None

def speak_with_pyttsx3(text):
    try:
        import pyttsx3
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
        return True
    except Exception:
        return False

def speak_windows_powershell(text, powershell_path):
    """Use Windows PowerShell (powershell.exe) and System.Speech."""
    safe = text.replace("'", "''")
    ps_command = (
        "Add-Type -AssemblyName System.Speech;"
        f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe}')"
    )
    cmd = [powershell_path, "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command", ps_command]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True)
        return proc.returncode == 0
    except Exception:
        return False

def speak_pwsh_core(text, pwsh_path):
    """Attempt to use PowerShell Core (pwsh). System.Speech may not be available there."""
    safe = text.replace("'", "''")
    ps_command = (
        "Add-Type -AssemblyName System.Speech;"
        f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe}')"
    )
    cmd = [pwsh_path, "-NoProfile", "-Command", ps_command]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True)
        return proc.returncode == 0
    except Exception:
        return False

def speak_mac_say(text):
    try:
        proc = subprocess.run(["say", text], capture_output=True, text=True)
        return proc.returncode == 0
    except Exception:
        return False

def speak_linux_cmd(cmd, text):
    try:
        if cmd == "espeak":
            proc = subprocess.run(["espeak", text], capture_output=True, text=True)
            return proc.returncode == 0
        if cmd == "spd-say":
            proc = subprocess.run(["spd-say", text], capture_output=True, text=True)
            return proc.returncode == 0
        if cmd == "festival":
            p = subprocess.Popen(["festival", "--tts"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            p.communicate(input=text.encode("utf-8"))
            return p.returncode == 0
    except Exception:
        return False
    return False

def winsound_beep_fallback():
    """Play a short system beep on Windows as a fallback so user gets audible feedback."""
    if not sys.platform.startswith("win"):
        return False
    try:
        import winsound
        winsound.MessageBeep(winsound.MB_OK)
        return True
    except Exception:
        return False

def speak_text(text):
    method, cmd = detect_system_tts()

    # Try pyttsx3 first if available
    if method == "pyttsx3":
        if speak_with_pyttsx3(text):
            return True

    # Windows: prefer powershell.exe
    if method == "windows" and cmd:
        if speak_windows_powershell(text, cmd):
            return True
        winsound_beep_fallback()
        return False

    # PowerShell Core (pwsh) fallback
    if method == "pwsh" and cmd:
        if speak_pwsh_core(text, cmd):
            return True
        if speak_with_pyttsx3(text):
            return True
        winsound_beep_fallback()
        return False

    # macOS
    if method == "mac":
        return speak_mac_say(text)

    # Linux
    if method == "linux" and cmd:
        return speak_linux_cmd(cmd, text)

    winsound_beep_fallback()
    return False

def generate_one(args):
    """Generate a single (first, middle, last) tuple based on args or interactive prompts."""
    first = pick_name(FIRST_NAMES, args.first, args.random_first)
    middle = pick_name(MIDDLE_NAMES, args.middle, args.random_middle)
    last = pick_name(LAST_NAMES, args.last, args.random_last)

    if first is None:
        first = interactive_prompt("first name", FIRST_NAMES)
    if middle is None:
        middle = interactive_prompt("middle name", MIDDLE_NAMES)
    if last is None:
        last = interactive_prompt("last name", LAST_NAMES)

    return first, middle, last

def interactive_loop(args):
    """Run the interactive repeat/quit loop."""
    while True:
        first, middle, last = generate_one(args)
        full = f"{first} {middle} {last}"
        print(f"\nResult: {full}\n")

        # Speak by default unless user passed --no-speak
        if args.speak:
            ok = speak_text(full)
            if not ok:
                print("Warning: speaking failed. Run from Command Prompt or Windows PowerShell (not IDLE).")

        try:
            choice = input("Press Enter to generate again, or type 'q' then Enter to quit: ").strip().lower()
        except EOFError:
            print("\nNo input available. Exiting.")
            return
        if choice == "q":
            print("Goodbye.")
            return

def main(argv=None):
    parser = argparse.ArgumentParser(description="Random first + middle + last name generator with repeat/quit and TTS")
    parser.add_argument("--first", type=str, help="Explicit first name to use")
    parser.add_argument("--middle", type=str, help="Explicit middle name to use")
    parser.add_argument("--last", type=str, help="Explicit last name to use")
    parser.add_argument("--random-first", action="store_true", help="Force random first name")
    parser.add_argument("--random-middle", action="store_true", help="Force random middle name")
    parser.add_argument("--random-last", action="store_true", help="Force random last name")
    parser.add_argument("--count", type=int, default=1, help="How many names to generate in non-interactive mode")
    parser.add_argument("--seed", type=int, help="Random seed for reproducible output")
    # speech enabled by default; provide --no-speak to disable
    parser.add_argument("--no-speak", action="store_true", help="Disable speaking the generated name")
    args = parser.parse_args(argv)

    # default: speak unless --no-speak provided
    args.speak = not args.no_speak

    if args.seed is not None:
        random.seed(args.seed)

    non_interactive_flags = any([
        args.first, args.middle, args.last,
        args.random_first, args.random_middle, args.random_last,
        args.count != 1, args.seed is not None
    ])

    if non_interactive_flags:
        for i in range(1, max(1, args.count) + 1):
            first = pick_name(FIRST_NAMES, args.first, args.random_first) or random.choice(FIRST_NAMES)
            middle = pick_name(MIDDLE_NAMES, args.middle, args.random_middle) or random.choice(MIDDLE_NAMES)
            last = pick_name(LAST_NAMES, args.last, args.random_last) or random.choice(LAST_NAMES)
            full = f"{first} {middle} {last}"
            print(f"{i}. {full}")
            if args.speak:
                ok = speak_text(full)
                if not ok:
                    print("Warning: speaking failed. Run from Command Prompt or Windows PowerShell.")
        return

    interactive_loop(args)

# Helper functions used earlier but defined after main logic for clarity
def pick_name(pool, explicit_value, random_flag):
    if explicit_value:
        return explicit_value
    if random_flag:
        return random.choice(pool)
    return None

if __name__ == "__main__":
    main()
