#!/usr/bin/env python3
"""
band_name_generator_tts_nopip.py
Interactive band-name generator with system TTS only (no pip).
Default count is 1. Run: python band_name_generator_tts_nopip.py
Controls while running:
  Enter  - generate more names
  s      - change strategy
  c      - change count
  t      - toggle text-to-speech on/off
  q      - quit
"""

import random
import platform
import subprocess
import shutil
import sys

# --- Expanded word lists (trimmed for readability; expand as desired) ---
ADJECTIVES = [
    "Abyssal","Acidic","Amber","Ancient","Arcane","Astral","Atomic","Autumnal",
    "Awakened","Barren","Bitter","Blazing","Bleak","Blurred","Brassy","Brisk",
    "Broken","Bronze","Calm","Celestial","Ceramic","Charmed","Chrome","Cinder",
    "Clouded","Coastal","Cold","Coral","Crimson","Crystalline","Cursed","Daring",
    "Deafening","Deep","Delicate","Deserted","Digital","Divine","Drifting","Dusky",
    "Electric","Ember","Empty","Ethereal","Faded","Fallen","Feral","Fiery",
    "Flickering","Floral","Frozen","Gilded","Glacial","Golden","Grimy","Hallowed",
    "Haunted","Hollow","Icy","Iron","Jagged","Luminous","Lurid","Lush","Lunar",
    "Lyrical","Mellow","Midnight","Misty","Molten","Moonlit","Mournful","Neon",
    "Nocturnal","Obsidian","Opaque","Pale","Paper","Phantom","Plastic","Polished",
    "Primal","Quiet","Radiant","Ragged","Rusty","Sacred","Sable","Savage","Scarlet",
    "Serene","Shattered","Silent","Silver","Sinewy","Solar","Somber","Sonic",
    "Starlit","Static","Steely","Stolen","Subtle","Sunken","Tangled","Tarnished",
    "Tempest","Tender","Thundering","Velvet","Verdant","Vicious","Vivid","Wandering",
    "Weathered","Whispering","Wild","Worn"
]

NOUNS = [
    "Abyss","Alley","Anchor","Anthem","Arcade","Armada","Arrow","Ashes","Atlas",
    "Aurora","Avenue","Axis","Bazaar","Beacon","Beasts","Bell","Bison","Blackout",
    "Bloom","Boulevard","Bramble","Brass","Bridge","Brook","Bureau","Cabin","Canvas",
    "Caravan","Cathedral","Chain","Chamber","Chapel","Circuit","Citadel","City",
    "Cliffs","Clockwork","Cloak","Coast","Colony","Comet","Compass","Concrete",
    "Constellation","Cove","Cradle","Crater","Crest","Crossroads","Crown","Crypt",
    "Current","Dagger","Dawn","Delta","Den","Desert","Device","Diary","Dock",
    "Domain","Doorway","Drift","Echo","Eclipse","Edge","Empire","Engine","Epoch",
    "Equinox","Estate","Ether","Factory","Falcon","Fathom","Feast","Field","Flame",
    "Fleet","Flood","Fortress","Fountain","Frame","Frontier","Furnace","Garden",
    "Gateway","Ghosts","Gilding","Glacier","Glade","Grotto","Harbor","Haze","Helm",
    "Horizon","House","Hunt","Icon","Idol","Isle","Junction","Keep","Key","Kingdom",
    "Lantern","Ledge","Legion","Library","Lighthouse","Lineage","Locket","Machine",
    "Manor","Market","Mask","Meadow","Meridian","Metro","Mirage","Mission","Mist",
    "Monolith","Monument","Moon","Mosaic","Motor","Mountain","Muse","Myth","Nebula",
    "Nest","Night","Node","Nomads","North","Oasis","Observatory","Ocean","Odyssey",
    "Oracle","Orchard","Outpost","Palace","Palisade","Passage","Path","Pavilion",
    "Peak","Penumbra","Perimeter","Phantom","Pier","Pillars","Pilots","Pinnacle",
    "Pit","Plaza","Prism","Pulse","Quarry","Quay","Radiance","Rail","Rampart","Range",
    "Rapture","Reef","Relay","Reliquary","Reservoir","Rift","River","Road","Rogue",
    "Ruins","Sanctuary","Satellite","Scar","Scarab","School","Sea","Season","Sentinel",
    "Serpent","Shrine","Signal","Silk","Skyline","Slab","Solace","Solstice","Sound",
    "Spire","Station","Steam","Stone","Storm","Strand","Stream","Studio","Suburb",
    "Summit","Sun","Surface","Swarm","Tapestry","Temple","Terminal","Terrace",
    "Thicket","Tide","Tower","Trail","Transit","Trench","Tribunal","Trove","Tunnel",
    "Twilight","Typhoon","Union","Vale","Vault","Vessel","Vortex","Wall","Ward",
    "Wharf","Wilderness","Window","Wing","Workshop","Yard","Zenith","Zephyr"
]

VERBS = [
    "Abandoning","Accelerating","Awakening","Baring","Beckoning","Blazing","Blending",
    "Blooming","Breaking","Breathing","Burning","Calling","Chasing","Climbing",
    "Collapsing","Crossing","Crumbling","Dancing","Daring","Dazzling","Drowning",
    "Drifting","Echoing","Embracing","Enchanting","Falling","Fading","Forging",
    "Freezing","Gliding","Glowing","Haunting","Hiding","Howling","Hunting","Igniting",
    "Illuminating","Imagining","Invading","Journeying","Knocking","Lamenting",
    "Lifting","Lingering","Longing","Losing","Marching","Melting","Mending","Merging",
    "Missing","Moving","Murmuring","Navigating","Nesting","Nurturing","Opening",
    "Orbiting","Painting","Passing","Pioneering","Plunging","Pulsing","Quivering",
    "Racing","Reaching","Reckoning","Reeling","Remembering","Resurrecting","Rising",
    "Roaming","Rushing","Sailing","Scattering","Searching","Shattering","Shimmering",
    "Shining","Shivering","Singing","Sinking","Skimming","Slipping","Soaring","Sowing",
    "Sparkling","Spinning","Splintering","Stalking","Standing","Stealing","Stirring",
    "Striking","Striving","Summoning","Surfacing","Sweeping","Swelling","Tearing",
    "Thundering","Ticking","Treading","Trembling","Unfolding","Vanishing","Veiling",
    "Venturing","Vibrating","Wandering","Waking","Whispering","Withering","Wrecking",
    "Yearning"
]

THEME_WORDS = [
    "Abyss","Afterglow","Alchemy","Alloy","Amber","Anchor","Antares","Arcadia",
    "Arcology","Armada","Artifact","Ash","Atlas","Aurora","Babylon","Beacon",
    "Binary","Blackout","Bloom","Borealis","Brimstone","Cadence","Canyon","Carbon",
    "Cascade","Cathedral","Celestia","Cipher","Circuit","Citadel","Clockwork",
    "Cobalt","Comet","Conduit","Cosmos","Crux","Dagger","Dawn","Decibel","Delta",
    "Drift","Echo","Eclipse","Eden","Ember","Equinox","Ether","Exile","Fable","Fallout",
    "Fathom","Flux","Forge","Fracture","Galaxy","Garrison","Gloom","Glyph","Gravity",
    "Halo","Harbor","Haze","Helix","Horizon","Husk","Icon","Illusion","Inferno","Ink",
    "Iron","Isle","Jade","Junction","Karma","Keystone","Labyrinth","Lament","Lattice",
    "Leviathan","Liminal","Locket","Lumen","Lullaby","Machine","Magma","Manor","Marble",
    "Meridian","Mirage","Monsoon","Monolith","Mosaic","Muse","Mythos","Nebula","Nexus",
    "Nightfall","Nimbus","Nomad","Nova","Obelisk","Obsidian","Odyssey","Oracle","Orbit",
    "Orchard","Omen","Opal","Outlaw","Paladin","Paradox","Passage","Pavilion","Pendulum",
    "Perigee","Phantom","Pillar","Pinnacle","Pixel","Plague","Polaris","Portal","Prism",
    "Pulse","Quasar","Quill","Radiant","Rapture","Relic","Rift","Ritual","River","Rogue",
    "Ruin","Sable","Sanctuary","Satellite","Scepter","Seance","Season","Sentinel","Seraph",
    "Serpent","Shrine","Signal","Silhouette","Siren","Skyline","Solace","Solstice","Sonic",
    "Spire","Spiral","Station","Static","Stone","Storm","Strand","Stream","Summit",
    "Sundown","Sunspot","Surface","Talisman","Tempest","Threshold","Tide","Titan",
    "Tomb","Torrent","Tower","Transit","Trident","Trove","Twilight","Typhoon","Umbra",
    "Union","Vale","Vault","Vector","Veil","Vessel","Vortex","Warden","Wasteland",
    "Wayfarer","Wharf","Wisp","Zenith","Zephyr"
]

TEMPLATES = [
    "{adj} {noun}",
    "{noun} of {theme}",
    "{verb} the {noun}",
    "The {adj} {noun}",
    "{theme} & {noun}",
    "{noun}-{noun}"
]

# --- System TTS helpers (no external packages) ---
def _which(cmd):
    return shutil.which(cmd) is not None

def speak_system(text):
    """Speak text using available system TTS. Returns True if spoken, False otherwise."""
    system = platform.system()
    # macOS: 'say'
    if system == "Darwin" and _which("say"):
        try:
            subprocess.run(["say", text], check=False)
            return True
        except Exception:
            return False
    # Windows: use PowerShell System.Speech (built-in)
    if system == "Windows":
        escaped = text.replace("'", "''")
        ps_cmd = (
            "Add-Type -AssemblyName System.Speech;"
            f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{escaped}');"
        )
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return True
        except Exception:
            return False
    # Linux/other: try spd-say or espeak if installed
    if _which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=False)
            return True
        except Exception:
            return False
    if _which("espeak"):
        try:
            subprocess.run(["espeak", text], check=False)
            return True
        except Exception:
            return False
    return False

# --- Generator functions ---
def stylize(name):
    choice = random.random()
    if choice < 0.12:
        return name.upper()
    if choice < 0.25:
        return ''.join(c.upper() if i % 2 == 0 else c.lower() for i, c in enumerate(name))
    return name.title()

def mashup(a, b):
    if not a or not b:
        return (a + b).capitalize()
    cut_a = max(1, len(a) // 2)
    cut_b = max(1, len(b) // 2)
    return (a[:cut_a] + b[cut_b:]).capitalize()

def generate_one(strategy="mixed"):
    if strategy == "adj_noun":
        name = random.choice(ADJECTIVES) + " " + random.choice(NOUNS)
    elif strategy == "mashup":
        a = random.choice(THEME_WORDS + ADJECTIVES)
        b = random.choice(NOUNS + THEME_WORDS)
        name = mashup(a, b)
    elif strategy == "single":
        name = random.choice(THEME_WORDS + NOUNS + ADJECTIVES)
    elif strategy == "template":
        tpl = random.choice(TEMPLATES)
        name = tpl.format(
            adj=random.choice(ADJECTIVES),
            noun=random.choice(NOUNS),
            verb=random.choice(VERBS),
            theme=random.choice(THEME_WORDS)
        )
    else:  # mixed
        strat = random.choice(["adj_noun", "mashup", "single", "template"])
        name = generate_one(strat)
    if random.random() < 0.12:
        name += random.choice([".", "!", "…", ""])
    if random.random() < 0.08:
        name += " " + str(random.randint(2, 99))
    return stylize(name)

def generate(count=1, strategy="mixed"):
    return [generate_one(strategy) for _ in range(count)]

# --- Interactive loop with TTS toggle ---
def interactive_loop():
    strategy = "mixed"
    count = 1  # default count set to 1
    tts_on = True
    # Check if any system TTS is available; if not, default tts_on False
    if not any((_which("say"), _which("spd-say"), _which("espeak"), platform.system() == "Windows")):
        tts_on = False
    print("Band Name Generator — type 'q' to quit, 's' to change strategy, 'c' to change count, 't' to toggle TTS.")
    if not tts_on:
        print("Note: No system TTS detected. On macOS 'say' is used; on Windows PowerShell speech is used; on Linux 'spd-say' or 'espeak' may be used.")
    try:
        while True:
            names = generate(count, strategy)
            for i, n in enumerate(names, start=1):
                line = f"{i}. {n}"
                print(line)
                if tts_on:
                    ok = speak_system(n)
                    if not ok:
                        print("[TTS unavailable — speech disabled]")
                        tts_on = False
            cmd = input("\nPress Enter to generate more, 's' to change strategy, 'c' to change count, 't' to toggle TTS, 'q' to quit: ").strip().lower()
            if cmd == "q":
                print("Goodbye.")
                break
            if cmd == "s":
                print("Strategies: mixed, adj_noun, mashup, single, template")
                new = input(f"Current strategy is '{strategy}'. Enter new strategy (or Enter to keep): ").strip().lower()
                if new in ("mixed","adj_noun","mashup","single","template"):
                    strategy = new
                    print(f"Strategy set to '{strategy}'.")
                elif new == "":
                    pass
                else:
                    print("Unknown strategy; keeping current.")
            elif cmd == "c":
                newc = input(f"Current count is {count}. Enter new count (1-100): ").strip()
                if newc.isdigit() and 1 <= int(newc) <= 100:
                    count = int(newc)
                    print(f"Count set to {count}.")
                else:
                    print("Invalid count; keeping current.")
            elif cmd == "t":
                if tts_on:
                    tts_on = False
                    print("Text-to-speech is now OFF.")
                else:
                    test = "Testing text to speech."
                    ok = speak_system(test)
                    if ok:
                        tts_on = True
                        print("Text-to-speech is now ON.")
                    else:
                        print("TTS not available on this system.")
            else:
                continue
    except KeyboardInterrupt:
        print("\nInterrupted. Goodbye.")

if __name__ == "__main__":
    interactive_loop()
