"""
Simon Game using tkinter (no pygame)

Save as simon_tk.py and run with: python simon_tk.py

Features
- 4 colored pads in 2x2 layout
- Sequence playback with flashing
- Player input by mouse clicks
- Strict mode toggle
- Score and round display
- Optional sound: winsound on Windows or simpleaudio if installed
"""

import sys
import random
import time
import threading
try:
    import tkinter as tk
    from tkinter import messagebox
except Exception as e:
    print("tkinter is required to run this program.")
    raise

# Try to import simpleaudio for cross-platform tones
SIMPLEAUDIO = False
try:
    import simpleaudio as sa
    SIMPLEAUDIO = True
except Exception:
    SIMPLEAUDIO = False

# On Windows, winsound is available
try:
    import winsound
    WINSOUND = True
except Exception:
    WINSOUND = False

# Configuration
FLASH_MS = 600
GAP_MS = 250
BUTTON_SIZE = 200
PADDING = 12

# Colors for pads
PAD_COLORS = {
    0: {"base": "#00994C", "lit": "#66FF99"},   # green
    1: {"base": "#CC0000", "lit": "#FF6666"},   # red
    2: {"base": "#FFCC00", "lit": "#FFFF99"},   # yellow
    3: {"base": "#0066CC", "lit": "#66B2FF"},   # blue
}

# Frequencies for tones (Hz)
TONE_FREQS = {0: 440, 1: 554, 2: 659, 3: 784}

def play_tone(freq, duration_ms=400):
    """Play a tone if possible. Non-blocking on simpleaudio; blocking on winsound."""
    if WINSOUND:
        try:
            winsound.Beep(int(freq), int(duration_ms))
        except Exception:
            pass
    elif SIMPLEAUDIO:
        # generate a simple sine wave
        import numpy as np
        fs = 44100
        t = np.linspace(0, duration_ms / 1000.0, int(fs * duration_ms / 1000.0), False)
        wave = 0.5 * np.sin(2 * np.pi * freq * t)
        audio = (wave * 32767).astype('int16')
        try:
            sa.play_buffer(audio, 1, 2, fs)
        except Exception:
            pass
    else:
        # no sound available
        return

class SimonApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Simon Game")
        self.sequence = []
        self.player_index = 0
        self.playing_back = False
        self.awaiting_input = False
        self.strict_mode = False
        self.score = 0
        self.buttons = {}
        self.flash_after_id = None
        self.gap_after_id = None
        self.feedback_after_id = None

        # Build UI
        self.build_ui()

    def build_ui(self):
        top_frame = tk.Frame(self.root, padx=10, pady=10, bg="#222")
        top_frame.pack(fill="both", expand=True)

        # Canvas for pads
        canvas_w = BUTTON_SIZE * 2 + PADDING * 3
        canvas_h = BUTTON_SIZE * 2 + PADDING * 3
        self.canvas = tk.Canvas(top_frame, width=canvas_w, height=canvas_h, bg="#111", highlightthickness=0)
        self.canvas.grid(row=0, column=0, columnspan=3, padx=10, pady=10)

        # Create 4 rectangular pads
        coords = [
            (PADDING, PADDING, PADDING + BUTTON_SIZE, PADDING + BUTTON_SIZE),
            (PADDING * 2 + BUTTON_SIZE, PADDING, PADDING * 2 + BUTTON_SIZE * 2, PADDING + BUTTON_SIZE),
            (PADDING, PADDING * 2 + BUTTON_SIZE, PADDING + BUTTON_SIZE, PADDING * 2 + BUTTON_SIZE * 2),
            (PADDING * 2 + BUTTON_SIZE, PADDING * 2 + BUTTON_SIZE, PADDING * 2 + BUTTON_SIZE * 2, PADDING * 2 + BUTTON_SIZE * 2),
        ]
        for i, c in enumerate(coords):
            rect = self.canvas.create_rectangle(*c, fill=PAD_COLORS[i]["base"], outline="#333", width=6, tags=f"pad{i}")
            self.canvas.tag_bind(f"pad{i}", "<Button-1>", lambda ev, idx=i: self.on_pad_click(idx))
            self.buttons[i] = rect

        # Controls
        self.start_btn = tk.Button(top_frame, text="Start", width=12, command=self.start_game)
        self.start_btn.grid(row=1, column=0, pady=(8, 12), padx=6)

        self.strict_btn = tk.Button(top_frame, text="Strict OFF", width=12, command=self.toggle_strict)
        self.strict_btn.grid(row=1, column=1, pady=(8, 12), padx=6)

        self.quit_btn = tk.Button(top_frame, text="Quit", width=12, command=self.root.quit)
        self.quit_btn.grid(row=1, column=2, pady=(8, 12), padx=6)

        # Status
        self.status_var = tk.StringVar(value="Press Start to play")
        self.status_label = tk.Label(top_frame, textvariable=self.status_var, fg="#fff", bg="#222", font=("Arial", 12))
        self.status_label.grid(row=2, column=0, columnspan=3, pady=(0, 10))

        self.score_var = tk.StringVar(value="Score: 0")
        self.score_label = tk.Label(top_frame, textvariable=self.score_var, fg="#fff", bg="#222", font=("Arial", 12))
        self.score_label.grid(row=3, column=0, columnspan=3)

    def start_game(self):
        self.cancel_timers()
        self.sequence = []
        self.player_index = 0
        self.score = 0
        self.update_score()
        self.add_round()
        self.root.after(300, self.play_sequence)

    def toggle_strict(self):
        self.strict_mode = not self.strict_mode
        self.strict_btn.config(text="Strict ON" if self.strict_mode else "Strict OFF")
        self.status_var.set("Strict mode ON" if self.strict_mode else "Strict mode OFF")

    def add_round(self):
        self.sequence.append(random.randint(0, 3))
        self.score = len(self.sequence)
        self.update_score()
        self.status_var.set(f"Round {self.score}")

    def update_score(self):
        self.score_var.set(f"Score: {self.score}")

    def play_sequence(self):
        self.playing_back = True
        self.awaiting_input = False
        self.player_index = 0
        self.status_var.set("Watch the sequence")
        # start playback loop
        self._playback_index = 0
        self._play_next_in_sequence()

    def _play_next_in_sequence(self):
        if self._playback_index >= len(self.sequence):
            self.playing_back = False
            self.awaiting_input = True
            self.status_var.set("Your turn")
            return
        idx = self.sequence[self._playback_index]
        self.flash_pad(idx)
        # schedule turning off and gap then next
        self.gap_after_id = self.root.after(FLASH_MS + GAP_MS, self._advance_playback)

    def _advance_playback(self):
        self._playback_index += 1
        self._play_next_in_sequence()

    def flash_pad(self, idx):
        # light pad
        self.canvas.itemconfig(self.buttons[idx], fill=PAD_COLORS[idx]["lit"])
        # play tone in separate thread to avoid blocking UI on winsound
        freq = TONE_FREQS.get(idx, None)
        if freq:
            threading.Thread(target=play_tone, args=(freq, FLASH_MS), daemon=True).start()
        # schedule unflash
        if self.flash_after_id:
            self.root.after_cancel(self.flash_after_id)
        self.flash_after_id = self.root.after(FLASH_MS, lambda: self.canvas.itemconfig(self.buttons[idx], fill=PAD_COLORS[idx]["base"]))

    def on_pad_click(self, idx):
        if not self.awaiting_input:
            return
        # give immediate feedback
        self.flash_pad(idx)
        expected = self.sequence[self.player_index]
        if idx == expected:
            self.player_index += 1
            if self.player_index >= len(self.sequence):
                # correct round
                self.awaiting_input = False
                self.status_var.set("Correct! Next round...")
                self.root.after(700, self._next_round)
        else:
            # mistake
            self.awaiting_input = False
            if self.strict_mode:
                self.status_var.set("Wrong! Game over. Press Start.")
                messagebox.showinfo("Simon", "Wrong! Game over.")
                self.sequence = []
                self.score = 0
                self.update_score()
            else:
                self.status_var.set("Wrong! Try again.")
                # replay same sequence after short pause
                self.root.after(900, self.play_sequence)

    def _next_round(self):
        self.add_round()
        self.root.after(300, self.play_sequence)

    def cancel_timers(self):
        for aid in (self.flash_after_id, self.gap_after_id, self.feedback_after_id):
            if aid:
                try:
                    self.root.after_cancel(aid)
                except Exception:
                    pass
        self.flash_after_id = None
        self.gap_after_id = None
        self.feedback_after_id = None

    def on_close(self):
        self.cancel_timers()
        self.root.quit()

def main():
    root = tk.Tk()
    app = SimonApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()

if __name__ == "__main__":
    main()
