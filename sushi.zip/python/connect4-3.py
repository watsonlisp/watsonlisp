#!/usr/bin/env python3
"""
Graphical Connect Four using tkinter.
Save as connect4_gui.py and run: python connect4_gui.py
"""

import tkinter as tk
from tkinter import messagebox

# Board configuration
ROWS = 6
COLS = 7
CELL_SIZE = 80          # pixels per cell
PADDING = 10            # padding around board
ANIMATION_SPEED = 12    # pixels per frame for drop animation

# Colors
BOARD_BG = "#0b5a8a"    # board background (blue-ish)
HOLE_COLOR = "#ffffff"  # empty hole color (white)
RED = "#d32f2f"
YELLOW = "#fbc02d"
BG = "#222222"

class ConnectFourGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Connect Four")
        self.current_player = 'R'  # 'R' or 'Y'
        self.board = [[None for _ in range(COLS)] for _ in range(ROWS)]
        width = COLS * CELL_SIZE + PADDING * 2
        height = ROWS * CELL_SIZE + PADDING * 2 + 50
        self.canvas = tk.Canvas(root, width=width, height=height, bg=BG, highlightthickness=0)
        self.canvas.pack()
        self.restart_btn = tk.Button(root, text="Restart", command=self.restart, font=("Helvetica", 12))
        self.restart_btn.place(x=10, y=height-40)
        self.status_label = tk.Label(root, text="Red's turn", fg="white", bg=BG, font=("Helvetica", 12))
        self.status_label.place(x=120, y=height-40)
        self.canvas.bind("<Button-1>", self.on_click)
        self.draw_board_static()
        self.draw_all_holes()

    def draw_board_static(self):
        left = PADDING
        top = PADDING
        right = PADDING + COLS * CELL_SIZE
        bottom = PADDING + ROWS * CELL_SIZE
        # board rectangle
        self.canvas.create_rectangle(left, top, right, bottom, fill=BOARD_BG, width=0, tags="board")

    def draw_all_holes(self):
        # draw holes and any chips
        self.canvas.delete("hole")
        for r in range(ROWS):
            for c in range(COLS):
                x0 = PADDING + c * CELL_SIZE + 8
                y0 = PADDING + r * CELL_SIZE + 8
                x1 = x0 + CELL_SIZE - 16
                y1 = y0 + CELL_SIZE - 16
                # hole background
                self.canvas.create_oval(x0, y0, x1, y1, fill=HOLE_COLOR, width=0, tags="hole")
                # chip if present
                token = self.board[r][c]
                if token is not None:
                    color = RED if token == 'R' else YELLOW
                    self.canvas.create_oval(x0, y0, x1, y1, fill=color, width=0, tags="hole")

    def on_click(self, event):
        # compute column from x coordinate
        x = event.x
        col = (x - PADDING) // CELL_SIZE
        if col < 0 or col >= COLS:
            return
        # find lowest empty row
        row = self.get_next_open_row(col)
        if row is None:
            return
        # compute start and target coordinates for animation
        start_x = PADDING + col * CELL_SIZE + 8
        start_y = PADDING - CELL_SIZE  # start above board
        target_y = PADDING + row * CELL_SIZE + 8
        color = RED if self.current_player == 'R' else YELLOW
        # create animated circle
        oval = self.canvas.create_oval(start_x, start_y, start_x + CELL_SIZE - 16, start_y + CELL_SIZE - 16,
                                       fill=color, width=0, tags="anim")
        self.animate_drop(oval, start_y, target_y, col, row)

    def animate_drop(self, oval, y, target_y, col, row):
        if y < target_y:
            dy = min(ANIMATION_SPEED, target_y - y)
            self.canvas.move(oval, 0, dy)
            self.root.after(12, lambda: self.animate_drop(oval, y + dy, target_y, col, row))
        else:
            # finalize: remove anim oval, set board cell, redraw holes
            self.canvas.delete(oval)
            self.board[row][col] = self.current_player
            self.draw_all_holes()
            if self.check_win(self.current_player):
                winner = "Red" if self.current_player == 'R' else "Yellow"
                self.draw_all_holes()
                messagebox.showinfo("Game Over", f"{winner} wins!")
                return
            if self.is_draw():
                messagebox.showinfo("Game Over", "It's a draw!")
                return
            # switch player
            self.current_player = 'Y' if self.current_player == 'R' else 'R'
            self.status_label.config(text=f"{'Red' if self.current_player=='R' else 'Yellow'}'s turn")

    def get_next_open_row(self, col):
        for r in range(ROWS-1, -1, -1):
            if self.board[r][col] is None:
                return r
        return None

    def is_draw(self):
        return all(self.board[0][c] is not None for c in range(COLS))

    def check_win(self, piece):
        # horizontal
        for r in range(ROWS):
            for c in range(COLS - 3):
                if all(self.board[r][c+i] == piece for i in range(4)):
                    return True
        # vertical
        for c in range(COLS):
            for r in range(ROWS - 3):
                if all(self.board[r+i][c] == piece for i in range(4)):
                    return True
        # positive diagonal (/)
        for r in range(3, ROWS):
            for c in range(COLS - 3):
                if all(self.board[r-i][c+i] == piece for i in range(4)):
                    return True
        # negative diagonal (\)
        for r in range(ROWS - 3):
            for c in range(COLS - 3):
                if all(self.board[r+i][c+i] == piece for i in range(4)):
                    return True
        return False

    def restart(self):
        self.board = [[None for _ in range(COLS)] for _ in range(ROWS)]
        self.current_player = 'R'
        self.status_label.config(text="Red's turn")
        self.draw_all_holes()

def main():
    root = tk.Tk()
    # center window on screen
    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()
    win_w = COLS * CELL_SIZE + PADDING * 2
    win_h = ROWS * CELL_SIZE + PADDING * 2 + 50
    x = (screen_w - win_w) // 2
    y = (screen_h - win_h) // 2
    root.geometry(f"{win_w}x{win_h}+{x}+{y}")
    app = ConnectFourGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
