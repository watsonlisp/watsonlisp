#!/usr/bin/env python3
"""
To‑Do List + Quote Generator by Profession (restored tasks, quotes, and BASE_QUOTES)
- Interactive CLI: enter profession(s), choose number of tasks/quotes, optional TTS (no pip).
- Cross-platform TTS: macOS `say`, Windows PowerShell System.Speech, Linux `espeak`/`spd-say`.
- Does NOT print the BASE_QUOTES list directly.
"""

from datetime import datetime
import json
import random
import shutil
import subprocess
import sys

# ---------------------------
# BASE_QUOTES (restored, but not printed directly)
# ---------------------------
BASE_QUOTES = [
    "Do one thing today that your future self will thank you for. — Unknown",
    "Progress, not perfection. — Unknown",
    "Small steps every day lead to big changes. — Unknown",
    "Start where you are. Use what you have. Do what you can. — Arthur Ashe",
    "Action is the antidote to fear. — Unknown",
    "The only way out is through. — Robert Frost",
    "Make it happen. Shock everyone. — Unknown",
    "Begin anywhere. — John Cage",
    "You don’t have to be great to start, but you have to start to be great. — Zig Ziglar",
    "One day or day one. You decide. — Unknown",
    "Consistency compounds. — Unknown",
    "Do the work; the results will follow. — Unknown",
    "Focus on being productive instead of busy. — Tim Ferriss",
    "Eat the frog first. — Mark Twain (popularized)",
    "Block time for what matters most. — Unknown",
    "If it’s not a hell yes, it’s a no. — Derek Sivers",
    "Protect your attention like it’s your most valuable asset. — Unknown",
    "Decide, then do. — Unknown",
    "Finish what you start. — Unknown",
    "Work in bursts, rest with purpose. — Unknown",
    "Plan the work, then work the plan. — Unknown",
    "Simplicity is the ultimate sophistication. — Leonardo da Vinci",
    "Less but better. — Dieter Rams",
    "Clarity precedes mastery. — Robin Sharma",
    "Creativity is intelligence having fun. — Albert Einstein",
    "Make something people love. — Paul Graham",
    "Design is how it works. — Steve Jobs",
    "Embrace constraints; they spark creativity. — Unknown",
    "Iterate quickly, learn faster. — Unknown",
    "Fail fast, learn faster. — Unknown",
    "Good design solves problems; great design creates delight. — Unknown",
    "Lead by example. — Unknown",
    "Listen more than you speak. — Unknown",
    "Clarity is kindness. — Unknown",
    "A leader’s job is to remove obstacles. — Unknown",
    "Hire character, train skill. — Peter Schutz (adapted)",
    "Assume positive intent. — Unknown",
    "Alone we go faster; together we go further. — African Proverb (adapted)",
    "Fall seven times, stand up eight. — Japanese Proverb",
    "What doesn’t kill you makes you stronger. — Friedrich Nietzsche",
    "Turn setbacks into setups for growth. — Unknown",
    "The comeback is always stronger than the setback. — Unknown",
    "Courage is a habit, not a feeling. — Unknown",
    "Stay curious; learning never ends. — Unknown",
    "Practice deliberately, improve steadily. — Anders Ericsson (adapted)",
    "Mistakes are tuition for mastery. — Unknown",
    "Teach to learn. — Unknown",
    "Read widely, think deeply, act boldly. — Unknown",
    "Rest is productive. — Unknown",
    "Sleep is nonnegotiable. — Unknown",
    "Hydrate, nourish, repeat. — Unknown",
    "Boundaries protect your energy. — Unknown",
    "Small habits shape big outcomes. — James Clear (adapted)",
    "Solve the customer’s problem, not just the ticket. — Unknown",
    "Underpromise and overdeliver. — Unknown",
    "Listen to understand, then act to resolve. — Unknown",
    "Turn complaints into loyalty. — Unknown",
    "A delighted customer is your best marketer. — Unknown",
    "Ship small, iterate often. — Unknown",
    "Read the error; it’s trying to help you. — Unknown",
    "Automate the repetitive, humanize the creative. — Unknown",
    "Refactor early to avoid technical debt. — Unknown",
    "Tests are documentation that never lies. — Unknown",
    "Solve a real problem for real people. — Unknown",
    "Run experiments, not opinions. — Unknown",
    "Cash is the oxygen of a startup. — Unknown",
    "Be stubborn on vision, flexible on tactics. — Jeff Bezos (adapted)",
    "Perseverance beats talent when talent doesn’t persevere. — Unknown"
]

# ---------------------------
# QUOTE_POOL fragments (used to augment quotes)
# ---------------------------
PREFIXES = ["Remember to", "Always", "Try to", "Make time to", "Don't forget to", "Aim to", "Start by", "Keep doing", "Prioritize", "Focus on"]
VERBS = ["focus on", "build", "create", "refine", "measure", "practice", "protect", "simplify", "test", "iterate on", "document", "share"]
OBJECTS = ["what matters most", "small daily habits", "the user experience", "clean code", "clear communication", "your health", "customer outcomes", "reliable systems", "meaningful work", "consistent progress"]
ENDINGS = ["and the rest will follow. — Unknown", "so momentum compounds. — Unknown", "and watch results appear. — Unknown", "because clarity creates speed. — Unknown"]

def generate_programmatic_quote(profession: str) -> str:
    p = random.choice(PREFIXES)
    v = random.choice(VERBS)
    o = random.choice(OBJECTS)
    e = random.choice(ENDINGS)
    if random.random() < 0.35:
        return f"{p} {v} {o} for {profession.title()} {e}"
    return f"{p} {v} {o} {e}"

# ---------------------------
# CURATED_TEMPLATES (expanded with many more tasks and quotes)
# ---------------------------
CURATED_TEMPLATES = {
    "software engineer": {
        "tasks": [
            "Review open pull requests and leave constructive comments",
            "Merge approved PRs and monitor CI builds",
            "Write unit tests for recent changes",
            "Add integration tests for critical flows",
            "Refactor a legacy module to improve readability",
            "Profile performance hotspots and propose optimizations",
            "Update or write documentation for public APIs",
            "Attend daily standup and sync on blockers",
            "Triage incoming bug reports and assign priorities",
            "Review dependency updates and security advisories",
            "Prepare a short demo for the weekly engineering review",
            "Clean up TODOs and remove dead code",
            "Back up local dev environment and configs",
            "Investigate flaky tests and stabilize CI",
            "Review architecture decisions and note technical debt",
            "Mentor a junior engineer on best practices",
            "Design a small experiment to validate a performance fix",
            "Create a reproducible bug report with steps and logs",
            "Automate a repetitive local workflow with a script",
            "Run a security scan and triage findings"
        ],
        "quotes": [
            "Code is like humor. When you have to explain it, it’s bad. — Cory House",
            "Programs must be written for people to read, and only incidentally for machines to execute. — Harold Abelson",
            "Ship small, iterate often. — Unknown",
            "Refactor early to avoid technical debt. — Unknown",
            "Tests are documentation that never lies. — Unknown",
            "Read the error; it’s trying to help you. — Unknown",
            "Make it work, make it right, make it fast. — Unknown",
            "Automate the repetitive, humanize the creative. — Unknown",
            "Design for the user, not the edge case. — Unknown",
            "Measure, then optimize. — Unknown",
            "Fail fast, learn faster. — Unknown",
            "Keep the codebase healthy; future you will thank you. — Unknown"
        ]
    },

    "teacher": {
        "tasks": [
            "Prepare lesson plan with clear learning objectives",
            "Create or update slide deck and handouts",
            "Design formative assessment questions",
            "Grade and provide actionable feedback on student work",
            "Plan differentiated activities for diverse learners",
            "Hold office hours for students needing help",
            "Communicate progress to parents or guardians",
            "Update classroom bulletin boards and resources",
            "Order or request classroom supplies",
            "Reflect on last lesson and note improvements",
            "Coordinate with colleagues on cross-curricular projects",
            "Enter grades and attendance into the LMS",
            "Prepare materials for substitute teacher",
            "Attend professional development or staff meeting",
            "Plan next week’s homework and reading assignments",
            "Meet with students for targeted interventions",
            "Design a formative quiz to check understanding",
            "Organize student portfolios and assessments",
            "Create rubrics for consistent grading",
            "Plan a small classroom experiment or project"
        ],
        "quotes": [
            "Teaching is the greatest act of optimism. — Colleen Wilcox",
            "A good teacher can inspire hope, ignite the imagination, and instill a love of learning. — Brad Henry",
            "Stay curious; learning never ends. — Unknown",
            "Practice deliberately, improve steadily. — Anders Ericsson (adapted)",
            "Mistakes are tuition for mastery. — Unknown",
            "Read widely, think deeply, act boldly. — Unknown",
            "Teach to learn. — Unknown",
            "Small wins compound into confidence. — Unknown",
            "Plan with the end in mind. — Unknown",
            "Listen first, then guide. — Unknown",
            "Create space for questions, not just answers. — Unknown",
            "Celebrate progress, not perfection. — Unknown"
        ]
    },

    "chef": {
        "tasks": [
            "Plan menu items and daily specials",
            "Order and inspect incoming deliveries",
            "Prep mise en place for service",
            "Train line cooks on new recipes",
            "Taste and adjust sauces and seasonings",
            "Manage kitchen staff scheduling",
            "Ensure food safety and sanitation standards",
            "Plate and quality-check dishes before service",
            "Develop costed recipes and portion controls",
            "Rotate inventory and minimize waste",
            "Coordinate with front-of-house on timing",
            "Test new menu concepts and gather feedback",
            "Document recipes and prep instructions",
            "Handle customer dietary requests and allergies",
            "Plan for catering or private events",
            "Train staff on plating and timing",
            "Audit storage and temperature logs",
            "Refine prep workflows to reduce waste",
            "Negotiate with vendors for better pricing",
            "Run a tasting to finalize a seasonal menu"
        ],
        "quotes": [
            "Cooking is an expression of love. — Unknown",
            "Good food is the foundation of genuine happiness. — Unknown",
            "Practice deliberately, improve steadily. — Anders Ericsson (adapted)",
            "Small habits shape big outcomes. — James Clear (adapted)",
            "Make the complicated simple. — Unknown",
            "Taste, adjust, repeat. — Unknown",
            "Respect your ingredients; they will respect you. — Unknown",
            "Timing is flavor. — Unknown",
            "Clean station, clear mind. — Unknown",
            "Train the team, protect the craft. — Unknown",
            "Simplicity done well is a delight. — Unknown",
            "Serve with warmth, plate with care. — Unknown"
        ]
    },

    "designer": {
        "tasks": [
            "Sketch multiple layout concepts for the brief",
            "Create wireframes for desktop and mobile",
            "Run a quick heuristic review of the current UI",
            "Collect and synthesize user feedback",
            "Design high-fidelity mockups for key screens",
            "Prepare interactive prototype for testing",
            "Export assets and prepare design handoff",
            "Update or expand the design system components",
            "Review accessibility contrast and semantics",
            "Polish micro-interactions and motion details",
            "Coordinate with developers on implementation constraints",
            "Research visual trends and competitor interfaces",
            "Document design decisions and rationale",
            "Prepare presentation for stakeholder review",
            "Archive old versions and organize files",
            "Create iconography and small UI elements",
            "Test prototypes with representative users",
            "Refine typography and spacing for consistency",
            "Audit component usage across products",
            "Run a design critique with peers"
        ],
        "quotes": [
            "Design is intelligence made visible. — Alina Wheeler",
            "Good design is obvious. Great design is transparent. — Joe Sparano",
            "Make something people love. — Paul Graham",
            "Design is how it works. — Steve Jobs",
            "Embrace constraints; they spark creativity. — Unknown",
            "Make the complicated simple. — Unknown",
            "Clarity precedes mastery. — Robin Sharma",
            "Iterate quickly, learn faster. — Unknown",
            "Design for accessibility first. — Unknown",
            "Prototype to learn, not to impress. — Unknown",
            "Design decisions should be documented. — Unknown",
            "Test with real users early and often. — Unknown"
        ]
    },

    "doctor": {
        "tasks": [
            "Review scheduled patient charts and histories",
            "Prioritize urgent consults and triage",
            "Conduct patient examinations and document findings",
            "Order and interpret diagnostic tests",
            "Discuss treatment plans and informed consent",
            "Prescribe medications and check interactions",
            "Coordinate care with specialists and nursing staff",
            "Update patient records and discharge summaries",
            "Follow up on pending lab results and imaging",
            "Attend multidisciplinary rounds and case reviews",
            "Mentor medical students or residents",
            "Review and sign off on referrals",
            "Participate in quality improvement initiatives",
            "Ensure compliance with clinical protocols",
            "Schedule time for continuing medical education",
            "Review medication reconciliation and allergies",
            "Communicate complex information with empathy",
            "Document care plans and follow-up instructions",
            "Perform a focused literature search for a rare case",
            "Prepare patient education materials"
        ],
        "quotes": [
            "Wherever the art of Medicine is loved, there is also a love of Humanity. — Hippocrates",
            "The good physician treats the disease; the great physician treats the patient who has the disease. — William Osler",
            "Compassion is the heart of nursing. — Unknown",
            "Prevention is better than cure. — Unknown",
            "Listen more than you speak. — Unknown",
            "Courage is a habit, not a feeling. — Unknown",
            "Care is the constant; technology is the tool. — Unknown",
            "Small acts of kindness are clinical interventions. — Unknown",
            "Document well; it protects patients and clinicians. — Unknown",
            "Keep learning; medicine evolves. — Unknown",
            "Safety first, speed second. — Unknown",
            "Communicate clearly; patients remember tone. — Unknown"
        ]
    },

    "nurse": {
        "tasks": [
            "Review patient assignments and prioritize care",
            "Perform medication administration and checks",
            "Monitor vital signs and document trends",
            "Coordinate with physicians on care plans",
            "Educate patients and families on discharge instructions",
            "Manage wound care and dressing changes",
            "Prepare patients for procedures and tests",
            "Update care plans and nursing notes",
            "Triage incoming calls and messages",
            "Ensure equipment is functioning and stocked",
            "Mentor new nursing staff and students",
            "Participate in shift handover with clear communication",
            "Audit medication reconciliation and allergies",
            "Report and escalate safety concerns",
            "Support multidisciplinary rounds",
            "Assist with patient mobility and fall prevention",
            "Document patient responses to interventions",
            "Follow infection control protocols",
            "Coordinate post-discharge follow-up",
            "Participate in quality improvement projects"
        ],
        "quotes": [
            "Nursing is an art: and if it is to be made an art, it requires an exclusive devotion. — Florence Nightingale (adapted)",
            "Compassion is the heart of nursing. — Unknown",
            "Small acts of care make big differences. — Unknown",
            "Listen to the patient; they often tell you the diagnosis. — Unknown",
            "Safety is a team sport. — Unknown",
            "Document clearly; care is continuity. — Unknown",
            "Rest when you can; you give better care when rested. — Unknown",
            "Teach to empower patients. — Unknown",
            "Be present; presence is therapeutic. — Unknown",
            "Advocate for the patient; it is your duty. — Unknown"
        ]
    },

    "data scientist": {
        "tasks": [
            "Ingest and clean the latest dataset for analysis",
            "Run exploratory data analysis and visualize findings",
            "Feature-engineer variables for model training",
            "Train baseline models and evaluate metrics",
            "Perform hyperparameter tuning and cross-validation",
            "Document data lineage and preprocessing steps",
            "Create reproducible notebooks for experiments",
            "Validate model assumptions and check biases",
            "Deploy a model to staging and monitor performance",
            "Set up data quality checks and alerts",
            "Collaborate with product on metric definitions",
            "Prepare a short report summarizing insights",
            "Automate periodic retraining pipelines",
            "Run A/B tests and analyze results",
            "Communicate findings to non-technical stakeholders",
            "Ensure privacy and compliance for datasets",
            "Optimize feature store and retrieval latency",
            "Investigate data drift and model degradation",
            "Create dashboards for key metrics",
            "Mentor junior analysts on statistical thinking"
        ],
        "quotes": [
            "Data is the new oil; refine it responsibly. — Unknown",
            "Measure what matters. — Unknown",
            "Start with the question, not the model. — Unknown",
            "Visualize to understand; summarize to act. — Unknown",
            "Bias in, bias out; check your assumptions. — Unknown",
            "Reproducibility is the foundation of trust. — Unknown",
            "Experiment, measure, iterate. — Unknown",
            "Keep models simple until complexity is justified. — Unknown",
            "Data quality beats fancy models. — Unknown",
            "Communicate insights, not just numbers. — Unknown"
        ]
    },

    "product manager": {
        "tasks": [
            "Define the product vision and success metrics",
            "Write and prioritize the product backlog",
            "Conduct stakeholder interviews to gather needs",
            "Run user research sessions and synthesize findings",
            "Draft PRDs and acceptance criteria for features",
            "Coordinate cross-functional planning with engineering and design",
            "Monitor product KPIs and usage trends",
            "Plan and execute product launches",
            "Run experiments to validate hypotheses",
            "Manage roadmap trade-offs and communicate decisions",
            "Collect and prioritize customer feedback",
            "Prepare executive updates and demos",
            "Facilitate sprint planning and retrospectives",
            "Define pricing and packaging experiments",
            "Ensure compliance and legal reviews for features",
            "Create onboarding flows to improve activation",
            "Analyze churn drivers and propose mitigations",
            "Map user journeys and identify friction points",
            "Run competitive analysis and market scans",
            "Mentor associate product managers"
        ],
        "quotes": [
            "Be stubborn on vision, flexible on tactics. — Jeff Bezos (adapted)",
            "Solve the customer’s problem, not just the ticket. — Unknown",
            "Measure outcomes, not outputs. — Unknown",
            "Prioritize ruthlessly; focus creates impact. — Unknown",
            "Ship small, learn fast. — Unknown",
            "Talk to customers every week. — Unknown",
            "Decisions without data are guesses; validate them. — Unknown",
            "Clarity precedes alignment. — Unknown",
            "Make the product obvious to use. — Unknown",
            "Lead by example; product is a team sport. — Unknown"
        ]
    },

    "project manager": {
        "tasks": [
            "Create and maintain the project plan and timeline",
            "Identify and assign project tasks and owners",
            "Run weekly status meetings and capture action items",
            "Track risks and maintain a risk register",
            "Manage stakeholder communications and expectations",
            "Coordinate dependencies across teams",
            "Ensure milestones are met and escalate blockers",
            "Prepare project status reports for leadership",
            "Facilitate retrospectives and continuous improvement",
            "Manage scope changes and update plans",
            "Track budget and resource utilization",
            "Onboard new project contributors",
            "Document decisions and meeting notes",
            "Validate deliverables against acceptance criteria",
            "Close out project and capture lessons learned",
            "Maintain a project RAID log (Risks, Assumptions, Issues, Dependencies)",
            "Run vendor coordination and contract follow-ups",
            "Ensure compliance with organizational processes",
            "Plan handover and operational readiness",
            "Celebrate project milestones with the team"
        ],
        "quotes": [
            "Plan the work, then work the plan. — Unknown",
            "Underpromise and overdeliver. — Unknown",
            "Communication is the project manager’s superpower. — Unknown",
            "Track risks early; mitigation beats firefighting. — Unknown",
            "Small, consistent progress wins the race. — Unknown",
            "Clarity is kindness; document decisions. — Unknown",
            "Align on outcomes, not just tasks. — Unknown",
            "A good plan adapts to reality. — Unknown",
            "Celebrate the team; projects are human endeavors. — Unknown",
            "Keep stakeholders informed; surprises erode trust. — Unknown"
        ]
    },

    "marketing manager": {
        "tasks": [
            "Draft the campaign brief and target audience",
            "Coordinate creative assets with design and copy",
            "Set up tracking and UTM parameters for campaigns",
            "Run A/B tests on landing pages and creatives",
            "Analyze campaign performance and optimize spend",
            "Manage content calendar and publishing schedule",
            "Collaborate with product on feature launches",
            "Segment audiences and personalize messaging",
            "Prepare weekly performance dashboards",
            "Run SEO audits and optimize key pages",
            "Coordinate with PR for earned media opportunities",
            "Manage agency relationships and briefs",
            "Plan events and webinars to drive leads",
            "Create nurture flows for new signups",
            "Monitor brand sentiment and social listening",
            "Define KPIs and report to leadership",
            "Run competitor analysis and market scans",
            "Optimize conversion funnels and reduce friction",
            "Train sales on campaign messaging",
            "Document learnings and playbooks"
        ],
        "quotes": [
            "Tell a story that people want to share. — Unknown",
            "Measure what matters; optimize the rest. — Unknown",
            "Test, learn, scale. — Unknown",
            "Know your audience better than they know themselves. — Unknown",
            "Content is a long game; consistency wins. — Unknown",
            "Make the first impression count. — Unknown",
            "Marketing is the art of meaningful interruption. — Unknown",
            "Focus on outcomes, not vanity metrics. — Unknown",
            "Personalization at scale is a competitive advantage. — Unknown",
            "Brand trust compounds over time. — Unknown"
        ]
    },

    "sales representative": {
        "tasks": [
            "Research and qualify inbound leads",
            "Run discovery calls to understand customer needs",
            "Prepare tailored proposals and demos",
            "Follow up on open opportunities and objections",
            "Update CRM with activity and next steps",
            "Coordinate with product and legal on contracts",
            "Negotiate terms and close deals",
            "Prepare pipeline forecasts and reports",
            "Attend weekly sales huddles and training",
            "Collect customer references and case studies",
            "Manage renewal and upsell conversations",
            "Track competitor activity in accounts",
            "Prepare personalized outreach sequences",
            "Log call notes and meeting recordings",
            "Plan territory coverage and account prioritization",
            "Collaborate with marketing on lead handoff",
            "Run win/loss analysis to improve messaging",
            "Maintain relationships with key stakeholders",
            "Prepare handover to customer success post-close",
            "Keep product knowledge up to date"
        ],
        "quotes": [
            "Listen to understand, then act to resolve. — Unknown",
            "Underpromise and overdeliver. — Unknown",
            "People buy from people they trust. — Unknown",
            "Qualify early to save time later. — Unknown",
            "Follow up consistently; persistence pays. — Unknown",
            "Focus on outcomes, not features. — Unknown",
            "Build relationships, not transactions. — Unknown",
            "Know the customer's success criteria. — Unknown",
            "Be consultative; solve real problems. — Unknown",
            "Celebrate small closes; they lead to big wins. — Unknown"
        ]
    },

    "customer success manager": {
        "tasks": [
            "Onboard new customers and run kickoff calls",
            "Create success plans with measurable outcomes",
            "Monitor product usage and identify at-risk accounts",
            "Run quarterly business reviews with stakeholders",
            "Coordinate support escalations and follow-ups",
            "Collect feedback and advocate for customers",
            "Track renewal dates and prepare renewal playbooks",
            "Share best practices and enablement materials",
            "Measure NPS and follow up on detractors",
            "Identify upsell and cross-sell opportunities",
            "Document customer wins and case studies",
            "Train customer teams on new features",
            "Manage a health-score framework for accounts",
            "Facilitate customer advisory boards",
            "Coordinate with product on roadmap requests",
            "Prepare churn analysis and mitigation plans",
            "Automate routine check-ins and reporting",
            "Maintain a knowledge base for customers",
            "Celebrate customer milestones and successes",
            "Collect testimonials and references"
        ],
        "quotes": [
            "A delighted customer is your best marketer. — Unknown",
            "Solve the customer’s problem, not just the ticket. — Unknown",
            "Listen first; then act. — Unknown",
            "Retention is the foundation of growth. — Unknown",
            "Measure health, then intervene early. — Unknown",
            "Be proactive; surprise customers with value. — Unknown",
            "Customer success is a partnership. — Unknown",
            "Document outcomes; they justify renewals. — Unknown",
            "Teach customers to fish; they stay longer. — Unknown",
            "Turn complaints into loyalty. — Unknown"
        ]
    },

    "graphic designer": {
        "tasks": [
            "Create visual concepts for the campaign brief",
            "Produce high-fidelity assets for web and print",
            "Prepare brand-compliant templates and layouts",
            "Export assets in required formats and sizes",
            "Collaborate with copy on messaging and tone",
            "Iterate on feedback from stakeholders",
            "Maintain and update the brand asset library",
            "Design social media graphics and ad creatives",
            "Create icon sets and small UI elements",
            "Optimize images for performance and accessibility",
            "Prepare print-ready files and proofs",
            "Run visual QA on implemented designs",
            "Document design decisions and usage guidelines",
            "Create motion assets or hand off to motion team",
            "Design presentation decks for leadership",
            "Audit visual consistency across channels",
            "Create templates for recurring campaigns",
            "Support product launches with visual assets",
            "Design packaging or physical collateral",
            "Participate in creative critiques"
        ],
        "quotes": [
            "Good design is obvious. Great design is transparent. — Joe Sparano",
            "Design is intelligence made visible. — Alina Wheeler",
            "Make something people love. — Paul Graham",
            "Simplicity is the ultimate sophistication. — Leonardo da Vinci",
            "Iterate quickly, learn faster. — Unknown",
            "Design with empathy; users are people. — Unknown",
            "Pixels matter; polish matters more. — Unknown",
            "Design systems scale design quality. — Unknown",
            "Test visuals with real users. — Unknown",
            "Document components; reuse is efficiency. — Unknown"
        ]
    },

    "photographer": {
        "tasks": [
            "Plan the shoot and create a shot list",
            "Scout locations and check lighting conditions",
            "Prepare and test camera gear and backups",
            "Coordinate with talent and stylists",
            "Capture a variety of compositions and exposures",
            "Review shots on location and adjust as needed",
            "Import and back up raw files after the shoot",
            "Select and edit the best images for delivery",
            "Deliver retouched images in required formats",
            "Manage licensing and usage rights for images",
            "Maintain a portfolio and update galleries",
            "Invoice clients and track deliverables",
            "Create presets and workflows for consistency",
            "Archive projects and maintain metadata",
            "Collaborate with art directors on creative direction",
            "Prepare images for web and print optimization",
            "Run client review sessions and collect feedback",
            "Plan a marketing shoot to showcase new work",
            "Train an assistant on gear handling and workflow",
            "Keep up with trends in lighting and composition"
        ],
        "quotes": [
            "Photography is the story I fail to put into words. — Destin Sparks (adapted)",
            "Light is the language of photography. — Unknown",
            "Shoot with intention; edit with restraint. — Unknown",
            "Back up your files; backups are insurance. — Unknown",
            "Composition guides the eye; simplicity guides the mind. — Unknown",
            "Practice makes the shutter click with confidence. — Unknown",
            "Tell a story with a single frame. — Unknown",
            "Respect your subjects; trust is visible in photos. — Unknown",
            "Keep learning; techniques evolve. — Unknown",
            "Deliver on time; reliability builds clients. — Unknown"
        ]
    },

    "electrician": {
        "tasks": [
            "Inspect electrical panels and breakers for safety",
            "Diagnose and repair faulty wiring or outlets",
            "Install new lighting fixtures and switches",
            "Run conduit and pull wiring for new circuits",
            "Test circuits with appropriate meters and tools",
            "Ensure compliance with local electrical codes",
            "Replace or upgrade service panels as needed",
            "Troubleshoot intermittent power issues",
            "Perform preventive maintenance on systems",
            "Coordinate with contractors on new builds",
            "Label circuits and update electrical diagrams",
            "Install grounding and surge protection",
            "Estimate jobs and prepare material lists",
            "Order parts and manage inventory",
            "Provide safety briefings to apprentices",
            "Document work and update service records",
            "Respond to emergency electrical calls",
            "Verify load calculations for new equipment",
            "Install EV charging stations and test",
            "Perform final inspections and sign-offs"
        ],
        "quotes": [
            "Safety first; electricity demands respect. — Unknown",
            "Measure twice, wire once. — Unknown",
            "Code compliance protects people and property. — Unknown",
            "A tidy panel is a reliable panel. — Unknown",
            "Document your work; future you will thank you. — Unknown",
            "Test thoroughly; assumptions are dangerous. — Unknown",
            "Train apprentices; craft is passed on. — Unknown",
            "Plan the route; avoid surprises in walls. — Unknown",
            "Quality materials reduce callbacks. — Unknown",
            "Work clean; professionalism shows in details. — Unknown"
        ]
    },

    "plumber": {
        "tasks": [
            "Inspect plumbing systems for leaks and corrosion",
            "Unclog drains and clear blockages",
            "Replace worn valves and seals",
            "Install new fixtures and faucets",
            "Run new supply and waste lines for remodels",
            "Pressure-test systems after repairs",
            "Service water heaters and check thermostats",
            "Diagnose low water pressure issues",
            "Coordinate with contractors on bathroom builds",
            "Ensure compliance with plumbing codes",
            "Estimate jobs and prepare material lists",
            "Maintain inventory of fittings and parts",
            "Document repairs and update service logs",
            "Respond to emergency burst pipe calls",
            "Install backflow prevention devices",
            "Perform preventive maintenance on systems",
            "Train apprentices on safe practices",
            "Check for cross-connections and contamination",
            "Advise customers on water-saving upgrades",
            "Perform final inspections and handover"
        ],
        "quotes": [
            "Fix the root cause, not just the symptom. — Unknown",
            "A small leak today is a big problem tomorrow. — Unknown",
            "Quality fittings save time and money. — Unknown",
            "Test after repair; trust but verify. — Unknown",
            "Keep the workspace clean; customers notice. — Unknown",
            "Plan the route; avoid unnecessary cuts. — Unknown",
            "Document what you changed; it helps later. — Unknown",
            "Safety and code compliance are non-negotiable. — Unknown",
            "Teach apprentices the right way to do it. — Unknown",
            "Preventive maintenance prevents emergencies. — Unknown"
        ]
    },

    "mechanic": {
        "tasks": [
            "Perform diagnostic scans and interpret codes",
            "Inspect brakes, suspension, and steering components",
            "Change oil and replace filters per schedule",
            "Replace worn belts, hoses, and fluids",
            "Perform tune-ups and engine diagnostics",
            "Align wheels and check tire condition",
            "Repair or replace exhaust and emissions components",
            "Service transmission and drivetrain systems",
            "Perform safety inspections and road tests",
            "Document repairs and parts used",
            "Estimate repair costs and timelines",
            "Order parts and manage inventory",
            "Communicate repair status to customers",
            "Train junior technicians on diagnostics",
            "Maintain shop tools and calibration",
            "Perform preventive maintenance programs",
            "Investigate unusual noises and vibrations",
            "Ensure compliance with environmental regulations",
            "Test electrical systems and charging circuits",
            "Prepare vehicles for inspection and sale"
        ],
        "quotes": [
            "Listen to the car; it often tells you what’s wrong. — Unknown",
            "Diagnose before you replace. — Unknown",
            "Keep tools organized; speed and safety improve. — Unknown",
            "Document repairs; transparency builds trust. — Unknown",
            "Quality parts reduce repeat visits. — Unknown",
            "Test drive after repair; it validates the fix. — Unknown",
            "Train continuously; vehicles evolve. — Unknown",
            "Safety checks save lives. — Unknown",
            "Communicate clearly with customers. — Unknown",
            "Preventive maintenance is cost-effective. — Unknown"
        ]
    },

    "veterinarian": {
        "tasks": [
            "Review patient histories and vaccination records",
            "Perform physical exams and document findings",
            "Order and interpret diagnostic tests",
            "Administer vaccines and preventive care",
            "Perform minor surgeries and wound care",
            "Advise owners on nutrition and behavior",
            "Coordinate referrals to specialists when needed",
            "Prescribe medications and check interactions",
            "Update medical records and discharge instructions",
            "Follow up on post-op patients and recovery",
            "Participate in community outreach and education",
            "Maintain sterile technique in procedures",
            "Mentor veterinary technicians and students",
            "Manage inventory of medical supplies",
            "Ensure compliance with animal welfare regulations",
            "Prepare case summaries for complex patients",
            "Handle emergency triage and stabilization",
            "Document informed consent and owner communications",
            "Plan preventive care schedules for clients",
            "Contribute to clinic quality improvement initiatives"
        ],
        "quotes": [
            "Wherever the art of Medicine is loved, there is also a love of Humanity. — Hippocrates (adapted)",
            "Treat the animal, educate the owner. — Unknown",
            "Compassion and competence go hand in hand. — Unknown",
            "Prevention is better than cure. — Unknown",
            "Listen to the owner; they know their pet best. — Unknown",
            "Document clearly; it protects patients and clinicians. — Unknown",
            "Small comforts matter in recovery. — Unknown",
            "Keep learning; veterinary medicine advances. — Unknown",
            "Teamwork saves lives. — Unknown",
            "Empathy is part of clinical skill. — Unknown"
        ]
    },

    "accountant": {
        "tasks": [
            "Reconcile bank statements and ledgers",
            "Prepare monthly financial statements",
            "Review and code expenses and invoices",
            "Manage accounts payable and receivable",
            "Prepare tax filings and compliance documents",
            "Run variance analysis against budgets",
            "Close the books at month-end and quarter-end",
            "Prepare audit schedules and support requests",
            "Automate recurring journal entries",
            "Maintain fixed asset register and depreciation",
            "Forecast cash flow and working capital needs",
            "Coordinate with external auditors",
            "Implement internal controls and policies",
            "Train staff on accounting procedures",
            "Prepare management reports and KPIs",
            "Review payroll entries and benefits reconciliations",
            "Ensure compliance with accounting standards",
            "Document accounting policies and procedures",
            "Support financial planning and analysis",
            "Archive financial records securely"
        ],
        "quotes": [
            "Cash is the oxygen of a business. — Unknown",
            "Underpromise and overdeliver on forecasts. — Unknown",
            "Accuracy matters; small errors compound. — Unknown",
            "Document everything; audits appreciate clarity. — Unknown",
            "Automate repetitive tasks to reduce risk. — Unknown",
            "Understand the business, not just the numbers. — Unknown",
            "Controls protect the company and its people. — Unknown",
            "Timely closes enable better decisions. — Unknown",
            "Keep learning; standards evolve. — Unknown",
            "Communicate numbers in plain language. — Unknown"
        ]
    },

    "lawyer": {
        "tasks": [
            "Review client intake and conflict checks",
            "Research relevant statutes and case law",
            "Draft contracts, pleadings, and agreements",
            "Prepare discovery requests and responses",
            "Negotiate terms with opposing counsel",
            "Advise clients on regulatory compliance",
            "Prepare for hearings and depositions",
            "Manage case timelines and deadlines",
            "Coordinate with experts and witnesses",
            "Review and summarize documents for clients",
            "Draft settlement proposals and memos",
            "Maintain privileged communications and records",
            "Bill time and prepare client invoices",
            "Attend client meetings and provide counsel",
            "Prepare closing arguments or trial exhibits",
            "Update clients on case strategy and risks",
            "Conduct legal due diligence for transactions",
            "Train junior associates on drafting standards",
            "Monitor changes in relevant laws and regulations",
            "Archive closed matter files securely"
        ],
        "quotes": [
            "Assume positive intent; negotiate with respect. — Unknown",
            "Document decisions; clarity reduces disputes. — Unknown",
            "Know the facts, then apply the law. — Unknown",
            "Prepare thoroughly; confidence follows preparation. — Unknown",
            "Communicate risks clearly to clients. — Unknown",
            "Ethics and competence are inseparable. — Unknown",
            "Listen to the client; their goals guide strategy. — Unknown",
            "Draft simply; complexity invites ambiguity. — Unknown",
            "Keep learning; the law evolves. — Unknown",
            "Protect privilege; confidentiality is essential. — Unknown"
        ]
    },

    "researcher": {
        "tasks": [
            "Define research questions and hypotheses",
            "Design experiments or study protocols",
            "Collect and clean data for analysis",
            "Run statistical analyses and validate results",
            "Document methods and reproducible workflows",
            "Prepare figures and tables for publication",
            "Write literature reviews and related work sections",
            "Submit IRB or ethics applications when required",
            "Coordinate with collaborators and co-authors",
            "Present findings at internal seminars",
            "Draft manuscripts and respond to reviewer comments",
            "Archive datasets and code for reproducibility",
            "Apply for grants and prepare budgets",
            "Mentor students and junior researchers",
            "Attend conferences and network with peers",
            "Maintain lab notebooks or research logs",
            "Perform sensitivity analyses and robustness checks",
            "Prepare data management plans",
            "Ensure compliance with funding requirements",
            "Plan next-phase experiments based on results"
        ],
        "quotes": [
            "Stay curious; learning never ends. — Unknown",
            "Run experiments, not opinions. — Unknown",
            "Document methods so others can reproduce your work. — Unknown",
            "Fail fast, learn faster. — Unknown",
            "Measure uncertainty; report it honestly. — Unknown",
            "Collaboration accelerates discovery. — Unknown",
            "Read widely to find new connections. — Unknown",
            "Be rigorous, but be humble about conclusions. — Unknown",
            "Share data responsibly; it multiplies impact. — Unknown",
            "Mentor to multiply scientific capacity. — Unknown"
        ]
    },

    "hr manager": {
        "tasks": [
            "Manage recruitment and interview pipelines",
            "Coordinate onboarding and orientation programs",
            "Maintain employee records and compliance",
            "Run performance review cycles and calibration",
            "Design and implement training programs",
            "Handle employee relations and conflict resolution",
            "Manage benefits enrollment and vendor relationships",
            "Track headcount and workforce planning",
            "Prepare HR reports and dashboards",
            "Ensure compliance with labor laws and policies",
            "Support managers with coaching and development",
            "Plan employee engagement and recognition programs",
            "Conduct exit interviews and analyze trends",
            "Update job descriptions and competency frameworks",
            "Coordinate diversity, equity, and inclusion initiatives",
            "Manage HRIS data integrity and updates",
            "Facilitate leadership development programs",
            "Prepare compensation benchmarking and recommendations",
            "Support organizational change and restructuring",
            "Document HR policies and employee handbooks"
        ],
        "quotes": [
            "Hire character, train skill. — Peter Schutz (adapted)",
            "Assume positive intent; resolve with empathy. — Unknown",
            "People are the organization’s greatest asset. — Unknown",
            "Clarity precedes alignment; communicate policies clearly. — Unknown",
            "Invest in development; retention follows. — Unknown",
            "Measure engagement and act on signals. — Unknown",
            "Fair processes build trust. — Unknown",
            "Listen to employees; they will tell you what matters. — Unknown",
            "Document decisions; transparency reduces confusion. — Unknown",
            "Lead with empathy and accountability. — Unknown"
        ]
    },

    "recruiter": {
        "tasks": [
            "Source candidates through multiple channels",
            "Screen resumes and conduct initial phone screens",
            "Coordinate interviews with hiring teams",
            "Provide timely feedback to candidates",
            "Maintain candidate pipelines and CRM hygiene",
            "Write compelling job descriptions and postings",
            "Manage offer processes and negotiations",
            "Track diversity metrics and sourcing effectiveness",
            "Build talent pools for future hiring needs",
            "Train hiring managers on interview best practices",
            "Run reference checks and background verifications",
            "Prepare recruitment reports and forecasts",
            "Attend career fairs and campus events",
            "Optimize interview workflows and candidate experience",
            "Coordinate relocation and onboarding logistics",
            "Maintain relationships with external agencies",
            "Analyze time-to-hire and quality-of-hire metrics",
            "Support employer branding initiatives",
            "Document hiring decisions and approvals",
            "Continuously improve sourcing strategies"
        ],
        "quotes": [
            "Assume positive intent; treat candidates with respect. — Unknown",
            "Speed and quality are both important; balance them. — Unknown",
            "Candidate experience is your brand. — Unknown",
            "Source proactively; great talent is not always looking. — Unknown",
            "Measure outcomes; refine your process. — Unknown",
            "Build relationships; recruiting is long-term. — Unknown",
            "Communicate clearly; uncertainty loses candidates. — Unknown",
            "Diversity requires intentional sourcing. — Unknown",
            "Train interviewers; consistency reduces bias. — Unknown",
            "Celebrate hires and learn from misses. — Unknown"
        ]
    },

    "ux researcher": {
        "tasks": [
            "Plan user research studies and recruit participants",
            "Write discussion guides and test scripts",
            "Conduct usability tests and contextual interviews",
            "Synthesize qualitative findings into themes",
            "Create personas and journey maps from insights",
            "Present research findings to cross-functional teams",
            "Collaborate with designers to iterate on prototypes",
            "Run remote unmoderated studies and analyze results",
            "Measure task success and time-on-task metrics",
            "Document research methods and participant notes",
            "Advocate for user needs in product planning",
            "Create research repositories and tag insights",
            "Run diary studies for longitudinal insights",
            "Validate assumptions with quick guerrilla tests",
            "Train product teams on research literacy",
            "Prioritize research questions based on impact",
            "Ensure ethical treatment and consent for participants",
            "Prepare executive summaries and recommendations",
            "Translate insights into actionable design changes",
            "Track research impact on product metrics"
        ],
        "quotes": [
            "Listen to users; they reveal unmet needs. — Unknown",
            "Research reduces risk; test early and often. — Unknown",
            "Synthesize to tell a clear story. — Unknown",
            "Context matters; observe real behavior. — Unknown",
            "Make insights accessible to the whole team. — Unknown",
            "Triangulate data sources for confidence. — Unknown",
            "Ethics and consent are non-negotiable. — Unknown",
            "Small studies can yield big insights. — Unknown",
            "Document methods so others can replicate. — Unknown",
            "Advocate for users; product decisions follow. — Unknown"
        ]
    },

    "qa engineer": {
        "tasks": [
            "Write and maintain automated test suites",
            "Create test plans and acceptance criteria",
            "Run regression tests and report failures",
            "Triage bugs and reproduce issues with steps",
            "Coordinate with developers on fixes and retests",
            "Perform exploratory testing on new features",
            "Validate performance and load characteristics",
            "Integrate tests into CI pipelines",
            "Maintain test data and environment configurations",
            "Document flaky tests and stabilize suites",
            "Review requirements for testability",
            "Automate smoke checks for deployments",
            "Run security scans and report findings",
            "Prepare release test reports and sign-offs",
            "Mentor developers on writing testable code",
            "Track test coverage and gaps",
            "Create end-to-end scenarios for critical flows",
            "Validate cross-browser and device compatibility",
            "Participate in sprint planning for test estimates",
            "Continuously improve testing processes"
        ],
        "quotes": [
            "Tests are documentation that never lies. — Unknown",
            "Read the error; it’s trying to help you. — Unknown",
            "Automate the repetitive, humanize the creative. — Unknown",
            "Stability beats speed when customers rely on you. — Unknown",
            "Test early; catch issues before they compound. — Unknown",
            "Flaky tests hide real problems; fix them. — Unknown",
            "Quality is a team responsibility. — Unknown",
            "Measure coverage, but measure impact more. — Unknown",
            "Document test cases for reproducibility. — Unknown",
            "Continuous improvement keeps suites healthy. — Unknown"
        ]
    },

    "systems administrator": {
        "tasks": [
            "Monitor system health and respond to alerts",
            "Patch servers and apply security updates",
            "Manage user accounts and access controls",
            "Backup critical systems and verify restores",
            "Automate routine maintenance tasks with scripts",
            "Manage DNS, DHCP, and network configurations",
            "Troubleshoot connectivity and performance issues",
            "Maintain configuration management and IaC",
            "Document runbooks and incident procedures",
            "Coordinate maintenance windows with stakeholders",
            "Audit logs and investigate anomalies",
            "Provision new servers and services",
            "Manage cloud resources and cost optimization",
            "Ensure compliance with security policies",
            "Rotate keys and manage secrets securely",
            "Test disaster recovery plans and RTOs",
            "Onboard and offboard employees securely",
            "Monitor capacity and plan for scaling",
            "Maintain monitoring dashboards and alerts",
            "Train team members on operational practices"
        ],
        "quotes": [
            "Automate the repetitive, humanize the creative. — Unknown",
            "Backups are insurance; test restores regularly. — Unknown",
            "Monitor what matters; alerts should be actionable. — Unknown",
            "Document runbooks; they save time in incidents. — Unknown",
            "Security is everyone’s responsibility. — Unknown",
            "Keep systems simple; complexity breeds fragility. — Unknown",
            "Plan for failure; design for recovery. — Unknown",
            "Communicate clearly during incidents. — Unknown",
            "Capacity planning prevents outages. — Unknown",
            "Invest in observability; it pays in time saved. — Unknown"
        ]
    },

    "startup founder": {
        "tasks": [
            "Refine the company vision and value proposition",
            "Talk to customers to validate the problem",
            "Prioritize product features for the next sprint",
            "Raise capital and manage investor relations",
            "Hire key early team members and set culture",
            "Set OKRs and align the team on goals",
            "Monitor cash runway and burn rate",
            "Run experiments to find product-market fit",
            "Prepare investor updates and metrics",
            "Negotiate partnerships and commercial deals",
            "Handle legal and compliance basics for the company",
            "Create a hiring plan and interview process",
            "Define pricing and go-to-market strategy",
            "Lead demos and sales conversations",
            "Set up basic operational processes and tools",
            "Collect user feedback and iterate quickly",
            "Manage vendor contracts and procurement",
            "Plan for scaling engineering and support",
            "Document core company policies and values",
            "Celebrate milestones and learn from failures"
        ],
        "quotes": [
            "Be stubborn on vision, flexible on tactics. — Jeff Bezos (adapted)",
            "Cash is the oxygen of a startup. — Unknown",
            "Ship small, iterate often. — Unknown",
            "Talk to customers; build what they need. — Unknown",
            "Perseverance beats talent when talent doesn’t persevere. — Unknown",
            "Measure traction, not vanity. — Unknown",
            "Hire people who amplify your strengths. — Unknown",
            "Focus on one metric that matters. — Unknown",
            "Learn quickly from experiments. — Unknown",
            "Protect your runway; plan for contingencies. — Unknown"
        ]
    },

    "barista": {
        "tasks": [
            "Prepare espresso shots and calibrate grinders",
            "Steam milk to correct texture and temperature",
            "Maintain cleanliness of the espresso machine",
            "Brew batch coffee and manage freshness",
            "Serve customers with friendly, efficient service",
            "Train new staff on drink recipes and standards",
            "Manage inventory of beans, milk, and supplies",
            "Create seasonal drink suggestions and specials",
            "Handle cash and POS transactions accurately",
            "Maintain health and safety standards",
            "Prepare cold brew and specialty beverages",
            "Clean and sanitize workstations between shifts",
            "Restock condiments and display cases",
            "Engage customers and collect feedback",
            "Prepare catering orders and large batches",
            "Monitor equipment and report maintenance needs",
            "Create latte art for customer delight",
            "Balance the till and prepare deposits",
            "Plan shift schedules with the manager",
            "Participate in coffee cupping and quality checks"
        ],
        "quotes": [
            "Serve with warmth; coffee is a ritual. — Unknown",
            "Consistency in every cup builds loyalty. — Unknown",
            "Clean equipment makes better coffee. — Unknown",
            "Train the team; standards scale with people. — Unknown",
            "Taste often; calibrate grinders and doses. — Unknown",
            "Small gestures make big customer impressions. — Unknown",
            "Keep the workflow smooth; speed with quality. — Unknown",
            "Know your beans; freshness matters. — Unknown",
            "Be present; customers remember service. — Unknown",
            "Celebrate the craft; coffee is both art and science. — Unknown"
        ]
    },

    "bartender": {
        "tasks": [
            "Prepare classic cocktails and follow recipes",
            "Create seasonal drink menus and specials",
            "Manage bar inventory and reorder supplies",
            "Maintain cleanliness and glassware rotation",
            "Check IDs and ensure responsible service",
            "Train staff on cocktail techniques and speed",
            "Balance the bar cash and tabs at shift end",
            "Engage guests and recommend pairings",
            "Prepare garnishes and mise en place for service",
            "Coordinate with kitchen on timing for food orders",
            "Monitor stock levels and rotate perishable items",
            "Handle customer complaints with composure",
            "Create batch cocktails for events",
            "Perform opening and closing bar checklists",
            "Maintain bar equipment and refrigeration",
            "Run tastings and staff training sessions",
            "Document new recipes and ingredient sources",
            "Plan for busy service and staffing needs",
            "Ensure compliance with local liquor laws",
            "Support private events and catering requests"
        ],
        "quotes": [
            "Craft cocktails are hospitality in a glass. — Unknown",
            "Balance is the heart of a great drink. — Unknown",
            "Prep well; service is a performance. — Unknown",
            "Know your spirits; recommendations build trust. — Unknown",
            "Keep the bar clean; it shows professionalism. — Unknown",
            "Train for speed without sacrificing quality. — Unknown",
            "Listen to guests; tailor the experience. — Unknown",
            "Stock rotation keeps flavors fresh. — Unknown",
            "Safety and responsibility come first. — Unknown",
            "Celebrate the team; service is collaborative. — Unknown"
        ]
    },

    "architect": {
        "tasks": [
            "Develop schematic designs and concept sketches",
            "Coordinate with clients to refine program requirements",
            "Produce construction documents and details",
            "Coordinate with structural and MEP engineers",
            "Review code compliance and zoning constraints",
            "Prepare material palettes and finish schedules",
            "Conduct site visits and document conditions",
            "Manage consultant deliverables and timelines",
            "Prepare presentation boards for client review",
            "Estimate phasing and construction sequencing",
            "Respond to RFIs during construction",
            "Perform quality reviews of contractor work",
            "Update drawings and issue addenda as needed",
            "Coordinate with landscape and interior designers",
            "Prepare permit submissions and follow-ups",
            "Document as-built conditions at project close",
            "Run design charrettes with stakeholders",
            "Incorporate sustainability strategies and targets",
            "Maintain project BIM models and libraries",
            "Mentor junior designers and interns"
        ],
        "quotes": [
            "Good architecture begins with people. — Unknown",
            "Design for how people will live, not just how it looks. — Unknown",
            "Sustainability is design responsibility. — Unknown",
            "Document decisions; construction depends on clarity. — Unknown",
            "Coordinate early to avoid costly changes. — Unknown",
            "Sketch to explore; model to communicate. — Unknown",
            "Listen to the site; context informs design. — Unknown",
            "Detail is where design becomes buildable. — Unknown",
            "Collaborate across disciplines for better outcomes. — Unknown",
            "Design with empathy and durability in mind. — Unknown"
        ]
    },

    "real estate agent": {
        "tasks": [
            "Prepare property listings with accurate descriptions",
            "Coordinate professional photography and staging",
            "Research comparable sales and set pricing strategy",
            "Host open houses and private showings",
            "Qualify buyer leads and understand needs",
            "Negotiate offers and counteroffers on behalf of clients",
            "Coordinate inspections and disclosures",
            "Manage transaction timelines and paperwork",
            "Communicate regularly with clients on status",
            "Prepare market updates and neighborhood reports",
            "Coordinate with lenders and title companies",
            "Advise clients on market timing and strategy",
            "Collect feedback from showings and adjust marketing",
            "Prepare closing checklists and final walkthroughs",
            "Maintain CRM and follow-up with past clients",
            "Create marketing materials and social posts",
            "Attend networking events to build referral sources",
            "Monitor local zoning and development news",
            "Support relocation logistics for clients",
            "Document lessons learned from each transaction"
        ],
        "quotes": [
            "Location, condition, and timing matter. — Unknown",
            "Listen to the client; their priorities guide the search. — Unknown",
            "Market knowledge builds client confidence. — Unknown",
            "Prepare thoroughly; transactions are detail-driven. — Unknown",
            "Communicate clearly; surprises erode trust. — Unknown",
            "Negotiate with integrity; reputation matters. — Unknown",
            "Marketing sells; presentation matters. — Unknown",
            "Follow up consistently; relationships create referrals. — Unknown",
            "Be a trusted advisor, not just a salesperson. — Unknown",
            "Celebrate closings; they mark meaningful milestones. — Unknown"
        ]
    },

    "pilot": {
        "tasks": [
            "Perform pre-flight inspections and checklists",
            "Review weather briefings and NOTAMs",
            "Plan fuel requirements and alternate airports",
            "File flight plans and coordinate with ATC",
            "Conduct cockpit briefings with crew",
            "Monitor aircraft systems during flight",
            "Communicate clearly with ATC and ground services",
            "Manage in-flight deviations and contingencies",
            "Complete post-flight logs and maintenance reports",
            "Participate in recurrent training and checkrides",
            "Coordinate with dispatch on scheduling",
            "Ensure compliance with regulations and SOPs",
            "Perform weight and balance calculations",
            "Manage passenger briefings and safety procedures",
            "Report defects and follow up on rectifications",
            "Plan for crew rest and duty limitations",
            "Review company safety bulletins and advisories",
            "Mentor junior pilots and cadets",
            "Participate in emergency procedure drills",
            "Maintain currency on aircraft systems and updates"
        ],
        "quotes": [
            "Aviate, navigate, communicate — in that order. — Unknown",
            "Preparation reduces surprises in flight. — Unknown",
            "Checklists are the backbone of safe operations. — Unknown",
            "Communicate clearly; ambiguity is dangerous. — Unknown",
            "Respect weather; it is a pilot’s primary constraint. — Unknown",
            "Train for emergencies; muscle memory saves lives. — Unknown",
            "Maintain situational awareness at all times. — Unknown",
            "Log everything; records matter for safety and compliance. — Unknown",
            "Mentor the next generation of aviators. — Unknown",
            "Safety culture is built by consistent actions. — Unknown"
        ]
    },

    "truck driver": {
        "tasks": [
            "Inspect vehicle and secure cargo before departure",
            "Plan route and check for restrictions or closures",
            "Log hours and comply with HOS regulations",
            "Perform pre-trip and post-trip vehicle checks",
            "Communicate ETAs with dispatch and customers",
            "Manage fuel stops and optimize routes",
            "Secure loads and check tie-downs periodically",
            "Report defects and coordinate repairs",
            "Follow safety procedures for loading/unloading",
            "Maintain clean and organized cab and paperwork",
            "Handle border or permit paperwork when required",
            "Monitor weather and road conditions en route",
            "Complete delivery confirmations and PODs",
            "Coordinate with warehouse for efficient handoffs",
            "Adhere to company safety and compliance policies",
            "Perform basic roadside troubleshooting",
            "Plan rest breaks and manage fatigue",
            "Update maintenance logs and service schedules",
            "Train new drivers on company procedures",
            "Participate in safety meetings and briefings"
        ],
        "quotes": [
            "Safety and compliance keep you on the road. — Unknown",
            "Plan your route; avoid surprises. — Unknown",
            "Inspect before you drive; it prevents breakdowns. — Unknown",
            "Communicate early; customers appreciate updates. — Unknown",
            "Secure the load; it protects everyone on the road. — Unknown",
            "Rest is part of the job; fatigue is dangerous. — Unknown",
            "Keep records accurate; they matter in audits. — Unknown",
            "Maintain your rig; it pays in reliability. — Unknown",
            "Be courteous on the road; reputation matters. — Unknown",
            "Continuous improvement reduces downtime. — Unknown"
        ]
    },

    "receptionist": {
        "tasks": [
            "Greet visitors and manage sign-in procedures",
            "Answer and route incoming phone calls",
            "Manage meeting room bookings and calendars",
            "Receive and distribute mail and packages",
            "Maintain a tidy and welcoming reception area",
            "Provide basic information to visitors and callers",
            "Coordinate with facilities for office needs",
            "Support administrative tasks for the team",
            "Manage visitor badges and security protocols",
            "Update contact lists and directories",
            "Assist with event setup and logistics",
            "Handle simple billing or payment processing",
            "Prepare meeting materials and refreshments",
            "Escalate urgent requests to appropriate staff",
            "Maintain office supplies and reorder when low",
            "Record and report visitor feedback",
            "Support onboarding logistics for new hires",
            "Manage voicemail and message delivery",
            "Coordinate with building management for issues",
            "Document daily front-desk activities"
        ],
        "quotes": [
            "First impressions matter; be welcoming. — Unknown",
            "Clarity and courtesy make every interaction smoother. — Unknown",
            "Be organized; small details create big trust. — Unknown",
            "Communicate promptly; messages are time-sensitive. — Unknown",
            "Keep the space tidy; it reflects the organization. — Unknown",
            "Know who to escalate to; speed matters. — Unknown",
            "Document requests; follow-through builds reliability. — Unknown",
            "Be patient; every caller has a story. — Unknown",
            "Anticipate needs; proactive service delights. — Unknown",
            "Smile; it changes the tone of the day. — Unknown"
        ]
    },

    "consultant": {
        "tasks": [
            "Clarify client objectives and success criteria",
            "Conduct stakeholder interviews and discovery",
            "Analyze current-state processes and data",
            "Develop recommendations and implementation plans",
            "Prepare slide decks and executive summaries",
            "Facilitate workshops and alignment sessions",
            "Support pilot implementations and measure outcomes",
            "Document change management and training plans",
            "Coordinate with client teams for handover",
            "Track project milestones and deliverables",
            "Perform cost-benefit analyses for options",
            "Collect feedback and iterate on recommendations",
            "Prepare final reports and lessons learned",
            "Manage client expectations and communications",
            "Support procurement and vendor selection",
            "Ensure knowledge transfer to client teams",
            "Maintain confidentiality and professional standards",
            "Develop reusable frameworks and templates",
            "Mentor junior consultants on client work",
            "Measure impact and ROI post-implementation"
        ],
        "quotes": [
            "Solve the real problem, not the symptom. — Unknown",
            "Listen more than you speak; insights come from listening. — Unknown",
            "Frame recommendations with clear outcomes. — Unknown",
            "Be pragmatic; perfect is the enemy of progress. — Unknown",
            "Document assumptions; they guide decisions. — Unknown",
            "Measure impact to prove value. — Unknown",
            "Communicate clearly to build alignment. — Unknown",
            "Tailor solutions to the client’s context. — Unknown",
            "Transfer knowledge; sustainability matters. — Unknown",
            "Be a partner, not just a vendor. — Unknown"
        ]
    },

    "therapist": {
        "tasks": [
            "Prepare for client sessions and review notes",
            "Conduct intake assessments and set goals",
            "Provide evidence-based interventions during sessions",
            "Document session notes and treatment plans",
            "Coordinate care with other providers when appropriate",
            "Monitor progress and adjust therapeutic approaches",
            "Maintain confidentiality and ethical standards",
            "Manage scheduling and follow-up appointments",
            "Provide crisis intervention when needed",
            "Refer clients to community resources and supports",
            "Engage in supervision and professional development",
            "Prepare reports for insurance or legal requests",
            "Support clients with relapse prevention planning",
            "Track outcomes and measure therapeutic progress",
            "Maintain boundaries and self-care practices",
            "Participate in multidisciplinary case reviews",
            "Update treatment plans based on client feedback",
            "Document informed consent and risk assessments",
            "Provide psychoeducation and coping strategies",
            "Plan group therapy sessions and materials"
        ],
        "quotes": [
            "Listen to understand, not to reply. — Unknown",
            "Therapy is a collaborative journey. — Unknown",
            "Small steps toward change compound over time. — Unknown",
            "Empathy opens the door to healing. — Unknown",
            "Boundaries protect both client and clinician. — Unknown",
            "Self-care enables sustainable care for others. — Unknown",
            "Measure progress; celebrate small gains. — Unknown",
            "Confidentiality builds trust. — Unknown",
            "Be present; presence is therapeutic. — Unknown",
            "Reflect, don’t judge; curiosity helps. — Unknown"
        ]
    },

    "psychologist": {
        "tasks": [
            "Conduct psychological assessments and testing",
            "Interpret results and write clinical reports",
            "Provide individual and group therapy sessions",
            "Develop treatment plans and measurable goals",
            "Coordinate care with psychiatrists and other providers",
            "Monitor client progress and adjust interventions",
            "Supervise trainees and interns in clinical work",
            "Engage in research or program evaluation when relevant",
            "Maintain ethical and legal documentation",
            "Provide consultation to organizations on mental health",
            "Deliver psychoeducation workshops and trainings",
            "Manage crisis assessments and safety planning",
            "Contribute to multidisciplinary treatment teams",
            "Stay current with evidence-based practices",
            "Publish or present clinical findings when appropriate",
            "Advocate for client needs within systems",
            "Maintain professional development and licensure",
            "Collect outcome measures and analyze trends",
            "Support community mental health initiatives",
            "Document informed consent and confidentiality"
        ],
        "quotes": [
            "Practice deliberately, improve steadily. — Anders Ericsson (adapted)",
            "Listen deeply; assessment informs care. — Unknown",
            "Measure outcomes to guide treatment. — Unknown",
            "Therapeutic alliance is the strongest predictor of change. — Unknown",
            "Be curious about behavior, not judgmental. — Unknown",
            "Ethics and competence are inseparable. — Unknown",
            "Teach skills that clients can use daily. — Unknown",
            "Reflective practice improves clinical care. — Unknown",
            "Collaborate with systems to support clients. — Unknown",
            "Self-care sustains clinical effectiveness. — Unknown"
        ]
    },

    "librarian": {
        "tasks": [
            "Curate collections and manage acquisitions",
            "Catalog new materials and update metadata",
            "Assist patrons with research and reference questions",
            "Plan and run community programs and events",
            "Manage interlibrary loan requests and returns",
            "Maintain digital resources and subscriptions",
            "Develop reading lists and resource guides",
            "Train patrons on database and catalog use",
            "Preserve special collections and archives",
            "Coordinate volunteers and student workers",
            "Prepare displays and thematic exhibits",
            "Manage circulation policies and fines",
            "Support literacy and outreach initiatives",
            "Evaluate collection usage and gaps",
            "Write grants for programming and preservation",
            "Digitize materials and manage digital access",
            "Collaborate with schools and community partners",
            "Maintain quiet study and public access spaces",
            "Document policies and emergency procedures",
            "Promote library services through marketing"
        ],
        "quotes": [
            "Read widely, think deeply, act boldly. — Unknown",
            "Libraries are gateways to lifelong learning. — Unknown",
            "Preserve knowledge; share it generously. — Unknown",
            "Curate with community needs in mind. — Unknown",
            "Access to information empowers people. — Unknown",
            "Organize so others can find what they need. — Unknown",
            "Teach research skills; they last a lifetime. — Unknown",
            "Celebrate curiosity and discovery. — Unknown",
            "Digitize thoughtfully; preserve context. — Unknown",
            "Libraries build community through shared resources. — Unknown"
        ]
    },

    "translator": {
        "tasks": [
            "Review source text and clarify terminology",
            "Translate content while preserving tone and intent",
            "Localize idioms and cultural references appropriately",
            "Proofread and edit translated drafts",
            "Maintain glossaries and translation memories",
            "Coordinate with subject-matter experts for accuracy",
            "Format translated documents to match originals",
            "Manage deadlines and client expectations",
            "Perform quality assurance checks on final files",
            "Update translation memories with new terms",
            "Provide localization recommendations for UI/UX",
            "Handle confidential documents with care",
            "Prepare bilingual glossaries for recurring clients",
            "Adapt marketing copy for target audiences",
            "Translate subtitles and timecode accurately",
            "Work with voice talent for localized audio",
            "Maintain consistent terminology across projects",
            "Estimate project timelines and resource needs",
            "Train junior translators on style guides",
            "Collect client feedback and refine translations"
        ],
        "quotes": [
            "Translate meaning, not just words. — Unknown",
            "Context is the translator’s compass. — Unknown",
            "Maintain tone and intent across languages. — Unknown",
            "Glossaries preserve consistency and speed. — Unknown",
            "Localize for culture, not just language. — Unknown",
            "Proofread carefully; nuance matters. — Unknown",
            "Communicate ambiguities to clients early. — Unknown",
            "Build translation memories to scale quality. — Unknown",
            "Respect confidentiality in sensitive texts. — Unknown",
            "Keep learning; languages evolve. — Unknown"
        ]
    },

    "museum curator": {
        "tasks": [
            "Research and acquire objects for the collection",
            "Develop exhibition concepts and narratives",
            "Write labels and interpretive materials",
            "Coordinate conservation and storage of artifacts",
            "Plan installation logistics and layouts",
            "Manage loans and provenance documentation",
            "Develop educational programs and tours",
            "Prepare grant applications for exhibitions",
            "Collaborate with designers on exhibit fabrication",
            "Conduct object condition reports and conservation",
            "Engage with donors and patrons for support",
            "Maintain collection databases and metadata",
            "Plan public programming and opening events",
            "Evaluate visitor feedback and attendance metrics",
            "Coordinate with marketing for exhibition promotion",
            "Document accession and deaccession processes",
            "Train docents and volunteer guides",
            "Research and publish on collection items",
            "Ensure ethical stewardship and repatriation policies",
            "Plan long-term collection care and storage"
        ],
        "quotes": [
            "Curate with care; objects carry stories. — Unknown",
            "Context transforms objects into meaning. — Unknown",
            "Preserve for future generations; stewardship matters. — Unknown",
            "Interpretation invites visitors into the story. — Unknown",
            "Collaborate across disciplines for richer exhibits. — Unknown",
            "Document provenance; it honors history. — Unknown",
            "Engage communities to make collections relevant. — Unknown",
            "Conservation protects both object and story. — Unknown",
            "Exhibitions are conversations, not monologues. — Unknown",
            "Measure impact to inform future curation. — Unknown"
        ]
    },

    "nonprofit director": {
        "tasks": [
            "Define organizational strategy and mission-aligned goals",
            "Manage fundraising and donor relations",
            "Oversee program delivery and impact measurement",
            "Prepare budgets and monitor financial health",
            "Lead board meetings and governance processes",
            "Develop partnerships with community organizations",
            "Ensure compliance with nonprofit regulations",
            "Hire and develop senior staff and leaders",
            "Represent the organization at public events",
            "Prepare grant proposals and reports",
            "Monitor program outcomes and iterate on design",
            "Manage communications and storytelling",
            "Coordinate volunteer programs and training",
            "Develop risk management and contingency plans",
            "Advocate for policy changes aligned with mission",
            "Ensure transparency and accountability to stakeholders",
            "Build a culture of inclusion and equity",
            "Measure and report social impact metrics",
            "Plan strategic retreats and planning sessions",
            "Document policies and succession plans"
        ],
        "quotes": [
            "Mission-driven work requires both heart and rigor. — Unknown",
            "Measure impact to tell a credible story. — Unknown",
            "Build partnerships; collective action scales impact. — Unknown",
            "Donor trust is earned through transparency. — Unknown",
            "Invest in people; programs follow. — Unknown",
            "Listen to the communities you serve. — Unknown",
            "Sustainability requires diversified funding. — Unknown",
            "Document outcomes; funders value evidence. — Unknown",
            "Lead with humility and accountability. — Unknown",
            "Celebrate small wins; they sustain momentum. — Unknown"
        ]
    },

    "fitness trainer": {
        "tasks": [
            "Assess client fitness levels and goals",
            "Design personalized training programs",
            "Demonstrate proper exercise technique and form",
            "Track client progress and adjust plans",
            "Provide nutritional guidance within scope",
            "Lead group classes and motivate participants",
            "Ensure safety and injury prevention during sessions",
            "Prepare warm-up and cool-down routines",
            "Create progress reports and milestone plans",
            "Maintain equipment and clean workout spaces",
            "Onboard new clients and set expectations",
            "Run fitness assessments periodically",
            "Educate clients on recovery and sleep importance",
            "Coordinate with healthcare providers when needed",
            "Plan specialty workshops or bootcamps",
            "Manage scheduling and client communications",
            "Collect testimonials and success stories",
            "Stay current with exercise science research",
            "Offer modifications for special populations",
            "Promote long-term habit formation and consistency"
        ],
        "quotes": [
            "Small habits shape big outcomes. — James Clear (adapted)",
            "Consistency compounds; show up and progress follows. — Unknown",
            "Form first, load second. — Unknown",
            "Recovery is part of training; respect it. — Unknown",
            "Measure progress, not perfection. — Unknown",
            "Coach the person, not just the workout. — Unknown",
            "Nutrition supports performance; plan accordingly. — Unknown",
            "Set realistic goals and celebrate milestones. — Unknown",
            "Teach clients to be their own coach. — Unknown",
            "Movement is medicine; prescribe it wisely. — Unknown"
        ]
    },

    "yoga instructor": {
        "tasks": [
            "Plan class sequences aligned to themes and levels",
            "Lead mindful warm-ups and breathwork",
            "Demonstrate safe alignment and offer modifications",
            "Create playlists and set the class tone",
            "Provide hands-on adjustments with consent",
            "Offer restorative and mobility-focused sessions",
            "Guide students through relaxation and meditation",
            "Manage class scheduling and student communications",
            "Develop workshops on specific practices",
            "Maintain props and studio cleanliness",
            "Onboard new students and assess needs",
            "Adapt classes for injuries and special populations",
            "Collect feedback and refine class flow",
            "Promote classes and community events",
            "Continue personal practice and teacher training",
            "Coordinate retreats and longer-form offerings",
            "Document sequences and cueing notes",
            "Support students with home practice plans",
            "Ensure safety and inclusivity in classes",
            "Build relationships within the yoga community"
        ],
        "quotes": [
            "Begin anywhere; practice is the path. — John Cage (adapted)",
            "Breath anchors the body and mind. — Unknown",
            "Consistency in practice reveals progress. — Unknown",
            "Listen to your body; honor its limits. — Unknown",
            "Teach with compassion and clarity. — Unknown",
            "Small daily practice compounds into transformation. — Unknown",
            "Presence is the most powerful cue. — Unknown",
            "Create space for stillness and reflection. — Unknown",
            "Adaptations make practice accessible. — Unknown",
            "Practice with curiosity, not judgment. — Unknown"
        ]
    },

    "nutritionist": {
        "tasks": [
            "Assess client dietary intake and goals",
            "Develop personalized meal plans and guidelines",
            "Educate clients on macronutrients and portioning",
            "Monitor progress and adjust recommendations",
            "Coordinate with healthcare providers for medical conditions",
            "Run group nutrition workshops and cooking demos",
            "Analyze food diaries and identify patterns",
            "Provide evidence-based guidance on supplements",
            "Create resources and handouts for clients",
            "Support behavior change and habit formation",
            "Prepare nutrition protocols for special populations",
            "Evaluate food labels and product recommendations",
            "Stay current with nutrition research and guidelines",
            "Develop meal prep templates and shopping lists",
            "Measure outcomes and client satisfaction",
            "Document consultations and follow-up plans",
            "Advise on sports nutrition and performance fueling",
            "Plan community outreach and education",
            "Train staff on basic nutrition literacy",
            "Collect testimonials and case studies"
        ],
        "quotes": [
            "Hydrate, nourish, repeat. — Unknown",
            "Small changes in diet compound into health. — Unknown",
            "Personalization beats one-size-fits-all advice. — Unknown",
            "Focus on sustainable habits, not quick fixes. — Unknown",
            "Food is medicine when used thoughtfully. — Unknown",
            "Measure progress with behavior and outcomes. — Unknown",
            "Educate to empower long-term change. — Unknown",
            "Balance and variety support adherence. — Unknown",
            "Plan meals to reduce decision fatigue. — Unknown",
            "Listen to the client's context; it guides recommendations. — Unknown"
        ]
    },

    "it support specialist": {
        "tasks": [
            "Respond to helpdesk tickets and prioritize issues",
            "Troubleshoot hardware and software problems",
            "Reset passwords and manage account access",
            "Install and configure workstations and peripherals",
            "Maintain inventory of devices and licenses",
            "Document solutions in a knowledge base",
            "Perform remote support and screen sharing sessions",
            "Coordinate escalations to engineering teams",
            "Deploy updates and security patches",
            "Onboard and offboard employees with IT access",
            "Monitor system alerts and respond to incidents",
            "Run basic network diagnostics and fixes",
            "Support conference room AV and meeting setups",
            "Train users on common tools and best practices",
            "Manage backups and verify restores for endpoints",
            "Maintain endpoint security and antivirus updates",
            "Prepare reports on ticket trends and SLAs",
            "Test new hardware and provide recommendations",
            "Ensure compliance with IT policies",
            "Participate in disaster recovery drills"
        ],
        "quotes": [
            "Read the error; it’s trying to help you. — Unknown",
            "Document fixes so others can repeat them. — Unknown",
            "Automate repetitive tasks to save time. — Unknown",
            "Communicate clearly with users; empathy reduces frustration. — Unknown",
            "Keep systems patched; prevention beats remediation. — Unknown",
            "Backups are insurance; verify restores regularly. — Unknown",
            "Train users; many issues are avoidable. — Unknown",
            "Prioritize security in every change. — Unknown",
            "Measure ticket trends to prevent recurring problems. — Unknown",
            "Be patient; technology is a tool for people. — Unknown"
        ]
    }
}

# ---------------------------
# Helpers to build tasks & quotes for non-curated professions
# ---------------------------
ACTIONS = ["Review", "Prepare", "Plan", "Schedule", "Follow up on", "Draft", "Update", "Coordinate", "Research", "Test", "Inspect", "Audit", "Analyze", "Document"]
ROLE_TASKS = ["daily priorities", "weekly roadmap", "project timeline", "client feedback", "team backlog", "safety checks", "quality metrics", "performance reports", "user stories", "test cases"]
ROLE_VERBS = ["with stakeholders", "for the team", "for the client", "for production", "for review", "and document findings", "and assign owners", "and set deadlines"]

def build_tasks_for_profession(profession: str, count: int = 12):
    rnd = random.Random(profession)
    actions = rnd.sample(ACTIONS, k=len(ACTIONS))
    role_tasks = rnd.sample(ROLE_TASKS, k=len(ROLE_TASKS))
    role_verbs = rnd.sample(ROLE_VERBS, k=len(ROLE_VERBS))
    tasks = []
    i = 0
    prof_title = profession.title()
    while len(tasks) < count:
        a = actions[i % len(actions)]
        rt = role_tasks[i % len(role_tasks)]
        rv = role_verbs[i % len(role_verbs)]
        if i % 6 == 0:
            t = f"{a} {rt} for {prof_title} {rv}"
        elif i % 6 == 1:
            t = f"{a} the {rt} and prepare a short summary"
        elif i % 6 == 2:
            t = f"{a} the {rt} and share findings with stakeholders"
        elif i % 6 == 3:
            t = f"{a} a quick check on {rt} and log any issues"
        elif i % 6 == 4:
            t = f"{a} {rt} and {rv}"
        else:
            t = f"{a} {rt} and schedule next steps"
        if t not in tasks:
            tasks.append(t)
        i += 1
    return tasks[:count]

def build_quote_pool_for_profession(profession: str, count: int) -> list:
    pool = []
    curated = CURATED_TEMPLATES.get(profession.lower(), {}).get("quotes", [])
    for q in curated:
        if q not in pool:
            pool.append(q)
        if len(pool) >= count:
            return pool[:count]
    for q in BASE_QUOTES:
        if q not in pool:
            pool.append(q)
        if len(pool) >= count:
            return pool[:count]
    attempts = 0
    while len(pool) < count and attempts < count * 6:
        q = generate_programmatic_quote(profession)
        if q not in pool:
            pool.append(q)
        attempts += 1
    idx = 0
    while len(pool) < count:
        pool.append(f"{BASE_QUOTES[idx % len(BASE_QUOTES)]} (variant {idx // len(BASE_QUOTES) + 1})")
        idx += 1
    return pool[:count]

# ---------------------------
# Cross-platform TTS (no pip)
# ---------------------------
def _escape_for_powershell(s: str) -> str:
    return s.replace("'", "''")

def speak_text(text: str, filename: str | None = None, rate: int | None = None) -> bool:
    text = text.strip()
    if not text:
        return False
    platform = sys.platform

    # macOS
    if platform == "darwin":
        say_cmd = shutil.which("say")
        if not say_cmd:
            return False
        if filename:
            try:
                subprocess.run([say_cmd, "-o", filename, text], check=True)
                return True
            except Exception:
                return False
        else:
            cmd = [say_cmd]
            if rate:
                cmd += ["-r", str(rate)]
            cmd += [text]
            try:
                subprocess.run(cmd, check=True)
                return True
            except Exception:
                return False

    # Windows
    if platform.startswith("win"):
        pwsh = shutil.which("powershell") or shutil.which("pwsh")
        if not pwsh:
            return False
        safe_text = _escape_for_powershell(text)
        if filename:
            safe_file = filename.replace("'", "''")
            ps = (
                f"Add-Type -AssemblyName System.speech;"
                f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                f"$s.SetOutputToWaveFile('{safe_file}');"
                f"$s.Speak('{safe_text}');"
                f"$s.Dispose();"
            )
        else:
            ps = (
                f"Add-Type -AssemblyName System.speech;"
                f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe_text}');"
            )
        try:
            subprocess.run([pwsh, "-NoProfile", "-Command", ps], check=True)
            return True
        except Exception:
            return False

    # Linux / BSD
    if platform.startswith("linux") or platform.startswith("freebsd"):
        espeak = shutil.which("espeak")
        spd = shutil.which("spd-say")
        if filename and espeak:
            try:
                subprocess.run([espeak, "-w", filename, text], check=True)
                return True
            except Exception:
                return False
        if spd:
            try:
                subprocess.run([spd, text], check=True)
                return True
            except Exception:
                return False
        if espeak:
            try:
                subprocess.run([espeak, text], check=True)
                return True
            except Exception:
                return False
        return False

    return False

# ---------------------------
# Printing helpers
# ---------------------------
def pretty_print_todo(profession: str, tasks: list, quotes: list, show_tasks: bool = True, show_quotes: bool = True):
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    header = f"To‑Do List for {profession.title()} — {now}"
    print("\n" + "=" * len(header))
    print(header)
    print("=" * len(header))
    if show_tasks:
        print("Tasks:")
        for i, t in enumerate(tasks, 1):
            print(f"{i}. {t}")
    if show_quotes:
        print("\nQuotes:")
        for i, q in enumerate(quotes, 1):
            print(f"{i}. {q}")
    print()

def tts_for_profession(profession: str, tasks: list, quotes: list, speak_tasks: bool, speak_quotes: bool, save_files: bool):
    safe_prof = profession.replace(" ", "_").lower()
    print(f"\nTTS for {profession}:")
    timestamp_base = datetime.now().strftime("%Y%m%d_%H%M%S")
    if speak_tasks:
        for idx, task in enumerate(tasks, 1):
            filename = None
            if save_files:
                ext = "wav" if not sys.platform == "darwin" else "aiff"
                filename = f"tts_{safe_prof}_task_{idx}_{timestamp_base}.{ext}"
            ok = speak_text(task, filename=filename)
            if ok:
                if filename:
                    print(f"  Saved task audio: {filename}")
                else:
                    print(f"  Played task: {task[:60]}...")
            else:
                print("  TTS not available for tasks on this system or tool missing.")
                return
    if speak_quotes:
        for idx, quote in enumerate(quotes, 1):
            filename = None
            if save_files:
                ext = "wav" if not sys.platform == "darwin" else "aiff"
                filename = f"tts_{safe_prof}_quote_{idx}_{timestamp_base}.{ext}"
            ok = speak_text(quote, filename=filename)
            if ok:
                if filename:
                    print(f"  Saved quote audio: {filename}")
                else:
                    print(f"  Played quote: {quote[:60]}...")
            else:
                print("  TTS not available for quotes on this system or tool missing.")
                return

# ---------------------------
# Interactive CLI
# ---------------------------
def prompt_user():
    print("To‑Do + Quote Generator — enter profession(s) and options")
    prof_input = input("Enter profession(s) or role(s) (comma-separated, e.g., 'teacher, chef'): ").strip()
    if not prof_input:
        prof_input = "professional"
    professions = [p.strip() for p in prof_input.split(",") if p.strip()]
    try:
        num_tasks = int(input("How many tasks per profession? (default 8): ") or "8")
    except ValueError:
        num_tasks = 8
    num_tasks = max(1, min(50, num_tasks))
    try:
        num_quotes = int(input("How many quotes per profession? (default 6): ") or "6")
    except ValueError:
        num_quotes = 6
    num_quotes = max(1, min(200, num_quotes))
    save_answer = input("Save output to JSON file? (y/N): ").strip().lower()
    save = save_answer == "y"
    tts_play = input("Play TTS now? (y/N): ").strip().lower() == "y"
    tts_save = False
    if tts_play:
        tts_save = input("Save TTS to audio files as well? (y/N): ").strip().lower() == "y"
    speak_tasks = False
    speak_quotes = False
    if tts_play:
        mode = input("Speak tasks, quotes, or both? (tasks/quotes/both) [both]: ").strip().lower() or "both"
        speak_tasks = mode in ("tasks", "both")
        speak_quotes = mode in ("quotes", "both")
    return professions, num_tasks, num_quotes, save, tts_play, tts_save, speak_tasks, speak_quotes

def generate_todo_and_quotes(profession: str, num_tasks: int = 5, num_quotes: int = 3):
    curated = CURATED_TEMPLATES.get(profession.lower())
    if curated:
        tasks = curated["tasks"][:num_tasks] if len(curated["tasks"]) >= num_tasks else curated["tasks"] + build_tasks_for_profession(profession, num_tasks - len(curated["tasks"]))
        quotes = build_quote_pool_for_profession(profession, num_quotes)
        # ensure curated quotes appear first if present
        base_q = curated.get("quotes", [])
        combined = []
        for q in base_q + quotes:
            if q not in combined:
                combined.append(q)
        quotes = combined[:num_quotes]
    else:
        tasks = build_tasks_for_profession(profession, num_tasks)
        quotes = build_quote_pool_for_profession(profession, num_quotes)
    return tasks, quotes

def main():
    while True:
        professions, num_tasks, num_quotes, save, tts_play, tts_save, speak_tasks, speak_quotes = prompt_user()

        # Generate and display to-do lists and the requested quotes (do NOT print BASE_QUOTES list)
        results = {}
        for prof in professions:
            tasks, quotes = generate_todo_and_quotes(prof, num_tasks, num_quotes)
            results[prof.title()] = {"tasks": tasks, "quotes": quotes}
            pretty_print_todo(prof, tasks, quotes, show_tasks=True, show_quotes=True)

        # Save results if requested
        if save:
            now = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"todo_quotes_full_{now}.json"
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(results, f, ensure_ascii=False, indent=2)
            print(f"\nSaved all results to {filename}")

        # TTS if requested
        if tts_play:
            for prof, data in results.items():
                tts_for_profession(prof, data["tasks"], data["quotes"], speak_tasks=speak_tasks, speak_quotes=speak_quotes, save_files=tts_save)

        # Repeat or quit prompt
        again = input("\nGenerate another to‑do list? (y/N): ").strip().lower()
        if again != "y":
            print("Goodbye.")
            break

if __name__ == "__main__":
    main()
