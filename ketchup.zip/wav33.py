#!/usr/bin/env python3
"""
win_mci_rec_no_external_deps_wrapped_ui_save_edited_with_scroll.py

Adds a horizontal scrollbar to the waveform canvas so long audio can be scrolled.
No external dependencies. Windows-only (MCI).
"""

import os
import sys
import wave
import struct
import tempfile
import ctypes
import math
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import shutil
import time
import traceback
import threading
import random

if sys.platform != "win32":
    raise SystemExit("This script runs on Windows only.")

# ----------------- MCI wrapper -----------------

_winmm = ctypes.windll.winmm
_mciSendString = _winmm.mciSendStringW
_MCI_BUFFER_LEN = 1024

def mci_send(cmd: str) -> str:
    buf = ctypes.create_unicode_buffer(_MCI_BUFFER_LEN)
    err = _mciSendString(cmd, buf, _MCI_BUFFER_LEN, 0)
    if err != 0:
        errbuf = ctypes.create_unicode_buffer(_MCI_BUFFER_LEN)
        _winmm.mciGetErrorStringW(err, errbuf, _MCI_BUFFER_LEN)
        raise RuntimeError(f"MCI error {err}: {errbuf.value} (cmd: {cmd})")
    return buf.value

# ----------------- Helpers -----------------

def _safe_clamp_float(v):
    if not math.isfinite(v):
        return 0.0
    if v > 1.0:
        return 1.0
    if v < -1.0:
        return -1.0
    return v

def _ensure_uncompressed_wave(wf: wave.Wave_read):
    comp = wf.getcomptype()
    if comp != "NONE":
        raise RuntimeError(f"Unsupported WAV compression type: {comp}")

def _unpack_24bit_to_ints(raw):
    n_samples = len(raw) // 3
    ints = []
    for i in range(n_samples):
        b0 = raw[i*3 + 0]
        b1 = raw[i*3 + 1]
        b2 = raw[i*3 + 2]
        val = b0 | (b1 << 8) | (b2 << 16)
        if val & 0x800000:
            val = val - 0x1000000
        ints.append(val)
    return ints

# ----------------- Simple writers and converters (no external deps) -----------------

def convert_float_to_16bit_and_write(dest_path, floats, samplerate):
    ints16 = [int(round(max(-1.0, min(1.0, v)) * 32767.0)) for v in floats]
    with wave.open(dest_path, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(samplerate)
        wf.writeframes(struct.pack('<{}h'.format(len(ints16)), *ints16))

def float32_wav_to_temp_16bit(src_path):
    with wave.open(src_path, 'rb') as wf:
        _ensure_uncompressed_wave(wf)
        sw = wf.getsampwidth()
    if sw == 4:
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav"); tmp.close()
        try:
            convert_float32_wav_to_16bit(src_path, tmp.name, keep_channels=False)
            return tmp.name
        except Exception:
            try: os.remove(tmp.name)
            except Exception: pass
            raise
    elif sw == 3:
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav"); tmp.close()
        try:
            convert_24bit_wav_to_16bit(src_path, tmp.name, keep_channels=False)
            return tmp.name
        except Exception:
            try: os.remove(tmp.name)
            except Exception: pass
            raise
    elif sw == 2:
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav"); tmp.close()
        with open(src_path, 'rb') as s, open(tmp.name, 'wb') as d:
            d.write(s.read())
        return tmp.name
    elif sw == 1:
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav"); tmp.close()
        try:
            with wave.open(src_path, 'rb') as wf:
                nch = wf.getnchannels()
                fr = wf.getframerate()
                raw = wf.readframes(wf.getnframes())
            ints8 = list(raw)
            if nch == 1:
                floats = [ (i - 128) / 128.0 for i in ints8 ]
            else:
                floats = []
                for i in range(0, len(ints8), nch):
                    s = sum(ints8[i + ch] for ch in range(nch)) / nch
                    floats.append((s - 128.0) / 128.0)
            convert_float_to_16bit_and_write(tmp.name, floats, fr)
            return tmp.name
        except Exception:
            try: os.remove(tmp.name)
            except Exception: pass
            raise
    else:
        raise RuntimeError("Unsupported sample width for playback conversion.")

# Minimal implementations referenced above (24/float->16 converters)
def convert_24bit_wav_to_16bit(src_path, dest_path, keep_channels=False, target_samplerate=None, force_stereo=False):
    with wave.open(src_path, 'rb') as wf:
        _ensure_uncompressed_wave(wf)
        nch = wf.getnchannels()
        fr = wf.getframerate()
        raw = wf.readframes(wf.getnframes())
    ints24 = _unpack_24bit_to_ints(raw)
    out_sr = target_samplerate if target_samplerate else fr
    if nch == 1:
        mono = [v / 8388608.0 for v in ints24]
    else:
        mono = []
        for i in range(0, len(ints24), nch):
            s = 0
            for ch in range(nch):
                s += ints24[i + ch]
            s = s / nch
            mono.append(s / 8388608.0)
    convert_float_to_16bit_and_write(dest_path, mono, out_sr)

def convert_float32_wav_to_16bit(src_path, dest_path, keep_channels=False, target_samplerate=None, force_stereo=False):
    with wave.open(src_path, 'rb') as wf:
        _ensure_uncompressed_wave(wf)
        nch = wf.getnchannels()
        fr = wf.getframerate()
        raw = wf.readframes(wf.getnframes())
    count = len(raw) // 4
    if count == 0:
        with wave.open(dest_path, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(target_samplerate or fr)
            wf.writeframes(b'')
        return
    floats = None
    try:
        floats = struct.unpack('<{}f'.format(count), raw)
    except struct.error:
        ints32 = struct.unpack('<{}i'.format(count), raw)
        floats = [max(-1.0, min(1.0, v / 2147483647.0)) for v in ints32]
    out_sr = target_samplerate or fr
    if nch == 1:
        mono = [float(v) for v in floats]
    else:
        mono = []
        for i in range(0, len(floats), nch):
            s = 0.0
            for ch in range(nch):
                s += floats[i + ch]
            s = s / nch
            mono.append(s)
    convert_float_to_16bit_and_write(dest_path, mono, out_sr)

# ----------------- Validation helper -----------------

def validate_and_rewrite_wav(path):
    try:
        with wave.open(path, 'rb') as wf:
            _ensure_uncompressed_wave(wf)
            wf.rewind()
            wf.readframes(min(1024, wf.getnframes()))
        return True
    except Exception:
        return False

# ----------------- GUI Application with wrapped controls + Save Edited + Scrollbar -----------------

class WinMCIRecorderApp:
    def __init__(self, root):
        self.root = root
        root.title("Windows Recorder — Scrollable Waveform")
        root.minsize(820, 420)

        # Canvas base size (visible area)
        self.canvas_w = 900
        self.canvas_h = 300

        # Frame to hold canvas + scrollbar
        self.canvas_frame = ttk.Frame(root)
        self.canvas_frame.pack(padx=8, pady=(8,4), fill="both", expand=True)

        # Canvas for waveform (scrollable)
        self.canvas = tk.Canvas(self.canvas_frame, width=self.canvas_w, height=self.canvas_h, bg="black", highlightthickness=0)
        self.h_scroll = ttk.Scrollbar(self.canvas_frame, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(xscrollcommand=self.h_scroll.set)

        # Pack canvas and scrollbar
        self.canvas.pack(side="top", fill="both", expand=True)
        self.h_scroll.pack(side="bottom", fill="x")

        # Control rows
        self.ctrl_top = ttk.Frame(root); self.ctrl_top.pack(fill="x", padx=6, pady=(4,2))
        self.ctrl_mid = ttk.Frame(root); self.ctrl_mid.pack(fill="x", padx=6, pady=2)
        self.ctrl_bottom = ttk.Frame(root); self.ctrl_bottom.pack(fill="x", padx=6, pady=(2,8))

        btn_w = 12

        # Top row: recording / playback / load / save / save edited
        self.record_btn = ttk.Button(self.ctrl_top, text="Record", width=btn_w, command=self.start_record)
        self.record_btn.grid(row=0, column=0, padx=3, pady=2)
        self.stop_btn = ttk.Button(self.ctrl_top, text="Stop & Save", width=btn_w, command=self.stop_and_save, state="disabled")
        self.stop_btn.grid(row=0, column=1, padx=3, pady=2)
        self.play_record_btn = ttk.Button(self.ctrl_top, text="Play Rec", width=btn_w, command=self.play_record, state="disabled")
        self.play_record_btn.grid(row=0, column=2, padx=3, pady=2)
        self.load_btn = ttk.Button(self.ctrl_top, text="Load WAV", width=btn_w, command=self.load_wav)
        self.load_btn.grid(row=0, column=3, padx=3, pady=2)
        self.save_copy_btn = ttk.Button(self.ctrl_top, text="Save Copy", width=btn_w, command=self.save_copy, state="disabled")
        self.save_copy_btn.grid(row=0, column=4, padx=3, pady=2)
        self.play_btn = ttk.Button(self.ctrl_top, text="Play WAV", width=btn_w, command=self.play_wav, state="disabled")
        self.play_btn.grid(row=0, column=5, padx=3, pady=2)
        self.stop_play_btn = ttk.Button(self.ctrl_top, text="Stop Play", width=btn_w, command=self.stop_play, state="disabled")
        self.stop_play_btn.grid(row=0, column=6, padx=3, pady=2)
        self.save_edited_btn = ttk.Button(self.ctrl_top, text="Save Edited", width=btn_w, command=self.save_edited_wav, state="disabled")
        self.save_edited_btn.grid(row=0, column=7, padx=3, pady=2)

        # Middle row: conversions and sample rate + options
        self.conv32_btn = ttk.Button(self.ctrl_mid, text="To 32-bit", width=btn_w, command=self.convert_to_32bit, state="disabled")
        self.conv32_btn.grid(row=0, column=0, padx=3, pady=2)
        self.conv16_btn = ttk.Button(self.ctrl_mid, text="To 16-bit", width=btn_w, command=self.convert_to_16bit, state="disabled")
        self.conv16_btn.grid(row=0, column=1, padx=3, pady=2)

        self.preserve_var = tk.BooleanVar(value=False)
        self.preserve_chk = ttk.Checkbutton(self.ctrl_mid, text="Preserve", variable=self.preserve_var)
        self.preserve_chk.grid(row=0, column=2, padx=6, pady=2)

        self.force_stereo_var = tk.BooleanVar(value=False)
        self.force_stereo_chk = ttk.Checkbutton(self.ctrl_mid, text="Force Stereo", variable=self.force_stereo_var)
        self.force_stereo_chk.grid(row=0, column=3, padx=6, pady=2)

        ttk.Label(self.ctrl_mid, text="Target SR:").grid(row=0, column=4, padx=(12,2))
        self.sample_rate_var = tk.IntVar(value=44100)
        self.sr_spin = tk.Spinbox(self.ctrl_mid, from_=8000, to=192000, increment=100, textvariable=self.sample_rate_var, width=8)
        self.sr_spin.grid(row=0, column=5, padx=3, pady=2)

        # Bottom row: noise controls + clipboard group
        self.capture_noise_btn = ttk.Button(self.ctrl_bottom, text="Capture Noise", width=btn_w, command=self.capture_noise_profile)
        self.capture_noise_btn.grid(row=0, column=0, padx=3, pady=2)
        self.remove_noise_btn = ttk.Button(self.ctrl_bottom, text="Remove Noise", width=btn_w, command=self.remove_background, state="disabled")
        self.remove_noise_btn.grid(row=0, column=1, padx=3, pady=2)
        self.export_noise_btn = ttk.Button(self.ctrl_bottom, text="Export Noise", width=btn_w, command=self.export_noise_only, state="disabled")
        self.export_noise_btn.grid(row=0, column=2, padx=3, pady=2)

        # Clipboard controls grouped to the right of bottom row
        self.clipboard_frame = ttk.Frame(self.ctrl_bottom)
        self.clipboard_frame.grid(row=0, column=6, sticky="e", padx=6)
        self.cut_btn = ttk.Button(self.clipboard_frame, text="Cut", width=8, command=self.cut_selection, state="disabled")
        self.cut_btn.grid(row=0, column=0, padx=2)
        self.copy_btn = ttk.Button(self.clipboard_frame, text="Copy", width=8, command=self.copy_selection, state="disabled")
        self.copy_btn.grid(row=0, column=1, padx=2)
        self.paste_btn = ttk.Button(self.clipboard_frame, text="Paste", width=8, command=self.paste_clipboard, state="disabled")
        self.paste_btn.grid(row=0, column=2, padx=2)
        self.delete_btn = ttk.Button(self.clipboard_frame, text="Delete", width=8, command=self.delete_selection, state="disabled")
        self.delete_btn.grid(row=0, column=3, padx=2)
        self.clear_clipboard_btn = ttk.Button(self.clipboard_frame, text="Clear", width=8, command=self.clear_clipboard)
        self.clear_clipboard_btn.grid(row=0, column=4, padx=2)

        # Status label
        self.status = ttk.Label(root, text="Ready")
        self.status.pack(fill="x", padx=8, pady=(4,8))

        # Internal state
        self._alias = "recsound"
        self._is_recording = False
        self.wav_path = None
        self.samples = []
        self.samplerate = 44100

        # Playback state
        self._is_playing = False
        self._play_alias = "playback"
        self._play_tmp = None
        self._play_thread = None

        # Last recording temp file
        self._last_record_tmp = None

        # Noise profile state
        self._noise_profile = None

        # Clipboard and selection
        self._clipboard = []
        self.sel_start = None
        self.sel_end = None
        self._selection_rect = None
        self._mouse_down = False

        # Virtual canvas width (for scrollregion)
        self._virtual_width = self.canvas_w

        # Bind mouse events for selection on canvas
        self.canvas.bind("<ButtonPress-1>", self._on_canvas_mouse_down)
        self.canvas.bind("<B1-Motion>", self._on_canvas_mouse_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_canvas_mouse_up)

        # Redraw when canvas resized
        self.canvas.bind("<Configure>", lambda e: self.draw_waveform(self.samples))

        # Make grid columns expand sensibly
        for i in range(0, 9):
            self.ctrl_top.grid_columnconfigure(i, weight=1)
            self.ctrl_mid.grid_columnconfigure(i, weight=1)
            self.ctrl_bottom.grid_columnconfigure(i, weight=1)

    def set_status(self, text):
        self.status.config(text=text)

    # ----------------- Recording -----------------

    def start_record(self):
        if self._last_record_tmp and os.path.exists(self._last_record_tmp):
            try:
                os.remove(self._last_record_tmp)
            except Exception:
                pass
            self._last_record_tmp = None
            self.play_record_btn.config(state="disabled")

        try:
            try: mci_send(f"close {self._alias}")
            except Exception: pass
            mci_send(f'open new type waveaudio alias {self._alias}')
            mci_send(f"record {self._alias}")
        except Exception as e:
            messagebox.showerror("Record error", f"Could not start recording:\n{e}")
            return
        self._is_recording = True
        self.record_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.play_btn.config(state="disabled")
        self.conv32_btn.config(state="disabled")
        self.conv16_btn.config(state="disabled")
        self.save_copy_btn.config(state="disabled")
        self.save_edited_btn.config(state="disabled")
        self.set_status("Recording... Click Stop & Save to finish.")

    def stop_and_save(self):
        if not self._is_recording:
            return
        try:
            mci_send(f"stop {self._alias}")
        except Exception:
            pass

        tmp16 = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
        tmp16.close()
        tmp16_path = tmp16.name
        try:
            abs_tmp = os.path.abspath(tmp16_path)
            mci_send(f'save {self._alias} "{abs_tmp}"')
        except Exception as e:
            try:
                mci_send(f"close {self._alias}")
            except Exception:
                pass
            try:
                os.remove(tmp16_path)
            except Exception:
                pass
            messagebox.showerror("Save error", f"Could not save recording:\n{e}")
            self._is_recording = False
            self.record_btn.config(state="normal")
            self.stop_btn.config(state="disabled")
            self.set_status("Recording failed")
            return

        try:
            mci_send(f"close {self._alias}")
        except Exception:
            pass

        prev_size = -1
        stable_count = 0
        max_checks = 40
        for _ in range(max_checks):
            if os.path.exists(tmp16_path):
                try:
                    size = os.path.getsize(tmp16_path)
                except Exception:
                    size = -1
                if size > 0 and size == prev_size:
                    stable_count += 1
                else:
                    stable_count = 0
                prev_size = size
                if stable_count >= 3 and size > 0:
                    break
            time.sleep(0.05)
        time.sleep(0.1)

        if not os.path.exists(tmp16_path) or os.path.getsize(tmp16_path) == 0:
            try:
                os.remove(tmp16_path)
            except Exception:
                pass
            messagebox.showerror("Save error", "Recording file not created by MCI or is empty.")
            self._is_recording = False
            self.record_btn.config(state="normal")
            self.stop_btn.config(state="disabled")
            self.set_status("Recording failed")
            return

        try:
            with wave.open(tmp16_path, 'rb') as wf:
                _ensure_uncompressed_wave(wf)
        except Exception as e:
            try:
                os.remove(tmp16_path)
            except Exception:
                pass
            messagebox.showerror("Save error", f"Temporary recording is not a valid WAV:\n{e}")
            self._is_recording = False
            self.record_btn.config(state="normal")
            self.stop_btn.config(state="disabled")
            self.set_status("Recording failed")
            return

        if self._last_record_tmp and os.path.exists(self._last_record_tmp):
            try:
                os.remove(self._last_record_tmp)
            except Exception:
                pass
        self._last_record_tmp = tmp16_path
        self.play_record_btn.config(state="normal")

        self._is_recording = False
        self.record_btn.config(state="normal")
        self.stop_btn.config(state="disabled")

        dest = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("WAV files","*.wav")], title="Save recording as (16-bit PCM)")
        if not dest:
            self.set_status("Recording saved to temporary file (use Play Rec or Save Copy).")
            return

        try:
            shutil.copyfile(tmp16_path, dest)
        except Exception as e:
            tb = traceback.format_exc()
            print(tb)
            messagebox.showerror("Save error", f"Could not save recording:\n{e}")
            self.set_status("Save failed")
            return

        ok = validate_and_rewrite_wav(dest)
        if not ok:
            messagebox.showwarning("Saved but invalid", f"Saved file to {dest} but it appears invalid.")
            self.wav_path = dest
            self.set_status(f"Saved (invalid) WAV: {os.path.basename(dest)}")
            return

        try:
            fr, samples = self._read_wav_for_display(dest)
            self.wav_path = dest
            self.samples = samples
            self.samplerate = fr
            self.draw_waveform(samples)
            self.play_btn.config(state="normal")
            self.conv32_btn.config(state="normal")
            self.conv16_btn.config(state="normal")
            self.save_copy_btn.config(state="normal")
            self.save_edited_btn.config(state="normal")
            self._enable_selection_controls()
            self.set_status(f"Saved 16-bit WAV: {os.path.basename(dest)}")
        except Exception as e:
            tb = traceback.format_exc()
            print(tb)
            self.wav_path = dest
            self.set_status(f"Saved 16-bit WAV but failed to load: {os.path.basename(dest)}")
            messagebox.showwarning("Saved but load failed", f"Saved file to {dest} but failed to load into the app:\n{e}")

    # ----------------- Play the last recording (temp) -----------------

    def play_record(self):
        if not self._last_record_tmp or not os.path.exists(self._last_record_tmp):
            messagebox.showinfo("No recording", "No temporary recording available. Record something first.")
            self.play_record_btn.config(state="disabled")
            return
        if self._is_playing:
            messagebox.showinfo("Already playing", "Playback is already in progress.")
            return
        self._play_thread = threading.Thread(target=self._play_temp_record_thread, daemon=True)
        self._play_thread.start()

    def _play_temp_record_thread(self):
        play_path = self._last_record_tmp
        tmp_created = None
        try:
            try:
                with wave.open(play_path, 'rb') as wf:
                    sw = wf.getsampwidth()
            except Exception:
                ok = validate_and_rewrite_wav(play_path)
                if not ok:
                    raise RuntimeError("Temporary recording is not a valid WAV for playback.")
                with wave.open(play_path, 'rb') as wf:
                    sw = wf.getsampwidth()

            if sw != 2:
                tmp_created = float32_wav_to_temp_16bit(play_path)
                play_path = tmp_created
                self._play_tmp = tmp_created

            abs_play = os.path.abspath(play_path)
            try:
                mci_send(f"close {self._play_alias}")
            except Exception:
                pass

            try:
                mci_send(f'open "{abs_play}" type waveaudio alias {self._play_alias}')
                self._is_playing = True
                self.root.after(0, lambda: self.play_record_btn.config(state="disabled"))
                self.root.after(0, lambda: self.stop_play_btn.config(state="normal"))
                self.root.after(0, lambda: self.set_status(f"Playing recording: {os.path.basename(play_path)}"))
                mci_send(f'play {self._play_alias} wait')
            finally:
                try:
                    mci_send(f"close {self._play_alias}")
                except Exception:
                    pass
        except Exception as e:
            tb = traceback.format_exc()
            print(tb)
            self.root.after(0, lambda: messagebox.showerror("Playback error", f"Playback failed:\n{e}"))
        finally:
            if tmp_created:
                try:
                    os.remove(tmp_created)
                except Exception:
                    pass
                self._play_tmp = None
            self._is_playing = False
            try:
                self.root.after(0, lambda: self.play_record_btn.config(state="normal"))
                self.root.after(0, lambda: self.stop_play_btn.config(state="disabled"))
                self.root.after(0, lambda: self.set_status("Ready"))
            except Exception:
                pass

    # ----------------- Playback of loaded file -----------------

    def play_wav(self):
        if not self.wav_path:
            messagebox.showinfo("No WAV", "Load a WAV file first.")
            return
        if self._is_playing:
            messagebox.showinfo("Already playing", "Playback is already in progress.")
            return
        self._play_thread = threading.Thread(target=self._playback_thread, daemon=True)
        self._play_thread.start()

    def _playback_thread(self):
        play_path = None
        tmp_created = None
        try:
            with wave.open(self.wav_path, 'rb') as wf:
                sw = wf.getsampwidth()
            if sw != 2:
                self.set_status("Preparing audio for playback...")
                tmp_created = float32_wav_to_temp_16bit(self.wav_path)
                play_path = tmp_created
                self._play_tmp = tmp_created
            else:
                play_path = self.wav_path

            abs_play = os.path.abspath(play_path)
            try:
                mci_send(f"close {self._play_alias}")
            except Exception:
                pass

            try:
                mci_send(f'open "{abs_play}" type waveaudio alias {self._play_alias}')
                self._is_playing = True
                self.root.after(0, lambda: self.play_btn.config(state="disabled"))
                self.root.after(0, lambda: self.stop_play_btn.config(state="normal"))
                self.root.after(0, lambda: self.set_status(f"Playing: {os.path.basename(play_path)}"))
                mci_send(f'play {self._play_alias} wait')
            finally:
                try:
                    mci_send(f"close {self._play_alias}")
                except Exception:
                    pass
        except Exception as e:
            tb = traceback.format_exc()
            print(tb)
            self.root.after(0, lambda: messagebox.showerror("Playback error", f"Playback failed:\n{e}"))
        finally:
            if tmp_created:
                try:
                    os.remove(tmp_created)
                except Exception:
                    pass
                self._play_tmp = None
            self._is_playing = False
            try:
                self.root.after(0, lambda: self.play_btn.config(state="normal"))
                self.root.after(0, lambda: self.stop_play_btn.config(state="disabled"))
                self.root.after(0, lambda: self.set_status("Ready"))
            except Exception:
                pass

    def stop_play(self):
        if not self._is_playing:
            return
        try:
            mci_send(f"stop {self._play_alias}")
        except Exception:
            pass
        try:
            mci_send(f"close {self._play_alias}")
        except Exception:
            pass
        if self._play_tmp:
            try:
                os.remove(self._play_tmp)
            except Exception:
                pass
            self._play_tmp = None
        self._is_playing = False
        self.play_btn.config(state="normal")
        self.stop_play_btn.config(state="disabled")
        self.play_record_btn.config(state="normal")
        self.set_status("Playback stopped")

    # ----------------- Noise profile capture / reduction / export (time-domain) -----------------

    def capture_noise_profile(self):
        try:
            if getattr(self, "_last_record_tmp", None) and os.path.exists(self._last_record_tmp):
                path = self._last_record_tmp
            else:
                path = filedialog.askopenfilename(filetypes=[("WAV files","*.wav"),("All files","*.*")], title="Select noise-only WAV")
                if not path:
                    return
            fr, samples = self._read_wav_for_display(path, max_frames=int(self.sample_rate_var.get() * 5))
            avg_rms, frame_len = estimate_noise_profile_from_samples(samples, fr, max_seconds=5.0, frame_ms=50)
            self._noise_profile = (avg_rms, frame_len, fr)
            self.remove_noise_btn.config(state="normal")
            self.export_noise_btn.config(state="normal")
            self.set_status("Noise profile captured (time-domain)")
        except Exception as e:
            messagebox.showerror("Noise profile error", f"Could not capture noise profile:\n{e}")

    def remove_background(self):
        if not getattr(self, "_noise_profile", None):
            messagebox.showinfo("No noise profile", "Capture a noise profile first.")
            return
        src_path = self.wav_path if self.wav_path else getattr(self, "_last_record_tmp", None)
        if not src_path:
            messagebox.showinfo("No audio", "Load a WAV or record something first.")
            return
        try:
            fr, samples = self._read_wav_for_display(src_path)
            noise_rms, frame_len, prof_sr = self._noise_profile
            if prof_sr != fr:
                noise_rms, frame_len = estimate_noise_profile_from_samples(samples, fr, max_seconds=2.0, frame_ms=50)
            cleaned = apply_time_domain_noise_gate(samples, fr, noise_rms, frame_len, threshold_db=6.0, reduction_db=12.0)
            self.samples = cleaned
            self.samplerate = fr
            self.draw_waveform(self.samples)
            self._enable_selection_controls()
            self.save_edited_btn.config(state="normal")
            dest = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("WAV files","*.wav")], title="Save cleaned WAV")
            if dest:
                convert_float_to_16bit_and_write(dest, cleaned, fr)
                self.set_status(f"Saved cleaned WAV: {os.path.basename(dest)}")
            else:
                self.set_status("Background removed (not saved)")
        except Exception as e:
            messagebox.showerror("Noise reduction error", f"Noise reduction failed:\n{e}")

    def export_noise_only(self):
        if not getattr(self, "_noise_profile", None):
            messagebox.showinfo("No noise profile", "Capture a noise profile first.")
            return
        noise_rms, frame_len, fr = self._noise_profile
        try:
            duration_sec = 3.0
            n_samples = int(fr * duration_sec)
            clip = []
            for _ in range(n_samples):
                v = random.gauss(0, 1.0)
                clip.append(v)
            s = 0.0
            for v in clip:
                s += v * v
            cur_rms = math.sqrt(s / len(clip)) if clip else 0.0
            if cur_rms > 0:
                scale = noise_rms / cur_rms
            else:
                scale = 0.0
            clip = [max(-1.0, min(1.0, v * scale)) for v in clip]
            dest = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("WAV files","*.wav")], title="Save noise-only WAV")
            if dest:
                convert_float_to_16bit_and_write(dest, clip, fr)
                self.set_status(f"Saved noise-only WAV: {os.path.basename(dest)}")
            else:
                self.set_status("Noise-only clip generated (not saved)")
        except Exception as e:
            messagebox.showerror("Export noise error", f"Could not export noise-only audio:\n{e}")

    # ----------------- Conversion UI -----------------

    def convert_to_32bit(self):
        if not self.wav_path:
            messagebox.showinfo("No WAV", "Load a WAV file first.")
            return
        dest = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("WAV files","*.wav")], title="Save as 32-bit PCM WAV")
        if not dest:
            return
        try:
            fr, samples = self._read_wav_for_display(self.wav_path)
            ints32 = []
            for v in samples:
                v = _safe_clamp_float(v)
                ints32.append(int(round(v * 2147483647.0)))
            raw = struct.pack('<{}i'.format(len(ints32)), *ints32)
            with wave.open(dest, 'wb') as wf:
                wf.setnchannels(1)
                wf.setsampwidth(4)
                wf.setframerate(fr)
                wf.writeframes(raw)
            self.set_status(f"Converted to 32-bit PCM: {os.path.basename(dest)}")
        except Exception as e:
            tb = traceback.format_exc()
            print(tb)
            messagebox.showerror("Conversion error", f"Conversion failed:\n{e}")

    def convert_to_16bit(self):
        if not self.wav_path:
            messagebox.showinfo("No WAV", "Load a WAV file first.")
            return
        dest = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("WAV files","*.wav")], title="Save as 16-bit PCM WAV")
        if not dest:
            return
        try:
            with wave.open(self.wav_path, 'rb') as wf:
                _ensure_uncompressed_wave(wf)
                sw = wf.getsampwidth()
            if sw == 2:
                with open(self.wav_path, 'rb') as s, open(dest, 'wb') as d:
                    d.write(s.read())
            else:
                fr, samples = self._read_wav_for_display(self.wav_path)
                convert_float_to_16bit_and_write(dest, samples, fr)
            self.set_status(f"Converted to 16-bit PCM: {os.path.basename(dest)}")
        except Exception as e:
            tb = traceback.format_exc()
            print(tb)
            messagebox.showerror("Conversion error", f"Conversion failed:\n{e}")

    # ----------------- Display helpers -----------------

    def _read_wav_for_display(self, path, max_frames=None):
        with wave.open(path, "rb") as wf:
            _ensure_uncompressed_wave(wf)
            nch = wf.getnchannels()
            sw = wf.getsampwidth()
            fr = wf.getframerate()
            nframes = wf.getnframes()
            if max_frames:
                nframes = min(nframes, max_frames)
            raw = wf.readframes(nframes)
        expected_bytes = nframes * nch * sw
        if len(raw) < expected_bytes:
            actual_samples = len(raw) // sw
            nframes = actual_samples // nch
            raw = raw[:nframes * nch * sw]
        if sw == 1:
            ints = list(raw)
            if nch == 1:
                mono = [ (i - 128) / 128.0 for i in ints ]
            else:
                mono = []
                for i in range(0, len(ints), nch):
                    s = sum(ints[i + ch] for ch in range(nch)) / nch
                    mono.append((s - 128.0) / 128.0)
            return fr, [ _safe_clamp_float(x) for x in mono ]
        if sw == 2:
            count = len(raw) // 2
            if count == 0:
                return fr, []
            ints = struct.unpack('<{}h'.format(count), raw)
            if nch == 1:
                mono = [i / 32768.0 for i in ints]
            else:
                mono = []
                for i in range(0, len(ints), nch):
                    s = sum(ints[i + ch] for ch in range(nch)) / nch
                    mono.append(s / 32768.0)
            return fr, [ _safe_clamp_float(x) for x in mono ]
        if sw == 3:
            n_samples = len(raw) // 3
            if n_samples == 0:
                return fr, []
            floats = []
            for i in range(n_samples):
                b0 = raw[i*3 + 0]
                b1 = raw[i*3 + 1]
                b2 = raw[i*3 + 2]
                val = b0 | (b1 << 8) | (b2 << 16)
                if val & 0x800000:
                    val = val - 0x1000000
                floats.append(val / 8388608.0)
            if nch == 1:
                mono = floats
            else:
                mono = []
                for i in range(0, len(floats), nch):
                    s = sum(floats[i + ch] for ch in range(nch)) / nch
                    mono.append(s)
            return fr, [ _safe_clamp_float(x) for x in mono ]
        if sw == 4:
            count = len(raw) // 4
            if count == 0:
                return fr, []
            floats = None
            try:
                floats = struct.unpack('<{}f'.format(count), raw)
            except struct.error:
                ints32 = struct.unpack('<{}i'.format(count), raw)
                floats = [v / 2147483647.0 for v in ints32]
            if nch == 1:
                mono = [float(v) for v in floats]
            else:
                mono = []
                for i in range(0, len(floats), nch):
                    s = sum(floats[i + ch] for ch in range(nch)) / nch
                    mono.append(s)
            return fr, [ _safe_clamp_float(x) for x in mono ]
        raise RuntimeError(f"Unsupported sample width: {sw} bytes")

    def load_wav(self):
        path = filedialog.askopenfilename(filetypes=[("WAV files","*.wav"),("All files","*.*")])
        if not path:
            return
        try:
            fr, samples = self._read_wav_for_display(path)
        except Exception as e:
            try:
                with wave.open(path,'rb') as wf:
                    print("DEBUG: channels", wf.getnchannels(), "sampwidth", wf.getsampwidth(),
                          "fr", wf.getframerate(), "nframes", wf.getnframes(), "comptype", wf.getcomptype())
            except Exception as e2:
                print("DEBUG: wave.open failed:", e2)
            messagebox.showerror("Read error", f"Could not read WAV:\n{e}")
            return
        self.wav_path = path
        self.samples = samples
        self.samplerate = fr
        self.draw_waveform(samples)
        self.play_btn.config(state="normal")
        self.conv32_btn.config(state="normal")
        self.conv16_btn.config(state="normal")
        self.save_copy_btn.config(state="normal")
        self.save_edited_btn.config(state="normal")
        self._enable_selection_controls()
        self.set_status(f"Loaded {os.path.basename(path)} — {len(samples)} samples @ {fr} Hz")

    def save_copy(self):
        if not self.wav_path:
            return
        dest = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("WAV files","*.wav")], title="Save copy as")
        if not dest:
            return
        try:
            with open(self.wav_path, "rb") as s, open(dest, "wb") as d:
                d.write(s.read())
            self.set_status(f"Saved copy to {os.path.basename(dest)}")
        except Exception as e:
            messagebox.showerror("Save error", f"Could not save copy:\n{e}")

    # ----------------- Save Edited WAV -----------------

    def save_edited_wav(self):
        if not self.samples:
            messagebox.showinfo("No audio", "There are no edited samples to save.")
            return

        dest = filedialog.asksaveasfilename(defaultextension=".wav",
                                            filetypes=[("WAV files","*.wav")],
                                            title="Save edited WAV")
        if not dest:
            return

        try:
            try:
                mci_send(f"stop {self._play_alias}")
            except Exception:
                pass
            try:
                mci_send(f"close {self._play_alias}")
            except Exception:
                pass
            try:
                mci_send(f"close {self._alias}")
            except Exception:
                pass
        except Exception:
            pass

        try:
            sr = int(self.samplerate) if getattr(self, "samplerate", None) else int(self.sample_rate_var.get())
            ints16 = [int(round(max(-1.0, min(1.0, v)) * 32767.0)) for v in self.samples]
            with wave.open(dest, 'wb') as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sr)
                wf.writeframes(struct.pack('<{}h'.format(len(ints16)), *ints16))

            ok = validate_and_rewrite_wav(dest)
            if not ok:
                messagebox.showwarning("Saved but invalid", f"Saved file to {dest} but it appears invalid.")

            self.wav_path = dest
            self.samplerate = sr
            self.draw_waveform(self.samples)

            self.play_btn.config(state="normal")
            self.conv32_btn.config(state="normal")
            self.conv16_btn.config(state="normal")
            self.save_copy_btn.config(state="normal")
            self.save_edited_btn.config(state="normal")

            self.set_status(f"Saved edited WAV: {os.path.basename(dest)}")
        except Exception as e:
            tb = traceback.format_exc()
            print(tb)
            messagebox.showerror("Save error", f"Could not save edited WAV:\n{e}")

    # ----------------- Scroll-aware drawing and selection helpers -----------------

    def draw_waveform(self, samples):
        # Clear canvas
        self.canvas.delete("all")

        if not samples:
            self.sel_start = None
            self.sel_end = None
            self._update_selection_visual()
            # reset scrollregion
            self._virtual_width = self.canvas_w
            self.canvas.configure(scrollregion=(0,0,self._virtual_width,self.canvas_h))
            self.canvas.xview_moveto(0.0)
            return

        # Determine virtual width based on number of samples.
        # Aim for roughly 1-3 samples per pixel depending on length.
        visible_w = max(200, self.canvas.winfo_width() or self.canvas_w)
        n = len(samples)
        # choose pixels per sample so virtual width is not absurdly large
        if n <= visible_w:
            virtual_w = visible_w
            samples_per_pixel = 1
        else:
            # target virtual width between visible_w and n/2
            samples_per_pixel = max(1, n // (visible_w * 2))
            virtual_w = max(visible_w, n // samples_per_pixel)

        self._virtual_width = int(virtual_w)
        self.canvas.configure(scrollregion=(0,0,self._virtual_width,self.canvas_h))

        # draw waveform scaled to virtual width
        step = max(1, n // self._virtual_width)
        h = self.canvas.winfo_height() or self.canvas_h
        mid = h // 2

        # Build points on virtual canvas coordinates
        points = []
        for i in range(0, n, step):
            x = int((i / (n - 1)) * (self._virtual_width - 1)) if n > 1 else 0
            y = int(mid - samples[i] * (h // 2 - 2))
            points.append((x, y))

        # Draw lines on canvas (these are in virtual coords)
        for (x1, y1), (x2, y2) in zip(points, points[1:]):
            self.canvas.create_line(x1, y1, x2, y2, fill="#00ff00")

        # If current view is beyond right edge, clamp
        self.canvas.xview_moveto(min(self.canvas.xview()[0], 1.0))

        self._update_selection_visual()

    def _canvas_to_index(self, canvas_x):
        """Convert a canvas coordinate (virtual) to sample index."""
        if not self.samples:
            return 0
        n = len(self.samples)
        # clamp canvas_x
        canvas_x = max(0, min(self._virtual_width - 1, canvas_x))
        frac = canvas_x / (self._virtual_width - 1) if self._virtual_width > 1 else 0.0
        idx = int(frac * (n - 1))
        return idx

    def _index_to_canvas_x(self, idx):
        if not self.samples:
            return 0
        idx = max(0, min(len(self.samples) - 1, idx))
        frac = idx / (len(self.samples) - 1) if len(self.samples) > 1 else 0.0
        x = int(frac * (self._virtual_width - 1))
        return x

    def _x_to_index(self, event_x):
        # Convert screen x (event.x) to canvas virtual coordinate then to index
        canvas_x = self.canvas.canvasx(event_x)
        return self._canvas_to_index(canvas_x)

    def _index_to_x(self, idx):
        # Convert sample index to canvas virtual x coordinate
        return self._index_to_canvas_x(idx)

    def _update_selection_visual(self):
        if self._selection_rect:
            try:
                self.canvas.delete(self._selection_rect)
            except Exception:
                pass
            self._selection_rect = None
        if self.sel_start is None or self.sel_end is None:
            self.cut_btn.config(state="disabled")
            self.copy_btn.config(state="disabled")
            self.delete_btn.config(state="disabled")
            return
        a = min(self.sel_start, self.sel_end)
        b = max(self.sel_start, self.sel_end)
        if a == b:
            self.cut_btn.config(state="disabled")
            self.copy_btn.config(state="disabled")
            self.delete_btn.config(state="disabled")
            return
        x1 = self._index_to_x(a)
        x2 = self._index_to_x(b)
        h = self.canvas.winfo_height() or self.canvas_h
        self._selection_rect = self.canvas.create_rectangle(x1, 0, x2, h, fill="#ffffff", stipple="gray25", outline="")
        self.cut_btn.config(state="normal")
        self.copy_btn.config(state="normal")
        self.delete_btn.config(state="normal")

    # ----------------- Mouse event handlers for selection -----------------

    def _on_canvas_mouse_down(self, event):
        if not self.samples:
            return
        self._mouse_down = True
        idx = self._x_to_index(event.x)
        self.sel_start = idx
        self.sel_end = idx
        self._update_selection_visual()

    def _on_canvas_mouse_drag(self, event):
        if not self._mouse_down or not self.samples:
            return
        idx = self._x_to_index(event.x)
        self.sel_end = idx
        self._update_selection_visual()

    def _on_canvas_mouse_up(self, event):
        if not self._mouse_down:
            return
        self._mouse_down = False
        if not self.samples:
            return
        idx = self._x_to_index(event.x)
        self.sel_end = idx
        self._update_selection_visual()
        if self._clipboard:
            self.paste_btn.config(state="normal")
        else:
            self.paste_btn.config(state="disabled")

    # ----------------- Clipboard operations -----------------

    def _get_selection_range(self):
        if self.sel_start is None or self.sel_end is None:
            return None
        a = min(self.sel_start, self.sel_end)
        b = max(self.sel_start, self.sel_end)
        if a == b:
            return None
        return a, b

    def copy_selection(self):
        rng = self._get_selection_range()
        if not rng:
            return
        a, b = rng
        self._clipboard = list(self.samples[a:b])
        self.paste_btn.config(state="normal")
        self.set_status(f"Copied {b-a} samples to clipboard")

    def cut_selection(self):
        rng = self._get_selection_range()
        if not rng:
            return
        a, b = rng
        self._clipboard = list(self.samples[a:b])
        self.samples = self.samples[:a] + self.samples[b:]
        self.sel_start = a
        self.sel_end = a
        self.draw_waveform(self.samples)
        self.paste_btn.config(state="normal")
        self.save_edited_btn.config(state="normal")
        self.set_status(f"Cut {b-a} samples to clipboard")

    def delete_selection(self):
        rng = self._get_selection_range()
        if not rng:
            return
        a, b = rng
        self.samples = self.samples[:a] + self.samples[b:]
        self.sel_start = None
        self.sel_end = None
        self.draw_waveform(self.samples)
        self.save_edited_btn.config(state="normal")
        self.set_status(f"Deleted {b-a} samples")

    def paste_clipboard(self):
        if not self._clipboard:
            messagebox.showinfo("Clipboard empty", "Clipboard is empty. Copy or cut a selection first.")
            return
        insert_idx = 0
        rng = self._get_selection_range()
        if rng:
            a, b = rng
            insert_idx = a
            self.samples = self.samples[:a] + list(self._clipboard) + self.samples[b:]
            self.sel_start = insert_idx
            self.sel_end = insert_idx + len(self._clipboard)
        else:
            if self.sel_start is not None:
                insert_idx = self.sel_start
            else:
                insert_idx = len(self.samples)
            self.samples = self.samples[:insert_idx] + list(self._clipboard) + self.samples[insert_idx:]
            self.sel_start = insert_idx
            self.sel_end = insert_idx + len(self._clipboard)
        self.draw_waveform(self.samples)
        self.save_edited_btn.config(state="normal")
        self.set_status(f"Pasted {len(self._clipboard)} samples")

    def clear_clipboard(self):
        self._clipboard = []
        self.paste_btn.config(state="disabled")
        self.set_status("Clipboard cleared")

    def _enable_selection_controls(self):
        if self._clipboard:
            self.paste_btn.config(state="normal")
        else:
            self.paste_btn.config(state="disabled")

# ----------------- Minimal time-domain noise helpers (used above) -----------------

def estimate_noise_profile_from_samples(samples, sr, max_seconds=5.0, frame_ms=50):
    if not samples:
        raise RuntimeError("No samples for noise estimation")
    max_frames = int(min(len(samples), int(sr * max_seconds)))
    frame_len = max(1, int(sr * (frame_ms / 1000.0)))
    rms_list = []
    i = 0
    while i < max_frames:
        frame = samples[i:i+frame_len]
        if not frame:
            break
        s = 0.0
        for v in frame:
            s += v * v
        rms = math.sqrt(s / len(frame)) if len(frame) else 0.0
        rms_list.append(rms)
        i += frame_len
    if not rms_list:
        raise RuntimeError("Not enough audio for noise profile")
    avg_rms = sum(rms_list) / len(rms_list)
    return avg_rms, frame_len

def apply_time_domain_noise_gate(samples, sr, noise_rms, frame_len, threshold_db=6.0, reduction_db=12.0):
    if not samples:
        return []
    threshold_lin = noise_rms * (10 ** (threshold_db / 20.0))
    reduction_lin = 10 ** (-reduction_db / 20.0)
    out = []
    i = 0
    n = len(samples)
    while i < n:
        frame = samples[i:i+frame_len]
        s = 0.0
        for v in frame:
            s += v * v
        rms = math.sqrt(s / len(frame)) if len(frame) else 0.0
        if rms <= threshold_lin:
            for v in frame:
                out.append(v * reduction_lin)
        else:
            out.extend(frame)
        i += frame_len
    return out[:n]

# ----------------- Main -----------------

def main():
    root = tk.Tk()
    app = WinMCIRecorderApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
