import random
import sys
import subprocess
import time
import platform

# ==========================
#   JEOPARDY WITH REAL TTS
#   (No pip; uses PowerShell on Windows; prints on other OS)
# ==========================

TTS_ON = True  # TTS enabled by default

def speak(text):
    """Speak text using built-in Windows System.Speech via PowerShell.
    Falls back to printing and a short pause on non-Windows platforms.
    """
    if not TTS_ON:
        return

    if platform.system().lower().startswith("win"):
        safe = text.replace("'", "''")
        cmd = [
            "powershell",
            "-NoProfile",
            "-Command",
            "Add-Type -AssemblyName System.Speech; "
            f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak('{safe}')"
        ]
        try:
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        except Exception:
            print(f"[TTS failed] {text}")
            time.sleep(min(0.05 * len(text.split()), 1.5))
    else:
        print(f"[SPEAK] {text}")
        time.sleep(min(0.05 * len(text.split()), 1.5))


# ==========================
#   FULL QUESTION BANK
#   (original + expansion + bulk pack)
# ==========================

questions = [

    # --- ORIGINAL QUESTIONS ---
    {
        "category": "HISTORY",
        "question": "Who was the first President of the United States?",
        "choices": ["A) George Washington", "B) John Adams", "C) Thomas Jefferson", "D) James Madison"],
        "answer": "A"
    },
    {
        "category": "SCIENCE",
        "question": "What planet is known as the Red Planet?",
        "choices": ["A) Venus", "B) Mars", "C) Jupiter", "D) Saturn"],
        "answer": "B"
    },
    {
        "category": "MOVIES",
        "question": "Which movie features the quote: 'I'll be back'?",
        "choices": ["A) Terminator", "B) Predator", "C) Commando", "D) Total Recall"],
        "answer": "A"
    },
    {
        "category": "MUSIC",
        "question": "Which band recorded the album 'Dark Side of the Moon'?",
        "choices": ["A) Led Zeppelin", "B) Pink Floyd", "C) Rush", "D) Queen"],
        "answer": "B"
    },
    {
        "category": "GEOGRAPHY",
        "question": "What is the largest ocean on Earth?",
        "choices": ["A) Atlantic", "B) Indian", "C) Pacific", "D) Arctic"],
        "answer": "C"
    },

    # --- MASSIVE EXPANSION PACK (40 NEW QUESTIONS) ---
    {"category": "HISTORY","question": "Which ancient civilization built Machu Picchu?","choices": ["A) Maya","B) Aztec","C) Inca","D) Olmec"],"answer": "C"},
    {"category": "HISTORY","question": "The Magna Carta was signed in which year?","choices": ["A) 1066","B) 1215","C) 1492","D) 1776"],"answer": "B"},
    {"category": "HISTORY","question": "Which empire was ruled by Genghis Khan?","choices": ["A) Ottoman","B) Mongol","C) Persian","D) Roman"],"answer": "B"},

    {"category": "SCIENCE","question": "What gas makes up most of Earth's atmosphere?","choices": ["A) Oxygen","B) Nitrogen","C) Carbon Dioxide","D) Argon"],"answer": "B"},
    {"category": "SCIENCE","question": "What is the powerhouse of the cell?","choices": ["A) Nucleus","B) Ribosome","C) Mitochondria","D) Golgi Apparatus"],"answer": "C"},
    {"category": "SCIENCE","question": "What is the chemical symbol for gold?","choices": ["A) Ag","B) Au","C) Gd","D) Go"],"answer": "B"},

    {"category": "GEOGRAPHY","question": "Which country has the largest population?","choices": ["A) United States","B) India","C) China","D) Indonesia"],"answer": "B"},
    {"category": "GEOGRAPHY","question": "What is the capital of Australia?","choices": ["A) Sydney","B) Melbourne","C) Canberra","D) Perth"],"answer": "C"},
    {"category": "GEOGRAPHY","question": "Which river flows through Egypt?","choices": ["A) Amazon","B) Nile","C) Yangtze","D) Danube"],"answer": "B"},

    {"category": "MOVIES","question": "Which actor voiced Woody in Toy Story?","choices": ["A) Tom Hanks","B) Tim Allen","C) Billy Crystal","D) Robin Williams"],"answer": "A"},
    {"category": "MOVIES","question": "Which film features a DeLorean time machine?","choices": ["A) Ghostbusters","B) Back to the Future","C) Tron","D) Blade Runner"],"answer": "B"},
    {"category": "MOVIES","question": "Which movie introduced Jack Sparrow?","choices": ["A) Hook","B) Pirates of the Caribbean","C) Treasure Island","D) Waterworld"],"answer": "B"},

    {"category": "MUSIC","question": "Which instrument has 88 keys?","choices": ["A) Piano","B) Organ","C) Harpsichord","D) Synthesizer"],"answer": "A"},
    {"category": "MUSIC","question": "Which genre is associated with Nashville?","choices": ["A) Jazz","B) Country","C) Reggae","D) Metal"],"answer": "B"},
    {"category": "MUSIC","question": "Which band is known for 'Nevermind'?","choices": ["A) Pearl Jam","B) Nirvana","C) Soundgarden","D) Alice in Chains"],"answer": "B"},

    {"category": "TECH","question": "What does CPU stand for?","choices": ["A) Central Processing Unit","B) Computer Power Utility","C) Core Performance Unit","D) Central Program Unit"],"answer": "A"},
    {"category": "TECH","question": "Which company created the first iPhone?","choices": ["A) Microsoft","B) Apple","C) IBM","D) Samsung"],"answer": "B"},
    {"category": "TECH","question": "What does HTML stand for?","choices": ["A) HyperText Markup Language","B) High-Tech Machine Logic","C) Home Tool Media Layer","D) Hyperlink Transfer Mode"],"answer": "A"},

    {"category": "LITERATURE","question": "Who wrote '1984'?","choices": ["A) Aldous Huxley","B) George Orwell","C) Ray Bradbury","D) J.R.R. Tolkien"],"answer": "B"},
    {"category": "LITERATURE","question": "Sherlock Holmes was created by which author?","choices": ["A) Agatha Christie","B) Arthur Conan Doyle","C) Edgar Allan Poe","D) Charles Dickens"],"answer": "B"},
    {"category": "LITERATURE","question": "Which novel begins with 'Call me Ishmael'?","choices": ["A) Moby-Dick","B) The Odyssey","C) The Great Gatsby","D) War and Peace"],"answer": "A"},

    {"category": "ANIMALS","question": "What is the fastest land animal?","choices": ["A) Lion","B) Cheetah","C) Gazelle","D) Horse"],"answer": "B"},
    {"category": "ANIMALS","question": "Which animal has black-and-white stripes?","choices": ["A) Tiger","B) Zebra","C) Skunk","D) Panda"],"answer": "B"},
    {"category": "ANIMALS","question": "What is the largest species of shark?","choices": ["A) Great White","B) Tiger Shark","C) Whale Shark","D) Hammerhead"],"answer": "C"},

    {"category": "FOOD","question": "Which fruit has seeds on the outside?","choices": ["A) Blueberry","B) Strawberry","C) Raspberry","D) Blackberry"],"answer": "B"},
    {"category": "FOOD","question": "Sushi originated in which country?","choices": ["A) China","B) Japan","C) Korea","D) Thailand"],"answer": "B"},
    {"category": "FOOD","question": "Which grain is used to make pasta?","choices": ["A) Corn","B) Wheat","C) Rice","D) Barley"],"answer": "B"},

    {"category": "SPORTS","question": "How many players are on a baseball team on the field?","choices": ["A) 7","B) 8","C) 9","D) 10"],"answer": "C"},
    {"category": "SPORTS","question": "Which sport uses a shuttlecock?","choices": ["A) Tennis","B) Badminton","C) Squash","D) Pickleball"],"answer": "B"},
    {"category": "SPORTS","question": "Which country won the first modern Olympics?","choices": ["A) France","B) Greece","C) USA","D) Germany"],"answer": "B"},

    {"category": "SPACE","question": "Which planet has the most moons?","choices": ["A) Earth","B) Jupiter","C) Saturn","D) Neptune"],"answer": "C"},
    {"category": "SPACE","question": "What is the name of our galaxy?","choices": ["A) Andromeda","B) Milky Way","C) Sombrero","D) Whirlpool"],"answer": "B"},
    {"category": "SPACE","question": "What star is closest to Earth?","choices": ["A) Alpha Centauri","B) Betelgeuse","C) The Sun","D) Sirius"],"answer": "C"},

    {"category": "RANDOM","question": "Which shape has three sides?","choices": ["A) Square","B) Triangle","C) Pentagon","D) Hexagon"],"answer": "B"},
    {"category": "RANDOM","question": "Which color is made by mixing red and blue?","choices": ["A) Green","B) Purple","C) Orange","D) Brown"],"answer": "B"},
    {"category": "RANDOM","question": "Which month has 28 days?","choices": ["A) February","B) All of them","C) January","D) April"],"answer": "B"},

    # --- BULK EXPANSION: 96 QUESTIONS (8 per category) ---
    {"category":"HISTORY","question":"Which year did the Berlin Wall fall?","choices":["A) 1987","B) 1989","C) 1991","D) 1993"],"answer":"B"},
    {"category":"HISTORY","question":"Who was the British prime minister during most of World War II?","choices":["A) Neville Chamberlain","B) Winston Churchill","C) Clement Attlee","D) Anthony Eden"],"answer":"B"},
    {"category":"HISTORY","question":"Which civilization built the pyramids at Giza?","choices":["A) Sumerians","B) Egyptians","C) Mayans","D) Greeks"],"answer":"B"},
    {"category":"HISTORY","question":"The American Civil War began in which year?","choices":["A) 1850","B) 1861","C) 1870","D) 1881"],"answer":"B"},
    {"category":"HISTORY","question":"Who led the Soviet Union during World War II?","choices":["A) Lenin","B) Stalin","C) Khrushchev","D) Brezhnev"],"answer":"B"},
    {"category":"HISTORY","question":"Which explorer is credited with circumnavigating the globe (completed by his crew)?","choices":["A) Christopher Columbus","B) Ferdinand Magellan","C) Vasco da Gama","D) James Cook"],"answer":"B"},
    {"category":"HISTORY","question":"Which document declared the American colonies independent from Britain?","choices":["A) Constitution","B) Bill of Rights","C) Declaration of Independence","D) Articles of Confederation"],"answer":"C"},
    {"category":"HISTORY","question":"Which empire was centered in modern-day Turkey from the 14th to early 20th century?","choices":["A) Byzantine","B) Ottoman","C) Persian","D) Mongol"],"answer":"B"},

    {"category":"SCIENCE","question":"What is the chemical formula for water?","choices":["A) CO2","B) H2O","C) O2","D) H2SO4"],"answer":"B"},
    {"category":"SCIENCE","question":"What force keeps planets in orbit around the Sun?","choices":["A) Magnetism","B) Friction","C) Gravity","D) Electricity"],"answer":"C"},
    {"category":"SCIENCE","question":"What is the basic unit of life?","choices":["A) Atom","B) Molecule","C) Cell","D) Organ"],"answer":"C"},
    {"category":"SCIENCE","question":"Which gas do plants primarily absorb for photosynthesis?","choices":["A) Oxygen","B) Nitrogen","C) Carbon dioxide","D) Hydrogen"],"answer":"C"},
    {"category":"SCIENCE","question":"What is the speed of light in vacuum approximately?","choices":["A) 3 x 10^5 m/s","B) 3 x 10^6 m/s","C) 3 x 10^7 m/s","D) 3 x 10^8 m/s"],"answer":"D"},
    {"category":"SCIENCE","question":"What particle has a negative electric charge?","choices":["A) Proton","B) Neutron","C) Electron","D) Photon"],"answer":"C"},
    {"category":"SCIENCE","question":"Which organ filters blood and produces urine?","choices":["A) Liver","B) Kidney","C) Heart","D) Lung"],"answer":"B"},
    {"category":"SCIENCE","question":"What scale measures earthquake magnitude?","choices":["A) Richter scale","B) Beaufort scale","C) Celsius scale","D) Mohs scale"],"answer":"A"},

    {"category":"GEOGRAPHY","question":"Which is the largest country by area?","choices":["A) Canada","B) China","C) Russia","D) United States"],"answer":"C"},
    {"category":"GEOGRAPHY","question":"What is the capital of Canada?","choices":["A) Toronto","B) Ottawa","C) Vancouver","D) Montreal"],"answer":"B"},
    {"category":"GEOGRAPHY","question":"Which desert is the largest hot desert on Earth?","choices":["A) Gobi","B) Sahara","C) Kalahari","D) Mojave"],"answer":"B"},
    {"category":"GEOGRAPHY","question":"Mount Kilimanjaro is located in which country?","choices":["A) Kenya","B) Tanzania","C) Uganda","D) Ethiopia"],"answer":"B"},
    {"category":"GEOGRAPHY","question":"Which U.S. state is the Grand Canyon primarily in?","choices":["A) Utah","B) Arizona","C) Nevada","D) Colorado"],"answer":"B"},
    {"category":"GEOGRAPHY","question":"Which river is the longest in the world by most measures?","choices":["A) Amazon","B) Nile","C) Yangtze","D) Mississippi"],"answer":"B"},
    {"category":"GEOGRAPHY","question":"What is the capital of Italy?","choices":["A) Milan","B) Venice","C) Rome","D) Florence"],"answer":"C"},
    {"category":"GEOGRAPHY","question":"Which country is an island nation in the North Atlantic, capital Reykjavik?","choices":["A) Ireland","B) Iceland","C) Greenland","D) Faroe Islands"],"answer":"B"},

    {"category":"MOVIES","question":"Which director made 'Jurassic Park' (1993)?","choices":["A) James Cameron","B) Steven Spielberg","C) Ridley Scott","D) Martin Scorsese"],"answer":"B"},
    {"category":"MOVIES","question":"Which film won Best Picture at the 1994 Oscars (for 1993 films)?","choices":["A) Schindler's List","B) Forrest Gump","C) Pulp Fiction","D) The Shawshank Redemption"],"answer":"B"},
    {"category":"MOVIES","question":"Which actor played the Joker in 'The Dark Knight' (2008)?","choices":["A) Jack Nicholson","B) Jared Leto","C) Heath Ledger","D) Joaquin Phoenix"],"answer":"C"},
    {"category":"MOVIES","question":"Which movie features the line 'Here's looking at you, kid'?","choices":["A) Casablanca","B) Citizen Kane","C) Gone with the Wind","D) The Maltese Falcon"],"answer":"A"},
    {"category":"MOVIES","question":"Which film series features a character named 'Darth Vader'?","choices":["A) Star Trek","B) Star Wars","C) Battlestar Galactica","D) The Matrix"],"answer":"B"},
    {"category":"MOVIES","question":"Which animated film features a clownfish named Marlin?","choices":["A) Finding Nemo","B) The Little Mermaid","C) Shark Tale","D) Nemo's Adventure"],"answer":"A"},
    {"category":"MOVIES","question":"Which actor starred as Indiana Jones?","choices":["A) Harrison Ford","B) Tom Cruise","C) Mel Gibson","D) Sean Connery"],"answer":"A"},
    {"category":"MOVIES","question":"Which movie is famous for the line 'You can't handle the truth!'?","choices":["A) A Few Good Men","B) Top Gun","C) The Godfather","D) Rain Man"],"answer":"A"},

    {"category":"MUSIC","question":"Which singer is known as the 'King of Pop'?","choices":["A) Elvis Presley","B) Michael Jackson","C) Prince","D) Stevie Wonder"],"answer":"B"},
    {"category":"MUSIC","question":"Which instrument typically has six strings?","choices":["A) Violin","B) Guitar","C) Flute","D) Trumpet"],"answer":"B"},
    {"category":"MUSIC","question":"Which band recorded 'Hey Jude'?","choices":["A) The Rolling Stones","B) The Beatles","C) The Who","D) Led Zeppelin"],"answer":"B"},
    {"category":"MUSIC","question":"Which genre is characterized by improvisation and swing?","choices":["A) Classical","B) Jazz","C) Country","D) Techno"],"answer":"B"},
    {"category":"MUSIC","question":"Which composer wrote the 'Fifth Symphony' with the famous four-note motif?","choices":["A) Mozart","B) Beethoven","C) Bach","D) Tchaikovsky"],"answer":"B"},
    {"category":"MUSIC","question":"Which pop star released the album '1989'?","choices":["A) Adele","B) Taylor Swift","C) Rihanna","D) Katy Perry"],"answer":"B"},
    {"category":"MUSIC","question":"Which instrument uses a bow to produce sound?","choices":["A) Piano","B) Saxophone","C) Violin","D) Guitar"],"answer":"C"},
    {"category":"MUSIC","question":"Which music streaming company launched in 2008 and popularized playlists?","choices":["A) Apple Music","B) Spotify","C) Pandora","D) Tidal"],"answer":"B"},

    {"category":"TECH","question":"What does 'HTTP' stand for in web addresses?","choices":["A) HyperText Transfer Protocol","B) High Transfer Text Protocol","C) Hyperlink Text Transfer Process","D) Host Transfer Text Protocol"],"answer":"A"},
    {"category":"TECH","question":"Which company makes the Windows operating system?","choices":["A) Apple","B) Google","C) Microsoft","D) IBM"],"answer":"C"},
    {"category":"TECH","question":"What is the name for malicious software?","choices":["A) Firmware","B) Malware","C) Shareware","D) Freeware"],"answer":"B"},
    {"category":"TECH","question":"Which device converts digital audio into sound you can hear?","choices":["A) Modem","B) DAC (digital-to-analog converter)","C) Router","D) GPU"],"answer":"B"},
    {"category":"TECH","question":"What does 'AI' stand for?","choices":["A) Automated Interface","B) Artificial Intelligence","C) Applied Internet","D) Analog Input"],"answer":"B"},
    {"category":"TECH","question":"Which company developed the Android operating system?","choices":["A) Microsoft","B) Apple","C) Google","D) Samsung"],"answer":"C"},
    {"category":"TECH","question":"What does 'CPU' stand for?","choices":["A) Central Processing Unit","B) Computer Power Unit","C) Core Performance Utility","D) Central Program Unit"],"answer":"A"},
    {"category":"TECH","question":"Which technology is used to make contactless payments?","choices":["A) Bluetooth","B) NFC (Near Field Communication)","C) Infrared","D) Wi-Fi"],"answer":"B"},

    {"category":"LITERATURE","question":"Who wrote 'Pride and Prejudice'?","choices":["A) Charlotte Bronte","B) Jane Austen","C) Mary Shelley","D) Emily Dickinson"],"answer":"B"},
    {"category":"LITERATURE","question":"Which epic poem is attributed to Homer?","choices":["A) The Aeneid","B) The Iliad","C) Beowulf","D) Paradise Lost"],"answer":"B"},
    {"category":"LITERATURE","question":"Who wrote 'Hamlet'?","choices":["A) Christopher Marlowe","B) William Shakespeare","C) John Milton","D) Geoffrey Chaucer"],"answer":"B"},
    {"category":"LITERATURE","question":"Which novel features the character Atticus Finch?","choices":["A) To Kill a Mockingbird","B) The Catcher in the Rye","C) Of Mice and Men","D) The Grapes of Wrath"],"answer":"A"},
    {"category":"LITERATURE","question":"Which author wrote 'The Hobbit'?","choices":["A) C.S. Lewis","B) J.R.R. Tolkien","C) J.K. Rowling","D) Ursula K. Le Guin"],"answer":"B"},
    {"category":"LITERATURE","question":"Which book begins 'It was the best of times, it was the worst of times'?","choices":["A) Great Expectations","B) A Tale of Two Cities","C) Oliver Twist","D) David Copperfield"],"answer":"B"},
    {"category":"LITERATURE","question":"Which poet wrote 'The Raven'?","choices":["A) Robert Frost","B) Walt Whitman","C) Edgar Allan Poe","D) T.S. Eliot"],"answer":"C"},
    {"category":"LITERATURE","question":"Which novel is set on the fictional island of Pemberley?","choices":["A) Emma","B) Sense and Sensibility","C) Pride and Prejudice","D) Mansfield Park"],"answer":"C"},

    {"category":"ANIMALS","question":"Which mammal is known for echolocation?","choices":["A) Dolphin","B) Bat","C) Elephant","D) Kangaroo"],"answer":"B"},
    {"category":"ANIMALS","question":"What is a group of lions called?","choices":["A) Pack","B) Herd","C) Pride","D) School"],"answer":"C"},
    {"category":"ANIMALS","question":"Which bird is known for its ability to mimic human speech?","choices":["A) Sparrow","B) Parrot","C) Pigeon","D) Crow"],"answer":"B"},
    {"category":"ANIMALS","question":"Which animal is the largest living land animal?","choices":["A) Rhino","B) Elephant","C) Hippo","D) Giraffe"],"answer":"B"},
    {"category":"ANIMALS","question":"Which marine creature has eight arms?","choices":["A) Squid","B) Octopus","C) Jellyfish","D) Starfish"],"answer":"B"},
    {"category":"ANIMALS","question":"Which insect goes through metamorphosis from caterpillar to adult?","choices":["A) Ant","B) Butterfly","C) Grasshopper","D) Beetle"],"answer":"B"},
    {"category":"ANIMALS","question":"Which animal is famous for building dams?","choices":["A) Beaver","B) Otter","C) Muskrat","D) Platypus"],"answer":"A"},
    {"category":"ANIMALS","question":"Which reptile changes color to blend with its surroundings?","choices":["A) Snake","B) Lizard (chameleon)","C) Turtle","D) Crocodile"],"answer":"B"},

    {"category":"FOOD","question":"Which cheese is traditionally used on pizza?","choices":["A) Cheddar","B) Mozzarella","C) Brie","D) Feta"],"answer":"B"},
    {"category":"FOOD","question":"Saffron is obtained from which part of a flower?","choices":["A) Petal","B) Stigma","C) Stem","D) Leaf"],"answer":"B"},
    {"category":"FOOD","question":"Which cuisine is sushi associated with?","choices":["A) Chinese","B) Japanese","C) Thai","D) Korean"],"answer":"B"},
    {"category":"FOOD","question":"What is tofu made from?","choices":["A) Rice","B) Soybeans","C) Wheat","D) Corn"],"answer":"B"},
    {"category":"FOOD","question":"Which fruit is a cross between a raspberry and a blackberry?","choices":["A) Loganberry","B) Blueberry","C) Strawberry","D) Gooseberry"],"answer":"A"},
    {"category":"FOOD","question":"Which nut is used to make marzipan?","choices":["A) Almond","B) Walnut","C) Cashew","D) Pecan"],"answer":"A"},
    {"category":"FOOD","question":"Which spice is ground from dried red peppers and often used in Mexican cuisine?","choices":["A) Cumin","B) Paprika","C) Turmeric","D) Cardamom"],"answer":"B"},
    {"category":"FOOD","question":"Which grain is the main ingredient in risotto?","choices":["A) Basmati rice","B) Arborio rice","C) Quinoa","D) Barley"],"answer":"B"},

    {"category":"SPORTS","question":"How many players are on a soccer team on the field per side?","choices":["A) 9","B) 10","C) 11","D) 12"],"answer":"C"},
    {"category":"SPORTS","question":"Which sport uses a pommel horse?","choices":["A) Gymnastics","B) Equestrian","C) Wrestling","D) Fencing"],"answer":"A"},
    {"category":"SPORTS","question":"Which country hosted the 2016 Summer Olympics?","choices":["A) China","B) Brazil","C) UK","D) Russia"],"answer":"B"},
    {"category":"SPORTS","question":"In tennis, what score comes after 40-40?","choices":["A) Advantage","B) Deuce","C) Game","D) Set"],"answer":"B"},
    {"category":"SPORTS","question":"Which sport is known as 'the beautiful game'?","choices":["A) Basketball","B) Soccer (football)","C) Rugby","D) Cricket"],"answer":"B"},
    {"category":"SPORTS","question":"How many points is a touchdown worth in American football?","choices":["A) 3","B) 6","C) 7","D) 8"],"answer":"B"},
    {"category":"SPORTS","question":"Which sport uses a shuttlecock?","choices":["A) Tennis","B) Badminton","C) Squash","D) Table tennis"],"answer":"B"},
    {"category":"SPORTS","question":"Which race is traditionally 26.2 miles long?","choices":["A) Half marathon","B) Marathon","C) 10K","D) Ultramarathon"],"answer":"B"},

    {"category":"SPACE","question":"Which planet is known for its rings?","choices":["A) Jupiter","B) Saturn","C) Mars","D) Venus"],"answer":"B"},
    {"category":"SPACE","question":"What is the name of Earth's natural satellite?","choices":["A) Luna (the Moon)","B) Phobos","C) Deimos","D) Europa"],"answer":"A"},
    {"category":"SPACE","question":"Which spacecraft first landed humans on the Moon?","choices":["A) Apollo 11","B) Voyager 1","C) Sputnik 1","D) Challenger"],"answer":"A"},
    {"category":"SPACE","question":"What is the term for a system of millions or billions of stars, together with gas and dust?","choices":["A) Planet","B) Galaxy","C) Nebula","D) Comet"],"answer":"B"},
    {"category":"SPACE","question":"Which planet is known as the Red Planet?","choices":["A) Venus","B) Mars","C) Mercury","D) Neptune"],"answer":"B"},
    {"category":"SPACE","question":"What do we call a small body of ice and dust that orbits the Sun and sometimes forms a tail?","choices":["A) Asteroid","B) Comet","C) Meteor","D) Dwarf planet"],"answer":"B"},
    {"category":"SPACE","question":"Which star is at the center of our solar system?","choices":["A) Proxima Centauri","B) The Sun","C) Sirius","D) Vega"],"answer":"B"},
    {"category":"SPACE","question":"What is the name of the galaxy nearest to the Milky Way?","choices":["A) Triangulum","B) Andromeda","C) Whirlpool","D) Sombrero"],"answer":"B"},

    {"category":"RANDOM","question":"Which shape has four equal sides and four right angles?","choices":["A) Rectangle","B) Rhombus","C) Square","D) Trapezoid"],"answer":"C"},
    {"category":"RANDOM","question":"Which color is created by mixing yellow and blue?","choices":["A) Green","B) Orange","C) Purple","D) Brown"],"answer":"A"},
    {"category":"RANDOM","question":"How many continents are there on Earth?","choices":["A) 5","B) 6","C) 7","D) 8"],"answer":"C"},
    {"category":"RANDOM","question":"Which month comes after July?","choices":["A) June","B) August","C) September","D) May"],"answer":"B"},
    {"category":"RANDOM","question":"Which unit measures temperature in most of the world?","choices":["A) Fahrenheit","B) Kelvin","C) Celsius","D) Rankine"],"answer":"C"},
    {"category":"RANDOM","question":"Which tool is used to measure time intervals?","choices":["A) Thermometer","B) Stopwatch","C) Barometer","D) Altimeter"],"answer":"B"},
    {"category":"RANDOM","question":"Which day of the week is commonly considered the first day in many calendars?","choices":["A) Sunday","B) Monday","C) Saturday","D) Friday"],"answer":"A"},
    {"category":"RANDOM","question":"Which direction does the sun rise from?","choices":["A) North","B) South","C) East","D) West"],"answer":"C"}
]


# ==========================
#   UTILITY: find full choice text by letter
# ==========================

def find_choice_text(choices, letter):
    letter = letter.upper()
    for c in choices:
        s = c.strip().upper()
        if s.startswith(letter + ")") or s.startswith(letter + ".") or s.startswith(letter + " "):
            return c
    return letter


# ==========================
#   NEW: Shuffle choices per question (keeps correct mapping)
# ==========================

def _strip_label(choice_str):
    # Remove leading label like "A) " or "A. " or "A "
    parts = choice_str.split(')', 1)
    if len(parts) == 2:
        return parts[1].strip()
    parts = choice_str.split('.', 1)
    if len(parts) == 2:
        return parts[1].strip()
    # fallback: remove first 2 chars if they look like "A "
    return choice_str[2:].strip() if len(choice_str) > 2 else choice_str.strip()

def shuffle_choices_for_question(q):
    """Shuffle the choices for a single question and update q['choices'] and q['answer'] accordingly."""
    original_choices = q.get("choices", [])
    if not original_choices:
        return

    # Extract plain texts
    texts = [_strip_label(c) for c in original_choices]

    # Determine original correct text
    orig_letter = q.get("answer", "A").upper()
    letter_to_index = {"A": 0, "B": 1, "C": 2, "D": 3}
    orig_index = letter_to_index.get(orig_letter, 0)
    if orig_index >= len(texts):
        orig_index = 0
    correct_text = texts[orig_index]

    # Shuffle texts
    shuffled = texts[:]
    random.shuffle(shuffled)

    # Reformat with letters
    letters = ["A", "B", "C", "D"]
    new_choices = []
    for i, t in enumerate(shuffled):
        label = letters[i] if i < len(letters) else f"X{i}"
        new_choices.append(f"{label}) {t}")

    # Find new index of correct_text
    try:
        new_index = shuffled.index(correct_text)
    except ValueError:
        new_index = 0

    q["choices"] = new_choices
    q["answer"] = letters[new_index] if new_index < len(letters) else "A"


# ==========================
#   GAME LOGIC (speaks question and speaks correct answer)
#   Allows user to choose number of questions
# ==========================

def play_game():
    total_questions = len(questions)

    # Ask user how many questions they want; infer if input invalid
    prompt = f"How many questions would you like to answer? (1-{total_questions}) or press Enter for all: "
    user_input = input(prompt).strip()

    if user_input == "":
        num = total_questions
    else:
        try:
            requested = int(user_input)
            # Clamp to valid range
            if requested < 1:
                num = 1
            elif requested > total_questions:
                num = total_questions
            else:
                num = requested
        except Exception:
            # If parsing fails, default to all
            num = total_questions

    # Select num random questions without replacement
    selected_questions = random.sample(questions, num)

    score = 0
    random.shuffle(selected_questions)  # randomize order of selected questions

    print("\n==============================")
    print("      JEOPARDYISH QUIZ GAME")
    print("==============================\n")

    speak("Welcome to Jeopardyish Quiz Game. Questions will be spoken and the correct answer will be spoken after each question.")

    for idx, q in enumerate(selected_questions, start=1):
        # Shuffle choices for this question so choices are random each time
        shuffle_choices_for_question(q)

        category = q["category"]
        question = q["question"]
        choices = q["choices"]
        correct_letter = q["answer"].upper()

        # Announce question number and category
        header = f"Question {idx} of {num}. Category: {category}."
        print(header)
        speak(header)

        # Speak the question
        print(question)
        speak(question)

        # Speak choices
        for choice in choices:
            print(choice)
            speak(choice)

        # Get user answer
        user_answer = input("\nYour answer (A/B/C/D or Q to quit): ").strip().upper()

        if user_answer == "Q":
            speak("You chose to quit. Goodbye.")
            print("\nYou chose to quit. Thanks for playing!")
            sys.exit()

        # Determine correct choice text and speak result
        correct_choice_text = find_choice_text(choices, correct_letter)
        if user_answer == correct_letter:
            print("Correct!\n")
            speak("Correct")
            score += 1
        else:
            print(f"Incorrect! The correct answer was {correct_letter}: {correct_choice_text}\n")
            speak("Incorrect")

        # Always speak the correct answer explicitly
        speak(f"The correct answer is {correct_choice_text}")

    speak(f"Game over. Your score is {score} out of {num}")
    print(f"Game Over! Your final score: {score}/{num}")


if __name__ == "__main__":
    play_game()
