import random
import subprocess
import sys
import shutil

FLAVORS = [
    "Vanilla", "Chocolate", "Strawberry", "Mint Chocolate Chip", "Pralines n Cream",
    "Rocky Road", "Jamoca Almond Fudge", "Cookies n Cream", "Butter Pecan",
    "Cotton Candy", "Rainbow Sherbet", "Pistachio Almond", "Chocolate Fudge",
    "Very Berry Strawberry", "Lemon Custard", "Caramel Turtle Truffle",
    "Gold Medal Ribbon", "World Class Chocolate", "Nutty Coconut", "Black Cherry",
    "Mango", "Green Tea", "Dulce de Leche", "Espresso Royale", "Birthday Cake",
    "Peanut Butter n Chocolate", "Salted Caramel", "Blueberry Cheesecake",
    "Cappuccino Crunch", "Honey Lavender", "Raspberry Sorbet"
]

def speak(text: str) -> bool:
    """
    Try to speak `text` using only system tools. Returns True if spoken, False otherwise.
    """
    text = str(text).strip()
    if not text:
        return False

    # macOS: say
    if sys.platform == "darwin":
        try:
            subprocess.run(["say", text], check=False)
            return True
        except Exception:
            pass

    # Windows: use PowerShell System.Speech (no external packages)
    if sys.platform.startswith("win"):
        # PowerShell single-quote escaping: double single quotes inside single-quoted string
        safe = text.replace("'", "''")
        ps_cmd = f"Add-Type -AssemblyName System.Speech; " \
                 f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe}')"
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return True
        except Exception:
            pass

    # Linux / other: try espeak or spd-say if available
    espeak = shutil.which("espeak")
    if espeak:
        try:
            subprocess.run([espeak, text], check=False)
            return True
        except Exception:
            pass

    spd = shutil.which("spd-say")
    if spd:
        try:
            subprocess.run([spd, text], check=False)
            return True
        except Exception:
            pass

    # No TTS available
    return False

def generate_sundae(num_scoops: int, allow_duplicates: bool = False) -> list:
    if num_scoops <= 0:
        raise ValueError("Number of scoops must be at least 1.")
    if not allow_duplicates and num_scoops > len(FLAVORS):
        raise ValueError(f"Cannot pick {num_scoops} unique scoops from {len(FLAVORS)} flavors.")
    if allow_duplicates:
        return [random.choice(FLAVORS) for _ in range(num_scoops)]
    return random.sample(FLAVORS, num_scoops)

def pretty_print_sundae(scoops: list):
    print("\nYour random sundae:")
    for i, flavor in enumerate(scoops, start=1):
        print(f"  Scoop {i}: {flavor}")
    print()

def ask_yes_no(prompt: str, default: str = "n") -> bool:
    while True:
        ans = input(prompt).strip().lower()
        if ans == "" and default:
            ans = default
        if ans in ("y", "yes"):
            return True
        if ans in ("n", "no"):
            return False
        print("Please answer 'y' or 'n'.")

def main():
    print("Welcome to the 31 Flavors Randomizer with TTS!")
    tts_enabled = ask_yes_no("Enable spoken output (TTS) if available? (Y/n): ", default="y")
    while True:
        try:
            n = int(input("How many scoops would you like? ").strip())
        except ValueError:
            print("Please enter a whole number.")
            continue

        allow_dup = False
        if n > len(FLAVORS):
            allow_dup = ask_yes_no(
                f"You asked for {n} scoops but there are only {len(FLAVORS)} unique flavors.\n"
                "Allow duplicates so flavors can repeat? (y/N): ", default="n"
            )

        try:
            scoops = generate_sundae(n, allow_duplicates=allow_dup)
        except ValueError as e:
            print("Error:", e)
            continue

        pretty_print_sundae(scoops)

        if tts_enabled:
            # Speak a short summary, then each scoop
            summary = f"Here is your {n}-scoop sundae."
            spoken = speak(summary)
            if not spoken:
                print("(TTS not available on this system.)")
            else:
                # speak each scoop with a short pause
                for i, flavor in enumerate(scoops, start=1):
                    speak(f"Scoop {i}: {flavor}")

        if not ask_yes_no("Generate another sundae? (Y/n): ", default="y"):
            print("Thanks for using 31 Flavors Randomizer. Enjoy your scoops!")
            break

if __name__ == "__main__":
    main()
