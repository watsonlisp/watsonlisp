#!/usr/bin/env python3
"""
bbs_menu_interactive.py

Menu-driven BBS chooser + interactive telnet-like client.

Features:
- CURATED_BBS + EXTRA_BBS_RAW loaded from user-provided list.
- Interactive sessions: terminal is placed into raw mode and keystrokes are forwarded immediately.
- Telnet IAC negotiation handling.
- Auto-login monitor (optional).
- Repeat/reconnect support.
- Favorites saved to ~/.bbs_login_favorites.json
- Continuous listing (no pagination pause).
- Shows Available BBS hosts only once at startup.
"""

from __future__ import annotations
import argparse
import socket
import sys
import time
import threading
import select
import os
import json
import getpass
import subprocess
import shutil

# Optional pyttsx3 import (fallback if available)
try:
    import pyttsx3
    PYTTSX3_AVAILABLE = True
except Exception:
    PYTTSX3_AVAILABLE = False

# Platform detection
IS_WINDOWS = sys.platform.startswith("win")
if not IS_WINDOWS:
    try:
        import termios, tty
    except Exception:
        termios = None
        tty = None
else:
    import msvcrt

# Telnet IAC constants
IAC = 255
DO = 253
DONT = 254
WILL = 251
WONT = 252
SB = 250
SE = 240

CONNECT_TIMEOUT = 6.0
RECV_TIMEOUT = 0.2
FAV_FILE = os.path.expanduser("~/.bbs_login_favorites.json")

# -------------------------
# Curated list of telnet-accessible hosts (host, port, note)
# -------------------------
CURATED_BBS = [
    ("bbs.decafbad.com", 6523, "0xDECAFBAD BBS"),
    ("13th.hoyvision.com", 6400, "13th Floor BBS"),
    ("13leader.net", 8023, "13th Leader BBS"),
    ("20forbeers.com", 1337, "20 For Beers BBS"),
    ("x-bit.org", 23230, "32-Bit BBS"),
    ("172.0.79.226", 23, "3D Realms"),
    ("bbs.4wheelham.com", 23, "4 Wheel Ham BBS"),
    ("bbs.4d2.org", 23, "4D2 Dot Org BBS"),
    ("64vintageremixbbs.dyndns.org", 6400, "64 Vintage BBS"),
    ("bbs.8bitlair.net", 6400, "8 Bit Lair BBS"),
    ("bbs.8-bitarchive.com", 2223, "8-Bit Archive"),
    ("bbs.8bitboyz.com", 6502, "8-Bit Boyz BBS"),
    ("8bit.hoyvision.com", 6400, "8-Bit Playground"),
    ("telnet.84-24.org", 23, "84-24"),
    ("bbs.8bitclub.com", 6502, "8Bit Club BBS"),
    ("abrotherto.dragons.systems", 23, "A Brother to Dragons"),
    ("droid.a-net.online", 2323, "A-Net Online (Droid Matrix)"),
    ("game.a-net-online.lol", 513, "A-Net Online (Game Server)"),
    ("x.a-net.online", 1337, "A-Net Online (Menu)"),
    ("mystic-anet.online", 23, "A-Net Online (Mystic)"),
    ("sf.a-net.online", 2323, "A-Net Online (Spitfire)"),
    ("a-net.online", 23, "A-Net Online (Synchronet)"),
    ("game.a-net-online.lol", 2002, "A-Net Online (TWGS)"),
    ("bbs.a-net.fyi", 2233, "A-Net Online ANetBBS"),
    ("x.a-net.online", 2323, "A-Net Online Beta BBS"),
    ("a1bbs.ddns.net", 23, "A1 BBS"),
    ("abandonedstardock.ddns.net", 2002, "Abandoned StarDock TWGS"),
    ("absinthebbs.net", 1940, "Absinthe BBS"),
    ("bbs.abyssnode.net", 23, "Abyss BBS"),
    ("chaotix.ddns.net", 2323, "Ace of Spades BBS"),
    ("blackflag.acid.org", 31337, "Acid Underworld"),
    ("adeptbbs.com", 23, "Adept BBS"),
    ("aerodromebbs.com", 6502, "Aerodrome BBS"),
    ("ah-bbs.com", 2333, "After Hours BBS"),
    ("agency.bbs.nz", 23, "Agency BBS"),
    ("krion.io", 1337, "Agon BBS"),
    ("67.205.168.255", 2323, "Aincrad BBS"),
    ("bbs.airandwave.net", 2323, "Air & Wave BBS"),
    ("bbs.alsgeeklab.com", 2323, "Al’s Geek Lab BBS"),
    ("alamobbs.mywire.org", 6400, "Alamo BBS"),
    ("bbs.alcatrash.org", 23, "AlcaBBS"),
    ("alcatrazbbs.ddns.net", 9000, "Alcatraz Prison BBS"),
    ("alcoholidaybbs.com", 23, "Alcoholiday BBS (Mystic)"),
    ("alcoholidaybbs.com", 95, "Alcoholiday BBS (Renegade)"),
    ("bbs.alecoexp.cz", 23, "Aleco Experience BBS"),
    ("alephbbs.com", 2626, "Aleph BBS"),
    ("the.alienmindbenders.net", 23, "Alien Mindbenders BBS"),
    ("newt.aliens.ph", 23, "Aliens' Alcove"),
    ("fido.alltsk.ru", 23, "Alltsk Fido"),
    ("acentauribbs.no-ip.org", 2002, "Alpha Centauri BBS"),
]

# -------------------------
# Extra curated entries loaded from the provided "BBS NAMETELNETMODEM" document.
# -------------------------
EXTRA_BBS_RAW = """
Bass Planetthebassplanet.com:64128
Baudvilleamis86.ddns.net:9000
Bayou BBSjayctheriot.com:6401
Bayou Blog BBSbayoublog.ddns.net
BBS Developmentbbsdev.net
BBS Gamerbbsgamer.ddns.net:2600
BBS OldChatbbs.oldchat.ru
BBS Orrelibbs.orreli.net:45023
BBS Retrocampusbbs.retrocampus.com
BBS Telesc.net.brbbs.telesc.net.br+554831984696 (not verified)
BBS Tournament Wordlebbswordle.com
BBS.b3ck.combbs.b3ck.com
BBS.JasonWalker.cabbs.jasonwalker.ca:2323
BBS.p1.lolbbs.p1.lol
BBS.Telearena.usbbs.telearena.us
BCG-Boxbbbs.net
BCR Games Serverbcrgames.com:31337
Bear’s Denbbs.bearfather.net
Beastiebbs.nxeed.com
Beiyou Forumbbs.byr.cn
BeOS Citybeos.retro-os.live
Beryl BBSberyl.h-o-soft.com:2323
Big Jim’s Secret Emporiumbbs.bigjim.ventures:6969
Big Rabbit BBSbunnybbs.tw
Big Time BBSbigtimebbs.net:2323+44-1484-320007 (Verified May 2026)
Big5 BBS39.106.161.147
BirdEnuf BBSbbs.birdenuf.com:2003
Bits & Bytes BBSbbs.bnbbbs.net:2023
Bitwoods RBBS-PCbitwoods.duckdns.org
Black Flag BBSblackflag.acid.org
Black Tower BBSblackflag.acid.org:26
BlackICEblackice.bbsindex.de
Blacklight Undergroundacentauribbs.no-ip.org:2424
Blackstar BBSblackstar-bbs.servegame.com
Blood MUDbbs.bloodmud.com
Blood Stonewwiv.bsbbs.com:2323
BLOODBBSblood.bbsn.us:2323
Bluehard BBSbbs.bluehard.com
Blurred Visionbbs.novass.net:2323
Boar’s Head Tavernbyob.hopto.org:64128
BodaX BBSbbs.beardy.se
Boebertfeet66.228.38.176:52270
Boneyard BBS, Theboneyard-bbs.com:8073
BoobTubebbs.wz5bbs.com
Books Chess Serverbooks.internetking.us:5000
Boot Factory 2K+bfbbs.no-ip.com:8888
Borderline BBSborderlinebbs.dyndns.org:6400951-652-1690
Bottomless Abyss BBSbbs.bottomlessabyss.net:2023
Brain Storm BBS (SSH)bsbbs.com.br:22
Brazi.netbrazi.net
Brett Bender BBS207.90.251.241:2323
Brewery BBSthebrewery.servebeer.com:6400
Brian’s Blog TWGStw2002.briancmoses.com
Brigandinebrigandine.org:9390
Brokedown Palace BBSpalace.brokedownpalace.online:2323
Broken Bubblebbs.thebrokenbubble.com
Brotherhood Of Groovynessbbs.b-o-g.org
Bucko’s Denbdn.wrgnbr.com:6800
BUEMA BBSbbs.buema.ch:2300
Bumgun Club BBSbumgun.club
BurbSec BBS104.131.160.109:4240
Butterfly BBSbbs.byr.cn
ByteBarn BBSbbs.bytebarn.de:2300
C128bbs.ddns.netc128bbs.ddns.net:6301
C3BBSc3bbs.retronetworking.org
C64 Ultimate Clubc64u.club:6400
Cabin BBS, Thethecabinbbs.com:6400
Camelot BBScamelotbbs.ddns.net:2323
Canada Remote Systemsphotorm.net
Canerduh BBS (Mystic)bbs.canerduh.com:23905
Canerduh BBS (VADV)bbs.canerduh.com:23903
Capital Station BBScsbbs.dyndns.org
Capitol City Online BBScapitolcityonline.net
Capitol Shrill BBScapitolshrill.com
Captain’s Quarters BBS IIcqbbs.ddns.net:6800
Casbahcasbah.goip.de:5354
Castle Rock BBS63.230.156.110:2424
Catch 22 BBS (Daydream)catch22bbs.org:26
Catch 22 BBS (Impulse)catch22bbs.org:28
Catch 22 BBS (Renegade)catch22bbs.org:24
Catpit BBSbbs.cis92.net
Cave BBScavebbs.homeip.net
CB2 Micro BBSemail.qrp.gr:2323
Cbaxyz TWGStdod.org:2002
CBBS/TNcbbs.mitsaltair.com:8800
CCUW BBSrtc.to
CCX BBSbbs.ccxbbs.net
CECCcecc.everettjamalhall.com:8888
CedarValley BBS63.230.156.110:2525
CedarValley BBS 263.230.156.110:2626
Cellfish BBScloud.kanskje.com
Cement Cityscenewall.bbs.io:4000
Central Ontario Remote Synchrocentralontarioremote.net:2323
Centronian BBSbbs.centronian.ca:6400
Chaotic Factor BBSchfbbs.net
Chatter BBSchatter.pw:2323
Chick-N-Bone’s HumanNip Trapgame.human-interact.com
Chimia BBSchimia.se:2323
Choice Core BBS (1st)1stchoicecore.co.nz
Choice Core BBS (2nd)
Chosenman BBS, Thechosenman.duckdns.org
Chris BBScloud.iiot-factory.com
Christian Fellowshipcfbbs.no-ip.com:26
Chrysalis Online Services TBBS BBSchrysalisbbs.org:8888
CIA Amiga BBSciaamiga.org:6400
CIRCL’s BBSbbs.circl.lu
Citadel 64 BBScitadel64.thejlab.com:6400
Citrick BBScitlmbbs.synchro.net:2300
Cittadella BBSbbs.cittadellabbs.it:4001
City Of Angels BBShouseoftna.xyz
City on the Edge of Foreverinterzone.annexia.xyz:2002
CJ’s Placecjsplace.thruhere.net
Clacker Workscw.qc.to:9000
Classic BBSboard.classicbbs.net:9339
Classic Computing BBSbbs.classiccomputing.net
Classic Macs BBSmacos.retro-os.live
Claude’s BBSclaudes.lovelybits.org:2323
Clover Love (Chinese)segaa.net
Clube da Insonia BBSbbs.conf.eti.br
Clutch BBSclutchbbs.com
Coalfields BBScoalfields.synchronetbbs.org
COCONetcoconet.ddns.net:6809
COE BBSbbs.eow.lol:2377
COE/EOWeow.lol:2377
Cold Fusion BBScfbbs.net
Cold Winter Knightsbbs.coldwinterknights.net:8888
Colossus BBSbbs.qzwx.com
Commodore 64 BBScommodore64bbs.com:6464
Commodore Imagecib.dyndns.org:6400
Commodore Image IIcib.dyndns.org:6401
Commodore Image IIIcib.dyndns.org:6402
Comms Nuts BBSworkstation.ddmcomputers.com.au:2323
Compunet Rebornvme.compunet.live:6401
Computer Expresscebbs.costakis.org
Computer Godcpugod.net
Constructive Chaos BBSconchaos.synchro.net
Convolutionconvolution.us
Cool Davidbbs.cooldavid.org
Cottonwood BBScottonwoodbbs.dyndns.org:6502951-652-1690
CP/M Dencpmden.ddns.net:1024
Cr1mson BBS45.134.226.117:23777
Crack In Time BBScrackintimebbs.ddns.net:2323
CrappieCracker Online BBSwww.crappiecracker.com:2323
Crawford Family Officediaspara.ca:2323
Crazy Eric’s BBSbbs.crazyerics.com
Crazy Paradisecpbbs.de:2323
Crazy Terminalcrazytermbbs.duckdns.org:6411
Crazy World BBS (Game Server)crazyworldbbs.com:888
Crazy World BBS (Mystic)crazyworldbbs.com:2324
Crimson Protocol BBScp-bbs.com
Crisis/Line BBScrisisbbs.net
CrNet BBSbbs.crnet.net:2323
Crusty Chicken TWGSstream.thecrustychicken.com
Crystal Palacecptalker.com:9900
Crystal Setzl4kj.nz
Curioscurios.synchronetbbs.org
CVCFED168.138.77.143
Cyber Swordbbs.excalibursheath.com
Cyberdawg BBSkuehlbox.wtf:1337
Cyrellia BBSbbs.cyrellia.com
D0P3 BBSbbs.intersrv.net
Danger Bay BBSdangerbaybbs.dyndns.org:1337
Dank Domainplay.ddgame.us
Dark Endlessdarkendlessbbs.hopto.org:6510
Dark Game BBSdarkgame.buanzo.org
Dark Realmsbbs.darkrealms.ca647-847-2083
Dark Wastelandsdarkwastelands.com:8888
DarkForce! BBS, Thedarkforce-bbs.dyndns.org:1040
Darklabs Research Institutewizball.hellasleeper.com:2323
Darkleveldarklevel.hopto.org:64128
DarkMatter’s TWGStwgs.geekm0nkey.com
Darkside BBSthedarkside.ath.cx:64128
DarkWell BBS, Theriverstyx.ddns.net:2324
Darkwood BBSdarkwood.ddns.net
Dave’s BBSdavesbbs.com
Dawn of Demise (MajorBBS)tdod.org:3000
Dawn of Demise (Synchronet)tdod.org:5000
Dawn of Demise (Worldgroup)tdod.org
Day Of The Tentacledott.synchro.net:2424
Dead Carrier BBSthe-rotten-core.strangled.net:2323
Dead Internet Societydeadinternet.synchronetbbs.org
Dead Linesdeadlines.ddns.net:6510
Dead Modem Societytelnet.deadmodemsociety.com:1337
Dead Zone BBSdzbbs.hopto.org:64128
Deadbeatz BBSdeadbeatz.org
Deadline BBSt0x.net:1337
Death Row BBSdeathrow.servebbs.org:1001
Decades BBSdecades.freeddns.org:6401
DeepSkies BBSbbs.deepskies.com:6400
Delta City BBSdeltacity.se+46-8-6058800 (no answer May 2026)
Demigoth BBSbbs.demigoth.com
Demonsnet BBSdemonsnet.com
Der Archivar84.247.143.28:2323
Desert Rats Sanctuary BBSbbs.kn6q.org
Desert Rats Sanctuary TWGSbbs.kn6q.org:2002
Devs42.com BBSdevs42.com:2323
DHXYdhxy.info
Diamond Mine Online (Synchronet)sbbs.dmine.net:24540-369-2900 / 833-473-5400
Diamond Mine Online (WWIV)wwiv.dmine.net:2323540-369-2900 / 833-473-5400
Digicom BBSbbs.digicombbs.com:2323
Digital Dial BBSdigitaldial.homeunix.com:2300
Digital Distortionbbs.digitaldistortionbbs.com971-910-4722
Digital Dreamsddreams.synchro.net
Digital Highwaydigitalhighway.com.se:1084
Digital Line BBSvorpahl.online
Digital Rainbowbbs.digitalrainbow.info
Digital Shelter BBS71.9.202.10
Digital Warfarebbs.digital-warfare.net:1337
Digital-Xdigitalx.ddns.net:7411
Dime BBSalcoholidaybbs.com:94
Disconnected by Peer BBSbbs.disconnected-by-peer.at
Diskbox ][tag.diskbox2.net
Diskhoppers Palace BBSdiskhopp.synchro.net
Distant Empires BBSbbs.distantempires.com:8023
Distortiond1st.org
DJ Dave BBSdjdave.uk:8088
DLWX BBS107.175.69.10:60023
DniproWave BBSbbs.net.ua
Dock Sudbbs.docksud.com.ar
Dogtown BBSbbs.kiwi.net
Door Games Unlimiteddgu.strangled.net
Dove Onlycasper.homeip.net
Down-Lobbs.winzlo.com
DownUnder BBSdownunderbbs.com
Dragon’s Lair BBSdragon.vk3heg.net:6800
Dragonsweb Labs BBSbbs.dragonsweb.org
Dream Gardencd.csie.io
Dream Land BBSccns.cc:3456
Dreamline BBSdin.asciiattic.com
DUAO BBShermes.okyler.com
Duensing Digitalbbs.duensing.digital
Dundarach BBSdundarach.tplinkdns.com
Dungeon BBS (1)59.167.142.49
Dungeon BBS (2)dungeon.darkness.services:2323
Dura-Europosdura-bbs.net:6359
Dynamite BBS (1)dynamite.bbsing.com
Dynamite BBS (2)dynamite.synchronetbbs.org:513
Dyslexic Donkeydydo.erb.pw:1337
Eagle’s Dare BBSbbsdoors.com
Eaglewing BBSeaglewing1962.freeddns.org:6400
Eat My Shorts! BBSems-bbs.com
Echo Chamber BBS50.116.29.47:3640
EchoBase BBSwww.eifelaktiv.de
Echoes BBSechoes.120v.ac
Eclipse BBSeclipsebbs.com
Eclipse TWGSeclipsebbs.com:2002
Efectolinuxbbs.efectolinux.com
El Vicioelvicio.net
Eldritch Clockworkeldritchclockwork.net
Electronic Chicken BBSbbs.electronicchicken.com
Elevator BBSdxtrlab.org
Emerald Valleybbs.emeraldvalley.net
Empire of the Dragon BBSbbs.eotd.com303-679-0161
EMU486bbs.emu486.net
Enchanted BBSchatverse.servehttp.com
End Of The Line BBSendofthelinebbs.com469-200-3550
ENiAC 2.0 BBSeniacv2.net:1337385-202-2120
Enigma BBSenigma-bbs.com
Enlightenlight.hopto.org:6400
Enterprise BBSenterprisebbs.ddns.net:1701
Entropy BBSentropybbs.zapto.org
Error 1202 BBSerror1202bbs.ddns.net:1202
Error 200 Tech BBSbbs.error200.tech:1337
Error 404 (TWGS)error404bbs.ddns.net:24
Error 404 BBS File Servererror404bbs.ddns.net:513
Error 404 BBS Phone Bookerror404bbs.ddns.net:419
Escape To Other Worldsetow.synchro.net
Eternal Domain BBSbbs.eternaldomain.net
Euphoria BBSeuphoria.mudinfo.net:8888
Exile’s Gate BBS139.64.219.31:2323
Extreme BBSbayvillewireless.com
Extricate BBSbbs.extricate.org
Eye of the Beholder (1)fido.beholderbbs.org
Eye Of The Beholder BBS (2)bbs.beholderbbs.org
Eye of the Stormon.the.net.nz
Fading Black23.95.146.28:8282
Falcon BBSbbs.falconbbs.nl
Family BBSfamilybbs.ddns.net
Fastlinefastline.nu:1541
Fatalexe.comfatalexe.com:8888
FDD1fdd.one
Federation Apocalypsefedapoc.tel:2301
Fenglin BBSfenglin.info:2323
Fennec BBS50.116.41.177
Fercho BBSferchobbs.ddns.net:2323
Fiendnetwww.fiendzine.net:8008
File Bank BBStfb-bbs.org
Files 4 Fun BBSbbs.f4fbbs.com:2323
Fireside BBSfiresidebbs.com:23231
First Divisionfdiv.amielite.com:1987
Fleet Headquartersbbs.fleethq.org
FlipperZero BBSbbs.gglab.cloud:2323
FlupH BBSfluph.zapto.org
Fluxpod Information Exchangefix.no:24
FMRLfmrl.throwbackbbs.com:2324
Fool’s Quarter BBSfqbbs.synchro.net
FordServer BBSbbs.fordserver.co
Forem XE BBSforemxebbs.ddns.net:9999
Forze BBSbbs.opicron.eu
Fox-BBSbbs.home.bernardeau.net:9999
Free Cornerbbs.debonne.eu
Freeway BBSfreeway.vkradio.com
French Connectionthefrenchconnexion.ca:31023
Frequency Frequency Synchronicitybbs.longwoodgeek.net
Fria Bad BBSfriabad.hopto.org:64128
Frontier BBSfrontierbbs.co.uk
Frozen Floppy BBSbbs.retrohack.se:64128
fTelnet Demo Serverbbs.ftelnet.ca
Fuji Summitwinnow.1q1.me
Funtopia BBSfuntopia.synchro.net:3023+49-331-2804136 (Verified May 2026)
Furmen Services TWGSfurmenservices.net:2002
Furry Refugebbs.furryrefuge.com
Fusion BBSpruffino.com
Future World IIfw2.cnetbbs.net:6800
Futurelandfutureland.today
Game Masterbbs.game-master.com
Gamenet BBS Networkgamenet.synchronetbbs.org:513
Gate BBS (Synchronet)thegateb.synchro.net
Gate BBS (WWIV)thegateb.synchro.net:2424
Gateway BBSgatewaybbs.net:2023
Genetic-PETg-point.tunk.org:1025
Genetic-Point BBSg-point.tunk.org:500
GeoSyncgeo.synchro.net:223
Ghosts in the Machinetheunderground.us:1717
Ghosts of the Revolution67.223.99.43
Gibson BBSgiaco.net:2323
GigaBite BBSbbs.gigabite.se
Global Chaos BBSglobalchaosbbs.com
Global Village BBSthe.globalvillagebbs.net:2323
Gods69.com BBS92.91.25.209:2323
Goldmine Community Door Game Servergoldminedoors.com:2513
Gone Rogue TWGSroguetw.net:2002
Gongpit, Thebbs.gongpit.com:2323
Goof’s Garagegoofsgarage.com:6464
Goosenet BBSbbs.g00r00.com
Greenhead BBSbbs.greenhead.ca:2323
Grimoire BBSgrimoirebbs.sytes.net
Grinches Realm, Thetgr.freeddns.org
Ground Control BBSgcbbs.net:2323
Ground Zero BBS73.75.95.211:2323
Guardian of Foreverguardian.synchro.net
Guru BBSbbs.bajer.cz:32
Haciend El Bananashaciend.com:8821
Hackerforce BBSbbs.hackerforce.de:2323
Hacki Shackbbs.hackishack.online:6401
Hackmeeting 0x1B BBSsegnalazioni.longinoconsulting.net:8888
Hagar’s Helplinehagars.org.uk:24
Halcyon BBShalcyonbbs.scisweb.org
Halls of Valhalla BBShovalbbs.com:2333
Happylandcitadel.dc540.org:23230
Harada Stationmitsukoharada.com:2323
Hard Drive Cafehdcbbs.com
Hated Realityhatedreality.homeunix.net
Hawaii BBS Atari 8 Bitatari-bbs.zapto.org:8888
Hax0r’s Palacetelnet.unknownrealm.org
Heatwaveheatwave.ddns.net:9640
Heights BBSheightsbbs.heightspc.net:6860800-258-4660 or 520-303-7894
Herbies BBSherbies-bbs.ddns.net:2323
HeXed BBS (Mystic)hexedbbs.com:1337
HeXed BBS (OBV/2)hexedbbs.com:23999
Hidden BBSthe-hidden.hopto.org:64128
Hidden Paradisehpbbs.dyndns.org
High Desert BBShighdesertbbs.ddns.net:6400
HispaMSX BBSbbs.hispamsx.org
Hobbit Empirebbs.hobbitempire.net:6501
Hobbit Station BBSwfido.ru:1234
Hobby Line! BBShobbylinebbs.com
Hobby Spacehobbyspc.synchro.net
Hohimer BBSmail.hohimer.org:1336
Hold Fast BBSinterzone.annexia.xyz:2323
Hologram Computing BBSsbbs.hologramcomputing.net
Honey-At-Homefido.bajtek.org
Hook and Rail BBS35.208.121.0
Horizon BBSbbs.horizonbbs.org
House of Baud BBShouseofbaud.com:8888
Huanian Xiaojiliterature.twbbs.io
HyNET BBSbbs.hyena.network
Hysteria BBSbbs.retrorewind.ca
IB-BBSbbs.ibbs.be
Ice Castle BBSice-castle-bbs.net
Image64bbs.ddns.netimage64bbs.ddns.net:6300
Imzadi Boxbox.imzadi.de
Inconsistency BBSbbs.jsbackus.com:2323
Infonet BBSbbs.rclabs.com.br:2323
Information Exchange BBSiebbs.ddns.net:2323
Inner Coresbbs.ricin.io
Insane Asylum BBS (1)tiabbs.synchro.net
Insane Asylum BBS (2)75.86.99.33
Insight BBSbbs.ihlau.net:2323
Insomniainsomnia.synchronetbbs.org
INTAAbbs.intaa.net
Integrated Telecommunications Centreitcbbs.ddns.net:23000
Intergalactic Loading Dock TWGSild-tw.com:2002
Internal Dimension (AmiExpress)bbs.idbbs.ca:1581
Internal Dimension BBS (Mystic)bbs.idbbs.ca:59
Interstellar Scout Service107.174.246.213:2323
Interstellar TWGS70.122.245.201:2002
Interzonebbs.interzone.cloud
IntraNICfae1.mooo.com:2323
IntraServe138.197.146.22
Iowa Student Assc. BBS (ISCA)bbs.iscabbs.com
IPTIA BBS (Synchronet)bbs2.ipingthereforeiam.com:2323
ISIS Unveiled70.116.73.77
Itchy Butt (Amiga/AmiExpress)itchybutt.org:6400
Itchy Butt BBS (Color 64)itchybutt.org:6502
Jacob’s Hideout BBSbbs.jacobcat.app
JawnCon0x10x1.jawncon.org:8888
Jersey Jam BBSjerseyjam.com
JLR BBS104.189.133.180:8888
Joe’s Computer BBSjoesbbs.com
Jolly Roger BBS, Thebbs.thejollyrogerbbs.com:8023
JumpStart BBSexciter.ws
Jumpstart TWGSexciter.ws:2002
Jungle BBS (1)junglebbs.com
Jupiterjupiter.bbs.io
K4JTT BBSk4jttbbs.ddns.net:2424
Kalgoorlie Retro BBSbbs.theiguru.au:2323
Kats Alleytka.8bitboyz.com:6400
KCM BBS Systemzahrl.ddns.net:2023
KD3netbbs.kd3.us
KD8HFXbbs.kd8hfx.net
KEEP BBSthekeep.net503-852-3170
Kernel Fortresskernelfortress.org
Killed In Action BBSkia.zapto.org
Kingdom’s End BBS (Synchronet)sbbs.kingdomsendbbs.net
Kirika BBSandcycle.idv.tw
KiwiMates96.231.233.47
KK4QBN BBSkk4qbn.synchro.net
Kludge BBSklud.ge312-500-2600
Kng BBSbbs.kng.fi:2323
Korenblombbs.korenblom.nl
KR4KPA’s Cornerbbs.kr4kpa.com
Kraaby Gamer BBSkraaby.synchro.net
L.O.R.D. Towntelnet.lord.town:2323
L33Test Gaming Collectivebbs.l33test.com
Lab BBS, Thebbs.dicksonlabs.net:2325
Lake House BBSlakehouse.lilpenguins.com:2333
Land of the Lostlandofthelost.ca:2300
Landover BBSlandover.synchronetbbs.org
Last Rangers’ BBSlastrangers.com
Last Telegraph Officebbs.acornabbey.us:2323917-259-1391
LateNight DiversiDiallatenight.diversidial.com:313
Legends of Yesteryearfurmenservices.net:2323
Lehigh Valley Vintage Computer Clubbbs.lightly-salted.com:8023
Leisure Time BBSbbs.riddells.net:10023
Level 29bbs.fozztexx.com916-965-1701
Lexicon BBS (Image BBS)lexiconbbs.com:6400
Liane BBSbbs.vslib.cz
Liquid Digital107.220.168.189
Live Wire BBSlivewirebbs.com:1025
LNRC-IN Boardsboard.lnrcbbs.net
Local Yocal BBSlocalyocalbbs.com
Looney Bin BBS!looneybinbbs.com:2023
Lord Jord’s Board BBSbbs.lordjord.xyz:8888
Lord Raptor’s Domain150.221.218.212
Lord.stabs.orglord.stabs.org
Lost Caverns BBStlcbbs.dynu.net:6400
Lost Chord BBS (Commodore BBS)tlcbbs.synchro.net:6400
Lost Chord BBS (Searchlight BBS)tlcbbs.synchro.net:6023
Lostways BBS98.144.7.205
Love Of Net Endless (Chinese)bbs.qeeai.com
LowCrash DEV BBSbbs.lowcrash.dev:8888
LSNET Archivebbs.lsnet.dev
Lunar Outpostlunarout.synchro.net:8023
Lunatics Unleashed BBSlunaticsunleashed.ddns.net:2333
Lytical HackFund BBS134.209.40.1:31337
M. Stationmstation.servebbs.com
M0n.de BBS172.105.27.143
Machdyne BBS206.189.226.31
Madman with a Blue Boxmadmanbbs.ddns.net
MadWorld BBSwww.madworldbbs.com:52146
Magic Systemsbbs.magicbbs.eu:6323
Magnum BBSmagnumbbs.net+44-1484-320007 (Verified May 2026)
Maiden’s Realmbbs.maidensrealm.com
Maiks Place BBSbbs.maik.ch:2323
MajorBBS Official Demo BBSbbs.themajorbbs.com
MajorMud BBS207.96.54.24
MakeStay68.102.160.116
Maltebbs.swedishchef.org
ManetherenWG24.3.154.248
Maniac Zonetmz.synchronetbbs.org:513
Mark Van Daele’s TWGSgame.tw2002.net
MarkoFiume.com BBSmarkofiume.com
Master Boot Recordmbrserver.com
MasterCombbs.sunspothq.dyndns.org
Mastodonmastodon.uy
MaxBBSmaxbbs.ddns.net:24023
Mbpeikertmbpeikert.ddns.net
MBSE Professional Dev BBSphoenix.bnbbbs.net:2323
Medusa BBSmedusagaming.ca:230
Mega BBS Public BBS System, Thethemegabbs.ddns.net:6400
Megadodo Publicationsmegadodo.online:4242
Mel’s Diner199.195.254.241:6800
Memory Hole BBSprogressivepawns.com
Memphis TW BBSbbs.memphistw.org
Memphis TW TWGSbbs.memphistw.org:2002
Metal Zonetmzbbs01.synchro.net
Metro Olografixbbs.olografix.org
MeuLab BBSbbs.meulab.fun
MicroBlaster TWGSmicroblaster.net:2002
Microtown BBSmicrotownbbs.com:6400
Midnight Loungemidnightlounge.online
Mimac Rebirthmimac.bizzi.org:2323
Miya Netmiyanet.moe
Mizuki Community (Newsmth BBS)bbs.newsmth.net
MMNweb.mmn.ca
Mmud.io35.88.220.48
Modemo Tidermodematider.selstam.nu:50023
Modern Retro, Thehiggshightech.org:2323
Moe’s Tavernmoetiki.ddns.net:27502-875-8938
Mojo’s World BBSmojo.synchro.net
Monochromemono.org
Monterey BBSmontereybbs.com
Montreal Greek Times BBSbbs.greektimes.ca
Moon Base Alpha (TWGS)mba.dnsalias.com:2002
Moon Base Alpha (VADV)mba.dnsalias.com
MorningSide Mortuarymortuary.ddns.net
Mousenetbbs-mousenet.dynip.online:8889
Mouth of Hell BBSmouthofhell.duckdns.org
Mozy’s Swamp and Red Dwarf BBSbbs.mozysswamp.org
Mozy’s Swamp and Red Dwarf TWGSbbs.mozysswamp.org:24
MtlGeek (Synchronet)mtlgeek.synchro.net
MtlGeek (TWGS)mtlgeek.synchro.net:2002
Muinetmuinet.com:2323
MULTINUBE-BBSmultinube.net
Murphy BBSmeteo.leopedone.it:2023
Music Stationhome.bsrealm.net
Mutiny BBS (1)mutinybbs.com:2332
Mutiny BBS (2)mutiny.cigdangle.com:65023
Mutiny Communitymutinybbs.com:2300
Myndgame BBSbbs.themyndgame.com
Mysmth BBSbbs.mysmth.net
Mysteria Majicka BBSmajicka.at2k.org:1955
Mystic Hobbiesmystic-hobbies.com
Mystic Realmsmysticrealms.ddns.net:11000
Mystic Rhythms BBSmystic.wwivbbs.org
Mystical Realm BBSmysticalrealmbbs.com
Mythical Kingdom Tech BBSice.lilacway.com:3000
Mythical Kingdom Tech SBBSbbs.mythicalkingdom.com:5023
Mythology BBSmythologybbs.com:6984
Naclcon BBSnaclconbbs.net
Nanyang Innbbs.nykz.net
NCKU CCNSbbs.ccns.ncku.edu.tw:3456
NE BBSnebbs.servehttp.com:9223
Necro-Cyberbbs.abraxas.wtf
Needspace BBSneedspace.us
Neo-Vintage BBSbbs.delorted.com
NerdRage BBSnerdragebbs.ddns.net
Netpoint TWGSnetpoint.webhop.me:2002
Nettwerked BBSnettwerked.synchronetbbs.org
NetVillage Sysop Community96.231.233.50
Neutral Zone TWGScountsflix.com:2002
Never Never Land BBSneverneverlandbbs.com:2323567-304-4098
New World of the Internet209.141.35.127
News BBSbbs.dosnetz.de:3232
NewsNetOnline.org47.32.85.161
Newton Citybbs.newtoncity.org
Nexus BBSnexus.aefinity.io
Night Owl BBSnightowlbbs.ddns.net:6400+44-20-3422-8439 (Verified May 2026)
Nightbite BBSnightbite.redirectme.net:2323
Nightfallbbs.coppens.family
Nightlife BBSnightlife.myexp.de:2323
Nightwire BBS144.91.91.30:8888+07 2143 6740 (unverified)
Nikom BBSbbs.nikom.org:2323
Nine Worlds BBSthenineworlds.dnshome.de:923
Nite Eyes BBS (Mystic)bbs.lizardmaster.com
Nite Eyes BBS (Synchronet)107.152.35.11
NiteLite BBSnitelite.ddns.net:9000
No Carrier BBSbbs.wehack.net
No Signal BBSnosignalbbs.com
Noise Forest BBStnf-bbs.net
Noisebridge BBSnoisebridgebbs.com:8888
Non-Existant BBS184.99.42.197
NORE BBSvetromac.dyndns-ip.com:2323
Northern BBSbbs.thediamonds.org:2323902-893-1022
Northern Palacethenorthernpalace.com:2020
NostalManianostalmania.com
Noverdu BBSnoverdu.com
NoWhere TWGSjoestavern.ddns.net:2002
Nuage BBS Computer Systembbs.nuageinfo.com
Nuclear Clubnuke.club:513
Nut Asylum (Mystic)xtcbox.org:2323
Nut Asylum (Wildcat)xtcbox.org
Oasis BBSoasisbbs.hopto.org:6400
OETELX BBSoetelx.nl
Off The Walloffthewall.dmxrob.net
Offgrid Holdout BBSbbs.offgridholdout.org:2524
Oiran Alien Museumlibido.cx
Old Highland Borgohb.synchronetbbs.org
Old Time’s Sake BBSotsbbs.ddns.net:2323
Oldest Future Objectofo.tw
Olympus BBSolympus.hermesbbs.com:2300
Omniverse BBSomniversebbs.com:3237
ON3PLZ BBSbbs.on3plz.net
Onix BBSonixbbs.servebbs.com:2525
Operation Ivy BBSopivy-bbs.com
Optical Illusion BBSoptical.c64bbs.nu:64128
OPTO 22 BBS47.181.149.218
Orchestra BBSsacrebase.mywire.org:486
Oshaboy BBStop-swadba.de:2323
Outer Limits, Theouterlimitsbbs.duckdns.org
Outpost 9 BBSbbs.outpost9.co:2023
Outpost BBSbbs.outpostbbs.net
Outwest BBSoutwest.synchronet.net
Over The Brink69.201.5.244
Overfitoverfit.retrievo.xyz:8023
OWCES47.166.101.67:2323
Palantir BBSpalantirbbs.ddns.net
PapiChulo’s MajorBBS75.31.92.35
Paradox BBS (1)paradoxbbs.synchronetbbs.org:513
Parasitewww.kimmoviitanen.fi:2323
Part-Time BBSptbbs.ddns.net:8000
Particles! BBSparticlesbbs.dyndns.org:6400479-553-8122
Party Bowl BBSpartybowlbbs.ddns.net:2323
Path Unknown BBSpathunknown.net
Pebkac.lolpebkac.lol
Penalty Box BBSthepenaltybox.org
PepsiCola23.118.36.39:2023
Pepzi BBSpepzi.eu
Pesto BBSbbs.pewp.us
Petit Caillou BBSbbs.jayscafe.net:6402
Phantasmphantasm.bbs.io:4489
Phantom BBSbbs.phantombbs.info:2323
Pharcyde BBSbbs.pharcyde.org
Phaseshift174.1.49.147:2323
Phatstar Teleporter198.71.48.13:7777
Phoenix BBS (1)phoenix.bnbbbs.net860-446-6118
Phoenix BBS (2)hello.phoenixbbs.uk:6502
Phoenix BBS (3)76.180.235.16
Phospher BBSbbs.phospher.com
PhreakNetbbs.phreaknet.org231-0980 PhreakNet (https://portal.phreaknet.org/directory)
PipeLine BBSbbs.wantit.net
Piranha BBSblackflag.acid.org:27
Pirate’s Cove TWGS38.188.130.43
Pixelgrounds BBS (Enigma 1/2)bbs.pixelgrounds.net:8888
Pixelgrounds BBS (Worldgroup)bbs.pixelgrounds.net:8887
Plasma Sphere BBSbbs.halium.com
Play LORDplaylord.org
PlayMajorMUD.complaymajormud.com
PlayMM_dev157.250.206.117:2323
PlayPen BBSplaypenbbs.com
Plop Shopplopshop.top:8888
PMF BBSbbs.venerandi.it
Poignant Beacon (Pharos BBS)bbs.pharos.rocks
Port of Call BBS (Image)pocbbs.duckdns.org:6400
Port of Call BBS (Renegade)pocbbs.duckdns.org
Port of Call BBS (Synchronet)pocbbs.duckdns.org:2323
Portfolio BBS (Atari Portfolio)pofobbs.ddns.net:992
Power BBSbbs.powerbbs.com
Private Heaven IIbbs.sydbolton.ca:6502
Pro-Kegsproline.ksherlock.com:6523
Project Luminiferous Aetherluminiferousaether.tel
Propaganda HQdenniskjaer.dk
Protectorate BBS, The73.252.135.162
Protoweb BBSwarpstream.org
PSCpsc.servebeer.com:6870
Psych Ward3.19.240.72
Psycho Wardbbs.8yo.biz:5150
Public Electronic Net Info Systempenisys.online:6502
Pweck’s Retreatbbs.pwecksretreat.com:2332
QL Dump001english-eu.no-ip.biz
Quantum Wormhole, Thebbs.erb.pw
Quazar BBS Door Game Serverquazarbbs.dynu.net:2523
Radio Freaks & Geeksradiostream.amigaz.org:2323
Ragnarok’s BBScrm.bertonmoreno.com.ar:23021
Ralser Lab BBS & BBSradioeuklid.ddns.net:5745
Ramificationsbbs.ramifications.ca:5128
RapidFirerapidfire.hopto.org:64128
Rats Den BBSbbs.catracing.org:6840
Raven of the Storm50.20.127.213
Raveolutionraveolution.hopto.org:64128
Rayzer’s BBSmail.hohimer.org:1336
RayzerNET BBSconnect.rayzer.net:2112
Razzpie BBSrazzpie.ddns.net:2300
RBB Systems Int’lrbb.fidonet.fi:32
RC-BOXrc2014.ddns.net:2014
React BBSreact-bbs.nikoh.it:2323
Realitycheck BBSrealitycheckbbs.org
Realm BBStherealm.synchro.net
Realm of Darknessbbs.trod.org
Realm of Serionconnect.serionbbs.com
Red Ghost BBS87.106.7.15
ReichBBSreich.familyds.net
Reign of Firecall.rofbbs.com:6800423-541-8271
Reign of Fire IIcall.rofbbs.com:6400
Reign of Fire IIIcall.rofbbs.com:8502
Retro Archivebbs.retroarchive.org
Retro BBSretro.nedmr.com:2323
Retro Nomiconbbs.retronomicon.de:6666
Retro Running BBSretrorunning.ddns.net:8880
Retro Tech Hausbbs.retrotech.haus
Retro Unboxersflashbackbbs.sytes.net:6502
Retro16 BBSmail.drf-solutions.net
Retro32 BBSbbs.retro32.com:1337
Retroaktiv BBSretr0aktiv.com
RetroBoard BBSbbs.retroboardbbs.com:2323
Retrocampus BBSbbs.retrocampus.com
Retroconnect.orgretroconnect.org
RetroDigital BBSrdnetbbs.com
Retrogaming Activitiesreact-bbs.nikoh.it:2323
Retrograde BBSrtg.dyndns.biz:6428
Retrograde II BBScib.dyndns.org:6404
RetroLair BBSretrolair.amigaretro.net:6800
RetroSwim BBSezycom.retroswim.net:2323
Reverse Polarityrevpol.lovelybits.org:1337
Revertive Pulserevertivepulse.net
RHDbbs.ilimits.uk
Ricks BBSricksbbs.synchro.net
RMSBBS187.61.237.55
Rock BBS IIItherockbbs.net:10023
Rolling BBSrollingbbs.ddns.net
Roon’s BBSbbs.roonsbbs.hu:1212
RougeNet BBSbbs.roguenet.work:8888
Rougue BBS (Chinese)35.201.128.35
Rusty Mailboxtrmb.ca:2030
S.W.A.T.S. BBSswatsbbs.ddns.net:2323
Sanctuary BBSsanctuary.zapto.org:1541
Sanctum II BBS (1)sanctumbbs.com
Sanctum II BBS (2)sanctumbbs.com:6502
Sandnes BBSstokmarknes.org:24
Sands of Timerayyeargin.com
Santronics R&D Beta Siteupdate.winserver.com:24
Santronics Softwareonline.winserver.com:24
Saturn 5bbs.saturn5bbs.com
SBB Systemsbbs.sbbsystems.com:8888
SBDSbbs.sbdsdev.com
ScanNet BBSscannetbbs.myddns.me:6400
Scene List (1)scenelist.org
Scene List (2)ftp.scenelist.org:4000
Scratched Realityreality.throwbackbbs.com:2323
SD2IEC Test BBScib.dyndns.org:6403
SDF-1 BBSbbs.sdf1.net:5023
Sea Breeze Gaming Network (TWGS)seabreeze.servegame.com:2002
Sea Breeze Gaming Network (Worldgroup)seabreeze.servegame.com
Sea of Fantasyseaoffantasy.synchronetbbs.org
Seacyb BBS34.74.128.48
Shadow BBSshadowbbs.com
Shadowland BBSshadowlandbbs.eu
ShadoWorks BBSbbs.shadoworks.net
Shadowscopeshadowscope.noip.us
ShadowThrone81.166.116.101:2323
Shenk’s Expressshenksxp.dyndns.org
Shift-Bits BBSbbs.shift-bits.com:2000
Shipwrecks & Shibbolethsshibboleths.org:800
Shurato’s Heavenly Sphereshsbbs.net
Sidir’s BBSwww.sirdir.ch:8888
Silent Node BBSsilentnode.ddns.net:6400
Silfen Path BBSbbs.silfenpath.com
SiliconUndergroundsiliconu.com
Silvermeresilvermerebbs.org
Sinclair Retro BBSretrobbs.sinclair.homepc.it
Sinner’s Heaven207.246.74.70
Sinusoid188.61.246.69:2323
Skara Brea80.7.90.17:31337
SKO BBS134.185.84.52:2323
Slackers BBSslackers.ovh:2323
Slasher BBS162.118.68.79
Slime City BBSbbs.retrohack.se
SlipStream BBSslipstreambbs.net
Slumberlandbbs.slumberland.org
Snobsoft BBSsnobsoft.de:6401
Soft Solutionsbbs.softsolutions.net.br:2023
Solarflow BBSsolarflow.dynu.net:2300
Sotano MSX BBS212.145.190.92
Sounds of Silence BBSsos-bbs.net
South Centralsouthcentral.se:1023
SouthEast Starsestar.synchro.net
Southern Amissouthernamis.ddns.net
Spaghetti Hutspaghettihut.amigaretro.net:6800
Spectrum Syntaxtactic.emindtek.com
Splatter Haussplatter.haus:666
Sprawl BBS202.61.251.17
Squared Circle BBS45.79.93.198
Star Collision BBSscbbs.nsupdate.info:61023
Star Flight BBSstateoftheark.ca:1990
Star Killer’s TWGSsk-twgs.com:2002
Star Mansion Returnsviewneye.net:2323
Starbase 11 BBSbbs.starbase11.de:2323+49 9144 9278428 (no answer May 2026)
Starbase 21bbs.starbase21.net
Starbase Discoverysb-discovery.com
Starship Junkyardbbs.starshipjunkyard.com
Steven’s Hive BBSstevensbbs.stevenshive.xyz
Storm BBStelnet.stormbbs.com
Stormgate BBSstormgate.synchronetbbs.org
Strange Planet BBSstrangeplanet.org:6800
Street Corner BBSstreetcorner.ddns.net:6400
Strip It To Ridestripittoride.club:9000
Subcarrier BBSsubcarrier.ignorelist.com:2323
Subhumansubhuman.ddns.net:1338
Sunset City178.105.20.174
Super Dimension Fortress (SDF-1)sdf.org
Surf Shop BBS (1)ssbbs.ddns.net:6510
Sursum Corda TWGSsursum-corda.com:2002
Sursum Corda! BBSsursum-corda.com256-895-4786
Swap BBSdose.0wnz.at
SWATS BBSswatsbbs.ddns.net:2323
Swedish User Group Of Amigasuga.se:42512
SWIBBSswibbs.swiowa.tech
Swifty BBSbbs.swiftycode.ca:2323
SwissIRC BBSbbs.swissirc.net
Swords Of Chaos Forever BBSbbs.soc4ever.com
Synaptic Recluse BBS75.164.252.57:8888
SynchroGeekhome.echristopherson.com
Synchronixnix.synchro.net
Synerchatsynerchat.com
Sysop Solaris Dot Com (Menu)sysopsolaris.ddns.net:2323
System One BBScib.dyndns.org:6491
Taco Prontotacopronto.bbs.io
TARDIS BBSbbs.cortex-media.info
Tartarus BBSbbs.martincanto.com
Tassie Bob BBSbbs.tassiebob.com:2323
Techrono BBStechrono.synchro.net
Techwarebbs.techware2k.com
TelBoxtelbox.net
Telehacktelehac
"""

# -------------------------
# Prompt detection patterns
# -------------------------
PROMPT_PATTERNS = [b"login", b"name", b"user", b"handle", b"account",
                   b"password", b"pass", b"pw", b"choice", b">", b":"]

# -------------------------
# Utilities
# -------------------------
def parse_host_line(line: str):
    line = line.strip()
    if not line:
        return None
    tokens = [t.strip() for t in line.replace(",", " ").split()]
    for tok in tokens:
        if ":" in tok:
            host, port = tok.split(":", 1)
            port_digits = ""
            for ch in port:
                if ch.isdigit():
                    port_digits += ch
                else:
                    break
            if port_digits:
                try:
                    return (host.strip(), int(port_digits), line)
                except Exception:
                    pass
    if tokens:
        candidate = tokens[-1]
        if "." in candidate or candidate.isdigit():
            return (candidate, 23, line)
    return (line, 23, "")

def load_favorites():
    try:
        if os.path.exists(FAV_FILE):
            with open(FAV_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            return [tuple(item) for item in data]
    except Exception:
        pass
    return []

def save_favorites(favs):
    try:
        with open(FAV_FILE, "w", encoding="utf-8") as f:
            json.dump([list(x) for x in favs], f, indent=2)
    except Exception:
        pass

def host_of(cand):
    return cand[0]

def port_of(cand):
    return cand[1]

def note_of(cand):
    return cand[2] if len(cand) > 2 else ""

def filter_candidates(candidates, term: str):
    t = term.lower()
    return [c for c in candidates if t in host_of(c).lower() or t in note_of(c).lower()]

# -------------------------
# Screen helpers
# -------------------------
def clear_screen():
    try:
        if IS_WINDOWS:
            os.system("cls")
        else:
            if "TERM" in os.environ:
                sys.stdout.write("\x1b[2J\x1b[H")
                sys.stdout.flush()
            else:
                os.system("clear")
    except Exception:
        pass

# -------------------------
# TTS helpers (opt-in)
# -------------------------
def _has_command(cmd: str) -> bool:
    return shutil.which(cmd) is not None

def _speak_with_say(text: str) -> bool:
    try:
        subprocess.Popen(["say", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False

def _speak_with_spd(text: str) -> bool:
    try:
        subprocess.Popen(["spd-say", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False

def _speak_with_espeak(text: str) -> bool:
    try:
        subprocess.Popen(["espeak", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False

def _speak_with_powershell(text: str) -> bool:
    try:
        cmd = [
            "powershell",
            "-NoProfile",
            "-Command",
            f"Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{text}');"
        ]
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, shell=False)
        return True
    except Exception:
        return False

def _speak_with_pyttsx3(text: str) -> bool:
    if not PYTTSX3_AVAILABLE:
        return False
    try:
        def _run():
            try:
                engine = pyttsx3.init()
                engine.say(text)
                engine.runAndWait()
                try:
                    engine.stop()
                except Exception:
                    pass
            except Exception:
                pass
        t = threading.Thread(target=_run, daemon=True)
        t.start()
        return True
    except Exception:
        return False

def speak_text(text: str) -> bool:
    if _speak_with_pyttsx3(text):
        return True
    if _has_command("say"):
        return _speak_with_say(text)
    if IS_WINDOWS:
        return _speak_with_powershell(text)
    if _has_command("spd-say"):
        return _speak_with_spd(text)
    if _has_command("espeak"):
        return _speak_with_espeak(text)
    return False

def speak_async(text: str):
    try:
        t = threading.Thread(target=speak_text, args=(text,), daemon=True)
        t.start()
    except Exception:
        pass

# -------------------------
# Network helpers
# -------------------------
def scan_candidate(addr, timeout=CONNECT_TIMEOUT):
    host = addr[0]
    port = addr[1]
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        s.close()
        return True, None
    except Exception as e:
        return False, str(e)

def scan_all(candidates, timeout=CONNECT_TIMEOUT, parallel=20):
    results = [None] * len(candidates)
    q = list(enumerate(candidates))
    lock = threading.Lock()
    def worker():
        while True:
            with lock:
                if not q:
                    return
                idx, cand = q.pop()
            ok, err = scan_candidate(cand, timeout=timeout)
            results[idx] = (host_of(cand), port_of(cand), ok, err)
    threads = []
    for _ in range(min(parallel, max(1, len(candidates)))):
        t = threading.Thread(target=worker, daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join()
    return results

# -------------------------
# Telnet negotiation helpers
# -------------------------
def respond_negotiation(sock: socket.socket, cmd: int, opt: int):
    try:
        if cmd == DO:
            sock.sendall(bytes([IAC, WONT, opt]))
        elif cmd == WILL:
            sock.sendall(bytes([IAC, DONT, opt]))
    except Exception:
        pass

def strip_and_negotiate(buffer: bytearray, sock: socket.socket):
    out = bytearray()
    i = 0
    L = len(buffer)
    while i < L:
        b = buffer[i]
        if b == IAC:
            if i + 1 >= L:
                break
            cmd = buffer[i+1]
            if cmd in (WILL, WONT, DO, DONT):
                if i + 2 >= L:
                    break
                opt = buffer[i+2]
                respond_negotiation(sock, cmd, opt)
                i += 3
                continue
            elif cmd == SB:
                j = i + 2
                found = False
                while j < L:
                    if buffer[j] == IAC and j + 1 < L and buffer[j+1] == SE:
                        j += 2
                        found = True
                        break
                    j += 1
                if not found:
                    break
                i = j
                continue
            else:
                if i + 1 >= L:
                    break
                i += 2
                continue
        else:
            out.append(b)
            i += 1
    del buffer[:i]
    return bytes(out)

# -------------------------
# Terminal raw mode helpers
# -------------------------
def set_raw_terminal():
    """Put terminal into raw mode (Unix). Returns original attrs to restore."""
    if IS_WINDOWS:
        return None
    if termios is None or tty is None:
        return None
    fd = sys.stdin.fileno()
    try:
        old = termios.tcgetattr(fd)
        tty.setraw(fd)
        return old
    except Exception:
        return None

def restore_terminal(old_attrs):
    if IS_WINDOWS:
        return
    if old_attrs is None:
        return
    try:
        fd = sys.stdin.fileno()
        termios.tcsetattr(fd, termios.TCSADRAIN, old_attrs)
    except Exception:
        pass

# -------------------------
# Auto-login monitor
# -------------------------
def auto_login_monitor(shared_display: bytearray, shared_lock: threading.Lock,
                       sock: socket.socket, stop_event: threading.Event,
                       username: str, password: str, encoding: str,
                       login_delay: float = 0.15):
    if not username:
        return
    seen_user = False
    seen_pass = False
    start = time.time()
    timeout_total = 30.0
    prompts_login = [b"login", b"name", b"user", b"handle", b"account"]
    prompts_pass = [b"password", b"pass", b"pw"]
    try:
        while not stop_event.is_set() and time.time() - start < timeout_total:
            with shared_lock:
                data = bytes(shared_display)
            lower = data.lower()
            tail = lower[-128:] if len(lower) > 128 else lower
            tail_stripped = tail.rstrip()
            tail_ends_prompt = tail_stripped.endswith(b":") or tail_stripped.endswith(b">")
            if (not seen_user):
                login_in_tail = any(p in tail for p in prompts_login)
                login_anywhere = any(p in lower for p in prompts_login)
                if login_in_tail or (login_anywhere and tail_ends_prompt):
                    try:
                        time.sleep(login_delay)
                        sock.sendall(username.encode(encoding, errors="replace") + b"\r\n")
                        seen_user = True
                    except Exception:
                        stop_event.set()
                        return
            if seen_user and (not seen_pass):
                if any(p in lower for p in prompts_pass):
                    try:
                        time.sleep(login_delay)
                        sock.sendall(password.encode(encoding, errors="replace") + b"\r\n")
                        seen_pass = True
                        return
                    except Exception:
                        stop_event.set()
                        return
            time.sleep(0.12)
    except Exception:
        return

# -------------------------
# Receiver + optional capture
# -------------------------
def receiver_loop(sock: socket.socket, stop_event: threading.Event,
                  shared_display: bytearray, shared_lock: threading.Lock,
                  encoding: str, capture_file: str | None, capture_lock: threading.Lock | None):
    sock.settimeout(RECV_TIMEOUT)
    recv_buffer = bytearray()
    try:
        while not stop_event.is_set():
            try:
                chunk = sock.recv(4096)
            except socket.timeout:
                continue
            except Exception:
                stop_event.set()
                break
            if not chunk:
                stop_event.set()
                break
            if capture_file and capture_lock is not None:
                try:
                    with capture_lock:
                        with open(capture_file, "ab") as cf:
                            cf.write(chunk)
                except Exception:
                    pass
            recv_buffer.extend(chunk)
            display = strip_and_negotiate(recv_buffer, sock)
            if display:
                with shared_lock:
                    shared_display.extend(display)
                    if len(shared_display) > 20000:
                        del shared_display[:len(shared_display)-20000]
                try:
                    sys.stdout.buffer.write(display)
                    sys.stdout.buffer.flush()
                except Exception:
                    try:
                        sys.stdout.write(display.decode(encoding, errors="replace"))
                        sys.stdout.flush()
                    except Exception:
                        pass
    finally:
        stop_event.set()

# -------------------------
# Stdin forwarder for interactive raw-mode sessions
# -------------------------
def stdin_forwarder_raw(sock: socket.socket, stop_event: threading.Event, encoding: str, debug: bool = False):
    try:
        if IS_WINDOWS:
            while not stop_event.is_set():
                if msvcrt.kbhit():
                    ch = msvcrt.getwch()
                    if ch in ("\x00", "\xe0"):
                        ch2 = msvcrt.getwch()
                        try:
                            sock.sendall((ch + ch2).encode(encoding, errors="replace"))
                        except Exception:
                            stop_event.set()
                            break
                    else:
                        if ch == "\r" or ch == "\n":
                            try:
                                sock.sendall(b"\r\n")
                            except Exception:
                                stop_event.set()
                                break
                        else:
                            try:
                                sock.sendall(ch.encode(encoding, errors="replace"))
                            except Exception:
                                stop_event.set()
                                break
                else:
                    time.sleep(0.01)
        else:
            fd = sys.stdin.fileno()
            while not stop_event.is_set():
                r, _, _ = select.select([fd], [], [], 0.1)
                if r:
                    try:
                        data = os.read(fd, 1024)
                    except Exception:
                        stop_event.set()
                        break
                    if not data:
                        stop_event.set()
                        break
                    if data == b"\n":
                        out = b"\r\n"
                    else:
                        out = data.replace(b"\n", b"\r\n")
                    try:
                        sock.sendall(out)
                    except Exception:
                        stop_event.set()
                        break
    except Exception:
        stop_event.set()

# -------------------------
# Interactive connect and interact
# -------------------------
def connect_and_interact_interactive(host, port, encoding="utf-8", username=None, password=None,
                                    debug=False, login_delay=0.15, capture_file: str | None = None,
                                    tts: bool = True, repeat: bool = False):
    if tts:
        try:
            speak_async(f"Connecting to {host}")
        except Exception:
            pass

    while True:
        print(f"\nConnecting to {host}:{port} ...")
        try:
            sock = socket.create_connection((host, port), timeout=10)
        except Exception as e:
            print("Connect failed:", e)
            if repeat:
                try:
                    ans = input("Connection failed. Retry? (Y/n/q): ").strip().lower()
                except EOFError:
                    return "ok"
                if ans == "n":
                    return "ok"
                if ans == "q":
                    return "quit"
                continue
            return "ok"

        stop_event = threading.Event()
        shared_display = bytearray()
        shared_lock = threading.Lock()
        capture_lock = threading.Lock() if capture_file else None

        old_attrs = set_raw_terminal()

        recv_t = threading.Thread(target=receiver_loop,
                                  args=(sock, stop_event, shared_display, shared_lock, encoding, capture_file, capture_lock),
                                  daemon=True)
        recv_t.start()

        if username:
            login_t = threading.Thread(target=auto_login_monitor,
                                       args=(shared_display, shared_lock, sock, stop_event, username, password or "", encoding, login_delay),
                                       daemon=True)
            login_t.start()

        stdin_t = threading.Thread(target=stdin_forwarder_raw,
                                   args=(sock, stop_event, encoding, debug),
                                   daemon=True)
        stdin_t.start()

        print("\n--- Connected. Keystrokes are sent immediately. Press Ctrl-C to end session. ---")
        try:
            while not stop_event.is_set():
                time.sleep(0.1)
        except KeyboardInterrupt:
            stop_event.set()
        finally:
            stop_event.set()
            time.sleep(0.05)
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                sock.close()
            except Exception:
                pass
            restore_terminal(old_attrs)
            try:
                sys.stdout.write("\n")
                sys.stdout.flush()
            except Exception:
                pass
            print("\nDisconnected.")

        if not repeat:
            return "ok"

        try:
            ans = input("Reconnect to this host? (Y/n/q): ").strip().lower()
        except EOFError:
            return "ok"
        if ans == "n":
            return "ok"
        if ans == "q":
            return "quit"

# -------------------------
# Listing helpers
# -------------------------
def show_menu(candidates, favorites):
    total = len(candidates)
    if total == 0:
        print("\nNo available BBS hosts.")
    else:
        print("\nAvailable BBS hosts:")
        for i, cand in enumerate(candidates, start=1):
            h = host_of(cand)
            p = port_of(cand)
            note = note_of(cand)
            if note:
                print(f"  {i}. {h}:{p}  —  {note}")
            else:
                print(f"  {i}. {h}:{p}")

    if favorites:
        print("\nSaved favorites:")
        for j, fav in enumerate(favorites, start=1):
            h, p, note = fav
            if note:
                print(f"  f{j}. {h}:{p}  —  {note}")
            else:
                print(f"  f{j}. {h}:{p}")

    print("\nCommands: [number] connect  R[number] repeat connect  f[number] favorite  a add  s[number] save  find <term>  search <term>  q quit")

def prompt_add_host():
    try:
        line = input("Enter host[:port] (or blank to cancel): ").strip()
    except EOFError:
        return None
    if not line:
        return None
    parsed = parse_host_line(line)
    if not parsed:
        print("Invalid format.")
        return None
    try:
        note = input("Optional short note: ").strip()
    except EOFError:
        note = ""
    return (parsed[0], parsed[1], note)

# -------------------------
# Menu loop — show the Available BBS hosts only once at startup
# -------------------------
def menu_loop(candidates, favorites, encoding, debug=False, login_delay=0.15, capture_opt=False, tts: bool = True):
    # Show the list once up front
    show_menu(candidates, favorites)

    while True:
        try:
            choice = input("\nChoice: ").strip()
        except EOFError:
            return
        if not choice:
            continue
        lc = choice.lower()
        if lc == "q":
            print("Quitting.")
            return

        if lc.startswith("find ") or lc.startswith("search "):
            parts = choice.split(None, 1)
            if len(parts) < 2 or not parts[1].strip():
                print("Usage: find <term>")
                continue
            term = parts[1].strip()
            matches = filter_candidates(candidates, term)
            if not matches:
                print(f"No matches for '{term}'.")
            else:
                print(f"Matches for '{term}':")
                for i, cand in enumerate(matches, 1):
                    print(f"  {i}. {host_of(cand)}:{port_of(cand)}  —  {note_of(cand)}")
            continue

        if lc == "a":
            new = prompt_add_host()
            if new:
                candidates.append((new[0], new[1], new[2]))
                print("Added:", new[0], new[1])
            continue

        if lc.startswith("s"):
            num = choice[1:]
            try:
                idx = int(num) - 1
                if 0 <= idx < len(candidates):
                    h, p, note = candidates[idx]
                    note_in = input("Note for favorite: ").strip()
                    favorites.append((h, p, note_in))
                    save_favorites(favorites)
                    print("Saved favorite:", h, p)
                else:
                    print("Invalid candidate number.")
            except Exception:
                print("Invalid command.")
            continue

        if lc.startswith("f"):
            num = choice[1:]
            try:
                idx = int(num) - 1
                if 0 <= idx < len(favorites):
                    h, p, note = favorites[idx]
                    do_login = input("Attempt auto-login to this favorite? (y/N): ").strip().lower() == "y"
                    username = None
                    password = None
                    if do_login:
                        username = input("Username: ").strip()
                        password = getpass.getpass("Password: ")
                    repeat_choice = input("Repeat connection on disconnect? (y/N): ").strip().lower() == "y"
                    capture_file = None
                    if capture_opt and input("Capture raw session to file? (y/N): ").strip().lower() == "y":
                        capture_file = input("Capture filename: ").strip() or None
                    result = connect_and_interact_interactive(h, p, encoding=encoding, username=username, password=password,
                                                              debug=debug, login_delay=login_delay, capture_file=capture_file,
                                                              tts=tts, repeat=repeat_choice)
                    if result == "quit":
                        print("Quitting.")
                        return
                else:
                    print("Invalid favorite number.")
            except Exception:
                print("Invalid command.")
            continue

        if lc.startswith("r"):
            num = choice[1:]
            try:
                idx = int(num) - 1
                if 0 <= idx < len(candidates):
                    h, p, _ = candidates[idx]
                    do_login = input("Attempt auto-login? (y/N): ").strip().lower() == "y"
                    username = None
                    password = None
                    if do_login:
                        username = input("Username: ").strip()
                        password = getpass.getpass("Password: ")
                    print(f"Starting repeat loop for {h}:{p}. Press Ctrl-C during a session to stop that session.")
                    capture_file = None
                    if capture_opt and input("Capture raw session to file? (y/N): ").strip().lower() == "y":
                        capture_file = input("Capture filename: ").strip() or None
                    result = connect_and_interact_interactive(h, p, encoding=encoding, username=username, password=password,
                                                              debug=debug, login_delay=login_delay, capture_file=capture_file,
                                                              tts=tts, repeat=True)
                    if result == "quit":
                        print("Quitting.")
                        return
                else:
                    print("Invalid candidate number.")
            except Exception:
                print("Invalid command.")
            continue

        # numeric selection
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(candidates):
                h, p, _ = candidates[idx]
                do_login = input("Attempt auto-login? (y/N): ").strip().lower() == "y"
                username = None
                password = None
                if do_login:
                    username = input("Username: ").strip()
                    password = getpass.getpass("Password: ")
                repeat_choice = input("Repeat connection on disconnect? (y/N): ").strip().lower() == "y"
                capture_file = None
                if capture_opt and input("Capture raw session to file? (y/N): ").strip().lower() == "y":
                    capture_file = input("Capture filename: ").strip() or None
                result = connect_and_interact_interactive(h, p, encoding=encoding, username=username, password=password,
                                                          debug=debug, login_delay=login_delay, capture_file=capture_file,
                                                          tts=tts, repeat=repeat_choice)
                if result == "quit":
                    print("Quitting.")
                    return
            else:
                print("Invalid selection.")
        except Exception:
            print("Unknown command.")

# -------------------------
# Main
# -------------------------
def main():
    parser = argparse.ArgumentParser(description="BBS chooser + interactive client.")
    parser.add_argument("--file", help="File with host:port lines (one per line).")
    parser.add_argument("--encoding", default="utf-8", help="Text encoding (try cp437).")
    parser.add_argument("--auto", action="store_true", help="Automatically connect to the first reachable candidate.")
    parser.add_argument("--index", type=int, help="Connect to candidate number N (1-based) after scanning.")
    parser.add_argument("--debug", action="store_true", help="Print debug info about bytes sent (hex).")
    parser.add_argument("--login-delay", type=float, default=0.15, help="Delay before sending login/password after prompt detection.")
    parser.add_argument("--capture", action="store_true", help="When connecting, offer to capture raw session to a file.")
    parser.add_argument("--tts", dest="tts", action="store_true", help="Enable TTS (default enabled).", default=True)
    parser.add_argument("--no-tts", dest="tts", action="store_false", help="Disable TTS (overrides default).")
    args = parser.parse_args()

    candidates = list(CURATED_BBS)
    favorites = load_favorites()

    # Parse and append EXTRA_BBS_RAW entries
    for ln in EXTRA_BBS_RAW.splitlines():
        parsed = parse_host_line(ln)
        if parsed:
            candidates.append(parsed)

    # If a file was provided, load additional hosts
    if args.file:
        try:
            with open(args.file, "r", encoding="utf-8") as hf:
                for ln in hf:
                    parsed = parse_host_line(ln)
                    if parsed:
                        candidates.append((parsed[0], parsed[1], parsed[2] if len(parsed) > 2 else ""))
        except Exception as e:
            print("Failed to read file:", e)

    # If auto or index flags are used, scan and act accordingly
    if args.auto or args.index:
        print("Scanning candidates (this may take a few seconds)...")
        scan_results = scan_all(candidates)
        reachable = [c for i, c in enumerate(candidates) if scan_results[i] and scan_results[i][2]]
        if not reachable:
            print("No reachable candidates found.")
        else:
            if args.auto:
                h, p, note = reachable[0]
                res = connect_and_interact_interactive(h, p, encoding=args.encoding, debug=args.debug, login_delay=args.login_delay, tts=args.tts)
                if res == "quit":
                    return
                return
            if args.index:
                idx = args.index - 1
                if 0 <= idx < len(candidates):
                    h, p, note = candidates[idx]
                    res = connect_and_interact_interactive(h, p, encoding=args.encoding, debug=args.debug, login_delay=args.login_delay, tts=args.tts)
                    if res == "quit":
                        return
                    return
                else:
                    print("Index out of range.")

    # Enter interactive menu
    try:
        menu_loop(candidates, favorites, encoding=args.encoding, debug=args.debug, login_delay=args.login_delay, capture_opt=args.capture, tts=args.tts)
    except KeyboardInterrupt:
        print("\nExiting.")

if __name__ == "__main__":
    main()
