#!/usr/bin/env python3
"""
Tapper — full-screen, high-resolution pixel-art sprites (Tkinter).
Customers now have a multi-frame walking cycle so their legs animate as they walk.
Everything else (lane walkways, bartender, mugs, sounds, restart) remains the same.
Save as tapper_animated_legs.py and run: python tapper_animated_legs.py
"""

import tkinter as tk
import random
import time
import threading
import os
import sys

# Optional sound backends
try:
    import pygame
    _HAS_PYGAME = True
except Exception:
    _HAS_PYGAME = False

try:
    import winsound
    _HAS_WINSOUND = True
except Exception:
    _HAS_WINSOUND = False

# --- Configuration (will adapt to full screen) ---
LANES = 4
LANE_MARGIN = 90
BARTENDER_X = 160
MUG_SPEED = 18
CUSTOMER_BASE_SPEED = 1.8
SPAWN_INTERVAL = 1200
LIVES = 3
FRAME_MS = 30
MAX_CUSTOMERS = 18
MAX_MUGS = 60
ANIM_MS = 140  # animation tick for sprite frames

# --- Colors / helpers ---
BG = "#d7f0fb"
BAR_COLOR = "#6b3f24"
BAR_TOP = "#8b5a2b"
BAR_HIGHLIGHT = "#b07a4a"
STOOL_COLOR = "#2f2f2f"
TEXT_COLOR = "#111111"
LANE_BAR_COLOR = "#e6f2ff"
LANE_BAR_EDGE = "#bcdcff"
LANE_BAR_HEIGHT = 72

def make_sprite_map(rows):
    return rows

# --- Sound manager (simple, same fallback behavior) ------------------------
class SoundManager:
    def __init__(self, root=None):
        self.root = root
        self.sounds = {}
        self.backend = None
        self.base_path = os.path.dirname(os.path.abspath(sys.argv[0]))
        if _HAS_PYGAME:
            try:
                pygame.mixer.init()
                self.backend = "pygame"
            except Exception:
                self.backend = None
        if self.backend is None and _HAS_WINSOUND:
            self.backend = "winsound"
        if self.backend is None:
            self.backend = "tkbell"
        for name in ("throw", "serve", "miss", "gameover", "restart"):
            path = os.path.join(self.base_path, f"{name}.wav")
            self.sounds[name] = path if os.path.isfile(path) else None

    def play(self, name):
        path = self.sounds.get(name)
        if self.backend == "pygame" and path:
            try:
                snd = pygame.mixer.Sound(path)
                snd.play()
                return
            except Exception:
                pass
        if self.backend == "winsound" and path:
            try:
                winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
                return
            except Exception:
                pass
        if self.backend == "winsound":
            try:
                tones = {
                    "throw": (1200, 80),
                    "serve": (1500, 100),
                    "miss": (600, 200),
                    "gameover": (400, 400),
                    "restart": (900, 120),
                }
                freq, dur = tones.get(name, (800, 80))
                winsound.Beep(freq, dur)
                return
            except Exception:
                pass
        if self.root:
            try:
                self.root.after(0, lambda: self.root.bell())
                return
            except Exception:
                pass
        threading.Thread(target=lambda: None, daemon=True).start()

# --- Animated PixelSprite (supports multiple frames) -----------------------
class PixelSprite:
    def __init__(self, canvas, frames, palette, scale=12, x=0, y=0):
        self.canvas = canvas
        self.frames = frames
        self.palette = palette
        self.scale = scale
        self.frame_index = 0
        self.map = frames[0]
        self.h = len(self.map)
        self.w = len(self.map[0]) if self.h else 0
        self.x = x
        self.y = y
        self.items = []
        self._create_items()

    def _create_items(self):
        half_w = (self.w * self.scale) // 2
        half_h = (self.h * self.scale) // 2
        left = self.x - half_w
        top = self.y - half_h
        self.items = []
        for ry, row in enumerate(self.map):
            for rx, ch in enumerate(row):
                if ch == ".":
                    self.items.append(None)
                    continue
                color = self.palette.get(ch, "#000000")
                x0 = left + rx * self.scale
                y0 = top + ry * self.scale
                x1 = x0 + self.scale
                y1 = y0 + self.scale
                rect = self.canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline=color)
                self.items.append(rect)

    def move_to(self, x, y):
        dx = x - self.x
        dy = y - self.y
        if dx == 0 and dy == 0:
            return
        for it in self.items:
            if it:
                self.canvas.move(it, dx, dy)
        self.x = x
        self.y = y

    def set_palette(self, palette):
        self.palette = palette
        self._apply_frame(self.frame_index)

    def _apply_frame(self, idx):
        frame = self.frames[idx]
        it_index = 0
        for ry, row in enumerate(frame):
            for rx, ch in enumerate(row):
                it = self.items[it_index]
                if it:
                    color = self.palette.get(ch, "#000000")
                    self.canvas.itemconfig(it, fill=color, outline=color)
                it_index += 1

    def set_frame(self, idx):
        if not self.frames:
            return
        idx = idx % len(self.frames)
        if idx == self.frame_index:
            return
        self.frame_index = idx
        self._apply_frame(self.frame_index)

    def destroy(self):
        for it in self.items:
            if it:
                try:
                    self.canvas.delete(it)
                except Exception:
                    pass
        self.items.clear()

# --- Side-profile bartender sprite (16x16) --------------------------------
BARTENDER_FRAMES = [
    make_sprite_map([
        "................",
        "......RRRRR.....",
        ".....RRRRRRR....",
        "....RRR.RRRR....",
        "....RRR.RRRR....",
        "....RRRRRRRRR...",
        "....RRR.RRRR....",
        ".....R..ffff....",
        ".....R.fMMMMf...",
        ".....R..ffff....",
        "....BB.BBBBB....",
        "...BB.BBYBB.....",
        "...BB.BBBBB.....",
        "....bb....bb....",
        "....bb....bb....",
        "................",
    ]),
    make_sprite_map([
        "................",
        "......RRRRR.....",
        ".....RRRRRRR....",
        "....RRR.RRRR....",
        "....RRR.RRRR....",
        "....RRRRRRRRR...",
        "....RRR.RRRR....",
        ".....R..ffff....",
        ".....R.fMMMMf...",
        ".....R..ffff....",
        "....BB.BBBBB....",
        "...BB.BBYBB.....",
        "...BB.BBBBB.....",
        ".....bb.bb......",
        "....bb....bb....",
        "................",
    ])
]

# --- Customer sprites flipped horizontally and with walking frames -------
# Each customer variant now has a 4-frame walking cycle:
# Frame 0: neutral/idle
# Frame 1: left leg forward
# Frame 2: neutral (slightly different)
# Frame 3: right leg forward
CUSTOMER_FRAMES_1 = [
    # Frame 0 - neutral
    make_sprite_map([
        "................",
        "......yy..yy....",
        ".....yffffffy...",
        "....y.fff.ffy..",
        "....y..fffff..y.",
        "....y..fffff..y.",
        ".....yyyyyyyyy..",
        ".....yrRrrrry..",
        ".....yrRrrrry..",
        "......rrr..rr...",
        ".......rr.rr....",
        ".......r..rr....",
        ".......r..rr....",
        "................",
        "................",
        "................",
    ]),
    # Frame 1 - left leg forward
    make_sprite_map([
        "................",
        "......yy..yy....",
        ".....yffffffy...",
        "....y.fff.ffy..",
        "....y..fffff..y.",
        "....y..fffff..y.",
        ".....yyyyyyyyy..",
        ".....yrRrrrry..",
        ".....yrRrrrry..",
        ".....rrr...rr...",
        "......rrr.rr....",
        "......r...rr....",
        "......r...rr....",
        "................",
        "................",
        "................",
    ]),
    # Frame 2 - neutral variant
    make_sprite_map([
        "................",
        "......yy..yy....",
        ".....yffffffy...",
        "....y.fff.ffy..",
        "....y..fffff..y.",
        "....y..fffff..y.",
        ".....yyyyyyyyy..",
        ".....yrRrrrry..",
        ".....yrRrrrry..",
        "......rrr..rr...",
        ".......rr.rr....",
        ".......r..rr....",
        ".......r..rr....",
        "................",
        "................",
        "................",
    ]),
    # Frame 3 - right leg forward
    make_sprite_map([
        "................",
        "......yy..yy....",
        ".....yffffffy...",
        "....y.fff.ffy..",
        "....y..fffff..y.",
        "....y..fffff..y.",
        ".....yyyyyyyyy..",
        ".....yrRrrrry..",
        ".....yrRrrrry..",
        ".......rrr..rr..",
        "......rr.rrr....",
        ".....rr...r....",
        ".....rr...r....",
        "................",
        "................",
        "................",
    ])
]

CUSTOMER_FRAMES_2 = [
    # Frame 0 - neutral
    make_sprite_map([
        "................",
        "......gg..gg....",
        ".....gffffffg...",
        "....g.fff.ffg..",
        "....g..fffff..g.",
        "....g..fffff..g.",
        ".....ggggggggg..",
        ".....grRrrrrg..",
        ".....grRrrrrg..",
        "......rrr..rr...",
        ".......rr.rr....",
        ".......r..rr....",
        ".......r..rr....",
        "................",
        "................",
        "................",
    ]),
    # Frame 1 - left leg forward
    make_sprite_map([
        "................",
        "......gg..gg....",
        ".....gffffffg...",
        "....g.fff.ffg..",
        "....g..fffff..g.",
        "....g..fffff..g.",
        ".....ggggggggg..",
        ".....grRrrrrg..",
        ".....grRrrrrg..",
        ".....rrr...rr...",
        "......rrr.rr....",
        "......r...rr....",
        "......r...rr....",
        "................",
        "................",
        "................",
    ]),
    # Frame 2 - neutral variant
    make_sprite_map([
        "................",
        "......gg..gg....",
        ".....gffffffg...",
        "....g.fff.ffg..",
        "....g..fffff..g.",
        "....g..fffff..g.",
        ".....ggggggggg..",
        ".....grRrrrrg..",
        ".....grRrrrrg..",
        "......rrr..rr...",
        ".......rr.rr....",
        ".......r..rr....",
        ".......r..rr....",
        "................",
        "................",
        "................",
    ]),
    # Frame 3 - right leg forward
    make_sprite_map([
        "................",
        "......gg..gg....",
        ".....gffffffg...",
        "....g.fff.ffg..",
        "....g..fffff..g.",
        "....g..fffff..g.",
        ".....ggggggggg..",
        ".....grRrrrrg..",
        ".....grRrrrrg..",
        ".......rrr..rr..",
        "......rr.rrr....",
        ".....rr...r....",
        ".....rr...r....",
        "................",
        "................",
        "................",
    ])
]

# --- Mug (10x10) -----------------------------------------------------------
MUG_FRAMES = [
    make_sprite_map([
        "............",
        "....wwww....",
        "...wwWWww...",
        "..wwWWWWww..",
        "..wwWWWWww..",
        "..wwWWWWww..",
        "...wwWWww...",
        "...wWwwWw...",
        "....ww..w....",
        "............",
    ])
]

# --- Palettes --------------------------------------------------------------
BARTENDER_PALETTE = {
    "R": "#d62828",
    "B": "#2b5fb3",
    "b": "#6b3f24",
    "f": "#f1c27d",
    "M": "#111111",
    "Y": "#ffd400",
    ".": None
}
CUSTOMER_PALETTE_1 = {
    "y": "#ffd24d",
    "R": "#5a2a2a",
    "f": "#f1c27d",
    "r": "#7a3a3a",
    ".": None
}
CUSTOMER_PALETTE_2 = {
    "g": "#d94b4b",
    "R": "#5a2a2a",
    "f": "#f1c27d",
    "r": "#7a3a3a",
    ".": None
}
CUSTOMER_SERVED_PALETTE = {
    "y": "#4fcf6f",
    "g": "#4fcf6f",
    "R": "#3f7a4a",
    "f": "#f1c27d",
    "r": "#7a3a3a",
    ".": None
}
MUG_PALETTE = {
    "w": "#4aa3ff",
    "W": "#ffffff",
    ".": None
}

# --- Game objects ---------------------------------------------------------
class Bartender:
    def __init__(self, game):
        self.game = game
        self.lane = LANES // 2
        self.sprite = PixelSprite(game.canvas, BARTENDER_FRAMES, BARTENDER_PALETTE, scale=14,
                                  x=BARTENDER_X, y=game.lane_y[self.lane])

    def move(self, d):
        self.lane = max(0, min(LANES - 1, self.lane + d))
        new_y = self.game.lane_y[self.lane]
        self.sprite.move_to(BARTENDER_X, new_y)

    def set_anim_frame(self, idx):
        self.sprite.set_frame(idx % len(self.sprite.frames))

    def throw_pose(self):
        try:
            self.sprite.set_frame(1)
            self.game.root.after(160, lambda: self.sprite.set_frame(0))
        except Exception:
            pass

    def destroy(self):
        self.sprite.destroy()

class Mug:
    def __init__(self, game, lane):
        self.game = game
        self.lane = lane
        self.x = BARTENDER_X + 110
        self.y = game.lane_y[lane]
        self.vx = MUG_SPEED
        self.sprite = PixelSprite(game.canvas, MUG_FRAMES, MUG_PALETTE, scale=10, x=self.x, y=self.y)
        self.active = True

    def update(self):
        self.x += self.vx
        if self.x > self.game.SCREEN_W + 80:
            self.active = False
            try:
                self.sprite.destroy()
            except Exception:
                pass
            try:
                if not self.game.game_over:
                    self.game.sounds.play("miss")
                    self.game.lives -= 1
                    try:
                        self.game.canvas.itemconfig(self.game.hud_text, text=self.game._hud_text())
                    except Exception:
                        pass
                    if self.game.lives <= 0:
                        self.game.sounds.play("gameover")
                        self.game.game_over = True
            except Exception:
                pass
            return
        self.sprite.move_to(self.x, self.y)

    def destroy(self):
        self.sprite.destroy()

class Customer:
    """
    Each customer has a walking animation (multi-frame) and a patience bar above them.
    The walking animation is driven by the game's global animation tick (ANIM_MS).
    """
    BAR_WIDTH = 84
    BAR_HEIGHT = 10
    BAR_OFFSET = 28

    def __init__(self, game, lane, speed, variant=1):
        self.game = game
        self.lane = lane
        self.x = game.SCREEN_W + 160
        self.initial_x = self.x
        self.y = game.lane_y[lane]
        self.speed = speed
        self.served = False
        self.variant = variant
        frames = CUSTOMER_FRAMES_1 if variant == 1 else CUSTOMER_FRAMES_2
        palette = CUSTOMER_PALETTE_1 if variant == 1 else CUSTOMER_PALETTE_2
        # Use multi-frame sprite for walking
        self.sprite = PixelSprite(game.canvas, frames, palette, scale=12, x=self.x, y=self.y)

        # create bar UI above the customer
        bx = self.x - Customer.BAR_WIDTH // 2
        by = self.y - (self.sprite.h * self.sprite.scale)//2 - Customer.BAR_OFFSET
        self.bar_bg = game.canvas.create_rectangle(bx, by, bx + Customer.BAR_WIDTH, by + Customer.BAR_HEIGHT,
                                                   fill="#333333", outline="#000000")
        self.bar_fill = game.canvas.create_rectangle(bx + 2, by + 2, bx + 2, by + Customer.BAR_HEIGHT - 2,
                                                     fill="#4fcf6f", outline="")

        # compute target x (where they stop at the bar)
        self.target_x = BARTENDER_X + 110
        self.total_distance = max(1, self.initial_x - self.target_x)

    def update(self):
        self.x -= self.speed
        if self.x < -240:
            try:
                self.game.canvas.delete(self.bar_bg)
            except Exception:
                pass
            try:
                self.game.canvas.delete(self.bar_fill)
            except Exception:
                pass
            self.sprite.destroy()
            return False

        # move sprite
        self.sprite.move_to(self.x, self.y)

        # update bar position and fill based on progress toward bartender
        bx_center = self.x
        bx = bx_center - Customer.BAR_WIDTH // 2
        by = self.y - (self.sprite.h * self.sprite.scale)//2 - Customer.BAR_OFFSET
        try:
            self.game.canvas.coords(self.bar_bg, bx, by, bx + Customer.BAR_WIDTH, by + Customer.BAR_HEIGHT)
        except Exception:
            pass

        progress = 1.0 - max(0.0, min(1.0, (self.x - self.target_x) / self.total_distance))
        fill_inner_width = max(2, int((Customer.BAR_WIDTH - 4) * progress))
        try:
            self.game.canvas.coords(self.bar_fill, bx + 2, by + 2, bx + 2 + fill_inner_width, by + Customer.BAR_HEIGHT - 2)
        except Exception:
            pass

        return True

    def mark_served(self):
        self.served = True
        try:
            self.game.canvas.delete(self.bar_bg)
        except Exception:
            pass
        try:
            self.game.canvas.delete(self.bar_fill)
        except Exception:
            pass
        self.sprite.destroy()

    def set_anim_frame(self, idx):
        # idx is the global animation state; map it to the sprite's frames
        # sprite.set_frame already wraps modulo, so pass idx directly
        self.sprite.set_frame(idx % len(self.sprite.frames))

    def destroy(self):
        try:
            self.game.canvas.delete(self.bar_bg)
        except Exception:
            pass
        try:
            self.game.canvas.delete(self.bar_fill)
        except Exception:
            pass
        self.sprite.destroy()

    def reached_bartender(self):
        return self.x - (self.sprite.w * self.sprite.scale)//2 <= BARTENDER_X + 110 and not self.served

# --- Bar drawing helper with lane walkways ---------------------------------
def draw_bar_background_and_lanes(canvas, screen_w, screen_h, lane_y):
    bar_top = screen_h - int(screen_h * 0.22)
    canvas.create_rectangle(0, bar_top, screen_w, screen_h, fill=BAR_COLOR, outline="")
    canvas.create_rectangle(0, bar_top, screen_w, bar_top + int(screen_h * 0.04), fill=BAR_TOP, outline="")

    for i, y in enumerate(lane_y):
        lane_h = LANE_BAR_HEIGHT
        lane_top = y - lane_h//2
        lane_bottom = y + lane_h//2
        walk_x0 = BARTENDER_X + 140
        walk_x1 = screen_w - 40
        canvas.create_rectangle(walk_x0, lane_top, walk_x1, lane_bottom, fill=LANE_BAR_COLOR, outline="")
        canvas.create_line(walk_x0, lane_top + 2, walk_x1, lane_top + 2, fill=LANE_BAR_EDGE, width=2)
        canvas.create_line(walk_x0, lane_bottom - 2, walk_x1, lane_bottom - 2, fill="#9fbfe8", width=2)

    stripe_step = max(48, screen_w // 30)
    for i in range(0, screen_w, stripe_step):
        canvas.create_line(i, bar_top + 6, i + stripe_step//2, bar_top + int(screen_h * 0.03), fill=BAR_HIGHLIGHT, width=3)
    tap_x = BARTENDER_X + 80
    for i in range(6):
        tx = tap_x + i * (screen_w // 20)
        canvas.create_rectangle(tx, bar_top - 28, tx + 18, bar_top + 8, fill="#c9c9c9", outline="#777")
        canvas.create_oval(tx - 10, bar_top - 44, tx + 28, bar_top - 12, fill="#222", outline="")
    stool_y = screen_h - 40
    stool_count = max(8, screen_w // 140)
    spacing = screen_w // (stool_count + 1)
    for i in range(stool_count):
        sx = spacing * (i + 1)
        canvas.create_oval(sx - 22, stool_y - 14, sx + 22, stool_y + 14, fill=STOOL_COLOR, outline="")
        canvas.create_line(sx, stool_y + 14, sx, stool_y + 48, fill="#333", width=4)
    sign_w = min(600, screen_w // 3)
    canvas.create_rectangle(20, bar_top - 120, 20 + sign_w, bar_top - 40, fill="#ffd27a", outline="#b07a4a", width=4)
    canvas.create_text(20 + sign_w//2, bar_top - 80, text="TAPPER BAR", font=("Helvetica", max(20, sign_w//12), "bold"))

# --- Game -----------------------------------------------------------------
class TapperGame:
    def __init__(self, root):
        self.root = root
        root.update_idletasks()
        try:
            root.attributes("-fullscreen", True)
        except Exception:
            try:
                root.state("zoomed")
            except Exception:
                pass

        self.SCREEN_W = root.winfo_screenwidth()
        self.SCREEN_H = root.winfo_screenheight()
        self.canvas = tk.Canvas(root, width=self.SCREEN_W, height=self.SCREEN_H, bg=BG)
        self.canvas.pack(fill="both", expand=True)

        self.lane_y = self.compute_lane_y()
        draw_bar_background_and_lanes(self.canvas, self.SCREEN_W, self.SCREEN_H, self.lane_y)

        self.bartender = Bartender(self)
        self.bartender.sprite.move_to(BARTENDER_X, self.lane_y[self.bartender.lane])

        self.mugs = []
        self.customers = []
        self.score = 0
        self.lives = LIVES
        self.level = 1
        self.spawn_interval = SPAWN_INTERVAL
        self.last_spawn_time = time.time() * 1000
        self.game_over = False

        self.sounds = SoundManager(root=self.root)

        self.hud_text = self.canvas.create_text(24, 18, anchor="nw",
                                                text=self._hud_text(),
                                                fill=TEXT_COLOR, font=("Helvetica", 20, "bold"))

        root.bind("<Up>", lambda e: self.move_bartender(-1))
        root.bind("<Down>", lambda e: self.move_bartender(1))
        root.bind("<w>", lambda e: self.move_bartender(-1))
        root.bind("<s>", lambda e: self.move_bartender(1))
        root.bind("<space>", lambda e: self.throw_mug())
        root.bind("r", lambda e: self.reset())
        root.bind("q", lambda e: self.quit())
        root.bind("<Escape>", lambda e: self.quit())

        self._running = True
        self._last_anim = time.time() * 1000
        self._anim_state = 0
        self.loop()

    def compute_lane_y(self):
        bar_top = self.SCREEN_H - int(self.SCREEN_H * 0.22)
        usable_top = 40
        usable_bottom = bar_top - 40
        spacing = (usable_bottom - usable_top) // (LANES - 1)
        return [usable_top + i * spacing for i in range(LANES)]

    def _hud_text(self):
        return f"Score: {self.score}    Lives: {self.lives}    Level: {self.level}"

    def move_bartender(self, d):
        if not self.game_over:
            self.bartender.move(d)

    def throw_mug(self):
        if not self.game_over and len(self.mugs) < MAX_MUGS:
            mug = Mug(self, self.bartender.lane)
            self.mugs.append(mug)
            self.sounds.play("throw")
            self.bartender.throw_pose()

    def spawn_customer(self):
        if len(self.customers) >= MAX_CUSTOMERS:
            return
        lane = random.randrange(0, LANES)
        speed = CUSTOMER_BASE_SPEED + 0.22 * (self.level - 1) + random.random() * 0.8
        variant = random.choice([1, 2])
        c = Customer(self, lane, speed, variant=variant)
        self.customers.append(c)

    def update(self):
        now = time.time() * 1000
        if not self.game_over and now - self.last_spawn_time > self.spawn_interval:
            self.spawn_customer()
            self.last_spawn_time = now
            if self.spawn_interval > 500:
                self.spawn_interval -= 20

        # animation toggle for walking frames
        if now - self._last_anim > ANIM_MS:
            # advance animation state (this will be used by both bartender and customers)
            self._anim_state = (self._anim_state + 1) % 4  # 4-frame walking cycle
            self._last_anim = now
            # update frames
            self.bartender.set_anim_frame(self._anim_state)
            for c in self.customers:
                c.set_anim_frame(self._anim_state)

        for mug in list(self.mugs):
            mug.update()
            if not mug.active:
                try:
                    self.mugs.remove(mug)
                except ValueError:
                    pass

        for c in list(self.customers):
            alive = c.update()
            if not alive:
                try:
                    self.customers.remove(c)
                except ValueError:
                    pass

        # collisions: when a mug hits a customer, the customer disappears immediately
        for mug in list(self.mugs):
            for c in list(self.customers):
                if mug.active and mug.lane == c.lane:
                    mug_half = (mug.sprite.w * mug.sprite.scale)//2
                    cust_half = (c.sprite.w * c.sprite.scale)//2
                    if mug.x + mug_half > c.x - cust_half and mug.x - mug_half < c.x + cust_half:
                        try:
                            c.destroy()
                        except Exception:
                            pass
                        try:
                            self.customers.remove(c)
                        except ValueError:
                            pass
                        try:
                            mug.destroy()
                        except Exception:
                            pass
                        try:
                            if mug in self.mugs:
                                self.mugs.remove(mug)
                        except ValueError:
                            pass
                        self.score += 150
                        self.sounds.play("serve")

        # customers reaching bartender
        for c in list(self.customers):
            if c.reached_bartender() and not c.served:
                c.destroy()
                try:
                    self.customers.remove(c)
                except ValueError:
                    pass
                self.lives -= 1
                self.sounds.play("miss")
                if self.lives <= 0:
                    self.sounds.play("gameover")
                    self.game_over = True

        if self.score >= self.level * 1500:
            self.level += 1
            for c in self.customers:
                c.speed *= 1.08

        self.canvas.itemconfig(self.hud_text, text=self._hud_text())

    def draw_game_over(self):
        box_w = min(600, self.SCREEN_W // 2)
        box_h = 220
        self.game_over_box = self.canvas.create_rectangle(self.SCREEN_W//2 - box_w//2, self.SCREEN_H//2 - box_h//2,
                                                          self.SCREEN_W//2 + box_w//2, self.SCREEN_H//2 + box_h//2,
                                                          fill="#ffffffee", outline="black")
        self.game_over_text = self.canvas.create_text(self.SCREEN_W//2, self.SCREEN_H//2 - 20,
                                                      text="GAME OVER", font=("Helvetica", 48, "bold"))
        self.restart_text = self.canvas.create_text(self.SCREEN_W//2, self.SCREEN_H//2 + 40,
                                                    text="Press R to restart or Esc to quit", font=("Helvetica", 20))

    def loop(self):
        if not self._running:
            return
        self.update()
        if self.game_over:
            if not hasattr(self, "game_over_box"):
                self.draw_game_over()
        else:
            if hasattr(self, "game_over_box"):
                try:
                    self.canvas.delete(self.game_over_box)
                    self.canvas.delete(self.game_over_text)
                    self.canvas.delete(self.restart_text)
                except Exception:
                    pass
                del self.game_over_box
                del self.game_over_text
                del self.restart_text
        self.root.after(FRAME_MS, self.loop)

    def reset(self):
        try:
            self._running = False
        except Exception:
            pass

        try:
            for mug in list(self.mugs):
                mug.destroy()
        except Exception:
            pass
        try:
            for c in list(self.customers):
                c.destroy()
        except Exception:
            pass
        try:
            self.bartender.destroy()
        except Exception:
            pass

        try:
            self.canvas.destroy()
        except Exception:
            pass

        try:
            if hasattr(self, "sounds") and self.sounds:
                self.sounds.play("restart")
        except Exception:
            pass

        try:
            self.root.update_idletasks()
        except Exception:
            pass

        try:
            self.__init__(self.root)
        except Exception:
            try:
                self.quit()
            except Exception:
                pass

    def quit(self):
        self._running = False
        try:
            self.root.attributes("-fullscreen", False)
        except Exception:
            pass
        self.root.quit()

def main():
    root = tk.Tk()
    root.title("Tapper — Animated Legs")
    root.configure(bg=BG)
    root.resizable(False, False)
    game = TapperGame(root)
    root.mainloop()

if __name__ == "__main__":
    main()
