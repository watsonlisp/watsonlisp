import random
import re
import subprocess

# =========================
# TEXT TO SPEECH
# =========================

def speak(text):
    escaped = text.replace("'", "''")

    command = f"""
    Add-Type -AssemblyName System.Speech;
    $voice = New-Object System.Speech.Synthesis.SpeechSynthesizer;
    $voice.Rate = -2;
    $voice.Volume = 100;
    $voice.Speak('{escaped}');
    """

    subprocess.run(
        ["powershell", "-Command", command],
        capture_output=True
    )


# =========================
# PIRATE PHRASES
# =========================

phrase_translations = {
    "how are you": "how be ye",
    "where are you": "where be ye",
    "what are you doing": "what be ye doin'",
    "good morning": "top o' the mornin', matey",
    "good afternoon": "fair winds this afternoon",
    "good evening": "pleasant evenin', matey",
    "see you later": "until our courses cross again",
    "nice to meet you": "well met, matey",
    "thank you": "much obliged, matey",
    "excuse me": "beg yer pardon",
    "i don't know": "I haven't the foggiest",
    "be quiet": "belay that chatter",
    "hurry up": "step lively",
    "let's go": "hoist the sails",
    "watch out": "avast",
    "get lost": "be gone, ye landlubber",
    "that's awesome": "that be legendary",
    "i am hungry": "me belly be rumblin'",
    "i am tired": "I be needin' me hammock",
    "i love it": "I treasure it like booty",
}

# =========================
# PIRATE WORDS
# =========================

translations = {

    "hello": "ahoy",
    "hi": "ahoy",
    "hey": "ahoy",

    "i": "me",
    "my": "me",
    "mine": "me own",

    "you": "ye",
    "your": "yer",
    "yours": "yers",

    "friend": "matey",
    "friends": "mateys",

    "is": "be",
    "are": "be",
    "am": "be",

    "the": "th'",
    "of": "o'",
    "for": "fer",
    "and": "an'",
    "with": "wit'",
    "to": "t'",

    "yes": "aye",
    "yeah": "aye",
    "yep": "aye",

    "no": "nay",
    "never": "ne'er",

    "money": "booty",
    "gold": "doubloons",
    "treasure": "booty",

    "captain": "cap'n",
    "pirate": "corsair",
    "crew": "hands",

    "work": "toil",
    "working": "toilin'",

    "computer": "thinkin' machine",
    "internet": "worldwide sea lanes",
    "website": "charted page",
    "email": "message in a bottle",
    "phone": "talkin' box",

    "house": "cabin",
    "home": "port",
    "room": "quarters",

    "car": "wagon",
    "boat": "ship",
    "ship": "vessel",

    "food": "grub",
    "water": "fresh water",
    "beer": "grog",
    "coffee": "brewmaster's grog",

    "dog": "sea dog",
    "cat": "ship's cat",

    "good": "fine",
    "great": "legendary",
    "awesome": "legendary",

    "angry": "fit t' mutiny",
    "happy": "jolly",
    "sad": "down in the bilge",

    "run": "scurry",
    "walk": "swagger",
    "look": "spy",
    "see": "spot",
    "eat": "devour",
    "drink": "swig",

    "school": "academy o' sailin'",
    "hospital": "healer's berth",
    "jail": "brig",

    "left": "port",
    "right": "starboard",

    "beach": "shore",
    "ocean": "briny deep",
    "sea": "briny deep",

    "today": "this day",
    "tomorrow": "on the morrow",
    "yesterday": "the day afore",

    "stop": "avast",

    "idiot": "scallywag",
    "fool": "landlubber",
    "coward": "lily-livered swab"
}

# =========================
# RANDOM ENDINGS
# =========================

pirate_endings = [
    "Arrr!",
    "Yo ho ho!",
    "Shiver me timbers!",
    "By Blackbeard's beard!",
    "Avast, matey!",
    "Savvy?",
    "Fair winds t' ye!",
    "Aye aye, cap'n!",
    "Hoist the colors!",
]

# =========================
# TRANSLATOR
# =========================

def pirate_translate(text):

    text = text.lower()

    for phrase, replacement in phrase_translations.items():
        text = text.replace(phrase, replacement)

    tokens = re.findall(r"\w+|[^\w\s]", text)

    result = []

    for token in tokens:

        if token.isalpha():
            result.append(
                translations.get(token, token)
            )
        else:
            result.append(token)

    output = ""

    for i, token in enumerate(result):

        if i > 0 and token not in ".,!?;:":
            output += " "

        output += token

    output = output.capitalize()

    output += " " + random.choice(pirate_endings)

    return output


# =========================
# MAIN PROGRAM
# =========================

def main():

    print("=" * 40)
    print("🏴‍☠️ ULTIMATE PIRATE TRANSLATOR 🏴‍☠️")
    print("Type 'quit' to leave.")
    print("=" * 40)

    speak("Ultimate Pirate Translator ready matey")

    while True:

        text = input("\nEnglish: ")

        if text.lower() == "quit":

            farewell = "Fair winds and followin seas matey"
            print(farewell)
            speak(farewell)

            break

        pirate_text = pirate_translate(text)

        print("\nPirate:")
        print(pirate_text)

        speak(pirate_text)


if __name__ == "__main__":
    main()
