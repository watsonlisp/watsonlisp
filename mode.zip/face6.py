#!/usr/bin/env python3
"""
capture_with_biometrics_tts_manage.py

Biometric capture + TTS + enrollment manager (rename/delete).
"""
import cv2
import threading
import time
from pathlib import Path
import tkinter as tk
from tkinter import ttk, simpledialog, messagebox
import json
import math
import subprocess
import sys
import shutil

# -------------------------
# Configuration
# -------------------------
OUT_DIR = Path("captured_photos")
OUT_DIR.mkdir(parents=True, exist_ok=True)

BIOMETRICS_FILE = OUT_DIR / "biometrics.json"
CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
MIN_FACE_SIZE = (80, 80)
SAVE_CROPPED_FACE = True
AUTO_SAVE_ON_DETECT = False
AUTO_SAVE_COOLDOWN = 1.5
AUTO_IDENTIFY_COOLDOWN = 1.0
WEBCAM_INDEX = 0
WINDOW_NAME = "Camera Preview"

# Embedding parameters
EMBED_SIZE = (128, 128)
IDENTITY_THRESHOLD = 0.55

# -------------------------
# Helpers
# -------------------------
def timestamped_filename(prefix: str, ext: str = ".jpg") -> Path:
    ts = time.strftime("%Y%m%d_%H%M%S")
    counter = int(time.time() * 1000) % 1000
    return OUT_DIR / f"{prefix}_{ts}_{counter:03d}{ext}"

def safe_imwrite(path: Path, img) -> bool:
    try:
        ok = cv2.imwrite(str(path), img)
        if not ok:
            print("cv2.imwrite failed for", path)
        return ok
    except Exception as e:
        print("Exception writing file", path, e)
        return False

def clamp_rect(x, y, w, h, max_w, max_h):
    x = max(0, int(x))
    y = max(0, int(y))
    w = max(1, int(w))
    h = max(1, int(h))
    if x + w > max_w:
        w = max_w - x
    if y + h > max_h:
        h = max_h - y
    return x, y, w, h

def compute_embedding(face_img):
    if face_img is None:
        return None
    try:
        resized = cv2.resize(face_img, EMBED_SIZE, interpolation=cv2.INTER_LINEAR)
    except Exception:
        return None
    gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
    arr = gray.flatten().astype(float)
    n = len(arr)
    mean = sum(arr) / n
    var = sum((v - mean) ** 2 for v in arr) / n
    std = math.sqrt(var) if var > 1e-8 else 1.0
    normed = [(v - mean) / std for v in arr]
    norm = math.sqrt(sum(v * v for v in normed))
    if norm < 1e-8:
        return [0.0] * len(normed)
    return [v / norm for v in normed]

def cosine_similarity(a, b):
    if a is None or b is None or len(a) != len(b):
        return -1.0
    return sum(x * y for x, y in zip(a, b))

# -------------------------
# Biometrics storage (thread-safe helpers)
# -------------------------
def load_biometrics():
    if not BIOMETRICS_FILE.exists():
        return []
    try:
        with BIOMETRICS_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
    except Exception as e:
        print("Failed to load biometrics file:", e)
    return []

def save_biometrics(entries):
    try:
        with BIOMETRICS_FILE.open("w", encoding="utf-8") as f:
            json.dump(entries, f, indent=2)
        return True
    except Exception as e:
        print("Failed to save biometrics file:", e)
        return False

def enroll_template(name, embedding):
    entries = load_biometrics()
    entries.append({"name": name, "vector": embedding})
    if save_biometrics(entries):
        print(f"Enrolled {name} ({len(embedding)}-dim vector)")
        return True
    return False

def find_best_match(embedding):
    entries = load_biometrics()
    best = None
    best_score = -1.0
    for e in entries:
        vec = e.get("vector")
        if not vec:
            continue
        score = cosine_similarity(embedding, vec)
        if score > best_score:
            best_score = score
            best = e
    return best, best_score

# -------------------------
# Text To Speech (no pip)
# -------------------------
def _speak_windows(text):
    safe_text = text.replace("'", "''")
    cmd = [
        "powershell",
        "-NoProfile",
        "-Command",
        f"Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe_text}')"
    ]
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception as e:
        print("Windows TTS failed:", e)
        return False

def _speak_macos(text):
    cmd = ["say", text]
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception as e:
        print("macOS say failed:", e)
        return False

def _speak_linux(text):
    if shutil.which("spd-say"):
        cmd = ["spd-say", text]
    elif shutil.which("espeak"):
        cmd = ["espeak", text]
    else:
        return False
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception as e:
        print("Linux TTS failed:", e)
        return False

def speak(text):
    if not text:
        return
    def _worker(t):
        ok = False
        if sys.platform.startswith("win"):
            ok = _speak_windows(t)
        elif sys.platform == "darwin":
            ok = _speak_macos(t)
        else:
            ok = _speak_linux(t)
        if not ok:
            print("TTS unavailable, would have spoken:", t)
    threading.Thread(target=_worker, args=(text,), daemon=True).start()

# -------------------------
# Shared state and lock
# -------------------------
state = {
    "running": True,
    "auto_save": AUTO_SAVE_ON_DETECT,
    "auto_identify": False,
    "last_frame": None,
    "last_faces": [],
    "last_saved_time": 0.0,
    "last_identified_time": 0.0
}
state_lock = threading.Lock()

# -------------------------
# Video thread
# -------------------------
def video_loop():
    face_cascade = cv2.CascadeClassifier(CASCADE_PATH)
    if face_cascade.empty():
        print("Haar cascade not found. Check OpenCV installation.")
        state["running"] = False
        return

    cap = cv2.VideoCapture(WEBCAM_INDEX)
    if not cap.isOpened():
        print("Cannot open camera. Check WEBCAM_INDEX and permissions.")
        state["running"] = False
        return

    cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL)

    try:
        while state["running"]:
            ret, frame = cap.read()
            if not ret or frame is None:
                print("Failed to read frame from camera.")
                break

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=MIN_FACE_SIZE
            )

            with state_lock:
                state["last_frame"] = frame.copy()
                state["last_faces"] = [tuple(map(int, f)) for f in faces]

            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cv2.putText(frame, "Face", (x, y - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

            cv2.imshow(WINDOW_NAME, frame)

            now = time.time()
            with state_lock:
                auto = state["auto_save"]
                auto_identify = state["auto_identify"]
                last_saved = state["last_saved_time"]
                last_identified = state["last_identified_time"]
                faces_copy = list(state["last_faces"])
                frame_copy = state["last_frame"]

            if auto and len(faces_copy) > 0 and (now - last_saved) > AUTO_SAVE_COOLDOWN:
                if SAVE_CROPPED_FACE:
                    for i, (x, y, w, h) in enumerate(faces_copy, start=1):
                        if frame_copy is None:
                            continue
                        h_img, w_img = frame_copy.shape[:2]
                        x2, y2, w2, h2 = clamp_rect(x, y, w, h, w_img, h_img)
                        face_img = frame_copy[y2:y2+h2, x2:x2+w2]
                        out_path = timestamped_filename(f"face{i}")
                        if safe_imwrite(out_path, face_img):
                            print("Auto-saved cropped face to", out_path)
                else:
                    if frame_copy is not None:
                        out_path = timestamped_filename("frame")
                        if safe_imwrite(out_path, frame_copy):
                            print("Auto-saved full frame to", out_path)
                with state_lock:
                    state["last_saved_time"] = time.time()

            if auto_identify and len(faces_copy) > 0 and (now - last_identified) > AUTO_IDENTIFY_COOLDOWN:
                (x, y, w, h) = faces_copy[0]
                if frame_copy is not None:
                    h_img, w_img = frame_copy.shape[:2]
                    x2, y2, w2, h2 = clamp_rect(x, y, w, h, w_img, h_img)
                    face_img = frame_copy[y2:y2+h2, x2:x2+w2]
                    emb = compute_embedding(face_img)
                    if emb is not None:
                        best, score = find_best_match(emb)
                        if best and score >= IDENTITY_THRESHOLD:
                            name = best['name']
                            print(f"Auto-identified as {name} (score={score:.3f})")
                            speak(f"{name}")
                        else:
                            print(f"Auto-identify: no match (best score={score:.3f})" if best else "Auto-identify: no templates")
                with state_lock:
                    state["last_identified_time"] = time.time()

            if cv2.waitKey(1) & 0xFF == ord("q"):
                with state_lock:
                    state["running"] = False
                break

    finally:
        cap.release()
        cv2.destroyAllWindows()
        with state_lock:
            state["running"] = False

# -------------------------
# Enrollment manager UI helpers
# -------------------------
def open_manage_enrollments():
    # modal window
    mgr = tk.Toplevel(root)
    mgr.title("Manage Enrollments")
    mgr.geometry("360x300")
    mgr.resizable(False, False)

    frm_m = ttk.Frame(mgr, padding=8)
    frm_m.pack(fill="both", expand=True)

    lbl = ttk.Label(frm_m, text="Enrolled templates:")
    lbl.pack(anchor="w")

    listbox = tk.Listbox(frm_m, height=10)
    listbox.pack(fill="both", expand=True, pady=(4,6))

    # load entries
    def refresh_list():
        listbox.delete(0, tk.END)
        entries = load_biometrics()
        for idx, e in enumerate(entries):
            name = e.get("name", "<unknown>")
            vec = e.get("vector")
            vec_len = len(vec) if isinstance(vec, list) else 0
            listbox.insert(tk.END, f"{idx+1:03d}  {name}  ({vec_len}d)")

    def get_selected_index():
        sel = listbox.curselection()
        if not sel:
            return None
        # listbox index -> entries index
        return sel[0]

    def rename_selected():
        idx = get_selected_index()
        if idx is None:
            messagebox.showinfo("Rename", "Select an entry first.")
            return
        entries = load_biometrics()
        if idx >= len(entries):
            messagebox.showerror("Rename", "Selection out of range.")
            refresh_list()
            return
        current = entries[idx].get("name", "")
        new = simpledialog.askstring("Rename", "Enter new name:", initialvalue=current, parent=mgr)
        if not new:
            return
        entries[idx]["name"] = new
        if save_biometrics(entries):
            refresh_list()
            messagebox.showinfo("Rename", "Name updated.")
        else:
            messagebox.showerror("Rename", "Failed to save changes.")

    def delete_selected():
        idx = get_selected_index()
        if idx is None:
            messagebox.showinfo("Delete", "Select an entry first.")
            return
        entries = load_biometrics()
        if idx >= len(entries):
            messagebox.showerror("Delete", "Selection out of range.")
            refresh_list()
            return
        name = entries[idx].get("name", "<unknown>")
        if not messagebox.askyesno("Delete", f"Delete enrollment '{name}'?"):
            return
        entries.pop(idx)
        if save_biometrics(entries):
            refresh_list()
            messagebox.showinfo("Delete", "Entry deleted.")
        else:
            messagebox.showerror("Delete", "Failed to save changes.")

    def view_selected():
        idx = get_selected_index()
        if idx is None:
            messagebox.showinfo("View", "Select an entry first.")
            return
        entries = load_biometrics()
        if idx >= len(entries):
            messagebox.showerror("View", "Selection out of range.")
            refresh_list()
            return
        e = entries[idx]
        name = e.get("name", "<unknown>")
        vec = e.get("vector")
        vec_len = len(vec) if isinstance(vec, list) else 0
        messagebox.showinfo("Template", f"Name: {name}\nVector length: {vec_len}")

    btn_frame = ttk.Frame(frm_m)
    btn_frame.pack(fill="x", pady=(6,0))

    btn_rename = ttk.Button(btn_frame, text="Rename", command=rename_selected)
    btn_rename.pack(side="left", padx=(0,6))

    btn_delete = ttk.Button(btn_frame, text="Delete", command=delete_selected)
    btn_delete.pack(side="left", padx=(0,6))

    btn_view = ttk.Button(btn_frame, text="View", command=view_selected)
    btn_view.pack(side="left", padx=(0,6))

    btn_close = ttk.Button(btn_frame, text="Close", command=mgr.destroy)
    btn_close.pack(side="right")

    refresh_list()
    mgr.transient(root)
    mgr.grab_set()
    root.wait_window(mgr)

# -------------------------
# Button callbacks (Tkinter)
# -------------------------
def capture_button_callback():
    with state_lock:
        frame = state.get("last_frame")
        faces = list(state.get("last_faces", []))

    if frame is None:
        print("No frame available to capture yet.")
        return

    if SAVE_CROPPED_FACE and len(faces) > 0:
        for i, (x, y, w, h) in enumerate(faces, start=1):
            h_img, w_img = frame.shape[:2]
            x2, y2, w2, h2 = clamp_rect(x, y, w, h, w_img, h_img)
            face_img = frame[y2:y2+h2, x2:x2+w2]
            out_path = timestamped_filename(f"face{i}")
            if safe_imwrite(out_path, face_img):
                print("Saved cropped face to", out_path)
    else:
        out_path = timestamped_filename("frame")
        if safe_imwrite(out_path, frame):
            print("Saved full frame to", out_path)

def enroll_button_callback():
    with state_lock:
        frame = state.get("last_frame")
        faces = list(state.get("last_faces", []))

    if frame is None or len(faces) == 0:
        messagebox.showinfo("Enroll", "No face detected to enroll. Position a face in view and try again.")
        return

    name = simpledialog.askstring("Enroll", "Enter name for enrollment:")
    if not name:
        print("Enrollment cancelled or empty name.")
        return

    x, y, w, h = faces[0]
    h_img, w_img = frame.shape[:2]
    x2, y2, w2, h2 = clamp_rect(x, y, w, h, w_img, h_img)
    face_img = frame[y2:y2+h2, x2:x2+w2]
    emb = compute_embedding(face_img)
    if emb is None:
        print("Failed to compute embedding for enrollment.")
        return
    if enroll_template(name, emb):
        messagebox.showinfo("Enroll", f"Enrolled {name}.")
    else:
        messagebox.showerror("Enroll", "Failed to save enrollment.")

def identify_button_callback():
    with state_lock:
        frame = state.get("last_frame")
        faces = list(state.get("last_faces", []))

    if frame is None or len(faces) == 0:
        print("No face available to identify.")
        return

    for i, (x, y, w, h) in enumerate(faces, start=1):
        h_img, w_img = frame.shape[:2]
        x2, y2, w2, h2 = clamp_rect(x, y, w, h, w_img, h_img)
        face_img = frame[y2:y2+h2, x2:x2+w2]
        emb = compute_embedding(face_img)
        if emb is None:
            print(f"Face {i}: failed to compute embedding.")
            continue
        best, score = find_best_match(emb)
        if best and score >= IDENTITY_THRESHOLD:
            name = best['name']
            print(f"Face {i}: identified as {name} (score={score:.3f})")
            speak(f"{name}")
        else:
            if best:
                print(f"Face {i}: no match (best {best['name']} score={score:.3f})")
            else:
                print(f"Face {i}: no templates enrolled")

def toggle_auto_callback():
    with state_lock:
        state["auto_save"] = not state["auto_save"]
        auto_state = state["auto_save"]
    btn_auto.config(text=f"Auto Save: {'On' if auto_state else 'Off'}")
    print("Auto-save set to", auto_state)

def toggle_auto_identify_callback():
    with state_lock:
        state["auto_identify"] = not state["auto_identify"]
        auto_id = state["auto_identify"]
    btn_auto_id.config(text=f"Auto Identify: {'On' if auto_id else 'Off'}")
    print("Auto-identify set to", auto_id)

def quit_callback():
    with state_lock:
        state["running"] = False
    root.quit()

# -------------------------
# Start video thread and Tkinter UI
# -------------------------
video_thread = threading.Thread(target=video_loop, daemon=True)
video_thread.start()

root = tk.Tk()
root.title("Capture Controls")
root.geometry("360x260")
root.resizable(False, False)

frm = ttk.Frame(root, padding=10)
frm.pack(fill="both", expand=True)

btn_capture = ttk.Button(frm, text="Capture", command=capture_button_callback)
btn_capture.pack(fill="x", pady=(0,6))

btn_enroll = ttk.Button(frm, text="Enroll", command=enroll_button_callback)
btn_enroll.pack(fill="x", pady=(0,6))

btn_identify = ttk.Button(frm, text="Identify", command=identify_button_callback)
btn_identify.pack(fill="x", pady=(0,6))

btn_manage = ttk.Button(frm, text="Manage Enrollments", command=open_manage_enrollments)
btn_manage.pack(fill="x", pady=(0,6))

btn_auto = ttk.Button(frm, text=f"Auto Save: {'On' if state['auto_save'] else 'Off'}", command=toggle_auto_callback)
btn_auto.pack(fill="x", pady=(0,6))

btn_auto_id = ttk.Button(frm, text=f"Auto Identify: {'On' if state['auto_identify'] else 'Off'}", command=toggle_auto_identify_callback)
btn_auto_id.pack(fill="x", pady=(0,6))

btn_quit = ttk.Button(frm, text="Quit", command=quit_callback)
btn_quit.pack(fill="x")

def on_close():
    with state_lock:
        state["running"] = False
    root.destroy()

root.protocol("WM_DELETE_WINDOW", on_close)
root.mainloop()

video_thread.join(timeout=2.0)
print("Exiting.")
