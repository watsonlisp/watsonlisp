import tkinter as tk
from tkinter import messagebox
import random

# --- Game logic functions ---

def create_board(n):
    return [[' ' for _ in range(n)] for _ in range(n)]

def in_bounds(n, r, c):
    return 0 <= r < n and 0 <= c < n

def count_new_sos(board, r, c, letter):
    n = len(board)
    orig = board[r][c]
    board[r][c] = letter
    count = 0
    dirs = [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]
    for dr, dc in dirs:
        if letter == 'O':
            r1, c1 = r - dr, c - dc
            r2, c2 = r + dr, c + dc
            if in_bounds(n, r1, c1) and in_bounds(n, r2, c2):
                if board[r1][c1] == 'S' and board[r2][c2] == 'S':
                    count += 1
        if letter == 'S':
            r1, c1 = r + dr, c + dc
            r2, c2 = r + 2*dr, c + 2*dc
            if in_bounds(n, r1, c1) and in_bounds(n, r2, c2):
                if board[r1][c1] == 'O' and board[r2][c2] == 'S':
                    count += 1
            r1, c1 = r - dr, c - dc
            r2, c2 = r - 2*dr, c - 2*dc
            if in_bounds(n, r1, c1) and in_bounds(n, r2, c2):
                if board[r1][c1] == 'O' and board[r2][c2] == 'S':
                    count += 1
    board[r][c] = orig
    return count

def get_empty_cells(board):
    n = len(board)
    empties = []
    for r in range(n):
        for c in range(n):
            if board[r][c] == ' ':
                empties.append((r,c))
    return empties

def computer_move(board):
    empties = get_empty_cells(board)
    best_moves = []
    best_score = -1

    # 1) immediate scoring moves
    for (r,c) in empties:
        for letter in ('S','O'):
            score = count_new_sos(board, r, c, letter)
            if score > best_score:
                best_score = score
                best_moves = [(r,c,letter)]
            elif score == best_score:
                best_moves.append((r,c,letter))
    if best_score > 0:
        return random.choice(best_moves), best_score

    # 2) block opponent immediate scoring move
    blocks = []
    for (r,c) in empties:
        for letter in ('S','O'):
            opp_score = count_new_sos(board, r, c, letter)
            if opp_score > 0:
                blocks.append((r,c,letter,opp_score))
    if blocks:
        blocks.sort(key=lambda x: -x[3])
        r,c,_,_ = blocks[0]
        for my_letter in ('S','O'):
            if count_new_sos(board, r, c, my_letter) == 0:
                return (r,c,my_letter), 0
        return (r,c,'S'), 0

    # 3) random move
    r,c = random.choice(empties)
    letter = random.choice(('S','O'))
    return (r,c,letter), 0

# --- GUI Application ---

class SOSApp:
    def __init__(self, root):
        self.root = root
        root.title("SOS vs Computer")
        self.size_var = tk.IntVar(value=5)
        self.letter_var = tk.StringVar(value='S')
        self.board = create_board(self.size_var.get())
        self.buttons = []
        self.scores = {'Human':0, 'Computer':0}
        self.turn = 'Human'  # Human starts
        self.build_ui()
        self.draw_board()

    def build_ui(self):
        top = tk.Frame(self.root)
        top.pack(padx=8, pady=6, anchor='w')

        tk.Label(top, text="Board size").grid(row=0, column=0, sticky='w')
        tk.Spinbox(top, from_=3, to=8, width=4, textvariable=self.size_var).grid(row=0, column=1, sticky='w', padx=4)
        tk.Button(top, text="New Game", command=self.new_game).grid(row=0, column=2, padx=6)

        tk.Label(top, text="Your letter").grid(row=0, column=3, padx=(12,0))
        tk.Radiobutton(top, text='S', variable=self.letter_var, value='S').grid(row=0, column=4)
        tk.Radiobutton(top, text='O', variable=self.letter_var, value='O').grid(row=0, column=5)

        score_frame = tk.Frame(self.root)
        score_frame.pack(padx=8, pady=(0,6), anchor='w')
        self.score_label = tk.Label(score_frame, text=self.score_text())
        self.score_label.pack()

        self.board_frame = tk.Frame(self.root)
        self.board_frame.pack(padx=8, pady=6)

    def score_text(self):
        return f"Score  You: {self.scores['Human']}   Computer: {self.scores['Computer']}   Turn: {self.turn}"

    def new_game(self):
        n = self.size_var.get()
        if n < 2:
            messagebox.showinfo("Invalid size", "Choose board size at least 2")
            return
        self.board = create_board(n)
        self.scores = {'Human':0, 'Computer':0}
        self.turn = 'Human'
        self.draw_board()
        self.update_score()

    def draw_board(self):
        for widget in self.board_frame.winfo_children():
            widget.destroy()
        self.buttons = []
        n = len(self.board)
        for r in range(n):
            row_buttons = []
            for c in range(n):
                b = tk.Button(self.board_frame, text=' ', width=4, height=2,
                              command=lambda rr=r, cc=c: self.on_cell_click(rr, cc))
                b.grid(row=r, column=c, padx=2, pady=2)
                row_buttons.append(b)
            self.buttons.append(row_buttons)
        self.refresh_buttons()

    def refresh_buttons(self):
        n = len(self.board)
        for r in range(n):
            for c in range(n):
                self.buttons[r][c]['text'] = self.board[r][c]

    def update_score(self):
        self.score_label['text'] = self.score_text()

    def on_cell_click(self, r, c):
        if self.turn != 'Human':
            return
        if self.board[r][c] != ' ':
            return
        letter = self.letter_var.get()
        gained = count_new_sos(self.board, r, c, letter)
        self.board[r][c] = letter
        if gained > 0:
            self.scores['Human'] += gained
        # In this variant, scoring does NOT grant an extra move.
        self.turn = 'Computer'
        self.refresh_buttons()
        self.update_score()
        if not get_empty_cells(self.board):
            self.end_game()
            return
        self.root.after(300, self.computer_turn)

    def computer_turn(self):
        if not get_empty_cells(self.board):
            self.end_game()
            return
        (r,c,letter), _ = computer_move(self.board)
        gained = count_new_sos(self.board, r, c, letter)
        self.board[r][c] = letter
        if gained > 0:
            self.scores['Computer'] += gained
        # Computer also gets only one move per turn now
        self.turn = 'Human'
        self.refresh_buttons()
        self.update_score()
        if not get_empty_cells(self.board):
            self.end_game()

    def end_game(self):
        self.refresh_buttons()
        self.update_score()
        h = self.scores['Human']
        c = self.scores['Computer']
        if h > c:
            msg = f"You win {h} to {c}!"
        elif h < c:
            msg = f"Computer wins {c} to {h}."
        else:
            msg = f"It's a tie {h} to {c}."
        messagebox.showinfo("Game Over", msg)

if __name__ == "__main__":
    root = tk.Tk()
    app = SOSApp(root)
    root.mainloop()
