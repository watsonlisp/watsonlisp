"""
Randomized screening prototype with total-question control and prorated PHQ-9/GAD-7 scoring.
- Specify total number of questions for the session.
- Questions are sampled randomly from PHQ-9, GAD-7, and supplementary pools.
- If only a subset of PHQ/GAD items are asked, raw scores are prorated to full scale (approximate).
- TTS enabled by default (uses system commands; no pip required).
- Non-diagnostic indicators and urgent triage remain in place.

This script is for educational/screening purposes only. It does NOT provide a diagnosis.
Always recommend a professional clinical evaluation for any concerning results.
"""

import sys
import random
import shutil
import subprocess
import platform

# ---------------------------
# Core questionnaires
# ---------------------------
PHQ9_QUESTIONS = [
    "Little interest or pleasure in doing things",
    "Feeling down, depressed, or hopeless",
    "Trouble falling or staying asleep, or sleeping too much",
    "Feeling tired or having little energy",
    "Poor appetite or overeating",
    "Feeling bad about yourself — or that you are a failure or have let yourself or your family down",
    "Trouble concentrating on things, such as reading the newspaper or watching television",
    "Moving or speaking so slowly that other people could have noticed; or the opposite — being so fidgety or restless that you have been moving a lot more than usual",
    "Thoughts that you would be better off dead or of hurting yourself in some way"
]

GAD7_QUESTIONS = [
    "Feeling nervous, anxious, or on edge",
    "Not being able to stop or control worrying",
    "Worrying too much about different things",
    "Trouble relaxing",
    "Being so restless that it's hard to sit still",
    "Becoming easily annoyed or irritable",
    "Feeling afraid as if something awful might happen"
]

# ---------------------------
# Supplementary pools (sample)
# ---------------------------
SUPPLEMENTARY_MOOD = [
    "Loss of interest in hobbies or activities you used to enjoy",
    "Feeling hopeless about the future",
    "Feeling worthless or excessively guilty about minor things",
    "Crying spells or tearfulness more than usual",
    "Feeling slowed down in movements or speech",
    "Feeling restless or unable to sit still",
    "Frequent mood swings or emotional instability",
    "Reduced motivation to start or finish tasks",
    "Difficulty experiencing pleasure even in good moments"
]

SUPPLEMENTARY_ANXIETY = [
    "Worrying about many different things at once",
    "Feeling overwhelmed by small decisions",
    "Replaying conversations or events in your head repeatedly",
    "Avoiding places or situations because of worry",
    "Excessive worry about health or bodily sensations",
    "Persistent intrusive thoughts you can’t dismiss",
    "Feeling on edge or jumpy in situations others find calm"
]

SUPPLEMENTARY_PANIC = [
    "Sudden intense episodes of fear or discomfort",
    "Heart racing, chest tightness, or shortness of breath during episodes",
    "Trembling, sweating, or dizziness during sudden anxiety spikes",
    "Fear of losing control or 'going crazy' during an episode",
    "Fear of having another panic attack in public"
]

SUPPLEMENTARY_SLEEP = [
    "Difficulty falling asleep most nights",
    "Waking frequently during the night and not being able to return to sleep",
    "Waking much earlier than intended and unable to fall back asleep",
    "Sleeping much more than usual and still feeling tired",
    "Nightmares or disturbing dreams that affect daytime mood",
    "Daytime sleepiness or falling asleep unintentionally"
]

SUPPLEMENTARY_SUBSTANCE = [
    "Using alcohol to relax or to sleep more than intended",
    "Using drugs or medications to cope with stress or mood",
    "Needing more of a substance to get the same effect",
    "Trying and failing to cut down on alcohol or drug use",
    "Using substances in risky situations (driving, operating machinery)"
]

SUPPLEMENTARY_TRAUMA = [
    "Recurrent intrusive memories or flashbacks of a distressing event",
    "Avoiding reminders of a traumatic event (places, people, activities)",
    "Feeling emotionally numb or detached from others",
    "Hypervigilance or exaggerated startle response",
    "Irritable or aggressive behavior since a stressful event"
]

SUPPLEMENTARY_PSYCHOSIS = [
    "Hearing voices or sounds others do not hear",
    "Seeing things that others do not see",
    "Strong beliefs that others are plotting against you (paranoia)",
    "Feeling that your thoughts are being controlled or broadcast",
    "Sudden, unexplained changes in beliefs or worldview"
]

SUPPLEMENTARY_MANIA = [
    "Periods of unusually elevated, expansive, or irritable mood",
    "Decreased need for sleep (feeling rested after much less sleep)",
    "Racing thoughts or rapid speech",
    "Marked increase in goal-directed activity or physical restlessness",
    "Engaging in risky behaviors more than usual (spending, sex, driving)",
    "Unusually grand ideas or inflated self-esteem"
]

SUPPLEMENTARY_COGNITION = [
    "Trouble remembering recent events or appointments",
    "Difficulty following conversations or reading for long periods",
    "Slower thinking or difficulty finding words",
    "Frequent absentmindedness that affects work or safety"
]

SUPPLEMENTARY_FUNCTION = [
    "Difficulty completing work or school tasks on time",
    "Avoiding social interactions you used to enjoy",
    "Trouble managing household responsibilities (bills, chores)",
    "Reduced performance at work or school noticed by others"
]

SUPPLEMENTARY_SOCIAL = [
    "Increased conflict with family or friends",
    "Withdrawing from social activities or support networks",
    "Feeling misunderstood or isolated most of the time",
    "Difficulty trusting others or forming new relationships"
]

SUPPLEMENTARY_SUICIDAL = [
    "Thoughts that life is not worth living",
    "Thinking about harming yourself or wanting to die",
    "Having a plan for how you would harm yourself",
    "Having access to means to harm yourself (medication, weapons)",
    "Previous suicide attempt(s) or self-harm behavior"
]

ALL_SUPPLEMENTARY = (
    SUPPLEMENTARY_MOOD + SUPPLEMENTARY_ANXIETY + SUPPLEMENTARY_PANIC +
    SUPPLEMENTARY_SLEEP + SUPPLEMENTARY_SUBSTANCE + SUPPLEMENTARY_TRAUMA +
    SUPPLEMENTARY_PSYCHOSIS + SUPPLEMENTARY_MANIA + SUPPLEMENTARY_COGNITION +
    SUPPLEMENTARY_FUNCTION + SUPPLEMENTARY_SOCIAL + SUPPLEMENTARY_SUICIDAL
)

CHOICES = {
    "0": "Not at all",
    "1": "Several days",
    "2": "More than half the days",
    "3": "Nearly every day"
}

# ---------------------------
# TTS utilities (no pip)
# ---------------------------
def _which(cmd):
    return shutil.which(cmd) is not None

def _speak_mac(text):
    try:
        subprocess.run(["say", text], check=False)
    except Exception:
        pass

def _speak_windows(text):
    safe = text.replace("'", "''")
    ps_cmd = f"(New-Object -ComObject SAPI.SpVoice).Speak('{safe}')"
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
    except Exception:
        pass

def _speak_linux(text):
    try:
        if _which("spd-say"):
            subprocess.run(["spd-say", text], check=False)
            return
        if _which("espeak"):
            subprocess.run(["espeak", text], check=False)
            return
        if _which("festival"):
            p = subprocess.Popen(["festival", "--tts"], stdin=subprocess.PIPE)
            p.communicate(input=text.encode("utf-8"))
            return
    except Exception:
        pass

def detect_tts_backend():
    system = platform.system().lower()
    if system == "darwin" and _which("say"):
        return "mac_say"
    if system == "windows" and _which("powershell"):
        return "windows_powershell"
    if _which("spd-say") or _which("espeak") or _which("festival"):
        return "linux_cmd"
    return None

TTS_BACKEND = detect_tts_backend()

def speak(text, tts_enabled=True):
    if not tts_enabled or not TTS_BACKEND:
        return
    try:
        if TTS_BACKEND == "mac_say":
            _speak_mac(text)
        elif TTS_BACKEND == "windows_powershell":
            _speak_windows(text)
        elif TTS_BACKEND == "linux_cmd":
            _speak_linux(text)
    except Exception:
        pass

# ---------------------------
# Helpers and scoring
# ---------------------------
def ask_question(prompt, tts_enabled=True):
    print("\n" + prompt)
    for k, v in CHOICES.items():
        print(f"  {k}. {v}")
    print("  q. Quit")
    speak(prompt, tts_enabled=tts_enabled)
    while True:
        ans = input("Enter 0-3 or q: ").strip().lower()
        if ans in CHOICES:
            return int(ans)
        if ans in ("q", "quit"):
            raise SystemExit("User requested quit.")
        if ans in ("tts on", "tts off", "tts toggle"):
            return ans
        print("Invalid input. Enter 0,1,2,3 or q. You can also type 'tts on' or 'tts off'.")

def score_and_interpret_phq9(score):
    if score <= 4:
        return "Minimal or none"
    if score <= 9:
        return "Mild"
    if score <= 14:
        return "Moderate"
    if score <= 19:
        return "Moderately severe"
    return "Severe"

def score_and_interpret_gad7(score):
    if score <= 4:
        return "Minimal or none"
    if score <= 9:
        return "Mild"
    if score <= 14:
        return "Moderate"
    return "Severe"

def get_int_input(prompt_text, min_val, max_val):
    while True:
        raw = input(prompt_text).strip().lower()
        if raw in ("q", "quit"):
            raise SystemExit("User requested quit.")
        try:
            val = int(raw)
            if min_val <= val <= max_val:
                return val
            print(f"Enter a number between {min_val} and {max_val}.")
        except ValueError:
            print("Invalid input. Enter a whole number or 'q' to quit.")

# ---------------------------
# Symptom-cluster indicators
# ---------------------------
CLUSTER_POOLS = {
    "mania": SUPPLEMENTARY_MANIA,
    "psychosis": SUPPLEMENTARY_PSYCHOSIS,
    "trauma": SUPPLEMENTARY_TRAUMA,
    "substance": SUPPLEMENTARY_SUBSTANCE,
    "sleep": SUPPLEMENTARY_SLEEP,
    "panic": SUPPLEMENTARY_PANIC,
    "anxiety": SUPPLEMENTARY_ANXIETY,
    "mood": SUPPLEMENTARY_MOOD,
    "cognition": SUPPLEMENTARY_COGNITION,
    "function": SUPPLEMENTARY_FUNCTION,
    "social": SUPPLEMENTARY_SOCIAL,
    "suicidal": SUPPLEMENTARY_SUICIDAL
}

def evaluate_clusters(sampled_responses):
    resp_map = {q: ans for (q, ans) in sampled_responses}
    indicators = []
    for cluster, pool in CLUSTER_POOLS.items():
        count = sum(1 for q in pool if q in resp_map and resp_map[q] > 0)
        if cluster == "psychosis" and count > 0:
            indicators.append(("psychosis", count, "Features that can be seen with psychotic disorders (e.g., hallucinations, paranoia)."))
        elif cluster == "suicidal" and count > 0:
            indicators.append(("suicidal", count, "Endorsement of suicidal thoughts or behaviors; immediate clinical contact recommended."))
        elif cluster == "mania" and count >= 2:
            indicators.append(("mania", count, "Features that can be seen with bipolar spectrum conditions (e.g., elevated mood, decreased need for sleep, risky behavior)."))
        elif cluster in ("trauma", "substance") and count >= 2:
            indicators.append((cluster, count, f"Symptoms commonly associated with {cluster}-related concerns."))
        elif cluster in ("mood", "anxiety") and count >= 3:
            indicators.append((cluster, count, f"Symptoms consistent with significant {cluster}-related distress."))
        elif cluster in ("sleep", "panic", "cognition", "function", "social") and count >= 2:
            indicators.append((cluster, count, f"Notable symptoms in the {cluster} domain that may warrant follow-up."))
    return indicators

# ---------------------------
# Main flow: randomized sampling across all pools
# ---------------------------
def run_screening(tts_enabled=True):
    backend_msg = f" (TTS backend: {TTS_BACKEND})" if TTS_BACKEND else " (no TTS backend detected)"
    intro = "Welcome. This is a screening tool with randomized sampling across PHQ-9, GAD-7, and supplementary items."
    print(intro + backend_msg)
    speak(intro, tts_enabled=tts_enabled)
    print("This tool does NOT provide a diagnosis. It reports screening scores and possible symptom-pattern indicators.")
    speak("This tool does not provide a diagnosis. It reports screening scores and possible indicators.", tts_enabled=tts_enabled)

    include_core = input("Include PHQ-9 and GAD-7 items in the sampling pool? (y/n) [default y]: ").strip().lower()
    include_core = (include_core != "n")

    core_count = len(PHQ9_QUESTIONS) + len(GAD7_QUESTIONS)  # 16
    max_total = core_count + len(ALL_SUPPLEMENTARY)
    total_requested = get_int_input(f"Enter total number of questions for this session (0-{max_total}): ", 0, max_total)

    # Build combined pool (tagged)
    combined_pool = []
    if include_core:
        combined_pool.extend(("PHQ", q) for q in PHQ9_QUESTIONS)
        combined_pool.extend(("GAD", q) for q in GAD7_QUESTIONS)
    combined_pool.extend(("SUP", q) for q in ALL_SUPPLEMENTARY)

    # If requested more than available, cap
    total_requested = min(total_requested, len(combined_pool))

    # Randomly sample total_requested items from combined pool
    sampled_pool = random.sample(combined_pool, total_requested)
    random.shuffle(sampled_pool)  # randomize order

    # Ask questions
    phq9_answers = []      # list of (text, ans)
    gad7_answers = []      # list of (text, ans)
    supplementary_responses = []  # list of (text, ans)

    print(f"\nStarting session with {len(sampled_pool)} randomized questions.")
    speak(f"Starting session with {len(sampled_pool)} randomized questions.", tts_enabled=tts_enabled)

    for idx, (qtype, qtext) in enumerate(sampled_pool, start=1):
        label = f"{idx}. {qtext}"
        while True:
            ans = ask_question(label, tts_enabled=tts_enabled)
            if isinstance(ans, str):
                if ans == "tts on":
                    tts_enabled = True
                    print("TTS enabled.")
                    continue
                if ans == "tts off":
                    tts_enabled = False
                    print("TTS disabled.")
                    continue
                if ans == "tts toggle":
                    tts_enabled = not tts_enabled
                    print(f"TTS {'enabled' if tts_enabled else 'disabled'}.")
                    continue
            if qtype == "PHQ":
                phq9_answers.append((qtext, ans))
            elif qtype == "GAD":
                gad7_answers.append((qtext, ans))
            else:
                supplementary_responses.append((qtext, ans))
            break

    # Scoring PHQ-9 (raw and prorated)
    phq_raw = sum(ans for (_, ans) in phq9_answers)
    phq_items_asked = len(phq9_answers)
    phq_prorated = None
    phq_interpretation = None
    if phq_items_asked > 0:
        phq_prorated = phq_raw * (27.0 / (3 * phq_items_asked))
        # Round for display
        phq_prorated_rounded = round(phq_prorated, 1)
        phq_interpretation = score_and_interpret_phq9(phq_prorated)
    else:
        phq_prorated_rounded = None

    # Scoring GAD-7 (raw and prorated)
    gad_raw = sum(ans for (_, ans) in gad7_answers)
    gad_items_asked = len(gad7_answers)
    gad_prorated = None
    gad_interpretation = None
    if gad_items_asked > 0:
        gad_prorated = gad_raw * (21.0 / (3 * gad_items_asked))
        gad_prorated_rounded = round(gad_prorated, 1)
        gad_interpretation = score_and_interpret_gad7(gad_prorated)
    else:
        gad_prorated_rounded = None

    # Immediate safety check: PHQ-9 item 9 or any suicidal supplementary item
    suicidal_flag = False
    phq_item9_text = PHQ9_QUESTIONS[8]
    if any(q == phq_item9_text and ans > 0 for (q, ans) in phq9_answers):
        suicidal_flag = True
    suicidal_texts = set(SUPPLEMENTARY_SUICIDAL)
    if any(q in suicidal_texts and ans > 0 for (q, ans) in supplementary_responses):
        suicidal_flag = True

    # Evaluate clusters among sampled supplementary items
    indicators = evaluate_clusters(supplementary_responses)

    # Results
    print("\n" + "="*60)
    print("Screening results (non-diagnostic):")
    # PHQ output
    if phq_items_asked > 0:
        print(f"PHQ-9 raw score (from {phq_items_asked} item{'s' if phq_items_asked!=1 else ''}): {phq_raw}")
        print(f"PHQ-9 prorated score (approx to 0-27): {phq_prorated_rounded}")
        print(f"PHQ-9 interpretation (applied to prorated score): {phq_interpretation}")
        if phq_items_asked < 9:
            print("**Note**: Fewer than 9 PHQ items were asked. Prorated score is approximate and not validated.")
    else:
        print("PHQ-9 items were not included in this session.")
    print()
    # GAD output
    if gad_items_asked > 0:
        print(f"GAD-7 raw score (from {gad_items_asked} item{'s' if gad_items_asked!=1 else ''}): {gad_raw}")
        print(f"GAD-7 prorated score (approx to 0-21): {gad_prorated_rounded}")
        print(f"GAD-7 interpretation (applied to prorated score): {gad_interpretation}")
        if gad_items_asked < 7:
            print("**Note**: Fewer than 7 GAD items were asked. Prorated score is approximate and not validated.")
    else:
        print("GAD-7 items were not included in this session.")
    print("="*60 + "\n")

    # Supplementary flags
    flagged = [(q, ans) for (q, ans) in supplementary_responses if ans > 0]
    if flagged:
        print("Supplementary items you endorsed (non-validated flags):")
        for q, ans in flagged:
            print(f" - [{ans}] {q}")
        speak(f"You endorsed {len(flagged)} supplementary items.", tts_enabled=tts_enabled)
    else:
        print("No supplementary items were endorsed.")
        speak("No supplementary items were endorsed.", tts_enabled=tts_enabled)

    # Indicators
    if indicators:
        print("\nPossible symptom-pattern indicators (non-diagnostic):")
        for key, count, text in indicators:
            print(f" - {text} (endorsed {count} item{'s' if count!=1 else ''} in this domain)")
        speak("The screening found some symptom patterns that may warrant clinical follow up.", tts_enabled=tts_enabled)
    else:
        print("\nNo prominent symptom-pattern indicators were identified from the sampled items.")
        speak("No prominent symptom patterns were identified from the sampled items.", tts_enabled=tts_enabled)

    # Guidance and safety
    print("\nImportant guidance:")
    print("- These prorated scores and indicators are NOT diagnoses. They are approximate flags.")
    print("- Only a qualified clinician can perform a full diagnostic assessment.")
    print("- If you are in immediate danger or have thoughts of harming yourself, contact emergency services or a crisis resource now.")
    print("- If you have concerning scores or indicators, consider scheduling an evaluation with a primary care clinician, psychiatrist, or licensed mental health professional.")
    speak("These indicators are not diagnoses. Seek professional evaluation for any concerns.", tts_enabled=tts_enabled)

    if suicidal_flag:
        urgent = ("You indicated thoughts of self-harm or suicidal ideation on this screening. "
                  "This tool cannot assess risk fully. Please contact local emergency services or a trusted clinician immediately.")
        print("\n***** URGENT SAFETY NOTICE *****")
        print(urgent)
        print("*******************************\n")
        speak(urgent, tts_enabled=tts_enabled)

    # Printable summary option
    if input("Would you like a short printable summary? (y/n): ").strip().lower().startswith("y"):
        print_summary(phq_raw, phq_items_asked, phq_prorated_rounded,
                      gad_raw, gad_items_asked, gad_prorated_rounded,
                      flagged, indicators)

def print_summary(phq_raw, phq_count, phq_prorated,
                  gad_raw, gad_count, gad_prorated,
                  flagged, indicators):
    print("\n--- Screening Summary ---")
    if phq_count > 0:
        print(f"PHQ raw ({phq_count} items): {phq_raw}  |  Prorated approx: {phq_prorated} (0-27)")
    else:
        print("PHQ not asked.")
    if gad_count > 0:
        print(f"GAD raw ({gad_count} items): {gad_raw}  |  Prorated approx: {gad_prorated} (0-21)")
    else:
        print("GAD not asked.")
    if flagged:
        print("\nSupplementary flags:")
        for q, ans in flagged:
            print(f" - [{ans}] {q}")
    else:
        print("\nNo supplementary flags.")
    if indicators:
        print("\nPossible symptom-pattern indicators (non-diagnostic):")
        for key, count, text in indicators:
            print(f" - {text} (endorsed {count} item{'s' if count!=1 else ''})")
    print("\nThis summary is for informational purposes only and is not a medical record.")
    print("-------------------------\n")

def main_loop():
    tts_enabled = True
    try:
        raw = input("Enable TTS? (y/n) [default y]: ").strip().lower()
        if raw == "n":
            tts_enabled = False
    except (EOFError, KeyboardInterrupt):
        print("\nExiting.")
        return

    while True:
        try:
            run_screening(tts_enabled=tts_enabled)
        except SystemExit as e:
            print(f"\nExiting: {e}")
            break
        except KeyboardInterrupt:
            print("\nScreening cancelled by keyboard interrupt.")
            break

        while True:
            choice = input("Type 'r' to repeat, 't' to toggle TTS, or 'q' to quit: ").strip().lower()
            if choice in ("r", "repeat"):
                print("\nRestarting screening...\n")
                break
            if choice in ("t", "toggle"):
                tts_enabled = not tts_enabled
                print(f"TTS {'enabled' if tts_enabled else 'disabled'}.")
                break
            if choice in ("q", "quit"):
                print("\nGoodbye.")
                return
            print("Invalid choice. Enter 'r', 't', or 'q'.")

if __name__ == "__main__":
    try:
        main_loop()
    except SystemExit:
        pass
