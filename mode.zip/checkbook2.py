import json
from datetime import datetime

transactions = []
balance = 0.0


def save_register():
    data = {
        "balance": balance,
        "transactions": transactions
    }

    with open("checkbook.json", "w") as f:
        json.dump(data, f, indent=4)

    print("Register saved to checkbook.json\n")


def load_register():
    global balance, transactions

    try:
        with open("checkbook.json", "r") as f:
            data = json.load(f)

        balance = data.get("balance", 0.0)
        transactions = data.get("transactions", [])

        print("Register loaded from checkbook.json\n")

    except FileNotFoundError:
        print("No saved register found.\n")

    except Exception as e:
        print(f"Error loading file: {e}\n")


def add_deposit():
    global balance

    description = input("Deposit description: ")
    amount = float(input("Amount: $"))

    balance += amount

    transactions.append({
        "date": datetime.now().strftime("%m/%d/%Y"),
        "type": "DEP",
        "description": description,
        "amount": amount,
        "balance": balance
    })

    print("Deposit recorded.\n")


def write_check():
    global balance

    check_number = input("Check number: ")
    payee = input("Payee: ")
    amount = float(input("Amount: $"))

    balance -= amount

    transactions.append({
        "date": datetime.now().strftime("%m/%d/%Y"),
        "type": f"CHK#{check_number}",
        "description": payee,
        "amount": -amount,
        "balance": balance
    })

    print("Check entered.\n")


def withdraw_cash():
    global balance

    description = input("Withdrawal description: ")
    amount = float(input("Amount: $"))

    balance -= amount

    transactions.append({
        "date": datetime.now().strftime("%m/%d/%Y"),
        "type": "WD",
        "description": description,
        "amount": -amount,
        "balance": balance
    })

    print("Withdrawal recorded.\n")


def show_register():
    print("\n" + "=" * 85)
    print("OLD SCHOOL CHECKBOOK REGISTER")
    print("=" * 85)

    print(
        f"{'Date':<12}"
        f"{'Type':<12}"
        f"{'Description':<30}"
        f"{'Amount':>14}"
        f"{'Balance':>14}"
    )

    print("-" * 85)

    for t in transactions:
        print(
            f"{t['date']:<12}"
            f"{t['type']:<12}"
            f"{t['description']:<30}"
            f"${t['amount']:>12.2f}"
            f"${t['balance']:>12.2f}"
        )

    print("-" * 85)
    print(f"{'Current Balance:':>70} ${balance:.2f}")
    print("=" * 85)
    print()


def main():
    global balance

    print("OLD SCHOOL CHECKBOOK")
    print("--------------------")

    while True:
        print("\nMenu")
        print("1. New Register")
        print("2. Load Register")
        print("3. Deposit")
        print("4. Write Check")
        print("5. Withdrawal")
        print("6. View Register")
        print("7. Save Register")
        print("8. Exit")

        choice = input("\nChoice: ")

        if choice == "1":
            transactions.clear()
            balance = float(input("Starting Balance: $"))

        elif choice == "2":
            load_register()

        elif choice == "3":
            add_deposit()

        elif choice == "4":
            write_check()

        elif choice == "5":
            withdraw_cash()

        elif choice == "6":
            show_register()

        elif choice == "7":
            save_register()

        elif choice == "8":
            save_register()
            print("Goodbye.")
            break

        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
