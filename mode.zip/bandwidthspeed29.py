#!/usr/bin/env python3
"""
bandwidth_tester_curated_mirrors.py

Merged and extended version:
- Keeps original curated BASE_LOCATIONS.
- Adds EXTRA_LOCATIONS and CSV loader for user-supplied mirrors.
- Merges lists at runtime and probes candidates to present only healthy locations.
- Adds health cache, blacklist with cooldown, HEAD prechecks with IPv4 fallback,
  short timeouts, retries, and parallel probing to avoid showing locations that do not connect.
- Preserves download/upload measurement logic, sanitized tracebacks, CSV logging to home directory.
- Adds cross-platform TTS (no pip) and a combined Mbps summary using the same measured times.
- Adds a Download ↔ Upload summary helper that compares download and upload using the same time frame.
"""

import sys
import os
import time
import math
import csv
import json
import datetime
import urllib.request
import urllib.parse
import urllib.error
import http.client
import ssl
import socket
import traceback
import contextlib
import warnings
import platform
import subprocess
import shutil
from typing import List, Tuple, Optional, Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed

# Suppress ResourceWarning about unclosed sockets/responses (targeted)
warnings.filterwarnings("ignore", category=ResourceWarning)

# -------------------------
# Base curated locations
# -------------------------
BASE_LOCATIONS: List[Tuple[str, Optional[str]]] = [
    ("US Leaseweb 100MB", "http://mirror.us.leaseweb.net/speedtest/100mb.bin"),
    ("US CacheFly 100MB", "http://cachefly.cachefly.net/100mb.test"),
    ("US SoftLayer (Dallas) 100MB", "http://speedtest.sjc01.softlayer.com/downloads/test100.zip"),
    ("US Proof OVH 100MB", "http://proof.ovh.net/files/100Mb.dat"),
    ("UK ThinkBroadband 10MB", "http://ipv4.download.thinkbroadband.com/10MB.zip"),
    ("Netherlands Leaseweb 100MB", "http://mirror.nl.leaseweb.net/speedtest/100mb.bin"),
    ("Netherlands Serverius 100MB", "http://speedtest.serverius.net/100MB.bin"),
    ("France OVH 100MB", "http://proof.ovh.net/files/100Mb.dat"),
    ("Sweden Tele2 10MB", "http://speedtest.tele2.net/10MB.zip"),
    ("Japan NTT 100MB", "http://speedtest.ntt.jp/100MB.bin"),
    ("Singapore SGIX 100MB", "http://speedtest.sgix.net/100MB.bin"),
    ("Australia Telstra 100MB", "http://speedtest.telstra.net/100MB.bin"),
    ("Brazil UOL 100MB", "http://speedtest.uol.com.br/100MB.bin"),
    ("Fastly CDN 100MB (global)", "https://speedtest.fastly.net/100MB.bin"),
    ("Custom URL (enter your own)", None),
]

# -------------------------
# Extra candidate locations
# -------------------------
EXTRA_LOCATIONS: List[Tuple[str, Optional[str]]] = [
    ("Ubuntu Archive US ISO sample", "http://releases.ubuntu.com/20.04/ubuntu-20.04.6-desktop-amd64.iso"),
    ("Ubuntu Archive UK mirror", "http://mirrors.kernel.org/ubuntu/ubuntu-20.04.6-desktop-amd64.iso"),
    ("Debian Mirror US ls-lR.gz", "http://ftp.us.debian.org/debian/ls-lR.gz"),
    ("Debian Mirror NL ls-lR.gz", "http://ftp.nl.debian.org/debian/ls-lR.gz"),
    ("CentOS Mirror US ISO", "http://mirror.centos.org/centos/7/isos/x86_64/CentOS-7-x86_64-DVD-2009.iso"),
    ("CentOS Mirror EU ISO", "http://mirror.rackspace.com/CentOS/7/isos/x86_64/CentOS-7-x86_64-DVD-2009.iso"),
    ("Kernel.org ChangeLog sample", "http://www.kernel.org/pub/linux/kernel/v5.x/ChangeLog-5.10.1"),
    ("Apache Mirror US tarball", "http://apache.mirrors.tds.net/httpd/httpd-2.4.54.tar.gz"),
    ("Apache Mirror EU tarball", "http://mirror.ox.ac.uk/sites/ftp.apache.org/httpd/httpd-2.4.54.tar.gz"),
    ("Cloudflare sample 100MB", "https://speed.cloudflare.com/100MB.bin"),
    ("Fastly CDN 100MB", "https://speedtest.fastly.net/100MB.bin"),
    ("Google Cloud Storage sample 100MB", "https://storage.googleapis.com/speedtest/100MB.bin"),
    ("Microsoft Azure sample 100MB", "https://azurespeedtest.blob.core.windows.net/test/100MB.bin"),
    ("Linode Singapore 100MB", "http://speedtest.sgp1.linode.com/100MB.bin"),
    ("Linode London 100MB", "http://speedtest.lon1.linode.com/100MB.bin"),
    ("OVH Canada 100MB", "http://proof.ovh.net/files/100Mb.dat"),
    ("NTT Japan 100MB", "http://speedtest.ntt.jp/100MB.bin"),
    ("Telstra Australia 100MB", "http://speedtest.telstra.net/100MB.bin"),
    ("SGIX Singapore 100MB", "http://speedtest.sgix.net/100MB.bin"),
    ("ThinkBroadband 10MB UK", "http://ipv4.download.thinkbroadband.com/10MB.zip"),
    ("CacheFly 100MB", "http://cachefly.cachefly.net/100mb.test"),
    ("UOL Brazil 100MB", "http://speedtest.uol.com.br/100MB.bin"),
    ("Hetzner DE 100MB", "http://speed.hetzner.de/100MB.bin"),
    ("DigitalOcean NYC 100MB", "http://speedtest-nyc1.digitalocean.com/100mb.test"),
    ("DigitalOcean AMS 100MB", "http://speedtest-ams1.digitalocean.com/100mb.test"),
    ("Rackspace UK 100MB", "http://mirror.rackspace.com/test/100MB.bin"),
    ("HEAnet IE 100MB", "http://ftp.heanet.ie/mirrors/centos/7/isos/x86_64/CentOS-7-x86_64-DVD-2009.iso"),
    ("OpenSUSE Mirror ISO", "http://download.opensuse.org/distribution/leap/15.3/iso/openSUSE-Leap-15.3-DVD-x86_64.iso"),
    ("FreeBSD Mirror ISO", "http://ftp.freebsd.org/pub/FreeBSD/releases/ISO-IMAGES/13.1/FreeBSD-13.1-RELEASE-amd64-disc1.iso"),
    ("AWS S3 Public sample", "https://s3.amazonaws.com/speedtest/100MB.bin"),
    ("CDNJS jquery (small file)", "https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"),
    ("Custom URL (enter your own)", None),
]

# -------------------------
# Settings and constants
# -------------------------
HOME_DIR = os.path.expanduser("~")
CSV_LOG = os.path.join(HOME_DIR, "bandwidth_log.csv")
MAX_UPLOAD_BYTES = 50_000_000  # safety cap (50 MB)

# Diagnostic settings
HEAD_TIMEOUT = 6
DOWNLOAD_TIMEOUT = 30
HEAD_RETRIES = 2
HEAD_RETRY_DELAY = 1.0  # seconds

# Health cache and blacklist
_HEALTH_CACHE: Dict[str, Dict[str, Any]] = {}  # host -> {"ok": bool, "ts": epoch}
HEALTH_TTL = 10 * 60  # seconds to keep a successful/failed result
BLACKLIST_FILE = os.path.join(HOME_DIR, ".bandwidth_blacklist.json")
BLACKLIST_COOLDOWN = 30 * 60  # seconds to hide repeatedly failing hosts
PROBE_MAX_WORKERS = 12  # parallel probes when building menu

# -------------------------
# Utility functions
# -------------------------
def _sanitize_traceback(tb_text: str) -> str:
    if not tb_text:
        return tb_text
    return tb_text.replace(HOME_DIR, "~")

def human_size(bytes_count):
    if not bytes_count:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = min(int(math.floor(math.log(max(bytes_count, 1), 1024))), len(units) - 1)
    p = math.pow(1024, i)
    return f"{bytes_count / p:.2f} {units[i]}"

def validate_http_url(url):
    try:
        p = urllib.parse.urlparse(url)
        return p.scheme in ("http", "https") and p.netloc != "" and p.hostname is not None
    except Exception:
        return False

def format_speed(bytes_count, seconds):
    if not seconds or seconds <= 0:
        return 0.0, 0.0, "0.00 Mbps (0.00 MB/s)"
    bits_per_sec = (bytes_count * 8) / seconds
    mbps = bits_per_sec / 1_000_000
    mb_per_s = bytes_count / (1_000_000 * seconds)
    human = f"{mbps:.2f} Mbps ({mb_per_s:.2f} MB/s)"
    return mbps, mb_per_s, human

def _resolve_ipv4(hostname):
    try:
        infos = socket.getaddrinfo(hostname, None, family=socket.AF_INET, type=socket.SOCK_STREAM)
        return len(infos) > 0
    except Exception:
        return False

def _load_blacklist():
    try:
        with open(BLACKLIST_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_blacklist(b):
    try:
        with open(BLACKLIST_FILE, "w", encoding="utf-8") as f:
            json.dump(b, f)
    except Exception:
        pass

# -------------------------
# Cross-platform TTS helpers (no pip)
# -------------------------
def speak_text(text: str):
    """Cross-platform TTS using system tools only (no pip)."""
    system = platform.system()
    try:
        if system == "Darwin":
            # macOS: built-in say
            subprocess.run(["say", text], check=False)
            return
        if system == "Windows":
            # Windows: use PowerShell and System.Speech.Synthesis
            # Pass text via stdin to avoid quoting issues
            ps = (
                "Add-Type -AssemblyName System.speech;"
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                "$s.Speak([Console]::In.ReadToEnd());"
            )
            subprocess.run(["powershell", "-NoProfile", "-Command", ps], input=text.encode("utf-8"), check=False)
            return
        # Assume Linux/other: try spd-say then espeak
        if shutil.which("spd-say"):
            subprocess.run(["spd-say", text], check=False)
            return
        if shutil.which("espeak"):
            subprocess.run(["espeak", text], check=False)
            return
    except Exception:
        pass
    # Fallback: print the text
    print("TTS fallback:", text)

def speak_rates(dl_mbps: float, dl_seconds: float, up_mbps: float, up_seconds: float):
    """
    Compose a short summary using the same measured times and speak it.
    Also prints the summary to stdout.
    """
    parts = []
    if dl_seconds and dl_seconds > 0:
        parts.append(f"Download {dl_mbps:.2f} Mbps measured over {dl_seconds:.2f} seconds")
    else:
        parts.append("Download not measured")
    if up_seconds and up_seconds > 0:
        parts.append(f"Upload {up_mbps:.2f} Mbps measured over {up_seconds:.2f} seconds")
    else:
        parts.append("Upload not measured")

    # Combined summary using the same time measurement
    total_seconds = 0.0
    if dl_seconds and dl_seconds > 0:
        total_seconds += dl_seconds
    if up_seconds and up_seconds > 0:
        total_seconds += up_seconds

    if total_seconds > 0:
        dl_bits = dl_mbps * 1_000_000 * (dl_seconds if dl_seconds else 0)
        up_bits = up_mbps * 1_000_000 * (up_seconds if up_seconds else 0)
        combined_mbps = (dl_bits + up_bits) / total_seconds / 1_000_000
        parts.append(f"Combined average {combined_mbps:.2f} Mbps over {total_seconds:.2f} seconds")
    else:
        combined_mbps = None
        parts.append("No combined measurement available")

    summary = ". ".join(parts) + "."
    print("\nMbps summary:")
    print(summary)
    speak_text(summary)
    return combined_mbps

# -------------------------
# Download ↔ Upload summary helper (same time frame)
# -------------------------
def summarize_dl_up(dl_bytes: int, dl_seconds: float, up_bytes: int, up_seconds: float):
    """
    Print and speak a concise summary comparing download and upload using the same time frame.
    Inputs are raw bytes and measured seconds (use 0 for missing values).
    Returns a dict of computed metrics.
    """
    # Guard and convert
    dl_seconds = float(dl_seconds or 0.0)
    up_seconds = float(up_seconds or 0.0)
    dl_bytes = int(dl_bytes or 0)
    up_bytes = int(up_bytes or 0)

    # Compute per-test Mbps using same formulas as format_speed
    def _mbps_from(bytes_count, seconds):
        if seconds <= 0:
            return 0.0
        bits_per_sec = (bytes_count * 8) / seconds
        return bits_per_sec / 1_000_000

    dl_mbps = _mbps_from(dl_bytes, dl_seconds)
    up_mbps = _mbps_from(up_bytes, up_seconds)

    # Ratio and percent share (avoid division by zero)
    ratio = None
    percent_dl = percent_up = None
    if up_mbps > 0:
        ratio = dl_mbps / up_mbps
    total_mbps = dl_mbps + up_mbps
    if total_mbps > 0:
        percent_dl = (dl_mbps / total_mbps) * 100.0
        percent_up = (up_mbps / total_mbps) * 100.0

    # Time-weighted combined Mbps using the same time frame (sum of measured seconds)
    total_seconds = dl_seconds + up_seconds
    combined_mbps = None
    if total_seconds > 0:
        dl_bits = dl_mbps * 1_000_000 * dl_seconds
        up_bits = up_mbps * 1_000_000 * up_seconds
        combined_mbps = (dl_bits + up_bits) / total_seconds / 1_000_000

    # Human-friendly lines (explicitly show Mbps)
    lines = []
    lines.append(f"Download: {dl_mbps:.2f} Mbps measured over {dl_seconds:.2f} s")
    lines.append(f"Upload:   {up_mbps:.2f} Mbps measured over {up_seconds:.2f} s")
    if ratio is not None:
        lines.append(f"Download / Upload ratio: {ratio:.2f}x")
    if percent_dl is not None:
        lines.append(f"Share: Download {percent_dl:.1f}% · Upload {percent_up:.1f}%")
    if combined_mbps is not None:
        lines.append(f"Combined time-weighted average: {combined_mbps:.2f} Mbps over {total_seconds:.2f} s")
    else:
        lines.append("No combined measurement available (no measured seconds).")

    summary = "\n".join(lines)
    print("\nDownload ↔ Upload summary (same time frame):")
    print(summary)

    # Speak the short summary sentence (explicit Mbps)
    speak_sentence = (
        f"Download {dl_mbps:.2f} megabits per second, upload {up_mbps:.2f} megabits per second."
    )
    if combined_mbps is not None:
        speak_sentence += f" Combined average {combined_mbps:.2f} megabits per second."
    try:
        speak_text(speak_sentence)
    except Exception:
        print("TTS unavailable; spoken summary skipped.")

    # Return structured numbers if caller wants to use them
    return {
        "download_mbps": dl_mbps,
        "upload_mbps": up_mbps,
        "ratio": ratio,
        "percent_download": percent_dl,
        "percent_upload": percent_up,
        "combined_mbps": combined_mbps,
        "total_seconds": total_seconds,
    }

# -------------------------
# HTTP HEAD check and health logic
# -------------------------
def head_check_url(url, timeout=HEAD_TIMEOUT, force_ipv4=False):
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname
    if force_ipv4:
        if not _resolve_ipv4(host):
            raise RuntimeError(f"No IPv4 address found for host {host}")
    req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "python-bandwidth-tester/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.getcode(), getattr(resp, "reason", "")

def ensure_url_working(url, prefer_ipv4=False):
    """
    HEAD-check with health cache, blacklist, and short retries.
    Updates health cache and blacklist on repeated failures.
    """
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname
    if not host:
        raise ValueError("URL must include a host")

    now = time.time()
    # Check blacklist
    bl = _load_blacklist()
    if host in bl and now - bl[host].get("last_failed", 0) < BLACKLIST_COOLDOWN:
        raise RuntimeError(f"Host {host} is temporarily blacklisted due to recent failures")

    # Check health cache
    cached = _HEALTH_CACHE.get(host)
    if cached and now - cached["ts"] < HEALTH_TTL:
        if cached["ok"]:
            return url
        else:
            raise RuntimeError(f"Cached failure for host {host}")

    last_exc = None
    attempts = []
    if prefer_ipv4:
        attempts.append({"force_ipv4": True})
        attempts.append({"force_ipv4": False})
    else:
        attempts.append({"force_ipv4": False})
        attempts.append({"force_ipv4": True})

    for attempt in attempts:
        for i in range(HEAD_RETRIES):
            try:
                code, reason = head_check_url(url, timeout=HEAD_TIMEOUT, force_ipv4=attempt["force_ipv4"])
                ok = 200 <= code < 400
                _HEALTH_CACHE[host] = {"ok": ok, "ts": now}
                if ok:
                    # reset blacklist fail_count on success
                    if host in bl:
                        bl.pop(host, None)
                        _save_blacklist(bl)
                    return url
                raise RuntimeError(f"HEAD returned status {code} {reason}")
            except urllib.error.HTTPError as e:
                # treat HTTP errors as definitive failures for HEAD
                last_exc = e
                _HEALTH_CACHE[host] = {"ok": False, "ts": now}
                break
            except Exception as e:
                last_exc = e
                time.sleep(HEAD_RETRY_DELAY)
                continue

    # mark blacklist entry
    _HEALTH_CACHE[host] = {"ok": False, "ts": now}
    bl.setdefault(host, {"last_failed": now, "fail_count": 0})
    bl[host]["last_failed"] = now
    bl[host]["fail_count"] = bl[host].get("fail_count", 0) + 1
    _save_blacklist(bl)
    raise RuntimeError("URL HEAD check failed after retries") from last_exc

# -------------------------
# Download / Upload measurement
# -------------------------
def measure_download(url, max_bytes=None, chunk_size=64 * 1024, timeout=DOWNLOAD_TIMEOUT, prefer_ipv4=False):
    try:
        ensure_url_working(url, prefer_ipv4=prefer_ipv4)
        working = url
    except Exception:
        working = url

    if not validate_http_url(working):
        raise ValueError("Download URL must be a valid http or https URL.")

    req = urllib.request.Request(working, headers={"User-Agent": "python-bandwidth-tester/1.0"})
    start = time.time()
    first_byte_time = None
    total = 0
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            while True:
                chunk = resp.read(chunk_size)
                now = time.time()
                if chunk and first_byte_time is None:
                    first_byte_time = (now - start) * 1000.0
                if not chunk:
                    break
                total += len(chunk)
                if max_bytes and total >= max_bytes:
                    break
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP error {e.code} {e.reason} when downloading {working}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Network error when downloading {working}: {getattr(e, 'reason', e)}") from e
    except socket.timeout as e:
        raise RuntimeError(f"Download timed out after {timeout} seconds") from e
    except Exception as e:
        raise RuntimeError("Download failed: unexpected error") from e
    elapsed = time.time() - start
    return total, elapsed, first_byte_time

def measure_upload(url, total_bytes=10_000_000, chunk_size=64 * 1024, timeout=30):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("Upload URL must be a valid http or https URL.")
    if total_bytes > MAX_UPLOAD_BYTES:
        raise ValueError("Upload size exceeds safety cap.")

    host = parsed.hostname
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query
    use_https = parsed.scheme == "https"

    chunk = b"x" * chunk_size
    bytes_remaining = total_bytes
    conn = None
    start = None
    first_byte_time = None

    try:
        if use_https:
            context = ssl.create_default_context()
            conn = http.client.HTTPSConnection(host, port, timeout=timeout, context=context)
        else:
            conn = http.client.HTTPConnection(host, port, timeout=timeout)

        headers = {
            "User-Agent": "python-bandwidth-tester/1.0",
            "Content-Type": "application/octet-stream",
            "Content-Length": str(total_bytes),
            "Connection": "close",
            "Host": host,
        }

        start = time.time()
        with contextlib.closing(conn):
            conn.connect()
            conn.putrequest("POST", path, skip_host=True, skip_accept_encoding=True)
            for k, v in headers.items():
                conn.putheader(k, v)
            conn.endheaders()

            sent = 0
            while bytes_remaining > 0:
                to_send = chunk if bytes_remaining >= len(chunk) else b"x" * bytes_remaining
                try:
                    conn.send(to_send)
                except (BrokenPipeError, ConnectionResetError) as e:
                    raise RuntimeError("Connection closed by server while sending") from e
                sent += len(to_send)
                bytes_remaining -= len(to_send)
                if first_byte_time is None:
                    first_byte_time = (time.time() - start) * 1000.0

            try:
                resp = conn.getresponse()
            except Exception as e:
                raise RuntimeError("Failed to get response from server after upload") from e

            with contextlib.closing(resp):
                _ = resp.read(64)
                elapsed = time.time() - start
                return sent, elapsed, first_byte_time

    except http.client.RemoteDisconnected as e:
        raise RuntimeError("Server disconnected unexpectedly during upload") from e
    except socket.timeout as e:
        raise RuntimeError("Upload timed out") from e
    except Exception as e:
        raise RuntimeError("Upload failed: unexpected error") from e

# -------------------------
# CSV logging
# -------------------------
def save_csv(record, filename=CSV_LOG):
    header = [
        "timestamp",
        "test_type",
        "location_name",
        "url",
        "download_mbps",
        "upload_mbps",
        "download_bytes",
        "upload_bytes",
        "download_seconds",
        "upload_seconds",
        "ping_ms",
    ]
    write_header = False
    try:
        with open(filename, "r", newline="") as f:
            pass
    except FileNotFoundError:
        write_header = True
    with open(filename, "a", newline="") as f:
        writer = csv.writer(f)
        if write_header:
            writer.writerow(header)
        writer.writerow(
            [
                record.get("timestamp", ""),
                record.get("test_type", ""),
                record.get("location_name", ""),
                record.get("url", ""),
                record.get("download_mbps", ""),
                record.get("upload_mbps", ""),
                record.get("download_bytes", ""),
                record.get("upload_bytes", ""),
                record.get("download_seconds", ""),
                record.get("upload_seconds", ""),
                record.get("ping_ms", ""),
            ]
        )
    print(f"Saved to {filename}")

def _print_sanitized_traceback():
    tb = traceback.format_exc()
    print(_sanitize_traceback(tb))

# -------------------------
# Loading and merging locations
# -------------------------
def load_extra_locations_from_csv(path: str) -> List[Tuple[str, Optional[str]]]:
    extras: List[Tuple[str, Optional[str]]] = []
    try:
        with open(path, newline="", encoding="utf-8") as f:
            reader = csv.reader(f)
            for row in reader:
                if not row:
                    continue
                name = row[0].strip()
                url = row[1].strip() if len(row) > 1 else None
                if url == "":
                    url = None
                extras.append((name, url))
    except FileNotFoundError:
        pass
    return extras

def ALL_LOCATIONS(csv_path: Optional[str] = None) -> List[Tuple[str, Optional[str]]]:
    merged: List[Tuple[str, Optional[str]]] = []
    merged.extend(BASE_LOCATIONS)
    seen_urls = {u for _, u in merged if u}
    for name, url in EXTRA_LOCATIONS:
        if url and url in seen_urls:
            continue
        merged.append((name, url))
        if url:
            seen_urls.add(url)
    if csv_path:
        csv_extras = load_extra_locations_from_csv(csv_path)
        for name, url in csv_extras:
            if url and url in seen_urls:
                continue
            merged.append((name, url))
            if url:
                seen_urls.add(url)
    return merged

# Initialize DEFAULT_LOCATIONS from merged sources (includes ~/extra_mirrors.csv if present)
DEFAULT_LOCATIONS: List[Tuple[str, Optional[str]]] = ALL_LOCATIONS(csv_path=os.path.expanduser("~/extra_mirrors.csv"))

# -------------------------
# Probing helpers to present only healthy locations
# -------------------------
def _probe_one(name: str, url: Optional[str], prefer_ipv4: bool) -> Tuple[str, Optional[str], bool]:
    if not url:
        # custom entry always allowed
        return name, url, True
    try:
        ensure_url_working(url, prefer_ipv4=prefer_ipv4)
        return name, url, True
    except Exception:
        return name, url, False

def probe_locations(locations: List[Tuple[str, Optional[str]]], prefer_ipv4: bool = False, max_workers: int = PROBE_MAX_WORKERS) -> List[Tuple[str, Optional[str]]]:
    healthy: List[Tuple[str, Optional[str]]] = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(_probe_one, name, url, prefer_ipv4): (name, url) for name, url in locations}
        for fut in as_completed(futures):
            try:
                name, url, ok = fut.result()
            except Exception:
                name, url, ok = futures[fut][0], futures[fut][1], False
            if ok:
                healthy.append((name, url))
    # Ensure custom entry remains at end if present
    custom_entries = [e for e in healthy if e[1] is None]
    non_custom = [e for e in healthy if e[1] is not None]
    return non_custom + custom_entries

# -------------------------
# Location selection helpers
# -------------------------
def find_next_working_location(start_index: int, prefer_ipv4: bool = False) -> Optional[Tuple[int, str, str]]:
    n = len(DEFAULT_LOCATIONS)
    if n == 0:
        return None
    for offset in range(1, n):
        idx = (start_index + offset) % n
        name, url = DEFAULT_LOCATIONS[idx]
        if not url or not validate_http_url(url):
            continue
        try:
            ensure_url_working(url, prefer_ipv4=prefer_ipv4)
            return idx, name, url
        except Exception:
            continue
    return None

# -------------------------
# Interactive CLI
# -------------------------
def interactive():
    print("Bandwidth tester (curated mirrors).")
    # Ask once whether to prefer IPv4 for probing and HEAD checks
    pref_ipv4_choice = input("Prefer IPv4 for HEAD checks and probing? (y/N): ").strip().lower()
    pref_ipv4_global = pref_ipv4_choice == "y"

    while True:
        # Probe and present only healthy locations (fast parallel checks)
        print("\nProbing mirrors to build healthy list (this may take a few seconds)...")
        LOCATIONS = probe_locations(DEFAULT_LOCATIONS, prefer_ipv4=pref_ipv4_global, max_workers=PROBE_MAX_WORKERS)
        if not LOCATIONS:
            print("No healthy mirrors found from the curated list. You can enter a custom URL.")
            LOCATIONS = [("Custom URL (enter your own)", None)]

        print("\nLocations:")
        for i, (name, url) in enumerate(LOCATIONS, start=1):
            print(f"  {i}) {name} {'- ' + url if url else ''}")
        print("  0) Exit")
        choice = input("Choose a location number: ").strip()
        if choice == "0":
            print("Goodbye.")
            return
        if not choice.isdigit() or not (1 <= int(choice) <= len(LOCATIONS)):
            print("Invalid choice.")
            continue
        idx = int(choice) - 1
        name, url = LOCATIONS[idx]

        # If the chosen entry is the "Custom URL" (url is None), prompt the user.
        if url is None:
            url = input("Enter full HTTP/HTTPS download URL: ").strip()
            if not url:
                print("No URL entered.")
                continue
            if not validate_http_url(url):
                print("Invalid URL. Must start with http:// or https:// and include a host.")
                continue
        else:
            # Quick HEAD check for the chosen location; if it fails, automatically try next working location.
            try:
                ensure_url_working(url, prefer_ipv4=pref_ipv4_global)
            except Exception as e:
                print(f"\nSelected location '{name}' did not register: {e}")
                nxt = find_next_working_location(idx, prefer_ipv4=pref_ipv4_global)
                if nxt:
                    new_idx, new_name, new_url = nxt
                    print(f"Automatically switching to next working location: {new_name} - {new_url}")
                    idx = new_idx
                    name, url = new_name, new_url
                else:
                    print("No other working locations found. You can try a custom URL or pick another location.")
                    use_custom = input("Enter a custom URL now? (y/N): ").strip().lower() == "y"
                    if use_custom:
                        url = input("Enter full HTTP/HTTPS download URL: ").strip()
                        if not url or not validate_http_url(url):
                            print("Invalid or empty URL; returning to location menu.")
                            continue
                    else:
                        continue

        print(f"\nSelected: {name}\nURL: {url}")
        print("\nWhich test to run?")
        print("  1) Download only")
        print("  2) Upload only")
        print("  3) Download then upload")
        print("  4) Back to locations")
        t = input("Choice: ").strip()
        if t == "4":
            continue
        if t not in ("1", "2", "3"):
            print("Invalid test choice.")
            continue

        # Ask per-test IPv4 preference if user wants to override
        pref_ipv4 = pref_ipv4_global
        if input("Override IPv4 preference for this test? (y/N): ").strip().lower() == "y":
            pref_ipv4 = input("Prefer IPv4 for HEAD checks? (y/N): ").strip().lower() == "y"

        max_dl_mb = input("Max download to read in MB (enter for full file): ").strip()
        max_dl_bytes = None
        if max_dl_mb:
            try:
                max_dl_bytes = int(float(max_dl_mb) * 1_000_000)
            except Exception:
                print("Invalid number, using full file.")
                max_dl_bytes = None

        upload_url = input("Upload endpoint URL (enter for https://httpbin.org/post): ").strip()
        if not upload_url:
            upload_url = "https://httpbin.org/post"
        if not validate_http_url(upload_url):
            print("Invalid upload URL; using https://httpbin.org/post")
            upload_url = "https://httpbin.org/post"

        upload_size_mb = input("Upload size in MB (default 10, max 50): ").strip()
        try:
            upload_size = int(float(upload_size_mb) * 1_000_000) if upload_size_mb else 10_000_000
        except Exception:
            print("Invalid size, using 10 MB.")
            upload_size = 10_000_000

        if upload_size > MAX_UPLOAD_BYTES:
            print(f"Upload size too large; capping to {MAX_UPLOAD_BYTES} bytes.")
            upload_size = MAX_UPLOAD_BYTES

        # Use timezone-aware UTC timestamp
        record: Dict[str, Any] = {
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "test_type": "",
            "location_name": name,
            "url": url,
            "download_mbps": None,
            "upload_mbps": None,
            "download_bytes": None,
            "upload_bytes": None,
            "download_seconds": None,
            "upload_seconds": None,
            "ping_ms": None,
        }

        # Initialize local speed variables for summary/TTS
        dl_mbps = 0.0
        dl_seconds = 0.0
        up_mbps = 0.0
        up_seconds = 0.0
        dl_bytes = 0
        up_bytes = 0

        try:
            if t in ("1", "3"):
                print("\nStarting download test (diagnostics enabled)...")
                try:
                    dl_bytes, dl_seconds, first_byte_ms = measure_download(
                        url, max_bytes=max_dl_bytes, timeout=DOWNLOAD_TIMEOUT, prefer_ipv4=pref_ipv4
                    )
                except Exception as e:
                    print(f"Download failed for {name}: {e}")
                    nxt = find_next_working_location(idx, prefer_ipv4=pref_ipv4)
                    if nxt:
                        new_idx, new_name, new_url = nxt
                        print(f"Attempting download from next working location: {new_name} - {new_url}")
                        name, url, idx = new_name, new_url, new_idx
                        dl_bytes, dl_seconds, first_byte_ms = measure_download(
                            url, max_bytes=max_dl_bytes, timeout=DOWNLOAD_TIMEOUT, prefer_ipv4=pref_ipv4
                        )
                    else:
                        raise RuntimeError("No other working locations available for download.")
                dl_mbps, dl_mb_s, dl_human = format_speed(dl_bytes, dl_seconds)
                print(f"Downloaded {human_size(dl_bytes)} in {dl_seconds:.2f} s -> {dl_human}")
                if first_byte_ms is not None:
                    print(f"Time to first byte: {first_byte_ms:.1f} ms")
                record.update(
                    {
                        "download_mbps": round(dl_mbps, 3),
                        "download_bytes": dl_bytes,
                        "download_seconds": round(dl_seconds, 3),
                        "ping_ms": round(first_byte_ms, 3) if first_byte_ms is not None else None,
                    }
                )
            if t in ("2", "3"):
                print("\nStarting upload test...")
                try:
                    up_bytes, up_seconds, up_first_byte_ms = measure_upload(upload_url, total_bytes=upload_size)
                except Exception as e:
                    print(f"Upload failed: {e}")
                    up_bytes = up_seconds = up_first_byte_ms = None
                if up_bytes:
                    up_mbps, up_mb_s, up_human = format_speed(up_bytes, up_seconds)
                    print(f"Uploaded {human_size(up_bytes)} in {up_seconds:.2f} s -> {up_human}")
                    if up_first_byte_ms is not None:
                        print(f"Time to first upload byte: {up_first_byte_ms:.1f} ms")
                    record.update(
                        {
                            "upload_mbps": round(up_mbps, 3),
                            "upload_bytes": up_bytes,
                            "upload_seconds": round(up_seconds, 3),
                        }
                    )
            record["test_type"] = {"1": "download", "2": "upload", "3": "download+upload"}.get(t, "")
        except Exception as e:
            print("\nERROR during test:", e)
            _print_sanitized_traceback()

        # Prepare values for TTS/summary using the same measured times
        dl_mbps = float(record.get("download_mbps") or 0.0)
        dl_seconds = float(record.get("download_seconds") or 0.0)
        up_mbps = float(record.get("upload_mbps") or 0.0)
        up_seconds = float(record.get("upload_seconds") or 0.0)
        dl_bytes = int(record.get("download_bytes") or 0)
        up_bytes = int(record.get("upload_bytes") or 0)

        # Speak and print the Mbps summary (uses same time measurements)
        try:
            speak_rates(dl_mbps, dl_seconds, up_mbps, up_seconds)
        except Exception:
            # Ensure TTS failures don't crash the program
            print("TTS failed or unavailable; summary printed above.")

        # Also print and speak the Download ↔ Upload summary using the same time frame (explicit Mbps)
        try:
            summarize_dl_up(dl_bytes, dl_seconds, up_bytes, up_seconds)
        except Exception:
            print("Failed to produce Download ↔ Upload summary.")

        save = input("\nSave result to CSV? (y/N): ").strip().lower()
        if save == "y":
            try:
                save_csv(record)
            except Exception as e:
                print("Failed to save CSV:", e)
                _print_sanitized_traceback()

        cont = input("\nRun another test? (Y/n): ").strip().lower()
        if cont == "n":
            print("Done.")
            return

if __name__ == "__main__":
    try:
        interactive()
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting.")
        sys.exit(0)
