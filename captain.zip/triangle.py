import tkinter as tk
from tkinter import messagebox
import math

# Configuration
ROWS = 5                 # number of rows in the triangle (5 -> 15 holes)
HOLE_RADIUS = 14
SPACING = 50             # horizontal spacing between adjacent holes
TOP_MARGIN = 30
LEFT_MARGIN = 200

class TrianglePegGame:
    def __init__(self, master, rows=ROWS):
        self.master = master
        self.rows = rows
        self.canvas = tk.Canvas(master, width=600, height=500, bg="#f0f0f0")
        self.canvas.pack(padx=10, pady=10)
        self.reset_button = tk.Button(master, text="Reset", command=self.reset_board)
        self.reset_button.pack(side="left", padx=8)
        self.undo_button = tk.Button(master, text="Undo", command=self.undo)
        self.undo_button.pack(side="left", padx=8)
        self.status_label = tk.Label(master, text="Click a peg to select it.")
        self.status_label.pack(side="left", padx=8)

        self.holes = []            # list of hole dicts: {'r':, 'c':, 'x':, 'y':, 'has':bool, 'id':circle_id}
        self.selected = None       # index of selected hole
        self.history = []          # stack for undo: (from_idx, over_idx, to_idx)
        self._build_board()
        self.canvas.bind("<Button-1>", self.on_click)

    def _build_board(self):
        self.canvas.delete("all")
        self.holes.clear()
        # compute coordinates for triangular layout (equilateral spacing)
        v_spacing = SPACING * 0.866  # sin(60) for equilateral triangle vertical spacing
        for r in range(self.rows):
            for c in range(r + 1):
                # center the triangle horizontally
                x = LEFT_MARGIN + (c - r / 2) * SPACING
                y = TOP_MARGIN + r * v_spacing
                hole = {'r': r, 'c': c, 'x': x, 'y': y, 'has': True, 'id': None}
                self.holes.append(hole)
        # default: remove center peg (classic starting position)
        center_index = self._index_from_rc(self.rows // 2, self.rows // 2 // 1) if False else self._index_from_rc(0,0)
        # Many versions remove top peg; we'll remove the top center (0,0) by default to create a challenge
        top_idx = self._index_from_rc(0, 0)
        if top_idx is not None:
            self.holes[top_idx]['has'] = False

        # draw holes and pegs
        for i, h in enumerate(self.holes):
            x, y = h['x'], h['y']
            hole_id = self.canvas.create_oval(x - HOLE_RADIUS, y - HOLE_RADIUS,
                                              x + HOLE_RADIUS, y + HOLE_RADIUS,
                                              fill="#c0c0c0", outline="#606060")
            peg_id = None
            if h['has']:
                peg_id = self.canvas.create_oval(x - HOLE_RADIUS + 4, y - HOLE_RADIUS + 4,
                                                 x + HOLE_RADIUS - 4, y + HOLE_RADIUS - 4,
                                                 fill="#2b7cff", outline="#0b4f9a", width=2)
            h['id'] = (hole_id, peg_id)
        self.selected = None
        self.history.clear()
        self._update_status()

    def _index_from_rc(self, r, c):
        if r < 0 or r >= self.rows or c < 0 or c > r:
            return None
        # index mapping: sum_{k=0}^{r-1} (k+1) + c
        idx = r * (r + 1) // 2 + c
        return idx

    def _find_nearest_hole(self, x, y):
        best = None
        best_dist = 1e9
        for i, h in enumerate(self.holes):
            d = math.hypot(h['x'] - x, h['y'] - y)
            if d < best_dist:
                best_dist = d
                best = i
        if best_dist <= HOLE_RADIUS * 1.6:
            return best
        return None

    def on_click(self, event):
        idx = self._find_nearest_hole(event.x, event.y)
        if idx is None:
            return
        hole = self.holes[idx]
        if self.selected is None:
            if hole['has']:
                self.selected = idx
                self._highlight_selected(idx)
                self._update_status(f"Selected peg at {hole['r']},{hole['c']}. Choose destination.")
        else:
            if idx == self.selected:
                # deselect
                self.selected = None
                self._clear_highlight()
                self._update_status("Selection cleared.")
                return
            # attempt move from selected -> idx
            moved = self._attempt_move(self.selected, idx)
            if moved:
                self.selected = None
                self._clear_highlight()
                self._check_game_end()
            else:
                # if clicked another peg, switch selection
                if hole['has']:
                    self.selected = idx
                    self._highlight_selected(idx)
                    self._update_status(f"Selected peg at {hole['r']},{hole['c']}.")
                else:
                    self._update_status("Invalid move. Try another destination or select a different peg.")

    def _highlight_selected(self, idx):
        # draw a ring around selected peg
        self._clear_highlight()
        h = self.holes[idx]
        x, y = h['x'], h['y']
        ring = self.canvas.create_oval(x - HOLE_RADIUS - 4, y - HOLE_RADIUS - 4,
                                       x + HOLE_RADIUS + 4, y + HOLE_RADIUS + 4,
                                       outline="#ff9900", width=3, tags="selring")
        # optionally show possible destinations
        for j, dest in enumerate(self.holes):
            if not dest['has']:
                if self._is_valid_jump(idx, j):
                    self.canvas.create_oval(dest['x'] - 6, dest['y'] - 6, dest['x'] + 6, dest['y'] + 6,
                                            outline="#00aa00", width=2, tags="selring")

    def _clear_highlight(self):
        self.canvas.delete("selring")

    def _is_valid_jump(self, from_idx, to_idx):
        if from_idx == to_idx:
            return False
        a = self.holes[from_idx]
        b = self.holes[to_idx]
        if not a['has'] or b['has']:
            return False
        # distance between centers must be about 2 * spacing in some direction
        dist = math.hypot(a['x'] - b['x'], a['y'] - b['y'])
        # expected jump distance is roughly 2 * SPACING horizontally or 2 * v_spacing vertically
        expected = 2 * SPACING * 0.98  # tolerance factor
        v_expected = 2 * SPACING * 0.866 * 0.98
        if not (abs(dist - expected) < 12 or abs(dist - v_expected) < 12):
            return False
        # midpoint must correspond to a hole that has a peg
        mx, my = (a['x'] + b['x']) / 2, (a['y'] + b['y']) / 2
        mid_idx = self._find_nearest_hole(mx, my)
        if mid_idx is None:
            return False
        if not self.holes[mid_idx]['has']:
            return False
        # ensure midpoint is roughly halfway (avoid false positives)
        mid = self.holes[mid_idx]
        if math.hypot(mid['x'] - mx, mid['y'] - my) > 8:
            return False
        return True

    def _attempt_move(self, from_idx, to_idx):
        if not self._is_valid_jump(from_idx, to_idx):
            return False
        # find midpoint index
        a = self.holes[from_idx]
        b = self.holes[to_idx]
        mx, my = (a['x'] + b['x']) / 2, (a['y'] + b['y']) / 2
        mid_idx = self._find_nearest_hole(mx, my)
        # perform move
        self.holes[from_idx]['has'] = False
        self._remove_peg_visual(from_idx)
        self.holes[mid_idx]['has'] = False
        self._remove_peg_visual(mid_idx)
        self.holes[to_idx]['has'] = True
        self._draw_peg_visual(to_idx)
        self.history.append((from_idx, mid_idx, to_idx))
        self._update_status("Moved.")
        return True

    def _remove_peg_visual(self, idx):
        hole_id, peg_id = self.holes[idx]['id']
        if peg_id:
            self.canvas.delete(peg_id)
            self.holes[idx]['id'] = (hole_id, None)

    def _draw_peg_visual(self, idx):
        hole_id, peg_id = self.holes[idx]['id']
        if peg_id:
            return
        h = self.holes[idx]
        peg_id = self.canvas.create_oval(h['x'] - HOLE_RADIUS + 4, h['y'] - HOLE_RADIUS + 4,
                                         h['x'] + HOLE_RADIUS - 4, h['y'] + HOLE_RADIUS - 4,
                                         fill="#2b7cff", outline="#0b4f9a", width=2)
        self.holes[idx]['id'] = (hole_id, peg_id)

    def undo(self):
        if not self.history:
            self._update_status("Nothing to undo.")
            return
        from_idx, mid_idx, to_idx = self.history.pop()
        # reverse move
        self.holes[from_idx]['has'] = True
        self._draw_peg_visual(from_idx)
        self.holes[mid_idx]['has'] = True
        self._draw_peg_visual(mid_idx)
        self.holes[to_idx]['has'] = False
        self._remove_peg_visual(to_idx)
        self._update_status("Undo performed.")

    def reset_board(self):
        self._build_board()

    def _check_game_end(self):
        remaining = sum(1 for h in self.holes if h['has'])
        if remaining == 1:
            messagebox.showinfo("You win!", "Only one peg left. You solved it!")
            self._update_status("Solved! Reset to play again.")
            return
        # check if any valid moves remain
        for i, h in enumerate(self.holes):
            if h['has']:
                for j, dest in enumerate(self.holes):
                    if self._is_valid_jump(i, j):
                        return
        messagebox.showinfo("No moves", f"No moves left. Pegs remaining: {remaining}")
        self._update_status("No moves left. Reset to try again.")

    def _update_status(self, text=None):
        if text is None:
            remaining = sum(1 for h in self.holes if h['has'])
            text = f"Pegs remaining: {remaining}."
        self.status_label.config(text=text)

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Triangle Peg Game")
    game = TrianglePegGame(root, rows=ROWS)
    root.mainloop()
