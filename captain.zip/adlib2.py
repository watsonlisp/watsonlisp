#!/usr/bin/env python3
import random
import shutil
import subprocess
import sys
import platform
import base64

SENTENCES = [
    "This morning I found a __ on my doorstep.",
    "My neighbor's cat learned to __ last week.",
    "For breakfast I always crave __ with honey.",
    "When it rains I like to __ by the window.",
    "At the festival everyone wore a __ on their head.",
    "The old bookstore smelled like __ and memories.",
    "On road trips we compete to spot the first __.",
    "Her laugh sounded like a __ in the quiet room.",
    "He collects vintage __ from flea markets.",
    "The secret ingredient in the soup was __.",
    "I once traded a sandwich for a __ at the park.",
    "Under the full moon the garden turned into a __.",
    "She painted the fence the color of __.",
    "My favorite childhood toy was a __ that squeaked.",
    "We danced until dawn to a song about __.",
    "The letter began with a single word: __.",
    "He keeps a tiny __ in his pocket for luck.",
    "On Sundays we make pancakes shaped like __.",
    "The lighthouse flashed a warning about __.",
    "I wrote a postcard that only said the word __.",
    "The movie ended with an unexpected __.",
    "At the picnic a squirrel stole my __.",
    "Her handwriting looked like __ on the page.",
    "The old map showed a hidden __ behind the hill.",
    "He whispered a joke about __ and everyone laughed.",
    "The train smelled faintly of __ and coffee.",
    "She wore a necklace made from a single __.",
    "The recipe called for a pinch of __ and courage.",
    "In winter the pond turned into a mirror of __.",
    "He promised to bring __ to the reunion.",
    "The cat knocked over a vase shaped like a __.",
    "We built a fort out of blankets and a __.",
    "The magician pulled a __ out of his hat.",
    "Her garden grew a mysterious __ overnight.",
    "The old radio played a song about __.",
    "He named his boat after a __ he once saw.",
    "The museum had an exhibit dedicated to __.",
    "She keeps a list of things she wants to __.",
    "The bakery sold a pastry filled with __.",
    "On the hike we found a trail of __ footprints.",
    "He wrote a poem that mentioned __ three times.",
    "The cat's favorite hiding spot was inside a __.",
    "They celebrated by releasing a dozen __ into the sky.",
    "The clock stopped at the exact moment he said __.",
    "She taught her dog to fetch a __ on command.",
    "The attic smelled like __ and old photographs.",
    "He swore he saw a __ in the reflection.",
    "The festival's main attraction was a giant __.",
    "She keeps a jar of __ on her kitchen counter.",
    "The postcard from far away only had the word __.",
    "At midnight the city sounded like a chorus of __.",
    "He collects postcards that feature __ on the front.",
    "The secret handshake involved tapping a __ twice.",
    "She always orders the dish with extra __.",
    "The painting had a tiny hidden __ in the corner.",
    "He dreamed of a place where everyone wore __.",
    "The old theater still smelled faintly of __.",
    "She wrote her name in the sand next to a __.",
    "The festival handed out free samples of __.",
    "He keeps a small notebook titled 'Things I __'.",
    "The lighthouse keeper loved to whistle about __.",
    "She found a coin engraved with a tiny __.",
    "The recipe was passed down with a note about __.",
    "He swore the tree in the yard whispered __ at night.",
    "The parade featured a float shaped like a giant __.",
    "She wrapped the gift in paper printed with __.",
    "The cat's collar jingled with a charm shaped like __.",
    "He wrote a letter to his future self about __.",
    "The old clock tower chimed a tune about __.",
    "She keeps a playlist of songs that mention __.",
    "The market sold jars of homemade __ for charity.",
    "He painted his bicycle the color of __.",
    "The lighthouse beam briefly revealed a __ at sea.",
    "She planted seeds that promised to grow into __.",
    "The festival's mascot was a friendly __.",
    "He always carries a tiny __ in his wallet.",
    "The attic contained a trunk full of __.",
    "She learned to play a lullaby about __ on the piano.",
    "The recipe's final step was to sprinkle __ on top.",
    "He swore the old house hummed the tune of __.",
    "The postcard collection included one from __.",
    "She wore socks patterned with tiny __.",
    "The bakery's best seller was a roll filled with __.",
    "He once traded a story for a __ at a cafe.",
    "The garden gate had a knocker shaped like a __.",
    "She keeps a photograph of a sunset over __.",
    "The train conductor announced a stop called __.",
    "He wrote a short story titled 'The Last __'.",
    "The museum guide told a tale about a lost __.",
    "She found a note tucked inside a book that read __.",
    "The festival's closing act involved juggling __.",
    "He keeps a list of movies that feature __.",
    "The lighthouse's name was carved with the word __.",
    "She always adds a dash of __ to her tea.",
    "The cat left a present of a tiny __ on the mat.",
    "He dreamed of sailing to an island made of __.",
    "The old postcard showed a carnival with a giant __.",
    "She wrote a grocery list that included __ and milk.",
    "The clock in the hallway stopped when the __ arrived.",
    "He keeps a small stone engraved with the word __.",
    "The bakery displayed a sign that read 'Fresh __ Today'.",
    "She once found a message in a bottle that said __.",
    "The concert ended with everyone shouting the word __.",
    "He keeps a jar labeled 'Wishes' filled with __.",
    "The map in the attic marked an X near a __.",
    "She always hums a tune about __ while cooking.",
    "The festival sold handmade scarves patterned with __.",
    "He wrote a postcard that simply said 'Meet me at __'.",
    "The lighthouse's light revealed a silhouette of a __.",
    "She keeps a tiny flag from a place called __.",
    "The cat's favorite toy was a stuffed __.",
    "He once found a ticket stub for a show called __.",
    "The bakery's window displayed a cake shaped like a __.",
    "She keeps a list of things that make her __.",
    "The old radio host always signed off with the word __.",
    "He painted a mural that featured a giant __.",
    "The garden bench had a plaque that read '__ and Friends'.",
    "She wrote a short note that only said '__, always'.",
    "The market sold jars labeled 'Sunshine and __'.",
    "He keeps a postcard pinned above his desk that reads '__'.",
    "The festival's souvenir was a tiny replica of a __.",
    "She once found a key with a tag that said '__'.",
    "The lighthouse keeper kept a diary titled 'Days of __'.",
    "He swore the wind carried the scent of __ that afternoon.",
    "The bakery offered a special called 'The __ Surprise'.",
    "She keeps a ribbon tied to her bike that says '__'.",
    "The concert poster featured an illustration of a __.",
    "He wrote a list of things he'd like to learn, starting with __.",
    "The old map's legend included a symbol for __.",
    "She always leaves a cup of tea out for the __.",
    "The postcard from the coast had a stamp shaped like a __.",
    "He keeps a tiny wooden carving of a __ on his shelf.",
    "The festival's opening line-up included a band named '__'.",
    "She once received a letter that began with '__, my dear'.",
    "The bakery's secret recipe mentioned a pinch of __.",
    "He keeps a small tin labeled 'Memories of __'.",
    "The lighthouse's keeper loved to tell stories about __.",
    "She wrote a song that repeated the word '__' in the chorus.",
    "The market's best vendor always sold jars of __.",
    "He painted his mailbox the color of __.",
    "The cat's favorite nap spot was under a blanket with __.",
    "She keeps a postcard that simply reads 'Wish you were __'.",
    "The old theater marquee once advertised a play called '__'.",
    "He keeps a tiny bell that rings like a __.",
    "The festival's final fireworks formed the shape of a __.",
    "She once found a folded note that said 'Remember __'.",
    "The bakery's sign promised 'Warm __ every morning'.",
    "He keeps a list of places he'd like to visit, starting with __.",
    "The lighthouse's shadow fell across a field of __.",
    "She always tucks a small charm shaped like a __ into her pocket.",
    "The postcard collection included one with a picture of __.",
    "He once traded a map for a mysterious __ at the market.",
    "The concert encore featured a song about __.",
    "She keeps a jar of buttons, the prettiest one shaped like a __.",
    "The old clock's face had a tiny engraving of a __.",
    "He wrote a postcard that ended with the single word '__'."
]

def pick_sentence():
    return random.choice(SENTENCES)

def get_user_fill(prompt_text):
    fill = input(prompt_text).strip()
    while not fill:
        print("Please type something to fill the blank.")
        fill = input(prompt_text).strip()
    return fill

def tts_speak(text):
    system = platform.system()
    # macOS: use 'say'
    if system == "Darwin":
        if shutil.which("say"):
            try:
                subprocess.run(["say", text], check=True)
                return True
            except Exception:
                return False
        return False

    # Windows: use PowerShell + System.Speech via EncodedCommand to avoid quoting issues
    if system == "Windows":
        try:
            ps_script = (
                "Add-Type -AssemblyName System.Speech;"
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                "$s.Rate = 0;"
                "$s.Volume = 100;"
                "$s.Speak([Console]::In.ReadToEnd());"
            )
            # PowerShell expects UTF-16LE bytes for -EncodedCommand
            encoded = base64.b64encode(ps_script.encode("utf-16-le")).decode("ascii")
            proc = subprocess.Popen(
                ["powershell", "-NoProfile", "-EncodedCommand", encoded],
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                text=True
            )
            proc.communicate(text)
            return proc.returncode == 0
        except Exception:
            return False

    # Linux/other: try common TTS utilities
    if shutil.which("espeak"):
        try:
            subprocess.run(["espeak", text], check=True)
            return True
        except Exception:
            pass
    if shutil.which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=True)
            return True
        except Exception:
            pass
    if shutil.which("festival"):
        try:
            # festival can read from stdin with --tts
            proc = subprocess.Popen(["festival", "--tts"], stdin=subprocess.PIPE, text=True)
            proc.communicate(text)
            return proc.returncode == 0
        except Exception:
            pass

    return False

def run_adlib():
    print("Adlib Generator (no pip required). Press Ctrl+C to quit.\n")
    try:
        while True:
            template = pick_sentence()
            print("Fill this blank:")
            print("  " + template.replace("__", "_____"))
            user_fill = get_user_fill("Your word or phrase: ")
            completed = template.replace("__", user_fill)
            print("\nCompleted sentence:")
            print("  " + completed + "\n")
            spoken = tts_speak(completed)
            if not spoken:
                print("TTS not available on this system. (Completed sentence printed above.)\n")
            again = input("Try another? (y/n): ").strip().lower()
            if again not in ("y", "yes"):
                print("Goodbye!")
                break
    except KeyboardInterrupt:
        print("\nGoodbye!")

if __name__ == "__main__":
    run_adlib()
