#!/usr/bin/env python3
"""
Tamagotchi Tkinter GUI (standard library only) with Reset button.
Save as tamagotchi_tk.py and run: python tamagotchi_tk.py
"""

import json
import os
import time
import math
import sys
import tkinter as tk
from tkinter import simpledialog, messagebox

# Config
SAVE_FILE = "tamagotchi_state.json"
TICK_MS = 1000  # tick every 1 second
CANVAS_W, CANVAS_H = 640, 420

# Try winsound on Windows for nicer beeps
try:
    import winsound
    HAS_WINSOUND = True
except Exception:
    HAS_WINSOUND = False

def clamp(v, a=0, b=100):
    return max(a, min(b, int(v)))

class Tamagotchi:
    def __init__(self, name="Tama"):
        self.name = name
        self.hunger = 50      # 0 full -> 100 starving
        self.happiness = 50   # 0 sad -> 100 happy
        self.energy = 50      # 0 exhausted -> 100 rested
        self.age_seconds = 0
        self.alive = True
        self.sick = False

    def to_dict(self):
        return {
            "name": self.name,
            "hunger": self.hunger,
            "happiness": self.happiness,
            "energy": self.energy,
            "age_seconds": self.age_seconds,
            "alive": self.alive,
            "sick": self.sick,
        }

    @classmethod
    def from_dict(cls, d):
        pet = cls(d.get("name", "Tama"))
        pet.hunger = d.get("hunger", 50)
        pet.happiness = d.get("happiness", 50)
        pet.energy = d.get("energy", 50)
        pet.age_seconds = d.get("age_seconds", 0)
        pet.alive = d.get("alive", True)
        pet.sick = d.get("sick", False)
        return pet

    def feed(self, amount=20):
        if not self.alive:
            return "dead"
        self.hunger = clamp(self.hunger - amount)
        self.happiness = clamp(self.happiness + 5)
        return "ok"

    def play(self, duration=10):
        if not self.alive:
            return "dead"
        energy_cost = int(duration / 2)
        if self.energy < energy_cost:
            return "tired"
        self.happiness = clamp(self.happiness + int(duration / 2))
        self.energy = clamp(self.energy - energy_cost)
        self.hunger = clamp(self.hunger + int(duration / 3))
        return "ok"

    def sleep(self, duration=30):
        if not self.alive:
            return "dead"
        self.energy = clamp(self.energy + int(duration / 2))
        self.hunger = clamp(self.hunger + int(duration / 4))
        self.happiness = clamp(self.happiness + 2)
        return "ok"

    def tick(self, seconds=1):
        if not self.alive:
            return
        self.age_seconds += seconds
        # decay rates
        self.hunger = clamp(self.hunger + 0.5 * seconds)
        self.happiness = clamp(self.happiness - 0.3 * seconds)
        self.energy = clamp(self.energy - 0.2 * seconds)
        self.sick = self.hunger > 85 or self.energy < 10
        if self.hunger >= 100 or self.happiness <= 0 or self.energy <= 0:
            self.alive = False

# Sound helper (standard library only)
def play_sound(kind="ping"):
    if HAS_WINSOUND and sys.platform.startswith("win"):
        try:
            if kind == "feed":
                winsound.Beep(880, 100)
            elif kind == "play":
                winsound.Beep(660, 140)
            elif kind == "sleep":
                winsound.Beep(440, 200)
            elif kind == "dead":
                winsound.Beep(150, 600)
            elif kind == "confirm":
                winsound.Beep(1000, 80)
            else:
                winsound.MessageBeep()
        except Exception:
            pass
    else:
        # fallback: use tkinter bell (short) if root exists
        try:
            root.bell()
        except Exception:
            pass

class TamagotchiApp:
    def __init__(self, master, pet):
        self.master = master
        self.pet = pet
        master.title("Tamagotchi")
        master.resizable(False, False)

        self.canvas = tk.Canvas(master, width=CANVAS_W, height=CANVAS_H, bg="#f6f8ff")
        self.canvas.pack()

        # Buttons
        btn_frame = tk.Frame(master)
        btn_frame.pack(fill="x", pady=4)
        self.btn_feed = tk.Button(btn_frame, text="Feed (F)", width=10, command=self.on_feed)
        self.btn_play = tk.Button(btn_frame, text="Play (P)", width=10, command=self.on_play)
        self.btn_sleep = tk.Button(btn_frame, text="Sleep (S)", width=10, command=self.on_sleep)
        self.btn_save = tk.Button(btn_frame, text="Save (V)", width=10, command=self.on_save)
        self.btn_load = tk.Button(btn_frame, text="Load (L)", width=10, command=self.on_load)
        self.btn_reset = tk.Button(btn_frame, text="Reset (R)", width=10, command=self.on_reset)
        self.btn_quit = tk.Button(btn_frame, text="Quit (Q)", width=10, command=self.on_quit)
        for w in (self.btn_feed, self.btn_play, self.btn_sleep, self.btn_save, self.btn_load, self.btn_reset, self.btn_quit):
            w.pack(side="left", padx=6)

        # Bind keys
        master.bind("<f>", lambda e: self.on_feed())
        master.bind("<F>", lambda e: self.on_feed())
        master.bind("<p>", lambda e: self.on_play())
        master.bind("<P>", lambda e: self.on_play())
        master.bind("<s>", lambda e: self.on_sleep())
        master.bind("<S>", lambda e: self.on_sleep())
        master.bind("<v>", lambda e: self.on_save())
        master.bind("<V>", lambda e: self.on_save())
        master.bind("<l>", lambda e: self.on_load())
        master.bind("<L>", lambda e: self.on_load())
        master.bind("<r>", lambda e: self.on_reset())
        master.bind("<R>", lambda e: self.on_reset())
        master.bind("<q>", lambda e: self.on_quit())
        master.bind("<Q>", lambda e: self.on_quit())

        # Animation state
        self.bob = 0.0
        self.last_draw = time.time()

        # Start ticking and drawing
        self._tick()
        self._draw()

    def on_feed(self):
        res = self.pet.feed(25)
        if res == "ok":
            play_sound("feed")
        elif res == "dead":
            messagebox.showinfo("Feed", "Your pet is not alive.")
        self._draw()

    def on_play(self):
        res = self.pet.play(15)
        if res == "ok":
            play_sound("play")
        elif res == "tired":
            messagebox.showinfo("Play", f"{self.pet.name} is too tired to play.")
        elif res == "dead":
            messagebox.showinfo("Play", "Your pet is not alive.")
        self._draw()

    def on_sleep(self):
        res = self.pet.sleep(40)
        if res == "ok":
            play_sound("sleep")
        elif res == "dead":
            messagebox.showinfo("Sleep", "Your pet is not alive.")
        self._draw()

    def on_save(self):
        try:
            with open(SAVE_FILE, "w") as f:
                json.dump(self.pet.to_dict(), f)
            messagebox.showinfo("Save", "Saved pet state.")
        except Exception as e:
            messagebox.showerror("Save error", str(e))

    def on_load(self):
        if os.path.exists(SAVE_FILE):
            try:
                with open(SAVE_FILE, "r") as f:
                    data = json.load(f)
                loaded = Tamagotchi.from_dict(data)
                # copy fields to current pet object
                self.pet.name = loaded.name
                self.pet.hunger = loaded.hunger
                self.pet.happiness = loaded.happiness
                self.pet.energy = loaded.energy
                self.pet.age_seconds = loaded.age_seconds
                self.pet.alive = loaded.alive
                self.pet.sick = loaded.sick
                messagebox.showinfo("Load", f"Loaded {self.pet.name}.")
            except Exception as e:
                messagebox.showerror("Load error", str(e))
        else:
            messagebox.showinfo("Load", "No save file found.")
        self._draw()

    def on_reset(self):
        """Reset pet to default state after confirmation and remove save file."""
        if not messagebox.askyesno("Reset Pet", "Are you sure you want to reset your pet? This will delete the saved state."):
            return
        # Reset fields
        self.pet.name = "Tama"
        self.pet.hunger = 50
        self.pet.happiness = 50
        self.pet.energy = 50
        self.pet.age_seconds = 0
        self.pet.alive = True
        self.pet.sick = False
        # Remove save file if exists
        try:
            if os.path.exists(SAVE_FILE):
                os.remove(SAVE_FILE)
        except Exception:
            pass
        play_sound("confirm")
        messagebox.showinfo("Reset", "Pet has been reset.")
        self._draw()

    def on_quit(self):
        # save on exit
        try:
            with open(SAVE_FILE, "w") as f:
                json.dump(self.pet.to_dict(), f)
        except Exception:
            pass
        self.master.destroy()

    def _tick(self):
        # called every TICK_MS
        if self.pet.alive:
            self.pet.tick(1)
        else:
            self.pet.sick = False
        # autosave occasionally (every 10 seconds)
        if int(self.pet.age_seconds) % 10 == 0:
            try:
                with open(SAVE_FILE, "w") as f:
                    json.dump(self.pet.to_dict(), f)
            except Exception:
                pass
        # if pet died just now, play death sound
        if not self.pet.alive:
            play_sound("dead")
        self.master.after(TICK_MS, self._tick)

    def _draw(self):
        now = time.time()
        dt = now - self.last_draw
        self.last_draw = now
        self.bob += dt * 4.0
        pet_y_offset = int(math.sin(self.bob) * 6)

        self.canvas.delete("all")

        # Title and name
        self.canvas.create_text(CANVAS_W//2, 18, text=f"Tamagotchi — {self.pet.name}", font=("Helvetica", 16, "bold"))

        # Pet body (oval)
        pet_x, pet_y, pet_w, pet_h = 220, 60 + pet_y_offset, 200, 160
        self.canvas.create_oval(pet_x, pet_y, pet_x + pet_w, pet_y + pet_h, fill="#fff0d9", outline="#333", width=2)

        # Eyes
        eye_y = pet_y + 55
        self.canvas.create_oval(pet_x + 50, eye_y, pet_x + 70, eye_y + 20, fill="#000")
        self.canvas.create_oval(pet_x + 130, eye_y, pet_x + 150, eye_y + 20, fill="#000")

        # Mouth based on happiness
        mouth_y = pet_y + 110
        if self.pet.happiness > 60:
            self.canvas.create_arc(pet_x + 60, mouth_y - 10, pet_x + 140, mouth_y + 30, start=180, extent=180, style="arc", width=3, outline="#d33")
        elif self.pet.happiness < 30:
            self.canvas.create_arc(pet_x + 60, mouth_y - 10, pet_x + 140, mouth_y + 30, start=0, extent=180, style="arc", width=3, outline="#333")
        else:
            self.canvas.create_line(pet_x + 80, mouth_y + 10, pet_x + 120, mouth_y + 10, width=3, fill="#333")

        # Status bars labels
        self.canvas.create_text(80, 80, text="Hunger (low is good)", anchor="w", font=("Helvetica", 10))
        self.canvas.create_text(80, 140, text="Happiness", anchor="w", font=("Helvetica", 10))
        self.canvas.create_text(80, 200, text="Energy", anchor="w", font=("Helvetica", 10))

        # Bars (drawn as rectangles)
        def draw_bar(x, y, w, h, pct, fill):
            self.canvas.create_rectangle(x, y, x + w, y + h, fill="#ddd", outline="#333")
            inner = int(w * (pct / 100.0))
            if inner > 0:
                self.canvas.create_rectangle(x, y, x + inner, y + h, fill=fill, outline="")
            self.canvas.create_rectangle(x, y, x + w, y + h, outline="#000", width=1)

        draw_bar(40, 90, 220, 20, 100 - self.pet.hunger, "#6cc070")
        draw_bar(40, 150, 220, 20, self.pet.happiness, "#f0d54a")
        draw_bar(40, 210, 220, 20, self.pet.energy, "#6ea8f7")

        # Age and status
        age_str = time.strftime("%H:%M:%S", time.gmtime(self.pet.age_seconds))
        status_text = "Alive" if self.pet.alive else "Dead"
        status_color = "#2e8b57" if self.pet.alive else "#c0392b"
        self.canvas.create_text(520, 40, text=f"Age: {age_str}", font=("Helvetica", 12))
        self.canvas.create_text(520, 70, text=f"Status: {status_text}", font=("Helvetica", 12), fill=status_color)
        if self.pet.sick and self.pet.alive:
            self.canvas.create_text(520, 100, text="Sick", font=("Helvetica", 12), fill="#c0392b")

        # Hints
        self.canvas.create_text(CANVAS_W//2, 360, text="Keys: F feed   P play   S sleep   V save   L load   R reset   Q quit", font=("Helvetica", 10))

        # If dead, overlay a translucent rectangle and message
        if not self.pet.alive:
            self.canvas.create_rectangle(0, 0, CANVAS_W, CANVAS_H, fill="#000000", stipple="gray50")
            self.canvas.create_text(CANVAS_W//2, CANVAS_H//2, text=f"{self.pet.name} has passed away.", font=("Helvetica", 18, "bold"), fill="#fff")

        # schedule next draw
        self.master.after(50, self._draw)

def load_pet():
    if os.path.exists(SAVE_FILE):
        try:
            with open(SAVE_FILE, "r") as f:
                data = json.load(f)
            return Tamagotchi.from_dict(data)
        except Exception:
            pass
    return None

if __name__ == "__main__":
    # Create root early so play_sound can use bell fallback
    root = tk.Tk()
    pet = load_pet()
    if pet is None:
        name = simpledialog.askstring("Name your Tamagotchi", "Enter a name for your Tamagotchi:", parent=root)
        if not name:
            name = "Tama"
        pet = Tamagotchi(name=name)
    app = TamagotchiApp(root, pet)
    try:
        root.mainloop()
    except KeyboardInterrupt:
        try:
            with open(SAVE_FILE, "w") as f:
                json.dump(pet.to_dict(), f)
        except Exception:
            pass
        sys.exit(0)
