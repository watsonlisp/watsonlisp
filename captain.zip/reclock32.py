import math
import tkinter as tk
from datetime import datetime, timezone, timedelta

# --- Initial defaults (original values) ---
DEFAULTS = {
    "CUSTOM_MONTHS": 10,
    "DAYS_PER_MONTH": 30,
    "HOURS_PER_DAY": 20,
    "MINUTES_PER_HOUR": 50,
    "SECONDS_PER_MINUTE": 50
}

# --- Global configuration (start with defaults) ---
DAYS_GREGORIAN = 365
CUSTOM_MONTHS = DEFAULTS["CUSTOM_MONTHS"]
DAYS_PER_MONTH = DEFAULTS["DAYS_PER_MONTH"]
HOURS_PER_DAY = DEFAULTS["HOURS_PER_DAY"]
MINUTES_PER_HOUR = DEFAULTS["MINUTES_PER_HOUR"]
SECONDS_PER_MINUTE = DEFAULTS["SECONDS_PER_MINUTE"]

CUSTOM_SECONDS_PER_HOUR = MINUTES_PER_HOUR * SECONDS_PER_MINUTE
CUSTOM_SECONDS_PER_DAY = HOURS_PER_DAY * CUSTOM_SECONDS_PER_HOUR

# Timezone offset in hours (can be fractional). Default to system local offset if available.
try:
    _sys_offset = datetime.now().astimezone().utcoffset()
    DEFAULT_TZ_OFFSET = _sys_offset.total_seconds() / 3600.0 if _sys_offset is not None else 0.0
except Exception:
    DEFAULT_TZ_OFFSET = 0.0
TIMEZONE_OFFSET_HOURS = DEFAULT_TZ_OFFSET

# --- Conversion function: maps a datetime (UTC) to custom calendar values using timezone offset ---
def compute_custom(dt_utc):
    # dt_utc must be timezone-aware UTC
    # Apply timezone offset to get the "local" datetime used for calendar mapping
    local_dt = (dt_utc + timedelta(hours=TIMEZONE_OFFSET_HOURS)).astimezone(timezone.utc)

    start_of_year = datetime(local_dt.year, 1, 1, tzinfo=timezone.utc)
    day_of_year = (local_dt - start_of_year).days + 1

    seconds_since_midnight = local_dt.hour * 3600 + local_dt.minute * 60 + local_dt.second + local_dt.microsecond / 1e6
    fraction_of_day = seconds_since_midnight / 86400.0

    frac_year = (day_of_year - 1 + fraction_of_day) / DAYS_GREGORIAN
    custom_day_index = frac_year * (CUSTOM_MONTHS * DAYS_PER_MONTH)
    day_number = int(custom_day_index) + 1
    month = (day_number - 1) // DAYS_PER_MONTH + 1
    day_in_month = ((day_number - 1) % DAYS_PER_MONTH) + 1

    secs_into_custom_day = fraction_of_day * CUSTOM_SECONDS_PER_DAY

    # Keep fractional remainder for smoothness
    custom_hour = int(secs_into_custom_day // CUSTOM_SECONDS_PER_HOUR)          # 0..HOURS_PER_DAY-1
    secs_rem = secs_into_custom_day - custom_hour * CUSTOM_SECONDS_PER_HOUR

    custom_minute = int(secs_rem // SECONDS_PER_MINUTE)                        # 0..MINUTES_PER_HOUR-1
    custom_second = secs_rem - custom_minute * SECONDS_PER_MINUTE              # float, includes fraction

    return {
        "month": month,
        "day_in_month": day_in_month,
        "custom_hour": custom_hour,
        "custom_minute": custom_minute,
        "custom_second": custom_second,
        "local_dt": local_dt
    }

# --- Dial converter for the 20-hour military clock ---
def to_20hour_angles(pos):
    # Hour: exact custom-hour position (0..HOURS_PER_DAY)
    hour_frac = (pos["custom_minute"] + pos["custom_second"] / SECONDS_PER_MINUTE) / MINUTES_PER_HOUR
    dial_hour = (pos["custom_hour"] + hour_frac) % HOURS_PER_DAY
    angle_hour = (dial_hour / HOURS_PER_DAY) * 2 * math.pi - math.pi / 2

    # Minute: fraction of the current custom hour (0..1) -> full circle
    minute_fraction = (pos["custom_minute"] + pos["custom_second"] / SECONDS_PER_MINUTE) / MINUTES_PER_HOUR
    angle_minute = minute_fraction * 2 * math.pi - math.pi / 2

    # Second: faster sweep on the 20-hour dial (2 rotations per custom minute)
    second_fraction = pos["custom_second"] / SECONDS_PER_MINUTE
    angle_second = (second_fraction * 2.0) * 2 * math.pi - math.pi / 2

    return angle_hour, angle_minute, angle_second

# --- Tkinter UI setup: controls + single military 20-hour clock ---
WIDTH = 800
HEIGHT = 720
root = tk.Tk()
root.title("Military 20‑Hour Custom Clock")

# Top control frame
control_frame = tk.Frame(root, padx=8, pady=6, bg="#1a1a1a")
control_frame.pack(fill="x")

entries = {}

def make_labeled_entry(parent, label_text, default, col):
    lbl = tk.Label(parent, text=label_text, fg="#ddd", bg="#1a1a1a")
    lbl.grid(row=0, column=col*2, sticky="w", padx=(8,2))
    sv = tk.StringVar(value=str(default))
    ent = tk.Entry(parent, textvariable=sv, width=8)
    ent.grid(row=0, column=col*2+1, padx=(0,8))
    return sv

entries["CUSTOM_MONTHS"] = make_labeled_entry(control_frame, "CUSTOM_MONTHS", DEFAULTS["CUSTOM_MONTHS"], 0)
entries["DAYS_PER_MONTH"] = make_labeled_entry(control_frame, "DAYS_PER_MONTH", DEFAULTS["DAYS_PER_MONTH"], 1)
entries["HOURS_PER_DAY"] = make_labeled_entry(control_frame, "HOURS_PER_DAY", DEFAULTS["HOURS_PER_DAY"], 2)
entries["MINUTES_PER_HOUR"] = make_labeled_entry(control_frame, "MINUTES_PER_HOUR", DEFAULTS["MINUTES_PER_HOUR"], 3)
entries["SECONDS_PER_MINUTE"] = make_labeled_entry(control_frame, "SECONDS_PER_MINUTE", DEFAULTS["SECONDS_PER_MINUTE"], 4)

# Timezone offset entry (hours, can be fractional, e.g., -4, 5.5)
tz_label = tk.Label(control_frame, text="UTC offset (hours)", fg="#ddd", bg="#1a1a1a")
tz_label.grid(row=0, column=10, sticky="w", padx=(8,2))
tz_var = tk.StringVar(value=f"{DEFAULT_TZ_OFFSET:.2f}")
tz_entry = tk.Entry(control_frame, textvariable=tz_var, width=8)
tz_entry.grid(row=0, column=11, padx=(0,8))

status_label = tk.Label(control_frame, text="", fg="#ffcc66", bg="#1a1a1a")
status_label.grid(row=0, column=12, padx=12)

def apply_config():
    global CUSTOM_MONTHS, DAYS_PER_MONTH, HOURS_PER_DAY, MINUTES_PER_HOUR, SECONDS_PER_MINUTE
    global CUSTOM_SECONDS_PER_HOUR, CUSTOM_SECONDS_PER_DAY, TIMEZONE_OFFSET_HOURS
    try:
        cm = int(entries["CUSTOM_MONTHS"].get())
        dpm = int(entries["DAYS_PER_MONTH"].get())
        hpd = int(entries["HOURS_PER_DAY"].get())
        mph = int(entries["MINUTES_PER_HOUR"].get())
        spm = int(entries["SECONDS_PER_MINUTE"].get())
        tz_off = float(tz_var.get())

        if cm <= 0 or dpm <= 0 or hpd <= 0 or mph <= 0 or spm <= 0:
            raise ValueError("All values must be positive.")
        if cm > 1000 or dpm > 1000 or hpd > 1000 or mph > 10000 or spm > 10000:
            raise ValueError("One or more values are unreasonably large.")

        CUSTOM_MONTHS = cm
        DAYS_PER_MONTH = dpm
        HOURS_PER_DAY = hpd
        MINUTES_PER_HOUR = mph
        SECONDS_PER_MINUTE = spm
        TIMEZONE_OFFSET_HOURS = tz_off

        # recompute derived values
        globals()['CUSTOM_SECONDS_PER_HOUR'] = MINUTES_PER_HOUR * SECONDS_PER_MINUTE
        globals()['CUSTOM_SECONDS_PER_DAY'] = HOURS_PER_DAY * globals()['CUSTOM_SECONDS_PER_HOUR']

        update_translations()
        status_label.config(text="Applied", fg="#88ff88")
        root.after(1500, lambda: status_label.config(text="", fg="#ffcc66"))
    except Exception as e:
        status_label.config(text=f"Error: {e}", fg="#ff6666")
        root.after(3000, lambda: status_label.config(text="", fg="#ffcc66"))

def reset_defaults():
    for k, v in DEFAULTS.items():
        entries[k].set(str(v))
    tz_var.set(f"{DEFAULT_TZ_OFFSET:.2f}")
    apply_config()

btn_apply = tk.Button(control_frame, text="Apply", command=apply_config, bg="#2b2b2b", fg="#ddd")
btn_apply.grid(row=0, column=13, padx=(6,4))
btn_reset = tk.Button(control_frame, text="Reset Defaults", command=reset_defaults, bg="#2b2b2b", fg="#ddd")
btn_reset.grid(row=0, column=14, padx=(4,12))

# Canvas for the single clock
canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT-120, bg="#0b0b0b", highlightthickness=0)
canvas.pack()

# Layout: single clock center
CX = WIDTH // 2
CY = (HEIGHT - 120) // 2
RADIUS = int(min(WIDTH, HEIGHT-120) * 0.36)

# Quit with 'q'
def on_key(event):
    if event.char.lower() == 'q':
        root.destroy()
root.bind("<Key>", on_key)

def draw_20hour_face(cx, cy, radius):
    canvas.create_oval(cx - int(radius*1.08), cy - int(radius*1.08), cx + int(radius*1.08), cy + int(radius*1.08),
                       fill="#111111", outline="#cfcfcf", width=3)
    canvas.create_oval(cx - radius, cy - radius, cx + radius, cy + radius, fill="#0b0b0b", outline="")
    for i in range(HOURS_PER_DAY):
        angle = (i / HOURS_PER_DAY) * 2 * math.pi - math.pi/2
        outer = radius * 0.86
        inner = radius * 0.72
        x1 = cx + math.cos(angle) * outer
        y1 = cy + math.sin(angle) * outer
        x2 = cx + math.cos(angle) * inner
        y2 = cy + math.sin(angle) * inner
        canvas.create_line(x1, y1, x2, y2, fill="#ffffff", width=3)
        if HOURS_PER_DAY <= 24 or (i % 2 == 0):
            nx = cx + math.cos(angle) * (radius * 0.60)
            ny = cy + math.sin(angle) * (radius * 0.60)
            label = f"{i:02d}"
            canvas.create_text(nx, ny, text=label, fill="#ffffff", font=("Segoe UI", int(radius*0.08), "bold"))
    minor_count = max(4, HOURS_PER_DAY * 4)
    for i in range(minor_count):
        angle = (i / minor_count) * 2 * math.pi - math.pi/2
        x1 = cx + math.cos(angle) * (radius * 0.86)
        y1 = cy + math.sin(angle) * (radius * 0.86)
        x2 = cx + math.cos(angle) * (radius * 0.80)
        y2 = cy + math.sin(angle) * (radius * 0.80)
        canvas.create_line(x1, y1, x2, y2, fill="#666666", width=1)

def draw_hand(cx, cy, angle, length_frac, width, color):
    x = cx + math.cos(angle) * (RADIUS * length_frac)
    y = cy + math.sin(angle) * (RADIUS * length_frac)
    canvas.create_line(cx, cy, x, y, fill=color, width=width, capstyle=tk.ROUND)

# Compute initial translations for display
translation_lines = []
def update_translations():
    now_utc = datetime.now(timezone.utc)
    local_dt = (now_utc + timedelta(hours=TIMEZONE_OFFSET_HOURS))
    pos_local = compute_custom(now_utc)
    translation_local = f"Local (offset {TIMEZONE_OFFSET_HOURS:+.2f}h) {local_dt.isoformat()} -> Custom: Month {pos_local['month']} Day {pos_local['day_in_month']} Time {pos_local['custom_hour']:02d}:{pos_local['custom_minute']:02d}:{int(pos_local['custom_second']):02d}"
    translation_utc = translate_datetime_utc(now_utc)
    translation_lines.clear()
    translation_lines.extend([translation_local, translation_utc])

def translate_datetime_utc(dt_utc):
    pos = compute_custom(dt_utc)
    return (f"UTC {dt_utc.isoformat()} -> Custom: Month {pos['month']} Day {pos['day_in_month']} "
            f"Time {pos['custom_hour']:02d}:{pos['custom_minute']:02d}:{int(pos['custom_second']):02d}")

update_translations()

# Render loop: draw the face and hands each frame
def render():
    now_utc = datetime.now(timezone.utc)
    pos = compute_custom(now_utc)

    canvas.delete("all")

    # Draw 20-hour military face and hands
    draw_20hour_face(CX, CY, RADIUS)
    angle_h, angle_m, angle_s = to_20hour_angles(pos)
    draw_hand(CX, CY, angle_h, 0.45, 10, "#dcdcdc")
    draw_hand(CX, CY, angle_m, 0.68, 6, "#e6e6e6")
    draw_hand(CX, CY, angle_s, 0.78, 2, "#ffcc33")
    canvas.create_text(CX, CY - int(RADIUS*1.18), text="\nMilitary Hour Dial", fill="#ddd",
                       font=("Segoe UI", int(RADIUS*0.10), "bold"))

    # Center pin
    canvas.create_oval(CX - int(RADIUS*0.04), CY - int(RADIUS*0.04), CX + int(RADIUS*0.04), CY + int(RADIUS*0.04),
                       fill="#ffd27a", outline="")

    # Show custom date/time text under the clock
    custom_time = f"{pos['custom_hour']:02d}:{pos['custom_minute']:02d}:{int(pos['custom_second']):02d}"
    canvas.create_text(CX, CY + int(RADIUS*0.9), text=f"Month {pos['month']} Day {pos['day_in_month']}", fill="#ddd",
                       font=("Segoe UI", int(RADIUS*0.07)))
    canvas.create_text(CX, CY + int(RADIUS*1.05), text=f"\nCustom time (military): {custom_time}", fill="#ddd",
                       font=("Segoe UI", int(RADIUS*0.07)))

    # Show the translations at the top-left corner
    tx = 18
    ty = 18
    for i, line in enumerate(translation_lines):
        canvas.create_text(tx, ty + i*20, anchor="nw", text=line, fill="#ddd", font=("Segoe UI", 10))

    root.after(60, render)  # update ~16-17 FPS

# Start rendering
render()
root.mainloop()
