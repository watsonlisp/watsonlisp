#!/usr/bin/env python3
"""
Tic Tac Toe + Hollywood Trivia (Tkinter GUI) with TTS and expanded trivia bank
Save as tic_tac_trivia_tts_expanded.py and run with: python3 tic_tac_trivia_tts_expanded.py
TTS uses system utilities: macOS 'say', Windows PowerShell System.Speech, Linux 'spd-say' or 'espeak' if available.
No external packages required.
"""

import random
import threading
import subprocess
import platform
import shutil
import tkinter as tk
from tkinter import messagebox, simpledialog

# --- Very large Trivia bank: list of (question, answer) pairs (answers lowercase, trimmed) ---
TRIVIA = [
    ("Who directed Pulp Fiction?", "quentin tarantino"),
    ("Which actress played Andy in The Devil Wears Prada?", "anne hathaway"),
    ("Which film features the line 'Here's looking at you, kid'?", "casablanca"),
    ("Who played Jack in Titanic?", "leonardo dicaprio"),
    ("What 1927 film is considered the first major talkie?", "the jazz singer"),
    ("Name the skyscraper in Die Hard.", "nakatomi plaza"),
    ("What Pop-Tart flavor does Buddy use in Elf?", "chocolate"),
    ("Who played the Joker in The Dark Knight (2008)?", "heath ledger"),
    ("Which singer starred in Evita and sang 'Material Girl'?", "madonna"),
    ("What was the first fully computer-animated feature?", "toy story"),
    ("Which movie won Best Picture in 1994 starring Forrest?", "forrest gump"),
    ("Who directed Jaws, E.T., and Jurassic Park?", "steven spielberg"),
    ("Which 1977 film launched a major space-opera franchise?", "star wars"),
    ("Who played Mrs. Robinson in The Graduate?", "anne bancroft"),
    ("What animal's head appears in The Godfather?", "a horse"),
    ("Which film popularized the line 'Do you feel lucky?'", "dirty harry"),
    ("Who starred as Jack Sparrow?", "johnny depp"),
    ("Which movie features the address '42 Wallaby Way'?", "finding nemo"),
    ("Which 2018 Marvel film starred Chadwick Boseman?", "black panther"),
    ("What 2010 Pixar film features an old man and a floating house?", "up"),
    ("Who refused a salary to direct Schindler's List?", "steven spielberg"),
    ("Which 1980 horror film used 'Here's Johnny!'?", "the shining"),
    ("Who played Neo in The Matrix?", "keanu reeves"),
    ("Which Pixar film features the fictional band 4*Town?", "turning red"),
    ("Which director made Braveheart?", "mel gibson"),
    ("Which 2012 film used the tagline 'The D is silent'?", "django unchained"),
    ("Who composed the score for Scarface (1983)?", "giorgio moroder"),
    ("Which film was the first Netflix DVD sent out?", "beetlejuice"),
    ("Which 1987 film features Baby and a dance instructor?", "dirty dancing"),
    ("Who played Juror #8 in 12 Angry Men?", "henry fonda"),
    ("Which 2019 film by Bong Joon-ho won Best Picture?", "parasite"),
    ("Who directed The Shining?", "stanley kubrick"),
    ("Which film features Andy Dufresne?", "the shawshank redemption"),
    ("Who starred as Forrest Gump?", "tom hanks"),
    ("Which movie introduced the Red Pill / Blue Pill choice?", "the matrix"),
    ("Who directed The Godfather?", "francis ford coppola"),
    ("Which movie has the infamous horse head scene?", "the godfather"),
    ("Which film popularized the line 'I'll be back'?", "the terminator"),
    ("Who directed Citizen Kane?", "orson welles"),
    ("Which 1994 film features a slow-running man named Forrest?", "forrest gump"),
    ("Who played the lead in The Matrix trilogy?", "keanu reeves"),
    ("Which actress played Holly Golightly in Breakfast at Tiffany's?", "audrey hepburn"),
    ("Which movie features the song 'My Heart Will Go On'?", "titanic"),
    ("Who directed Schindler's List?", "steven spielberg"),
    ("Which actor played Indiana Jones?", "harrison ford"),
    ("Which film features the line 'You can't handle the truth'?", "a few good men"),
    ("Who directed Apocalypse Now?", "francis ford coppola"),
    ("Which movie features the character Tyler Durden?", "fight club"),
    ("Who played the Bride in Kill Bill?", "uma thurman"),
    ("Which film features the character Hannibal Lecter?", "the silence of the lambs"),
    ("Who directed Vertigo?", "alfred hitchcock"),
    ("Which movie features the song 'Stayin' Alive'?", "saturday night fever"),
    ("Who starred as Vito Corleone in The Godfather?", "marlon brando"),
    ("Which film features the line 'Here's Johnny'?", "the shining"),
    ("Who directed La La Land?", "damien chazelle"),
    ("Which movie features the character Andy Sachs?", "the devil wears prada"),
    ("Who played the lead in The Revenant?", "leonardo dicaprio"),
    ("Which film features the character Ellen Ripley?", "alien"),
    ("Who directed Taxi Driver?", "martin scorsese"),
    ("Which movie features the song 'Hakuna Matata'?", "the lion king"),
    ("Who voiced Woody in Toy Story?", "tom hanks"),
    ("Which film features the character Michael Corleone?", "the godfather"),
    ("Who directed Goodfellas?", "martin scorsese"),
    ("Which movie features the line 'May the Force be with you'?", "star wars"),
    ("Who played the lead in The Silence of the Lambs?", "jodie foster"),
    ("Which film features the character John McClane?", "die hard"),
    ("Who directed The Social Network?", "david fincher"),
    ("Which movie features the song 'Circle of Life'?", "the lion king"),
    ("Who starred as Tony Montana in Scarface (1983)?", "al pacino"),
    ("Which film features the character Ferris Bueller?", "ferris bueller's day off"),
    ("Who directed The Grand Budapest Hotel?", "wes anderson"),
    ("Which movie features the character Jules Winnfield?", "pulp fiction"),
    ("Who played the lead in A Beautiful Mind?", "russell crowe"),
    ("Which film features the character Amelie Poulain?", "amelie"),
    ("Who directed The Departed?", "martin scorsese"),
    ("Which movie features the song 'As Time Goes By'?", "casablanca"),
    ("Who starred as The Joker in Joker (2019)?", "joaquin phoenix"),
    ("Which film features the character Rocky Balboa?", "rocky"),
    ("Who directed 2001: A Space Odyssey?", "stanley kubrick"),
    ("Which movie features the character Norman Bates?", "psycho"),
    ("Who starred as Holly in Breakfast at Tiffany's?", "audrey hepburn"),
    ("Which film features the character Maximus Decimus Meridius?", "gladiator"),
    ("Who directed The Lord of the Rings trilogy?", "peter jackson"),
    ("Which movie features the character Don Vito Corleone?", "the godfather"),
    ("Who starred as The Terminator in The Terminator?", "arnold schwarzenegger"),
    ("Which film features the character Captain John Miller?", "saving private ryan"),
    ("Who directed Chinatown?", "roman polanski"),
    ("Which movie features the character Travis Bickle?", "taxi driver"),
    ("Who starred as The Bride in Kill Bill Vol 1?", "uma thurman"),
    ("Which film features the character Patrick Bateman?", "american psycho"),
    ("Who directed The Wizard of Oz (1939)?", "victor fleming"),
    ("Which movie features the character Benjamin Button?", "the curious case of benjamin button"),
    ("Who starred as Clarice Starling in The Silence of the Lambs?", "jodie foster"),
    ("Which film features the character Captain Jack Sparrow?", "pirates of the caribbean"),
    ("Who directed The King's Speech?", "tom hooper"),
    ("Which movie features the character Andy Dufresne's friend Red?", "the shawshank redemption"),
    ("Who starred as Forrest Gump's love interest Jenny?", "robin wright"),
    ("Which film features the character Jules Winnfield's partner Vincent Vega?", "pulp fiction"),
    ("Who directed The Irishman?", "martin scorsese"),
    ("Which movie features the character Elle Woods?", "legally blonde"),
    ("Who starred as the lead in The Big Lebowski?", "jeff bridges"),
    ("Which film features the character Neo's mentor Morpheus?", "the matrix"),
    ("Who directed The Prestige?", "christopher nolan"),
    ("Which movie features the character Andy Dufresne's prison friend Red's parole?", "the shawshank redemption"),
    ("Who starred as the lead in The Wolf of Wall Street?", "leonardo dicaprio"),
    ("Which film features the character The Dude?", "the big lebowski"),
    ("Who directed Inception?", "christopher nolan"),
    ("Which movie features the character Captain Ahab?", "moby dick"),
    ("Who starred as the lead in The Aviator?", "leonardo dicaprio"),
    ("Which film features the character Elle Driver?", "kill bill"),
    ("Who directed Memento?", "christopher nolan"),
    ("Which movie features the character Norman Osborn (Green Goblin)?", "spider-man"),
    ("Who starred as the lead in The English Patient?", "ralph fiennes"),
    ("Which film features the character The Wicked Witch of the West?", "the wizard of oz"),
    ("Who directed The Hurt Locker?", "kathryn bigelow"),
    ("Which movie features the character Andy's poster of Raquel Welch?", "the shawshank redemption"),
    ("Who starred as the lead in The Sixth Sense?", "bruce willis"),
    ("Which film features the character The Bride's yellow jumpsuit homage?", "kill bill"),
    ("Who directed Fargo?", "joel coen"),
    ("Which movie features the character The Narrator in Fight Club?", "fight club"),
    ("Who starred as the lead in The Pianist?", "adrien brody"),
    ("Which film features the character The Wicked Witch's melting scene?", "the wizard of oz"),
    ("Who directed The Truman Show?", "peter weir"),
    ("Which movie features the character Thelma and Louise?", "thelma and louise"),
    ("Who starred as the lead in The Last Samurai?", "tom cruise"),
    ("Which film features the character The Bride's fight at the House of Blue Leaves?", "kill bill"),
    ("Who directed The Social Network?", "david fincher"),
    ("Which movie features the character The Godfather's opening wedding scene?", "the godfather"),
    ("Who starred as the lead in The English Patient?", "ralph fiennes"),
]

# --- Cross-platform TTS (uses system tools only) ---
def _speak_command_available():
    system = platform.system()
    if system == "Darwin":
        return shutil.which("say") is not None
    if system == "Windows":
        return True
    return shutil.which("spd-say") is not None or shutil.which("espeak") is not None

def speak(text):
    system = platform.system()
    try:
        if system == "Darwin":
            subprocess.Popen(["say", text])
            return True
        elif system == "Windows":
            safe = text.replace("'", "''")
            ps_cmd = (
                "Add-Type -AssemblyName System.speech;"
                f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                f"$s.Speak('{safe}');"
            )
            subprocess.Popen(["powershell", "-NoProfile", "-Command", ps_cmd], shell=False)
            return True
        else:
            if shutil.which("spd-say"):
                subprocess.Popen(["spd-say", text])
                return True
            if shutil.which("espeak"):
                subprocess.Popen(["espeak", text])
                return True
    except Exception:
        pass
    return False

def speak_async(text):
    threading.Thread(target=speak, args=(text,), daemon=True).start()

# --- Game logic with GUI ---
class TicTacTrivia:
    def __init__(self, root):
        self.root = root
        self.root.title("Tic Tac Toe + Hollywood Trivia (TTS Expanded)")
        self.canvas_size = 360
        self.cell_size = self.canvas_size // 3
        self.canvas = tk.Canvas(root, width=self.canvas_size, height=self.canvas_size, bg="white")
        self.canvas.pack(padx=10, pady=10)
        self.reset_button = tk.Button(root, text="New Game", command=self.new_game)
        self.reset_button.pack(pady=(0,10))
        self.status_label = tk.Label(root, text="Click a square to answer trivia and place X", font=("Arial", 10))
        self.status_label.pack()
        self.canvas.bind("<Button-1>", self.on_click)
        self.new_game()

    def new_game(self):
        self.board = [" "] * 9
        self.player_mark = "X"
        self.cpu_mark = "O"
        self.turn = "player"
        self.draw_board()
        self.status_label.config(text="Your turn: click a square to attempt a move")

    def draw_board(self):
        self.canvas.delete("all")
        for i in range(1, 3):
            x = i * self.cell_size
            self.canvas.create_line(x, 0, x, self.canvas_size, width=3)
            y = i * self.cell_size
            self.canvas.create_line(0, y, self.canvas_size, y, width=3)
        for idx, mark in enumerate(self.board):
            if mark != " ":
                row, col = divmod(idx, 3)
                cx = col * self.cell_size + self.cell_size // 2
                cy = row * self.cell_size + self.cell_size // 2
                if mark == "X":
                    offset = self.cell_size // 3
                    self.canvas.create_line(cx - offset, cy - offset, cx + offset, cy + offset, width=6, fill="blue")
                    self.canvas.create_line(cx - offset, cy + offset, cx + offset, cy - offset, width=6, fill="blue")
                else:
                    r = self.cell_size // 3
                    self.canvas.create_oval(cx - r, cy - r, cx + r, cy + r, width=6, outline="red")

    def on_click(self, event):
        if self.turn != "player":
            return
        col = event.x // self.cell_size
        row = event.y // self.cell_size
        if not (0 <= col < 3 and 0 <= row < 3):
            return
        idx = row * 3 + col
        if self.board[idx] != " ":
            self.status_label.config(text="Square already taken. Pick another.")
            return
        correct, correct_answer = self.ask_trivia_with_tts()
        if correct:
            self.board[idx] = self.player_mark
            self.draw_board()
            if self.check_win(self.player_mark):
                messagebox.showinfo("You win!", "Congratulations — you won!")
                self.status_label.config(text="You won! Click New Game to play again.")
                self.turn = None
                return
            if self.board_full():
                messagebox.showinfo("Tie", "It's a tie!")
                self.status_label.config(text="Tie game. Click New Game to play again.")
                self.turn = None
                return
            self.turn = "cpu"
            self.status_label.config(text="CPU's turn...")
            self.root.after(600, self.cpu_move_and_continue)
        else:
            messagebox.showinfo("Incorrect", f"Incorrect. The correct answer was:\n\n{correct_answer}")
            speak_async(f"The correct answer was {correct_answer}")
            if self.board_full():
                messagebox.showinfo("Tie", "It's a tie!")
                self.status_label.config(text="Tie game. Click New Game to play again.")
                self.turn = None
                return
            self.turn = "cpu"
            self.status_label.config(text="CPU takes a free move because you missed the trivia.")
            self.root.after(600, self.cpu_move_and_continue)

    def ask_trivia_with_tts(self):
        q, a = random.choice(TRIVIA)
        if _speak_command_available():
            speak_async(q)
        answer = simpledialog.askstring("Hollywood Trivia", q, parent=self.root)
        if answer is None:
            return False, a
        user = answer.strip().lower()
        correct = user == a.strip().lower()
        return correct, a

    def cpu_move_and_continue(self):
        if self.turn != "cpu":
            return
        move = self.cpu_move()
        if move is not None:
            self.draw_board()
            if self.check_win(self.cpu_mark):
                messagebox.showinfo("CPU wins", "CPU wins. Better luck next time!")
                self.status_label.config(text="CPU won. Click New Game to play again.")
                self.turn = None
                return
            if self.board_full():
                messagebox.showinfo("Tie", "It's a tie!")
                self.status_label.config(text="Tie game. Click New Game to play again.")
                self.turn = None
                return
        self.turn = "player"
        self.status_label.config(text="Your turn: click a square to attempt a move")

    def cpu_move(self):
        moves = [i for i, v in enumerate(self.board) if v == " "]
        if not moves:
            return None
        choice = random.choice(moves)
        self.board[choice] = self.cpu_mark
        return choice

    def check_win(self, mark):
        wins = [
            (0,1,2),(3,4,5),(6,7,8),
            (0,3,6),(1,4,7),(2,5,8),
            (0,4,8),(2,4,6)
        ]
        return any(self.board[a] == self.board[b] == self.board[c] == mark for (a,b,c) in wins)

    def board_full(self):
        return all(s != " " for s in self.board)

def main():
    root = tk.Tk()
    app = TicTacTrivia(root)
    root.mainloop()

if __name__ == "__main__":
    main()
