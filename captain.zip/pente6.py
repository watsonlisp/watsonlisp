#!/usr/bin/env python3
"""
Pente (Tkinter) — human vs computer, no external packages required.
Board size 13x13 by default. Win by 5 in a row or 5 capture pairs (10 stones).
Features:
- Strict sandwich capture rule: capture only when pattern color - opp - opp - color.
- Announce Trias/Tria and captures in the on-screen capture log (no TTS).
- Display pairs captured and stones captured.
- Capture log panel showing who captured which coordinates.
- No external packages required.
"""

import tkinter as tk
from tkinter import messagebox, scrolledtext
import random
from copy import deepcopy

# ----- Configuration -----
BOARD_SIZE = 13       # recommended 9-19
CELL_PIX = 40         # pixels between intersections
MARGIN = 30           # margin around board
STONE_RADIUS = 14
CAPTURE_TARGET = 5    # pairs to win

EMPTY = '.'
BLACK = 'X'   # human
WHITE = 'O'   # computer
DIRECTIONS = [(1,0),(0,1),(1,1),(1,-1)]

# ----- Board logic -----
class Board:
    def __init__(self, size=BOARD_SIZE):
        self.size = size
        self.grid = [[EMPTY]*size for _ in range(size)]
        # captures counts pairs (each capture removes two opponent stones)
        self.captures = {BLACK:0, WHITE:0}

    def in_bounds(self, r, c):
        return 0 <= r < self.size and 0 <= c < self.size

    def get(self, r, c):
        return self.grid[r][c]

    def set(self, r, c, val):
        self.grid[r][c] = val

    def place(self, r, c, color):
        """
        Place a stone and apply captures. Returns a dict with:
          'placed': (r,c),
          'pairs_captured': int,
          'removed_coords': [(r1,c1),(r2,c2),...]
        """
        if not self.in_bounds(r,c) or self.get(r,c) != EMPTY:
            return None
        self.set(r,c,color)
        removed = self._check_and_apply_captures(r,c,color)
        return {
            'placed': (r,c),
            'pairs_captured': len(removed)//2,
            'removed_coords': removed
        }

    def _check_and_apply_captures(self, r, c, color):
        """
        Apply captures only when two opponent stones are sandwiched between
        two of the player's stones (pattern: color - opp - opp - color).
        Checks both orientations relative to the placed stone and returns
        a list of removed coordinates (may be empty).
        """
        opp = BLACK if color == WHITE else WHITE
        removed = []
        # check each direction (and its opposite)
        for dr, dc in DIRECTIONS + [(-d[0], -d[1]) for d in DIRECTIONS]:
            # mid positions (opponent stones) relative to placed stone
            r_mid1, c_mid1 = r + dr, c + dc
            r_mid2, c_mid2 = r + 2*dr, c + 2*dc

            # orientation A: other captor is before the placed stone (r-dr)
            r_before, c_before = r - dr, c - dc
            if (self.in_bounds(r_before, c_before)
                and self.in_bounds(r_mid1, c_mid1)
                and self.in_bounds(r_mid2, c_mid2)):
                if (self.get(r_before, c_before) == color
                    and self.get(r_mid1, c_mid1) == opp
                    and self.get(r_mid2, c_mid2) == opp):
                    # remove them if still present
                    if self.get(r_mid1, c_mid1) == opp and self.get(r_mid2, c_mid2) == opp:
                        self.set(r_mid1, c_mid1, EMPTY)
                        self.set(r_mid2, c_mid2, EMPTY)
                        self.captures[color] += 1
                        removed.extend([(r_mid1, c_mid1), (r_mid2, c_mid2)])

            # orientation B: other captor is after the two opponent stones (r+3dr)
            r_after, c_after = r + 3*dr, c + 3*dc
            if (self.in_bounds(r_after, c_after)
                and self.in_bounds(r_mid1, c_mid1)
                and self.in_bounds(r_mid2, c_mid2)):
                if (self.get(r_after, c_after) == color
                    and self.get(r_mid1, c_mid1) == opp
                    and self.get(r_mid2, c_mid2) == opp):
                    # remove them if still present
                    if self.get(r_mid1, c_mid1) == opp and self.get(r_mid2, c_mid2) == opp:
                        self.set(r_mid1, c_mid1, EMPTY)
                        self.set(r_mid2, c_mid2, EMPTY)
                        self.captures[color] += 1
                        removed.extend([(r_mid1, c_mid1), (r_mid2, c_mid2)])
        return removed

    def count_in_direction(self, r, c, dr, dc, color):
        cnt = 0
        rr, cc = r+dr, c+dc
        while self.in_bounds(rr,cc) and self.get(rr,cc) == color:
            cnt += 1
            rr += dr; cc += dc
        return cnt

    def is_five_in_row(self, r, c, color):
        for dr,dc in DIRECTIONS:
            total = 1 + self.count_in_direction(r,c,dr,dc,color) + self.count_in_direction(r,c,-dr,-dc,color)
            if total >= 5:
                return True
        return False

    def check_win(self, last_r, last_c, color):
        # win by captures (pairs)
        if self.captures[color] >= CAPTURE_TARGET:
            return True, f"{color} wins by captures ({self.captures[color]} pairs)"
        # win by five in a row
        if self.is_five_in_row(last_r, last_c, color):
            return True, f"{color} wins by five in a row"
        return False, None

    def legal_moves(self):
        return [(r,c) for r in range(self.size) for c in range(self.size) if self.get(r,c) == EMPTY]

    def copy(self):
        b = Board(self.size)
        b.grid = [row[:] for row in self.grid]
        b.captures = dict(self.captures)
        return b

# ----- AI helpers -----
def opponent(color):
    return BLACK if color == WHITE else WHITE

def find_immediate_win(board, color):
    for r,c in board.legal_moves():
        b2 = board.copy()
        b2.place(r,c,color)
        win, _ = b2.check_win(r,c,color)
        if win:
            return (r,c)
    return None

def find_capture_moves(board, color):
    moves = []
    opp = opponent(color)
    for r,c in board.legal_moves():
        for dr,dc in DIRECTIONS + [(-d[0],-d[1]) for d in DIRECTIONS]:
            r0, c0 = r-dr, c-dc
            r1, c1 = r+dr, c+dc
            r2, c2 = r+2*dr, c+2*dc
            if board.in_bounds(r0,c0) and board.in_bounds(r1,c1) and board.in_bounds(r2,c2):
                if board.get(r0,c0) == color and board.get(r1,c1) == opp and board.get(r2,c2) == opp:
                    moves.append((r,c))
    return list(set(moves))

def find_tria_block_moves(board, color):
    """
    Return a list of moves that block opponent 3-in-a-row patterns.
    Prefers blocking 'open' (Trias) first, then 'semi' (Tria).
    Each returned move is a (r,c) coordinate that fills an empty end of the 3-run.
    """
    opp = opponent(color)
    patterns = detect_three_patterns(board)
    open_blocks = []
    semi_blocks = []
    for p in patterns:
        p_color, r, c, dr, dc, kind = p
        if p_color != opp:
            continue
        before_r, before_c = r - dr, c - dc
        after_r, after_c = r + 3*dr, c + 3*dc
        # candidate: fill the empty cell before the run
        if board.in_bounds(before_r, before_c) and board.get(before_r, before_c) == EMPTY:
            if kind == 'open':
                open_blocks.append((before_r, before_c))
            else:
                semi_blocks.append((before_r, before_c))
        # candidate: fill the empty cell after the run
        if board.in_bounds(after_r, after_c) and board.get(after_r, after_c) == EMPTY:
            if kind == 'open':
                open_blocks.append((after_r, after_c))
            else:
                semi_blocks.append((after_r, after_c))
    # prefer open-blocks; deduplicate while preserving order
    if open_blocks:
        return list(dict.fromkeys(open_blocks))
    return list(dict.fromkeys(semi_blocks))

def score_move(board, r, c, color):
    s = 0
    for dr,dc in DIRECTIONS:
        s += board.count_in_direction(r,c,dr,dc,color)
        s += board.count_in_direction(r,c,-dr,-dc,color)
    opp = opponent(color)
    for dr,dc in DIRECTIONS:
        opp_count = board.count_in_direction(r,c,dr,dc,opp) + board.count_in_direction(r,c,-dr,-dc,opp)
        if opp_count >= 3:
            s += 2
    s += random.random()*0.1
    return s

def ai_choose_move(board, color):
    # 1) immediate win
    win_move = find_immediate_win(board, color)
    if win_move:
        return win_move
    # 2) block opponent immediate win
    block = find_immediate_win(board, opponent(color))
    if block:
        return block
    # 3) block opponent Tria/Trias (open Trias first, then semi Tria)
    tria_blocks = find_tria_block_moves(board, color)
    if tria_blocks:
        # prefer blocks that don't immediately give opponent a capture
        safe_blocks = []
        for r,c in tria_blocks:
            b2 = board.copy()
            b2.place(r,c,color)
            if not find_capture_moves(b2, opponent(color)):
                safe_blocks.append((r,c))
        if safe_blocks:
            # choose highest-scoring safe block if multiple
            best = max(safe_blocks, key=lambda rc: score_move(board, rc[0], rc[1], color))
            return best
        # if none are safe, pick any tria block (deduped list)
        return random.choice(tria_blocks)
    # 4) capture moves
    caps = find_capture_moves(board, color)
    if caps:
        return random.choice(caps)
    # 5) avoid moves that allow opponent immediate capture
    candidates = board.legal_moves()
    safe = []
    for r,c in candidates:
        b2 = board.copy()
        b2.place(r,c,color)
        opp_caps = find_capture_moves(b2, opponent(color))
        if not opp_caps:
            safe.append((r,c))
    if not safe:
        safe = candidates
    scored = [(score_move(board,r,c,color),(r,c)) for (r,c) in safe]
    scored.sort(reverse=True)
    best_score = scored[0][0]
    best_moves = [m for s,m in scored if abs(s-best_score) < 1e-6]
    return random.choice(best_moves)

# ----- Pattern detection for 3-in-a-row (open / semi-open) -----
def detect_three_patterns(board):
    """
    Return a set of tuples describing 3-in-a-row patterns:
    (color, start_r, start_c, dr, dc, kind) where kind is 'open' or 'semi'
    start is the first cell of the 3-run in the (dr,dc) direction.
    """
    patterns = set()
    size = board.size
    for r in range(size):
        for c in range(size):
            for dr,dc in DIRECTIONS:
                # ensure this is the start of a run (previous cell not same color)
                prev_r, prev_c = r-dr, c-dc
                if board.in_bounds(prev_r, prev_c) and board.get(prev_r, prev_c) != EMPTY:
                    continue
                # check three cells r..r+2*dr
                cells = []
                ok = True
                for k in range(3):
                    rr = r + k*dr
                    cc = c + k*dc
                    if not board.in_bounds(rr,cc):
                        ok = False; break
                    cells.append((rr,cc))
                if not ok:
                    continue
                colors = [board.get(rr,cc) for rr,cc in cells]
                if colors[0] == EMPTY or colors[1] != colors[0] or colors[2] != colors[0]:
                    continue
                color = colors[0]
                before_r, before_c = r-dr, c-dc
                after_r, after_c = r+3*dr, c+3*dc
                before_empty = (board.in_bounds(before_r,before_c) and board.get(before_r,before_c) == EMPTY)
                after_empty = (board.in_bounds(after_r,after_c) and board.get(after_r,after_c) == EMPTY)
                empties = (1 if before_empty else 0) + (1 if after_empty else 0)
                if empties == 2:
                    kind = 'open'   # Trias
                elif empties >= 1:
                    kind = 'semi'   # Tria
                else:
                    continue
                patterns.add((color, r, c, dr, dc, kind))
    return patterns

# ----- Tkinter GUI with capture log (no TTS) -----
class PenteGUI:
    def __init__(self, root, size=BOARD_SIZE):
        self.root = root
        self.size = size
        self.cell = CELL_PIX
        self.margin = MARGIN
        self.width = self.margin*2 + self.cell*(size-1)
        self.height = self.margin*2 + self.cell*(size-1) + 140
        self.canvas = tk.Canvas(root, width=self.width, height=self.height-100, bg="#2b2b2b")
        self.canvas.pack(side="left")
        # right panel for controls and log
        right = tk.Frame(root, bg="#222222", width=300)
        right.pack(side="right", fill="y")
        self.log_label = tk.Label(right, text="Capture Log", bg="#222222", fg="#e6e6e6")
        self.log_label.pack(pady=(8,0))
        self.log = scrolledtext.ScrolledText(right, width=36, height=12, state="disabled", bg="#1e1e1e", fg="#e6e6e6")
        self.log.pack(padx=6, pady=6)
        btn_frame = tk.Frame(right, bg="#222222")
        btn_frame.pack(fill="x", padx=6, pady=(0,6))
        tk.Button(btn_frame, text="Tria", command=lambda: self.log_message("Tria")).pack(side="left", padx=4)
        tk.Button(btn_frame, text="Trias", command=lambda: self.log_message("Trias")).pack(side="left", padx=4)
        tk.Button(btn_frame, text="Pente", command=lambda: self.log_message("Pente")).pack(side="left", padx=4)
        tk.Button(btn_frame, text="Restart", command=self.restart).pack(side="right", padx=4)

        self.board = Board(size)
        self.current = BLACK  # black moves first
        self.human_color = BLACK
        self.last_move = None
        self.game_over = False
        self.known_patterns = detect_three_patterns(self.board)

        self.draw_board()
        self.canvas.bind("<Button-1>", self.on_click)
        root.bind("r", lambda e: self.restart())
        root.bind("R", lambda e: self.restart())
        root.bind("q", lambda e: root.quit())
        root.bind("Q", lambda e: root.quit())

        # Log on startup
        self.log_message("Pente ready. Click to place your stone.")

    def log_message(self, text):
        """Append a short message to the capture log (no TTS)."""
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def draw_board(self):
        self.canvas.delete("all")
        left = self.margin
        top = self.margin
        # grid lines
        for i in range(self.size):
            x0 = left
            y = top + i*self.cell
            x1 = left + (self.size-1)*self.cell
            self.canvas.create_line(x0, y, x1, y, fill="#cfcfcf", width=2)
            x = left + i*self.cell
            y0 = top
            y1 = top + (self.size-1)*self.cell
            self.canvas.create_line(x, y0, x, y1, fill="#cfcfcf", width=2)
        # stones
        for r in range(self.size):
            for c in range(self.size):
                val = self.board.get(r,c)
                if val != EMPTY:
                    cx = left + c*self.cell
                    cy = top + r*self.cell
                    if val == BLACK:
                        self.canvas.create_oval(cx-STONE_RADIUS, cy-STONE_RADIUS, cx+STONE_RADIUS, cy+STONE_RADIUS, fill="#111111", outline="#666666")
                    else:
                        self.canvas.create_oval(cx-STONE_RADIUS, cy-STONE_RADIUS, cx+STONE_RADIUS, cy+STONE_RADIUS, fill="#f5f5f5", outline="#999999")
        # last move highlight
        if self.last_move:
            lx = left + self.last_move[1]*self.cell
            ly = top + self.last_move[0]*self.cell
            self.canvas.create_oval(lx-6, ly-6, lx+6, ly+6, fill="#d4b04b", outline="")
        # capture counters and instructions (show pairs and stones)
        pairs_black = self.board.captures[BLACK]
        pairs_white = self.board.captures[WHITE]
        stones_black = pairs_black * 2
        stones_white = pairs_white * 2
        cap_text = (f"Pairs captured: Black {pairs_black}  White {pairs_white}\n"
                    f"Stones captured: Black {stones_black}  White {stones_white}")
        self.canvas.create_text(10, 10, anchor="nw", text=cap_text, fill="#e6e6e6", font=("Arial", 12))
        instr = "Click to place. R restart. Q quit."
        self.canvas.create_text(10, 50, anchor="nw", text=instr, fill="#e6e6e6", font=("Arial", 10))

    def coord_to_cell(self, x, y):
        left = self.margin
        top = self.margin
        relx = x - left
        rely = y - top
        c = int(round(relx / self.cell))
        r = int(round(rely / self.cell))
        if 0 <= r < self.size and 0 <= c < self.size:
            ix = left + c*self.cell
            iy = top + r*self.cell
            if abs(ix - x) <= self.cell/2 and abs(iy - y) <= self.cell/2:
                return r, c
        return None

    def log_capture(self, who, removed_coords):
        if not removed_coords:
            return
        self.log.configure(state="normal")
        for i in range(0, len(removed_coords), 2):
            a = removed_coords[i]
            b = removed_coords[i+1] if i+1 < len(removed_coords) else None
            if b:
                line = f"{who} captured pair at {a} and {b}\n"
            else:
                line = f"{who} captured stone at {a}\n"
            self.log.insert("end", line)
        self.log.see("end")
        self.log.configure(state="disabled")

    def on_click(self, event):
        if self.game_over:
            return
        cell = self.coord_to_cell(event.x, event.y)
        if cell and self.current == self.human_color:
            r,c = cell
            if self.board.get(r,c) != EMPTY:
                self.log_message("That spot is already occupied.")
                return
            before_patterns = detect_three_patterns(self.board)
            result = self.board.place(r,c,self.current)
            if result is None:
                return
            self.last_move = (r,c)
            self.draw_board()
            self.log_message(f"You placed at row {r} column {c}")
            # announce captures and log
            if result['removed_coords']:
                self.log_capture("You", result['removed_coords'])
                self.log_message(f"You captured {result['pairs_captured']} pair{'s' if result['pairs_captured']>1 else ''}")
            # announce new patterns
            self._announce_new_patterns(before_patterns, self.current)
            win, msg = self.board.check_win(r,c,self.current)
            if win:
                self.game_over = True
                self.log_message("Pente")
                self.show_win(msg)
                return
            self.current = opponent(self.current)
            self.root.after(150, self.ai_move)

    def ai_move(self):
        if self.game_over or self.current == self.human_color:
            return
        before_patterns = detect_three_patterns(self.board)
        r,c = ai_choose_move(self.board, self.current)
        result = self.board.place(r,c,self.current)
        if result is None:
            return
        self.last_move = (r,c)
        self.draw_board()
        self.log_message(f"Computer placed at row {r} column {c}")
        if result['removed_coords']:
            self.log_capture("Computer", result['removed_coords'])
            self.log_message(f"Computer captured {result['pairs_captured']} pair{'s' if result['pairs_captured']>1 else ''}")
        self._announce_new_patterns(before_patterns, self.current)
        win, msg = self.board.check_win(r,c,self.current)
        if win:
            self.game_over = True
            self.log_message("Pente")
            self.show_win(msg)
            return
        self.current = opponent(self.current)

    def _announce_new_patterns(self, before_patterns, color_just_played):
        after_patterns = detect_three_patterns(self.board)
        new = [p for p in after_patterns - before_patterns if p[0] == color_just_played]
        announced_open = False
        announced_semi = False
        for p in new:
            _, r, c, dr, dc, kind = p
            who = "You" if color_just_played == self.human_color else "Computer"
            if kind == 'open' and not announced_open:
                self.log_message(f"Trias for {who}")
                announced_open = True
            elif kind == 'semi' and not announced_semi:
                self.log_message(f"Tria for {who}")
                announced_semi = True
        self.known_patterns = after_patterns

    def show_win(self, msg):
        msg_readable = msg.replace(BLACK, "Black").replace(WHITE, "White")
        self.log_message(f"Game over. {msg_readable}")
        messagebox.showinfo("Game Over", msg_readable + "\nPress Restart to play again.")

    def restart(self):
        self.board = Board(self.size)
        self.current = BLACK
        self.last_move = None
        self.game_over = False
        self.known_patterns = detect_three_patterns(self.board)
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        self.draw_board()
        self.log_message("New game started. You are black. Click to place your stone.")

def main():
    root = tk.Tk()
    root.title("Pente (No TTS) - Trias/Tria, Strict Captures, and Log")
    app = PenteGUI(root, size=BOARD_SIZE)
    root.mainloop()

if __name__ == "__main__":
    main()
