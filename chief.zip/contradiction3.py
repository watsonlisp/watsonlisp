#!/usr/bin/env python3
"""
Contradiction Quote Generator with simple cross-platform TTS (no pip required).
TTS is ON by default. Use --no-tts to disable.
Run: python contradiction_generator.py
"""

import random
import argparse
import subprocess
import sys
import shutil
from datetime import datetime

# -------------------------
# Data
# -------------------------
CONTRAST_PAIRS = [
    ("love", "hate"),
    ("always", "never"),
    ("yes", "no"),
    ("true", "false"),
    ("right", "wrong"),
    ("in", "out"),
    ("here", "gone"),
    ("happy", "sad"),
    ("begin", "end"),
    ("possible", "impossible"),
    ("light", "dark"),
    ("loud", "quiet"),
    ("fast", "slow"),
    ("open", "closed"),
    ("near", "far"),
    ("young", "old"),
    ("bold", "timid"),
    ("clean", "dirty"),
    ("free", "bound"),
    ("safe", "dangerous"),
]

TEMPLATES = [
    # Short punchy
    "{A}. {B}.",
    "{A} — {B}.",
    "{A}, not {B}.",
    "{A} and {B}.",
    "{A}? {B}.",
    "{A} or {B}.",
    "{A} / {B}.",
    "{A} — or maybe {B}.",
    "{A}, then {B}.",
    "{A} but {B}.",

    # Rhetorical and ironic
    "Who says {A} when {B} is true?",
    "I promised {A}, I delivered {B}.",
    "They wanted {A}; I chose {B}.",
    "If {A} is right, why {B}?",
    "You call that {A}? I call it {B}.",
    "Everyone expects {A}; I expect {B}.",
    "I preach {A} and practice {B}.",
    "I said {A} to be polite; I meant {B} to be honest.",
    "I aim for {A} and land on {B}.",
    "I warned them about {A} and then did {B}.",

    # Confessional and personal
    "Sometimes I {A}, sometimes I {B}.",
    "I used to {A}, now I {B}.",
    "I want to {A} but I {B}.",
    "I told myself {A} and then {B} happened.",
    "I believe in {A} and yet I do {B}.",
    "I say {A} to others and {B} to myself.",
    "I tried to be {A} and ended up {B}.",
    "I choose {A} when I'm brave, {B} when I'm scared.",
    "I wear {A} on the outside and {B} inside.",
    "I promised {A} and broke it with {B}.",

    # Playful and absurd
    "I love {A}, especially when it's {B}.",
    "I collect {A} and throw away {B}.",
    "I ordered {A} but the kitchen sent {B}.",
    "I practice {A} for fun, {B} for sport.",
    "I hug {A} and high-five {B}.",
    "I whisper {A} and shout {B}.",
    "I dance like {A} and sit like {B}.",
    "I wear {A} to bed and {B} to work.",
    "I plant {A} and harvest {B}.",
    "I read {A} and forget {B}.",

    # Philosophical and paradoxical
    "To be {A} is to be {B}.",
    "If {A} exists, then {B} must follow.",
    "The more {A}, the less {B}.",
    "I seek {A} and find {B} instead.",
    "Truth says {A}; life says {B}.",
    "I chase {A} and catch {B}.",
    "Believing {A} means denying {B}.",
    "I measure {A} by {B}.",
    "What is {A} if not {B}?",
    "I define {A} through {B}.",

    # Conversational and dialogic
    "You say {A}; I say {B}.",
    "They told me {A}, so I did {B}.",
    "She wanted {A}, he wanted {B}.",
    "I asked for {A} and got {B}.",
    "You promised {A} and delivered {B}.",
    "I told them {A} but they heard {B}.",
    "We agreed on {A} and argued about {B}.",
    "He called it {A}; I called it {B}.",
    "They expected {A}, we gave {B}.",
    "I asked for {A}, accepted {B}.",

    # Imperative and directive
    "Be {A}, not {B}.",
    "Choose {A} or choose {B}.",
    "Never {A}; always {B}.",
    "Try {A}, then try {B}.",
    "Stop {A} and start {B}.",
    "Keep {A} but avoid {B}.",
    "Practice {A} until {B} happens.",
    "Say {A}, mean {B}.",
    "Act {A}, think {B}.",
    "Demand {A}, tolerate {B}.",

    # Poetic and lyrical
    "I am {A} in the morning, {B} by night.",
    "Between {A} and {B} I walk.",
    "My heart says {A}, my hands do {B}.",
    "I sing {A} and hum {B}.",
    "The sky is {A}, the ground is {B}.",
    "I dream of {A} and wake to {B}.",
    "I carry {A} like a stone, {B} like a feather.",
    "I taste {A} and swallow {B}.",
    "I plant {A} in winter, harvest {B} in spring.",
    "I write {A} and erase {B}.",

    # Witty and sarcastic
    "Of course I {A}; who wouldn't {B}?",
    "I said {A} ironically and meant {B} literally.",
    "I promised {A} with a straight face and did {B} with a grin.",
    "I support {A} when it's convenient, {B} when it's not.",
    "I champion {A} until {B} shows up.",
    "I voted for {A} in my head and {B} with my feet.",
    "I applaud {A} and boo {B} at the same time.",
    "I endorse {A} for the novelty, {B} for the drama.",
    "I prefer {A} in theory and {B} in practice.",
    "I admire {A} from afar and {B} up close.",

    # Conditional and cause effect
    "If {A}, then {B}.",
    "When {A} happens, {B} follows.",
    "Because I {A}, I {B}.",
    "Only if {A} will I {B}.",
    "Unless {A}, I will {B}.",
    "Given {A}, expect {B}.",
    "Should {A} occur, I choose {B}.",
    "If not {A}, then certainly {B}.",
    "When I {A}, I never {B}.",
    "If you {A}, I will {B}.",

    # Meta and self-referential
    "This sentence is {A} and {B}.",
    "I wrote {A} to say {B}.",
    "The contradiction is {A} because it's {B}.",
    "I promised to avoid {A} and then wrote {B}.",
    "This program prints {A} and {B}.",
    "I named it {A} but called it {B}.",
    "I claim {A} while demonstrating {B}.",
    "I debug {A} by introducing {B}.",
    "I designed {A} to produce {B}.",
    "I said {A} to generate {B}.",

    # Extra variations for rhythm and structure
    "{A} — then {B}, always.",
    "Not {A}, but {B} instead.",
    "I meant {A}, I did {B}.",
    "First {A}, then {B}.",
    "I choose {A}; fate chooses {B}.",
    "I preach {A}, practice {B}, and call it balance.",
    "I promised {A} and kept {B}.",
    "I wanted {A} more than {B}.",
    "I said {A} out loud and {B} in my head.",
    "I am {A}, I remain {B}.",
]

# -------------------------
# Utilities
# -------------------------
def pick_contrast():
    a, b = random.choice(CONTRAST_PAIRS)
    return (a, b) if random.choice([True, False]) else (b, a)

def generate_contradiction():
    template = random.choice(TEMPLATES)
    A_word, B_word = pick_contrast()
    A_phrase = random.choice([
        A_word,
        f"be {A_word}",
        f"{A_word} it",
        f"say {A_word}",
        f"feel {A_word}",
        f"have {A_word}",
        f"love {A_word}",
        f"hate {A_word}",
    ])
    B_phrase = random.choice([
        B_word,
        f"be {B_word}",
        f"{B_word} it",
        f"say {B_word}",
        f"feel {B_word}",
        f"have {B_word}",
        f"love {B_word}",
        f"hate {B_word}",
    ])
    return template.format(A=A_phrase, B=B_phrase)

def generate_many(n=10):
    return [generate_contradiction() for _ in range(n)]

# -------------------------
# Simple cross-platform TTS (no pip)
# -------------------------
def _run_subprocess(cmd):
    try:
        subprocess.run(cmd, shell=False, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False

def speak_via_powershell(text):
    # Use System.Speech.Synthesis on Windows via PowerShell
    # Build a PowerShell command that speaks the text.
    # Keep the command short to avoid quoting issues.
    ps_cmd = [
        "powershell",
        "-NoProfile",
        "-Command",
        (
            "Add-Type -AssemblyName System.Speech;"
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            f"$s.Speak([Console]::In.ReadToEnd());"
        ),
    ]
    try:
        # Feed text via stdin to avoid quoting problems
        p = subprocess.Popen(ps_cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        p.communicate(input=text.encode("utf-8"))
        return p.returncode == 0
    except Exception:
        return False

def speak(text, tts_enabled=True):
    if not tts_enabled:
        return False

    platform = sys.platform
    # macOS: 'say'
    if platform == "darwin":
        if shutil.which("say"):
            return _run_subprocess(["say", text])
    # Windows: try PowerShell System.Speech
    if platform.startswith("win"):
        return speak_via_powershell(text)
    # Linux / other Unix: try espeak, then spd-say
    if shutil.which("espeak"):
        return _run_subprocess(["espeak", text])
    if shutil.which("spd-say"):
        return _run_subprocess(["spd-say", text])
    # If nothing available, try a fallback: print a hint
    return False

# -------------------------
# Interactive loop
# -------------------------
def interactive_loop(batch_size=10, tts_enabled=True, seed=None, save_path=None):
    if seed is not None:
        random.seed(seed)

    try:
        while True:
            quotes = generate_many(batch_size)
            header = f"Contradiction Quotes — {datetime.now().isoformat(timespec='seconds')}"
            print("\n" + header)
            print("-" * len(header))
            for q in quotes:
                print(q)
            # Speak the batch (concatenate into a short paragraph)
            spoken = "  ".join(quotes)
            tts_ok = speak(spoken, tts_enabled=tts_enabled)
            if not tts_ok and tts_enabled:
                print("\n[TTS requested but no supported TTS engine found on this system. Use --no-tts to disable.]")
            # Optionally save last batch
            if save_path:
                try:
                    with open(save_path, "a", encoding="utf-8") as f:
                        f.write(header + "\n")
                        for q in quotes:
                            f.write(q + "\n")
                        f.write("\n")
                except Exception as e:
                    print(f"[Warning] Could not write to {save_path}: {e}")
            # Prompt user
            user = input("\nPress Enter to generate more, or type 'q' then Enter to quit: ").strip().lower()
            if user == "q":
                print("Goodbye.")
                break
    except KeyboardInterrupt:
        print("\nInterrupted. Goodbye.")

# -------------------------
# CLI
# -------------------------
def main():
    parser = argparse.ArgumentParser(description="Contradiction Quote Generator (interactive, TTS on by default)")
    parser.add_argument("-n", "--number", type=int, default=10, help="Number of quotes per batch")
    parser.add_argument("-s", "--seed", type=int, default=None, help="Random seed for reproducibility")
    parser.add_argument("-o", "--output", type=str, default=None, help="Append each batch to this file")
    parser.add_argument("--no-tts", action="store_true", help="Disable text-to-speech")
    parser.add_argument("-c", "--count-templates", action="store_true", help="Show how many templates are available and exit")
    args = parser.parse_args()

    if args.count_templates:
        print(f"Templates available: {len(TEMPLATES)}")
        return

    interactive_loop(batch_size=args.number, tts_enabled=not args.no_tts, seed=args.seed, save_path=args.output)

if __name__ == "__main__":
    main()
