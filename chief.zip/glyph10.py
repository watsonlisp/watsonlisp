#!/usr/bin/env python3
"""
egyptian_tk.py
Render words as Egyptian-style glyphs using only the Python standard library (tkinter).
Run: python egyptian_tk.py
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import hashlib
import math

# ---------- Deterministic mapping helpers ----------
def char_seed(ch: str) -> int:
    h = hashlib.sha1(ch.encode("utf-8")).hexdigest()
    return int(h[:8], 16)

def pick_motif_index(ch: str, n=4) -> int:
    return char_seed(ch) % n

# ---------- Drawing helpers ----------
def translate(points, tx, ty):
    return [(x + tx, y + ty) for (x, y) in points]

def scale_points(points, s):
    return [(x * s, y * s) for (x, y) in points]

# ---------- Motif draw functions (centered at 0,0, size ~1 unit) ----------
def draw_ankh(canvas, cx, cy, size, fill="#d4af37", outline="black"):
    # loop (oval)
    w = 0.6 * size
    h = 0.9 * size
    canvas.create_oval(cx - w/2, cy - h/2, cx + w/2, cy + h/2, fill=fill, outline=outline, width=1.5)
    # stem
    sw = 0.18 * size
    sh = 1.0 * size
    sx0 = cx - sw/2
    canvas.create_rectangle(sx0, cy + h/2 - 0.05*size, sx0 + sw, cy + h/2 + sh - 0.05*size, fill=fill, outline=outline, width=1.5)
    # crossbar
    cross_w = 0.8 * size
    cross_h = 0.12 * size
    canvas.create_rectangle(cx - cross_w/2, cy + h/2 + 0.18*size, cx + cross_w/2, cy + h/2 + 0.18*size + cross_h, fill=fill, outline=outline, width=1.5)

def draw_eye(canvas, cx, cy, size, fill="#ffffff", outline="black"):
    # almond outer shape approximated by polygon with many points (smooth enough)
    w = 1.0 * size
    h = 0.45 * size
    pts = []
    steps = 40
    for t in range(steps + 1):
        theta = math.pi * (t / steps)  # top arc
        x = cx - w/2 * math.cos(theta)
        y = cy + h/2 * math.sin(theta)
        pts.append((x, y))
    for t in range(steps + 1):
        theta = math.pi * (t / steps)  # bottom arc reversed
        x = cx + w/2 * math.cos(theta)
        y = cy - h/2 * math.sin(theta)
        pts.append((x, y))
    flat = [coord for p in pts for coord in p]
    canvas.create_polygon(flat, fill=fill, outline=outline, width=1.2, smooth=True)
    # pupil
    pr = 0.18 * size
    canvas.create_oval(cx - pr, cy - pr, cx + pr, cy + pr, fill="#222222", outline=outline, width=1.0)

def draw_scarab(canvas, cx, cy, size, fill="#8fbf3f", outline="black"):
    # body oval
    w = 0.7 * size
    h = 0.9 * size
    canvas.create_oval(cx - w/2, cy - h/2, cx + w/2, cy + h/2, fill=fill, outline=outline, width=1.2)
    # head circle
    hr = 0.18 * size
    canvas.create_oval(cx - hr, cy - h/2 - hr*0.6, cx + hr, cy - h/2 + hr*0.6, fill=fill, outline=outline, width=1.0)
    # center line (elytra)
    canvas.create_line(cx, cy - h/2, cx, cy + h/2, fill=outline, width=1.0)
    # simple legs
    for dx in (-0.45*size, 0.45*size):
        for i in range(3):
            y0 = cy - 0.25*size + i * 0.25*size
            x0 = cx + dx
            x1 = x0 + (0.12*size if dx < 0 else -0.12*size)
            y1 = y0 + 0.18*size
            canvas.create_line(x0, y0, x1, y1, fill=outline, width=1.0)

def draw_cartouche(canvas, cx, cy, size, fill="#f0e68c", outline="black"):
    # rounded capsule: draw rectangle + semicircles
    w = 1.2 * size
    h = 0.6 * size
    r = h/2
    # rectangle center
    canvas.create_rectangle(cx - (w/2 - r), cy - h/2, cx + (w/2 - r), cy + h/2, fill=fill, outline=outline, width=1.2)
    # left semicircle
    canvas.create_oval(cx - w/2, cy - r, cx - w/2 + 2*r, cy + r, fill=fill, outline=outline, width=1.2)
    # right semicircle
    canvas.create_oval(cx + w/2 - 2*r, cy - r, cx + w/2, cy + r, fill=fill, outline=outline, width=1.2)

# ---------- Main GUI app ----------
class EgyptianApp:
    def __init__(self, root):
        self.root = root
        root.title("Egyptian Glyphs (tkinter only)")
        self.top = ttk.Frame(root, padding=6)
        self.top.pack(side="top", fill="x")
        ttk.Label(self.top, text="Word:").pack(side="left")
        self.entry = ttk.Entry(self.top, width=30)
        self.entry.pack(side="left", padx=6)
        self.entry.insert(0, "PYRAMID")
        ttk.Button(self.top, text="Render", command=self.render).pack(side="left", padx=4)
        ttk.Button(self.top, text="Save PostScript", command=self.save_ps).pack(side="left", padx=4)
        ttk.Button(self.top, text="Clear", command=self.clear).pack(side="left", padx=4)

        # Canvas
        self.canvas_w = 1000
        self.canvas_h = 320

        # Wrap canvas in a frame and add horizontal scrollbar (left/right scrolling)
        self.canvas_frame = ttk.Frame(root)
        self.canvas_frame.pack(side="top", fill="both", expand=True, padx=6, pady=6)

        self.canvas = tk.Canvas(self.canvas_frame, width=self.canvas_w, height=self.canvas_h, bg="white")
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.canvas_frame.rowconfigure(0, weight=1)
        self.canvas_frame.columnconfigure(0, weight=1)

        # horizontal scrollbar
        self.h_scroll = ttk.Scrollbar(self.canvas_frame, orient="horizontal", command=self.canvas.xview)
        self.h_scroll.grid(row=1, column=0, sticky="ew")
        self.canvas.configure(xscrollcommand=self.h_scroll.set)

        # initial render
        self.render()

        # Bind panning and shift-wheel horizontal scroll
        self.canvas.bind("<ButtonPress-1>", self._pan_start)
        self.canvas.bind("<B1-Motion>", self._pan_move)
        self.canvas.bind("<ButtonRelease-1>", self._pan_end)
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel, add="+")
        self.canvas.bind_all("<Button-4>", self._on_button4, add="+")
        self.canvas.bind_all("<Button-5>", self._on_button5, add="+")

    def clear(self):
        self.canvas.delete("all")

    # panning helpers
    def _pan_start(self, event):
        try:
            self.canvas.scan_mark(event.x, event.y)
            self._pan_active = True
        except Exception:
            self._pan_active = False

    def _pan_move(self, event):
        if getattr(self, "_pan_active", False):
            try:
                self.canvas.scan_dragto(event.x, event.y, gain=1)
            except Exception:
                pass

    def _pan_end(self, event):
        self._pan_active = False

    def _on_mousewheel(self, event):
        # Shift + wheel -> horizontal scroll
        shift = (event.state & 0x0001) != 0
        if shift:
            # event.delta is multiple of 120 on Windows/macOS
            units = -int(event.delta / 120)
            self.canvas.xview_scroll(units, "units")

    def _on_button4(self, event):
        shift = (event.state & 0x0001) != 0
        if shift:
            self.canvas.xview_scroll(-1, "units")

    def _on_button5(self, event):
        shift = (event.state & 0x0001) != 0
        if shift:
            self.canvas.xview_scroll(1, "units")

    def render(self):
        self.clear()
        word = self.entry.get().strip() or " "
        n = len(word)
        # layout
        glyph_w = 160
        spacing = 30
        margin = 20
        total_w = n * glyph_w + (n - 1) * spacing
        # If content wider than canvas, align left so scrollbar can pan; otherwise center
        if total_w + 2 * margin > self.canvas_w:
            start_x = margin
        else:
            start_x = margin + max(0, (self.canvas_w - total_w) / 2)
        y_center = self.canvas_h / 2 - 10

        for i, ch in enumerate(word):
            idx = pick_motif_index(ch)
            cx = start_x + i * (glyph_w + spacing) + glyph_w / 2
            cy = y_center
            size = glyph_w * 0.9
            # choose motif and color variations deterministically
            seed = char_seed(ch)
            color_palette = ["#d4af37", "#8fbf3f", "#f0e68c", "#c08040", "#ffffff", "#e07a5f"]
            fill = color_palette[(seed >> 5) % len(color_palette)]
            if idx == 0:
                draw_ankh(self.canvas, cx, cy, size, fill=fill)
            elif idx == 1:
                draw_eye(self.canvas, cx, cy, size, fill=fill)
            elif idx == 2:
                draw_scarab(self.canvas, cx, cy, size, fill=fill)
            else:
                draw_cartouche(self.canvas, cx, cy, size, fill=fill)
            # small label
            self.canvas.create_text(cx, cy + size*0.55, text=ch, font=("Helvetica", 12), fill="#222222")

        # title
        self.canvas.create_text(self.canvas_w/2, 18, text=f"Word: {word}", font=("Helvetica", 16, "bold"))

        # Update scrollregion to include all drawn items so horizontal scrollbar works
        self.canvas.update_idletasks()
        bbox = self.canvas.bbox("all")
        if bbox:
            pad = 10
            self.canvas.configure(scrollregion=(bbox[0]-pad, bbox[1]-pad, bbox[2]+pad, bbox[3]+pad))
            # if content narrower than canvas, keep xview at 0 (centering handled above)
            content_width = bbox[2] - bbox[0]
            if content_width < self.canvas_w:
                self.canvas.xview_moveto(0.0)
        else:
            self.canvas.configure(scrollregion=(0, 0, self.canvas_w, self.canvas_h))

    def save_ps(self):
        # Ask for filename and save canvas as PostScript
        fname = filedialog.asksaveasfilename(defaultextension=".ps", filetypes=[("PostScript","*.ps"),("All files","*.*")])
        if not fname:
            return
        try:
            # update the canvas to ensure correct size
            self.canvas.update()
            self.canvas.postscript(file=fname, colormode='color')
            messagebox.showinfo("Saved", f"Saved PostScript to:\n{fname}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save file:\n{e}")

def main():
    root = tk.Tk()
    # ttk styling
    try:
        style = ttk.Style(root)
        style.theme_use("clam")
    except Exception:
        pass
    app = EgyptianApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
