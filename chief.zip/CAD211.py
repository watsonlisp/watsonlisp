#!/usr/bin/env python3
"""
vector_cad_combined.py
AutoCAD-like mini CAD with visible controls, rubber-banding, click/text placement, and robust move/erase/copy behavior.
Combined from provided fragments into a single runnable main program.
Run: python vector_cad_combined.py
"""

import math, shlex, sys, os, webbrowser, copy, re, html
from itertools import repeat

# Try to import tkinter; fallback handled at runtime
try:
    import tkinter as tk
    from tkinter import ttk, simpledialog, filedialog, messagebox
    TK_AVAILABLE = True
except Exception:
    TK_AVAILABLE = False

# -------------------------
# Module-level defaults
# -------------------------
DEFAULT_TEXT_SIZE = 12.0

# -------------------------
# Minimal vector CAD engine
# -------------------------
def identity_matrix():
    return [[1.0,0.0,0.0],[0.0,1.0,0.0],[0.0,0.0,1.0]]

def translation(tx, ty):
    m = identity_matrix(); m[0][2]=tx; m[1][2]=ty; return m

def rotation(theta):
    c = math.cos(theta); s = math.sin(theta)
    return [[c,-s,0.0],[s,c,0.0],[0.0,0.0,1.0]]

def scale(sx, sy=None):
    if sy is None: sy = sx
    return [[sx,0.0,0.0],[0.0,sy,0.0],[0.0,0.0,1.0]]

def apply_transform_point(pt, m):
    x,y = pt
    tx = m[0][0]*x + m[0][1]*y + m[0][2]
    ty = m[1][0]*x + m[1][1]*y + m[1][2]
    w  = m[2][0]*x + m[2][1]*y + m[2][2]
    if w != 0 and w != 1:
        tx /= w; ty /= w
    return (tx, ty)

def ensure_list(v):
    if v is None: return []
    if isinstance(v, (list,tuple)): return list(v)
    return [v]

def broadcast_args(*args):
    lists = [ensure_list(a) for a in args]
    n = max((len(l) for l in lists), default=0)
    if n == 0: return [[] for _ in args]
    out=[]
    for l in lists:
        if len(l)==0: out.append([None]*n)
        elif len(l)==1: out.append([l[0]]*n)
        elif len(l)==n: out.append(list(l))
        else: out.append([l[i] if i < len(l) else l[-1] for i in range(n)])
    return out

# Optional helper: normalize common SVG-style anchors to Tk anchors
def _normalize_anchor_for_tk(anchor):
    if not anchor: return 'nw'
    a = str(anchor).lower()
    if a in ('start', 'left'): return 'w'
    if a in ('middle', 'center'): return 'center'
    if a in ('end', 'right'): return 'e'
    if a in ('nw','n','ne','e','se','s','sw','w','center'):
        return a
    return 'nw'

class PrimitiveStore:
    def __init__(self):
        self.lines=[]; self.circles=[]; self.arcs=[]; self.rects=[]; self.texts=[]
        self.ellipses=[]  # store ellipses as cx,cy,rx,ry,rot
        self.transform = identity_matrix()

    def add_lines(self, x1,y1,x2,y2, **style):
        style = dict(style)
        style.setdefault('layer', '0')
        x1s,y1s,x2s,y2s = broadcast_args(x1,y1,x2,y2)
        self.lines.append({'x1':x1s,'y1':y1s,'x2':x2s,'y2':y2s,'style':style})

    def add_circles(self, cx,cy,r, **style):
        style = dict(style)
        style.setdefault('layer', '0')
        cxs,cys,rs = broadcast_args(cx,cy,r)
        self.circles.append({'cx':cxs,'cy':cys,'r':rs,'style':style})

    def add_arcs(self, cx,cy,r,start,end, **style):
         style = dict(style)
         style.setdefault('stroke', 'black')   # default arc color
         style.setdefault('layer', '0')
         cxs,cys,rs,starts,ends = broadcast_args(cx,cy,r,start,end)
         self.arcs.append({'cx':cxs,'cy':cys,'r':rs,'start':starts,'end':ends,'style':style})

    def add_rects(self, x,y,w,h, rx=0, ry=0, **style):
        style = dict(style)
        style.setdefault('layer', '0')
        xs,ys,ws,hs,rxs,rys = broadcast_args(x,y,w,h,rx,ry)
        # initialize rotation for rects so they behave like other primitives when transformed
        n = max(len(xs), len(ys), len(ws), len(hs), len(rxs), len(rys))
        rots = [0.0] * n
        self.rects.append({'x':xs,'y':ys,'w':ws,'h':hs,'rx':rxs,'ry':rys,'rot':rots,'style':style})

    def add_text(self, x,y,text, size=None, anchor='start', **style):
        # Use module-level DEFAULT_TEXT_SIZE when caller does not provide size
        if size is None:
            size = DEFAULT_TEXT_SIZE
        style = dict(style)
        style.setdefault('layer', '0')
        xs,ys = broadcast_args(x,y)
        texts = ensure_list(text)
        n = max(len(xs), len(ys), len(texts))
        if len(texts)==1 and n>1: texts = texts * n
        if len(xs)==1 and n>1: xs = xs * n
        if len(ys)==1 and n>1: ys = ys * n
        anchor = _normalize_anchor_for_tk(anchor)
        style.setdefault('fill', 'black')
        # initialize rotation for text so it can store orientation like other primitives
        rots = [0.0] * max(1, len(xs))
        self.texts.append({'x':xs,'y':ys,'text':texts,'size':size,'anchor':anchor,'rot':rots,'style':style})

    def add_ellipses(self, cx, cy, rx, ry, rotation=0.0, **style):
        style = dict(style)
        style.setdefault('layer', '0')
        cxs,cys,rxs,rys,rots = broadcast_args(cx,cy,rx,ry,rotation)
        self.ellipses.append({'cx':cxs,'cy':cys,'rx':rxs,'ry':rys,'rot':rots,'style':style})

    def apply_transform(self, matrix):
        for e in self.lines:
            nx1,ny1,nx2,ny2 = [],[],[],[]
            for x1,y1,x2,y2 in zip(e['x1'],e['y1'],e['x2'],e['y2']):
                tx1,ty1 = apply_transform_point((x1,y1), matrix)
                tx2,ty2 = apply_transform_point((x2,y2), matrix)
                nx1.append(tx1); ny1.append(ty1); nx2.append(tx2); ny2.append(ty2)
            e['x1'],e['y1'],e['x2'],e['y2'] = nx1,ny1,nx2,ny2
        for e in self.circles:
            new_cx=[]; new_cy=[]
            for cx,cy in zip(e['cx'], e['cy']):
                tx,ty = apply_transform_point((cx,cy), matrix)
                new_cx.append(tx); new_cy.append(ty)
            e['cx'], e['cy'] = new_cx, new_cy
            sx = math.hypot(matrix[0][0], matrix[1][0]); sy = math.hypot(matrix[0][1], matrix[1][1])
            scale_avg = (sx+sy)/2.0
            e['r'] = [rr * scale_avg for rr in e['r']]
        for e in self.arcs:
            new_cx=[]; new_cy=[]
            for cx,cy in zip(e['cx'], e['cy']):
                tx,ty = apply_transform_point((cx,cy), matrix)
                new_cx.append(tx); new_cy.append(ty)
            e['cx'], e['cy'] = new_cx, new_cy
            sx = math.hypot(matrix[0][0], matrix[1][0]); sy = math.hypot(matrix[0][1], matrix[1][1])
            scale_avg = (sx+sy)/2.0
            e['r'] = [rr * scale_avg for rr in e['r']]
            rot = math.atan2(matrix[1][0], matrix[0][0])
            # rotate start/end angles by rotation amount
            e['start'] = [s + rot for s in e['start']]
            e['end'] = [e2 + rot for e2 in e['end']]
        for e in self.rects:
            new_x=[]; new_y=[]
            for x,y in zip(e['x'], e['y']):
                tx,ty = apply_transform_point((x,y), matrix)
                new_x.append(tx); new_y.append(ty)
            e['x'], e['y'] = new_x, new_y
            sx = math.hypot(matrix[0][0], matrix[1][0]); sy = math.hypot(matrix[0][1], matrix[1][1])
            e['w'] = [ww * sx for ww in e['w']]; e['h'] = [hh * sy for hh in e['h']]
            # update rotation for rects so they behave like other primitives
            rot = math.atan2(matrix[1][0], matrix[0][0])
            if 'rot' in e:
                e['rot'] = [r + rot for r in e['rot']]
            else:
                e['rot'] = [rot] * len(e['x'])
        for e in self.texts:
            new_x=[]; new_y=[]
            for x,y in zip(e['x'], e['y']):
                tx,ty = apply_transform_point((x,y), matrix)
                new_x.append(tx); new_y.append(ty)
            e['x'], e['y'] = new_x, new_y
            sx = math.hypot(matrix[0][0], matrix[1][0])
            if isinstance(e.get('size'), (list, tuple)):
                e['size'] = [float(sz) * sx for sz in e['size']]
            else:
                e['size'] = float(e.get('size', 12)) * sx
            # update rotation for text so it stores orientation like other primitives
            rot = math.atan2(matrix[1][0], matrix[0][0])
            if 'rot' in e:
                e['rot'] = [r + rot for r in e['rot']]
            else:
                e['rot'] = [rot] * len(e['x'])
        for e in self.ellipses:
            new_cx=[]; new_cy=[]
            for cx,cy in zip(e['cx'], e['cy']):
                tx,ty = apply_transform_point((cx,cy), matrix)
                new_cx.append(tx); new_cy.append(ty)
            e['cx'], e['cy'] = new_cx, new_cy
            sx = math.hypot(matrix[0][0], matrix[1][0]); sy = math.hypot(matrix[0][1], matrix[1][1])
            scale_avg = (sx+sy)/2.0
            e['rx'] = [rr * scale_avg for rr in e['rx']]
            e['ry'] = [rr * scale_avg for rr in e['ry']]
            rot = math.atan2(matrix[1][0], matrix[0][0])
            e['rot'] = [r + rot for r in e['rot']]

    def bounding_box(self, sampling=64):
        xs=[]; ys=[]
        for e in self.lines:
            xs.extend(e['x1']); xs.extend(e['x2']); ys.extend(e['y1']); ys.extend(e['y2'])
        for e in self.circles:
            for cx,cy,r in zip(e['cx'], e['cy'], e['r']):
                xs.append(cx-r); xs.append(cx+r); ys.append(cy-r); ys.append(cy+r)
        for e in self.arcs:
            for cx,cy,r,st,ed in zip(e['cx'], e['cy'], e['r'], e['start'], e['end']):
                steps = max(2, int(sampling * abs(ed-st) / (2*math.pi)))
                for i in range(steps):
                    t = st + (ed-st) * i / max(1, steps-1)
                    xs.append(cx + r*math.cos(t)); ys.append(cy + r*math.sin(t))
        for e in self.rects:
            for x,y,w,h,rot in zip(e['x'], e['y'], e['w'], e['h'], e.get('rot', [0]*len(e['x']))):
                if rot:
                    # compute rotated corners
                    cx = x + w/2.0; cy = y + h/2.0
                    corners = []
                    for px,py in ((x,y),(x+w,y),(x+w,y+h),(x,y+h)):
                        dx = px - cx; dy = py - cy
                        rx = cx + dx*math.cos(rot) - dy*math.sin(rot)
                        ry = cy + dx*math.sin(rot) + dy*math.cos(rot)
                        corners.append((rx,ry))
                    for rx,ry in corners:
                        xs.append(rx); ys.append(ry)
                else:
                    xs.extend([x, x+w]); ys.extend([y, y+h])
        for e in self.texts:
            xs.extend(e['x']); ys.extend(e['y'])
        for e in self.ellipses:
            for cx,cy,rx,ry,rot in zip(e['cx'], e['cy'], e['rx'], e['ry'], e['rot']):
                steps = max(8, int(sampling/4))
                for i in range(steps):
                    t = 2*math.pi * i / steps
                    x = cx + rx*math.cos(t)*math.cos(rot) - ry*math.sin(t)*math.sin(rot)
                    y = cy + rx*math.cos(t)*math.sin(rot) + ry*math.sin(t)*math.cos(rot)
                    xs.append(x); ys.append(y)
        if not xs: return (0,0,0,0)
        return (min(xs), min(ys), max(xs), max(ys))

    def to_svg(self, width=800, height=600, sampling=64, background=None):
        minx,miny,maxx,maxy = self.bounding_box(sampling=sampling)
        if maxx-minx < 1e-9 or maxy-miny < 1e-9:
            minx,miny,maxx,maxy = 0,0,width,height
        view_w = maxx-minx; view_h = maxy-miny
        parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="{minx} {miny} {view_w} {view_h}">']
        if background: parts.append(f'<rect x="{minx}" y="{miny}" width="{view_w}" height="{view_h}" fill="{background}" />')
        for e in self.lines:
            style = self._style_str(e['style'])
            for x1,y1,x2,y2 in zip(e['x1'],e['y1'],e['x2'],e['y2']):
                parts.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" {style} />')
        for e in self.circles:
            style = self._style_str(e['style'])
            for cx,cy,r in zip(e['cx'],e['cy'],e['r']):
                parts.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" {style} />')
        for e in self.arcs:
            style = self._style_str(e['style'])
            for cx,cy,r,st,ed in zip(e['cx'],e['cy'],e['r'],e['start'],e['end']):
                steps = max(2, int(sampling * abs(ed-st) / (2*math.pi)))
                pts = [(cx + r*math.cos(t), cy + r*math.sin(t)) for t in (st + (ed-st)*i/(steps-1) for i in range(steps))]
                d = 'M ' + ' L '.join(f'{x:.6f} {y:.6f}' for x,y in pts)
                parts.append(f'<path d="{d}" fill="none" {style} />')
        for e in self.rects:
            style = self._style_str(e['style'])
            for x,y,w,h,rx,ry,rot in zip(e['x'],e['y'],e['w'],e['h'],e['rx'],e['ry'], e.get('rot', [0]*len(e['x']))):
                # if rotation present, emit transform around rectangle center
                if rot:
                    cx = x + w/2.0; cy = y + h/2.0
                    deg = math.degrees(rot)
                    if rx and ry:
                        parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" ry="{ry}" transform="rotate({deg} {cx} {cy})" {style} />')
                    else:
                        parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" transform="rotate({deg} {cx} {cy})" {style} />')
                else:
                    if rx and ry:
                        parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" ry="{ry}" {style} />')
                    else:
                        parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" {style} />')
        for e in self.texts:
            style = self._style_str(e['style'])
            for x,y,t,size,anchor,rot in zip(e['x'], e['y'], e['text'], repeat(e['size'], len(e['x'])), repeat(e['anchor'], len(e['x'])), e.get('rot', [0]*len(e['x']))):
                esc = html.escape(str(t))
                if rot:
                    deg = math.degrees(rot)
                    parts.append(f'<text x="{x}" y="{y}" font-size="{size}" text-anchor="{anchor}" transform="rotate({deg} {x} {y})" {style}>{esc}</text>')
                else:
                    parts.append(f'<text x="{x}" y="{y}" font-size="{size}" text-anchor="{anchor}" {style}>{esc}</text>')
        for e in self.ellipses:
            style = self._style_str(e['style'])
            for cx,cy,rx,ry,rot in zip(e['cx'],e['cy'],e['rx'],e['ry'],e['rot']):
                parts.append(f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" transform="rotate({math.degrees(rot)} {cx} {cy})" {style} />')
        parts.append('</svg>')
        return '\n'.join(parts)

    def _style_str(self, style):
        stroke = style.get('stroke', style.get('color', 'black'))
        stroke_width = style.get('stroke_width', style.get('stroke-width', 1))
        fill = style.get('fill', 'none')
        s=[]
        if stroke is not None: s.append(f'stroke="{stroke}"')
        if stroke_width is not None: s.append(f'stroke-width="{stroke_width}"')
        if fill is not None: s.append(f'fill="{fill}"')
        for k,v in style.items():
            if k in ('stroke','stroke_width','stroke-width','fill','color'): continue
            s.append(f'{k}="{v}"')
        return ' '.join(s)

class Engine:
    def __init__(self):
        self.store = PrimitiveStore()
    def add_lines(self,*a,**k): return self.store.add_lines(*a,**k)
    def add_circles(self,*a,**k): return self.store.add_circles(*a,**k)
    def add_arcs(self,*a,**k): return self.store.add_arcs(*a,**k)
    def add_rects(self,*a,**k): return self.store.add_rects(*a,**k)
    def add_text(self,*a,**k): return self.store.add_text(*a,**k)
    def add_ellipses(self,*a,**k): return self.store.add_ellipses(*a,**k)
    def transform(self,m): return self.store.apply_transform(m)
    def to_svg(self,*a,**k): return self.store.to_svg(*a,**k)
    def bbox(self,*a,**k): return self.store.bounding_box(*a,**k)
    @property
    def store_ref(self): return self.store

# -------------------------
# CAD state: layers, undo
# -------------------------
class CADState:
    def __init__(self, engine):
        self.engine = engine
        self.active_layer = "0"
        self.layers = {"0": {"visible": True}}
        self.osnap = {"endpoint": True, "midpoint": True, "center": True}
        self.ortho = False
        self.polar = False
        self.polar_angle_snap = 15.0
        self.snap_tol = 10.0  # pixels
        self.grid_enabled = True
        self.grid_spacing = 10.0  # world units
        self.snap_to_grid = True
        self.undo_stack = []
        self.redo_stack = []

    def push_undo(self):
        # store a deep copy of the primitive store dict
        self.undo_stack.append(copy.deepcopy(self.engine.store_ref.__dict__))
        self.redo_stack.clear()

    def undo(self):
        if not self.undo_stack: return
        self.redo_stack.append(copy.deepcopy(self.engine.store_ref.__dict__))
        state = self.undo_stack.pop()
        self.engine.store_ref.__dict__.update(state)

    def redo(self):
        if not self.redo_stack: return
        self.undo_stack.append(copy.deepcopy(self.engine.store_ref.__dict__))
        state = self.redo_stack.pop()
        self.engine.store_ref.__dict__.update(state)

# -------------------------
# Coordinate parsing
# -------------------------
def parse_coord(token, last_point=None):
    token = token.strip()
    if token.startswith('@'):
        body = token[1:]
        if '<' in body:
            r, ang = body.split('<',1)
            r = float(r); ang = math.radians(float(ang))
            dx = r * math.cos(ang); dy = r * math.sin(ang)
        else:
            dx,dy = map(float, body.split(','))
        if last_point is None: raise ValueError("No base point for relative coordinate")
        return (last_point[0] + dx, last_point[1] + dy)
    else:
        if '<' in token:
            r, ang = token.split('<',1)
            r = float(r); ang = math.radians(float(ang))
            dx = r * math.cos(ang); dy = r * math.sin(ang)
            if last_point is None: return (dx, dy)
            return (last_point[0] + dx, last_point[1] + dy)
        else:
            x,y = map(float, token.split(','))
            return (x,y)

# -------------------------
# Constraints and osnap
# -------------------------
def apply_constraints(pt, base_pt, cadstate):
    if base_pt is None: return pt
    dx = pt[0] - base_pt[0]; dy = pt[1] - base_pt[1]
    if cadstate.ortho:
        if abs(dx) > abs(dy): return (base_pt[0] + dx, base_pt[1])
        else: return (base_pt[0], base_pt[1] + dy)
    if cadstate.polar:
        ang = math.degrees(math.atan2(dy, dx))
        snap = cadstate.polar_angle_snap
        ang_snapped = round(ang / snap) * snap
        r = math.hypot(dx, dy)
        a = math.radians(ang_snapped)
        return (base_pt[0] + r*math.cos(a), base_pt[1] + r*math.sin(a))
    return pt

def find_osnap_point(xw, yw, engine, s, tx, ty, cadstate):
    def wc(x,y): return (x*s + tx, y*s + ty)
    best=None; best_d = cadstate.snap_tol
    for e in engine.store_ref.lines:
        for x1,y1,x2,y2 in zip(e['x1'],e['y1'],e['x2'],e['y2']):
            for px,py in ((x1,y1),(x2,y2)):
                cx,cy = wc(px,py); d = math.hypot(cx-xw, cy-yw)
                if d < best_d and cadstate.osnap.get('endpoint', False):
                    best_d = d; best = (px,py)
            if cadstate.osnap.get('midpoint', False):
                mx,my = ((x1+x2)/2.0, (y1+y2)/2.0)
                cx,cy = wc(mx,my); d = math.hypot(cx-xw, cy-yw)
                if d < best_d: best_d = d; best = (mx,my)
    for e in engine.store_ref.circles:
        for cx0,cy0,r in zip(e['cx'], e['cy'], e['r']):
            if cadstate.osnap.get('center', False):
                cx,cy = wc(cx0,cy0); d = math.hypot(cx-xw, cy-yw)
                if d < best_d: best_d = d; best = (cx0,cy0)
    for e in engine.store_ref.ellipses:
        for cx0,cy0 in zip(e['cx'], e['cy']):
            if cadstate.osnap.get('center', False):
                cx,cy = wc(cx0,cy0); d = math.hypot(cx-xw, cy-yw)
                if d < best_d: best_d = d; best = (cx0,cy0)
    for e in engine.store_ref.rects:
        for cx0,cy0,w,h in zip(e['x'], e['y'], e['w'], e['h']):
            if cadstate.osnap.get('endpoint', False):
                # corners
                for px,py in ((cx0,cy0),(cx0+w,cy0),(cx0+w,cy0+h),(cx0,cy0+h)):
                    cx,cy = wc(px,py); d = math.hypot(cx-xw, cy-yw)
                    if d < best_d:
                        best_d = d; best = (px,py)
    for e in engine.store_ref.arcs:
        for cx0,cy0,r,st,ed in zip(e['cx'], e['cy'], e['r'], e['start'], e['end']):
            if cadstate.osnap.get('endpoint', False):
                sx = cx0 + r * math.cos(st); sy = cy0 + r * math.sin(st)
                ex = cx0 + r * math.cos(ed); ey = cy0 + r * math.sin(ed)
                for px,py in ((sx,sy),(ex,ey)):
                    cx,cy = wc(px,py); d = math.hypot(cx-xw, cy-yw)
                    if d < best_d:
                        best_d = d; best = (px,py)
            if cadstate.osnap.get('center', False):
                cx,cy = wc(cx0,cy0); d = math.hypot(cx-xw, cy-yw)
                if d < best_d:
                    best_d = d; best = (cx0,cy0)
    return best

# -------------------------
# Geometry helpers for 3-point arc and ellipse
# -------------------------
def circle_from_3pts(p1, p2, p3):
    (x1,y1),(x2,y2),(x3,y3) = p1,p2,p3
    a = x1 - x2; b = y1 - y2
    c = x1 - x3; d = y1 - y3
    e = ((x1*x1 - x2*x2) + (y1*y1 - y2*y2)) / 2.0
    f = ((x1*x1 - x3*x3) + (y1*y1 - y3*y3)) / 2.0
    det = a * d - b * c
    if abs(det) < 1e-9:
        raise ValueError("Points are collinear or too close to collinear")
    cx = (d*e - b*f) / det
    cy = (-c*e + a*f) / det
    r = math.hypot(cx - x1, cy - y1)
    return (cx, cy, r)

def normalize_angle(a):
    a = a % (2*math.pi)
    if a < 0: a += 2*math.pi
    return a

def angle_between_ccw(a, b, c):
    a = normalize_angle(a); b = normalize_angle(b); c = normalize_angle(c)
    if c >= a:
        return a <= b <= c
    else:
        return b >= a or b <= c

# -------------------------
# DXF save / load helpers
# -------------------------
def _dxf_escape_text(s):
    return str(s).replace('\n', '\\P')

def save_dxf_file(filename, engine):
    s = engine.store_ref
    lines_out = []
    def add_pair(code, value):
        lines_out.append(str(code))
        lines_out.append(str(value))

    add_pair(0, 'SECTION'); add_pair(2, 'HEADER'); add_pair(9, '$ACADVER'); add_pair(1, 'AC1009'); add_pair(0, 'ENDSEC')
    add_pair(0, 'SECTION'); add_pair(2, 'TABLES'); add_pair(0, 'ENDSEC')
    add_pair(0, 'SECTION'); add_pair(2, 'BLOCKS'); add_pair(0, 'ENDSEC')
    add_pair(0, 'SECTION'); add_pair(2, 'ENTITIES')

    for e in s.lines:
        style = e.get('style', {})
        layer = style.get('layer', None)
        for x1,y1,x2,y2 in zip(e['x1'], e['y1'], e['x2'], e['y2']):
            add_pair(0, 'LINE')
            if layer: add_pair(8, layer)
            add_pair(10, x1); add_pair(20, y1); add_pair(11, x2); add_pair(21, y2)

    for e in s.circles:
        style = e.get('style', {})
        layer = style.get('layer', None)
        for cx,cy,r in zip(e['cx'], e['cy'], e['r']):
            add_pair(0, 'CIRCLE')
            if layer: add_pair(8, layer)
            add_pair(10, cx); add_pair(20, cy); add_pair(40, r)

    for e in s.arcs:
        style = e.get('style', {})
        layer = style.get('layer', None)
        for cx,cy,r,st,ed in zip(e['cx'], e['cy'], e['r'], e['start'], e['end']):
            add_pair(0, 'ARC')
            if layer: add_pair(8, layer)
            add_pair(10, cx); add_pair(20, cy); add_pair(40, r)
            add_pair(50, math.degrees(st)); add_pair(51, math.degrees(ed))

    # Preserve rectangle rotation by writing rotated corner coordinates as LINE entities
    for e in s.rects:
        style = e.get('style', {})
        layer = style.get('layer', None)
        rots = e.get('rot', [0]*len(e['x']))
        for x,y,wid,hei,rot in zip(e['x'], e['y'], e['w'], e['h'], rots):
            # compute corners, rotated around rectangle center if rotation present
            if rot:
                cx = x + wid/2.0; cy = y + hei/2.0
                corners = []
                for px,py in ((x,y),(x+wid,y),(x+wid,y+hei),(x,y+hei)):
                    dx = px - cx; dy = py - cy
                    rx = cx + dx*math.cos(rot) - dy*math.sin(rot)
                    ry = cy + dx*math.sin(rot) + dy*math.cos(rot)
                    corners.append((rx, ry))
            else:
                corners = [(x,y),(x+wid,y),(x+wid,y+hei),(x,y+hei)]
            # write as 4 LINE entities using the computed corners
            for i in range(4):
                x1,y1 = corners[i]; x2,y2 = corners[(i+1)%4]
                add_pair(0, 'LINE')
                if layer: add_pair(8, layer)
                add_pair(10, x1); add_pair(20, y1); add_pair(11, x2); add_pair(21, y2)

    for e in s.texts:
        style = e.get('style', {})
        layer = style.get('layer', None)
        if isinstance(e.get('size'), (list, tuple)):
            sizes = list(e['size'])
        else:
            sizes = [e.get('size', 12)] * len(e['x'])
        rots = e.get('rot', [0]*len(e['x']))
        for x,y,t,size,anchor,rot in zip(e['x'], e['y'], e['text'], sizes, repeat(e['anchor'], len(e['x'])), rots):
            add_pair(0, 'TEXT')
            if layer: add_pair(8, layer)
            add_pair(10, x); add_pair(20, y)
            add_pair(40, size)
            # Preserve text rotation using DXF group code 50 (rotation in degrees)
            add_pair(50, math.degrees(rot))
            add_pair(1, _dxf_escape_text(t))

    for e in s.ellipses:
        style = e.get('style', {})
        layer = style.get('layer', None)
        for cx,cy,rx,ry,rot in zip(e['cx'], e['cy'], e['rx'], e['ry'], e['rot']):
            steps = 32
            pts = []
            for i in range(steps):
                t = 2*math.pi * i / steps
                x = cx + rx*math.cos(t)*math.cos(rot) - ry*math.sin(t)*math.sin(rot)
                y = cy + rx*math.cos(t)*math.sin(rot) + ry*math.sin(t)*math.cos(rot)
                pts.append((x,y))
            for i in range(len(pts)):
                x1,y1 = pts[i]; x2,y2 = pts[(i+1)%len(pts)]
                add_pair(0, 'LINE')
                if layer: add_pair(8, layer)
                add_pair(10, x1); add_pair(20, y1); add_pair(11, x2); add_pair(21, y2)

    add_pair(0, 'ENDSEC')
    add_pair(0, 'EOF')

    with open(filename, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines_out))

def _read_dxf_pairs(fp):
    while True:
        code_line = fp.readline()
        if not code_line:
            return
        code = code_line.strip()
        while code == '':
            code_line = fp.readline()
            if not code_line:
                return
            code = code_line.strip()
        val_line = fp.readline()
        if not val_line:
            return
        yield int(code), val_line.rstrip('\n')

def load_dxf_file(filename, engine, cadstate):
    cadstate.push_undo()
    s = engine.store_ref
    s.lines.clear(); s.circles.clear(); s.arcs.clear(); s.rects.clear(); s.texts.clear(); s.ellipses.clear()

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            pairs = _read_dxf_pairs(f)
            current_entity = None
            ent = {}

            def _flush_entity(cur_ent, ent_dict):
                if not cur_ent or not ent_dict:
                    return
                if cur_ent == 'LINE' and ent_dict:
                    # invert Y when reading DXF so drawing comes in right-side-up
                    x1 = float(ent_dict.get('10', 0)); y1 = -float(ent_dict.get('20', 0))
                    x2 = float(ent_dict.get('11', 0)); y2 = -float(ent_dict.get('21', 0))
                    style = {}
                    if '8' in ent_dict: style['layer'] = ent_dict['8']
                    else: style.setdefault('layer', '0')
                    s.lines.append({'x1':[x1],'y1':[y1],'x2':[x2],'y2':[y2],'style':style})
                elif cur_ent == 'CIRCLE' and ent_dict:
                    cx = float(ent_dict.get('10', 0)); cy = -float(ent_dict.get('20', 0)); r = float(ent_dict.get('40', 0))
                    style = {}
                    if '8' in ent_dict: style['layer'] = ent_dict['8']
                    else: style.setdefault('layer', '0')
                    s.circles.append({'cx':[cx],'cy':[cy],'r':[r],'style':style})
                elif cur_ent == 'ARC' and ent_dict:
                    cx = float(ent_dict.get('10', 0)); cy = -float(ent_dict.get('20', 0)); r = float(ent_dict.get('40', 0))
                    st = float(ent_dict.get('50', 0)); ed = float(ent_dict.get('51', 0))
                    style = {}
                    if '8' in ent_dict: style['layer'] = ent_dict['8']
                    else: style.setdefault('layer', '0')
                    # negate DXF angles to match internal orientation, then convert to radians
                    s.arcs.append({'cx':[cx],'cy':[cy],'r':[r],'start':[math.radians(-st)],'end':[math.radians(-ed)],'style':style})
                elif cur_ent == 'TEXT' and ent_dict:
                    x = float(ent_dict.get('10', 0)); y = -float(ent_dict.get('20', 0))
                    size = float(ent_dict.get('40', 12))
                    txt = ent_dict.get('1', '')
                    # read rotation if present (group code 50) and store as radians (negate DXF angle)
                    rot_deg = float(ent_dict.get('50', 0))
                    rot_rad = math.radians(-rot_deg)
                    style = {}
                    if '8' in ent_dict: style['layer'] = ent_dict['8']
                    else: style.setdefault('layer', '0')
                    # preserve anchor if present; default to 'nw' to match earlier behavior
                    anchor = ent_dict.get('71', None) or 'nw'
                    s.texts.append({'x':[x],'y':[y],'text':[txt],'size':size,'anchor':anchor,'rot':[rot_rad],'style':style})
                elif cur_ent == 'ELLIPSE' and ent_dict:
                    # If ELLIPSE entities are present as true DXF ellipses, handle center and radii.
                    cx = float(ent_dict.get('10', 0)); cy = -float(ent_dict.get('20', 0))
                    rx = float(ent_dict.get('40', 0)) if '40' in ent_dict else 0.0
                    ry = float(ent_dict.get('41', 0)) if '41' in ent_dict else rx
                    rot_deg = float(ent_dict.get('50', 0)) if '50' in ent_dict else 0.0
                    rot_rad = math.radians(-rot_deg)
                    style = {}
                    if '8' in ent_dict: style['layer'] = ent_dict['8']
                    else: style.setdefault('layer', '0')
                    s.ellipses.append({'cx':[cx],'cy':[cy],'rx':[rx],'ry':[ry],'rot':[rot_rad],'style':style})
                # other entity types are ignored here (or handled elsewhere)

            for code, val in pairs:
                if code == 0:
                    # flush previous entity before starting new one
                    _flush_entity(current_entity, ent)
                    ent = {}
                    current_entity = val.strip().upper()
                else:
                    ent[str(code)] = val
            # flush any remaining entity at EOF
            _flush_entity(current_entity, ent)

        # Ensure every entity has a style dict with a layer key (preserve original behavior)
        for e in s.lines:
            if 'style' not in e or not isinstance(e['style'], dict):
                e['style'] = {'layer': '0'}
            else:
                e['style'].setdefault('layer', '0')
        for e in s.circles:
            if 'style' not in e or not isinstance(e['style'], dict):
                e['style'] = {'layer': '0'}
            else:
                e['style'].setdefault('layer', '0')
        for e in s.arcs:
            if 'style' not in e or not isinstance(e['style'], dict):
                e['style'] = {'layer': '0'}
            else:
                e['style'].setdefault('layer', '0')
        for e in s.rects:
            if 'style' not in e or not isinstance(e['style'], dict):
                e['style'] = {'layer': '0'}
            else:
                e['style'].setdefault('layer', '0')
        for e in s.texts:
            if 'style' not in e or not isinstance(e['style'], dict):
                e['style'] = {'layer': '0'}
            else:
                e['style'].setdefault('layer', '0')
            # ensure rot list exists for texts
            if 'rot' not in e or not isinstance(e['rot'], list):
                e['rot'] = [0.0] * len(e['x'])
        for e in s.ellipses:
            if 'style' not in e or not isinstance(e['style'], dict):
                e['style'] = {'layer': '0'}
            else:
                e['style'].setdefault('layer', '0')
    except Exception:
        # if load fails, restore previous undo state and re-raise
        cadstate.undo()
        raise

# -------------------------
# Tkinter UI: controls + rubber-banding + text dialog + polygon + undo/redo + multi-select + window/crossing
# -------------------------
SVG_FILE = "out.svg"
COORD_RE = re.compile(r'^\s*@?\s*-?\d+(\.\d+)?\s*(<\s*-?\d+(\.\d+)?)?\s*(,\s*-?\d+(\.\d+)?)?\s*$')

def tk_main(engine):
    if not TK_AVAILABLE:
        raise RuntimeError("Tkinter not available in this Python environment.")
    cad = CADState(engine)
    root = tk.Tk(); root.title("Mini AutoCAD-like CAD (controls + rubber-banding + grid/snap + 3pt arc + ellipse + polygon + Undo/Redo + DXF)")

    top_frame = tk.Frame(root)
    top_frame.pack(side='top', fill='x')

    paned = ttk.Panedwindow(root, orient='horizontal')
    paned.pack(side='top', fill='both', expand=True)

    left_container = tk.Frame(paned)
    left_container.pack(fill='both', expand=True)
    paned.add(left_container, weight=0)

    center_frame = tk.Frame(paned)
    center_frame.pack(fill='both', expand=True)
    paned.add(center_frame, weight=1)

    bottom_frame = tk.Frame(root)
    bottom_frame.pack(side='bottom', fill='x')

    try:
        root.state('zoomed')
    except Exception:
        try:
            root.attributes('-zoomed', True)
        except Exception:
            sw = root.winfo_screenwidth(); sh = root.winfo_screenheight()
            root.geometry(f"{sw}x{sh}")

    def tb_button(text, cmd):
        b = tk.Button(top_frame, text=text, width=10, command=cmd)
        b.pack(side='left', padx=2, pady=2)
        return b

    left_notebook = ttk.Notebook(left_container, width=300)
    left_notebook.pack(fill='both', expand=True, padx=4, pady=4)

    layers_tab = tk.Frame(left_notebook)
    left_notebook.add(layers_tab, text='Layers')

    layers_label = tk.Label(layers_tab, text="Layers", font=("Arial", 10, "bold"))
    layers_label.pack(anchor='nw', padx=6, pady=(6,0))

    layers_frame = tk.Frame(layers_tab)
    layers_frame.pack(fill='both', expand=False, padx=6, pady=(2,4))
    layers_scroll = tk.Scrollbar(layers_frame, orient='vertical')
    layers_listbox = tk.Listbox(layers_frame, height=6, yscrollcommand=layers_scroll.set)
    layers_scroll.config(command=layers_listbox.yview)
    layers_listbox.pack(side='left', fill='both', expand=True)
    layers_scroll.pack(side='right', fill='y')

    layer_entry = tk.Entry(layers_tab)
    layer_entry.pack(fill='x', padx=6, pady=(2,4))

    # Text height control (allows user to enter default text size)
    text_size_var = tk.DoubleVar(value=DEFAULT_TEXT_SIZE)

    def _on_text_size_change(*args):
        global DEFAULT_TEXT_SIZE
        try:
            v = float(text_size_var.get())
            if v > 0:
                DEFAULT_TEXT_SIZE = v
        except Exception:
            pass

    text_size_var.trace_add('write', _on_text_size_change)

    text_size_frame = tk.Frame(layers_tab)
    text_size_frame.pack(fill='x', padx=6, pady=(2,4))
    tk.Label(text_size_frame, text="Text height:", anchor='w').pack(side='left')
    text_size_entry = tk.Entry(text_size_frame, textvariable=text_size_var, width=8)
    text_size_entry.pack(side='left', padx=(6,0))

    # --- Restore osnap controls (endpoint, midpoint, center) ---
    snaps_label = tk.Label(layers_tab, text="Object Snaps", font=("Arial", 10, "bold"))
    snaps_label.pack(anchor='nw', padx=6, pady=(4,0))

    snaps_frame = tk.Frame(layers_tab)
    snaps_frame.pack(fill='x', padx=6, pady=(2,6))

    endpoint_var = tk.BooleanVar(value=cad.osnap.get('endpoint', True))
    midpoint_var = tk.BooleanVar(value=cad.osnap.get('midpoint', True))
    center_var = tk.BooleanVar(value=cad.osnap.get('center', True))

    def _update_osnap_from_vars():
        cad.osnap['endpoint'] = bool(endpoint_var.get())
        cad.osnap['midpoint'] = bool(midpoint_var.get())
        cad.osnap['center'] = bool(center_var.get())
        append_history(f"osnap: endpoint={cad.osnap['endpoint']}, midpoint={cad.osnap['midpoint']}, center={cad.osnap['center']}")

    endpoint_cb = tk.Checkbutton(snaps_frame, text="Endpoint", variable=endpoint_var, command=_update_osnap_from_vars)
    midpoint_cb = tk.Checkbutton(snaps_frame, text="Midpoint", variable=midpoint_var, command=_update_osnap_from_vars)
    center_cb = tk.Checkbutton(snaps_frame, text="Center", variable=center_var, command=_update_osnap_from_vars)

    endpoint_cb.pack(anchor='w')
    midpoint_cb.pack(anchor='w')
    center_cb.pack(anchor='w')

    # --- Grid and Snap controls (restored) ---
    grid_label = tk.Label(layers_tab, text="Grid & Snap", font=("Arial", 10, "bold"))
    grid_label.pack(anchor='nw', padx=6, pady=(6,0))

    grid_frame = tk.Frame(layers_tab)
    grid_frame.pack(fill='x', padx=6, pady=(2,6))

    grid_enabled_var = tk.BooleanVar(value=cad.grid_enabled)
    snap_to_grid_var = tk.BooleanVar(value=cad.snap_to_grid)
    grid_spacing_var = tk.StringVar(value=str(cad.grid_spacing))

    def _update_grid_from_vars():
        try:
            spacing = float(grid_spacing_var.get())
            if spacing <= 0:
                raise ValueError
        except Exception:
            messagebox.showerror("Invalid spacing", "Grid spacing must be a positive number.")
            grid_spacing_var.set(str(cad.grid_spacing))
            return
        cad.grid_spacing = spacing
        cad.grid_enabled = bool(grid_enabled_var.get())
        cad.snap_to_grid = bool(snap_to_grid_var.get())
        append_history(f"Grid: enabled={cad.grid_enabled}, spacing={cad.grid_spacing}, snap_to_grid={cad.snap_to_grid}")
        draw_canvas()

    grid_enabled_cb = tk.Checkbutton(grid_frame, text="Show Grid", variable=grid_enabled_var, command=_update_grid_from_vars)
    snap_to_grid_cb = tk.Checkbutton(grid_frame, text="Snap To Grid", variable=snap_to_grid_var, command=_update_grid_from_vars)
    grid_spacing_label = tk.Label(grid_frame, text="Spacing:")
    grid_spacing_entry = tk.Entry(grid_frame, textvariable=grid_spacing_var, width=8)

    def _on_grid_spacing_enter(event=None):
        _update_grid_from_vars()

    grid_spacing_entry.bind("<Return>", _on_grid_spacing_enter)

    grid_enabled_cb.grid(row=0, column=0, sticky='w')
    snap_to_grid_cb.grid(row=1, column=0, sticky='w')
    grid_spacing_label.grid(row=0, column=1, padx=(8,2))
    grid_spacing_entry.grid(row=0, column=2, sticky='w')

    # Populate initial layer listbox
    layers_listbox.delete(0, 'end')
    for lname in cad.layers.keys():
        layers_listbox.insert('end', lname)

    hist_box = tk.Text(left_container, height=8, state='disabled')
    hist_box.pack(fill='x', padx=6, pady=(4,6))

    def append_history(msg):
        try:
            hist_box.config(state='normal')
            hist_box.insert('end', msg + '\n')
            hist_box.see('end')
            hist_box.config(state='disabled')
        except Exception:
            pass

    def add_layer():
        name = layer_entry.get().strip()
        if not name: return
        if name in cad.layers:
            append_history(f"Layer {name} exists")
        else:
            cad.layers[name] = {'visible': True}
            layers_listbox.insert('end', name)
            append_history(f"Layer {name} added")
            # set as current layer automatically
            cad.active_layer = name
            current_layer_label.config(text=f"Current: {cad.active_layer}")

    def del_layer():
        sel = layers_listbox.curselection()
        if not sel: return
        name = layers_listbox.get(sel[0])
        if name == '0': append_history("Cannot delete layer 0"); return
        cad.layers.pop(name, None)
        layers_listbox.delete(sel[0])
        append_history(f"Layer {name} deleted")
        # if deleted layer was current, revert to layer 0
        if cad.active_layer == name:
            cad.active_layer = '0'
            current_layer_label.config(text=f"Current: {cad.active_layer}")
            append_history("Current layer reset to 0")

    def toggle_layer_visibility():
        sel = layers_listbox.curselection()
        if not sel: return
        name = layers_listbox.get(sel[0])
        cad.layers[name]['visible'] = not cad.layers[name].get('visible', True)
        append_history(f"Layer {name} visible = {cad.layers[name]['visible']}")
        draw_canvas()

    def set_current_layer():
        sel = layers_listbox.curselection()
        if not sel:
            append_history("No layer selected to set current")
            return
        name = layers_listbox.get(sel[0])
        cad.active_layer = name
        current_layer_label.config(text=f"Current: {cad.active_layer}")
        append_history(f"Current layer set to {cad.active_layer}")

    # Current layer display and buttons
    current_layer_label = tk.Label(layers_tab, text=f"Current: {cad.active_layer}", anchor='w')
    current_layer_label.pack(fill='x', padx=6, pady=(2,4))

    layer_buttons_frame = tk.Frame(layers_tab)
    layer_buttons_frame.pack(fill='x', padx=6, pady=(2,6))
    tk.Button(layer_buttons_frame, text="Add Layer", command=add_layer).pack(side='left', padx=2)
    tk.Button(layer_buttons_frame, text="Delete Layer", command=del_layer).pack(side='left', padx=2)
    tk.Button(layer_buttons_frame, text="Toggle Visible", command=toggle_layer_visibility).pack(side='left', padx=2)
    tk.Button(layer_buttons_frame, text="Set Current", command=set_current_layer).pack(side='left', padx=2)

    # Canvas and view transform state
    canvas = tk.Canvas(center_frame, bg='white')
    canvas.pack(fill='both', expand=True)
    view_scale = 1.0
    view_tx = 0.0
    view_ty = 0.0

    def world_to_screen(x, y):
        return (x * view_scale + view_tx, y * view_scale + view_ty)

    def screen_to_world(sx, sy):
        return ((sx - view_tx) / view_scale, (sy - view_ty) / view_scale)

    # Selection and command state
    selection = []
    current_cmd = None
    move_origin = None
    last_mouse = (0,0)
    arc_points = []
    ellipse_points = []
    polygon_pts = []
    copied_entries = []
    copy_initial_positions = {}

    # Selection rectangle state (for window/crossing)
    select_origin = None
    select_rect_id = None

    # Middle-button pan state
    pan_last = None

    # osnap preview state
    osnap_preview = {'id': None, 'pt': None}

    # mouse world/screen for crosshair & coords
    mouse_world = None
    mouse_screen = None

    # --- helpers for rotate/scale and copy ---
    def _mat_mul(a, b):
        return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]

    def centroid_of_selection(engine_obj, selection_list):
        pts = []
        sref = engine_obj.store_ref
        for typ, i, j in selection_list:
            try:
                if typ == 'line':
                    e = sref.lines[i]
                    pts.append(((e['x1'][j] + e['x2'][j]) / 2.0, (e['y1'][j] + e['y2'][j]) / 2.0))
                elif typ == 'circle':
                    e = sref.circles[i]; pts.append((e['cx'][j], e['cy'][j]))
                elif typ == 'rect':
                    e = sref.rects[i]; pts.append((e['x'][j] + e['w'][j]/2.0, e['y'][j] + e['h'][j]/2.0))
                elif typ == 'text':
                    e = sref.texts[i]; pts.append((e['x'][j], e['y'][j]))
                elif typ == 'ellipse':
                    e = sref.ellipses[i]; pts.append((e['cx'][j], e['cy'][j]))
                elif typ == 'arc':
                    e = sref.arcs[i]; pts.append((e['cx'][j], e['cy'][j]))
            except Exception:
                pass
        if not pts: return (0.0, 0.0)
        sx = sum(p[0] for p in pts) / len(pts)
        sy = sum(p[1] for p in pts) / len(pts)
        return (sx, sy)

    def _duplicate_selection_entries(selection_list):
        """Duplicate the primitives in selection_list and return list of new entries (typ,i,j)."""
        new_entries = []
        sref = engine.store_ref
        for typ, i, j in selection_list:
            if typ == 'line':
                e = sref.lines[i]
                x1,y1 = e['x1'][j], e['y1'][j]; x2,y2 = e['x2'][j], e['y2'][j]
                layer = e.get('style', {}).get('layer', cad.active_layer)
                engine.add_lines(x1, y1, x2, y2, layer=layer)
                new_i = len(sref.lines) - 1
                new_j = len(sref.lines[new_i]['x1']) - 1
                new_entries.append(('line', new_i, new_j))
            elif typ == 'circle':
                e = sref.circles[i]
                cx,cy,r = e['cx'][j], e['cy'][j], e['r'][j]
                layer = e.get('style', {}).get('layer', cad.active_layer)
                engine.add_circles(cx, cy, r, layer=layer)
                new_i = len(sref.circles) - 1
                new_j = len(sref.circles[new_i]['cx']) - 1
                new_entries.append(('circle', new_i, new_j))
            elif typ == 'rect':
                e = sref.rects[i]
                x,y,w,h = e['x'][j], e['y'][j], e['w'][j], e['h'][j]
                rot = e.get('rot', [0])[j] if 'rot' in e else 0.0
                layer = e.get('style', {}).get('layer', cad.active_layer)
                engine.add_rects(x, y, w, h, layer=layer)
                # ensure rotation is copied if present
                new_i = len(sref.rects) - 1
                new_j = len(sref.rects[new_i]['x']) - 1
                if 'rot' in sref.rects[new_i]:
                    sref.rects[new_i]['rot'][new_j] = rot
                new_entries.append(('rect', new_i, new_j))
            elif typ == 'text':
                e = sref.texts[i]
                x,y = e['x'][j], e['y'][j]; t = e['text'][j]
                size = e.get('size', 12)
                anchor = e.get('anchor', 'nw')
                rot = e.get('rot', [0])[j] if 'rot' in e else 0.0
                layer = e.get('style', {}).get('layer', cad.active_layer)
                engine.add_text(x, y, t, size=size, anchor=anchor, layer=layer)
                new_i = len(sref.texts) - 1
                new_j = len(sref.texts[new_i]['x']) - 1
                if 'rot' in sref.texts[new_i]:
                    sref.texts[new_i]['rot'][new_j] = rot
                new_entries.append(('text', new_i, new_j))
            elif typ == 'ellipse':
                e = sref.ellipses[i]
                cx,cy,rx_e,ry_e,rot = e['cx'][j], e['cy'][j], e['rx'][j], e['ry'][j], e['rot'][j]
                layer = e.get('style', {}).get('layer', cad.active_layer)
                engine.add_ellipses(cx, cy, rx_e, ry_e, rot, layer=layer)
                new_i = len(sref.ellipses) - 1
                new_j = len(sref.ellipses[new_i]['cx']) - 1
                new_entries.append(('ellipse', new_i, new_j))
            elif typ == 'arc':
                e = sref.arcs[i]
                cx,cy,r,st,ed = e['cx'][j], e['cy'][j], e['r'][j], e['start'][j], e['end'][j]
                layer = e.get('style', {}).get('layer', cad.active_layer)
                engine.add_arcs(cx, cy, r, st, ed, layer=layer)
                new_i = len(sref.arcs) - 1
                new_j = len(sref.arcs[new_i]['cx']) - 1
                new_entries.append(('arc', new_i, new_j))
        return new_entries

    def _translate_entries(entries, dx, dy):
        """Translate only the given entries by dx,dy (modify store arrays directly)."""
        sref = engine.store_ref
        for typ, i, j in entries:
            try:
                if typ == 'line':
                    e = sref.lines[i]
                    e['x1'][j] += dx; e['y1'][j] += dy
                    e['x2'][j] += dx; e['y2'][j] += dy
                elif typ == 'circle':
                    e = sref.circles[i]
                    e['cx'][j] += dx; e['cy'][j] += dy
                elif typ == 'rect':
                    e = sref.rects[i]
                    e['x'][j] += dx; e['y'][j] += dy
                elif typ == 'text':
                    e = sref.texts[i]
                    e['x'][j] += dx; e['y'][j] += dy
                elif typ == 'ellipse':
                    e = sref.ellipses[i]
                    e['cx'][j] += dx; e['cy'][j] += dy
                elif typ == 'arc':
                    e = sref.arcs[i]
                    e['cx'][j] += dx; e['cy'][j] += dy
            except Exception:
                pass

    def _transform_entries(entries, matrix):
        """
        Apply a 3x3 transform matrix to only the specified entries.
        This mirrors PrimitiveStore.apply_transform but operates on selected primitives.
        """
        sref = engine.store_ref
        # compute scale/rotation components for radius/size adjustments
        sx = math.hypot(matrix[0][0], matrix[1][0])
        sy = math.hypot(matrix[0][1], matrix[1][1])
        scale_avg = (sx + sy) / 2.0
        rot = math.atan2(matrix[1][0], matrix[0][0])
        for typ, i, j in entries:
            try:
                if typ == 'line':
                    e = sref.lines[i]
                    x1,y1 = e['x1'][j], e['y1'][j]; x2,y2 = e['x2'][j], e['y2'][j]
                    tx1,ty1 = apply_transform_point((x1,y1), matrix)
                    tx2,ty2 = apply_transform_point((x2,y2), matrix)
                    e['x1'][j], e['y1'][j], e['x2'][j], e['y2'][j] = tx1,ty1,tx2,ty2
                elif typ == 'circle':
                    e = sref.circles[i]
                    cx,cy,r = e['cx'][j], e['cy'][j], e['r'][j]
                    tcx,tcy = apply_transform_point((cx,cy), matrix)
                    e['cx'][j], e['cy'][j] = tcx, tcy
                    e['r'][j] = r * scale_avg
                elif typ == 'rect':
                    e = sref.rects[i]
                    x,y,w,h = e['x'][j], e['y'][j], e['w'][j], e['h'][j]
                    tx,ty = apply_transform_point((x,y), matrix)
                    e['x'][j], e['y'][j] = tx, ty
                    e['w'][j] = w * sx
                    e['h'][j] = h * sy
                    # update rotation for rects so they rotate like other primitives
                    if 'rot' in e:
                        e['rot'][j] = e['rot'][j] + rot
                    else:
                        # ensure rot list exists
                        e['rot'] = [0.0] * len(e['x'])
                        e['rot'][j] = rot
                elif typ == 'text':
                    e = sref.texts[i]
                    x,y = e['x'][j], e['y'][j]
                    tx,ty = apply_transform_point((x,y), matrix)
                    e['x'][j], e['y'][j] = tx, ty
                    if isinstance(e.get('size'), (list, tuple)):
                        e['size'][j] = float(e['size'][j]) * sx
                    else:
                        e['size'] = float(e.get('size', 12)) * sx
                    # update rotation for text so it stores orientation
                    if 'rot' in e:
                        e['rot'][j] = e['rot'][j] + rot
                    else:
                        e['rot'] = [0.0] * len(e['x'])
                        e['rot'][j] = rot
                elif typ == 'ellipse':
                    e = sref.ellipses[i]
                    cx,cy,rx_e,ry_e,rot_e = e['cx'][j], e['cy'][j], e['rx'][j], e['ry'][j], e['rot'][j]
                    tcx,tcy = apply_transform_point((cx,cy), matrix)
                    e['cx'][j], e['cy'][j] = tcx, tcy
                    e['rx'][j] = rx_e * scale_avg
                    e['ry'][j] = ry_e * scale_avg
                    e['rot'][j] = rot_e + rot
                elif typ == 'arc':
                    e = sref.arcs[i]
                    cx,cy,r,st,ed = e['cx'][j], e['cy'][j], e['r'][j], e['start'][j], e['end'][j]
                    tcx,tcy = apply_transform_point((cx,cy), matrix)
                    e['cx'][j], e['cy'][j] = tcx, tcy
                    e['r'][j] = r * scale_avg
                    e['start'][j] = st + rot
                    e['end'][j] = ed + rot
            except Exception:
                pass

    def cmd_new():
        nonlocal current_cmd
        if messagebox.askyesno("New", "Clear current drawing?"):
            cad.push_undo()
            s = engine.store_ref
            s.lines.clear(); s.circles.clear(); s.arcs.clear(); s.rects.clear(); s.texts.clear(); s.ellipses.clear()
            cad.push_undo()
            draw_canvas()
            append_history("New: cleared drawing")
            current_cmd = None

    def cmd_open():
        fn = filedialog.askopenfilename(title="Open DXF", filetypes=[("DXF files","*.dxf"),("All files","*.*")])
        if not fn: return
        try:
            load_dxf_file(fn, engine, cad)
            cmd_zoom_extents()
            draw_canvas()
            append_history(f"Loaded {os.path.basename(fn)}")
        except Exception as e:
            messagebox.showerror("Open Error", str(e))

    def cmd_save():
        fn = filedialog.asksaveasfilename(title="Save DXF", defaultextension=".dxf", filetypes=[("DXF files","*.dxf"),("All files","*.*")])
        if not fn: return
        try:
            save_dxf_file(fn, engine)
            append_history(f"Saved {os.path.basename(fn)}")
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    # Undo / Redo commands (added)
    def cmd_undo():
        cad.undo()
        draw_canvas()
        append_history("Undo")

    def cmd_redo():
        cad.redo()
        draw_canvas()
        append_history("Redo")

    def cmd_zoom_extents(padding=0.95):
        nonlocal view_scale, view_tx, view_ty
        sref = engine.store_ref
        minx, miny, maxx, maxy = sref.bounding_box(sampling=64)
        if maxx - minx < 1e-9 or maxy - miny < 1e-9:
            view_scale = 1.0
            view_tx = (canvas.winfo_width() or 800) / 2.0 - 0.0 * view_scale
            view_ty = (canvas.winfo_height() or 600) / 2.0 - 0.0 * view_scale
            draw_canvas()
            append_history("Zoom Extents: empty drawing, centered at origin")
            return
        cw = canvas.winfo_width() or 800
        ch = canvas.winfo_height() or 600
        world_w = maxx - minx
        world_h = maxy - miny
        sx = cw / world_w
        sy = ch / world_h
        new_scale = min(sx, sy) * padding
        if new_scale <= 0:
            new_scale = 1.0
        world_cx = (minx + maxx) / 2.0
        world_cy = (miny + maxy) / 2.0
        view_scale = new_scale
        view_tx = cw / 2.0 - world_cx * view_scale
        view_ty = ch / 2.0 - world_cy * view_scale
        draw_canvas()
        append_history("Zoom Extents applied")

    # --- drawing primitives (interactive) ---
    temp_preview = {'id': None}

    def clear_temp_preview():
        if temp_preview['id'] is not None:
            try: canvas.delete(temp_preview['id'])
            except Exception: pass
            temp_preview['id'] = None

    def clear_osnap_preview():
        if osnap_preview['id'] is not None:
            try: canvas.delete(osnap_preview['id'])
            except Exception: pass
            osnap_preview['id'] = None
            osnap_preview['pt'] = None

    def start_line_command():
        nonlocal current_cmd
        cad.push_undo()
        current_cmd = 'line'
        append_history("Line: click start, drag, release to place")

    def on_left_down_line(event):
        nonlocal move_origin, last_mouse
        move_origin = left_click_generic_point(event)
        last_mouse = (event.x, event.y)

    def on_mouse_drag_line(event):
        clear_temp_preview()
        if move_origin is None: return
        sx1,sy1 = world_to_screen(*move_origin)
        sx2,sy2 = event.x, event.y
        temp_preview['id'] = canvas.create_line(sx1,sy1,sx2,sy2, fill='blue', dash=(4,2))

    def on_left_up_line(event):
        nonlocal current_cmd, move_origin
        if move_origin is None:
            current_cmd = None; return
        p2 = left_click_generic_point(event)
        engine.add_lines(move_origin[0], move_origin[1], p2[0], p2[1], layer=cad.active_layer)
        cad.push_undo()
        move_origin = None
        current_cmd = None
        clear_temp_preview()
        draw_canvas()
        append_history("Line created")

    def start_rect_command():
        nonlocal current_cmd
        cad.push_undo()
        current_cmd = 'rect'
        append_history("Rectangle: click first corner, drag, release to place")

    def on_left_down_rect(event):
        nonlocal move_origin, last_mouse
        move_origin = left_click_generic_point(event)
        last_mouse = (event.x, event.y)

    def on_mouse_drag_rect(event):
        clear_temp_preview()
        if move_origin is None: return
        p = screen_to_world(event.x, event.y)
        x1,y1 = move_origin
        x2,y2 = p
        sx1,sy1 = world_to_screen(x1,y1)
        sx2,sy2 = world_to_screen(x2,y2)
        temp_preview['id'] = canvas.create_rectangle(sx1,sy1,sx2,sy2, outline='blue', dash=(4,2))

    def on_left_up_rect(event):
        nonlocal current_cmd, move_origin
        if move_origin is None:
            current_cmd = None; return
        p2 = left_click_generic_point(event)
        x1,y1 = move_origin
        x2,y2 = p2
        x = min(x1,x2); y = min(y1,y2)
        w = abs(x2-x1); h = abs(y2-y1)
        engine.add_rects(x, y, w, h, layer=cad.active_layer)
        cad.push_undo()
        move_origin = None
        current_cmd = None
        clear_temp_preview()
        draw_canvas()
        append_history("Rectangle created")

    def start_circle_command():
        nonlocal current_cmd
        cad.push_undo()
        current_cmd = 'circle'
        append_history("Circle: click center, drag to set radius")

    def on_left_down_circle(event):
        nonlocal move_origin, last_mouse
        move_origin = left_click_generic_point(event)
        last_mouse = (event.x, event.y)

    def on_mouse_drag_circle(event):
        clear_temp_preview()
        if move_origin is None: return
        cur = screen_to_world(event.x, event.y)
        r = math.hypot(cur[0]-move_origin[0], cur[1]-move_origin[1])
        sx,sy = world_to_screen(move_origin[0], move_origin[1])
        rr = r * view_scale
        temp_preview['id'] = canvas.create_oval(sx-rr, sy-rr, sx+rr, sy+rr, outline='blue', dash=(4,2))

    def on_left_up_circle(event):
        nonlocal current_cmd, move_origin
        if move_origin is None:
            current_cmd = None; return
        cur = screen_to_world(event.x, event.y)
        r = math.hypot(cur[0]-move_origin[0], cur[1]-move_origin[1])
        engine.add_circles(move_origin[0], move_origin[1], r, layer=cad.active_layer)
        cad.push_undo()
        move_origin = None
        current_cmd = None
        clear_temp_preview()
        draw_canvas()
        append_history("Circle created")

    def start_arc_command():
        nonlocal current_cmd, arc_points
        cad.push_undo()
        current_cmd = 'arc'
        arc_points = []
        append_history("Arc: click start, click a point on arc, click end")

    def on_left_down_arc(event):
        nonlocal arc_points, current_cmd
        p = left_click_generic_point(event)
        arc_points.append(p)
        if len(arc_points) == 3:
            try:
                cx,cy,r = circle_from_3pts(arc_points[0], arc_points[1], arc_points[2])
                st = math.atan2(arc_points[0][1]-cy, arc_points[0][0]-cx)
                mid_ang = math.atan2(arc_points[1][1]-cy, arc_points[1][0]-cx)
                ed = math.atan2(arc_points[2][1]-cy, arc_points[2][0]-cx)
                if not angle_between_ccw(st, mid_ang, ed):
                    st, ed = ed, st
                engine.add_arcs(cx, cy, r, st, ed, layer=cad.active_layer)
                cad.push_undo()
                append_history("Arc created")
            except Exception as e:
                append_history(f"Arc error: {e}")
            arc_points = []
            current_cmd = None
            clear_temp_preview()
            draw_canvas()

    # --- Added: rubber-banding preview for arc ---
    def on_mouse_drag_arc(event):
        clear_temp_preview()
        if not arc_points:
            return
        cur = left_click_generic_point(event)
        if len(arc_points) == 1:
            # show line from start to current
            sx1,sy1 = world_to_screen(*arc_points[0])
            sx2,sy2 = world_to_screen(*cur)
            temp_preview['id'] = canvas.create_line(sx1,sy1,sx2,sy2, fill='blue', dash=(4,2))
        elif len(arc_points) == 2:
            # attempt to show arc passing through start, second, and current
            try:
                cx,cy,r = circle_from_3pts(arc_points[0], arc_points[1], cur)
                st = math.atan2(arc_points[0][1]-cy, arc_points[0][0]-cx)
                mid_ang = math.atan2(arc_points[1][1]-cy, arc_points[1][0]-cx)
                ed = math.atan2(cur[1]-cy, cur[0]-cx)
                if not angle_between_ccw(st, mid_ang, ed):
                    st, ed = ed, st
                steps = max(4, int(64 * abs(ed-st) / (2*math.pi)))
                pts = []
                for k in range(steps):
                    t = st + (ed-st) * k / max(1, steps-1)
                    x = cx + r*math.cos(t); y = cy + r*math.sin(t)
                    pts.append(world_to_screen(x,y))
                flat = [coord for p in pts for coord in p]
                if flat:
                    temp_preview['id'] = canvas.create_line(*flat, fill='blue', dash=(4,2), smooth=True)
            except Exception:
                # fallback: draw polyline through the three points
                sx1,sy1 = world_to_screen(*arc_points[0])
                sx2,sy2 = world_to_screen(*arc_points[1])
                sx3,sy3 = world_to_screen(*cur)
                temp_preview['id'] = canvas.create_line(sx1,sy1,sx2,sy2,sx3,sy3, fill='blue', dash=(4,2))

    def start_ellipse_command():
        nonlocal current_cmd, ellipse_points
        cad.push_undo()
        current_cmd = 'ellipse'
        ellipse_points = []
        append_history("Ellipse: click center, click major-axis point, click minor-axis point")

    def on_left_down_ellipse(event):
        nonlocal ellipse_points, current_cmd
        p = left_click_generic_point(event)
        ellipse_points.append(p)
        if len(ellipse_points) == 3:
            cx,cy = ellipse_points[0]
            majx,majy = ellipse_points[1]
            minx,miny = ellipse_points[2]
            rx = math.hypot(majx-cx, majy-cy)
            ry = math.hypot(minx-cx, miny-cy)
            rot = math.atan2(majy-cy, majx-cx)
            engine.add_ellipses(cx,cy,rx,ry,rot, layer=cad.active_layer)
            cad.push_undo()
            ellipse_points = []
            current_cmd = None
            clear_temp_preview()
            draw_canvas()
            append_history("Ellipse created")

    # --- Added: rubber-banding preview for ellipse ---
    def on_mouse_drag_ellipse(event):
        clear_temp_preview()
        if not ellipse_points:
            return
        cur = left_click_generic_point(event)
        if len(ellipse_points) == 1:
            # show major-axis line from center to current
            sx1,sy1 = world_to_screen(*ellipse_points[0])
            sx2,sy2 = world_to_screen(*cur)
            temp_preview['id'] = canvas.create_line(sx1,sy1,sx2,sy2, fill='blue', dash=(4,2))
        elif len(ellipse_points) == 2:
            # show ellipse preview using center, major point, and current as minor
            cx,cy = ellipse_points[0]
            majx,majy = ellipse_points[1]
            rx = math.hypot(majx-cx, majy-cy)
            ry = math.hypot(cur[0]-cx, cur[1]-cy)
            rot = math.atan2(majy-cy, majx-cx)
            steps = 64
            pts = []
            for k in range(steps):
                t = 2*math.pi * k / steps
                x = cx + rx*math.cos(t)*math.cos(rot) - ry*math.sin(t)*math.sin(rot)
                y = cy + rx*math.cos(t)*math.sin(rot) + ry*math.sin(t)*math.cos(rot)
                pts.append(world_to_screen(x,y))
            flat = [coord for p in pts for coord in p]
            if flat:
                temp_preview['id'] = canvas.create_line(*flat, fill='blue', dash=(4,2), smooth=True)

    def start_polygon_command():
        nonlocal current_cmd, polygon_pts
        cad.push_undo()
        current_cmd = 'polygon'
        polygon_pts = []
        append_history("Polygon: click vertices, double-click to close")

    def on_left_down_polygon(event):
        nonlocal polygon_pts
        p = left_click_generic_point(event)
        polygon_pts.append(p)
        sx,sy = world_to_screen(p[0], p[1])
        canvas.create_oval(sx-3,sy-3,sx+3,sy+3, fill='blue')

    # --- Added: rubber-banding preview for polygon (line from last vertex to mouse) ---
    def on_mouse_drag_polygon(event):
        clear_temp_preview()
        if not polygon_pts:
            return
        cur = left_click_generic_point(event)
        last = polygon_pts[-1]
        sx1,sy1 = world_to_screen(last[0], last[1])
        sx2,sy2 = world_to_screen(cur[0], cur[1])
        temp_preview['id'] = canvas.create_line(sx1,sy1,sx2,sy2, fill='blue', dash=(4,2))

    def finish_polygon():
        nonlocal polygon_pts, current_cmd
        if len(polygon_pts) < 3:
            append_history("Polygon needs at least 3 vertices")
            polygon_pts = []
            current_cmd = None
            clear_temp_preview()
            return
        for i in range(len(polygon_pts)):
            x1,y1 = polygon_pts[i]
            x2,y2 = polygon_pts[(i+1)%len(polygon_pts)]
            engine.add_lines(x1,y1,x2,y2, layer=cad.active_layer)
        cad.push_undo()
        polygon_pts = []
        current_cmd = None
        clear_temp_preview()
        draw_canvas()
        append_history("Polygon created")

    def start_text_command():
        nonlocal current_cmd
        current_cmd = 'text'
        append_history("Text: click to place text")

    def on_left_down_text(event):
        p = left_click_generic_point(event)
        txt = simpledialog.askstring("Text", "Enter text:")
        if txt is None: return
        engine.add_text(p[0], p[1], txt, layer=cad.active_layer)
        cad.push_undo()
        draw_canvas()
        append_history("Text added")
        current_cmd = None

    def start_move_command():
        nonlocal current_cmd
        if not selection:
            append_history("Select an object first (click to select)")
            current_cmd = 'select_for_move'
        else:
            cad.push_undo()
            current_cmd = 'move'
            append_history("Move: click origin, drag to move, release to apply")

    def start_copy_command():
        nonlocal current_cmd, copied_entries, copy_initial_positions
        if not selection:
            append_history("Select an object first (click to select)")
            current_cmd = 'select_for_copy'
            return
        cad.push_undo()
        copied_entries = _duplicate_selection_entries(selection)
        copy_initial_positions = {}
        sref = engine.store_ref
        for ent in copied_entries:
            typ,i,j = ent
            if typ == 'line':
                e = sref.lines[i]
                copy_initial_positions[ent] = (e['x1'][j], e['y1'][j], e['x2'][j], e['y2'][j])
            elif typ == 'circle':
                e = sref.circles[i]
                copy_initial_positions[ent] = (e['cx'][j], e['cy'][j])
            elif typ == 'rect':
                e = sref.rects[i]
                copy_initial_positions[ent] = (e['x'][j], e['y'][j], e['w'][j], e['h'][j])
            elif typ == 'text':
                e = sref.texts[i]
                copy_initial_positions[ent] = (e['x'][j], e['y'][j])
            elif typ == 'ellipse':
                e = sref.ellipses[i]
                copy_initial_positions[ent] = (e['cx'][j], e['cy'][j])
            elif typ == 'arc':
                e = sref.arcs[i]
                copy_initial_positions[ent] = (e['cx'][j], e['cy'][j], e['r'][j], e['start'][j], e['end'][j])
        current_cmd = 'copy'
        append_history("Copy: drag to move copies")

    def start_erase_command():
        nonlocal current_cmd
        if selection:
            cad.push_undo()
            _erase_selection()
            draw_canvas()
            append_history("Erased selection")
            current_cmd = None
            return
        current_cmd = 'erase'
        append_history("Erase: click object to erase")

    def _erase_selection():
        sref = engine.store_ref
        removals = {'lines': [], 'circles': [], 'rects': [], 'texts': [], 'ellipses': [], 'arcs': []}
        for typ,i,j in selection:
            if typ == 'line':
                removals['lines'].append((i,j))
            elif typ == 'circle':
                removals['circles'].append((i,j))
            elif typ == 'rect':
                removals['rects'].append((i,j))
            elif typ == 'text':
                removals['texts'].append((i,j))
            elif typ == 'ellipse':
                removals['ellipses'].append((i,j))
            elif typ == 'arc':
                removals['arcs'].append((i,j))
        def _remove_from_store(store_list, keys, idx_pairs):
            by_store = {}
            for si, ei in idx_pairs:
                by_store.setdefault(si, []).append(ei)
            to_delete_store_indices = []
            for si, eis in by_store.items():
                if si < 0 or si >= len(store_list):
                    continue
                entry = store_list[si]
                for ei in sorted(eis, reverse=True):
                    for k in keys:
                        if k in entry and ei < len(entry[k]):
                            entry[k].pop(ei)
                first_key = keys[0]
                if not entry.get(first_key):
                    to_delete_store_indices.append(si)
            for si in sorted(to_delete_store_indices, reverse=True):
                if 0 <= si < len(store_list):
                    store_list.pop(si)
        _remove_from_store(sref.lines, ['x1','y1','x2','y2'], removals['lines'])
        _remove_from_store(sref.circles, ['cx','cy','r'], removals['circles'])
        _remove_from_store(sref.rects, ['x','y','w','h','rx','ry','rot'], removals['rects'])
        _remove_from_store(sref.texts, ['x','y','text','rot'], removals['texts'])
        _remove_from_store(sref.ellipses, ['cx','cy','rx','ry','rot'], removals['ellipses'])
        _remove_from_store(sref.arcs, ['cx','cy','r','start','end'], removals['arcs'])
        selection.clear()

    def apply_translation_to_selection(dx, dy, make_copy=False):
        sref = engine.store_ref
        if make_copy:
            for typ,i,j in selection:
                if typ == 'line':
                    e = sref.lines[i]
                    x1,y1 = e['x1'][j], e['y1'][j]; x2,y2 = e['x2'][j], e['y2'][j]
                    layer = e.get('style', {}).get('layer', cad.active_layer)
                    engine.add_lines(x1+dx, y1+dy, x2+dx, y2+dy, layer=layer)
                elif typ == 'circle':
                    e = sref.circles[i]
                    cx,cy,r = e['cx'][j], e['cy'][j], e['r'][j]
                    layer = e.get('style', {}).get('layer', cad.active_layer)
                    engine.add_circles(cx+dx, cy+dy, r, layer=layer)
                elif typ == 'rect':
                    e = sref.rects[i]
                    x,y,w,h = e['x'][j], e['y'][j], e['w'][j], e['h'][j]
                    rot = e.get('rot', [0])[j] if 'rot' in e else 0.0
                    layer = e.get('style', {}).get('layer', cad.active_layer)
                    engine.add_rects(x+dx, y+dy, w, h, layer=layer)
                    new_i = len(sref.rects) - 1
                    new_j = len(sref.rects[new_i]['x']) - 1
                    if 'rot' in sref.rects[new_i]:
                        sref.rects[new_i]['rot'][new_j] = rot
                elif typ == 'text':
                    e = sref.texts[i]
                    x,y = e['x'][j], e['y'][j]; t = e['text'][j]
                    size = e.get('size',12)
                    rot = e.get('rot', [0])[j] if 'rot' in e else 0.0
                    layer = e.get('style', {}).get('layer', cad.active_layer)
                    engine.add_text(x+dx, y+dy, t, size=size, layer=layer)
                    new_i = len(sref.texts) - 1
                    new_j = len(sref.texts[new_i]['x']) - 1
                    if 'rot' in sref.texts[new_i]:
                        sref.texts[new_i]['rot'][new_j] = rot
                elif typ == 'ellipse':
                    e = sref.ellipses[i]
                    cx,cy,rx_e,ry_e,rot = e['cx'][j], e['cy'][j], e['rx'][j], e['ry'][j], e['rot'][j]
                    layer = e.get('style', {}).get('layer', cad.active_layer)
                    engine.add_ellipses(cx+dx, cy+dy, rx_e, ry_e, rot, layer=layer)
                elif typ == 'arc':
                    e = sref.arcs[i]
                    cx,cy,r,st,ed = e['cx'][j], e['cy'][j], e['r'][j], e['start'][j], e['end'][j]
                    layer = e.get('style', {}).get('layer', cad.active_layer)
                    engine.add_arcs(cx+dx, cy+dy, r, st, ed, layer=layer)
        else:
            trans = translation(dx, dy)
            engine.transform(trans)

    def on_left_down_select_move_copy(event):
        nonlocal move_origin, last_mouse
        move_origin = left_click_generic_point(event)
        last_mouse = (event.x, event.y)

    def on_mouse_drag_move(event):
        nonlocal last_mouse
        if move_origin is None: return
        prev = screen_to_world(last_mouse[0], last_mouse[1])
        cur = screen_to_world(event.x, event.y)
        dx = cur[0]-prev[0]; dy = cur[1]-prev[1]
        if current_cmd == 'copy' and copied_entries:
            # translate only the copied entries incrementally
            _translate_entries(copied_entries, dx, dy)
        else:
            # Modified: Move should operate on selected primitives only (not whole drawing)
            if selection:
                _translate_entries(selection, dx, dy)
            else:
                trans = translation(dx, dy)
                engine.transform(trans)
        last_mouse = (event.x, event.y)
        draw_canvas()

    def on_left_up_move(event):
        nonlocal current_cmd, move_origin
        if move_origin is None:
            current_cmd = None; return
        cad.push_undo()
        move_origin = None
        current_cmd = None
        draw_canvas()
        append_history("Move applied")

    def on_left_up_copy(event):
        nonlocal current_cmd, move_origin, copied_entries, copy_initial_positions
        if move_origin is None:
            current_cmd = None; return
        cad.push_undo()
        move_origin = None
        current_cmd = None
        copied_entries = []
        copy_initial_positions = {}
        draw_canvas()
        append_history("Copy applied")

    def on_left_down_erase(event):
        if selection:
            cad.push_undo()
            _erase_selection()
            draw_canvas()
            append_history("Erased selection")
            return
        p = left_click_generic_point(event)
        picked = pick_primitive(p)
        if not picked:
            append_history("Nothing to erase")
            return
        typ,i,j = picked
        sref = engine.store_ref
        cad.push_undo()
        if typ == 'line':
            e = sref.lines[i]
            for k in ('x1','y1','x2','y2'):
                e[k].pop(j)
            if not e['x1']:
                sref.lines.pop(i)
        elif typ == 'circle':
            e = sref.circles[i]
            for k in ('cx','cy','r'):
                e[k].pop(j)
            if not e['cx']:
                sref.circles.pop(i)
        elif typ == 'rect':
            e = sref.rects[i]
            for k in ('x','y','w','h','rx','ry','rot'):
                if k in e:
                    e[k].pop(j)
            if not e['x']:
                sref.rects.pop(i)
        elif typ == 'text':
            e = sref.texts[i]
            for k in ('x','y','text','rot'):
                if k in e:
                    e[k].pop(j)
            if not e['x']:
                sref.texts.pop(i)
        elif typ == 'ellipse':
            e = sref.ellipses[i]
            for k in ('cx','cy','rx','ry','rot'):
                e[k].pop(j)
            if not e['cx']:
                sref.ellipses.pop(i)
        elif typ == 'arc':
            e = sref.arcs[i]
            for k in ('cx','cy','r','start','end'):
                e[k].pop(j)
            if not e['cx']:
                sref.arcs.pop(i)
        draw_canvas()
        append_history("Erased selected primitive")

    def start_rotate_command():
        nonlocal current_cmd
        if not selection:
            append_history("No selection to rotate")
            return
        cad.push_undo()
        current_cmd = 'rotate'
        append_history("Rotate: click to set center, drag to set angle, release to apply")

    def on_left_down_rotate(event):
        nonlocal move_origin, last_mouse
        move_origin = left_click_generic_point(event)
        last_mouse = (event.x, event.y)

    def on_mouse_drag_rotate(event):
        nonlocal last_mouse
        if move_origin is None: return
        cx, cy = move_origin
        prev_w = screen_to_world(last_mouse[0], last_mouse[1])
        cur_w  = screen_to_world(event.x, event.y)
        ang_prev = math.atan2(prev_w[1]-cy, prev_w[0]-cx)
        ang_cur  = math.atan2(cur_w[1]-cy, cur_w[0]-cx)
        angle = ang_cur - ang_prev
        rot = rotation(angle)
        trans = _mat_mul(_mat_mul(translation(cx,cy), rot), translation(-cx,-cy))
        # Modified: apply rotation to selection only
        if selection:
            _transform_entries(selection, trans)
        else:
            engine.transform(trans)
        last_mouse = (event.x, event.y)
        draw_canvas()

    def on_left_up_rotate(event):
        nonlocal current_cmd, move_origin
        if move_origin is None:
            current_cmd = None
            return
        cad.push_undo()
        move_origin = None
        current_cmd = None
        draw_canvas()
        append_history("Rotate applied")

    def start_scale_command():
        nonlocal current_cmd
        if not selection:
            append_history("No selection to scale")
            return
        cad.push_undo()
        current_cmd = 'scale'
        append_history("Scale: click to set origin, drag to set scale factor, release to apply")

    def on_left_down_scale(event):
        nonlocal move_origin, last_mouse
        move_origin = left_click_generic_point(event)
        last_mouse = (event.x, event.y)

    def on_mouse_drag_scale(event):
        nonlocal last_mouse
        if move_origin is None: return
        ox, oy = move_origin
        prev_w = screen_to_world(last_mouse[0], last_mouse[1])
        cur_w  = screen_to_world(event.x, event.y)
        d_prev = max(1e-6, math.hypot(prev_w[0]-ox, prev_w[1]-oy))
        d_cur  = max(1e-6, math.hypot(cur_w[0]-ox, cur_w[1]-oy))
        factor = d_cur / d_prev
        s_mat = scale(factor)
        trans = _mat_mul(_mat_mul(translation(ox,oy), s_mat), translation(-ox,-oy))
        # Modified: apply scaling to selection only
        if selection:
            _transform_entries(selection, trans)
        else:
            engine.transform(trans)
        last_mouse = (event.x, event.y)
        draw_canvas()

    def on_left_up_scale(event):
        nonlocal current_cmd, move_origin
        if move_origin is None:
            current_cmd = None
            return
        cad.push_undo()
        move_origin = None
        current_cmd = None
        draw_canvas()
        append_history("Scale applied")

    # --- Select command (click or rectangle) ---
    def start_select_command():
        nonlocal current_cmd
        current_cmd = 'select'
        append_history("Select: click to pick or drag to window-select")

    # Primitive picking (simple distance-based)
    def pick_primitive(world_pt, tol=5.0):
        wx,wy = world_pt
        best = None; best_d = tol / max(1.0, view_scale)
        sref = engine.store_ref
        # lines
        for i,e in enumerate(sref.lines):
            for j,(x1,y1,x2,y2) in enumerate(zip(e['x1'], e['y1'], e['x2'], e['y2'])):
                # distance to segment
                dx = x2-x1; dy = y2-y1
                if dx==0 and dy==0:
                    d = math.hypot(wx-x1, wy-y1)
                else:
                    t = ((wx-x1)*dx + (wy-y1)*dy) / (dx*dx+dy*dy)
                    t = max(0.0, min(1.0, t))
                    px = x1 + t*dx; py = y1 + t*dy
                    d = math.hypot(wx-px, wy-py)
                if d < best_d:
                    best_d = d; best = ('line', i, j)
        # circles
        for i,e in enumerate(sref.circles):
            for j,(cx,cy,r) in enumerate(zip(e['cx'], e['cy'], e['r'])):
                d = abs(math.hypot(wx-cx, wy-cy) - r)
                if d < best_d:
                    best_d = d; best = ('circle', i, j)
        # rects (treat as 4 lines, but account for rotation by computing corners)
        for i,e in enumerate(sref.rects):
            for j,(x,y,w,h) in enumerate(zip(e['x'], e['y'], e['w'], e['h'])):
                rot = e.get('rot', [0]*len(e['x']))[j] if 'rot' in e else 0.0
                if rot:
                    cx = x + w/2.0; cy = y + h/2.0
                    pts = []
                    for px,py in ((x,y),(x+w,y),(x+w,y+h),(x,y+h)):
                        dxp = px - cx; dyp = py - cy
                        rx = cx + dxp*math.cos(rot) - dyp*math.sin(rot)
                        ry = cy + dxp*math.sin(rot) + dyp*math.cos(rot)
                        pts.append((rx,ry))
                else:
                    pts = [(x,y),(x+w,y),(x+w,y+h),(x,y+h)]
                for k in range(4):
                    x1,y1 = pts[k]; x2,y2 = pts[(k+1)%4]
                    dx = x2-x1; dy = y2-y1
                    if dx==0 and dy==0:
                        d = math.hypot(wx-x1, wy-y1)
                    else:
                        t = ((wx-x1)*dx + (wy-y1)*dy) / (dx*dx+dy*dy)
                        t = max(0.0, min(1.0, t))
                        px = x1 + t*dx; py = y1 + t*dy
                        d = math.hypot(wx-px, wy-py)
                    if d < best_d:
                        best_d = d; best = ('rect', i, j)
        # texts (point pick)
        for i,e in enumerate(sref.texts):
            for j,(x,y) in enumerate(zip(e['x'], e['y'])):
                d = math.hypot(wx-x, wy-y)
                if d < best_d:
                    best_d = d; best = ('text', i, j)
        # ellipses (approximate by center distance)
        for i,e in enumerate(sref.ellipses):
            for j,(cx,cy,rx,ry,rot) in enumerate(zip(e['cx'], e['cy'], e['rx'], e['ry'], e['rot'])):
                d = math.hypot(wx-cx, wy-cy)
                if d < best_d:
                    best_d = d; best = ('ellipse', i, j)
        # arcs (approximate by arc circle)
        for i,e in enumerate(sref.arcs):
            for j,(cx,cy,r,st,ed) in enumerate(zip(e['cx'], e['cy'], e['r'], e['start'], e['end'])):
                ang = math.atan2(wy-cy, wx-cx)
                if angle_between_ccw(st, ang, ed):
                    d = abs(math.hypot(wx-cx, wy-cy) - r)
                    if d < best_d:
                        best_d = d; best = ('arc', i, j)
        return best

    def left_click_generic_point(event):
        # convert screen to world, apply snap/grid/osnap
        wx,wy = screen_to_world(event.x, event.y)
        # snap to grid if enabled
        if cad.snap_to_grid and cad.grid_enabled and cad.grid_spacing > 0:
            gs = cad.grid_spacing
            wx = round(wx/gs) * gs
            wy = round(wy/gs) * gs
        # Apply osnap: check for nearby snap points (endpoints, midpoints, centers)
        osnap_pt = find_osnap_point(event.x, event.y, engine, view_scale, view_tx, view_ty, cad)
        if osnap_pt is not None:
            # osnap_pt is in world coords already
            wx, wy = osnap_pt
        return (wx, wy)

    # Helpers to compute primitive bounding boxes (world coords)
    def primitive_bbox(typ, i, j, sampling=32):
        sref = engine.store_ref
        if typ == 'line':
            e = sref.lines[i]
            x1,y1 = e['x1'][j], e['y1'][j]; x2,y2 = e['x2'][j], e['y2'][j]
            return (min(x1,x2), min(y1,y2), max(x1,x2), max(y1,y2))
        if typ == 'circle':
            e = sref.circles[i]
            cx,cy,r = e['cx'][j], e['cy'][j], e['r'][j]
            return (cx-r, cy-r, cx+r, cy+r)
        if typ == 'rect':
            e = sref.rects[i]
            x,y,w,h = e['x'][j], e['y'][j], e['w'][j], e['h'][j]
            rot = e.get('rot', [0]*len(e['x']))[j] if 'rot' in e else 0.0
            if rot:
                cx = x + w/2.0; cy = y + h/2.0
                xs=[]; ys=[]
                for px,py in ((x,y),(x+w,y),(x+w,y+h),(x,y+h)):
                    dxp = px - cx; dyp = py - cy
                    rx = cx + dxp*math.cos(rot) - dyp*math.sin(rot)
                    ry = cy + dxp*math.sin(rot) + dyp*math.cos(rot)
                    xs.append(rx); ys.append(ry)
                return (min(xs), min(ys), max(xs), max(ys))
            return (x, y, x+w, y+h)
        if typ == 'text':
            e = sref.texts[i]
            x,y = e['x'][j], e['y'][j]
            # treat text as small bbox around point
            s = e.get('size', 12)
            r = max(2.0, s * 0.5)
            return (x-r, y-r, x+r, y+r)
        if typ == 'ellipse':
            e = sref.ellipses[i]
            cx,cy,rx,ry,rot = e['cx'][j], e['cy'][j], e['rx'][j], e['ry'][j], e['rot'][j]
            xs=[]; ys=[]
            steps = max(8, sampling//4)
            for k in range(steps):
                t = 2*math.pi * k / steps
                x = cx + rx*math.cos(t)*math.cos(rot) - ry*math.sin(t)*math.sin(rot)
                y = cy + rx*math.cos(t)*math.sin(rot) + ry*math.sin(t)*math.cos(rot)
                xs.append(x); ys.append(y)
            return (min(xs), min(ys), max(xs), max(ys))
        if typ == 'arc':
            e = sref.arcs[i]
            cx,cy,r,st,ed = e['cx'][j], e['cy'][j], e['r'][j], e['start'][j], e['end'][j]
            xs=[]; ys=[]
            steps = max(4, int(sampling * abs(ed-st) / (2*math.pi)))
            for k in range(steps):
                t = st + (ed-st) * k / max(1, steps-1)
                x = cx + r*math.cos(t); y = cy + r*math.sin(t)
                xs.append(x); ys.append(y)
            return (min(xs), min(ys), max(xs), max(ys))
        return (0,0,0,0)

    def rect_contains(rect, bbox):
        rx0,ry0,rx1,ry1 = rect
        bx0,by0,bx1,by1 = bbox
        return bx0 >= rx0 - 1e-9 and by0 >= ry0 - 1e-9 and bx1 <= rx1 + 1e-9 and by1 <= ry1 + 1e-9

    def rect_intersects(rect, bbox):
        rx0,ry0,rx1,ry1 = rect
        bx0,by0,bx1,by1 = bbox
        return not (bx1 < rx0 or bx0 > rx1 or by1 < ry0 or by0 > ry1)

    def perform_selection_by_rect(world_rect):
        """
        world_rect: (x0,y0,x1,y1) in world coords where x0<=x1 and y0<=y1
        Determine window vs crossing based on drag direction:
          - If user dragged left-to-right (screen x2 > x1) -> window (fully inside)
          - If right-to-left -> crossing (intersect)
        The calling code will set selection accordingly.
        """
        # This function is not used directly; selection logic is in canvas handlers where drag direction is known.
        pass

    def draw_canvas():
        canvas.delete('all')
        # draw grid
        if cad.grid_enabled and cad.grid_spacing > 0:
            cw = canvas.winfo_width() or 800
            ch = canvas.winfo_height() or 600
            # compute world bounds visible
            left_top = screen_to_world(0,0)
            right_bottom = screen_to_world(cw,ch)
            x0 = math.floor(min(left_top[0], right_bottom[0]) / cad.grid_spacing) * cad.grid_spacing
            x1 = math.ceil(max(left_top[0], right_bottom[0]) / cad.grid_spacing) * cad.grid_spacing
            y0 = math.floor(min(left_top[1], right_bottom[1]) / cad.grid_spacing) * cad.grid_spacing
            y1 = math.ceil(max(left_top[1], right_bottom[1]) / cad.grid_spacing) * cad.grid_spacing
            for gx in frange(x0, x1, cad.grid_spacing):
                sx1,sy1 = world_to_screen(gx, y0)
                sx2,sy2 = world_to_screen(gx, y1)
                canvas.create_line(sx1,sy1,sx2,sy2, fill='#eee')
            for gy in frange(y0, y1, cad.grid_spacing):
                sx1,sy1 = world_to_screen(x0, gy)
                sx2,sy2 = world_to_screen(x1, gy)
                canvas.create_line(sx1,sy1,sx2,sy2, fill='#eee')
        # helper to check selection membership
        def is_selected(typ, idx, subidx):
            return (typ, idx, subidx) in selection
        # draw primitives with highlight for selected ones
        sref = engine.store_ref
        for i,e in enumerate(sref.lines):
            style = e.get('style', {})
            color = style.get('stroke', style.get('color', 'black'))
            width = style.get('stroke_width', style.get('stroke-width', 1))
            for j,(x1,y1,x2,y2) in enumerate(zip(e['x1'], e['y1'], e['x2'], e['y2'])):
                sx1,sy1 = world_to_screen(x1,y1)
                sx2,sy2 = world_to_screen(x2,y2)
                if is_selected('line', i, j):
                    # highlight: thicker red line with a subtle glow (drawn twice)
                    canvas.create_line(sx1,sy1,sx2,sy2, fill='red', width=max(3, int(width)+2))
                    canvas.create_line(sx1,sy1,sx2,sy2, fill=color, width=width)
                else:
                    canvas.create_line(sx1,sy1,sx2,sy2, fill=color, width=width)
        for i,e in enumerate(sref.circles):
            style = e.get('style', {})
            color = style.get('stroke', style.get('color', 'black'))
            width = style.get('stroke_width', style.get('stroke-width', 1))
            for j,(cx,cy,r) in enumerate(zip(e['cx'], e['cy'], e['r'])):
                sx,sy = world_to_screen(cx,cy)
                rr = r * view_scale
                if is_selected('circle', i, j):
                    # highlight: red outline (no fill)
                    canvas.create_oval(sx-rr, sy-rr, sx+rr, sy+rr, outline='red', width=max(3, int(width)+2))
                    canvas.create_oval(sx-rr, sy-rr, sx+rr, sy+rr, outline=color, width=width)
                else:
                    canvas.create_oval(sx-rr, sy-rr, sx+rr, sy+rr, outline=color, width=width)
        for i,e in enumerate(sref.arcs):
            style = e.get('style', {})
            color = style.get('stroke', style.get('color', 'black'))
            width = style.get('stroke_width', style.get('stroke-width', 1))
            for j,(cx,cy,r,st,ed) in enumerate(zip(e['cx'], e['cy'], e['r'], e['start'], e['end'])):
                steps = max(2, int(64 * abs(ed-st) / (2*math.pi)))
                pts = []
                for k in range(steps):
                    t = st + (ed-st) * k / max(1, steps-1)
                    x = cx + r*math.cos(t); y = cy + r*math.sin(t)
                    pts.append(world_to_screen(x,y))
                flat = [coord for p in pts for coord in p]
                if flat:
                    if is_selected('arc', i, j):
                        canvas.create_line(*flat, fill='red', width=max(3, int(width)+2), smooth=True)
                        canvas.create_line(*flat, fill=color, width=width, smooth=True)
                    else:
                        canvas.create_line(*flat, fill=color, width=width, smooth=True)
        for i,e in enumerate(sref.rects):
            style = e.get('style', {})
            color = style.get('stroke', style.get('color', 'black'))
            width = style.get('stroke_width', style.get('stroke-width', 1))
            for j,(x,y,w,h,rx,ry) in enumerate(zip(e['x'], e['y'], e['w'], e['h'], e['rx'], e['ry'])):
                rot = e.get('rot', [0]*len(e['x']))[j] if 'rot' in e else 0.0
                if rot:
                    # compute rotated corners and draw polygon
                    cx = x + w/2.0; cy = y + h/2.0
                    corners = []
                    for px,py in ((x,y),(x+w,y),(x+w,y+h),(x,y+h)):
                        dxp = px - cx; dyp = py - cy
                        rxp = cx + dxp*math.cos(rot) - dyp*math.sin(rot)
                        ryp = cy + dxp*math.sin(rot) + dyp*math.cos(rot)
                        corners.append(world_to_screen(rxp, ryp))
                    flat = [coord for p in corners for coord in p]
                    if is_selected('rect', i, j):
                        # outline highlight polygon (no fill)
                        try:
                            temp_id = canvas.create_polygon(*flat, outline='red', width=max(3, int(width)+2), fill='')
                        except Exception:
                            temp_id = canvas.create_polygon(*flat, outline='red', width=max(3, int(width)+2), fill='')
                        canvas.create_polygon(*flat, outline=color, width=width, fill='')
                    else:
                        canvas.create_polygon(*flat, outline=color, width=width, fill='')
                else:
                    sx1,sy1 = world_to_screen(x,y)
                    sx2,sy2 = world_to_screen(x+w,y+h)
                    if is_selected('rect', i, j):
                        canvas.create_rectangle(sx1,sy1,sx2,sy2, outline='red', width=max(3, int(width)+2))
                        canvas.create_rectangle(sx1,sy1,sx2,sy2, outline=color, width=width)
                    else:
                        canvas.create_rectangle(sx1,sy1,sx2,sy2, outline=color, width=width)
        # ---- Text drawing: now respects stored rotation like other primitives ----
        for i,e in enumerate(sref.texts):
            style = e.get('style', {})
            color = style.get('fill', 'black')
            # get rotation list (default zeros)
            rots = e.get('rot', [0]*len(e['x']))
            for j,(x,y,t,size,anchor) in enumerate(zip(e['x'], e['y'], e['text'], repeat(e['size'], len(e['x'])), repeat(e['anchor'], len(e['x'])))):
                sx,sy = world_to_screen(x,y)
                # Keep on-screen text height constant during zoom:
                try:
                    # ensure numeric
                    sz = float(size)
                except Exception:
                    sz = float(DEFAULT_TEXT_SIZE)
                # compute screen font size that lets text scale with the view (world-space size * view_scale)
                screen_font_size = max(1, int(round(sz * view_scale)))
                # rotation for text is stored and exported to SVG; now we also render rotated text on the Tk canvas
                rot = rots[j] if j < len(rots) else 0.0
                if is_selected('text', i, j):
                    # draw a rotated highlight rectangle behind text if rotated, otherwise axis-aligned
                    try:
                        bbox_w = max(10, screen_font_size * len(str(t)) * 0.5)
                        bbox_h = max(10, screen_font_size * 1.2)
                        if rot:
                            # compute rotated rectangle corners in screen space
                            rad = rot
                            cosr = math.cos(rad); sinr = math.sin(rad)
                            hw = bbox_w / 2.0; hh = bbox_h / 2.0
                            corners = [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]
                            pts = []
                            for dx, dy in corners:
                                rx = sx + dx * cosr - dy * sinr
                                ry = sy + dx * sinr + dy * cosr
                                pts.append((rx, ry))
                            flat = [coord for p in pts for coord in p]
                            try:
                                canvas.create_polygon(*flat, fill='#fff3b0', outline='red')
                            except Exception:
                                canvas.create_polygon(*flat, outline='red')
                        else:
                            canvas.create_rectangle(sx- bbox_w/2, sy - bbox_h/2, sx + bbox_w/2, sy + bbox_h/2, fill='#fff3b0', outline='red')
                    except Exception:
                        pass
                    # draw rotated text if rotation present
                    if rot:
                        deg = math.degrees(rot)
                        try:
                            canvas.create_text(sx, sy, text=str(t), fill=color, font=("Arial", screen_font_size), anchor=anchor, angle=deg)
                        except Exception:
                            # fallback if 'angle' not supported: draw unrotated text (rotation still preserved in data and SVG)
                            canvas.create_text(sx, sy, text=str(t), fill=color, font=("Arial", screen_font_size), anchor=anchor)
                    else:
                        canvas.create_text(sx,sy, text=str(t), fill=color, font=("Arial", screen_font_size), anchor=anchor)
                else:
                    if rot:
                        deg = math.degrees(rot)
                        try:
                            canvas.create_text(sx, sy, text=str(t), fill=color, font=("Arial", screen_font_size), anchor=anchor, angle=deg)
                        except Exception:
                            canvas.create_text(sx,sy, text=str(t), fill=color, font=("Arial", screen_font_size), anchor=anchor)
                    else:
                        canvas.create_text(sx,sy, text=str(t), fill=color, font=("Arial", screen_font_size), anchor=anchor)
        # ---- end text drawing ----
        for i,e in enumerate(sref.ellipses):
            style = e.get('style', {})
            color = style.get('stroke', style.get('color', 'black'))
            width = style.get('stroke_width', style.get('stroke-width', 1))
            for j,(cx,cy,rx,ry,rot) in enumerate(zip(e['cx'], e['cy'], e['rx'], e['ry'], e['rot'])):
                # approximate ellipse by polygon
                steps = 64
                pts = []
                for k in range(steps):
                    t = 2*math.pi * k / steps
                    x = cx + rx*math.cos(t)*math.cos(rot) - ry*math.sin(t)*math.sin(rot)
                    y = cy + rx*math.cos(t)*math.sin(rot) + ry*math.sin(t)*math.cos(rot)
                    pts.append(world_to_screen(x,y))
                flat = [coord for p in pts for coord in p]
                if flat:
                    if is_selected('ellipse', i, j):
                        canvas.create_line(*flat, fill='red', width=max(3, int(width)+2), smooth=True)
                        canvas.create_line(*flat, fill=color, width=width, smooth=True)
                    else:
                        canvas.create_line(*flat, fill=color, width=width, smooth=True)
        # draw selection highlight (simple bounding boxes for any remaining selection entries not already visually emphasized)
        for typ,i,j in selection:
            try:
                bx0,by0,bx1,by1 = primitive_bbox(typ,i,j)
                sx0,sy0 = world_to_screen(bx0,by0)
                sx1,sy1 = world_to_screen(bx1,by1)
                # draw dashed red rectangle if not already drawn as filled highlight
                canvas.create_rectangle(sx0,sy0,sx1,sy1, outline='red', dash=(3,2))
            except Exception:
                pass
        # If there is an osnap preview point (set by mouse motion), draw it on top
        if osnap_preview.get('pt') is not None:
            try:
                wx, wy = osnap_preview['pt']
                sx, sy = world_to_screen(wx, wy)
                r = max(4, 6)
                # small crosshair and circle to indicate snap
                canvas.create_oval(sx-r, sy-r, sx+r, sy+r, outline='orange', width=2)
                canvas.create_line(sx-8, sy, sx+8, sy, fill='orange', width=1)
                canvas.create_line(sx, sy-8, sx, sy+8, fill='orange', width=1)
            except Exception:
                pass
        # Draw crosshairs and coordinates if mouse position is known
        try:
            if mouse_world is not None and mouse_screen is not None:
                sx, sy = mouse_screen
                cw = canvas.winfo_width() or 800
                ch = canvas.winfo_height() or 600
                # horizontal and vertical crosshair lines
                canvas.create_line(0, sy, cw, sy, fill='#888', dash=(2,2))
                canvas.create_line(sx, 0, sx, ch, fill='#888', dash=(2,2))
                # coordinate text near cursor (offset to avoid overlapping)
                wx, wy = mouse_world
                coord_text = f"({wx:.3f}, {wy:.3f})"
                # measure approximate text size using font metrics is complex; use background rectangle sized by char count
                txt_x = sx + 12
                txt_y = sy + 12
                # background rectangle
                try:
                    # estimate width by characters
                    est_w = max(60, 8 * len(coord_text))
                    est_h = 18
                    canvas.create_rectangle(txt_x-4, txt_y-12, txt_x+est_w, txt_y+est_h-12, fill='white', outline='black')
                except Exception:
                    pass
                canvas.create_text(txt_x+2, txt_y+2, text=coord_text, anchor='nw', fill='black', font=("Arial", 10))
        except Exception:
            pass

    def frange(a, b, step):
        vals = []
        if step == 0: return vals
        x = a
        if step > 0:
            while x <= b + 1e-9:
                vals.append(x); x += step
        else:
            while x >= b - 1e-9:
                vals.append(x); x += step
        return vals

    # Bindings and UI buttons
    tb_button("New", cmd_new)
    tb_button("Open", cmd_open)
    tb_button("Save", cmd_save)
    tb_button("Undo", cmd_undo)
    tb_button("Redo", cmd_redo)
    tb_button("Zoom Extents", cmd_zoom_extents)
    tb_button("Line", start_line_command)
    tb_button("Rect", start_rect_command)
    tb_button("Circle", start_circle_command)
    tb_button("Arc", start_arc_command)
    tb_button("Ellipse", start_ellipse_command)
    tb_button("Polygon", start_polygon_command)
    tb_button("Text", start_text_command)
    tb_button("Move", start_move_command)
    tb_button("Copy", start_copy_command)
    tb_button("Erase", start_erase_command)
    tb_button("Rotate", start_rotate_command)
    tb_button("Scale", start_scale_command)
    tb_button("Select", start_select_command)

    # Mouse wheel handler for zoom (scroll) and middle-button pan (press+drag)
    def on_mouse_wheel(event):
        nonlocal view_scale, view_tx, view_ty
        # Determine delta in a cross-platform way
        if hasattr(event, 'delta') and event.delta != 0:
            d = event.delta
        else:
            # X11: Button-4 (up) / Button-5 (down)
            if getattr(event, 'num', None) == 4:
                d = 120
            elif getattr(event, 'num', None) == 5:
                d = -120
            else:
                d = 0
        # Always zoom centered at mouse position when scrolling
        factor = 1.0 + (d / 120.0) * 0.1
        if factor <= 0:
            factor = 0.01
        # world coordinate under cursor before zoom
        wx, wy = screen_to_world(event.x, event.y)
        new_scale = view_scale * factor
        # clamp scale to reasonable range
        new_scale = max(1e-6, min(new_scale, 1e6))
        # adjust translation so that (wx,wy) remains under cursor
        view_tx = event.x - wx * new_scale
        view_ty = event.y - wy * new_scale
        view_scale = new_scale
        draw_canvas()

    # Middle-button pan handlers
    def on_middle_down(event):
        nonlocal pan_last
        pan_last = (event.x, event.y)

    def on_middle_drag(event):
        nonlocal pan_last, view_tx, view_ty
        if pan_last is None:
            pan_last = (event.x, event.y)
            return
        dx = event.x - pan_last[0]
        dy = event.y - pan_last[1]
        view_tx += dx
        view_ty += dy
        pan_last = (event.x, event.y)
        draw_canvas()

    def on_middle_up(event):
        nonlocal pan_last
        pan_last = None

    # Show nearby osnaps on mouse move (new behavior)
    def on_mouse_move(event):
        nonlocal mouse_world, mouse_screen
        # compute nearest osnap point (if any) and store it for draw_canvas to render
        pt = find_osnap_point(event.x, event.y, engine, view_scale, view_tx, view_ty, cad)
        if pt is not None:
            osnap_preview['pt'] = pt
        else:
            osnap_preview['pt'] = None
        # update mouse world/screen for crosshair & coords
        try:
            mouse_world = screen_to_world(event.x, event.y)
            mouse_screen = (event.x, event.y)
        except Exception:
            mouse_world = None
            mouse_screen = None
        # redraw canvas (osnap marker and crosshair will be drawn on top)
        draw_canvas()

    # Canvas mouse bindings (map to generic handlers depending on current_cmd)
    def canvas_left_down(event):
        nonlocal current_cmd, select_origin, select_rect_id
        # detect Ctrl pressed (platform-dependent bitmask; 0x4 is common for Control)
        ctrl_pressed = (event.state & 0x4) != 0
        if current_cmd == 'line':
            on_left_down_line(event)
        elif current_cmd == 'rect':
            on_left_down_rect(event)
        elif current_cmd == 'circle':
            on_left_down_circle(event)
        elif current_cmd == 'arc':
            on_left_down_arc(event)
        elif current_cmd == 'ellipse':
            on_left_down_ellipse(event)
        elif current_cmd == 'polygon':
            on_left_down_polygon(event)
        elif current_cmd == 'text':
            on_left_down_text(event)
        elif current_cmd in ('move','select_for_move','copy','select_for_copy'):
            on_left_down_select_move_copy(event)
        elif current_cmd == 'erase':
            on_left_down_erase(event)
        elif current_cmd == 'rotate':
            on_left_down_rotate(event)
        elif current_cmd == 'scale':
            on_left_down_scale(event)
        elif current_cmd == 'select':
            # allow immediate single-click selection as well as rectangle selection
            p = left_click_generic_point(event)
            picked = pick_primitive(p)
            if picked:
                # If Ctrl pressed, toggle membership in selection; otherwise replace selection
                if ctrl_pressed:
                    if picked in selection:
                        selection.remove(picked)
                        append_history(f"Unselected {picked}")
                    else:
                        selection.append(picked)
                        append_history(f"Added {picked} to selection")
                else:
                    selection.clear(); selection.append(picked)
                    append_history(f"Selected {picked}")
                draw_canvas()
            # start rectangle selection (support crossing/window)
            select_origin = (event.x, event.y)
            # create preview rectangle
            if select_rect_id is not None:
                try: canvas.delete(select_rect_id)
                except Exception: pass
            select_rect_id = canvas.create_rectangle(event.x, event.y, event.x, event.y, outline='blue', dash=(4,2))
        else:
            # default: pick
            p = left_click_generic_point(event)
            picked = pick_primitive(p)
            if picked:
                # allow Ctrl to add/remove in default pick mode as well
                ctrl_pressed = (event.state & 0x4) != 0
                if ctrl_pressed:
                    if picked in selection:
                        selection.remove(picked)
                        append_history(f"Unselected {picked}")
                    else:
                        selection.append(picked)
                        append_history(f"Added {picked} to selection")
                else:
                    selection.clear(); selection.append(picked)
                    append_history(f"Selected {picked}")
                draw_canvas()

    def canvas_mouse_drag(event):
        nonlocal select_rect_id
        if current_cmd == 'line':
            on_mouse_drag_line(event)
        elif current_cmd == 'rect':
            on_mouse_drag_rect(event)
        elif current_cmd == 'circle':
            on_mouse_drag_circle(event)
        elif current_cmd in ('move','copy'):
            on_mouse_drag_move(event)
        elif current_cmd == 'rotate':
            on_mouse_drag_rotate(event)
        elif current_cmd == 'scale':
            on_mouse_drag_scale(event)
        elif current_cmd == 'arc':
            # rubber-banding for arc
            on_mouse_drag_arc(event)
        elif current_cmd == 'ellipse':
            # rubber-banding for ellipse
            on_mouse_drag_ellipse(event)
        elif current_cmd == 'polygon':
            # rubber-banding for polygon
            on_mouse_drag_polygon(event)
        elif current_cmd == 'select':
            # update selection rectangle preview
            if select_rect_id is not None:
                try:
                    canvas.coords(select_rect_id, select_origin[0], select_origin[1], event.x, event.y)
                except Exception:
                    pass

    def canvas_left_up(event):
        nonlocal select_origin, select_rect_id, current_cmd
        # detect Ctrl pressed for rectangle finalization
        ctrl_pressed = (event.state & 0x4) != 0
        if current_cmd == 'line':
            on_left_up_line(event)
        elif current_cmd == 'rect':
            on_left_up_rect(event)
        elif current_cmd == 'circle':
            on_left_up_circle(event)
        elif current_cmd == 'move':
            on_left_up_move(event)
        elif current_cmd == 'copy':
            on_left_up_copy(event)
        elif current_cmd == 'rotate':
            on_left_up_rotate(event)
        elif current_cmd == 'scale':
            on_left_up_scale(event)
        elif current_cmd == 'select':
            # finalize rectangle selection
            if select_origin is None:
                current_cmd = None
                return
            x1,y1 = select_origin
            x2,y2 = event.x, event.y
            # remove preview
            if select_rect_id is not None:
                try: canvas.delete(select_rect_id)
                except Exception: pass
                select_rect_id = None
            select_origin = None
            # if click without drag (small movement), treat as click select (existing behavior)
            if abs(x2-x1) < 4 and abs(y2-y1) < 4:
                p = left_click_generic_point(event)
                picked = pick_primitive(p)
                if picked:
                    # Ctrl toggles membership
                    if ctrl_pressed:
                        if picked in selection:
                            selection.remove(picked)
                            append_history(f"Unselected {picked}")
                        else:
                            selection.append(picked)
                            append_history(f"Added {picked} to selection")
                    else:
                        selection.clear(); selection.append(picked)
                        append_history(f"Selected {picked}")
                else:
                    if not ctrl_pressed:
                        selection.clear()
                        append_history("Selection cleared")
                draw_canvas()
                current_cmd = None
                return
            # determine window vs crossing based on drag direction in screen coords
            # left-to-right => window (fully inside), right-to-left => crossing (intersect)
            mode = 'window' if x2 > x1 else 'crossing'
            # convert rectangle to world coords and normalize
            wx1,wy1 = screen_to_world(x1,y1)
            wx2,wy2 = screen_to_world(x2,y2)
            rx0,rx1 = min(wx1,wx2), max(wx1,wx2)
            ry0,ry1 = min(wy1,wy2), max(wy1,wy2)
            rect = (rx0, ry0, rx1, ry1)
            # collect matching primitives
            new_selection = []
            sref = engine.store_ref
            # lines
            for i,e in enumerate(sref.lines):
                for j in range(len(e['x1'])):
                    bbox = primitive_bbox('line', i, j)
                    if mode == 'window':
                        if rect_contains(rect, bbox):
                            new_selection.append(('line', i, j))
                    else:
                        if rect_intersects(rect, bbox):
                            new_selection.append(('line', i, j))
            # circles
            for i,e in enumerate(sref.circles):
                for j in range(len(e['cx'])):
                    bbox = primitive_bbox('circle', i, j)
                    if mode == 'window':
                        if rect_contains(rect, bbox):
                            new_selection.append(('circle', i, j))
                    else:
                        if rect_intersects(rect, bbox):
                            new_selection.append(('circle', i, j))
            # rects
            for i,e in enumerate(sref.rects):
                for j in range(len(e['x'])):
                    bbox = primitive_bbox('rect', i, j)
                    if mode == 'window':
                        if rect_contains(rect, bbox):
                            new_selection.append(('rect', i, j))
                    else:
                        if rect_intersects(rect, bbox):
                            new_selection.append(('rect', i, j))
            # texts
            for i,e in enumerate(sref.texts):
                for j in range(len(e['x'])):
                    bbox = primitive_bbox('text', i, j)
                    if mode == 'window':
                        if rect_contains(rect, bbox):
                            new_selection.append(('text', i, j))
                    else:
                        if rect_intersects(rect, bbox):
                            new_selection.append(('text', i, j))
            # ellipses
            for i,e in enumerate(sref.ellipses):
                for j in range(len(e['cx'])):
                    bbox = primitive_bbox('ellipse', i, j)
                    if mode == 'window':
                        if rect_contains(rect, bbox):
                            new_selection.append(('ellipse', i, j))
                    else:
                        if rect_intersects(rect, bbox):
                            new_selection.append(('ellipse', i, j))
            # arcs
            for i,e in enumerate(sref.arcs):
                for j in range(len(e['cx'])):
                    bbox = primitive_bbox('arc', i, j)
                    if mode == 'window':
                        if rect_contains(rect, bbox):
                            new_selection.append(('arc', i, j))
                    else:
                        if rect_intersects(rect, bbox):
                            new_selection.append(('arc', i, j))
            # If Ctrl pressed, add to existing selection (avoid duplicates); otherwise replace selection
            if ctrl_pressed:
                for ent in new_selection:
                    if ent not in selection:
                        selection.append(ent)
                append_history(f"Selection {mode} added: {len(new_selection)} primitives")
            else:
                selection.clear()
                selection.extend(new_selection)
                append_history(f"Selection {mode}: {len(selection)} primitives")
            draw_canvas()
            current_cmd = None

    # Bind mouse wheel for zoom (scroll) and middle-button pan (press+drag)
    canvas.bind("<MouseWheel>", on_mouse_wheel)   # Windows, macOS (with delta)
    canvas.bind("<Button-4>", on_mouse_wheel)     # X11 scroll up
    canvas.bind("<Button-5>", on_mouse_wheel)     # X11 scroll down

    # Middle button pan bindings
    canvas.bind("<Button-2>", on_middle_down)     # press mouse wheel to start pan
    canvas.bind("<B2-Motion>", on_middle_drag)    # drag with middle button to pan
    canvas.bind("<ButtonRelease-2>", on_middle_up) # release middle button to end pan

    canvas.bind("<Button-1>", canvas_left_down)
    canvas.bind("<B1-Motion>", canvas_mouse_drag)
    canvas.bind("<ButtonRelease-1>", canvas_left_up)
    canvas.bind("<Double-Button-1>", lambda e: finish_polygon())

    # Bind mouse motion to show nearby osnaps and crosshair/coords
    canvas.bind("<Motion>", on_mouse_move)

    # initial draw
    root.after(200, draw_canvas)

    root.mainloop()

# Entry point
if __name__ == "__main__":
    eng = Engine()
    if TK_AVAILABLE:
        tk_main(eng)
    else:
        print("Tkinter not available. This program requires a GUI environment.")
