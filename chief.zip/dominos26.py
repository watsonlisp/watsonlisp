"""
Graphical Dominoes (Human vs Computer) using Tkinter.
Save as dominoes_gui.py and run: python dominoes_gui.py
"""

import random
import tkinter as tk
from tkinter import messagebox
from collections import deque, namedtuple
import platform

Tile = namedtuple("Tile", ["a", "b"])

# ---------- Game logic helpers ----------

def make_set(max_pip=6):
    return [Tile(i, j) for i in range(max_pip + 1) for j in range(i, max_pip + 1)]

def pip_sum(hand):
    return sum(t.a + t.b for t in hand)

def can_play(tile, left_end, right_end):
    return tile.a == left_end or tile.b == left_end or tile.a == right_end or tile.b == right_end

def find_playable_indices(hand, left_end, right_end):
    return [i for i, t in enumerate(hand) if can_play(t, left_end, right_end)]

def normalize_for_side(tile, side_value):
    # Return tile oriented so that tile.a == side_value when placing on right end
    if tile.a == side_value:
        return Tile(tile.a, tile.b)
    if tile.b == side_value:
        return Tile(tile.b, tile.a)
    return tile  # caller should ensure it's playable

def orient_for_placement(tile, side, end_value):
    """
    Return a tile oriented left-to-right (tile.a is left half, tile.b is right half)
    such that:
      - if side == 'L' (we're placing to the left of the train), the new tile's right half
        (tile.b) equals end_value (the previous left end).
      - if side == 'R' (placing to the right), the new tile's left half (tile.a) equals end_value.
    The function assumes the tile is playable on that end.
    """
    if side == "L":
        # want tile.b == end_value
        if tile.b == end_value:
            return Tile(tile.a, tile.b)
        if tile.a == end_value:
            return Tile(tile.b, tile.a)
    else:
        # side == "R": want tile.a == end_value
        if tile.a == end_value:
            return Tile(tile.a, tile.b)
        if tile.b == end_value:
            return Tile(tile.b, tile.a)
    return tile

# ---------- Pip/dot helpers (for domino-style rendering) ----------

def dice_positions(x, y, w, h):
    """Standard die-face positions for values 0..6 inside rectangle (x,y,w,h)."""
    cx = x + w / 2
    cy = y + h / 2
    left = x + w * 0.22
    right = x + w * 0.78
    top = y + h * 0.22
    bottom = y + h * 0.78
    middle = cy
    return {
        0: [],
        1: [(cx, cy)],
        2: [(left, top), (right, bottom)],
        3: [(left, top), (cx, cy), (right, bottom)],
        4: [(left, top), (left, bottom), (right, top), (right, bottom)],
        5: [(left, top), (left, bottom), (cx, cy), (right, top), (right, bottom)],
        6: [(left, top), (left, middle), (left, bottom), (right, top), (right, middle), (right, bottom)],
    }

def draw_pips(canvas, x, y, w, h, value, pip_color="#000000"):
    """Draw pip dots for a single half (value 0..6)."""
    positions = dice_positions(x, y, w, h).get(value, [])
    r = min(w, h) * 0.07
    for (px, py) in positions:
        canvas.create_oval(px - r, py - r, px + r, py + r, fill=pip_color, outline="")

# ---------- GUI / Game class ----------

class DominoesGUI:
    # Defaults for canvas/board size
    CANVAS_W = 1400
    CANVAS_H = 760

    # Tile sizing
    TILE_W = 110
    TILE_H = 64
    GAP = 10

    # Extra blank space to the left of the train layout (pixels)
    LEFT_SPACER = 80

    # Positions
    HAND_Y = CANVAS_H - 100
    LAYOUT_Y = CANVAS_H // 2 - 60

    def __init__(self, root):
        self.root = root
        root.title("Dominoes - GUI (Human vs Computer)")

        # Try to maximize window for a nicer board
        try:
            root.state("zoomed")
        except Exception:
            try:
                root.attributes("-fullscreen", True)
            except Exception:
                pass

        # Frame to hold canvas and scrollbars
        board_frame = tk.Frame(root)
        board_frame.pack(fill="both", expand=True)

        # Canvas (we'll make it scrollable both horizontally and vertically)
        self.canvas = tk.Canvas(board_frame, bg="#2b2b2b", width=self.CANVAS_W, height=self.CANVAS_H)
        self.h_scroll = tk.Scrollbar(board_frame, orient="horizontal", command=self.canvas.xview)
        self.v_scroll = tk.Scrollbar(board_frame, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=self.h_scroll.set, yscrollcommand=self.v_scroll.set)

        # Layout: canvas with vertical scrollbar on right, horizontal scrollbar at bottom
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.v_scroll.grid(row=0, column=1, sticky="ns")
        self.h_scroll.grid(row=1, column=0, sticky="ew")
        board_frame.grid_rowconfigure(0, weight=1)
        board_frame.grid_columnconfigure(0, weight=1)

        # Bind configure to redraw and update scrollregion
        self.canvas.bind("<Configure>", lambda e: self.redraw())

        # Bind mouse events for scrolling/panning
        # Middle-button drag to pan (Button-2 on many systems). Also support Button-3 (right) as alternative.
        self.canvas.bind("<ButtonPress-2>", self._start_pan)
        self.canvas.bind("<B2-Motion>", self._do_pan)
        self.canvas.bind("<ButtonRelease-2>", self._end_pan)
        # Right-button pan as fallback
        self.canvas.bind("<ButtonPress-3>", self._start_pan)
        self.canvas.bind("<B3-Motion>", self._do_pan)
        self.canvas.bind("<ButtonRelease-3>", self._end_pan)

        # Mouse wheel scrolling: platform differences
        system = platform.system()
        if system == "Windows":
            self.canvas.bind_all("<MouseWheel>", self._on_mousewheel_windows)
        elif system == "Darwin":
            self.canvas.bind_all("<MouseWheel>", self._on_mousewheel_windows)  # macOS uses delta too
        else:
            # Linux: Button-4 (up) and Button-5 (down)
            self.canvas.bind_all("<Button-4>", self._on_mousewheel_linux)
            self.canvas.bind_all("<Button-5>", self._on_mousewheel_linux)

        # Buttons and labels (below the board)
        control_frame = tk.Frame(root)
        control_frame.pack(fill="x", pady=6)
        self.left_btn = tk.Button(control_frame, text="Place Left", command=lambda: self.place_selected("L"))
        self.left_btn.pack(side="left", padx=6)
        self.right_btn = tk.Button(control_frame, text="Place Right", command=lambda: self.place_selected("R"))
        self.right_btn.pack(side="left", padx=6)
        self.draw_btn = tk.Button(control_frame, text="Draw from Boneyard", command=self.draw_from_boneyard)
        self.draw_btn.pack(side="left", padx=6)
        self.pass_btn = tk.Button(control_frame, text="Pass", command=self.pass_turn)
        self.pass_btn.pack(side="left", padx=6)
        self.status_label = tk.Label(control_frame, text="Welcome to Dominoes", anchor="w")
        self.status_label.pack(side="left", padx=12)

        # Bind click on canvas for selecting tiles (we convert to canvas coords inside handler)
        self.canvas.bind("<Button-1>", self.on_canvas_click)

        # Pan state
        self._pan_start = None

        # Initialize game
        self.reset_game()

    # ---------- Pan / scroll helpers ----------

    def _start_pan(self, event):
        # record starting canvas coordinates
        self._pan_start = (self.canvas.canvasx(event.x), self.canvas.canvasy(event.y))

    def _do_pan(self, event):
        if self._pan_start is None:
            return
        x0, y0 = self._pan_start
        x1, y1 = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        dx = x1 - x0
        dy = y1 - y0
        # move view by negative delta (dragging moves content)
        self.canvas.xview_scroll(int(-dx / 2), "units")
        self.canvas.yview_scroll(int(-dy / 2), "units")
        # update start to current so panning is smooth
        self._pan_start = (self.canvas.canvasx(event.x), self.canvas.canvasy(event.y))

    def _end_pan(self, event):
        self._pan_start = None

    def _on_mousewheel_windows(self, event):
        # If Shift is held, scroll horizontally; otherwise vertically
        if (event.state & 0x0001) != 0:  # Shift mask (works on many platforms)
            # horizontal scroll
            if event.delta > 0:
                self.canvas.xview_scroll(-3, "units")
            else:
                self.canvas.xview_scroll(3, "units")
        else:
            # vertical scroll
            if event.delta > 0:
                self.canvas.yview_scroll(-3, "units")
            else:
                self.canvas.yview_scroll(3, "units")

    def _on_mousewheel_linux(self, event):
        # Button-4 = up, Button-5 = down
        if event.num == 4:
            self.canvas.yview_scroll(-1, "units")
        elif event.num == 5:
            self.canvas.yview_scroll(1, "units")

    # ---------- Game setup ----------

    def reset_game(self):
        deck = make_set(6)
        random.shuffle(deck)
        self.hand_size = 7
        self.human = [deck.pop() for _ in range(self.hand_size)]
        self.computer = [deck.pop() for _ in range(self.hand_size)]
        self.boneyard = deck
        # start layout with one tile from boneyard
        start_tile = self.boneyard.pop()
        self.layout = deque([start_tile])
        self.selected_index = None
        self.current = "human"  # human starts
        self.passes = 0
        self.redraw()
        self.update_status("Game started. Your turn.")

    # ---------- Drawing ----------

    def redraw(self):
        # Clear and redraw everything, then update scrollregion so the scrollbars cover all content
        self.canvas.delete("all")
        self.draw_layout()
        self.draw_hands()
        self.draw_boneyard_info()

        # Update scrollregion to include all drawn items
        self.canvas.update_idletasks()
        bbox = self.canvas.bbox("all")
        if bbox:
            pad = 20
            self.canvas.configure(scrollregion=(bbox[0] - pad, bbox[1] - pad, bbox[2] + pad, bbox[3] + pad))
        else:
            self.canvas.configure(scrollregion=(0, 0, self.CANVAS_W, self.CANVAS_H))

    def draw_tile(self, x, y, tile, tag=None, highlight=False):
        """
        Draw a domino-style tile:
        - white rectangle with black border
        - center divider
        - dice-style pip dots on each half
        - small numeric corner labels for quick reference
        """
        w, h = self.TILE_W, self.TILE_H
        bg = "#ffffff" if not highlight else "#fff7d9"
        border = "#000000"
        # tile rectangle
        self.canvas.create_rectangle(x, y, x + w, y + h, fill=bg, outline=border, width=2, tags=tag)
        # center divider (thick black line)
        mid_x = x + w / 2
        self.canvas.create_line(mid_x, y + 6, mid_x, y + h - 6, fill=border, width=3)
        # inset halves for pips (leave a small margin)
        left_x1, left_y1 = x + 8, y + 8
        left_w = (w / 2) - 16
        left_h = h - 16
        right_x1 = mid_x + 8
        right_y1 = y + 8
        right_w = (w / 2) - 16
        right_h = h - 16

        # subtle inner shadow/bevel (very light gray lines) to make tile look embossed
        self.canvas.create_line(x + 3, y + 3, x + w - 3, y + 3, fill="#f0f0f0")
        self.canvas.create_line(x + 3, y + 3, x + 3, y + h - 3, fill="#f0f0f0")

        # draw pips on each half (black pips)
        draw_pips(self.canvas, left_x1, left_y1, left_w, left_h, tile.a, pip_color="#111111")
        draw_pips(self.canvas, right_x1, right_y1, right_w, right_h, tile.b, pip_color="#111111")

        # small numeric corner labels for quick numeric reference (subtle gray)
        self.canvas.create_text(x + 10, y + 10, text=str(tile.a), anchor="nw", font=("Helvetica", 9), fill="#444444")
        self.canvas.create_text(x + w - 10, y + 10, text=str(tile.b), anchor="ne", font=("Helvetica", 9), fill="#444444")

    def draw_layout(self):
        # Use current canvas width so we can compute a reasonable center if desired
        cw = self.canvas.winfo_width()
        if cw <= 1:
            cw = self.CANVAS_W

        total = len(self.layout)
        total_w = total * (self.TILE_W + self.GAP) - self.GAP
        margin = 20

        # Start the train with a left spacer + margin so there's always room on the left
        start_x = margin + self.LEFT_SPACER

        # If the train is narrower than the canvas, center it visually while keeping the left spacer
        if total_w + start_x + margin < cw:
            # center the train within the visible canvas but keep LEFT_SPACER as minimum left offset
            centered_start = (cw - total_w) / 2
            start_x = max(start_x, centered_start)

        y = self.LAYOUT_Y

        # optional: draw a subtle spacer marker at the left edge of the train (visual cue)
        spacer_x = start_x - self.LEFT_SPACER
        if self.LEFT_SPACER > 0:
            # draw a faint vertical bar to indicate spacer (matches background so it's subtle)
            self.canvas.create_rectangle(spacer_x, y, spacer_x + 6, y + self.TILE_H,
                                         fill="#2b2b2b", outline="", tags="spacer")

        # Draw tiles in deque order left-to-right. Each tile should already be oriented
        # so that adjacent halves match (we ensure this when placing).
        for i, t in enumerate(self.layout):
            x = start_x + i * (self.TILE_W + self.GAP)
            self.draw_tile(x, y, t, tag=f"layout_{i}")

    def draw_hands(self):
        # Human hand at bottom (fixed area near left margin)
        x = 20
        y = self.HAND_Y
        for i, t in enumerate(self.human):
            tag = f"hand_{i}"
            highlight = (i == self.selected_index)
            self.draw_tile(x, y, t, tag=tag, highlight=highlight)
            # small index label (redundant with corner label but kept for clarity)
            self.canvas.create_text(x + 12, y + 12, text=str(i), anchor="nw", fill="#222222", font=("Helvetica", 8))
            x += self.TILE_W + self.GAP

        # Computer hand (hidden) at top as backs
        x = 20
        y = 20
        for i, _ in enumerate(self.computer):
            # draw back of tile (larger to match tile size)
            self.canvas.create_rectangle(x, y, x + self.TILE_W, y + self.TILE_H, fill="#3b5aa6", outline="#111111")
            # subtle pattern on back
            spacing = 12
            bx1, by1 = x + 6, y + 6
            bx2, by2 = x + self.TILE_W - 6, y + self.TILE_H - 6
            start = - (by2 - by1)
            end = bx2 - bx1
            for j in range(start, end, spacing):
                self.canvas.create_line(bx1 + j, by1, bx1 + j + (by2 - by1), by2, fill="#2f4f9a")
            x += self.TILE_W + self.GAP

    def draw_boneyard_info(self):
        txt = f"Boneyard: {len(self.boneyard)} tiles"
        # place this near the top-right of the visible canvas area
        cw = self.canvas.winfo_width() or self.CANVAS_W
        # convert visible right edge to canvas coords
        try:
            right_visible = self.canvas.canvasx(cw)
        except Exception:
            right_visible = cw
        self.canvas.create_text(right_visible - 200, 30, text=txt, fill="#ffffff", font=("Helvetica", 12, "bold"))

    # ---------- Interaction ----------

    def on_canvas_click(self, event):
        # Convert event coords to canvas coordinates (accounts for scrolling)
        cx = self.canvas.canvasx(event.x)
        cy = self.canvas.canvasy(event.y)
        # detect clicks on human hand tiles (hand is drawn near left margin)
        start_x = 20
        y0 = self.HAND_Y
        for i in range(len(self.human)):
            tx = start_x + i * (self.TILE_W + self.GAP)
            if tx <= cx <= tx + self.TILE_W and y0 <= cy <= y0 + self.TILE_H:
                # select or deselect
                if self.selected_index == i:
                    self.selected_index = None
                else:
                    self.selected_index = i
                self.redraw()
                return

    def place_selected(self, side):
        if self.current != "human":
            self.update_status("Not your turn.")
            return
        if self.selected_index is None:
            self.update_status("Select a tile first.")
            return
        tile = self.human[self.selected_index]
        left_end = self.layout[0].a
        right_end = self.layout[-1].b
        if not can_play(tile, left_end, right_end):
            self.update_status("Selected tile is not playable.")
            return
        # orient and place so matching halves touch
        if side == "L":
            oriented = orient_for_placement(tile, "L", left_end)
            # appendleft expects the tile to be oriented left-to-right; orient_for_placement
            # ensures oriented.b == left_end so the right half of the new tile touches the old left end.
            self.layout.appendleft(oriented)
        else:
            oriented = orient_for_placement(tile, "R", right_end)
            # oriented.a == right_end so the left half of the new tile touches the old right end.
            self.layout.append(oriented)
        # remove from hand
        self.human.pop(self.selected_index)
        self.selected_index = None
        self.passes = 0
        self.redraw()
        # check win
        if not self.human:
            self.end_game(winner="human")
            return
        # switch to computer
        self.current = "computer"
        self.update_status("You played. Computer's turn.")
        self.root.after(700, self.computer_turn)

    def draw_from_boneyard(self):
        if self.current != "human":
            self.update_status("Not your turn.")
            return
        if not self.boneyard:
            self.update_status("Boneyard is empty.")
            return
        self.human.append(self.boneyard.pop())
        self.redraw()
        self.update_status("Drew a tile.")
        # human may continue to play

    def pass_turn(self):
        if self.current != "human":
            self.update_status("Not your turn.")
            return
        self.passes += 1
        self.current = "computer"
        self.selected_index = None
        self.redraw()
        self.update_status("You passed. Computer's turn.")
        self.root.after(700, self.computer_turn)

    # ---------- Computer AI ----------

    def computer_turn(self):
        left_end = self.layout[0].a
        right_end = self.layout[-1].b
        playable = find_playable_indices(self.computer, left_end, right_end)
        # draw until playable or boneyard empty
        while not playable and self.boneyard:
            self.computer.append(self.boneyard.pop())
            playable = find_playable_indices(self.computer, left_end, right_end)
        if not playable:
            self.passes += 1
            self.update_status("Computer passes.")
            # check blocked condition
            if self.passes >= 2 and not self.boneyard:
                self.end_game(winner=None)  # blocked
                return
            self.current = "human"
            self.redraw()
            return
        # play first playable
        idx = playable[0]
        tile = self.computer.pop(idx)
        # choose side and orient so matching halves touch
        if tile.a == left_end or tile.b == left_end:
            oriented = orient_for_placement(tile, "L", left_end)
            self.layout.appendleft(oriented)
        else:
            oriented = orient_for_placement(tile, "R", right_end)
            self.layout.append(oriented)
        self.passes = 0
        self.redraw()
        # check win
        if not self.computer:
            self.end_game(winner="computer")
            return
        # back to human
        self.current = "human"
        self.update_status("Computer played. Your turn.")

    # ---------- Endgame ----------

    def end_game(self, winner):
        if winner == "human":
            score = pip_sum(self.computer)
            messagebox.showinfo("Game Over", f"You emptied your hand. You win!\nScore gained: {score}")
        elif winner == "computer":
            score = pip_sum(self.human)
            messagebox.showinfo("Game Over", f"Computer emptied its hand. Computer wins.\nComputer gains: {score}")
        else:
            # blocked
            p1_sum = pip_sum(self.human)
            p2_sum = pip_sum(self.computer)
            if p1_sum < p2_sum:
                msg = f"Game blocked. You win by lower pip total.\nYour pips: {p1_sum}  Computer pips: {p2_sum}"
            elif p2_sum < p1_sum:
                msg = f"Game blocked. Computer wins by lower pip total.\nYour pips: {p1_sum}  Computer pips: {p2_sum}"
            else:
                msg = f"Game blocked. Tie.\nYour pips: {p1_sum}  Computer pips: {p2_sum}"
            messagebox.showinfo("Game Over", msg)
        # ask to play again
        if messagebox.askyesno("Play again?", "Start a new game?"):
            self.reset_game()
        else:
            self.root.quit()

    def update_status(self, text):
        self.status_label.config(text=text)

# ---------- Run ----------

if __name__ == "__main__":
    root = tk.Tk()
    app = DominoesGUI(root)
    root.mainloop()
