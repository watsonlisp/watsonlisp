#!/usr/bin/env python3
"""
Random Pickup-Line Flirter (interactive loop) with simple TTS (no pip required).
TTS is ON by default. Toggle with 't'. Controls are shown at each prompt.
"""

import random
import re
import sys
import subprocess
import platform
import shutil

# --- Expanded, safe set of conversation starters and light pickup lines ---
PICKUP_LINES = {
    "friendly": [
        "Hi there — what's the best thing that happened to you today?",
        "Hello! If you could teleport anywhere right now, where would you go?",
        "Hey — I like your energy. What are you excited about this week?",
        "Hi! What's one small thing that made you smile recently?",
        "Hello — do you have a favorite local coffee shop?",
        "Hi — what's a hobby you wish you had more time for?",
        "Hey there — read any good books lately?",
        "Hello! What's a movie you can watch again and again?",
        "Hi — what's one skill you’d love to learn this year?",
        "Hey — what song is stuck in your head right now?"
    ],
    "witty": [
        "If you were a punctuation mark, which one would you be and why?",
        "Do you prefer sunrise, sunset, or the moment your coffee is perfect?",
        "If you could rename any color, which would you rename and to what?",
        "Would you rather explore space or the deep sea for a day?",
        "If you could have dinner with any fictional character, who would it be?",
        "Is cereal a soup? Defend your answer.",
        "If you had to pick a theme song for today, what would it be?",
        "Would you rather time travel to the past or the future for one hour?",
        "If you could instantly master one instrument, which would you choose?",
        "What’s the most useful useless talent you have?"
    ],
    "cheesy_puns": [
        "Are you a sunrise? Because you brighten the start of my day.",
        "Do you like puzzles? Because I think we could piece together a great conversation.",
        "Are you a library book? Because I want to check you out for recommendations.",
        "If you were a pastry, you'd be a perfect croissant — flaky in the best way.",
        "Are you a playlist? Because I could listen to you all afternoon.",
        "If you were a season, you'd be the one I look forward to.",
        "Are you a compass? Because you point me toward interesting stories.",
        "If you were a flavor, you'd be the one everyone asks about.",
        "Are you a sunrise hike? Because you make the effort worth it.",
        "If you were a museum exhibit, I'd spend extra time reading the placard."
    ],
    "polite_invites": [
        "Would you like to grab a coffee sometime and swap book recommendations?",
        "If you're free this weekend, want to check out that new gallery?",
        "Care to join me for a walk in the park and some good conversation?",
        "If you enjoy board games, would you like to play one afternoon?",
        "Would you be interested in trying that bakery downtown together?",
        "If you like live music, want to catch a local show this month?",
        "Would you like to meet for a casual chat over tea?",
        "If you enjoy museums, want to visit the new exhibit with me?",
        "Would you be up for a short hike and a picnic this weekend?",
        "If you like coffee and conversation, shall we pick a time?"
    ],
    "thoughtful": [
        "You have a calm presence — what helps you stay grounded?",
        "I admire people who listen well. What's something you recently learned from someone else?",
        "You seem curious — what's a topic you could talk about for hours?",
        "I appreciate thoughtful people. What idea has changed your perspective lately?",
        "You strike me as creative — what project are you proud of?",
        "You seem kind — what's a small kindness you try to practice?",
        "I like how attentive you are — what inspires that in you?",
        "You seem adventurous — what's a memorable trip you've taken?",
        "I notice you have good taste — what's a recent discovery you loved?",
        "You seem intentional — how do you decide what to prioritize?"
    ],
    "nerdy": [
        "If you could solve one unsolved math problem, which would it be?",
        "Are you more into quantum puzzles or cosmic mysteries?",
        "If you could program any device to do one task perfectly, what would it be?",
        "Which sci‑fi world would you most like to visit for a day?",
        "If you could have a conversation with any scientist, living or historical, who would it be?",
        "Do you prefer analog or digital tools for creative work?",
        "If you could design a robot to help with one chore, what would it do?",
        "Which scientific discovery do you wish everyone understood better?",
        "If you could time‑stamp one moment in history to observe, what would it be?",
        "Are you team telescope or team microscope?"
    ],
    "travel_food_music": [
        "What's the best meal you've ever had while traveling?",
        "If you could eat one cuisine for the rest of the year, what would it be?",
        "Which city has the friendliest coffee culture in your experience?",
        "What's a song that always transports you to a place?",
        "If you could learn to cook one regional dish perfectly, which would it be?",
        "What's a small town you think more people should visit?",
        "Which album do you return to when you need comfort?",
        "If you could recommend one street food, what would it be?",
        "What's a travel memory that still makes you smile?",
        "Which local band or artist should everyone hear at least once?"
    ],
    "compliments": [
        "You have a great laugh — it’s contagious in the best way.",
        "You explain things clearly — that’s a rare and useful skill.",
        "You seem thoughtful — I appreciate that in a conversation partner.",
        "You have a warm presence — it makes chatting easy.",
        "You ask interesting questions — it keeps the conversation lively.",
        "You have a good sense of humor — it brightens the room.",
        "You’re a good listener — that’s a real gift.",
        "You bring calm energy — it’s refreshing.",
        "You have an eye for detail — it shows in what you notice.",
        "You’re easy to talk to — thank you for that."
    ],
    "light_challenges": [
        "I bet I can guess your favorite ice cream flavor in three tries.",
        "Challenge: describe your perfect day in exactly five words.",
        "I dare you to tell me the most unusual hobby you’ve tried.",
        "Quick game: name three things that always make you laugh.",
        "Bet you can’t pick a favorite movie genre without changing your mind.",
        "Try this: tell me a fact about yourself most people don’t know.",
        "I challenge you to recommend a book I haven’t heard of.",
        "Game: pick a color and I’ll tell you what it says about you.",
        "I dare you to share the best advice you’ve ever received.",
        "Quick: what’s one small habit that improves your day?"
    ],
    "seasonal": [
        "What’s your favorite way to spend a crisp autumn afternoon?",
        "Do you have a go‑to summer treat you look forward to?",
        "What’s a winter ritual you enjoy every year?",
        "Which spring activity makes you feel most refreshed?",
        "Do you prefer cozy indoor days or sunny outdoor adventures?",
        "What seasonal food do you always get excited about?",
        "Which holiday tradition do you look forward to most?",
        "What’s your favorite seasonal scent or smell?",
        "Do you have a favorite seasonal playlist?",
        "Which season would you pick if you could have it year‑round?"
    ]
}

# --- Simple blacklist to avoid offensive lines ---
BLACKLIST = {"sex", "drunk", "slut", "bitch", "fuck", "ass"}  # extend as needed

def is_safe(line: str) -> bool:
    """Return True if line doesn't contain blacklisted words (case-insensitive)."""
    words = re.findall(r"\w+", line.lower())
    return not any(b in words for b in BLACKLIST)

def choose_line(category: str | None = None, name: str | None = None) -> str:
    """Choose a random safe line from a category or from all categories."""
    pool = []
    if category:
        pool = PICKUP_LINES.get(category.lower(), [])
    else:
        for lines in PICKUP_LINES.values():
            pool.extend(lines)
    safe_pool = [l for l in pool if is_safe(l)]
    if not safe_pool:
        return "Sorry, I don't have a line that fits that request right now."
    line = random.choice(safe_pool)
    if name:
        if "{name}" in line:
            line = line.replace("{name}", name)
        else:
            line = f"{name}, {line}"
    return line

# --- Simple cross-platform TTS using system utilities (no pip) ---
def _which_tts_command():
    """Detect available TTS command on the system."""
    system = platform.system()
    if system == "Darwin" and shutil.which("say"):
        return ("say",)
    if system == "Linux":
        if shutil.which("spd-say"):
            return ("spd-say",)
        if shutil.which("espeak"):
            return ("espeak",)
    if system == "Windows":
        # We'll use PowerShell's System.Speech if PowerShell is available
        if shutil.which("powershell"):
            return ("powershell",)
    return None

_TTS_CMD = _which_tts_command()

def _escape_for_powershell(text: str) -> str:
    # Replace single quotes with double single-quotes for PowerShell single-quoted string
    return text.replace("'", "''")

def speak(text: str, tts_on: bool = True):
    """Speak text using a system TTS command if available and enabled."""
    if not tts_on or not _TTS_CMD:
        return
    try:
        cmd = _TTS_CMD[0]
        system = platform.system()
        if cmd == "say":
            subprocess.run(["say", text], check=False)
        elif cmd == "spd-say":
            # spd-say accepts text directly
            subprocess.run(["spd-say", text], check=False)
        elif cmd == "espeak":
            subprocess.run(["espeak", text], check=False)
        elif cmd == "powershell":
            # Use .NET System.Speech via PowerShell
            safe = _escape_for_powershell(text)
            ps = (
                "Add-Type -AssemblyName System.Speech;"
                f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe}')"
            )
            subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=False)
    except Exception:
        # Fail silently if TTS fails
        pass

def list_categories() -> list:
    """Return available categories."""
    return sorted(PICKUP_LINES.keys())

def interactive_loop():
    """Run an interactive loop that repeats until the user quits.
    Controls are displayed at each prompt and TTS status is shown.
    """
    current_category = None
    current_name = None
    tts_on = True  # TTS on by default
    controls_template = (
        "[Enter] generate  |  m <n> generate n lines  |  c <cat> set/clear  |  n <name> set/clear  |  l list  |  t toggle TTS  |  q quit"
    )
    print("Random Pickup-Line Flirter (interactive).")
    if not _TTS_CMD:
        print("Note: No system TTS command detected; TTS will be disabled automatically.")
        tts_on = False

    while True:
        try:
            tts_status = "ON" if tts_on else "OFF"
            prompt = f"\n{controls_template}\nTTS: {tts_status}  |  Category: {current_category or 'all'}  |  Name: {current_name or 'none'}\nPress Enter to generate, or type a command: "
            cmd = input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            return

        if cmd == "":
            line = choose_line(category=current_category, name=current_name)
            print("\n" + line)
            speak(line, tts_on=tts_on)
            continue

        cmd_lower = cmd.lower()
        if cmd_lower in {"q", "quit", "exit"}:
            print("Quitting. Goodbye.")
            return

        if cmd_lower == "t":
            # toggle TTS
            if _TTS_CMD:
                tts_on = not tts_on
                print(f"TTS turned {'ON' if tts_on else 'OFF'}.")
            else:
                print("No TTS command available on this system.")
            continue

        if cmd_lower.startswith("m "):
            parts = cmd.split(maxsplit=1)
            try:
                count = int(parts[1])
                for _ in range(max(1, count)):
                    line = choose_line(category=current_category, name=current_name)
                    print(line)
                    speak(line, tts_on=tts_on)
            except (ValueError, IndexError):
                print("Invalid number. Usage: m 3")
            continue

        if cmd_lower.startswith("c"):
            parts = cmd.split(maxsplit=1)
            if len(parts) == 1:
                current_category = None
                print("Category cleared. Using all categories.")
            else:
                cat = parts[1].strip().lower()
                if cat in PICKUP_LINES:
                    current_category = cat
                    print(f"Category set to '{cat}'.")
                else:
                    print(f"Unknown category '{cat}'. Type 'l' to list categories.")
            continue

        if cmd_lower.startswith("n"):
            parts = cmd.split(maxsplit=1)
            if len(parts) == 1:
                current_name = None
                print("Name cleared.")
            else:
                current_name = parts[1].strip()
                print(f"Name set to '{current_name}'.")
            continue

        if cmd_lower == "l":
            print("Available categories:", ", ".join(list_categories()))
            continue

        # If user typed a number alone, generate that many lines
        if cmd.isdigit():
            count = int(cmd)
            for _ in range(max(1, count)):
                line = choose_line(category=current_category, name=current_name)
                print(line)
                speak(line, tts_on=tts_on)
            continue

        print("Unknown command. Type 'q' to quit.")

def main():
    # If the user passed CLI args, keep backward compatibility
    if len(sys.argv) > 1:
        import argparse
        parser = argparse.ArgumentParser(description="Random pickup-line flirter (non-interactive)")
        parser.add_argument("-c", "--category", help="Category to use")
        parser.add_argument("-n", "--name", help="Optional name to personalize the line")
        parser.add_argument("-m", "--multiple", type=int, default=1, help="How many lines to print")
        args = parser.parse_args()
        for _ in range(max(1, args.multiple)):
            line = choose_line(category=args.category, name=args.name)
            print(line)
        return

    # Otherwise start interactive loop
    interactive_loop()

if __name__ == "__main__":
    main()
