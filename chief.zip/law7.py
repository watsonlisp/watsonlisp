#!/usr/bin/env python3
"""
lawgen_tts.py
Random Law Quote Generator with optional keyword seeding and TTS.
TTS is enabled by default. Use --no-tts to disable.
No external Python packages required. Uses OS-native TTS where available.
"""

import argparse
import csv
import json
import random
import re
import sys
import subprocess
import shutil
import platform
from difflib import get_close_matches
from typing import List, Dict

# -------------------------
# Library loading / search
# -------------------------
def load_csv(path: str) -> List[Dict]:
    items = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'id': (row.get('id') or '').strip(),
                'title': (row.get('title') or '').strip(),
                'section': (row.get('section') or '').strip(),
                'text': (row.get('text') or '').strip(),
                'citation': (row.get('citation') or '').strip()
            })
    return items

def load_json(path: str) -> List[Dict]:
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    items = []
    for obj in data:
        items.append({
            'id': str(obj.get('id', '')).strip(),
            'title': str(obj.get('title', '')).strip(),
            'section': str(obj.get('section', '')).strip(),
            'text': str(obj.get('text', '')).strip(),
            'citation': str(obj.get('citation', '')).strip()
        })
    return items

def load_library(path: str) -> List[Dict]:
    if path.lower().endswith('.csv'):
        return load_csv(path)
    if path.lower().endswith('.json'):
        return load_json(path)
    raise ValueError("Unsupported file type. Use .csv or .json")

def find_matches(library: List[Dict], seed: str, fuzzy: bool = True) -> List[Dict]:
    seed_l = seed.lower()
    matches = [item for item in library
               if seed_l in (item.get('title','') + ' ' + item.get('section','') + ' ' + item.get('text','')).lower()]
    if matches:
        return matches
    if not fuzzy:
        return []
    titles = [item.get('title','') for item in library if item.get('title')]
    close = get_close_matches(seed, titles, n=10, cutoff=0.6)
    if close:
        return [item for item in library if item.get('title') in close]
    pattern = re.compile(r'\b' + re.escape(seed_l) + r'\b', re.IGNORECASE)
    return [item for item in library if pattern.search(item.get('text','')) or pattern.search(item.get('title',''))]

def pick_random(items: List[Dict], count: int) -> List[Dict]:
    if not items:
        return []
    if count >= len(items):
        return [random.choice(items) for _ in range(count)]
    return random.sample(items, count)

def format_output(item: Dict) -> str:
    header_parts = []
    if item.get('title'):
        header_parts.append(f"**{item['title']}**")
    if item.get('section'):
        header_parts.append(item['section'])
    header = " | ".join(header_parts) if header_parts else f"ID {item.get('id','')}"
    text = item.get('text','').strip()
    citation = item.get('citation','').strip()
    return f"{header}\n{text}\n— {citation}"

# -------------------------
# TTS (no external pip)
# -------------------------
def _tts_windows(text: str) -> bool:
    ps_cmd = [
        "powershell",
        "-NoProfile",
        "-Command",
        "Add-Type -AssemblyName System.speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak([Console]::In.ReadToEnd())"
    ]
    try:
        subprocess.run(ps_cmd, input=text.encode('utf-8'), check=True)
        return True
    except Exception:
        return False

def _tts_macos(text: str) -> bool:
    say = shutil.which("say")
    if not say:
        return False
    try:
        subprocess.run([say, text], check=True)
        return True
    except Exception:
        return False

def _tts_linux(text: str) -> bool:
    spd = shutil.which("spd-say")
    if spd:
        try:
            subprocess.run([spd, text], check=True)
            return True
        except Exception:
            pass
    espeak = shutil.which("espeak")
    if espeak:
        try:
            subprocess.run([espeak, text], check=True)
            return True
        except Exception:
            pass
    return False

def speak(text: str) -> None:
    if not text:
        return
    system = platform.system().lower()
    ok = False
    if system == "windows":
        ok = _tts_windows(text)
    elif system == "darwin":
        ok = _tts_macos(text)
    else:
        ok = _tts_linux(text)
    if not ok:
        print("[TTS unavailable on this system or required command not found]")

# -------------------------
# Demo library (70 entries)
# -------------------------
DEMO_LIBRARY = [
    {'id':'1','title':'Town Ordinances','section':'Sec 2-1','text':'No person shall ride a unicycle on Main Street between 10pm and 6am.','citation':'Town Code §2-1'},
    {'id':'2','title':'Animal Control','section':'Sec 5-4','text':'It is unlawful to keep more than three ferrets in a single dwelling unit.','citation':'Municipal Code §5-4'},
    {'id':'3','title':'Noise','section':'Sec 3-2','text':'Playing bagpipes within 50 feet of a hospital is prohibited between midnight and 7am.','citation':'City Code §3-2'},
    {'id':'4','title':'Public Decorum','section':'Sec 7-9','text':'Wearing a hat shaped like a pineapple in the public library is discouraged but not illegal.','citation':'City Code §7-9'},
    {'id':'5','title':'Parking','section':'Sec 4-7','text':'No vehicle may be parked facing the opposite direction of traffic on Elm Avenue.','citation':'Traffic Code §4-7'},
    {'id':'6','title':'Food Safety','section':'Sec 8-1','text':'Street vendors must cover all prepared food with a lid or mesh while on public sidewalks.','citation':'Health Code §8-1'},
    {'id':'7','title':'Historic Preservation','section':'Sec 12-3','text':'Painting a historic facade a non-approved color requires a permit from the preservation board.','citation':'Preservation Code §12-3'},
    {'id':'8','title':'Curfew','section':'Sec 6-2','text':'Minors under 16 are not permitted in public parks after 10pm without adult supervision.','citation':'Public Safety §6-2'},
    {'id':'9','title':'Noise (Pets)','section':'Sec 5-9','text':'Owners must prevent their parrot from whistling the national anthem between 2am and 5am.','citation':'Animal Code §5-9'},
    {'id':'10','title':'Bicycle Rules','section':'Sec 9-4','text':'Bicycles must yield to pedestrians on all marked crosswalks and shared paths.','citation':'Traffic Code §9-4'},
    {'id':'11','title':'Drone Use','section':'Sec 11-1','text':'Drones may not be flown over municipal swimming pools during operating hours.','citation':'Aviation Code §11-1'},
    {'id':'12','title':'Signage','section':'Sec 10-5','text':'Temporary signs larger than 2 square feet require a permit for display on public property.','citation':'Zoning Code §10-5'},
    {'id':'13','title':'Noise (Construction)','section':'Sec 3-8','text':'Construction noise is restricted to weekdays between 7am and 6pm in residential zones.','citation':'City Code §3-8'},
    {'id':'14','title':'Tree Care','section':'Sec 14-2','text':'Removing a street tree requires a licensed arborist report and city approval.','citation':'Urban Forestry §14-2'},
    {'id':'15','title':'Public Art','section':'Sec 13-1','text':'Artists must register murals with the arts commission before painting on municipal walls.','citation':'Arts Code §13-1'},
    {'id':'16','title':'Pet Licensing','section':'Sec 5-1','text':'All dogs over 6 months must be licensed and wear a current tag when in public.','citation':'Animal Control §5-1'},
    {'id':'17','title':'Fireworks','section':'Sec 15-4','text':'Consumer fireworks are prohibited within city limits except on July 4 with a permit.','citation':'Safety Code §15-4'},
    {'id':'18','title':'Noise (Music)','section':'Sec 3-12','text':'Live amplified music requires a noise variance if expected to exceed 75 dB at property lines.','citation':'Entertainment Code §3-12'},
    {'id':'19','title':'Sidewalk Cafes','section':'Sec 10-9','text':'Sidewalk cafes must maintain a 4-foot clear pedestrian path at all times.','citation':'Zoning Code §10-9'},
    {'id':'20','title':'Littering','section':'Sec 2-5','text':'Discarding food wrappers in public transit shelters carries a fine of up to $100.','citation':'Sanitation Code §2-5'},
    {'id':'21','title':'Holiday Lights','section':'Sec 12-8','text':'Holiday light displays may not be installed on public trees without permission.','citation':'Public Works §12-8'},
    {'id':'22','title':'Noise (Animals)','section':'Sec 5-12','text':'Roosters are not permitted within city residential limits at any time.','citation':'Animal Code §5-12'},
    {'id':'23','title':'Vendor Permits','section':'Sec 8-6','text':'Mobile book vendors must move locations every two hours to avoid monopolizing a block.','citation':'Vendor Code §8-6'},
    {'id':'24','title':'Public Pools','section':'Sec 16-2','text':'No inflatable pool toys larger than 3 feet are allowed in municipal pools during peak hours.','citation':'Recreation Code §16-2'},
    {'id':'25','title':'Graffiti','section':'Sec 13-5','text':'Property owners must remove graffiti within 14 days of notification or the city will abate and bill them.','citation':'Code Enforcement §13-5'},
    {'id':'26','title':'Noise (Vehicles)','section':'Sec 4-12','text':'Vehicles with modified exhaust systems that exceed 95 dB are subject to citation.','citation':'Traffic Code §4-12'},
    {'id':'27','title':'Holiday Parades','section':'Sec 17-1','text':'Animals in parades must be leashed and have proof of vaccination available on request.','citation':'Event Code §17-1'},
    {'id':'28','title':'Public Markets','section':'Sec 8-2','text':'Farmers at the public market must label produce with origin and price per pound.','citation':'Market Code §8-2'},
    {'id':'29','title':'Noise (Holidays)','section':'Sec 3-20','text':'Fireworks noise exemptions require a public safety plan and insurance certificate.','citation':'Safety Code §3-20'},
    {'id':'30','title':'Street Performers','section':'Sec 9-9','text':'Street performers may not use amplified sound without a permit and must stay within designated zones.','citation':'Arts Code §9-9'},
    {'id':'31','title':'Holiday Trees','section':'Sec 12-12','text':'Cutting down a live holiday tree on city property is prohibited without a permit.','citation':'Parks Code §12-12'},
    {'id':'32','title':'Public Restrooms','section':'Sec 6-7','text':'Businesses with more than 50 seats must provide public restroom access during business hours.','citation':'Health Code §6-7'},
    {'id':'33','title':'Noise (Appliances)','section':'Sec 3-25','text':'Operating leaf blowers is restricted to weekdays between 8am and 5pm in residential areas.','citation':'Environmental Code §3-25'},
    {'id':'34','title':'Boat Mooring','section':'Sec 18-4','text':'Private boats may not be moored to public docks for more than 48 consecutive hours.','citation':'Harbor Code §18-4'},
    {'id':'35','title':'Holiday Sales','section':'Sec 19-2','text':'Retailers must clearly mark sale prices and the original price for comparison during holiday sales.','citation':'Consumer Protection §19-2'},
    {'id':'36','title':'Public Speaking','section':'Sec 20-1','text':'Speakers in the town square must register with the events office for amplified sound.','citation':'Public Assembly §20-1'},
    {'id':'37','title':'Noise (Schools)','section':'Sec 3-30','text':'No commercial leafleting within 200 feet of school property during school hours.','citation':'Education Code §3-30'},
    {'id':'38','title':'Pet Waste','section':'Sec 5-7','text':'Pet owners must carry waste bags and dispose of pet waste in designated receptacles.','citation':'Animal Control §5-7'},
    {'id':'39','title':'Holiday Parking','section':'Sec 4-20','text':'Parking meters are free on designated city holidays; signs will indicate applicable dates.','citation':'Parking Code §4-20'},
    {'id':'40','title':'Noise (Bells)','section':'Sec 3-33','text':'Church bells may not be rung for more than 5 minutes between 11pm and 6am.','citation':'Public Nuisance §3-33'},
    {'id':'41','title':'Food Trucks','section':'Sec 8-10','text':'Food trucks must move at least 200 feet from a brick-and-mortar restaurant unless invited.','citation':'Vendor Code §8-10'},
    {'id':'42','title':'Noise (Sports)','section':'Sec 3-40','text':'Sports stadiums must submit a noise mitigation plan for events exceeding 10,000 attendees.','citation':'Event Code §3-40'},
    {'id':'43','title':'Holiday Decorations','section':'Sec 12-15','text':'Decorations on public lampposts require approval and must be removed within 30 days after the holiday.','citation':'Public Works §12-15'},
    {'id':'44','title':'Public Transit','section':'Sec 21-3','text':'Eating hot food on buses is prohibited to prevent spills and odors; cold sealed items allowed.','citation':'Transit Code §21-3'},
    {'id':'45','title':'Noise (Construction Vehicles)','section':'Sec 3-45','text':'Heavy construction vehicles must use engine brakes sparingly in residential zones.','citation':'Traffic Code §3-45'},
    {'id':'46','title':'Community Gardens','section':'Sec 14-9','text':'Plots in community gardens must be actively cultivated or will be reassigned after one season.','citation':'Parks Code §14-9'},
    {'id':'47','title':'Noise (Festivals)','section':'Sec 3-50','text':'Outdoor festivals must end amplified music by 10pm on weekdays and 11pm on weekends.','citation':'Event Code §3-50'},
    {'id':'48','title':'Holiday Sales Tax','section':'Sec 19-5','text':'Temporary tax exemptions for small vendors require registration with the tax office.','citation':'Finance Code §19-5'},
    {'id':'49','title':'Public Safety','section':'Sec 6-12','text':'Feeding wildlife in city parks is prohibited to protect animal health and public safety.','citation':'Wildlife Code §6-12'},
    {'id':'50','title':'Noise (Bicycles)','section':'Sec 9-12','text':'Bicycle bells must be audible at 25 feet to be compliant with safety standards.','citation':'Traffic Code §9-12'},
    {'id':'51','title':'Street Lighting','section':'Sec 22-1','text':'Residents may request a light outage inspection; repairs prioritized by safety impact.','citation':'Public Works §22-1'},
    {'id':'52','title':'Noise (Theaters)','section':'Sec 3-60','text':'Movie theaters must limit pre-show advertisements to 10 minutes to reduce late-night noise.','citation':'Entertainment Code §3-60'},
    {'id':'53','title':'Holiday Tree Disposal','section':'Sec 12-18','text':'Residents must place holiday trees at curbside on scheduled pickup days for recycling.','citation':'Sanitation Code §12-18'},
    {'id':'54','title':'Noise (Pets at Large)','section':'Sec 5-15','text':'Allowing a dog to roam off-leash in a non-designated area is a civil infraction.','citation':'Animal Control §5-15'},
    {'id':'55','title':'Public Art Removal','section':'Sec 13-9','text':'Temporary public art installations must include a removal plan and bond for cleanup.','citation':'Arts Code §13-9'},
    {'id':'56','title':'Noise (Generators)','section':'Sec 3-70','text':'Portable generators may not be operated within 50 feet of residential windows overnight.','citation':'Safety Code §3-70'},
    {'id':'57','title':'Holiday Parade Floats','section':'Sec 17-4','text':'Float operators must secure all loose decorations to prevent debris on parade routes.','citation':'Event Code §17-4'},
    {'id':'58','title':'Public WiFi','section':'Sec 23-1','text':'Municipal public WiFi is provided as-is; users must not use it for illegal downloads.','citation':'IT Policy §23-1'},
    {'id':'59','title':'Noise (Schools After Hours)','section':'Sec 3-80','text':'School facilities used after hours must keep amplified sound below 70 dB at property lines.','citation':'Education Code §3-80'},
    {'id':'60','title':'Vendor Noise','section':'Sec 8-14','text':'Vendors using generators must use mufflers and place units away from residential windows.','citation':'Vendor Code §8-14'},
    {'id':'61','title':'Holiday Tree Lighting','section':'Sec 12-20','text':'Public tree lighting ceremonies require a safety plan and crowd control measures.','citation':'Event Code §12-20'},
    {'id':'62','title':'Noise (Ice Cream Trucks)','section':'Sec 3-85','text':'Ice cream truck music is limited to 30 seconds per block to reduce neighborhood disturbance.','citation':'Vendor Code §3-85'},
    {'id':'63','title':'Public Records','section':'Sec 24-1','text':'Requests for public records must be acknowledged within 5 business days with an estimated completion.','citation':'Records Code §24-1'},
    {'id':'64','title':'Noise (Bells at Noon)','section':'Sec 3-90','text':'Municipal noon bells are limited to one minute to avoid repeated disturbance.','citation':'Public Nuisance §3-90'},
    {'id':'65','title':'Holiday Fire Safety','section':'Sec 15-9','text':'Live holiday greenery must be kept moist and away from open flames in public displays.','citation':'Safety Code §15-9'},
    {'id':'66','title':'Noise (Delivery Trucks)','section':'Sec 4-30','text':'Delivery trucks are restricted from idling for more than 5 minutes in residential zones.','citation':'Traffic Code §4-30'},
    {'id':'67','title':'Public Markets (Pets)','section':'Sec 8-3','text':'Pets are allowed at outdoor markets only if leashed and with owner supervision.','citation':'Market Code §8-3'},
    {'id':'68','title':'Noise (Bells for Events)','section':'Sec 3-95','text':'Event bell ringing requires prior notice to nearby residential buildings.','citation':'Event Code §3-95'},
    {'id':'69','title':'Holiday Vendor Permits','section':'Sec 19-8','text':'Temporary holiday vendors must provide proof of liability insurance to obtain a permit.','citation':'Finance Code §19-8'},
    {'id':'70','title':'Noise (Quiet Zones)','section':'Sec 3-100','text':'Designated quiet zones near hospitals prohibit non-emergency sirens except for immediate danger.','citation':'Public Safety §3-100'}
]

# -------------------------
# UI / control flow
# -------------------------
def show_picks(picks: List[Dict], tts_enabled: bool):
    if not picks:
        print("No items to show.\n")
        return
    for p in picks:
        out = format_output(p)
        print(out)
        print()
        if tts_enabled:
            speak_text = f"{p.get('title','')}. {p.get('section','')}. {p.get('text','')} {p.get('citation','')}"
            speak(speak_text)

def interactive_mode(library: List[Dict], tts_enabled: bool):
    print("Law Quote Generator — interactive mode (type 'q' to quit at any prompt)")
    last_action = None  # tuple: (mode, seed, count)
    while True:
        if last_action is None:
            mode = input("Choose mode (random/search/quit) > ").strip().lower()
        else:
            mode = input("Press Enter to repeat last action, 'n' for new action, or 'q' to quit > ").strip().lower()
            if mode == '':
                mode = last_action[0]
            elif mode in ('n','new'):
                mode = input("Choose mode (random/search/quit) > ").strip().lower()

        if mode in ('q','quit','exit'):
            print("Goodbye.")
            break

        if mode == 'random':
            try:
                if last_action and last_action[0] == 'random':
                    default_n = str(last_action[2])
                else:
                    default_n = "1"
                n = int(input(f"How many quotes? (default {default_n}) > ") or default_n)
            except ValueError:
                n = 1
            picks = pick_random(library, n)
            show_picks(picks, tts_enabled)
            last_action = ('random', None, n)

        elif mode == 'search':
            if last_action and last_action[0] == 'search':
                default_seed = last_action[1] or ''
                default_n = str(last_action[2])
            else:
                default_seed = ''
                default_n = "1"
            seed = input(f"Enter keyword seed (default '{default_seed}') > ").strip() or default_seed
            if not seed:
                print("Empty seed; try again.")
                continue
            matches = find_matches(library, seed)
            if not matches:
                print("No matches found for that seed. Showing a random quote instead.\n")
                picks = pick_random(library, 1)
                n = 1
            else:
                try:
                    n = int(input(f"Found {len(matches)} matches. How many to show? (default {default_n}) > ") or default_n)
                except ValueError:
                    n = 1
                picks = pick_random(matches, n)
            show_picks(picks, tts_enabled)
            last_action = ('search', seed, n)

        else:
            print("Unknown mode. Choose random, search, or quit.")

def run_once(library: List[Dict], mode: str, seed: str, count: int, tts_enabled: bool) -> None:
    if mode == 'random':
        picks = pick_random(library, count)
    else:
        if not seed:
            print("Search mode requires --seed. Falling back to random.", file=sys.stderr)
            picks = pick_random(library, count)
        else:
            matches = find_matches(library, seed)
            if not matches:
                print("No matches found for seed; returning random results.", file=sys.stderr)
                picks = pick_random(library, count)
            else:
                picks = pick_random(matches, count)
    show_picks(picks, tts_enabled)

def prompt_after_run(current_mode: str, current_seed: str, current_count: int):
    try:
        resp = input("Press Enter to repeat, type 'n' for new action, or 'q' to quit > ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return ('quit', current_mode, current_seed, current_count)
    if resp in ('q','quit','exit'):
        return ('quit', current_mode, current_seed, current_count)
    if resp in ('n','new'):
        mode = input("Choose mode (random/search) > ").strip().lower()
        if mode not in ('random','search'):
            print("Invalid mode; defaulting to random.")
            mode = 'random'
        seed = current_seed
        count = current_count
        if mode == 'search':
            seed = input("Enter keyword seed > ").strip()
            if not seed:
                print("Empty seed; will use random instead.")
                mode = 'random'
        try:
            count = int(input("How many quotes? (default 1) > ") or "1")
        except ValueError:
            count = 1
        return ('new', mode, seed, count)
    return ('repeat', current_mode, current_seed, current_count)

# -------------------------
# Main
# -------------------------
def main():
    parser = argparse.ArgumentParser(description="Random Law Quote Generator with optional seeding and TTS.")
    parser.add_argument('--file', '-f', required=False, help='Path to laws CSV or JSON file.')
    parser.add_argument('--mode', '-m', choices=['random','search'], default='random', help='random or search mode')
    parser.add_argument('--seed', '-s', help='Keyword seed for search mode')
    parser.add_argument('--count', '-n', type=int, default=1, help='Number of quotes to return')
    parser.add_argument('--interactive', '-i', action='store_true', help='Run interactive prompt')
    # TTS enabled by default; --no-tts disables it
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--tts', dest='tts', action='store_true', help='Enable Text-to-Speech using OS-native tools (default)')
    group.add_argument('--no-tts', dest='tts', action='store_false', help='Disable Text-to-Speech')
    parser.set_defaults(tts=True)
    args = parser.parse_args()

    if not args.file:
        library = DEMO_LIBRARY
    else:
        try:
            library = load_library(args.file)
        except Exception as e:
            print(f"Failed to load library: {e}", file=sys.stderr)
            sys.exit(2)

    if args.interactive:
        interactive_mode(library, args.tts)
        return

    current_mode = args.mode
    current_seed = args.seed or ''
    current_count = args.count

    while True:
        run_once(library, current_mode, current_seed, current_count, args.tts)
        action, new_mode, new_seed, new_count = prompt_after_run(current_mode, current_seed, current_count)
        if action == 'quit':
            print("Goodbye.")
            break
        if action == 'repeat':
            continue
        if action == 'new':
            current_mode = new_mode
            current_seed = new_seed
            current_count = new_count
            continue

if __name__ == '__main__':
    main()
