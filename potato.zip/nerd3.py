#!/usr/bin/env python3
"""
nerd_accomplishments_tts_loop.py

Expanded nerd-accomplishment quote generator with:
- interactive repeat-and-quit loop
- TTS enabled by default using only system utilities (no pip, no PIL)
- CLI flags for non-interactive use and to disable TTS

TTS strategy (no external Python packages):
- macOS: uses `say`
- Windows: uses PowerShell + System.Speech (via subprocess)
- Linux: tries `spd-say` then `espeak` if available
If no system TTS is available the script prints a helpful message.
"""

import random
import argparse
import json
import shutil
import subprocess
import sys
import platform
from datetime import datetime

# --- MASSIVE WORD BANKS FOR NERD ACCOMPLISHMENT QUOTES ---
SUBJECTS = [
    "You", "Your code", "That pull request", "Your terminal", "Your debugger",
    "Your microcontroller", "Your neural net", "Your script", "Your build system",
    "Your CI runner", "Your VM", "Your container", "Your package manager",
    "Your IDE", "Your keyboard", "Your monitor", "Your laptop", "Your workstation",
    "Your repo", "Your branch", "Your commit", "Your README", "Your docs",
    "Your test suite", "Your test runner", "Your scheduler", "Your cron job",
    "Your router", "Your switch", "Your NAS", "Your backup script", "Your logger",
    "Your profiler", "Your optimizer", "Your compiler", "Your linker", "Your bootloader",
    "Your firmware", "Your PCB", "Your soldering iron", "Your oscilloscope",
    "Your multimeter", "Your 3D printer", "Your CAD file", "Your dataset",
    "Your model checkpoint", "Your hyperparameters", "Your data pipeline",
    "Your ETL job", "Your SQL query", "Your index", "Your cache", "Your CDN",
    "Your API", "Your endpoint", "Your webhook", "Your auth token", "Your SSL cert",
    "Your firewall rule", "Your VPN", "Your SSH key", "Your cron entry",
    "Your migration script", "Your schema", "Your ORM mapping", "Your lambda",
    "Your microservice", "Your monolith", "Your container image", "Your Dockerfile",
    "Your Makefile", "Your build script", "Your release notes", "Your changelog",
    "Your issue tracker", "Your backlog", "Your sprint board", "Your CI badge",
    "Your pair programming session", "Your code review", "Your refactor",
    "Your hotfix", "Your rollback", "Your feature flag", "Your integration test",
    "Your unit test", "Your mock", "Your stub", "Your fixture", "Your seed data",
    "Your keyboard shortcut", "Your plugin", "Your extension", "Your alias"
]

ACTIONS = [
    "survived", "mastered", "optimized", "debugged", "refactored",
    "containerized", "deployed", "documented", "automated", "reverse engineered",
    "patched", "patched and shipped", "profiled", "benchmarked", "parallelized",
    "serialized", "deserialized", "minified", "obfuscated", "linted",
    "formatted", "typed", "untangled", "modularized", "decoupled",
    "squashed", "merged", "rebased", "cherry-picked", "rolled back",
    "hotfixed", "patched", "hardened", "secured", "encrypted",
    "decrypted", "migrated", "upgraded", "downgraded", "container-slimmed",
    "cross-compiled", "cross-validated", "sanitized", "validated", "sanity-checked",
    "mocked", "stubbed", "seeded", "seeded and tested", "orchestrated",
    "scheduled", "provisioned", "deprovisioned", "virtualized", "emulated",
    "soldered", "wired", "etched", "routed", "sliced",
    "rendered", "compiled", "assembled", "disassembled", "documented thoroughly",
    "commented", "annotated", "translated", "localized", "container-orchestrated",
    "scaled", "load-tested", "stress-tested", "fuzz-tested", "sanitized inputs",
    "fixed a race condition", "fixed a deadlock", "fixed a memory leak",
    "recovered data", "restored a backup", "reindexed", "reconciled",
    "normalized", "denormalized", "indexed", "cached", "invalidated cache",
    "rolled out canary", "rolled out blue-green", "rolled out gradual deploy",
    "implemented feature toggle", "wrote a migration", "wrote a script",
    "wrote a plugin", "wrote a driver", "wrote a shim", "wrote a wrapper"
]

OBJECTS = [
    "a legacy codebase", "a race condition", "a memory leak", "a CI pipeline",
    "an obscure bug", "a 200-line regex", "an ancient dependency", "a flaky test suite",
    "a circular import", "a segfault", "a null pointer deref", "a stack overflow",
    "a deadlock", "a livelock", "a misconfigured DNS", "a broken SSL chain",
    "a missing semicolon", "a misplaced comma", "a confusing API", "a brittle test",
    "a failing build", "a merge conflict", "a broken migration", "a corrupt DB",
    "a missing index", "a slow query", "a noisy neighbor", "a throttled endpoint",
    "a misrouted packet", "a fried capacitor", "a cracked hose", "a leaky gasket",
    "a blown fuse", "a fried transistor", "a bad solder joint", "a warped PCB",
    "a misaligned stepper", "a clogged nozzle", "a corrupted checkpoint",
    "a mislabeled dataset", "a biased model", "a vanishing gradient", "an exploding gradient",
    "a bad hyperparameter", "a stale cache", "a race in tests", "a flaky integration",
    "a missing dependency", "a circular dependency", "a deprecated API",
    "a broken link", "a 404", "a 500", "a timeout", "a slow startup",
    "a noisy log", "a silent failure", "a permission error", "an auth failure",
    "a token expiry", "a misconfigured cron", "a zombie process", "a runaway job",
    "a miswired harness", "a bad connector", "a malformed payload", "a malformed header",
    "a malformed CSV", "a malformed JSON", "a malformed XML", "a bad regex",
    "a confusing UX flow", "a race in the scheduler", "a misbehaving plugin",
    "a broken symlink", "a missing file", "a corrupted image", "a bad checksum",
    "a checksum mismatch", "a stale lockfile", "a dead service", "a misrouted webhook"
]

RESULTS = [
    "without breaking anything", "and the tests still pass", "in under an hour",
    "with only one Stack Overflow tab", "and your coworkers applauded", "and the server didn't explode",
    "while drinking cold coffee", "and you didn't need to reboot", "with zero downtime",
    "with graceful degradation", "and the metrics improved", "and latency dropped",
    "and throughput doubled", "and memory usage halved", "and CPU stayed calm",
    "and the logs were readable", "and the CI badge turned green", "and the deploy was silent",
    "and the rollback was never needed", "and the users didn't notice", "and the pager stayed quiet",
    "and the boss sent a thumbs-up", "and the PR got merged", "and the release notes were short",
    "and the changelog was concise", "and the docs were updated", "and the tutorial worked",
    "and onboarding was easier", "and the demo didn't crash", "and the demo impressed",
    "and the demo didn't need a script", "and the demo ran on battery", "and the build finished early",
    "and the compile warnings vanished", "and the linter smiled", "and the profiler approved",
    "and the memory graph flattened", "and the GC behaved", "and the tests flaked no more",
    "and the flaky test became stable", "and the race condition surrendered", "and the deadlock untangled",
    "and the data was recovered", "and the backup restored cleanly", "and the migration completed",
    "and the DB stayed consistent", "and the index sped things up", "and the cache hit rate soared",
    "and the page load time dropped", "and the UX flowed", "and the user didn't rage-quit",
    "and the CI didn't time out", "and the build artifact was tiny", "and the binary fit the flash",
    "and the firmware flashed on first try", "and the printer didn't jam", "and the nozzle stayed cool",
    "and the stepper didn't skip", "and the solder joint held", "and the LED blinked happily",
    "and the model generalized", "and the validation loss fell", "and the ROC improved",
    "and the AUC rose", "and the accuracy climbed", "and the false positives dropped",
    "and the false negatives dropped", "and the pipeline didn't choke", "and the ETL finished before lunch"
]

TWISTS = [
    "You are now officially a wizard.", "Badge unlocked: Senior Problem Whisperer.",
    "Proceed to the next level: buy better headphones.", "This counts as cardio for your brain.",
    "Claim your free debugging cape.", "Add this to your resume under 'miracles'.",
    "Reward yourself with a snack.", "You earned a coffee and a nap.",
    "This is why you have trust issues with production.", "Now go write a blog post about it.",
    "Frame the terminal output and hang it on the wall.", "Tell your future self about this.",
    "You may now accept praise in the form of pizza.", "You have ascended to 'That Guy' status.",
    "Apply this achievement to your LinkedIn.", "This will haunt the next on-call rotation.",
    "You deserve a sticker.", "You unlocked the 'I fixed it' emote.",
    "Proceed to claim your debugging cape.", "You have earned the right to rename variables.",
    "This is a feature, not a bug (now).", "You have tamed the legacy beast.",
    "You are now a certified stack whisperer.", "You may now speak in commit messages only.",
    "Add 'saves production' to your business card.", "You have earned a free merge.",
    "You can now retire gracefully (or not).", "This will be a footnote in the project's history.",
    "You have achieved temporary immortality in logs.", "You are the reason the CI pipeline breathes.",
    "You have unlocked 'Senior Problem Whisperer' badge.", "You have earned the right to a new sticker pack.",
    "Your future self thanks you.", "You may now take a victory lap around the office.",
    "This counts as 30 minutes of professional development.", "You have earned a debugging cape and a cookie.",
    "Claim your free upgrade to 'Legend' status.", "You are now a minor deity in the error namespace.",
    "You have successfully bribed the compiler.", "You have negotiated peace between modules.",
    "You have outsmarted the machine.", "You have outwitted the stack.",
    "You have tamed the wild dependency.", "You have made the logs readable for humans.",
    "You have earned the right to rename the function 'do_stuff'.", "You have earned a new alias: 'The Fixer'.",
    "You have earned the respect of the linter.", "You have earned a quiet weekend."
]

TEMPLATES = [
    "{subject} {action} {object} {result}. {twist}",
    "{subject} {action} {object} {result}.",
    "Achievement unlocked: {action} {object}. {twist}",
    "{subject} just {action} {object} — {result}.",
    "Pro tip: {subject} {action} {object} {result}.",
    "Status update: {subject} {action} {object} {result}.",
    "Mic drop: {subject} {action} {object} {result}. {twist}",
    "Dev log: {subject} {action} {object} {result}.",
    "Commit message: {action} {object}. {twist}",
    "Release note: {subject} {action} {object} {result}.",
    "TL;DR: {subject} {action} {object}. {twist}",
    "Daily win: {subject} {action} {object} {result}.",
    "Pro move: {subject} {action} {object} {result}.",
    "Legendary: {subject} {action} {object} {result}. {twist}",
    "Patch notes: {action} {object} — {result}.",
    "Ops report: {subject} {action} {object} {result}.",
    "QA: {subject} {action} {object} {result}.",
    "Hot take: {subject} {action} {object} {result}.",
    "Memo: {subject} {action} {object} {result}.",
    "FYI: {subject} {action} {object} {result}. {twist}",
    "Pro tip: when {subject} {action} {object}, expect {result}.",
    "If at first you don't succeed, {subject} {action} {object} {result}.",
    "In other news: {subject} {action} {object} {result}.",
    "Achievement: {subject} {action} {object}. {twist}",
    "Victory log: {subject} {action} {object} {result}.",
    "Status: {subject} {action} {object} — {result}.",
    "Note to self: {subject} {action} {object} {result}.",
    "Pro tip for interns: {subject} {action} {object} {result}.",
    "Engineering folklore: {subject} {action} {object} {result}. {twist}",
    "War story: {subject} {action} {object} {result}.",
    "Debug diary: {subject} {action} {object} {result}.",
    "Patch summary: {action} {object} {result}.",
    "Kudos: {subject} {action} {object} {result}.",
    "Shoutout: {subject} {action} {object} {result}. {twist}",
    "Milestone: {subject} {action} {object} {result}.",
    "Pro-level: {subject} {action} {object} {result}.",
    "Tiny victory: {subject} {action} {object} {result}.",
    "Big brain move: {subject} {action} {object} {result}. {twist}",
    "Slogan: {subject} {action} {object} {result}.",
    "One-liner: {subject} {action} {object} {result}.",
    "Elevator pitch: {subject} {action} {object} {result}. {twist}"
]

# -------------------------
# Quote generation
# -------------------------
def generate_quote(seed=None, twist_chance=0.35):
    """Generate a single nerd accomplishment quote."""
    if seed is not None:
        random.seed(seed)
    template = random.choice(TEMPLATES)
    subject = random.choice(SUBJECTS)
    action = random.choice(ACTIONS)
    obj = random.choice(OBJECTS)
    result = random.choice(RESULTS)
    twist = random.choice(TWISTS) if random.random() < twist_chance else ""
    quote = template.format(subject=subject, action=action, object=obj, result=result, twist=twist)
    return " ".join(quote.split())

def generate_many(n=10, seed=None, twist_chance=0.35):
    """Generate multiple quotes and return as a list."""
    quotes = []
    for i in range(n):
        s = None if seed is None else seed + i
        quotes.append(generate_quote(seed=s, twist_chance=twist_chance))
    return quotes

def save_to_file(quotes, filename):
    """Save quotes to a JSON file with timestamp."""
    payload = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "count": len(quotes),
        "quotes": quotes
    }
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return filename

# -------------------------
# TTS (no pip) utilities
# -------------------------
def _tts_mac(text):
    """Use macOS `say` command."""
    try:
        subprocess.run(["say", text], check=False)
        return True
    except Exception:
        return False

def _tts_windows(text):
    """
    Use PowerShell and System.Speech.Synthesis.SpeechSynthesizer.
    This avoids external Python packages by invoking PowerShell.
    """
    # Escape double quotes for PowerShell string literal
    safe_text = text.replace('"', '`"')
    ps_cmd = (
        'Add-Type -AssemblyName System.Speech;'
        f'$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;'
        f'$s.Speak("{safe_text}");'
    )
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
        return True
    except Exception:
        return False

def _tts_linux(text):
    """Try spd-say then espeak if available."""
    if shutil.which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=False)
            return True
        except Exception:
            pass
    if shutil.which("espeak"):
        try:
            subprocess.run(["espeak", text], check=False)
            return True
        except Exception:
            pass
    return False

def speak_text(text):
    """Cross-platform TTS wrapper. Returns True if spoken, False otherwise."""
    system = platform.system()
    # Limit length to avoid shell issues
    max_len = 800
    if len(text) > max_len:
        text = text[:max_len].rsplit(" ", 1)[0] + "..."
    if system == "Darwin":
        return _tts_mac(text)
    elif system == "Windows":
        return _tts_windows(text)
    else:
        return _tts_linux(text)

# -------------------------
# Interactive loop
# -------------------------
def interactive_loop(seed=None, twist_chance=0.35, tts_enabled=True):
    """Run an interactive repeat-and-quit loop."""
    print("Nerd Accomplishment Generator — interactive mode")
    print("Press Enter to generate, type 'n <count>' to generate multiple, 's' to save last batch, 'q' to quit.")
    last_batch = []
    counter = 0
    base_seed = seed if seed is not None else random.randrange(1 << 30)
    while True:
        try:
            user = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            break

        if user.lower() in ("q", "quit", "exit"):
            print("Goodbye.")
            break

        if user.lower().startswith("n "):
            # generate N quotes
            try:
                n = int(user.split()[1])
            except Exception:
                print("Usage: n <count>  (e.g. n 5)")
                continue
            quotes = generate_many(n=n, seed=base_seed + counter, twist_chance=twist_chance)
            counter += n
            last_batch = quotes
            for q in quotes:
                print(q)
                if tts_enabled:
                    ok = speak_text(q)
                    if not ok:
                        print("(TTS not available on this system or no suitable TTS utility found.)")
            continue

        if user.lower() in ("s", "save"):
            if not last_batch:
                print("No quotes to save yet.")
                continue
            fname = f"nerd_quotes_{datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')}.json"
            save_to_file(last_batch, fname)
            print(f"Saved {len(last_batch)} quotes to {fname}")
            continue

        # default: generate one quote
        quote = generate_quote(seed=base_seed + counter, twist_chance=twist_chance)
        counter += 1
        last_batch = [quote]
        print(quote)
        if tts_enabled:
            ok = speak_text(quote)
            if not ok:
                print("(TTS not available on this system or no suitable TTS utility found.)")

# -------------------------
# CLI entrypoint
# -------------------------
def main():
    parser = argparse.ArgumentParser(description="Generate nerd accomplishment quotes (interactive, TTS on by default, no pip).")
    parser.add_argument("-n", "--number", type=int, default=None, help="Generate N quotes and exit (non-interactive).")
    parser.add_argument("-s", "--seed", type=int, default=None, help="Optional random seed for reproducibility.")
    parser.add_argument("-t", "--twist", type=float, default=0.35, help="Probability [0-1] to append a witty twist.")
    parser.add_argument("--interactive", action="store_true", help="Run interactive repeat-and-quit loop.")
    parser.add_argument("--no-tts", action="store_true", help="Disable TTS (TTS is enabled by default).")
    parser.add_argument("-o", "--output", type=str, default=None, help="Save output to a JSON file (non-interactive mode).")
    args = parser.parse_args()

    tts_enabled = not args.no_tts  # TTS on by default

    if args.number is not None and not args.interactive:
        quotes = generate_many(n=args.number, seed=args.seed, twist_chance=args.twist)
        for q in quotes:
            print(q)
            if tts_enabled:
                ok = speak_text(q)
                if not ok:
                    print("(TTS not available or no suitable system TTS found.)")
        if args.output:
            saved = save_to_file(quotes, args.output)
            print(f"\nSaved {len(quotes)} quotes to {saved}")
        return

    # Default: interactive loop (TTS on by default)
    interactive_loop(seed=args.seed, twist_chance=args.twist, tts_enabled=tts_enabled)

if __name__ == "__main__":
    main()
