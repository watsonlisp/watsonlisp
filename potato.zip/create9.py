#!/usr/bin/env python3
"""
Creativity Coach with built-in TTS (no pip required).
TTS is on by default and uses system tools:
  - macOS: say
  - Windows: PowerShell System.Speech
  - Linux: espeak or spd-say (if available)
If no system TTS is available, it falls back to printing the text.

Runs repeatedly until the user chooses to quit.
Defaults for interactive prompts are populated from the most recent saved prompt (if any).
Timer and "How many minutes do you have?" features removed.
Menu consolidated into a single prompt line.
Supports generating multiple variations in one run using the same inputs.
"""

import random
import json
import threading
import subprocess
import shutil
import platform
from datetime import datetime
from pathlib import Path

HISTORY_FILE = "creativity_history.json"
TTS_ENABLED = True  # TTS on by default

PROMPT_TEMPLATES = {
    "writing": [
        "Write a short scene (300-600 words) where {subject} discovers a secret in {place}.",
        "Compose a letter from {subject} to their future self about {theme}.",
        "Write a microfiction (under 200 words) that begins with: '{line}'.",
        "Write a letter from {subject} to someone they lost, describing {theme} without naming it.",
        "Draft a scene where {subject} must choose between two doors in {place}; reveal the choice only through sensory detail.",
        "Write a short story (500-800 words) told entirely as a series of receipts and notes found in {place}.",
        "Compose a monologue where {subject} argues with their younger self about {theme}.",
        "Write a piece in which every paragraph ends with a different season; the setting is {place}.",
        "Create a dialogue between two objects in {place} that remember {theme}.",
        "Write a flash fiction (150 words) that begins with: '{line}' and ends with a question.",
        "Tell a story from the perspective of an unreliable narrator who keeps misnaming {place}.",
        "Write a scene where {subject} discovers a map that leads to an emotion instead of a place.",
        "Compose a short myth explaining why {place} behaves the way it does, using {theme} as the moral.",
        "Write a series of three micro-letters from {subject} to a future city about {mood}.",
        "Create a character sketch of {subject} using only metaphors drawn from weather.",
        "Write a scene where time moves backward for five minutes in {place}; focus on cause and consequence.",
        "Draft a news article from an alternate history where {impossible_product} exists and changed {theme}.",
        "Write a recipe-style instruction for performing {theme} as if it were a dish."
    ],
    "visual": [
        "Create a quick sketch inspired by {subject} using only {limited_palette}.",
        "Design a poster that advertises an impossible product: {impossible_product}.",
        "Make a collage (digital or paper) that represents the feeling of {mood}.",
        "Design a poster advertising a festival in {place} that celebrates {theme} using only {limited_palette}.",
        "Create a character portrait of {subject} using collage elements from magazines and found text.",
        "Sketch a cityscape where buildings are shaped by people's memories of {mood}.",
        "Make a one-page comic strip where the punchline reframes {theme}.",
        "Design packaging for {impossible_product} as if it were sold in the 1970s.",
        "Create a diptych: left panel shows {place} at dawn, right panel shows it at midnight; connect them with a single motif.",
        "Produce a minimalist poster that communicates {theme} without words.",
        "Make a series of three thumbnails exploring different silhouettes for {subject}.",
        "Create a map of an imaginary island where each region represents a different emotion tied to {mood}.",
        "Design a book cover for a novel titled '{theme}' set in {place}.",
        "Paint or draw a still life that includes an unexpected animal and an everyday object that symbolizes {theme}.",
        "Create a typographic piece that uses only one repeated word to express {mood}.",
        "Design a logo for a secret society that protects {place}.",
        "Make a storyboard for a 30-second visual poem about {subject}."
    ],
    "music": [
        "Compose a 30-second melody in {mode} that repeats a motif three times.",
        "Create a rhythm using only body percussion and record one loop.",
        "Write lyrics for a chorus about {theme} and set them to a simple chord progression.",
        "Compose a 16-bar melody that repeats a motif and shifts mode halfway through; base the mood on {mood}.",
        "Write a chorus about {theme} using only three chords in {mode}.",
        "Create a percussion loop using household objects that evokes {place}.",
        "Write a lullaby for {subject} that includes an unexpected rhythmic pattern.",
        "Compose a short ambient piece inspired by the soundscape of {place}.",
        "Write lyrics that tell a complete story in four lines about {theme}.",
        "Create a call-and-response melody where the second phrase answers the first with a different instrument.",
        "Arrange a familiar nursery rhyme into {genre} style and add a twist about {mood}.",
        "Compose a 30-second motif that can be layered into a longer piece; label each layer with an emotion.",
        "Write a bridge that changes the song's perspective from first person to third person.",
        "Create a harmonic progression that resolves unexpectedly to highlight {theme}.",
        "Write a short jingle advertising {impossible_product} in a retro radio style."
    ],
    "improv": [
        "Perform a 2-minute monologue as {character} who is stuck in {place}.",
        "Improvise a scene with the rule: no character can say the word 'no'.",
        "Act out a conversation where every line must be a question.",
        "Perform a two-minute scene where every line must include a color from {limited_palette}.",
        "Improvise a conversation in which each character speaks in a different tense about {theme}.",
        "Act out a scene where {subject} cannot use nouns for the first minute.",
        "Create a silent improv where actions alone reveal a secret about {place}.",
        "Improvise a scene that begins with the line: '{line}' and ends with a physical prop reveal.",
        "Perform a scene where the rule is: every time someone laughs, the scene must change location.",
        "Improvise a negotiation between two characters over ownership of {impossible_product}.",
        "Do a one-person improv where you play three generations of the same family in {place}.",
        "Improvise a scene where the audience supplies a single word that must be used in every line.",
        "Perform a scene where characters can only speak in questions for the first two minutes.",
        "Improvise a monologue as {subject} who is trying to teach someone about {theme}.",
        "Create a scene where the environment (sound or light) dictates the emotional tone."
    ],
    "remix": [
        "Take a familiar song or poem and rewrite it in a different genre: {genre}.",
        "Remix a childhood memory into a sci-fi short scene.",
        "Turn a news headline into a haiku.",
        "Take a well-known fairy tale and retell it as a noir short scene set in {place}.",
        "Remix a childhood memory into a futuristic short story about {impossible_product}.",
        "Turn a news headline into a haiku that captures {theme}.",
        "Rewrite a classic poem in the voice of {subject} living in {place}.",
        "Take a pop song and rewrite its chorus as a protest chant about {theme}.",
        "Remix a recipe into a love letter that uses cooking steps as metaphors for {mood}.",
        "Transform a mundane email into a dramatic monologue for the stage.",
        "Take a famous painting and write a short scene imagining what happens next in the image.",
        "Remix a childhood game into a board game concept that teaches {theme}.",
        "Turn a weather report into a short speculative fiction premise about {place}.",
        "Rewrite a commercial jingle as a solemn hymn about {impossible_product}.",
        "Remix a social media thread into a short epistolary story."
    ],
    "design": [
        "Design a tiny living space for {subject} in {place} using only modular furniture.",
        "Create a user interface for an app that helps people track {mood}.",
        "Design a public bench that encourages strangers to share stories about {theme}.",
        "Sketch a concept for a wearable that translates emotions into color from {limited_palette}.",
        "Design packaging for a product that must be opened in a ritualistic way.",
        "Create a transit map for a city where routes are named after emotions.",
        "Design a poster series that teaches one micro-habit related to {theme}.",
        "Create a set of icons that represent five stages of {mood}.",
        "Design a tiny book layout for a 24-page chapbook about {place}.",
        "Sketch a concept for a pop-up shop that sells memories as souvenirs.",
        "Design a festival badge system that rewards acts of kindness tied to {theme}.",
        "Create a concept for a public art installation that reacts to weather.",
        "Design a simple board game that teaches negotiation using {impossible_product}.",
        "Create a set of postcards that together tell a story about {subject}.",
        "Design a poster that uses only negative space to show {mood}."
    ],
    "photography": [
        "Shoot a series of five photos that capture {mood} in {place} using only natural light.",
        "Create a portrait series where each subject holds an object that reveals {theme}.",
        "Photograph a day in the life of {subject} using only close-up details.",
        "Make a black-and-white photo essay about a hidden corner of {place}.",
        "Create a diptych pairing a human-made object with a natural element to show contrast.",
        "Shoot a sequence that tells a story in exactly six frames.",
        "Photograph reflections in {place} and use them to reveal a secret about {theme}.",
        "Make a long-exposure image that visualizes movement tied to {mood}.",
        "Create a still life that includes {impossible_product} as if it were real.",
        "Photograph strangers and ask them one question about {theme}; pair image with quote.",
        "Make a portrait using only one color from {limited_palette} as a backdrop.",
        "Create a series of images that explore scale by juxtaposing tiny and huge objects.",
        "Shoot a photo that could be mistaken for a painting; explain the technique in a caption.",
        "Photograph a doorway in {place} from three different angles and stitch them into a triptych.",
        "Create a photo story that begins at dawn and ends at dusk in {place}."
    ],
    "film": [
        "Storyboard a 60-second film where the protagonist finds {impossible_product} and must decide what to do.",
        "Write a short film logline about {subject} who returns to {place} after many years.",
        "Create a shot list for a scene that reveals {theme} through objects, not dialogue.",
        "Draft a 3-minute silent film concept that uses only music and movement to convey {mood}.",
        "Write a scene where the camera never cuts away from a single object in {place}.",
        "Plan a micro-documentary about a local tradition tied to {theme}.",
        "Create a film treatment where the antagonist is a weather pattern in {place}.",
        "Write a short script where every line is spoken off-screen and the visuals tell the story.",
        "Storyboard a chase sequence that takes place entirely inside a building in {place}.",
        "Draft a scene where the protagonist learns a secret by watching old home videos.",
        "Plan a one-take scene that escalates from calm to chaos in five minutes.",
        "Write a short film that uses a single prop to connect three different time periods.",
        "Create a concept for a film festival program centered on {mood}.",
        "Draft a trailer for a fictional product that solves a small, human problem related to {theme}.",
        "Write a scene where the soundtrack is the main character and the visuals are secondary."
    ],
    "crafts": [
        "Make a small handmade book that folds into a secret compartment for a note about {theme}.",
        "Create a wearable made from recycled materials that represents {mood}.",
        "Design a paper toy that transforms between two states representing {place}.",
        "Build a tiny diorama that captures a memory of {subject}.",
        "Create a set of handmade postcards using collage and one repeated phrase.",
        "Make a simple puppet and perform a one-minute scene about {theme}.",
        "Craft a decorative jar that collects small objects representing daily joys.",
        "Sew a patch that symbolizes {mood} and explain its stitches in a short note.",
        "Make a set of three bookmarks that together tell a micro-story.",
        "Create a handmade zine (4 pages) about an impossible product and its uses.",
        "Build a simple mechanical toy that moves when you pull a tab and reveals a secret.",
        "Make a set of gift tags that each include a tiny writing prompt.",
        "Create a paper mask that changes expression when tilted.",
        "Design a small ritual object that helps someone mark the end of a day.",
        "Make a decorative map that marks emotional landmarks instead of streets."
    ]
}

TWISTS = [
    "use only three colors",
    "include an unexpected animal",
    "make it silent (no dialogue)",
    "use a palindrome somewhere",
    "repeat one word exactly five times",
    "limit yourself to one paragraph",
    "write in second person",
    "use only present tense",
    "avoid the letter 'e' for one paragraph",
    "start with a question and end with a command",
    "write as a list of instructions",
    "use only sensory details (no names)",
    "include a hidden acrostic",
    "write in the voice of a child",
    "write in the voice of an elder",
    "use only one-syllable words for one paragraph",
    "include a surprising metaphor",
    "frame it as a found object",
    "make the protagonist an inanimate object",
    "use only dialogue",
    "write as a series of headlines",
    "use a repeating motif every other sentence",
    "end with an unresolved image",
    "begin in medias res",
    "use a non-linear timeline",
    "write as a confession",
    "write as a recipe",
    "use a constraint: no adjectives",
    "use a constraint: no verbs",
    "use only questions",
    "include a secret code (A=1 style)",
    "write as a postcard",
    "write as a voicemail transcript",
    "use alternating perspectives each sentence",
    "include a sudden genre shift",
    "write as if for radio",
    "write as if for a silent film",
    "use only punctuation and no letters for one line",
    "repeat the first word of the piece at the end",
    "use a circular structure (end where you began)",
    "write as a dialogue between two memories",
    "use a constraint: every sentence must be under 10 words",
    "use a constraint: every sentence must be over 20 words",
    "write in a formal register then switch to slang",
    "use a single repeated sentence with small changes",
    "write as a map legend",
    "use a constraint: no commas",
    "use a constraint: no periods",
    "write as a classified ad",
    "write as a weather report",
    "use only colors as descriptors",
    "write as a child's drawing caption",
    "write as a museum placard",
    "use a constraint: alternate lines rhyme",
    "use a constraint: every third word is capitalized",
    "write as a series of text messages",
    "write as a shopping list that tells a story",
    "use a constraint: include exactly three questions",
    "write as a letter to an unknown recipient",
    "write as a legal clause",
    "use a constraint: include one invented word",
    "write as a travel itinerary for an emotion",
    "use a constraint: no letter 'a' for one paragraph",
    "write as a child's bedtime promise",
    "write as a press release for an impossible product",
    "use a constraint: every sentence begins with the same letter",
    "write as a confession to a tree",
    "use a constraint: include a palindrome phrase",
    "write as a list of things not to do",
    "write as a set of stage directions",
    "use a constraint: include a haiku somewhere",
    "write as a short FAQ",
    "use a constraint: alternate between past and future tense",
    "write as a series of labels on jars",
    "use a constraint: no pronouns",
    "write as a child's game rules",
    "use a constraint: include a hidden rhyme scheme",
    "write as a weathered postcard from the future",
    "use a constraint: every sentence must contain a color",
    "write as a radio jingle chorus",
    "use a constraint: include a line in another language",
    "write as a list of regrets turned into advice",
    "use a constraint: include a repeated numeric pattern",
    "write as a dialogue with silence",
    "use a constraint: every sentence ends with the same word",
    "write as a set of instructions for a ritual",
    "use a constraint: include exactly two commas per sentence",
    "write as a child's lost memory",
    "use a constraint: write without the letter 's' for one paragraph",
    "write as a series of postcards from different years",
    "use a constraint: include a clock time in every paragraph",
    "write as a product review for an emotion",
    "use a constraint: alternate sentence length short/long",
    "write as a map of smells",
    "use a constraint: include a color and a sound in each sentence",
    "write as a conversation between two shadows",
    "use a constraint: include a palindrome word",
    "write as a list of things that never happened",
    "use a constraint: write only in questions and exclamations",
    "write as a child's promise to the moon",
    "use a constraint: include a repeated three-word phrase",
    "write as a set of clues for a scavenger hunt",
    "use a constraint: no letter 't' for one paragraph",
    "write as a short myth explaining a modern object",
    "use a constraint: every sentence must include a number",
    "write as a recipe for forgetting",
    "use a constraint: include a line break after every two words",
    "write as a list of things the wind would say",
    "use a constraint: include a color, an animal, and a verb in each sentence",
    "write as a child's drawing turned into a story",
    "use a constraint: write in alternating syllable counts",
    "write as a set of instructions for building a memory",
    "use a constraint: include a musical term in every sentence",
    "write as a conversation between a clock and a photograph",
    "use a constraint: include a different season in each paragraph",
    "write as a letter from a future self with one secret",
    "use a constraint: every sentence must contain a city name",
    "write as a list of small rebellions",
    "use a constraint: include a repeated punctuation mark as motif",
    "write as a child's list of impossible inventions",
    "use a constraint: include a palindrome sentence",
    "write as a set of instructions for a dream",
    "use a constraint: include a color and a taste in each line",
    "write as a short scene where the weather is the antagonist",
    "use a constraint: every sentence must include a household object",
    "write as a series of micro-epiphanies",
    "use a constraint: include a repeated rhyme word at line ends",
    "write as a conversation with a closed door",
    "use a constraint: write one sentence that contains all vowels in order",
    "write as a list of things you would whisper to a river",
    "use a constraint: include a different punctuation mark as a motif each sentence",
    "write as a child's map to a secret place",
    "use a constraint: include a repeated three-syllable word",
    "write as a short scene told through labels and signs",
    "use a constraint: include a color, a number, and a sound in each sentence"
]

LIMITED_PALETTES = ["black and white", "warm tones", "cool tones", "neon accents", "muted earth tones"]

IMPOSSIBLE_PRODUCTS = [
    "a pocket-sized weather machine",
    "a self-folding shirt",
    "a plant that hums lullabies",
    "a clock that counts memories instead of minutes"
]

MODES = ["major", "minor", "dorian", "mixolydian", "pentatonic", "phrygian"]

# ---------------- TTS utilities ----------------

def _speak_system(text: str):
    system = platform.system().lower()
    if system == "darwin" and shutil.which("say"):
        try:
            subprocess.run(["say", text], check=False)
            return
        except Exception:
            pass
    if system == "windows":
        safe = text.replace("'", "''")
        ps_cmd = (
            "Add-Type -AssemblyName System.Speech;"
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            f"$s.Speak('{safe}');"
        )
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return
        except Exception:
            pass
    if system == "linux":
        if shutil.which("espeak"):
            try:
                subprocess.run(["espeak", text], check=False)
                return
            except Exception:
                pass
        if shutil.which("spd-say"):
            try:
                subprocess.run(["spd-say", text], check=False)
                return
            except Exception:
                pass
    print("[TTS unavailable] " + text)

def speak(text: str):
    if not TTS_ENABLED:
        return
    thread = threading.Thread(target=_speak_system, args=(text,), daemon=True)
    thread.start()

# ---------------- file history ----------------

def load_history():
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def save_history(history):
    Path(HISTORY_FILE).parent.mkdir(parents=True, exist_ok=True)
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)

def get_last_entry():
    history = load_history()
    if history:
        return history[-1]
    return {}

def ask(prompt, default=None):
    resp = input(f"{prompt} " + (f"[{default}] " if default else ""))
    return resp.strip() or (default or "")

def choose_template(medium):
    templates = PROMPT_TEMPLATES.get(medium, [])
    if not templates:
        templates = random.choice(list(PROMPT_TEMPLATES.values()))
    return random.choice(templates)

def build_prompt_from_values(values):
    """
    Build a prompt using explicit values dict (no interactive asks).
    This is used when re-running multiple variations while keeping inputs constant.
    """
    impossible_product = random.choice(IMPOSSIBLE_PRODUCTS)
    limited_palette = random.choice(LIMITED_PALETTES)
    mode = random.choice(MODES)
    template = choose_template(values["medium"])
    prompt_text = template.format(
        subject=values["subject"],
        place=values["place"],
        theme=values["theme"],
        line=values["line"],
        impossible_product=impossible_product,
        limited_palette=limited_palette,
        mood=values["mood"],
        genre=values["genre"],
        mode=mode,
        character=values["character"]
    )
    twist = random.choice(TWISTS)
    full_prompt = f"{prompt_text} Twist: {twist}."
    return full_prompt

def interactive_collect_defaults(last):
    """Collect interactive fields once and return a dict of values to reuse."""
    defaults = {
        "mood": last.get("mood", "curious"),
        "medium": last.get("medium", "writing"),
        "subject": last.get("subject", "a traveler"),
        "place": last.get("place", "an old train station"),
        "theme": last.get("theme", last.get("mood", "curiosity")),
        "line": last.get("line", "The light smelled like rain."),
        "genre": last.get("genre", "noir"),
        "character": last.get("character", "the librarian")
    }

    # Ask core interactive fields once
    mood = ask("How are you feeling right now (mood)?", defaults["mood"])
    medium = ask("Preferred medium (writing, visual, music, improv, remix, design, photography, film, crafts)?", defaults["medium"]).lower()
    subject = ask("Give a subject or character (one or two words)", defaults["subject"])
    place = ask("Name a place (real or imaginary)", defaults["place"])
    theme = ask("Give a theme or emotion (e.g., longing, joy)", defaults["theme"])
    line = ask("Give a first line (or press enter to auto-generate)", defaults["line"])
    genre = ask("Pick a genre for remix (e.g., noir, pop, ambient)", defaults["genre"])
    character = ask("Name a character (for improv templates)", defaults["character"])

    # Ask how many variations to generate
    redo_raw = ask("How many variations would you like to generate with these inputs? (enter a number)", "1")
    try:
        redo_count = max(1, int(redo_raw))
    except Exception:
        redo_count = 1

    values = {
        "mood": mood,
        "medium": medium,
        "subject": subject,
        "place": place,
        "theme": theme,
        "line": line,
        "genre": genre,
        "character": character,
        "redo_count": redo_count
    }
    return values

def show_history():
    history = load_history()
    if not history:
        print("No prompts saved yet.")
        return
    for i, entry in enumerate(history, 1):
        ts = entry.get("timestamp", "")
        mood = entry.get("mood", "")
        medium = entry.get("medium", "")
        prompt = entry.get("prompt", "")
        print(f"\n[{i}] {ts} | mood: {mood} | medium: {medium}")
        print(prompt)
    print("\nEnd of history.\n")

def run_once():
    global TTS_ENABLED
    last = get_last_entry()
    # Collect interactive inputs once and get redo_count
    values = interactive_collect_defaults(last)
    redo_count = values.pop("redo_count", 1)

    history = load_history()
    for i in range(redo_count):
        prompt = build_prompt_from_values(values)
        print(f"\n--- Variation {i+1} of {redo_count} ---\n")
        print(prompt)
        print("\n-------------------\n")

        if TTS_ENABLED:
            speak(prompt)

        save = ask("Save this prompt to history? (y/n)", "y").lower().startswith("y")
        if save:
            entry = {
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "mood": values.get("mood"),
                "medium": values.get("medium"),
                "prompt": prompt,
                # store the used interactive fields so they become defaults next time
                "subject": values.get("subject"),
                "place": values.get("place"),
                "theme": values.get("theme"),
                "line": values.get("line"),
                "genre": values.get("genre"),
                "character": values.get("character")
            }
            history.append(entry)
            save_history(history)
            print("Saved to", HISTORY_FILE)

def main():
    global TTS_ENABLED
    header = "=== Creativity Coach ===  (R)un  (H)istory  (T)oggle TTS  (Q)uit"
    print(header)
    while True:
        status = "ON" if TTS_ENABLED else "OFF"
        choice = ask(f"[{status}] Choose R/H/T/Q or press Enter to Run", "R").strip().lower()
        if choice in ("q", "quit"):
            print("Goodbye — keep creating.")
            break
        elif choice in ("h", "history"):
            show_history()
        elif choice in ("t", "toggle"):
            TTS_ENABLED = not TTS_ENABLED
            print("TTS is now", "ON" if TTS_ENABLED else "OFF")
        else:
            run_once()

if __name__ == "__main__":
    main()
