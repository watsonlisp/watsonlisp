#!/usr/bin/env python3
# random_lyrics_menu_full_prompt.py
import random
import platform
import shutil
import subprocess
import sys
import time

LYRIC_LINES = [
    "Neon mornings paint the sky in gold",
    "We chase the echoes of a midnight song",
    "Paper boats and promises afloat",
    "Your laughter is the map I keep",
    "City lights like scattered constellations",
    "I learned to dance with all my shadows",
    "Whispers turn to bridges in the rain",
    "Hold the moment like a fragile flame",
    "We write our names on the back of time",
    "Slow breaths, the world rearranges",
    "Moonlight stitches silver into the dark",
    "Coffee steam carries yesterday away",
    "Footsteps hum the rhythm of the street",
    "Windows hold the stories we forget",
    "A paper plane remembers how to fly",
    "Your silence is a room I wander in",
    "Thunder drums the secret of the sea",
    "We trade our fears for borrowed stars",
    "The horizon keeps a patient grin",
    "Leaves applaud the passing of the sun",
    "I keep a pocket full of unfinished songs",
    "Rain writes letters on the windowpane",
    "We fold our wishes into paper cranes",
    "The city breathes in neon and sighs",
    "Old photographs smell like summer rain",
    "A single chord can open locked doors",
    "We plant our doubts and watch them bloom",
    "Streetlamps sketch the edges of our names",
    "Your shadow learned to speak my language",
    "I collect small moments like rare coins",
    "The train hums lullabies to sleeping towns",
    "We trade maps for the thrill of getting lost",
    "Sunset melts the day into a promise",
    "Our footprints fade but the song remains",
    "I keep a lighthouse in my pocket for you",
    "The ocean folds its hands and listens",
    "We build cathedrals out of quiet afternoons",
    "Your smile is a compass I follow home",
    "The clock forgets to count our laughter",
    "We hang our hopes on telephone wires",
    "A stray melody finds its way to me",
    "The alleyway remembers every goodbye",
    "We sip the moon like warm chamomile",
    "Your voice is a doorway I step through",
    "The sky borrows colors from our dreams",
    "We barter secrets with the passing wind",
    "A single match can rewrite the night",
    "We keep our promises in jars of light",
    "The city hums like a sleeping giant",
    "Your hand fits the map of my palm",
    "I learned to read the weather in your eyes",
    "We fold the world into a paper song",
    "The morning steals the hush from our lips",
    "We plant our names beneath the old oak",
    "Your laughter is a lighthouse in fog",
    "The river remembers the stones we skipped",
    "We trade our shadows for a little sun",
    "A quiet street becomes a cathedral",
    "We stitch our stories into the hem of night",
    "Your breath writes poems on my collarbone",
    "The attic keeps the echoes of our youth",
    "We chase the scent of rain on hot pavement",
    "A single star can hold a thousand wishes",
    "We fold our fears into paper boats",
    "Your eyes are constellations I can read",
    "The night hums like a distant engine",
    "We keep our secrets in the seams of coats",
    "A stray dog knows the way back home",
    "We trade our maps for the thrill of dawn",
    "Your whisper is a tide that pulls me in",
    "The city wears a crown of flickering lights",
    "We plant small gardens in the cracks of time",
    "A broken clock still remembers noon",
    "We write our vows on the backs of receipts",
    "Your shadow keeps me company at dusk",
    "The moon borrows silver from the sea",
    "We fold our laughter into paper wings",
    "A single bell can wake a sleeping town",
    "We keep our promises like pressed flowers",
    "Your name tastes like rain on my tongue",
    "The rooftop holds a thousand quiet prayers",
    "We trade our worries for a slice of sky",
    "A stray breeze carries a forgotten song",
    "We stitch our mornings with a thread of gold",
    "Your heartbeat is a drum I follow home",
    "The alley keeps the footprints of old lovers",
    "We plant our dreams in the cracks of sidewalks",
    "A candle learns the shape of the dark",
    "We fold our goodbyes into the lining of coats",
    "Your laugh is a lighthouse on a foggy night",
    "The train keeps secrets between its rails",
    "We trade our names for a moment of grace",
    "A single cloud remembers how to wander",
    "We keep our stories in the pockets of jackets",
    "Your touch is a map of quiet revolutions",
    "The dawn writes its name across the rooftops",
    "We plant small suns in the jars of our hands",
    "A stray note becomes the chorus of the day",
    "We fold our sorrows into paper lanterns",
    "Your voice is a compass that never lies",
    "The river hums the tune of old goodbyes",
    "We trade our fears for a handful of stars",
    "A single step can change the course of rain",
    "We keep our promises like secret recipes",
    "Your smile is a ticket to a better place",
    "The night keeps the footprints of our dreams",
    "We plant our laughter in the soil of dawn",
    "A broken streetlight still remembers names",
    "We fold our wishes into the hems of coats",
    "Your whisper is a map of quiet revolutions",
    "The city hums like a pocket full of coins",
    "We trade our maps for the taste of salt air",
    "A single match can start a constellation",
    "We keep our memories in the seams of books",
    "Your eyes are windows to a softer weather",
    "The attic holds the ghosts of summer songs",
    "We plant our hopes on the edge of the pier",
    "A stray melody becomes the city's heartbeat",
    "We fold our mornings into the shape of you",
    "Your laugh is a lighthouse on a distant shore",
    "The moon writes postcards to the sleeping sea",
    "We trade our doubts for a handful of dawns",
    "A single bell can call the lost back home",
    "We keep our promises like old vinyl records",
    "Your touch is a map of all the places I've been",
    "The alleyway remembers the names we whispered",
    "We plant small gardens in the hollows of time",
    "A candle learns to speak in the language of dusk",
    "We fold our goodbyes into the pockets of coats",
    "Your voice is a harbor for my wandering songs",
    "The train hums lullabies to the empty stations",
    "We trade our maps for the thrill of the unknown",
    "A single cloud can carry the weight of a wish",
    "We keep our stories in the margins of notebooks",
    "Your smile is a compass that points to home",
    "The dawn stitches gold into the edges of sleep",
    "We plant our names on the underside of clouds",
    "A stray dog howls the chorus of the night",
    "We fold our sorrows into the folds of maps",
    "Your breath is a tide that reshapes my shore",
    "The city wears a necklace of blinking promises",
    "We trade our fears for the warmth of a bench",
    "A single star remembers the names we called",
    "We keep our secrets in the hollow of a tree",
    "Your eyes are constellations I trace with my thumb",
    "The rooftop keeps the footprints of small rebellions",
    "We plant our laughter like seeds in winter soil",
    "A broken clock still hums the tune of noon",
    "We fold our wishes into the corners of books",
    "Your whisper is a map that leads me through fog",
    "The river remembers the names we carved in stone",
    "We trade our maps for the taste of distant rain",
    "A single match can teach the dark to dance",
    "We keep our promises like pressed leaves in a book",
    "Your touch is a compass that points to quiet places",
    "The night hums like a radio tuned to memory",
    "We plant small suns in the jars of our pockets",
    "A stray melody finds its way into my coat",
    "We fold our mornings into the shape of a smile",
    "Your laugh is a lighthouse guiding me inland",
    "The moon borrows stories from the sleeping town",
    "We trade our doubts for a handful of warm light",
    "A single bell can stitch the edges of a wound",
    "We keep our memories like coins in a fountain",
    "Your voice is a harbor where my storms come to rest",
    "The alley keeps the echoes of our quiet vows",
    "We plant our hopes in the cracks of old sidewalks",
    "A candle learns the names of every small goodbye",
    "We fold our goodbyes into the hems of our coats",
    "Your shadow keeps the shape of every promise",
    "The train carries the scent of faraway kitchens",
    "We trade our maps for the taste of new mornings",
    "A single cloud can hold the weight of a song",
    "We keep our stories in the pockets of our coats",
    "Your eyes are the atlas of my softer weather",
    "The attic keeps the lullabies of our childhood",
    "We plant our names where the tide forgets to reach",
    "A stray note becomes the anthem of the street",
    "We fold our sorrows into paper boats and set them free",
    "Your breath writes constellations on the inside of my wrist",
    "The city hums like a pocket full of old radios",
    "We trade our fears for a bench beneath the elm",
    "A single match can teach the night to remember dawn",
    "We keep our promises like photographs in a drawer",
    "Your touch is a map of the small revolutions we make",
    "The moon writes letters to the rooftops in silver ink",
    "We plant small suns in the jars of our hands and watch them glow",
]

def make_verse(lines=2):
    return " — ".join(random.sample(LYRIC_LINES, k=lines))

def _which(cmd):
    return shutil.which(cmd) is not None

def speak_with_system_tts(text):
    system = platform.system()
    if system == "Darwin" and _which("say"):
        try:
            subprocess.run(["say", text], check=False)
            return True
        except Exception:
            return False
    if system == "Windows":
        escaped = text.replace("'", "''")
        ps_cmd = (
            "Add-Type -AssemblyName System.Speech;"
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            "$s.Rate = -2;"
            f"$s.Speak('{escaped}');"
        )
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return True
        except Exception:
            return False
    if _which("espeak"):
        try:
            subprocess.run(["espeak", text], check=False)
            return True
        except Exception:
            return False
    if _which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=False)
            return True
        except Exception:
            return False
    return False

def generate_and_speak(count=1, verse_lines=2, delay=0.25, start_index=1):
    for i in range(count):
        lyric = random.choice(LYRIC_LINES) if random.random() < 0.5 else make_verse(lines=verse_lines)
        print(f"\n[{start_index + i}/{start_index + count - 1}] 🎵  {lyric}\n")
        ok = speak_with_system_tts(lyric)
        if not ok:
            print("[No system TTS found] " + lyric)
        time.sleep(delay)

def interactive_menu(default_count=5, verse_lines=2, delay=0.25):
    current_default = default_count
    idx = 1
    try:
        while True:
            prompt = (
                "\nControls (type the key then Enter):\n"
                "  Enter  : generate one lyric now\n"
                "  r      : generate the current default count in a row (default = {})\n"
                "  g      : generate a specific count now (you will be prompted for the number)\n"
                "  s      : set the default count used by 'r' (you will be prompted)\n"
                "  l      : set lines per verse when composing a verse (1-6)\n"
                "  d      : set delay between items in seconds (e.g., 0.25)\n"
                "  h      : show this full help text again\n"
                "  q      : quit the program\n\n"
                "Choose (Enter/r/g/s/l/d/h/q): "
            ).format(current_default)
            choice = input(prompt).strip().lower()
            if choice == "q":
                print("Goodbye.")
                break
            if choice == "":
                generate_and_speak(count=1, verse_lines=verse_lines, delay=delay, start_index=idx)
                idx += 1
                continue
            if choice == "r":
                print(f"Generating {current_default} items (default count)...")
                generate_and_speak(count=current_default, verse_lines=verse_lines, delay=delay, start_index=idx)
                idx += current_default
                continue
            if choice == "g":
                try:
                    n = int(input("Enter count to generate now: ").strip())
                    if n <= 0:
                        print("Count must be positive.")
                        continue
                except ValueError:
                    print("Invalid number.")
                    continue
                generate_and_speak(count=n, verse_lines=verse_lines, delay=delay, start_index=idx)
                idx += n
                continue
            if choice == "s":
                try:
                    new_default = int(input("Set new default count: ").strip())
                    if new_default <= 0:
                        print("Default must be positive.")
                        continue
                    current_default = new_default
                    print(f"Default count set to {current_default}.")
                except ValueError:
                    print("Invalid number.")
                continue
            if choice == "l":
                try:
                    new_lines = int(input("Lines per verse (1-6): ").strip())
                    if not (1 <= new_lines <= 6):
                        print("Choose between 1 and 6.")
                        continue
                    verse_lines = new_lines
                    print(f"Lines per verse set to {verse_lines}.")
                except ValueError:
                    print("Invalid number.")
                continue
            if choice == "d":
                try:
                    new_delay = float(input("Delay between items in seconds (e.g., 0.25): ").strip())
                    if new_delay < 0:
                        print("Delay must be non-negative.")
                        continue
                    delay = new_delay
                    print(f"Delay set to {delay} seconds.")
                except ValueError:
                    print("Invalid number.")
                continue
            if choice == "h":
                # loop will reprint the full prompt (help) on next iteration
                continue
            print("Unknown option. Type 'h' to show the full controls.")
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting.")
        sys.exit(0)

def main():
    # If a one-shot count is passed as first arg, run non-interactive
    if len(sys.argv) > 1:
        try:
            if sys.argv[1] in ("-n", "--count") and len(sys.argv) > 2:
                n = int(sys.argv[2])
                generate_and_speak(count=n, verse_lines=2, delay=0.25, start_index=1)
                return
        except Exception:
            pass
    interactive_menu(default_count=5, verse_lines=2, delay=0.25)

if __name__ == "__main__":
    main()
