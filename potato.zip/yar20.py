# yars_topdown_yar_rotated_levels_sounds_local_fast_enemy_red_wall_patrol_lives.py
# Same game as before, with enemy patrolling between top and bottom of the wall,
# and a 3-lives system for the player (respawn with brief safety field).
# Save and run with standard Python (Tkinter included).

import tkinter as tk
import random
import time
import math
import platform
import sys
import threading

# ---------- Config (base values) ----------
WIDTH, HEIGHT = 1000, 640
FPS = 60

BASE_PLAYER_SPEED = 6
BASE_BULLET_SPEED = 14
BASE_CANNON_BASE_SPEED = 18
BASE_ENEMY_DIVE_SPEED = 6
BASE_ENEMY_PROJECTILE_SPEED = 9

# **Enemy speed boost**: multiply enemy dive and projectile speeds by this factor
ENEMY_SPEED_BOOST = 1.6  # 1.0 = no boost

# ---------- Patrol tuning (move between top and bottom of the wall) ----------
# How fast the enemy moves while patrolling (pixels per frame scaled by speed_mult)
PATROL_SPEED = 1.8

# How long the enemy pauses at each end (seconds)
PATROL_PAUSE = 0.45

SHIELD_ZONE_WIDTH = 140

# Wall made half as thick (fewer columns)
WALL_COLS = 7
WALL_ROWS = 10
BLOCK = 22
WALL_X = WIDTH - (WALL_COLS * BLOCK) - 40
WALL_Y = (HEIGHT - WALL_ROWS * BLOCK) // 2

# Cannon charge settings
CANNON_CHARGE_MAX = 100
CHARGE_PER_BLOCK = 8
CHARGE_PER_TOUCH = 4
WALL_THRESHOLD = 18

# Safety field settings
SAFETY_DURATION = 2.0
SAFETY_COOLDOWN = 6.0

# Level speed scaling
LEVEL_SPEED_MULTIPLIER = 1.12
LEVEL_DIVE_COOLDOWN_REDUCTION = 0.92

# ---------- Sound support (no external files) ----------
IS_WINDOWS = platform.system() == "Windows"
try:
    if IS_WINDOWS:
        import winsound
except Exception:
    IS_WINDOWS = False

# Run sounds on a background thread so the UI doesn't block.
def _threaded(fn):
    def wrapper(*a, **k):
        t = threading.Thread(target=fn, args=a, kwargs=k, daemon=True)
        t.start()
    return wrapper

@_threaded
def play_sound(name):
    mapping = {
        'player_bullet': [(1200, 50)],
        'player_cannon': [(600, 160), (1100, 80)],
        'enemy_fire': [(820, 90)],
        'cannon_hit_wall': [(380, 140)],
        'player_hit': [(300, 120), (220, 80)],
    }

    seq = mapping.get(name)
    if not seq:
        return

    if IS_WINDOWS and 'winsound' in sys.modules:
        try:
            for freq, dur in seq:
                winsound.Beep(int(freq), int(dur))
                time.sleep(0.02)
            return
        except Exception:
            pass

    root = globals().get('root')
    if not isinstance(root, tk.Tk):
        try:
            tmp = tk.Tk()
            tmp.withdraw()
            root = tmp
            created_tmp = True
        except Exception:
            root = None
            created_tmp = False
    else:
        created_tmp = False

    try:
        for freq, dur in seq:
            factor = max(1, int((freq / 400)))
            count = max(1, int((dur / 60) * (factor / 3)))
            spacing = max(0.03, 0.12 - (factor * 0.01))
            for _ in range(count):
                try:
                    if root:
                        root.bell()
                    else:
                        print('\a', end='', flush=True)
                except Exception:
                    print('\a', end='', flush=True)
                time.sleep(spacing)
            time.sleep(0.02)
    finally:
        if created_tmp:
            try:
                root.destroy()
            except Exception:
                pass

# ---------- Utility ----------
def clamp(val, lo, hi):
    return max(lo, min(hi, val))

# ---------- Game classes ----------
class Player:
    def __init__(self, game):
        self.g = game
        self.w, self.h = 36, 28
        self.x = SHIELD_ZONE_WIDTH + 48
        self.y = HEIGHT // 2
        self.charge_start = None
        self.cannon_ready = False
        self.alive = True
        self.safety_active = False
        self.safety_start = 0.0
        self.safety_last_used = -999.0

    def rect(self):
        return (self.x, self.y, self.x + self.w, self.y + self.h)

class Bullet:
    def __init__(self, x, y, vx, vy, owner='player', color='white', r=4):
        self.x = x; self.y = y; self.vx = vx; self.vy = vy
        self.owner = owner; self.color = color; self.r = r

class Wall:
    def __init__(self):
        self.blocks = [[True]*WALL_COLS for _ in range(WALL_ROWS)]

    def remaining(self):
        return sum(1 for r in range(WALL_ROWS) for c in range(WALL_COLS) if self.blocks[r][c])

class Enemy:
    def __init__(self):
        self.w, self.h = 44, 34
        self.x = WALL_X + WALL_COLS * BLOCK + 12
        self.y = HEIGHT // 2
        # base_y is the patrol baseline center; target_y toggles between top and bottom of wall
        self.base_y = self.y
        self.top_y = WALL_Y + self.h//2 + 4
        self.bottom_y = WALL_Y + WALL_ROWS*BLOCK - self.h//2 - 4
        self.target_y = self.top_y
        self.pause_until = 0.0
        self.state = 'idle'
        self.vx = 0; self.vy = 0
        self.return_x = self.x; self.return_y = self.base_y
        self.projectiles = []
        self.dive_cooldown = 110
        self.dive_timer = 0
        self.alive = True
        self.barrel_angle = 180

# ---------- Game ----------
class Game:
    def __init__(self, root):
        globals()['root'] = root
        self.root = root
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg='black')
        self.canvas.pack()
        self.reset()
        self.bind_keys()
        self.last_time = time.time()
        self.running = True
        self.loop()

    def reset(self):
        self.player = Player(self)
        self.bullets = []
        self.cannon_bullets = []
        self.wall = Wall()
        self.enemy = Enemy()
        self.score = 0
        self.cannon_spawned = False
        self.game_over = False
        self.win = False
        self.keys = set()
        self.cannon_charge = 0
        self.cannon_used_since_full = False

        # Lives system: start with 3 lives
        self.lives = 3
        # respawn handling
        self.respawn_time = 0.0
        self.respawn_delay = 1.2
        self.player_hit_recent = False

        # Leveling
        self.level = 1
        self.speed_mult = 1.0
        self.enemy.dive_cooldown = 110

        # Level completion state
        self.level_complete = False
        self.level_complete_time = 0.0
        self.level_transition_delay = 1.4

        # initialize enemy patrol targets and clamp them
        e = self.enemy
        e.top_y = clamp(WALL_Y + e.h//2 + 4, e.h//2 + 4, HEIGHT - e.h//2 - 4)
        e.bottom_y = clamp(WALL_Y + WALL_ROWS*BLOCK - e.h//2 - 4, e.h//2 + 4, HEIGHT - e.h//2 - 4)
        e.base_y = clamp(HEIGHT // 2, e.h//2 + 4, HEIGHT - e.h//2 - 4)
        e.y = e.base_y
        e.target_y = e.top_y
        e.pause_until = 0.0
        e.return_y = e.base_y

    def bind_keys(self):
        self.root.bind("<KeyPress>", self.on_key)
        self.root.bind("<KeyRelease>", self.on_key_release)
        self.root.protocol("WM_DELETE_WINDOW", self.quit)

    # ---------- Input ----------
    def on_key(self, event):
        k = event.keysym.lower()
        self.keys.add(k)
        if k == 'z' and self.player.alive and not self.game_over and not self.level_complete:
            self.fire_bullet()
        if k == 'r' and self.game_over:
            self.reset()
        if k == 'space' and self.player.cannon_ready and self.player.charge_start is None and not self.level_complete:
            self.player.charge_start = time.time()
        if k == 's' and self.player.alive and not self.game_over:
            self.try_activate_safety()
        if k == 'escape':
            self.quit()

    def on_key_release(self, event):
        k = event.keysym.lower()
        if k in self.keys:
            self.keys.remove(k)
        if k == 'space' and self.player.cannon_ready and not self.game_over and not self.level_complete:
            if self.player.charge_start is not None:
                charge = min(1.0, (time.time() - self.player.charge_start) / 1.2)
                self.fire_cannon(charge)
                self.player.charge_start = None
                self.cannon_charge = 0
                self.player.cannon_ready = False
                self.cannon_spawned = False
                self.cannon_used_since_full = True

    def try_activate_safety(self):
        now = time.time()
        p = self.player
        if p.safety_active:
            return
        if now - p.safety_last_used >= SAFETY_COOLDOWN:
            p.safety_active = True
            p.safety_start = now
            p.safety_last_used = now

    # ---------- Effective speeds (apply multiplier + enemy boost) ----------
    def player_speed(self):
        return BASE_PLAYER_SPEED * self.speed_mult

    def bullet_speed(self):
        return BASE_BULLET_SPEED * self.speed_mult

    def cannon_speed(self, charge):
        return (BASE_CANNON_BASE_SPEED + int(charge * 10)) * self.speed_mult

    def enemy_dive_speed(self):
        return BASE_ENEMY_DIVE_SPEED * self.speed_mult * ENEMY_SPEED_BOOST

    def enemy_projectile_speed(self):
        return BASE_ENEMY_PROJECTILE_SPEED * self.speed_mult * ENEMY_SPEED_BOOST

    # ---------- Firing ----------
    def fire_bullet(self):
        p = self.player
        bx = p.x + p.w + 8
        by = p.y + p.h//2
        vx = self.bullet_speed()
        self.bullets.append(Bullet(bx, by, vx, 0))
        play_sound('player_bullet')

    def fire_cannon(self, charge):
        y = self.player.y + self.player.h//2
        x = 8
        speed = self.cannon_speed(charge)
        self.cannon_bullets.append(Bullet(x, y, speed, 0, owner='player', color='cyan', r=7))
        play_sound('player_cannon')

    def spawn_cannon_if_needed(self):
        if not self.cannon_spawned:
            if self.wall.remaining() <= WALL_THRESHOLD:
                self.cannon_spawned = True
                self.player.cannon_ready = True
            elif self.cannon_charge >= CANNON_CHARGE_MAX:
                self.cannon_spawned = True
                self.player.cannon_ready = True
                self.cannon_used_since_full = False

    def on_enemy_destroyed(self):
        self.score += 500
        self.level_complete = True
        self.level_complete_time = time.time()
        self.speed_mult *= LEVEL_SPEED_MULTIPLIER
        self.enemy.dive_cooldown = max(20, int(self.enemy.dive_cooldown * LEVEL_DIVE_COOLDOWN_REDUCTION))
        self.cannon_charge = 0
        self.player.cannon_ready = False
        self.cannon_spawned = False
        self.cannon_used_since_full = True

    def start_next_level(self):
        self.level += 1
        self.wall = Wall()
        self.enemy = Enemy()
        self.enemy.dive_cooldown = max(20, int(110 * (LEVEL_DIVE_COOLDOWN_REDUCTION ** (self.level - 1))))
        self.enemy.x = WALL_X + WALL_COLS * BLOCK + 12
        # recalc patrol bounds and baseline
        self.enemy.top_y = clamp(WALL_Y + self.enemy.h//2 + 4, self.enemy.h//2 + 4, HEIGHT - self.enemy.h//2 - 4)
        self.enemy.bottom_y = clamp(WALL_Y + WALL_ROWS*BLOCK - self.enemy.h//2 - 4, self.enemy.h//2 + 4, HEIGHT - self.enemy.h//2 - 4)
        self.enemy.base_y = clamp(HEIGHT // 2 + random.randint(-40, 40), self.enemy.h//2 + 4, HEIGHT - self.enemy.h//2 - 4)
        self.enemy.y = self.enemy.base_y
        self.enemy.return_x = self.enemy.x
        self.enemy.return_y = self.enemy.base_y
        self.enemy.target_y = self.enemy.top_y
        self.enemy.pause_until = 0.0
        self.bullets = []
        self.cannon_bullets = []
        self.level_complete = False

    # ---------- Player life / respawn ----------
    def player_die(self):
        """Handle player being hit: decrement lives, play sound, set respawn or game over."""
        if self.player_hit_recent:
            return
        self.player_hit_recent = True
        self.lives -= 1
        play_sound('player_hit')
        if self.lives > 0:
            # schedule respawn
            self.respawn_time = time.time() + self.respawn_delay
            self.player.alive = False
            # clear some projectiles to give breathing room
            self.bullets.clear()
            self.enemy.projectiles.clear()
        else:
            # no lives left -> game over
            self.player.alive = False
            self.game_over = True
            self.win = False

    def respawn_player(self):
        """Bring player back with brief safety field and reset position."""
        p = self.player
        p.alive = True
        p.x = SHIELD_ZONE_WIDTH + 48
        p.y = HEIGHT // 2
        p.safety_active = True
        p.safety_start = time.time()
        p.safety_last_used = time.time()
        # reset hit flag so future hits count
        self.player_hit_recent = False

    # ---------- Update loop ----------
    def update(self):
        if self.game_over:
            return

        now = time.time()
        p = self.player

        # handle respawn timing
        if not p.alive and not self.game_over and self.lives > 0 and now >= self.respawn_time:
            self.respawn_player()

        # handle level transition timing
        if self.level_complete:
            if now - self.level_complete_time >= self.level_transition_delay:
                self.start_next_level()
            return

        # safety field timeout
        if p.safety_active and (now - p.safety_start >= SAFETY_DURATION):
            p.safety_active = False

        # player movement
        if p.alive:
            spd = self.player_speed()
            if 'left' in self.keys:
                p.x -= spd
            if 'right' in self.keys:
                p.x += spd
            if 'up' in self.keys:
                p.y -= spd
            if 'down' in self.keys:
                p.y += spd
            p.x = max(SHIELD_ZONE_WIDTH + 2, min(WIDTH - p.w - 2, p.x))
            p.y = max(2, min(HEIGHT - p.h - 2, p.y))

        # bullets
        for b in list(self.bullets):
            b.x += b.vx; b.y += b.vy
            if b.x < 0 or b.x > WIDTH or b.y < 0 or b.y > HEIGHT:
                try: self.bullets.remove(b)
                except: pass

        # cannon bullets update and collision with wall
        for cb in list(self.cannon_bullets):
            cb.x += cb.vx
            if self.cannon_hits_wall(cb):
                try: self.cannon_bullets.remove(cb)
                except: pass
                play_sound('cannon_hit_wall')
                continue
            if cb.x > WIDTH:
                try: self.cannon_bullets.remove(cb)
                except: pass

        # enemy update
        e = self.enemy
        if e.alive:
            e.barrel_angle = 180 + math.sin(time.time()*1.2)*8

            # ---------- PATROL: move smoothly between top_y and bottom_y ----------
            if e.state == 'idle':
                # if currently pausing at an end, wait until pause ends
                if now < e.pause_until:
                    pass
                else:
                    # move toward target_y at PATROL_SPEED (scaled by speed_mult)
                    speed = PATROL_SPEED * self.speed_mult
                    dy = e.target_y - e.y
                    if abs(dy) <= speed:
                        # reached target: snap, pause, then flip target
                        e.y = e.target_y
                        e.pause_until = now + PATROL_PAUSE
                        # flip target for next patrol
                        e.target_y = e.bottom_y if e.target_y == e.top_y else e.top_y
                    else:
                        e.y += speed if dy > 0 else -speed

                e.dive_timer += 1
                if e.dive_timer >= e.dive_cooldown:
                    if self.wall_has_gap_for_dive():
                        self.start_enemy_dive()
                    else:
                        e.dive_timer = e.dive_cooldown - 20

            elif e.state == 'diving':
                speed = self.enemy_dive_speed()
                e.x += e.vx * (speed / BASE_ENEMY_DIVE_SPEED)
                e.y += e.vy * (speed / BASE_ENEMY_DIVE_SPEED)
                # clamp while diving so the enemy cannot go off-screen vertically
                e.y = clamp(e.y, e.h//2 + 4, HEIGHT - e.h//2 - 4)
                if e.x < WALL_X - 40 or e.y < -50 or e.y > HEIGHT + 50:
                    self.enemy_fire_projectile()
                    self.start_enemy_return()

            elif e.state == 'returning':
                dx = e.return_x - e.x; dy = e.return_y - e.y
                dist = math.hypot(dx, dy)
                if dist < 4:
                    e.state = 'idle'; e.dive_timer = 0
                    # ensure patrol baseline and targets are clamped and consistent
                    e.base_y = clamp(e.return_y, e.h//2 + 4, HEIGHT - e.h//2 - 4)
                    e.top_y = clamp(WALL_Y + e.h//2 + 4, e.h//2 + 4, HEIGHT - e.h//2 - 4)
                    e.bottom_y = clamp(WALL_Y + WALL_ROWS*BLOCK - e.h//2 - 4, e.h//2 + 4, HEIGHT - e.h//2 - 4)
                    # choose nearest target to resume patrol smoothly
                    if abs(e.y - e.top_y) < abs(e.y - e.bottom_y):
                        e.target_y = e.bottom_y
                    else:
                        e.target_y = e.top_y
                    e.pause_until = time.time() + PATROL_PAUSE
                else:
                    e.x += dx / dist * 3; e.y += dy / dist * 3
                    e.y = clamp(e.y, e.h//2 + 4, HEIGHT - e.h//2 - 4)

            for pproj in list(e.projectiles):
                pproj.x += pproj.vx; pproj.y += pproj.vy
                if pproj.x < 0 or pproj.x > WIDTH or pproj.y < 0 or pproj.y > HEIGHT:
                    try: e.projectiles.remove(pproj)
                    except: pass

        # collisions: bullets vs wall and enemy
        for b in list(self.bullets):
            if self.hit_wall(b):
                try: self.bullets.remove(b)
                except: pass
                self.score += 5
                self.add_cannon_charge(CHARGE_PER_BLOCK)
                continue
            if self.enemy.alive and self.rects_collide((b.x-b.r, b.y-b.r, b.x+b.r, b.y+b.r),
                                                      (self.enemy.x, self.enemy.y, self.enemy.x+self.enemy.w, self.enemy.y+self.enemy.h)):
                try: self.bullets.remove(b)
                except: pass
                self.score += 20

        # cannon vs enemy
        for cb in list(self.cannon_bullets):
            if self.enemy.alive and self.rects_collide((cb.x-cb.r, cb.y-cb.r, cb.x+cb.r, cb.y+cb.r),
                                                      (self.enemy.x, self.enemy.y, self.enemy.x+self.enemy.w, self.enemy.y+self.enemy.h)):
                try: self.cannon_bullets.remove(cb)
                except: pass
                # trigger level completion instead of ending the game
                self.on_enemy_destroyed()
                self.enemy.alive = False

        # enemy projectiles vs player (respect safety field)
        for pproj in list(self.enemy.projectiles):
            if self.rects_collide((pproj.x-pproj.r, pproj.y-pproj.r, pproj.x+pproj.r, pproj.y+pproj.r), self.player.rect()):
                if not self.player.safety_active and self.player.alive:
                    self.player_die()
                else:
                    try: self.enemy.projectiles.remove(pproj)
                    except: pass

        # enemy collides with player (respect safety)
        if self.enemy.alive and self.rects_collide(self.player.rect(),
                                                  (self.enemy.x, self.enemy.y, self.enemy.x+self.enemy.w, self.enemy.y+self.enemy.h)):
            if not self.player.safety_active and self.player.alive:
                self.player_die()

        # player touching wall eats blocks and charges cannon a bit
        if self.hit_wall_rect(self.player.rect(), charge_on_hit=True):
            self.score += 2
            self.add_cannon_charge(CHARGE_PER_TOUCH)

        # enemy projectiles break wall
        for pproj in list(self.enemy.projectiles):
            if self.hit_wall_rect((pproj.x-pproj.r, pproj.y-pproj.r, pproj.x+pproj.r, pproj.y+pproj.r)):
                try: self.enemy.projectiles.remove(pproj)
                except: pass

        # spawn cannon if needed
        self.spawn_cannon_if_needed()

        # occasional enemy projectile
        if self.enemy.state == 'idle' and random.random() < 0.0025:
            self.enemy_fire_projectile()

        self.score += 0.01

    def add_cannon_charge(self, amount):
        if self.cannon_charge >= CANNON_CHARGE_MAX and not self.cannon_used_since_full:
            return
        self.cannon_charge = min(CANNON_CHARGE_MAX, self.cannon_charge + amount)
        if self.cannon_charge >= CANNON_CHARGE_MAX:
            self.player.cannon_ready = True
            self.cannon_spawned = True
            self.cannon_used_since_full = False

    # ---------- Enemy behaviors ----------
    def start_enemy_dive(self):
        e = self.enemy
        e.state = 'diving'
        angle = random.uniform(-0.9, 0.9)
        base_vx = -1.0
        base_vy = math.tan(angle)
        e.vx = base_vx
        e.vy = base_vy
        e.dive_timer = 0

    def start_enemy_return(self):
        e = self.enemy
        e.state = 'returning'
        e.return_x = WALL_X + WALL_COLS * BLOCK + 12
        e.return_y = clamp(HEIGHT // 2, e.h//2 + 4, HEIGHT - e.h//2 - 4)

    def enemy_fire_projectile(self):
        e = self.enemy
        px = e.x - 6
        py = e.y + e.h//2
        speed = self.enemy_projectile_speed()
        vx = -speed - random.random()*2*self.speed_mult
        vy = random.uniform(-1.5, 1.5) * self.speed_mult
        e.projectiles.append(Bullet(px, py, vx, vy, owner='enemy', color='red', r=6))
        play_sound('enemy_fire')

    # ---------- Wall collision helpers ----------
    def hit_wall(self, bullet):
        rect = (bullet.x - bullet.r, bullet.y - bullet.r, bullet.x + bullet.r, bullet.y + bullet.r)
        return self.hit_wall_rect(rect, charge_on_hit=True)

    def cannon_hits_wall(self, cannon_bullet):
        rect = (cannon_bullet.x - cannon_bullet.r, cannon_bullet.y - cannon_bullet.r,
                cannon_bullet.x + cannon_bullet.r, cannon_bullet.y + cannon_bullet.r)
        rx1, ry1, rx2, ry2 = rect
        for r in range(WALL_ROWS):
            for c in range(WALL_COLS):
                if self.wall.blocks[r][c]:
                    bx = WALL_X + c*BLOCK; by = WALL_Y + r*BLOCK
                    bx2 = bx + BLOCK; by2 = by + BLOCK
                    if not (rx2 < bx or rx1 > bx2 or ry2 < by or ry1 > by2):
                        self.wall.blocks[r][c] = False
                        self.score += 50
                        return True
        return False

    def hit_wall_rect(self, rect, charge_on_hit=False):
        rx1, ry1, rx2, ry2 = rect
        for r in range(WALL_ROWS):
            for c in range(WALL_COLS):
                if self.wall.blocks[r][c]:
                    bx = WALL_X + c*BLOCK; by = WALL_Y + r*BLOCK
                    bx2 = bx + BLOCK; by2 = by + BLOCK
                    if not (rx2 < bx or rx1 > bx2 or ry2 < by or ry1 > by2):
                        self.wall.blocks[r][c] = False
                        if charge_on_hit:
                            self.add_cannon_charge(CHARGE_PER_BLOCK)
                        return True
        return False

    def rects_collide(self, a, b):
        ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
        return not (ax2 < bx1 or ax1 > bx2 or ay2 < by1 or ay1 > by2)

    def wall_has_gap_for_dive(self):
        mid_rows = range(max(0, WALL_ROWS//3), min(WALL_ROWS, WALL_ROWS - WALL_ROWS//3))
        for c in range(WALL_COLS):
            for r in mid_rows:
                if not self.wall.blocks[r][c]:
                    return True
        return False

    # ---------- Drawing (rotated top-down Yar) ----------
    def draw_yar_player(self, x, y, w, h):
        cx = x + w // 2
        cy = y + h // 2

        shell_main = '#66cc66'
        shell_dark = '#2f8f2f'
        head_color = '#4bd24b'
        eye_color = '#ffffff'
        pupil_color = '#000000'
        leg_color = '#2b7f2b'
        antenna_color = '#dfefff'
        accent = '#9fe6a6'

        body_w = int(w * 0.9)
        body_h = int(h * 0.85)
        head_w = int(body_w * 0.45)
        head_h = int(body_h * 0.45)

        self.canvas.create_oval(cx - body_w//2, cy - body_h//2,
                                cx + body_w//2, cy + body_h//2,
                                fill=shell_main, outline=shell_dark, width=2)

        seg_count = 3
        for i in range(seg_count):
            t = (i - (seg_count-1)/2) / ((seg_count-1)/2 if seg_count>1 else 1)
            seg_cx = cx + int(t * (body_w * 0.18))
            seg_h_w = int(body_w * 0.36)
            seg_h_h = int(body_h * (0.92 - abs(t) * 0.12))
            self.canvas.create_oval(seg_cx - seg_h_w//2, cy - seg_h_h//2,
                                    seg_cx + seg_h_w//2, cy + seg_h_h//2,
                                    fill=accent if i==1 else shell_main, outline=shell_dark, width=1)

        stripe_h = max(2, int(body_h * 0.12))
        self.canvas.create_rectangle(cx - body_w//2 + 4, cy - stripe_h//2,
                                     cx + body_w//2 - 4, cy + stripe_h//2,
                                     fill=shell_dark, outline='')

        head_cx = cx + int(body_w * 0.38)
        head_cy = cy - int(body_h * 0.0)
        self.canvas.create_oval(head_cx - head_w//2, head_cy - head_h//2,
                                head_cx + head_w//2, head_cy + head_h//2,
                                fill=head_color, outline=shell_dark, width=1)

        eye_r = max(2, head_w // 8)
        eye_x = head_cx + int(head_w * 0.18)
        eye_y = head_cy - int(head_h * 0.12)
        self.canvas.create_oval(eye_x - eye_r, eye_y - eye_r, eye_x + eye_r, eye_y + eye_r, fill=eye_color, outline='')
        self.canvas.create_oval(eye_x - eye_r//2, eye_y - eye_r//2, eye_x + eye_r//2, eye_y + eye_r//2, fill=pupil_color, outline='')

        ant_len = int(head_w * 1.6)
        self.canvas.create_line(head_cx + head_w//4, head_cy - head_h//4,
                                head_cx + head_w//4 + ant_len*0.6, head_cy - head_h//4 - ant_len*0.4,
                                fill=antenna_color, width=2, smooth=True)
        self.canvas.create_line(head_cx + head_w//4, head_cy + head_h//4,
                                head_cx + head_w//4 + ant_len*0.6, head_cy + head_h//4 + ant_len*0.4,
                                fill=antenna_color, width=2, smooth=True)

        leg_count = 3
        leg_spacing = body_w * 0.22
        for side in (-1, 1):
            for i in range(leg_count):
                frac = (i - (leg_count-1)/2)
                leg_x = cx + int(frac * leg_spacing)
                start_x = leg_x
                start_y = cy + side * int(body_h * 0.45)
                mid_x = start_x + int((i - 1) * (body_w * 0.06))
                mid_y = start_y + side * int(body_h * 0.25)
                foot_x = start_x + int((0.6 + abs(frac)*0.15) * (body_w * 0.25))
                foot_y = start_y + side * int(body_h * 0.55)
                self.canvas.create_line(start_x, start_y, mid_x, mid_y, fill=leg_color, width=3, capstyle='round')
                self.canvas.create_line(mid_x, mid_y, foot_x, foot_y, fill=leg_color, width=3, capstyle='round')
                claw_len = 6
                self.canvas.create_line(foot_x, foot_y, foot_x + 4, foot_y + side * claw_len, fill=leg_color, width=2)

        highlight_w = int(body_w * 0.18)
        highlight_h = int(body_h * 0.08)
        self.canvas.create_oval(cx - highlight_w//2, cy - int(body_h*0.12) - highlight_h//2,
                                cx + highlight_w//2, cy - int(body_h*0.12) + highlight_h//2,
                                fill=accent, outline='')

        shadow_w = int(body_w * 1.05)
        shadow_h = int(body_h * 0.35)
        try:
            self.canvas.create_oval(cx - shadow_w//2, cy + body_h//2 - 6,
                                    cx + shadow_w//2, cy + body_h//2 + shadow_h - 6,
                                    fill='#000000', outline='', stipple='gray25')
        except Exception:
            self.canvas.create_oval(cx - shadow_w//2, cy + body_h//2 - 6,
                                    cx + shadow_w//2, cy + body_h//2 + shadow_h - 6,
                                    fill='#111111', outline='')

    def draw_gun_enemy(self, e):
        bx = e.x; by = e.y; bw = e.w; bh = e.h
        base_x1 = bx - 6; base_y1 = by + bh - 6
        base_x2 = bx + bw + 6; base_y2 = by + bh + 8
        self.canvas.create_rectangle(base_x1, base_y1, base_x2, base_y2, fill='#333', outline='black')
        self.canvas.create_oval(bx, by, bx + bw, by + bh, fill='#ff9a3c', outline='black')
        angle = math.radians(e.barrel_angle)
        barrel_length = bw + 18
        barrel_w = 8
        cx = bx + 6
        cy = by + bh//2
        x2 = cx + math.cos(angle) * barrel_length
        y2 = cy + math.sin(angle) * barrel_length
        self.canvas.create_line(cx, cy, x2, y2, fill='#222', width=barrel_w, capstyle='round')
        muzzle_x = cx + math.cos(angle) * (barrel_length + 6)
        muzzle_y = cy + math.sin(angle) * (barrel_length + 6)
        self.canvas.create_oval(muzzle_x-6, muzzle_y-6, muzzle_x+6, muzzle_y+6, fill='#111', outline='yellow')
        self.canvas.create_rectangle(bx + bw//2 - 6, by + 6, bx + bw//2 + 6, by + 12, fill='#222')

    # ---------- Drawing ----------
    def draw(self):
        self.canvas.delete("all")
        self.canvas.create_rectangle(0,0,SHIELD_ZONE_WIDTH,HEIGHT, fill='#1e1e3c', outline='')
        self.canvas.create_text(12, 12, anchor='nw', text="ZORLON CHARGE", fill='white', font=('TkDefaultFont', 10, 'bold'))
        bar_x = 12; bar_y = 36; bar_w = SHIELD_ZONE_WIDTH - 24; bar_h = 18
        self.canvas.create_rectangle(bar_x, bar_y, bar_x+bar_w, bar_y+bar_h, fill='#333', outline='white')
        fill_w = int((self.cannon_charge / CANNON_CHARGE_MAX) * bar_w)
        fill_color = 'cyan' if self.cannon_charge >= CANNON_CHARGE_MAX else 'yellow'
        self.canvas.create_rectangle(bar_x, bar_y, bar_x+fill_w, bar_y+bar_h, fill=fill_color, outline='')
        self.canvas.create_text(bar_x, bar_y+bar_h+6, anchor='nw', text=f"{int(self.cannon_charge)}/{CANNON_CHARGE_MAX}", fill='white', font=('TkDefaultFont', 10))

        if self.enemy.alive:
            self.draw_gun_enemy(self.enemy)
            for p in self.enemy.projectiles:
                self.canvas.create_oval(p.x-p.r, p.y-p.r, p.x+p.r, p.y+p.r, fill=p.color)

        # wall (right side) - red
        for r in range(WALL_ROWS):
            for c in range(WALL_COLS):
                if self.wall.blocks[r][c]:
                    bx = WALL_X + c*BLOCK; by = WALL_Y + r*BLOCK
                    self.canvas.create_rectangle(bx, by, bx+BLOCK-2, by+BLOCK-2, fill='#cc2222', outline='black')

        for b in self.bullets:
            self.canvas.create_oval(b.x-b.r, b.y-b.r, b.x+b.r, b.y+b.r, fill=b.color)
        for cb in self.cannon_bullets:
            self.canvas.create_oval(cb.x-cb.r, cb.y-cb.r, cb.x+cb.r, cb.y+cb.r, fill=cb.color)

        if self.player.alive:
            x1,y1,x2,y2 = self.player.rect()
            self.draw_yar_player(x1, y1, self.player.w, self.player.h)
            if self.player.safety_active:
                cx = x1 + self.player.w//2
                cy = y1 + self.player.h//2
                radius = max(self.player.w, self.player.h) * 3
                self.canvas.create_oval(cx-radius, cy-radius, cx+radius, cy+radius, outline='cyan', width=3)

        if self.player.cannon_ready:
            self.canvas.create_rectangle(6, HEIGHT//2 - 26, 22, HEIGHT//2 + 26, fill='cyan')
            if self.player.charge_start:
                charge = min(1.0, (time.time() - self.player.charge_start) / 1.2)
                self.canvas.create_rectangle(28, HEIGHT//2 - 12, 28 + int(140*charge), HEIGHT//2 + 12, fill='yellow')

        now = time.time()
        cooldown_left = max(0.0, SAFETY_COOLDOWN - (now - self.player.safety_last_used))
        cd_text = f"Safety CD: {cooldown_left:.1f}s" if cooldown_left > 0 else "Safety Ready (S)"
        self.canvas.create_text(12, HEIGHT - 36, anchor='nw', text=cd_text, fill='white', font=('TkDefaultFont', 10))

        # HUD: Score, Wall, Level, Lives
        self.canvas.create_text(SHIELD_ZONE_WIDTH+12, 12, anchor='nw',
                                text=f"Score: {int(self.score)}  Wall: {self.wall.remaining()}  Level: {self.level}  Lives: {self.lives}",
                                fill='white', font=('TkDefaultFont', 12))
        self.canvas.create_text(SHIELD_ZONE_WIDTH+12, HEIGHT-28, anchor='nw', text="Move: Arrows   Fire: Z   Cannon: Hold Space   Safety: S   Restart: R", fill='white', font=('TkDefaultFont', 10))

        if self.level_complete:
            msg = f"LEVEL {self.level} COMPLETE"
            self.canvas.create_text(WIDTH//2, HEIGHT//2 - 20, text=msg, fill='yellow', font=('TkDefaultFont', 28, 'bold'))
            sub = "Preparing next level..."
            self.canvas.create_text(WIDTH//2, HEIGHT//2 + 12, text=sub, fill='white', font=('TkDefaultFont', 14))

        if self.game_over:
            msg = "YOU LOSE! Press R to restart"
            self.canvas.create_text(WIDTH//2, HEIGHT//2 - 20, text=msg, fill='red', font=('TkDefaultFont', 20))

    # ---------- Main loop ----------
    def loop(self):
        if not self.running:
            return
        now = time.time()
        elapsed = now - self.last_time
        if elapsed >= 1.0 / FPS:
            self.update()
            self.draw()
            self.last_time = now
        self.root.after(6, self.loop)

    def quit(self):
        self.running = False
        try:
            self.root.destroy()
        except Exception:
            pass

# ---------- Run ----------
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Yars Inspired — Enemy Patrol + 3 Lives")
    game = Game(root)
    root.mainloop()
