#!/usr/bin/env python3
"""
Random Pizza Topping Generator that remembers the last inputs as defaults.

Features:
- Interactive loop that remembers the last choices (weird, category, tts, seed/seed-word).
- CLI single-run mode still supported.
- Seed words supported (hashed to a 32-bit integer).
- Cross-platform TTS using only system tools (no pip).
- Type 'q' or 'quit' at the main prompt to exit.
"""

import sys
import random
import argparse
import subprocess
import shutil
import hashlib

TOPPINGS = [
    # meats
    "pepperoni", "Italian sausage", "breakfast sausage", "bacon", "pancetta",
    "prosciutto", "ham", "smoked ham", "Canadian bacon", "salami",
    "soppressata", "chorizo", "meatballs", "rotisserie chicken", "grilled chicken",
    "pulled pork", "BBQ pulled beef", "pastrami", "corned beef", "turkey",
    "nduja", "lamb", "duck confit", "venison", "bresaola", "speck", "mortadella",

    # cheeses
    "mozzarella", "whole-milk mozzarella", "fresh mozzarella", "smoked mozzarella",
    "provolone", "fontina", "parmesan", "pecorino romano", "asiago",
    "gorgonzola", "blue cheese", "goat cheese", "ricotta", "feta",
    "halloumi", "burrata", "manchego", "cheddar", "colby jack", "brie",
    "camembert", "gruyere", "emmental",

    # vegetables
    "red onion", "white onion", "caramelized onion", "green bell pepper",
    "red bell pepper", "roasted red pepper", "poblano pepper", "banana pepper",
    "jalapeño", "serrano pepper", "cherry tomato", "sun-dried tomato",
    "grape tomato", "mushroom", "cremini mushroom", "shiitake mushroom",
    "oyster mushroom", "portobello mushroom", "spinach", "arugula",
    "kale", "broccoli", "zucchini", "eggplant", "artichoke hearts",
    "roasted garlic", "corn", "scallions", "leeks", "fennel", "bok choy",
    "snap peas", "watercress", "radicchio", "beet slices", "carrot ribbons",

    # pickled and tangy
    "dill pickles", "bread-and-butter pickles", "pickled red onion",
    "pickled jalapeño", "giardiniera", "kimchi", "sauerkraut", "capers",
    "black olives", "green olives", "Castelvetrano olives", "pepperoncini",

    # seafood
    "anchovies", "shrimp", "smoked salmon", "crab meat", "lobster chunks",
    "tuna", "clams", "mussels", "scallops",

    # sauces and bases
    "classic tomato sauce", "San Marzano tomato puree", "garlic-olive oil base",
    "pesto", "white béchamel", "Alfredo sauce", "BBQ sauce", "buffalo sauce",
    "chimichurri drizzle", "harissa paste", "gochujang glaze", "miso glaze",
    "hoisin drizzle", "teriyaki glaze", "ranch drizzle",

    # fruits and sweet-ish
    "pineapple", "pear slices", "apple slices", "fresh figs", "dried figs",
    "dates", "raisins", "grapes", "banana", "mango", "peach slices",
    "cranberry compote", "apple chutney", "pickled mango (achar)",

    # crunch and texture
    "crushed potato chips", "crushed tortilla chips", "pretzel pieces",
    "toasted breadcrumbs", "candied walnuts", "toasted pine nuts",
    "sliced almonds", "sesame seeds", "fried shallots", "crispy onions",
    "panko crunch", "roasted chickpeas",

    # herbs and finishes
    "fresh basil", "dried oregano", "fresh oregano", "thyme", "rosemary",
    "parsley", "chives", "crushed red pepper flakes", "black pepper",
    "flaky sea salt", "truffle oil", "chili oil", "balsamic glaze",
    "honey", "lemon zest", "za'atar", "sumac",

    # international and funky
    "labneh dollops", "tandoori chicken", "paneer cubes", "curry-spiced potatoes",
    "chaat masala sprinkle", "harissa-roasted veggies", "gochujang drizzle",
    "souvlaki lamb", "shawarma spices", "shawarma chicken", "falafel crumbles",

    # dessert and wildcards
    "mini marshmallows", "chocolate chips", "Nutella swirl", "peanut butter dollops",
    "gummy bears", "fruity cereal", "ice cream scoop (post-bake)", "caramel sauce",
    "dulce de leche", "toasted coconut", "candied bacon", "maple syrup drizzle"
]

CATEGORIES = {
    "meats": {"pepperoni","Italian sausage","breakfast sausage","bacon","pancetta","prosciutto",
              "ham","smoked ham","Canadian bacon","salami","soppressata","chorizo","meatballs",
              "rotisserie chicken","grilled chicken","pulled pork","BBQ pulled beef","pastrami",
              "corned beef","turkey","nduja","lamb","duck confit","venison","bresaola","speck","mortadella"},
    "cheeses": {"mozzarella","whole-milk mozzarella","fresh mozzarella","smoked mozzarella","provolone",
                "fontina","parmesan","pecorino romano","asiago","gorgonzola","blue cheese","goat cheese",
                "ricotta","feta","halloumi","burrata","manchego","cheddar","colby jack","brie","camembert",
                "gruyere","emmental"},
    "vegetables": {"red onion","white onion","caramelized onion","green bell pepper","red bell pepper",
                   "roasted red pepper","poblano pepper","banana pepper","jalapeño","serrano pepper",
                   "cherry tomato","sun-dried tomato","grape tomato","mushroom","cremini mushroom",
                   "shiitake mushroom","oyster mushroom","portobello mushroom","spinach","arugula","kale",
                   "broccoli","zucchini","eggplant","artichoke hearts","roasted garlic","corn","scallions",
                   "leeks","fennel","bok choy","snap peas","watercress","radicchio","beet slices","carrot ribbons"},
    "pickled": {"dill pickles","bread-and-butter pickles","pickled red onion","pickled jalapeño",
                "giardiniera","kimchi","sauerkraut","capers","black olives","green olives",
                "Castelvetrano olives","pepperoncini"},
    "seafood": {"anchovies","shrimp","smoked salmon","crab meat","lobster chunks","tuna","clams","mussels","scallops"},
    "sauces": {"classic tomato sauce","San Marzano tomato puree","garlic-olive oil base","pesto","white béchamel",
               "Alfredo sauce","BBQ sauce","buffalo sauce","chimichurri drizzle","harissa paste","gochujang glaze",
               "miso glaze","hoisin drizzle","teriyaki glaze","ranch drizzle"},
    "fruits": {"pineapple","pear slices","apple slices","fresh figs","dried figs","dates","raisins","grapes","banana",
               "mango","peach slices","cranberry compote","apple chutney","pickled mango (achar)"},
    "crunch": {"crushed potato chips","crushed tortilla chips","pretzel pieces","toasted breadcrumbs","candied walnuts",
              "toasted pine nuts","sliced almonds","sesame seeds","fried shallots","crispy onions","panko crunch","roasted chickpeas"},
    "herbs": {"fresh basil","dried oregano","fresh oregano","thyme","rosemary","parsley","chives","crushed red pepper flakes",
              "black pepper","flaky sea salt","truffle oil","chili oil","balsamic glaze","honey","lemon zest","za'atar","sumac"},
    "funky": {"labneh dollops","tandoori chicken","paneer cubes","curry-spiced potatoes","chaat masala sprinkle",
              "harissa-roasted veggies","gochujang drizzle","souvlaki lamb","shawarma spices","shawarma chicken","falafel crumbles"},
    "dessert": {"mini marshmallows","chocolate chips","Nutella swirl","peanut butter dollops","gummy bears","fruity cereal",
                "ice cream scoop (post-bake)","caramel sauce","dulce de leche","toasted coconut","candied bacon","maple syrup drizzle"}
}

# -------------------------
# Seed word utilities
# -------------------------
def word_to_seed(word: str) -> int:
    if not word:
        return None
    h = hashlib.sha256(word.encode("utf-8")).digest()
    return int.from_bytes(h[:4], "big")

# -------------------------
# Cross-platform TTS (no pip)
# -------------------------
def _has(cmd):
    return shutil.which(cmd) is not None

def speak(text: str):
    if not text:
        return
    plat = sys.platform
    if plat == "darwin" and _has("say"):
        try:
            subprocess.Popen(["say", text])
            return
        except Exception:
            pass
    if plat.startswith("win"):
        try:
            escaped = text.replace("'", "''")
            cmd = [
                "powershell",
                "-NoProfile",
                "-Command",
                f"Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{escaped}')"
            ]
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        except Exception:
            pass
    if _has("espeak"):
        try:
            subprocess.Popen(["espeak", text])
            return
        except Exception:
            pass
    if _has("spd-say"):
        try:
            subprocess.Popen(["spd-say", text])
            return
        except Exception:
            pass
    print("[TTS unavailable: install espeak or spd-say on Linux, or use macOS/Windows built-in TTS]")

# -------------------------
# Generator logic
# -------------------------
def build_pool(include_weird=False, category=None):
    if category:
        key = category.lower()
        if key not in CATEGORIES:
            raise KeyError(f"Unknown category '{category}'. Available: {', '.join(sorted(CATEGORIES.keys()))}")
        pool = [t for t in TOPPINGS if t in CATEGORIES[key]]
    else:
        pool = list(TOPPINGS)
    if include_weird and (not category or category.lower() != "dessert"):
        for item in CATEGORIES["dessert"]:
            if item not in pool:
                pool.append(item)
    seen = set()
    unique = []
    for item in pool:
        if item not in seen:
            seen.add(item)
            unique.append(item)
    return unique

def generate_toppings(count, weird=False, category=None, seed=None):
    if seed is not None:
        random.seed(seed)
    pool = build_pool(include_weird=weird, category=category)
    if count < 1:
        raise ValueError("Pick at least 1 topping.")
    if count > len(pool):
        raise ValueError(f"Requested {count} toppings but only {len(pool)} available in the selected pool.")
    return random.sample(pool, count)

# -------------------------
# CLI and interactive loop with "remember last inputs"
# -------------------------
def parse_args(argv):
    p = argparse.ArgumentParser(description="Random Pizza Topping Generator (remembers last inputs)")
    p.add_argument("count", type=int, nargs="?", help="Number of toppings to pick (single-run).")
    p.add_argument("--weird", action="store_true", help="Include dessert/wildcard toppings")
    p.add_argument("--category", type=str, help="Restrict picks to a category (e.g., meats, cheeses, vegetables)")
    p.add_argument("--seed", type=int, help="Numeric seed for single-run or default for interactive rounds")
    p.add_argument("--seed-word", type=str, help="Seed word for single-run or default for interactive rounds")
    p.add_argument("--tts", action="store_true", help="Speak the generated topping list using system TTS")
    return p.parse_args(argv)

def prompt_with_default(prompt, default, show_default=True):
    """Helper: show default in prompt and return user input (empty string if blank)."""
    if show_default and default is not None and default != "":
        return input(f"{prompt} [default: {default}] ").strip()
    else:
        return input(f"{prompt} ").strip()

def interactive_loop(default_weird=False, default_category=None, default_tts=False, default_seed=None, default_seed_word=None):
    """
    Interactive loop that remembers the last entered values and uses them as defaults for the next round.
    The "last" values are updated after each successful generation.
    """
    print("Interactive mode. Type 'q' or 'quit' at the main prompt to exit.")
    # Initialize last-used values from defaults
    last_weird = default_weird
    last_category = default_category
    last_tts = default_tts
    last_seed = default_seed
    last_seed_word = default_seed_word

    while True:
        raw = input("\nHow many toppings would you like? (or 'q' to quit) ").strip()
        if raw.lower() in {"q", "quit"}:
            print("Goodbye.")
            return
        try:
            count = int(raw)
        except ValueError:
            print("Please enter a valid integer or 'q' to quit.")
            continue

        # Ask about weird, showing last choice
        w_prompt = "Include weird/dessert toppings? (y/N)"
        w_default = "y" if last_weird else "N"
        w_raw = prompt_with_default(w_prompt, w_default)
        if w_raw == "":
            weird = last_weird
        else:
            weird = w_raw.strip().lower().startswith("y")

        # Category prompt (show last)
        c_prompt = "Restrict to a category? (leave blank for all)"
        c_raw = prompt_with_default(c_prompt, last_category or "")
        cat = c_raw or last_category

        # TTS prompt (show last)
        t_prompt = "Speak results with TTS? (y/N)"
        t_default = "y" if last_tts else "N"
        t_raw = prompt_with_default(t_prompt, t_default)
        if t_raw == "":
            tts = last_tts
        else:
            tts = t_raw.strip().lower().startswith("y")

        # Seed prompt: show last seed word or numeric seed if present
        if last_seed_word is not None:
            seed_prompt = f"Seed word (optional, leave blank to use last '{last_seed_word}')"
            seed_raw = prompt_with_default(seed_prompt, last_seed_word)
        elif last_seed is not None:
            seed_prompt = f"Seed (optional, leave blank to use last {last_seed})"
            seed_raw = prompt_with_default(seed_prompt, str(last_seed))
        else:
            seed_prompt = "Seed or seed word (optional, leave blank for random)"
            seed_raw = prompt_with_default(seed_prompt, "")

        # Resolve seed: blank => use last; numeric => int; otherwise treat as seed word
        if seed_raw == "":
            seed = last_seed
            seed_word = last_seed_word
        else:
            if seed_raw.lstrip("-").isdigit():
                try:
                    seed = int(seed_raw)
                    seed_word = None
                except ValueError:
                    print("Invalid numeric seed. Try again.")
                    continue
            else:
                seed_word = seed_raw
                seed = word_to_seed(seed_word)

        # Attempt generation
        try:
            chosen = generate_toppings(count, weird=weird, category=cat, seed=seed)
        except (ValueError, KeyError) as e:
            print("Error:", e)
            continue

        # Print results
        print("\nYour random pizza toppings:")
        for i, t in enumerate(chosen, 1):
            print(f"{i}. {t}")

        if tts:
            speak("Your pizza toppings are: " + ", ".join(chosen))

        # Update "last" values to what the user just used (so they become defaults next round)
        last_weird = weird
        last_category = cat
        last_tts = tts
        last_seed = seed
        last_seed_word = seed_word

def main(argv=None):
    args = parse_args(argv or sys.argv[1:])
    # Resolve CLI seed precedence for single-run
    if args.seed_word:
        cli_seed = word_to_seed(args.seed_word)
        cli_seed_word = args.seed_word
    else:
        cli_seed = args.seed
        cli_seed_word = None

    # Single-run mode
    if args.count is not None:
        try:
            chosen = generate_toppings(args.count, weird=args.weird, category=args.category, seed=cli_seed)
        except (ValueError, KeyError) as e:
            print("Error:", e)
            return
        print("\nYour random pizza toppings:")
        for i, t in enumerate(chosen, 1):
            print(f"{i}. {t}")
        if args.tts:
            speak("Your pizza toppings are: " + ", ".join(chosen))
        return

    # Interactive mode: pass CLI flags as initial defaults
    interactive_loop(
        default_weird=args.weird,
        default_category=args.category,
        default_tts=args.tts,
        default_seed=cli_seed,
        default_seed_word=cli_seed_word
    )

if __name__ == "__main__":
    main()
