#!/usr/bin/env python3
"""
lexi_tts_loop.py
Repeat loop + quit + cross-platform TTS with no-pip default and optional pip packages.

Usage:
  python lexi_tts_loop.py
Type words or phrases (comma separated). Type "quit", "q", or "exit" to stop.
"""

import sys
import time
import urllib.parse
import urllib.request
import re
import subprocess
import shutil
import tempfile
import os

USER_AGENT = "Mozilla/5.0 (compatible; LexiBot/1.0; +https://example.local/)"

# -------------------------
# Networking and scraping
# -------------------------
def fetch_url(url, timeout=10):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        charset = resp.headers.get_content_charset() or "utf-8"
        return resp.read().decode(charset, errors="replace")

def bing_search_html(query, count=10):
    q = urllib.parse.quote_plus(query)
    url = f"https://www.bing.com/search?q={q}&count={count}"
    return fetch_url(url)

def extract_estimated_results_from_bing(html):
    m = re.search(r'([0-9][0-9,\.]{0,20})\s+results', html, flags=re.IGNORECASE)
    if m:
        raw = m.group(1)
        return int(re.sub(r'[^\d]', '', raw))
    m2 = re.search(r'About\s+([0-9][0-9,\.]{0,20})', html, flags=re.IGNORECASE)
    if m2:
        raw = m2.group(1)
        return int(re.sub(r'[^\d]', '', raw))
    return None

def extract_result_links_from_bing(html, max_links=5):
    links = []
    for m in re.finditer(r'<li class="b_algo".*?>.*?<a\s+href="([^"]+)"', html, flags=re.DOTALL):
        url = m.group(1)
        if url.startswith("http"):
            links.append(url)
        if len(links) >= max_links:
            break
    if not links:
        for m in re.finditer(r'<a\s+href="(https?://[^"]+)"', html):
            links.append(m.group(1))
            if len(links) >= max_links:
                break
    seen = set()
    out = []
    for u in links:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out[:max_links]

def strip_tags(html):
    text = re.sub(r'(?s)<script.*?>.*?</script>', ' ', html)
    text = re.sub(r'(?s)<style.*?>.*?</style>', ' ', text)
    text = re.sub(r'<!--.*?-->', ' ', text)
    text = re.sub(r'<[^>]+>', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def count_term_in_text(text, term, case_insensitive=True):
    if case_insensitive:
        text = text.lower()
        term = term.lower()
    pattern = re.escape(term)
    return len(re.findall(pattern, text))

def analyze_term(term, scan_pages=False, top_n=5, delay=0.5):
    result = {
        "term": term,
        "estimated_results": None,
        "searchpage_count": 0,
        "top_pages": {}
    }
    try:
        html = bing_search_html(term, count=top_n)
    except Exception as e:
        print("  Error fetching search page:", e)
        return result

    result["estimated_results"] = extract_estimated_results_from_bing(html)
    text = strip_tags(html)
    result["searchpage_count"] = count_term_in_text(text, term)

    if scan_pages:
        links = extract_result_links_from_bing(html, max_links=top_n)
        for url in links:
            try:
                page_html = fetch_url(url)
                page_text = strip_tags(page_html)
                cnt = count_term_in_text(page_text, term)
                result["top_pages"][url] = cnt
            except Exception:
                result["top_pages"][url] = None
            time.sleep(delay)
    return result

# -------------------------
# Text to Speech utilities
# -------------------------
def speak_system(text):
    """Try system TTS: macOS say, Windows PowerShell System.Speech, Linux spd-say or espeak."""
    text = str(text).strip()
    if not text:
        return False

    # macOS
    if shutil.which("say"):
        try:
            subprocess.run(["say", text], check=False)
            return True
        except Exception:
            pass

    # Windows via PowerShell System.Speech
    if sys.platform.startswith("win"):
        try:
            # Escape single quotes for PowerShell single-quoted string by doubling them
            ps_text = text.replace("'", "''")
            cmd = [
                "powershell",
                "-NoProfile",
                "-Command",
                f"Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{ps_text}')"
            ]
            subprocess.run(cmd, check=False)
            return True
        except Exception:
            pass

    # Linux: try spd-say then espeak
    if shutil.which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=False)
            return True
        except Exception:
            pass
    if shutil.which("espeak"):
        try:
            subprocess.run(["espeak", text], check=False)
            return True
        except Exception:
            pass

    return False

def speak_pyttsx3(text):
    """Try pyttsx3 if installed (pip)."""
    try:
        import pyttsx3
    except Exception:
        return False
    try:
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
        return True
    except Exception:
        return False

def speak_gtts(text):
    """Try gTTS if installed and an audio player is available. This requires internet for gTTS."""
    try:
        from gtts import gTTS
    except Exception:
        return False
    # choose a player
    player = None
    for p in ("mpg123", "mpv", "afplay", "ffplay", "play"):
        if shutil.which(p):
            player = p
            break
    if not player:
        return False
    try:
        tts = gTTS(text=text, lang="en")
        fd, path = tempfile.mkstemp(suffix=".mp3")
        os.close(fd)
        tts.save(path)
        # play without printing
        if player == "ffplay":
            subprocess.run([player, "-nodisp", "-autoexit", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.run([player, path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            os.remove(path)
        except Exception:
            pass
        return True
    except Exception:
        return False

def speak(text, prefer_pip=False):
    """Unified speak function. prefer_pip tries pip packages first if True."""
    if prefer_pip:
        if speak_pyttsx3(text):
            return True
        if speak_gtts(text):
            return True
    # fallback to system TTS
    if speak_system(text):
        return True
    # final fallback: try pip packages even if not preferred
    if speak_pyttsx3(text):
        return True
    if speak_gtts(text):
        return True
    return False

# -------------------------
# Interactive loop
# -------------------------
def prompt_yes_no(prompt, default=False):
    ans = input(prompt + (" [y/N] " if not default else " [Y/n] ")).strip().lower()
    if ans == "":
        return default
    return ans[0] == "y"

def main():
    print("Lexi TTS loop — type words, press Enter. Type quit, q, or exit to stop.")
    prefer_pip = prompt_yes_no("Prefer pip-based TTS if available", default=False)
    scan = prompt_yes_no("Fetch top result pages and count exact occurrences (slower)", default=False)
    try:
        top_n = int(input("How many top results to scan (default 5) > ").strip() or "5")
    except ValueError:
        top_n = 5

    while True:
        raw = input("\nEnter one or more words or phrases (comma separated) > ").strip()
        if not raw:
            print("No input. Type quit to exit.")
            continue
        if raw.lower() in ("quit", "q", "exit"):
            print("Goodbye.")
            speak("Goodbye.")
            break

        terms = [t.strip() for t in raw.split(",") if t.strip()]
        for term in terms:
            print(f"\nAnalyzing: {term!r}")
            res = analyze_term(term, scan_pages=scan, top_n=top_n)
            if res["estimated_results"] is not None:
                print(f"  Estimated search results (scraped): {res['estimated_results']:,}")
            else:
                print("  Estimated search results: not found")
            print(f"  Occurrences inside search page text (heuristic): {res['searchpage_count']}")
            if scan:
                print("  Exact counts on top pages:")
                for url, cnt in res["top_pages"].items():
                    if cnt is None:
                        print(f"    {url}  ->  fetch failed or blocked")
                    else:
                        print(f"    {url}  ->  {cnt}")

            # Prepare a short spoken summary
            est = res["estimated_results"]
            est_text = f"about {est:,} results" if est else "an unknown number of results"
            speak_text = f"Search for {term}. {est_text}. Occurrences in search page {res['searchpage_count']}."
            ok = speak(speak_text, prefer_pip=prefer_pip)
            if not ok:
                print("  TTS not available on this system. See script header for optional pip packages.")
            time.sleep(0.2)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrupted. Bye.")
        try:
            speak("Goodbye.")
        except Exception:
            pass
        sys.exit(0)
