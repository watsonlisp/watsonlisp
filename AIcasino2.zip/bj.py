import random

def create_deck():
    """ Create a standard deck of cards. """
    suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades']
    values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']
    deck = [{'suit': suit, 'value': value} for suit in suits for value in values]
    random.shuffle(deck)
    return deck

def card_value(card):
    """ Turn a card into its blackjack value. """
    if card['value'] in ['Jack', 'Queen', 'King']:
        return 10
    elif card['value'] == 'Ace':
        return 11  # We'll handle Aces later
    return int(card['value'])

def play_blackjack():
    """ Main function to play a game of blackjack. """
    deck = create_deck()

    # Deal initial hands
    player_hand = [deck.pop(), deck.pop()]
    dealer_hand = [deck.pop(), deck.pop()]

    # Show player's hand and one of dealer's cards
    print("Your hand:", player_hand)
    print("Dealer shows:", dealer_hand[0])

    # Player's turn
    while True:
        action = input("h or s? ").lower()
        if action == 'h':
            player_hand.append(deck.pop())
            print("Your hand:", player_hand)
            if sum(card_value(card) for card in player_hand) > 21:
                print("Bust! You lose.")
                return
        else:
            break

    # Dealer's turn
    print("Dealer's hand:", dealer_hand)
    while sum(card_value(card) for card in dealer_hand) < 17:
        dealer_hand.append(deck.pop())
        print("Dealer's hand:", dealer_hand)
        if sum(card_value(card) for card in dealer_hand) > 21:
            print("Dealer busts! You win.")
            return

    # Final result
    player_score = sum(card_value(card) for card in player_hand)
    dealer_score = sum(card_value(card) for card in dealer_hand)

    if player_score > dealer_score:
        print("You win!")
    elif player_score < dealer_score:
        print("Dealer wins!")
    else:
        print("It's a tie!")

play_blackjack()

