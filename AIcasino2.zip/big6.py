import random

def spin_wheel():
    wheel_sections = [1, 2, 5, 10, 20]
    return random.choice(wheel_sections)

def big_six_game():
    print("Welcome to Big Six!")
    bet_section = int(input("Select a section (1, 2, 5, 10, 20): "))
    bet_amount = float(input("How much do you want to bet? "))

    result = spin_wheel()
    print(f"The wheel landed on {result}.")

    if result == bet_section:
        print(f"Congrats! You won ${bet_amount * bet_section}")
    else:
        print("Sorry, you lose this time.")

big_six_game()

