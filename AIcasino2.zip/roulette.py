import random

# Setting up the roulette wheel with numbers and colors
def create_wheel():
    wheel = {'numbers': list(range(0, 37)), 'red': [], 'black': []}
    for i in range(1, 37):
        if i % 2 == 0:
            wheel['red'].append(i)
        else:
            wheel['black'].append(i)
    return wheel

# Placing bets with different options
def place_bet():
    bet_type = input("Bet on 'number', 'color', or 'odd/even': ")
    if bet_type == 'number':
        return int(input("Place your bet on a number (0-36): "))
    elif bet_type in ('color', 'odd/even'):
        return bet_type, input("Place your bet (red/black or odd/even): ")
    
# Spin the wheel
def spin_wheel(wheel):
    return random.choice(wheel['numbers'])

# Main game loop
def roulette():
    wheel = create_wheel()
    player_bet = place_bet()
    winning_number = spin_wheel(wheel)
    if type(player_bet) == tuple:
        bet_type, bet_value = player_bet
        if bet_type == 'color':
            result_color = 'red' if winning_number in wheel['red'] else 'black'
            if bet_value == result_color:
                print("You win!")
            else:
                print(f"You lose. The winning number was {winning_number}")
        elif bet_type == 'odd/even':
            result_parity = 'odd' if winning_number % 2 != 0  else 'even'
            if bet_value == result_parity:
                print("You win!")
            else:
                print(f"You lose. The winning number was {winning_number}")
    else:
        if player_bet == winning_number:
            print("You win!")
        else:
            print(f"You lose. The winning number was {winning_number}")

roulette()
