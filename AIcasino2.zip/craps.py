import random

def roll_dice():
    return random.randint(1, 6) + random.randint(1, 6)

def play_craps():
    print("Welcome to Craps!")
    first_roll = roll_dice()
    print(f"You rolled: {first_roll}")

    if first_roll in [7, 11]:
        print("You win!")
    elif first_roll in [2, 3, 12]:
        print("Craps! You lose.")
    else:
        point = first_roll
        print(f"Point is set to {point}. Keep rolling!")
        while True:
            roll = roll_dice()
            print(f"You rolled: {roll}")
            if roll == point:
                print("You hit the point! You win!")
                break
            elif roll == 7:
                print("You rolled a 7. You lose.")
                break



play_craps()

