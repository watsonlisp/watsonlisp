import random

def slot_machine(slots):
    slogans = [
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "I",
        "J",
        "K",
        "L",
        "M",
        "N",
        "O",
        "E",
        "O",
        "P",
        "Q",
        "R",
        "R",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z"
    ]

    results = [random.choice(slogans) for _ in range(slots)]
    return results

# Select the slot machine type you want and then pick 3 to 5 slots
slots = int(input("Enter the number of slots (3 to 5): "))
assert 3 <= slots <= 5, "Please choose between 3 to 5 slots."

# Run the slot machine
print("Let's play!")
results = slot_machine(slots)
for result in results:
    print(result)
    


