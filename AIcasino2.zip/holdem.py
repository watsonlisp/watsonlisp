import random


def holdem():
    pot = 0

    def calculate_hand_value(hand):
        """Calculate the value of a hand."""
        value = 0
        ace_count = 0
        for card in hand:
            if card['rank'] in ['Jack', 'Queen', 'King']:
                value += 10
            elif card['rank'] == 'Ace':
                ace_count += 1
            else:
                value += int(card['rank'])

        for _ in range(ace_count):
            if value + 11 > 21:
                value += 1
            else:
                value += 11

        return value


    # Define the suits and ranks
    suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades']
    ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']

    # Create the deck of cards
    deck = [{'rank': rank, 'suit': suit} for suit in suits for rank in ranks]

    # Shuffle the deck
    random.shuffle(deck)

    # Deal two cards to each player
    player_1_hand = [deck.pop(), deck.pop()]
    player_2_hand = [deck.pop(), deck.pop()]

    print(f"Player 1 hand: {player_1_hand}")
    print(f"Player 2 hand: {player_2_hand}")



    # Starting chips for each player
    player_chips = {1: 1000, 2: 1000}

    def pot_tracker(pot, event=""):
     print(f"🌀 Pot update: {pot} chips after {event}")





 #   def pottotal():
    def pottotal(pot):
     if pot is not None and pot >= 1:
        print("go for it")
     else:
        pot = 0
     return pot
    
  #  pottotal(pot)

    
    # Betting function
    def betting_round(player_chips, pot):
        current_bet = 0

        for player in player_chips:
         action = input(f"Player {player}, you have {player_chips[player]} chips. Enter 'Bet', 'Raise', or 'Fold': ").lower()

         if action == 'b':
            bet_amount = int(input("Enter bet amount: "))
            current_bet = bet_amount
            player_chips[player] -= bet_amount
            pot += bet_amount
            pot_tracker(pot, f"Player {player} bet {bet_amount}")
            if player == 2:
             return pot

         elif action == 'r':
            raise_amount = int(input("Enter raise amount: "))
            current_bet += raise_amount
            player_chips[player] -= raise_amount
            pot += raise_amount
#            pot_tracker(pot, f"Player {player} bet {bet_amount}")

            # Ask other player to match
            for opponent in player_chips:
                if opponent != player:
                    response = input(f"Player {opponent}, match the raise of {raise_amount}? (yes/no): ").lower()
                    if response == 'yes':
                        player_chips[opponent] -= raise_amount
                        pot += raise_amount
                    else:
                        print(f"Player {opponent} folds.")
                if player == 2:
                    return pot
            
         elif action == 'f':
            print(f"Player {player} folds.")
            break
         else:
            print("Invalid action. Try again.")
     #       return pot
    #return pot




    # Example round
   # pot = betting_round(player_chips)
    print(f"Pot is now: {pot} chips")
    print(f"Player chips after betting: {player_chips}")




    def deal_cards(deck, num_players):
        return {f'Player {i+1}': [deck.pop(), deck.pop()] for i in range(num_players)}

    # Deal hole cards
    players_hands = {
        'Player 1': [deck.pop(), deck.pop()],
        'Player 2': [deck.pop(), deck.pop()]
    }

    # Deal community cards
    community_cards = [deck.pop() for _ in range(5)]
    blind = community_cards[:0]
    flop = community_cards[:3]
    turn = community_cards[3]
    river = community_cards[4]

    print("blind:", blind)

    pot = betting_round(player_chips, pot)

    print("Flop:", flop)

    pot = betting_round(player_chips, pot)


    print("Turn:", turn)

    pot = betting_round(player_chips, pot)

    print("River:", river)

    pot = betting_round(player_chips, pot)

    def showdown(players_hands, community_cards, pot):

        rankings = {}
        for player, hand in players_hands.items():
            full_hand = hand + community_cards
            rank = evaluate_hand(full_hand)
            print(f"{player} final hand: {show_hand(full_hand)} -> {rank[0]}")
            rankings[player] = rank

        winner = max(rankings, key=lambda k: (rankings[k][0], rankings[k][1]))
        print(f"🏆 {winner} wins with {rankings[winner][0]}")
        print(f"🏁 Final pot total: {pot} chips") 




    def usage():
        deck = [{'rank': rank, 'suit': suit} for suit in suits for rank in ranks]
        random.shuffle(deck)

        players_hands = deal_cards(deck, 2)
        dealer_hand = [deck.pop(), deck.pop()]

        for player, hand in players_hands.items():
            print(f"{player}'s turn")
            player_turn(hand, deck)
        
        print("Dealer's turn")
        dealer_turn(dealer_hand, deck)


        def format_card(card):
         return f"{card['rank']} of {card['suit']}"

    def show_hand(hand):
        return ", ".join(format_card(card) for card in hand)

    from collections import Counter

    #from collections import Counter

    def evaluate_hand(hand):
        ranks = [card['rank'] for card in hand]
        rank_values = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7,
                       '8':8, '9':9, '10':10, 'Jack':11,
                       'Queen':12, 'King':13, 'Ace':14}
        values = [rank_values[r] for r in ranks]
        counts = Counter(values)

        if 4 in counts.values():
            return ('Four of a Kind', max(counts, key=lambda k: counts[k]))
        elif sorted(counts.values()) == [2,3]:
            return ('Full House', max(counts, key=lambda k: counts[k]))
        elif 3 in counts.values():
            return ('Three of a Kind', max(counts, key=lambda k: counts[k]))
        elif list(counts.values()).count(2) == 2:
            return ('Two Pair', max(counts, key=lambda k: counts[k]))
        elif 2 in counts.values():
            return ('One Pair', max(counts, key=lambda k: counts[k]))
        else:
            return ('High Card', max(values))

        def is_flush(hand):
         suits = [card['suit'] for card in hand]
         return len(set(suits)) == 1

        def is_straight(values):
         values = sorted(set(values))
         for i in range(len(values) - 4):
          if values[i+4] - values[i] == 4:
            return True
    # Handle Ace-low straight (A-2-3-4-5)
            if set([14, 2, 3, 4, 5]).issubset(values):
             return True
             return False




    hand_strength = {
        'High Card': 1,
        'One Pair': 2,
        'Two Pair': 3,
        'Three of a Kind': 4,
        'Straight': 5,
        'Flush': 6,
        'Full House': 7,
        'Four of a Kind': 8,
        'Straight Flush': 9
    }

    def format_card(card):
        return f"{card['rank']} of {card['suit']}"

    def show_hand(hand):
        return ", ".join(format_card(card) for card in hand)

    showdown(players_hands, community_cards, pot)


holdem()
        

