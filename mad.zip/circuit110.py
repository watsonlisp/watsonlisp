#!/usr/bin/env python3
"""
Circuit Designer — merged, runnable script with:
- wire-drawing robustness fixes
- confirmation prompts when combining components
- prompting for values on every component insertion
- working Probe mode
- Solve (Ohm's law) auto-shows solution when a resistance is prefilled
- When a resistor is selected and Solve is used, show the calculation steps and do NOT replace the resistor

Run with Python 3. No external dependencies.
"""
import tkinter as tk
from tkinter import simpledialog, filedialog, messagebox
import json, math, copy, heapq, traceback, os

# Default configuration
CANVAS_W = 1200
CANVAS_H = 800
PALETTE_W = 420
GRID = 10.0
CLUSTER_DIST = 8.0
SNAP_DIST = 12.0
JUNCTION_RADIUS = 6.0

# --- Geometry helpers ---
def dist2(a, b):
    dx = a[0] - b[0]; dy = a[1] - b[1]
    return dx*dx + dy*dy

def dist(a, b):
    return math.hypot(a[0]-b[0], a[1]-b[1])

def project_point_to_segment(p, a, b):
    ax, ay = a; bx, by = b; px, py = p
    vx, vy = bx-ax, by-ay
    l2 = vx*vx + vy*vy
    if l2 == 0: return a
    t = ((px-ax)*vx + (py-ay)*vy) / l2
    t = max(0.0, min(1.0, t))
    return (ax + t*vx, ay + t*vy)

# --- Value formatting ---
def format_value(v, unit=""):
    if v is None or v == "": return ""
    try:
        num = float(v)
    except Exception:
        return str(v)
    absnum = abs(num)
    if absnum >= 1e9: s = f"{num/1e9:.3g}G"
    elif absnum >= 1e6: s = f"{num/1e6:.3g}M"
    elif absnum >= 1e3: s = f"{num/1e3:.3g}k"
    elif absnum >= 1.0: s = f"{num:.3g}"
    elif absnum >= 1e-3: s = f"{num*1e3:.3g}m"
    elif absnum >= 1e-6: s = f"{num*1e6:.3g}u"
    elif absnum >= 1e-9: s = f"{num*1e9:.3g}n"
    else: s = f"{num:.3g}"
    return f"{s} {unit}" if unit else s

# --- Data classes ---
class Component:
    def __init__(self, kind, x, y, angle=0, label=None, value=None, unit=None):
        self.kind = kind
        self.x = float(x); self.y = float(y); self.angle = angle  # degrees
        self.label = label or f"{kind[:3]}{int(x)}"
        self.value = value
        self.unit = unit or self.default_unit()
        self.id_items = []
        self.nodes = [None, None]

    def default_unit(self):
        return {"resistor":"Ω","capacitor":"F","inductor":"H","vsource":"V","isource":"A"}.get(self.kind,"")

    def to_dict(self):
        return {"kind":self.kind,"x":self.x,"y":self.y,"angle":self.angle,"label":self.label,"value":self.value,"unit":self.unit}

    @staticmethod
    def from_dict(d):
        return Component(d["kind"], d["x"], d["y"], d.get("angle",0), d.get("label"), d.get("value"), d.get("unit"))

class Wire:
    def __init__(self, points):
        # Defensive: sanitize incoming points list so invalid entries don't crash the app.
        self.points = []
        if points is None:
            points = []
        for p in points:
            try:
                # Accept either (x,y) or objects with indexable coords
                x = float(p[0]); y = float(p[1])
                self.points.append((x, y))
            except Exception:
                # skip invalid point entries silently (don't crash)
                continue
        self.id_items = []

    def to_dict(self):
        return {"points": self.points}

    @staticmethod
    def from_dict(d):
        pts = d.get("points", []) if isinstance(d, dict) else []
        return Wire([tuple(p) for p in pts if isinstance(p, (list, tuple)) and len(p) >= 2])

class Node:
    def __init__(self, nid, coord):
        self.id = nid
        self.coord = coord
        self.wires = set()
        self.components = set()
        self.voltage = None
        self.marker_id = None

# --- Main app ---
class CircuitDesigner:
    def __init__(self, root):
        self.root = root
        self._init_config()
        root.title("Circuit Designer — Probe Fixed")
        # Global Tkinter callback exception handler
        try:
            self.root.report_callback_exception = self._tk_exception_handler
        except Exception:
            pass

        # state
        self.mode = "select"
        self.multimeter_type = None
        self.multimeter_panel = None
        self._multimeter_var = None
        self.multimeter_reading_var = None
        self.snap = True

        self.components = []
        self.wires = []
        self.nodes = []

        self.selected = None
        self.multi_selected = []
        self.drag_data = {"item":None,"x":0,"y":0}

        self.wire_points = []
        self.rubber_pos = None

        # Probe-specific state
        self.region_start = None
        self.region_rect_id = None
        self.region_results = []   # list of (type, ref) tuples: ("comp", Component) or ("wire", Wire)
        self.region_index = -1
        self.region_panel = None

        self.probe_annotations = []
        self.multimeter_points = []

        self.scale = 1.0
        self.offset_x = 0.0
        self.offset_y = 0.0

        self.panning = False
        self.pan_start = (0,0)
        self.pan_offset_start = (0,0)

        self.undo_stack = []
        self.max_undo = 100

        # UI layout
        root.rowconfigure(0, weight=1); root.columnconfigure(1, weight=1)
        self.left_container = tk.Frame(root, width=self.PALETTE_W)
        self.left_container.grid(row=0, column=0, sticky="ns")
        self.left_container.grid_propagate(False)

        self.palette_canvas = tk.Canvas(self.left_container, width=self.PALETTE_W, height=self.CANVAS_H, bg="#f0f0f0", highlightthickness=0)
        self.palette_scroll = tk.Scrollbar(self.left_container, orient="vertical", command=self.palette_canvas.yview)
        self.palette_canvas.configure(yscrollcommand=self.palette_scroll.set)
        self.palette_scroll.pack(side="right", fill="y")
        self.palette_canvas.pack(side="left", fill="both", expand=True)
        self.palette_inner = tk.Frame(self.palette_canvas)
        self.palette_canvas.create_window((0,0), window=self.palette_inner, anchor="nw")
        self.palette_inner.bind("<Configure>", lambda e: self.palette_canvas.configure(scrollregion=self.palette_canvas.bbox("all")))

        self.canvas = tk.Canvas(root, width=self.CANVAS_W, height=self.CANVAS_H, bg="white")
        self.canvas.grid(row=0, column=1, sticky="nsew")

        tk.Label(self.palette_inner, text="Palette", font=("Arial",12,"bold")).pack(pady=6)
        kinds = ["resistor","capacitor","inductor","vsource","isource","diode","led","npn","pnp","mosfet","ground","switch","transformer","opamp","wire","erase","probe","multimeter","move","rotate","select"]
        for k in kinds:
            label = (k.upper() if len(k)>6 else k.capitalize())
            b = tk.Button(self.palette_inner, text=label, width=44, command=lambda k=k: self.set_mode(k))
            b.pack(pady=2, padx=6)

        tk.Button(self.palette_inner, text="End Wire (Enter)", width=44, command=self.finish_wire).pack(pady=6)
        tk.Button(self.palette_inner, text="Cancel Wire (Esc)", width=44, command=self.cancel_wire).pack(pady=2)
        tk.Button(self.palette_inner, text="Set Value", width=44, command=self.set_value_for_selected).pack(pady=6)
        tk.Button(self.palette_inner, text="Solve (Ohm's law)", width=44, command=lambda: self.solve_circuit(silent=False)).pack(pady=6)

        tk.Label(self.palette_inner, text="Combine Selection", font=("Arial",10,"bold")).pack(pady=(12,2))
        tk.Button(self.palette_inner, text="Sum Series (selected)", width=44, command=self.sum_series_selected).pack(pady=2)
        tk.Button(self.palette_inner, text="Combine Parallel (selected)", width=44, command=self.combine_parallel_selected).pack(pady=2)
        tk.Button(self.palette_inner, text="Clear Multi-Selection", width=44, command=self.clear_multi_selection).pack(pady=2)

        tk.Button(self.palette_inner, text="Undo (Ctrl+Z)", width=44, command=self.undo).pack(pady=(12,6))
        tk.Button(self.palette_inner, text="Help (F1 / Ctrl+H)", width=44, command=self.open_help).pack(pady=(2,8))

        tk.Button(self.palette_inner, text="Settings", width=44, command=self.open_settings).pack(pady=8)
        tk.Button(self.palette_inner, text="Save", width=44, command=self.save_circuit).pack(pady=6)
        tk.Button(self.palette_inner, text="Load", width=44, command=self.load_circuit).pack(pady=2)
        tk.Button(self.palette_inner, text="Clear", width=44, command=self.clear_all).pack(pady=2)

        self.status = tk.StringVar()
        self.status.set("Mode: select — Click to select; Shift+click to multi-select; drag to move; C to copy; R to rotate.")
        tk.Label(root, textvariable=self.status, anchor="w").grid(row=1, column=0, columnspan=2, sticky="we")

        # bindings
        self.canvas.bind("<Button-1>", self.on_left_click)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Double-Button-1>", self.on_double_click)
        self.canvas.bind("<Button-3>", self.on_right_click)
        self.canvas.bind("<Motion>", self.on_mouse_move)

        self.canvas.bind("<Button-2>", self.on_middle_down)
        self.canvas.bind("<B2-Motion>", self.on_middle_drag)
        self.canvas.bind("<ButtonRelease-2>", self.on_middle_up)

        self.canvas.bind("<MouseWheel>", self.on_mouse_wheel)
        self.canvas.bind("<Button-4>", self.on_mouse_wheel)
        self.canvas.bind("<Button-5>", self.on_mouse_wheel)

        root.bind("g", self.toggle_grid); root.bind("G", self.toggle_grid)
        root.bind("r", self.rotate_selected); root.bind("R", self.rotate_selected)
        root.bind("c", self.copy_selected); root.bind("C", self.copy_selected)
        root.bind("<Control-c>", self.copy_selected)
        root.bind("<Return>", lambda e: self.finish_wire())
        root.bind("<KP_Enter>", lambda e: self.finish_wire())
        root.bind("<Escape>", lambda e: self.cancel_wire())
        root.bind("n", lambda e: self.cycle_region_results()); root.bind("N", lambda e: self.cycle_region_results())
        root.bind("m", lambda e: self.set_mode("multimeter"))
        root.bind("<Control-z>", lambda e: self.undo())
        root.bind("<F1>", lambda e: self.open_help())
        root.bind("<Control-h>", lambda e: self.open_help())

        self.reset_view()
        self.set_mode("select")
        self.redraw()

    # --- Tkinter exception handler ---
    def _tk_exception_handler(self, exc, val, tb):
        try:
            tb_text = "".join(traceback.format_exception(exc, val, tb))
            print(tb_text)
            messagebox.showerror("Unhandled Exception", f"An unexpected error occurred:\n\n{val}\n\nSee console for full traceback.")
        except Exception:
            try:
                print("Error in exception handler:")
                traceback.print_exception(exc, val, tb)
            except Exception:
                pass

    def _init_config(self):
        self.CANVAS_W = CANVAS_W
        self.CANVAS_H = CANVAS_H
        self.PALETTE_W = PALETTE_W
        self.GRID = GRID
        self.CLUSTER_DIST = CLUSTER_DIST
        self.SNAP_DIST = SNAP_DIST
        self.JUNCTION_RADIUS = JUNCTION_RADIUS

    # --- Help dialog ---
    def open_help(self):
        help_text = [
            ("Modes", [
                "select — Click to select components or wires; Shift+click to multi-select.",
                "move — Drag components or wires for fine-grained repositioning.",
                "wire — Click to add wire points; Enter to finish; Esc to cancel.",
                "probe — Drag a region to list components and wires with values.",
                "multimeter — Click two nodes to measure voltage/resistance/current.",
                "erase — Click or drag to remove components/wires.",
                "rotate — Click a component to rotate 90°."
            ]),
            ("Shortcuts", [
                "Ctrl+Z — Undo last change.",
                "F1 or Ctrl+H — Open this help dialog.",
                "C or Ctrl+C — Copy selected component or wire.",
                "R — Rotate selected component (also Rotate mode).",
                "Enter — Finish wire drawing.",
                "Esc — Cancel wire or close panels."
            ]),
            ("Combine Selection", [
                "Sum Series — With multiple resistors selected, sums numeric values (unknowns ignored with prompt).",
                "Combine Parallel — Computes 1 / sum(1/R) for numeric resistors; handles 0Ω (short) specially."
            ]),
            ("Probe Panel", [
                "After dragging a region in Probe mode, a panel lists components and wires with values/lengths.",
                "Double-click an item in the panel to select it on the canvas.",
                "Use Select All to multi-select all listed items."
            ]),
            ("Multimeter", [
                "Open Multimeter (button or mode) to choose Voltage/Current/Resistance.",
                "Click two nodes (or terminals) on the canvas to get a heuristic reading.",
                "Resistance uses shortest-resistance path through resistors (simple graph heuristic)."
            ]),
            ("Files & Settings", [
                "Save / Load — Save circuit to JSON and reload later.",
                "Settings — Change GRID, SNAP_DIST, JUNCTION_RADIUS, canvas/palette sizes."
            ]),
            ("Undo Behavior", [
                "Undo stores snapshots before mutating actions (place, move, copy, rotate, delete, wire finish/cancel, set value, combine, load, clear).",
                "Up to 100 undo steps are kept by default."
            ])
        ]

        dlg = tk.Toplevel(self.root)
        dlg.title("Help — Commands and Shortcuts")
        dlg.geometry("+%d+%d" % (self.root.winfo_rootx()+60, self.root.winfo_rooty()+60))
        dlg.resizable(True, True)

        header = tk.Label(dlg, text="Circuit Designer — Quick Reference", font=("Arial", 12, "bold"))
        header.pack(anchor="w", padx=10, pady=(8,4))

        canvas = tk.Canvas(dlg)
        frame = tk.Frame(canvas)
        vsb = tk.Scrollbar(dlg, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        canvas.create_window((0,0), window=frame, anchor="nw")
        frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        for section, lines in help_text:
            lbl = tk.Label(frame, text=section, font=("Arial", 10, "bold"))
            lbl.pack(anchor="w", padx=8, pady=(8,2))
            for ln in lines:
                tk.Label(frame, text="• " + ln, anchor="w", justify="left", wraplength=520).pack(anchor="w", padx=18)

        btn_frame = tk.Frame(dlg)
        btn_frame.pack(fill="x", padx=8, pady=8)
        tk.Button(btn_frame, text="Close", command=dlg.destroy).pack(side="right")

    # --- Undo helpers ---
    def _snapshot_state(self):
        return {
            "components": [c.to_dict() for c in self.components],
            "wires": [w.to_dict() for w in self.wires],
            "selected_index": self.components.index(self.selected) if self.selected in self.components else None,
            "multi_selected_labels": [c.label for c in self.multi_selected if isinstance(c, Component)]
        }

    def push_undo(self):
        try:
            snap = self._snapshot_state()
            self.undo_stack.append(snap)
            if len(self.undo_stack) > self.max_undo:
                self.undo_stack.pop(0)
            self.status.set("State saved for undo.")
        except Exception:
            pass

    def undo(self):
        if not self.undo_stack:
            self.status.set("Nothing to undo.")
            return
        snap = self.undo_stack.pop()
        try:
            self.components = [Component.from_dict(d) for d in snap.get("components",[])]
            self.wires = [Wire.from_dict(d) for d in snap.get("wires",[])]
            self.rebuild_nodes()
            sel_idx = snap.get("selected_index")
            if sel_idx is not None and 0 <= sel_idx < len(self.components):
                self.selected = self.components[sel_idx]
            else:
                self.selected = None
            labels = snap.get("multi_selected_labels", [])
            self.multi_selected = []
            for lbl in labels:
                for c in self.components:
                    if c.label == lbl:
                        self.multi_selected.append(c)
                        break
            self.redraw()
            self.status.set("Undo applied.")
        except Exception as e:
            messagebox.showerror("Undo Error", str(e))

    # --- view transforms ---
    def reset_view(self):
        w = self.canvas.winfo_width() or self.CANVAS_W
        h = self.canvas.winfo_height() or self.CANVAS_H
        self.scale = 1.0
        self.offset_x = w/2.0
        self.offset_y = h/2.0

    def world_to_screen(self, pt):
        xw, yw = pt
        xs = xw * self.scale + self.offset_x
        ys = yw * self.scale + self.offset_y
        return (xs, ys)

    def screen_to_world(self, sx, sy):
        xw = (sx - self.offset_x) / self.scale
        yw = (sy - self.offset_y) / self.scale
        return (xw, yw)

    def zoom_at(self, screen_x, screen_y, factor):
        wx_before, wy_before = self.screen_to_world(screen_x, screen_y)
        self.scale *= factor
        self.scale = max(0.05, min(8.0, self.scale))
        wx_after, wy_after = self.screen_to_world(screen_x, screen_y)
        self.offset_x += (wx_after - wx_before) * self.scale
        self.offset_y += (wy_after - wy_before) * self.scale

    # --- helpers ---
    def snap_xy(self, x, y):
        if not self.snap: return (float(x), float(y))
        gx = self.GRID
        try:
            return (round(x/gx)*gx, round(y/gx)*gx)
        except Exception:
            # fallback to raw floats if something odd happens
            return (float(x), float(y))

    def set_mode(self, mode):
        if self.mode == "multimeter" and mode != "multimeter":
            self.close_multimeter_panel()
        self.mode = mode
        self.multimeter_points = []
        self.rubber_pos = None
        self.drag_data = {"item":None,"x":0,"y":0}
        self.clear_probe_annotations()
        self.region_clear()
        if mode == "multimeter":
            self.multimeter_type = "voltage"
            self.open_multimeter_panel()
            self.status.set("Mode: Multimeter — tap two nodes to measure.")
        elif mode == "probe":
            self.status.set("Mode: Probe — drag to select region.")
        elif mode == "move":
            self.status.set("Mode: Move — drag components or wires (fine increments).")
        elif mode == "rotate":
            self.status.set("Mode: Rotate — click a component to rotate.")
        else:
            self.status.set(f"Mode: {mode} — Left click to place or draw; Enter to finish wire; Esc to cancel.")
        if mode == "wire":
            self.canvas.focus_set()
        self.redraw()

    # --- multimeter UI & logic ---
    def open_multimeter_panel(self):
        if self.multimeter_panel:
            return
        panel = tk.Toplevel(self.root)
        panel.title("Multimeter")
        panel.resizable(False, False)
        self.multimeter_panel = panel

        tk.Label(panel, text="Function:", font=("Arial", 10, "bold")).pack(anchor="w", padx=8, pady=(8,0))
        self._multimeter_var = tk.StringVar(value=self.multimeter_type or "voltage")

        def set_fn():
            self.multimeter_type = self._multimeter_var.get()
            self.multimeter_points = []
            self.clear_probe_annotations()
            self.status.set(f"Multimeter: {self.multimeter_type}")

        for v, text in [("voltage","Voltage (V)"), ("current","Current (A)"), ("resistance","Resistance (Ω)")] :
            rb = tk.Radiobutton(panel, text=text, variable=self._multimeter_var, value=v, command=set_fn)
            rb.pack(anchor="w", padx=12)

        self.multimeter_reading_var = tk.StringVar(value="Reading: —")
        tk.Label(panel, textvariable=self.multimeter_reading_var, font=("Arial", 10, "bold")).pack(anchor="w", padx=8, pady=(6,4))
        tk.Button(panel, text="Clear Reading", command=self._clear_multimeter_reading).pack(pady=4, padx=8)
        tk.Button(panel, text="Close Multimeter", command=lambda: self.set_mode("select")).pack(pady=8, padx=8)
        try:
            x = self.root.winfo_rootx() + 10; y = self.root.winfo_rooty() + 60
            panel.geometry(f"+{x}+{y}")
        except: pass

    def _clear_multimeter_reading(self):
        if self.multimeter_reading_var:
            self.multimeter_reading_var.set("Reading: —")
        self.multimeter_points = []
        self.clear_probe_annotations()
        self.status.set("Multimeter: cleared.")

    def close_multimeter_panel(self):
        if self.multimeter_panel:
            try: self.multimeter_panel.destroy()
            except: pass
            self.multimeter_panel = None
            self.multimeter_type = None
            self._multimeter_var = None
            self.multimeter_reading_var = None
            self.multimeter_points = []

    def find_node_for_world_point(self, world_pt):
        best = None; bestd = self.SNAP_DIST*self.SNAP_DIST
        for n in self.nodes:
            d = dist2(world_pt, n.coord)
            if d < bestd:
                bestd = d; best = n
        return best

    def handle_multimeter_click_screen(self, sx, sy):
        wx, wy = self.screen_to_world(sx, sy)
        node = self.find_node_for_world_point((wx, wy))
        if node is None:
            term = self.find_nearest_terminal((wx, wy))
            if term is None:
                term = self.find_nearest_point_on_any_wire((wx, wy))
            if term is None:
                self.status.set("Multimeter: no nearby terminal.")
                return
            node = self.find_node_for_world_point(term)
            if node is None:
                self.status.set("Multimeter: no nearby node.")
                return
        self.multimeter_points.append(node)
        self.clear_probe_annotations()
        sx2, sy2 = self.world_to_screen(node.coord)
        aid = self.canvas.create_oval(sx2-6, sy2-6, sx2+6, sy2+6, outline="red", width=2)
        self.probe_annotations.append(aid)
        if len(self.multimeter_points) == 2:
            a_node = self.multimeter_points[0]; b_node = self.multimeter_points[1]
            self.rebuild_nodes()
            self.estimate_node_voltages_simple()
            reading = "—"
            if self.multimeter_type == "voltage":
                va = a_node.voltage; vb = b_node.voltage
                if va is not None and vb is not None:
                    reading = format_value(va - vb, "V")
                else:
                    vs = self.find_voltage_sources(); found = False
                    for n0,n1,v in vs:
                        if v is None: continue
                        if n0 == a_node.id and n1 == b_node.id:
                            reading = format_value(v, "V"); found = True; break
                        if n0 == b_node.id and n1 == a_node.id:
                            reading = format_value(-v, "V"); found = True; break
                    if not found: reading = "Unknown"
            elif self.multimeter_type == "resistance":
                r = self.shortest_resistance(a_node.id, b_node.id)
                reading = "Open" if r is None else format_value(r, "Ω")
            elif self.multimeter_type == "current":
                va = a_node.voltage; vb = b_node.voltage; dv = None
                if va is not None and vb is not None: dv = va - vb
                else:
                    vs = self.find_voltage_sources()
                    for n0,n1,v in vs:
                        if v is None: continue
                        if n0 == a_node.id and n1 == b_node.id: dv = v; break
                        if n0 == b_node.id and n1 == a_node.id: dv = -v; break
                if dv is None:
                    reading = "Unknown"
                else:
                    r = self.shortest_resistance(a_node.id, b_node.id)
                    if r is None or r == 0:
                        reading = "Open" if r is None else "Short"
                    else:
                        reading = format_value(dv / r, "A")
            if self.multimeter_reading_var:
                self.multimeter_reading_var.set(f"Reading: {reading}")
            self.status.set(f"Multimeter: {reading}")
            self.multimeter_points = []

    def clear_probe_annotations(self):
        for a in list(self.probe_annotations):
            try: self.canvas.delete(a)
            except: pass
        self.probe_annotations = []

    # --- rotation helpers ---
    @staticmethod
    def rotate_offset(ox, oy, angle_deg):
        a = math.radians(angle_deg); ca = math.cos(a); sa = math.sin(a)
        return (ox*ca - oy*sa, ox*sa + oy*ca)

    def rotated_point(self, sx, sy, px, py, angle_deg):
        ox, oy = px - sx, py - sy
        rx, ry = self.rotate_offset(ox, oy, angle_deg)
        return (sx + rx, sy + ry)

    def rotated_points(self, sx, sy, pts, angle_deg):
        return [self.rotated_point(sx, sy, px, py, angle_deg) for (px,py) in pts]

    def sample_arc(self, cx, cy, rx, ry, start_deg, extent_deg, steps=12):
        pts = []
        for i in range(steps+1):
            t = i/steps
            ang = math.radians(start_deg + extent_deg * t)
            x = cx + rx * math.cos(ang); y = cy + ry * math.sin(ang)
            pts.append((x,y))
        return pts

    # --- drawing helpers with rotation ---
    def draw_lines_rot(self, segments, sx, sy, angle_deg, **kwargs):
        ids = []
        for a,b in segments:
            pa = self.rotated_point(sx, sy, a[0], a[1], angle_deg)
            pb = self.rotated_point(sx, sy, b[0], b[1], angle_deg)
            ids.append(self.canvas.create_line(pa[0], pa[1], pb[0], pb[1], **kwargs))
        return ids

    def draw_polyline_rot(self, pts, sx, sy, angle_deg, **kwargs):
        rpts = self.rotated_points(sx, sy, pts, angle_deg)
        flat = []
        for x,y in rpts: flat.extend([x,y])
        return [self.canvas.create_line(*flat, **kwargs)]

    def draw_polygon_rot(self, pts, sx, sy, angle_deg, **kwargs):
        rpts = self.rotated_points(sx, sy, pts, angle_deg)
        flat = []
        for x,y in rpts: flat.extend([x,y])
        return [self.canvas.create_polygon(*flat, **kwargs)]

    def draw_oval_rot(self, cx, cy, rx, ry, sx, sy, angle_deg, **kwargs):
        corners = [(cx-rx, cy-ry), (cx+rx, cy-ry), (cx+rx, cy+ry), (cx-rx, cy+ry)]
        rc = [self.rotated_point(sx, sy, x, y, angle_deg) for (x,y) in corners]
        xs = [p[0] for p in rc]; ys = [p[1] for p in rc]
        return [self.canvas.create_oval(min(xs), min(ys), max(xs), max(ys), **kwargs)]

    def draw_arc_rot(self, cx, cy, rx, ry, start_deg, extent_deg, sx, sy, angle_deg, steps=12, **kwargs):
        pts = self.sample_arc(cx, cy, rx, ry, start_deg, extent_deg, steps=steps)
        rpts = [self.rotated_point(sx, sy, x, y, angle_deg) for (x,y) in pts]
        flat = []
        for x,y in rpts: flat.extend([x,y])
        return [self.canvas.create_line(*flat, **kwargs)]

    # --- symbol drawing (rotation-aware) ---
    def draw_resistor(self, c, sx, sy, color="black"):
        dx = 32 * self.scale
        pts = [(sx-dx,sy),(sx-dx*0.7,sy-8*self.scale),(sx-dx*0.4,sy+8*self.scale),(sx-dx*0.1,sy-8*self.scale),
               (sx+dx*0.1,sy+8*self.scale),(sx+dx*0.4,sy-8*self.scale),(sx+dx*0.7,sy+8*self.scale),(sx+dx,sy)]
        ids = []
        ids.extend(self.draw_lines_rot([((sx-dx-12*self.scale, sy),(sx-dx, sy))], sx, sy, c.angle, width=2, fill=color))
        ids.extend(self.draw_polyline_rot(pts, sx, sy, c.angle, width=2, fill=color))
        ids.extend(self.draw_lines_rot([((sx+dx, sy),(sx+dx+12*self.scale, sy))], sx, sy, c.angle, width=2, fill=color))
        return ids

    def draw_capacitor(self, c, sx, sy):
        dx = 20 * self.scale; ids = []
        segs = [((sx-dx-12*self.scale,sy),(sx-dx,sy)), ((sx-dx,sy),(sx-dx/2,sy)),
                ((sx+dx/2,sy),(sx+dx,sy)), ((sx+dx,sy),(sx+dx+12*self.scale,sy))]
        ids.extend(self.draw_lines_rot(segs, sx, sy, c.angle, width=2))
        p1 = (sx-dx/2, sy-20*self.scale); p2 = (sx-dx/2, sy+20*self.scale)
        p3 = (sx+dx/2, sy-20*self.scale); p4 = (sx+dx/2, sy+20*self.scale)
        ids.extend(self.draw_lines_rot([((p1[0],p1[1]),(p2[0],p2[1])), ((p3[0],p3[1]),(p4[0],p4[1]))], sx, sy, c.angle, width=2))
        return ids

    def draw_inductor(self, c, sx, sy):
        ids = []
        spacing = 10 * self.scale
        start = sx - 24*self.scale
        for i in range(5):
            cx = start + i*spacing*1.2
            ids.extend(self.draw_arc_rot(cx, sy, spacing/2, spacing/2, 0, 180, sx, sy, c.angle, steps=8, width=2))
        ids.extend(self.draw_lines_rot([((start-12*self.scale, sy),(start, sy)), ((start+5*spacing*1.2, sy),(start+5*spacing*1.2+12*self.scale, sy))], sx, sy, c.angle, width=2))
        return ids

    def draw_vsource(self, c, sx, sy):
        ids = []
        ids.extend(self.draw_lines_rot([((sx-36*self.scale, sy),(sx-12*self.scale, sy))], sx, sy, c.angle, width=2))
        ids.extend(self.draw_oval_rot(sx, sy, 12*self.scale, 12*self.scale, sx, sy, c.angle, outline="black", width=2))
        ids.extend(self.draw_lines_rot([((sx+12*self.scale, sy),(sx+36*self.scale, sy))], sx, sy, c.angle, width=2))
        ids.append(self.canvas.create_text(sx, sy-4*self.scale, text="+", font=("Arial", max(8,int(10*self.scale)))))
        ids.append(self.canvas.create_text(sx, sy+10*self.scale, text="-", font=("Arial", max(8,int(10*self.scale)))))
        return ids

    def draw_isource(self, c, sx, sy):
        ids = []
        ids.extend(self.draw_lines_rot([((sx-36*self.scale, sy),(sx-12*self.scale, sy))], sx, sy, c.angle, width=2))
        ids.extend(self.draw_oval_rot(sx, sy, 12*self.scale, 12*self.scale, sx, sy, c.angle, outline="black", width=2))
        p1 = (sx-4*self.scale, sy-6*self.scale); p2 = (sx+8*self.scale, sy); p3 = (sx-4*self.scale, sy+6*self.scale)
        ids.extend(self.draw_lines_rot([((p1[0],p1[1]),(p2[0],p2[1])), ((p2[0],p2[1]),(p3[0],p3[1]))], sx, sy, c.angle, width=2))
        ids.extend(self.draw_lines_rot([((sx+12*self.scale, sy),(sx+36*self.scale, sy))], sx, sy, c.angle, width=2))
        return ids

    def draw_diode(self, c, sx, sy):
        ids = []
        tri = [(sx-18*self.scale, sy-12*self.scale),(sx+6*self.scale, sy),(sx-18*self.scale, sy+12*self.scale)]
        ids.extend(self.draw_polygon_rot(tri, sx, sy, c.angle, outline="black", fill=""))
        ids.extend(self.draw_lines_rot([((sx+6*self.scale, sy-12*self.scale),(sx+6*self.scale, sy+12*self.scale))], sx, sy, c.angle, width=2))
        ids.extend(self.draw_lines_rot([((sx-36*self.scale, sy),(sx-18*self.scale, sy)), ((sx+6*self.scale, sy),(sx+36*self.scale, sy))], sx, sy, c.angle, width=2))
        return ids

    def draw_led(self, c, sx, sy):
        ids = self.draw_diode(c, sx, sy)
        ids.extend(self.draw_lines_rot([((sx+14*self.scale, sy-14*self.scale),(sx+22*self.scale, sy-22*self.scale)),
                                       ((sx+14*self.scale, sy+14*self.scale),(sx+22*self.scale, sy+22*self.scale))], sx, sy, c.angle, width=1, dash=(2,2)))
        return ids

    def draw_transistor_npnp(self, c, sx, sy, pnp=False):
        ids = []
        ids.extend(self.draw_oval_rot(sx, sy, 12*self.scale, 12*self.scale, sx, sy, c.angle, outline="black", width=2))
        ids.extend(self.draw_lines_rot([((sx-24*self.scale, sy),(sx-12*self.scale, sy)),
                                       ((sx+12*self.scale, sy-12*self.scale),(sx+24*self.scale, sy-24*self.scale)),
                                       ((sx+12*self.scale, sy+12*self.scale),(sx+24*self.scale, sy+24*self.scale))], sx, sy, c.angle, width=2))
        if pnp:
            ids.extend(self.draw_lines_rot([((sx+6*self.scale, sy+6*self.scale),(sx+12*self.scale, sy+12*self.scale))], sx, sy, c.angle, width=2))
            ids.extend(self.draw_lines_rot([((sx+12*self.scale, sy+12*self.scale),(sx+8*self.scale, sy+12*self.scale))], sx, sy, c.angle, width=2))
        else:
            ids.extend(self.draw_lines_rot([((sx+12*self.scale, sy+12*self.scale),(sx+6*self.scale, sy+6*self.scale))], sx, sy, c.angle, width=2))
            ids.extend(self.draw_lines_rot([((sx+8*self.scale, sy+12*self.scale),(sx+12*self.scale, sy+12*self.scale))], sx, sy, c.angle, width=2))
        return ids

    def draw_npn(self, c, sx, sy):
        return self.draw_transistor_npnp(c, sx, sy, pnp=False)

    def draw_pnp(self, c, sx, sy):
        return self.draw_transistor_npnp(c, sx, sy, pnp=True)

    def draw_mosfet(self, c, sx, sy):
        ids = []
        body_w = 24*self.scale; body_h = 20*self.scale
        ids.extend(self.draw_polygon_rot([(sx-body_w/2, sy-body_h/2),(sx+body_w/2, sy-body_h/2),(sx+body_w/2, sy+body_h/2),(sx-body_w/2, sy+body_h/2)], sx, sy, c.angle, outline="black", fill=""))
        ids.extend(self.draw_lines_rot([((sx-body_w/2-12*self.scale, sy),(sx-body_w/2, sy)),
                                       ((sx+body_w/2, sy-body_h/2-6*self.scale),(sx+body_w/2+12*self.scale, sy-body_h/2-6*self.scale)),
                                       ((sx+body_w/2, sy+body_h/2+6*self.scale),(sx+body_w/2+12*self.scale, sy+body_h/2+6*self.scale))], sx, sy, c.angle, width=2))
        ids.extend(self.draw_lines_rot([((sx-body_w/4, sy-body_h/4),(sx-body_w/4, sy+body_h/4))], sx, sy, c.angle, width=2))
        return ids

    def draw_ground(self, c, sx, sy):
        ids = []
        ids.extend(self.draw_lines_rot([((sx, sy),(sx, sy+6*self.scale))], sx, sy, c.angle, width=2))
        ids.append(self.canvas.create_line(sx-8*self.scale, sy+6*self.scale, sx+8*self.scale, sy+6*self.scale))
        ids.append(self.canvas.create_line(sx-5*self.scale, sy+9*self.scale, sx+5*self.scale, sy+9*self.scale))
        ids.append(self.canvas.create_line(sx-2*self.scale, sy+12*self.scale, sx+2*self.scale, sy+12*self.scale))
        return ids

    def draw_switch(self, c, sx, sy):
        ids = []
        ids.extend(self.draw_lines_rot([((sx-24*self.scale, sy),(sx-6*self.scale, sy))], sx, sy, c.angle, width=2))
        ids.append(self.canvas.create_oval(sx-6*self.scale-3, sy-3, sx-6*self.scale+3, sy+3, outline="black"))
        ids.extend(self.draw_lines_rot([((sx-6*self.scale, sy),(sx+18*self.scale, sy-12*self.scale))], sx, sy, c.angle, width=2))
        ids.extend(self.draw_lines_rot([((sx+18*self.scale, sy-12*self.scale),(sx+36*self.scale, sy-12*self.scale))], sx, sy, c.angle, width=2))
        return ids

    def draw_transformer(self, c, sx, sy):
        ids = []
        ids.extend(self.draw_lines_rot([((sx-36*self.scale, sy-12*self.scale),(sx-12*self.scale, sy-12*self.scale)),
                                       ((sx-36*self.scale, sy+12*self.scale),(sx-12*self.scale, sy+12*self.scale))], sx, sy, c.angle, width=2))
        ids.extend(self.draw_lines_rot([((sx+12*self.scale, sy-12*self.scale),(sx+36*self.scale, sy-12*self.scale)),
                                       ((sx+12*self.scale, sy+12*self.scale),(sx+36*self.scale, sy+12*self.scale))], sx, sy, c.angle, width=2))
        ids.extend(self.draw_lines_rot([((sx-6*self.scale, sy-20*self.scale),(sx-6*self.scale, sy+20*self.scale)),
                                       ((sx+6*self.scale, sy-20*self.scale),(sx+6*self.scale, sy+20*self.scale))], sx, sy, c.angle, width=2))
        return ids

    def draw_opamp(self, c, sx, sy):
        ids = []
        pts = [(sx-24*self.scale, sy-20*self.scale),(sx+24*self.scale, sy),(sx-24*self.scale, sy+20*self.scale)]
        ids.extend(self.draw_polygon_rot(pts, sx, sy, c.angle, outline="black", fill=""))
        ids.extend(self.draw_lines_rot([((sx-36*self.scale, sy-10*self.scale),(sx-24*self.scale, sy-10*self.scale)),
                                       ((sx-36*self.scale, sy+10*self.scale),(sx-24*self.scale, sy+10*self.scale)),
                                       ((sx+24*self.scale, sy),(sx+36*self.scale, sy))], sx, sy, c.angle, width=2))
        return ids

    # --- New helper: parse human-friendly values with suffixes ---
    def parse_value_with_unit(self, s):
        if s is None: return None
        if isinstance(s, (int, float)): return float(s)
        s = str(s).strip()
        if s == "": return None
        s = s.replace("µ", "u").replace("μ", "u")
        for ch in ["Ω", "ohm", "Ohm", "V", "v", "A", "a", "F", "H"]:
            s = s.replace(ch, "")
        s = s.strip()
        multipliers = {"g":1e9, "G":1e9, "M":1e6, "k":1e3, "K":1e3,
                       "m":1e-3, "u":1e-6, "n":1e-9, "p":1e-12}
        if len(s) > 0 and s[-1].isalpha():
            suf = s[-1]
            numpart = s[:-1]
            try:
                num = float(numpart)
                mul = multipliers.get(suf, 1.0)
                return num * mul
            except Exception:
                try:
                    return float(s)
                except Exception:
                    return None
        else:
            try:
                return float(s)
            except Exception:
                return None

    # --- Solve (Ohm's law) UI and logic (updated to show calculation steps and not replace resistor) ---
    def solve_circuit(self, silent=True):
        pre_v = pre_i = pre_r = None
        if self.selected and isinstance(self.selected, Component):
            val = self.selected.value
            unit = (self.selected.unit or "").strip()
            if self.selected.kind == "resistor":
                pre_r = self.parse_value_with_unit(val)
            else:
                if unit in ("V", "v"):
                    pre_v = self.parse_value_with_unit(val)
                elif unit in ("A", "a"):
                    pre_i = self.parse_value_with_unit(val)
                elif unit in ("Ω", "ohm", "Ohms"):
                    pre_r = self.parse_value_with_unit(val)

        dlg = tk.Toplevel(self.root)
        dlg.title("Solve Ohm's Law — enter two values")
        dlg.resizable(False, False)
        tk.Label(dlg, text="Enter any two values; leave the third blank. Units optional (k, M, m, u, n).").grid(row=0, column=0, columnspan=3, padx=8, pady=(8,4))

        tk.Label(dlg, text="Voltage (V):").grid(row=1, column=0, sticky="e", padx=6, pady=4)
        v_entry = tk.Entry(dlg, width=20); v_entry.grid(row=1, column=1, padx=6, pady=4)
        if pre_v is not None: v_entry.insert(0, str(pre_v))

        tk.Label(dlg, text="Current (A):").grid(row=2, column=0, sticky="e", padx=6, pady=4)
        i_entry = tk.Entry(dlg, width=20); i_entry.grid(row=2, column=1, padx=6, pady=4)
        if pre_i is not None: i_entry.insert(0, str(pre_i))

        tk.Label(dlg, text="Resistance (Ω):").grid(row=3, column=0, sticky="e", padx=6, pady=4)
        r_entry = tk.Entry(dlg, width=20); r_entry.grid(row=3, column=1, padx=6, pady=4)
        if pre_r is not None: r_entry.insert(0, str(pre_r))

        result_var = tk.StringVar(value="")
        tk.Label(dlg, textvariable=result_var, wraplength=360, justify="left").grid(row=4, column=0, columnspan=3, padx=8, pady=(6,4))

        def do_compute(auto=False):
            sv = v_entry.get().strip(); si = i_entry.get().strip(); sr = r_entry.get().strip()
            v = self.parse_value_with_unit(sv) if sv != "" else None
            i = self.parse_value_with_unit(si) if si != "" else None
            r = self.parse_value_with_unit(sr) if sr != "" else None
            provided = sum(1 for x in (v,i,r) if x is not None)
            if provided < 2:
                if auto and pre_r is not None and provided == 1:
                    result_var.set("Resistance known. Provide Voltage or Current to compute the other value.")
                else:
                    result_var.set("Please provide at least two numeric values (V, I, or R).")
                return
            try:
                calc_lines = []
                # compute missing value and show calculation steps
                if v is None and i is not None and r is not None:
                    v = i * r
                    calc_lines.append(f"V = I × R = {format_value(i,'A')} × {format_value(r,'Ω')} = {format_value(v,'V')}")
                elif i is None and v is not None and r is not None:
                    if r == 0:
                        result_var.set("Resistance is zero — current would be infinite (short)."); return
                    i = v / r
                    calc_lines.append(f"I = V / R = {format_value(v,'V')} / {format_value(r,'Ω')} = {format_value(i,'A')}")
                elif r is None and v is not None and i is not None:
                    if i == 0:
                        result_var.set("Current is zero — resistance would be infinite (open)."); return
                    r = v / i
                    calc_lines.append(f"R = V / I = {format_value(v,'V')} / {format_value(i,'A')} = {format_value(r,'Ω')}")
                else:
                    # all three provided or other combos: show consistency checks
                    if v is not None and i is not None and r is not None:
                        calc_lines.append("All three values provided; checking consistency:")
                        try:
                            check_r = v / i if i != 0 else None
                            calc_lines.append(f"Computed R from V/I = {format_value(check_r,'Ω') if check_r is not None else '∞'}; given R = {format_value(r,'Ω')}")
                        except Exception:
                            pass
                    else:
                        # fallback generic message
                        calc_lines.append("Computed values:")
                out_lines = []
                out_lines.append("Results:")
                out_lines.append(f"Voltage: {format_value(v, 'V') if v is not None else '—'}")
                out_lines.append(f"Current: {format_value(i, 'A') if i is not None else '—'}")
                out_lines.append(f"Resistance: {format_value(r, 'Ω') if r is not None else '—'}")
                if calc_lines:
                    out_lines.append("")
                    out_lines.append("Calculation:")
                    out_lines.extend(calc_lines)
                # If a resistor is selected, show the calculation but do NOT replace its value
                if self.selected and isinstance(self.selected, Component) and self.selected.kind == "resistor":
                    out_lines.append("")
                    out_lines.append(f"Note: Selected resistor '{self.selected.label}' was used for calculation but will not be modified.")
                result_var.set("\n".join(out_lines))
            except Exception as e:
                result_var.set(f"Error computing values: {e}")

        btn_frame = tk.Frame(dlg); btn_frame.grid(row=5, column=0, columnspan=3, pady=(6,8))
        tk.Button(btn_frame, text="Compute", command=lambda: do_compute(auto=False)).pack(side="left", padx=6)
        tk.Button(btn_frame, text="Close", command=dlg.destroy).pack(side="right", padx=6)

        # Auto-run logic: compute immediately when appropriate
        try:
            v_now = self.parse_value_with_unit(v_entry.get().strip()) if v_entry.get().strip() != "" else None
            i_now = self.parse_value_with_unit(i_entry.get().strip()) if i_entry.get().strip() != "" else None
            r_now = self.parse_value_with_unit(r_entry.get().strip()) if r_entry.get().strip() != "" else None
            provided_now = sum(1 for x in (v_now, i_now, r_now) if x is not None)
            if provided_now >= 2 or (pre_r is not None and (v_now is not None or i_now is not None)):
                self.root.after(50, lambda: do_compute(auto=True))
            else:
                if pre_r is not None and provided_now == 1:
                    result_var.set("Resistance known. Provide Voltage or Current to compute the other value.")
        except Exception:
            pass

        try:
            x = self.root.winfo_rootx() + 80; y = self.root.winfo_rooty() + 80
            dlg.geometry(f"+{x}+{y}")
        except Exception:
            pass

    # --- Core interactive behaviors implemented ---
    def finish_wire(self):
        # Validate wire_points before creating a Wire
        try:
            # Ensure all points are tuples of two floats
            clean_pts = []
            for p in self.wire_points:
                try:
                    x = float(p[0]); y = float(p[1])
                    clean_pts.append((x, y))
                except Exception:
                    continue
            if len(clean_pts) < 2:
                self.status.set("Wire: need at least two valid points.")
                self.wire_points = []; self.rubber_pos = None; self.redraw()
                return
            self.push_undo()
            w = Wire(clean_pts)
            # Only append wires that have at least two valid points
            if len(w.points) >= 2:
                self.wires.append(w)
                self.rebuild_nodes()
                self.status.set("Wire finished.")
            else:
                self.status.set("Wire: invalid points, nothing added.")
            self.wire_points = []; self.rubber_pos = None
            self.redraw()
        except Exception as e:
            # Defensive: don't crash on unexpected errors while finishing a wire
            print("Error finishing wire:", e)
            self.status.set("Error finishing wire; see console.")
            self.wire_points = []; self.rubber_pos = None
            self.redraw()

    def cancel_wire(self):
        self.wire_points = []; self.rubber_pos = None
        self.status.set("Wire cancelled.")
        self.redraw()

    def set_value_for_selected(self):
        if not self.selected or not isinstance(self.selected, Component):
            messagebox.showinfo("Set Value", "No component selected.")
            return
        cur = "" if self.selected.value is None else str(self.selected.value)
        ans = simpledialog.askstring("Set Value", f"Enter value for {self.selected.label} (units optional):", initialvalue=cur, parent=self.root)
        if ans is None: return
        val = self.parse_value_with_unit(ans)
        self.push_undo()
        if val is None:
            self.selected.value = ans
        else:
            self.selected.value = val
        self.redraw()
        self.status.set(f"Value set for {self.selected.label}.")

    def _prompt_value_for_component(self, comp):
        """
        Prompt the user for a value when a component is inserted.
        Returns True if a value was set (or left blank intentionally), False if user cancelled.
        """
        prompt = f"Enter value for {comp.label} ({comp.kind}). Units optional (k, M, m, u, n). Leave blank for unknown."
        initial = "" if comp.value is None else str(comp.value)
        ans = simpledialog.askstring("Component Value", prompt, initialvalue=initial, parent=self.root)
        if ans is None:
            # user cancelled the dialog; treat as cancel insertion
            return False
        val = self.parse_value_with_unit(ans)
        if val is None:
            # store raw string if parsing failed but user entered something non-empty
            comp.value = ans if ans.strip() != "" else None
        else:
            comp.value = val
        # set unit if common kinds
        if comp.kind == "resistor":
            comp.unit = "Ω"
        elif comp.kind == "vsource":
            comp.unit = "V"
        elif comp.kind == "isource":
            comp.unit = "A"
        return True

    def sum_series_selected(self):
        resistors = [c for c in self.multi_selected if isinstance(c, Component) and c.kind=="resistor"]
        if not resistors:
            messagebox.showinfo("Sum Series", "No resistors selected.")
            return
        total = 0.0; unknown = False
        lines = []
        for r in resistors:
            v = self.parse_value_with_unit(r.value)
            if v is None:
                unknown = True
                lines.append(f"{r.label}: unknown")
            else:
                total += v
                lines.append(f"{r.label}: {format_value(v,'Ω')}")
        # Build confirmation message
        msg_lines = ["You are about to sum the following resistors in series:"]
        msg_lines.extend(lines)
        msg_lines.append("")
        msg_lines.append(f"Computed series sum (numeric values only): {format_value(total,'Ω')}")
        if unknown:
            msg_lines.append("")
            msg_lines.append("Note: Some resistors have unknown values and were ignored in the numeric sum.")
        msg_lines.append("")
        msg_lines.append("Proceed with creating a single resistor with this value and removing the selected resistors?")
        confirm = messagebox.askyesno("Confirm Series Combine", "\n".join(msg_lines))
        if not confirm:
            self.status.set("Series combine cancelled.")
            return
        # Proceed with combine
        self.push_undo()
        avgx = sum(c.x for c in resistors)/len(resistors)
        avgy = sum(c.y for c in resistors)/len(resistors)
        new = Component("resistor", avgx, avgy, label="R_sum", value=total)
        self.components.append(new)
        for c in resistors:
            try: self.components.remove(c)
            except: pass
        self.multi_selected = []
        self.rebuild_nodes()
        self.redraw()
        self.status.set(f"Series sum created: {format_value(total,'Ω')}")

    def combine_parallel_selected(self):
        resistors = [c for c in self.multi_selected if isinstance(c, Component) and c.kind=="resistor"]
        if not resistors:
            messagebox.showinfo("Combine Parallel", "No resistors selected.")
            return
        inv_sum = 0.0; unknown = False; has_short = False
        lines = []
        for r in resistors:
            v = self.parse_value_with_unit(r.value)
            if v is None:
                unknown = True
                lines.append(f"{r.label}: unknown")
            else:
                lines.append(f"{r.label}: {format_value(v,'Ω')}")
                if v == 0:
                    has_short = True
                else:
                    inv_sum += 1.0 / v
        # Compute result (consider unknowns and shorts)
        if has_short:
            result = 0.0
            result_note = "At least one resistor is 0 Ω (short); combined result is 0 Ω."
        else:
            if inv_sum == 0:
                result = None
                result_note = "No numeric resistor values found to compute parallel combination."
            else:
                result = 1.0 / inv_sum
                result_note = ""
        # Build confirmation message
        msg_lines = ["You are about to combine the following resistors in parallel:"]
        msg_lines.extend(lines)
        msg_lines.append("")
        if result is None:
            msg_lines.append("Computed parallel result: (no numeric values)")
        else:
            msg_lines.append(f"Computed parallel result: {format_value(result,'Ω')}")
        if unknown:
            msg_lines.append("")
            msg_lines.append("Note: Some resistors have unknown values and were ignored in the numeric calculation.")
        if result_note:
            msg_lines.append("")
            msg_lines.append(result_note)
        msg_lines.append("")
        msg_lines.append("Proceed with creating a single resistor with this value and removing the selected resistors?")
        confirm = messagebox.askyesno("Confirm Parallel Combine", "\n".join(msg_lines))
        if not confirm:
            self.status.set("Parallel combine cancelled.")
            return
        # If result is None (no numeric values), abort
        if result is None:
            messagebox.showinfo("Combine Parallel", "No numeric resistor values found; nothing was combined.")
            self.status.set("Parallel combine aborted (no numeric values).")
            return
        # Proceed with combine
        self.push_undo()
        avgx = sum(c.x for c in resistors)/len(resistors)
        avgy = sum(c.y for c in resistors)/len(resistors)
        new = Component("resistor", avgx, avgy, label="R_par", value=result)
        self.components.append(new)
        for c in resistors:
            try: self.components.remove(c)
            except: pass
        self.multi_selected = []
        self.rebuild_nodes()
        self.redraw()
        self.status.set(f"Parallel combined: {format_value(result,'Ω')}")

    def clear_multi_selection(self):
        self.multi_selected = []
        self.status.set("Multi-selection cleared.")
        self.redraw()

    def open_settings(self):
        dlg = tk.Toplevel(self.root); dlg.title("Settings"); dlg.resizable(False, False)
        tk.Label(dlg, text="Grid spacing:").grid(row=0, column=0, sticky="e", padx=6, pady=4)
        g_entry = tk.Entry(dlg, width=10); g_entry.grid(row=0, column=1, padx=6, pady=4); g_entry.insert(0,str(self.GRID))
        tk.Label(dlg, text="Snap distance:").grid(row=1, column=0, sticky="e", padx=6, pady=4)
        s_entry = tk.Entry(dlg, width=10); s_entry.grid(row=1, column=1, padx=6, pady=4); s_entry.insert(0,str(self.SNAP_DIST))
        def apply_settings():
            try:
                self.GRID = float(g_entry.get()); self.SNAP_DIST = float(s_entry.get())
                self.status.set("Settings updated."); dlg.destroy(); self.redraw()
            except Exception as e:
                messagebox.showerror("Settings", f"Invalid values: {e}")
        tk.Button(dlg, text="Apply", command=apply_settings).grid(row=2, column=0, columnspan=2, pady=8)

    def save_circuit(self):
        path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON","*.json")])
        if not path: return
        data = {"components":[c.to_dict() for c in self.components], "wires":[w.to_dict() for w in self.wires]}
        try:
            with open(path,"w") as f: json.dump(data,f,indent=2)
            self.status.set(f"Saved to {os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    def load_circuit(self):
        path = filedialog.askopenfilename(filetypes=[("JSON","*.json")])
        if not path: return
        try:
            with open(path,"r") as f: data = json.load(f)
            self.push_undo()
            self.components = [Component.from_dict(d) for d in data.get("components",[])]
            self.wires = [Wire.from_dict(d) for d in data.get("wires",[])]
            self.rebuild_nodes()
            self.redraw()
            self.status.set(f"Loaded {os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Load Error", str(e))

    def clear_all(self):
        if not messagebox.askyesno("Clear", "Clear all components and wires?"):
            return
        self.push_undo()
        self.components = []; self.wires = []; self.nodes = []
        self.selected = None; self.multi_selected = []
        self.redraw()
        self.status.set("Cleared all.")

    # --- Canvas event handlers ---
    def on_left_click(self, e):
        sx, sy = e.x, e.y
        wx, wy = self.screen_to_world(sx, sy)
        if self.mode == "wire":
            x, y = self.snap_xy(wx, wy)
            # ensure we always append a tuple of floats
            try:
                self.wire_points.append((float(x), float(y)))
            except Exception:
                # ignore invalid point
                pass
            self.status.set(f"Wire: {len(self.wire_points)} points")
            self.redraw()
            return
        if self.mode == "erase":
            hit = self.find_component_near((wx,wy))
            if hit:
                self.push_undo(); self.components.remove(hit); self.rebuild_nodes(); self.redraw(); self.status.set("Component erased."); return
            w = self.find_wire_near((wx,wy))
            if w:
                self.push_undo(); self.wires.remove(w); self.rebuild_nodes(); self.redraw(); self.status.set("Wire erased."); return
            return
        if self.mode == "multimeter":
            self.handle_multimeter_click_screen(sx, sy); return

        # Probe mode: start region selection on left click
        if self.mode == "probe":
            # start region selection
            self.region_start = (wx, wy)
            self.region_rect_id = None
            self.region_results = []
            self.region_index = -1
            self.status.set("Probe: drag to select region, release to show results.")
            self.redraw()
            return

        hit = self.find_component_near((wx,wy))
        if hit:
            if e.state & 0x0001:  # Shift pressed
                if hit in self.multi_selected:
                    self.multi_selected.remove(hit)
                else:
                    self.multi_selected.append(hit)
                self.status.set(f"Multi-selected {len(self.multi_selected)}")
            else:
                self.selected = hit
                self.multi_selected = []
                self.drag_data = {"item":hit,"x":wx,"y":wy}
                self.status.set(f"Selected {hit.label}")
            self.redraw(); return
        if self.mode in ("resistor","capacitor","inductor","vsource","isource","diode","led","npn","pnp","mosfet","ground","switch","transformer","opamp"):
            x, y = self.snap_xy(wx, wy)
            try:
                x = float(x); y = float(y)
            except Exception:
                x, y = wx, wy
            # Create component but prompt for value before finalizing insertion.
            c = Component(self.mode, x, y, label=f"{self.mode[:3]}{len(self.components)+1}")
            # Prompt user for value; if user cancels, abort insertion.
            proceed = self._prompt_value_for_component(c)
            if not proceed:
                self.status.set("Component insertion cancelled.")
                return
            self.push_undo()
            self.components.append(c)
            self.rebuild_nodes()
            self.redraw()
            self.status.set(f"Placed {c.label}")
            return
        self.selected = None; self.multi_selected = []; self.redraw()

    def on_drag(self, e):
        sx, sy = e.x, e.y
        wx, wy = self.screen_to_world(sx, sy)
        if self.mode in ("move", "select") and self.drag_data.get("item"):
            item = self.drag_data["item"]
            dx = wx - self.drag_data["x"]; dy = wy - self.drag_data["y"]
            item.x += dx; item.y += dy
            self.drag_data["x"], self.drag_data["y"] = wx, wy
            self.rebuild_nodes()
            self.redraw()
            return
        if self.mode == "wire" and self.wire_points:
            # rubber_pos may be non-snapped; keep as floats
            try:
                self.rubber_pos = (float(wx), float(wy))
            except Exception:
                self.rubber_pos = None
            self.redraw()
            return

        # Probe dragging: update rubber rectangle
        if self.mode == "probe" and self.region_start:
            self.rubber_pos = (wx, wy)
            self.redraw()
            return

    def on_release(self, e):
        sx, sy = e.x, e.y
        wx, wy = self.screen_to_world(sx, sy)
        # If probe selection was active, finalize region
        if self.mode == "probe" and self.region_start:
            self.rubber_pos = (wx, wy)
            self._finalize_probe_region()
            return

        self.drag_data = {"item":None,"x":0,"y":0}
        self.rubber_pos = None
        self.redraw()

    def on_double_click(self, e):
        sx, sy = e.x, e.y
        wx, wy = self.screen_to_world(sx, sy)
        hit = self.find_component_near((wx,wy))
        if hit:
            self.selected = hit
            self.set_value_for_selected()
            return

    def on_right_click(self, e):
        sx, sy = e.x, e.y
        wx, wy = self.screen_to_world(sx, sy)
        hit = self.find_component_near((wx,wy))
        if hit:
            self.push_undo()
            hit.angle = (hit.angle + 90) % 360
            self.redraw()
            self.status.set(f"Rotated {hit.label}")

    def on_mouse_move(self, e):
        sx, sy = e.x, e.y
        wx, wy = self.screen_to_world(sx, sy)
        if self.mode == "probe" and self.region_start:
            self.rubber_pos = (wx, wy)
            self.redraw()

    def on_middle_down(self, e):
        self.panning = True
        self.pan_start = (e.x, e.y)
        self.pan_offset_start = (self.offset_x, self.offset_y)

    def on_middle_drag(self, e):
        if not self.panning: return
        dx = e.x - self.pan_start[0]; dy = e.y - self.pan_start[1]
        self.offset_x = self.pan_offset_start[0] + dx
        self.offset_y = self.pan_offset_start[1] + dy
        self.redraw()

    def on_middle_up(self, e):
        self.panning = False

    def on_mouse_wheel(self, e):
        factor = 1.0 + (0.1 if getattr(e, "delta", 0) > 0 else -0.1)
        if hasattr(e, "num") and e.num in (4,): factor = 1.1
        if hasattr(e, "num") and e.num in (5,): factor = 0.9
        self.zoom_at(e.x, e.y, factor)
        self.redraw()

    def toggle_grid(self, e=None):
        self.snap = not self.snap
        self.status.set(f"Grid snapping {'on' if self.snap else 'off'}")
        self.redraw()

    def rotate_selected(self, e=None):
        if self.selected:
            self.push_undo()
            self.selected.angle = (self.selected.angle + 90) % 360
            self.redraw()
            self.status.set(f"Rotated {self.selected.label}")

    def copy_selected(self, e=None):
        if not self.selected: return
        self.push_undo()
        c = self.selected
        new = Component(c.kind, c.x+20, c.y+20, angle=c.angle, label=c.label+"_copy", value=c.value, unit=c.unit)
        self.components.append(new)
        self.rebuild_nodes()
        self.redraw()
        self.status.set(f"Copied {c.label}")

    # --- Node reconstruction and simple analysis ---
    def rebuild_nodes(self):
        self.nodes = []
        pts = []
        for w in self.wires:
            # only include wires with valid points
            if not isinstance(w.points, (list, tuple)) or len(w.points) == 0:
                continue
            for p in w.points:
                if isinstance(p, (list, tuple)) and len(p) >= 2:
                    try:
                        pts.append((float(p[0]), float(p[1])))
                    except Exception:
                        continue
        for c in self.components:
            try:
                pts.append((c.x - 16, c.y))
                pts.append((c.x + 16, c.y))
            except Exception:
                continue
        clusters = []
        for p in pts:
            found = False
            for cl in clusters:
                if dist2(p, cl[0]) <= (self.CLUSTER_DIST*self.CLUSTER_DIST):
                    cl.append(p); found = True; break
            if not found:
                clusters.append([p])
        self.nodes = []
        for i,cl in enumerate(clusters):
            avgx = sum(p[0] for p in cl)/len(cl); avgy = sum(p[1] for p in cl)/len(cl)
            self.nodes.append(Node(i, (avgx,avgy)))
        for n in self.nodes:
            n.components = set(); n.wires = set()
        for c in self.components:
            t1 = (c.x - 16, c.y); t2 = (c.x + 16, c.y)
            n1 = self._find_node_index_for_point(t1); n2 = self._find_node_index_for_point(t2)
            c.nodes = [n1, n2]
            if n1 is not None and 0 <= n1 < len(self.nodes): self.nodes[n1].components.add(c)
            if n2 is not None and 0 <= n2 < len(self.nodes): self.nodes[n2].components.add(c)
        for w in self.wires:
            if not isinstance(w.points, (list, tuple)) or len(w.points) == 0:
                continue
            for p in (w.points[0], w.points[-1]):
                try:
                    ni = self._find_node_index_for_point((float(p[0]), float(p[1])))
                except Exception:
                    ni = None
                if ni is not None and 0 <= ni < len(self.nodes):
                    self.nodes[ni].wires.add(w)

    def _find_node_index_for_point(self, p):
        best = None; bestd = (self.SNAP_DIST*self.SNAP_DIST)
        for n in self.nodes:
            d = dist2(p, n.coord)
            if d < bestd:
                bestd = d; best = n.id
        return best

    def estimate_node_voltages_simple(self):
        for n in self.nodes: n.voltage = None
        for c in self.components:
            if c.kind == "vsource":
                v = self.parse_value_with_unit(c.value)
                if v is None: continue
                n0, n1 = c.nodes
                if n0 is not None and 0 <= n0 < len(self.nodes):
                    self.nodes[n0].voltage = v
                if n1 is not None and 0 <= n1 < len(self.nodes):
                    self.nodes[n1].voltage = 0.0

    def find_voltage_sources(self):
        vs = []
        for c in self.components:
            if c.kind == "vsource":
                v = self.parse_value_with_unit(c.value)
                n0, n1 = c.nodes
                vs.append((n0, n1, v))
        return vs

    def shortest_resistance(self, a, b):
        if a is None or b is None: return None
        graph = {}
        for n in self.nodes:
            graph[n.id] = []
        for c in self.components:
            if c.kind == "resistor":
                r = self.parse_value_with_unit(c.value)
                if r is None: continue
                n0, n1 = c.nodes
                if n0 is None or n1 is None: continue
                graph.setdefault(n0, []).append((n1, r))
                graph.setdefault(n1, []).append((n0, r))
        INF = float("inf")
        dist_map = {nid:INF for nid in graph}
        if a not in dist_map or b not in dist_map:
            return None
        dist_map[a] = 0.0
        pq = [(0.0, a)]
        while pq:
            d, u = heapq.heappop(pq)
            if d > dist_map[u]: continue
            if u == b: return d
            for v, w in graph.get(u, []):
                nd = d + w
                if nd < dist_map[v]:
                    dist_map[v] = nd
                    heapq.heappush(pq, (nd, v))
        return None if dist_map.get(b, INF) == INF else dist_map[b]

    def find_nearest_terminal(self, pt):
        best = None; bestd = self.SNAP_DIST*self.SNAP_DIST
        for c in self.components:
            t1 = (c.x - 16, c.y); t2 = (c.x + 16, c.y)
            for t in (t1, t2):
                d = dist2(pt, t)
                if d < bestd:
                    bestd = d; best = t
        return best

    def find_nearest_point_on_any_wire(self, pt):
        best = None; bestd = self.SNAP_DIST*self.SNAP_DIST
        for w in self.wires:
            if not isinstance(w.points, (list, tuple)) or len(w.points) < 2:
                continue
            for i in range(len(w.points)-1):
                try:
                    p = project_point_to_segment(pt, w.points[i], w.points[i+1])
                except Exception:
                    continue
                d = dist2(pt, p)
                if d < bestd:
                    bestd = d; best = p
        return best

    # --- Hit testing helpers ---
    def find_component_near(self, pt):
        best = None; bestd = (self.SNAP_DIST*self.SNAP_DIST)
        for c in self.components:
            d = dist2(pt, (c.x, c.y))
            if d < bestd:
                bestd = d; best = c
        return best

    def find_wire_near(self, pt):
        best = None; bestd = (self.SNAP_DIST*self.SNAP_DIST)
        for w in self.wires:
            if not isinstance(w.points, (list, tuple)) or len(w.points) < 2:
                continue
            for i in range(len(w.points)-1):
                try:
                    p = project_point_to_segment(pt, w.points[i], w.points[i+1])
                except Exception:
                    continue
                d = dist2(pt, p)
                if d < bestd:
                    bestd = d; best = w
        return best

    # --- Probe helpers (new/updated) ---
    def _finalize_probe_region(self):
        """Compute which components and wires intersect the region and show a panel."""
        try:
            if not self.region_start or not self.rubber_pos:
                self.region_start = None; self.rubber_pos = None; self.redraw(); return
            x0, y0 = self.region_start; x1, y1 = self.rubber_pos
            xmin, xmax = min(x0, x1), max(x0, x1)
            ymin, ymax = min(y0, y1), max(y0, y1)

            results = []
            # components whose center lies inside region
            for c in self.components:
                if xmin <= c.x <= xmax and ymin <= c.y <= ymax:
                    results.append(("comp", c))
            # wires that have any segment intersecting region or any point inside
            for w in self.wires:
                if not isinstance(w.points, (list, tuple)) or len(w.points) == 0:
                    continue
                hit = False
                for p in w.points:
                    try:
                        px, py = float(p[0]), float(p[1])
                    except Exception:
                        continue
                    if xmin <= px <= xmax and ymin <= py <= ymax:
                        hit = True; break
                if not hit:
                    # check segment intersection by sampling projection
                    for i in range(len(w.points)-1):
                        try:
                            a = w.points[i]; b = w.points[i+1]
                            proj = project_point_to_segment(((xmin+xmax)/2.0, (ymin+ymax)/2.0), a, b)
                            if xmin <= proj[0] <= xmax and ymin <= proj[1] <= ymax:
                                hit = True; break
                        except Exception:
                            continue
                if hit:
                    results.append(("wire", w))

            self.region_results = results
            self.region_index = -1
            self.region_start = None
            self.rubber_pos = None
            self.redraw()
            self._show_region_panel()
            self.status.set(f"Probe: {len(results)} items found.")
        except Exception as e:
            print("Probe finalize error:", e)
            self.status.set("Probe: error computing region; see console.")
            self.region_start = None; self.rubber_pos = None
            self.redraw()

    def _show_region_panel(self):
        """Create a small panel listing region results with interactions."""
        try:
            if self.region_panel:
                try: self.region_panel.destroy()
                except: pass
                self.region_panel = None
            panel = tk.Toplevel(self.root)
            panel.title("Probe Results")
            panel.geometry("+%d+%d" % (self.root.winfo_rootx()+80, self.root.winfo_rooty()+80))
            panel.resizable(False, False)
            self.region_panel = panel

            tk.Label(panel, text=f"Probe Results ({len(self.region_results)}):", font=("Arial", 10, "bold")).pack(anchor="w", padx=8, pady=(8,4))

            listbox = tk.Listbox(panel, width=60, height=12)
            listbox.pack(padx=8, pady=4)

            # map index to item
            self._region_list_map = []
            for typ, ref in self.region_results:
                if typ == "comp":
                    val = ref.value
                    valstr = format_value(val, ref.unit) if isinstance(val, (int, float)) else (str(val) if val is not None else "unknown")
                    line = f"Component: {ref.label} ({ref.kind}) — {valstr}"
                else:
                    # wire: show length in world units (approx)
                    length = 0.0
                    try:
                        for i in range(len(ref.points)-1):
                            a = ref.points[i]; b = ref.points[i+1]
                            length += dist((float(a[0]), float(a[1])), (float(b[0]), float(b[1])))
                        line = f"Wire: {len(ref.points)} pts — length {format_value(length,'')}"
                    except Exception:
                        line = f"Wire: {len(ref.points)} pts"
                listbox.insert("end", line)
                self._region_list_map.append((typ, ref))

            def on_double(evt):
                sel = listbox.curselection()
                if not sel: return
                idx = sel[0]
                typ, ref = self._region_list_map[idx]
                if typ == "comp":
                    self.selected = ref
                    self.multi_selected = []
                    self.redraw()
                    self.status.set(f"Selected {ref.label} from probe.")
                    try: panel.lift()
                    except: pass
                else:
                    # highlight wire by temporarily drawing overlay
                    try:
                        # draw overlay for wire
                        pts = []
                        for p in ref.points:
                            pts.append(self.world_to_screen((float(p[0]), float(p[1]))))
                        flat = []
                        for x,y in pts: flat.extend([x,y])
                        if len(flat) >= 4:
                            aid = self.canvas.create_line(*flat, fill="orange", width=4)
                            self.root.after(800, lambda: self.canvas.delete(aid))
                    except Exception:
                        pass

            listbox.bind("<Double-Button-1>", on_double)

            btn_frame = tk.Frame(panel)
            btn_frame.pack(fill="x", padx=8, pady=8)
            def select_all():
                self.multi_selected = [ref for typ,ref in self.region_results if typ=="comp"]
                self.selected = None
                self.redraw()
                self.status.set(f"Multi-selected {len(self.multi_selected)} from probe.")
            tk.Button(btn_frame, text="Select All Components", command=select_all).pack(side="left")
            tk.Button(btn_frame, text="Close", command=lambda: (self.region_panel and self.region_panel.destroy())).pack(side="right")
        except Exception as e:
            print("Probe panel error:", e)
            self.status.set("Probe: error showing results; see console.")

    def region_clear(self):
        self.region_start = None
        if self.region_rect_id:
            try: self.canvas.delete(self.region_rect_id)
            except: pass
            self.region_rect_id = None
        self.region_results = []
        self.region_index = -1
        if self.region_panel:
            try: self.region_panel.destroy()
            except: pass
            self.region_panel = None

    def cycle_region_results(self):
        if not self.region_results:
            self.status.set("No region results.")
            return
        self.region_index = (self.region_index + 1) % len(self.region_results)
        typ, ref = self.region_results[self.region_index]
        if typ == "comp":
            self.selected = ref; self.redraw(); self.status.set(f"Region select: {ref.label}")
        else:
            self.status.set("Region wire selected.")

    # --- Redraw everything ---
    def redraw(self):
        # Defensive redraw: wrap in try/except to avoid crashes from unexpected data
        try:
            self.canvas.delete("all")
            if self.snap:
                w = int(self.canvas.winfo_width() or self.CANVAS_W)
                h = int(self.canvas.winfo_height() or self.CANVAS_H)
                step = self.GRID * self.scale
                if step >= 6:
                    for x in range(0, w, max(1,int(step))):
                        self.canvas.create_line(x, 0, x, h, fill="#f7f7f7")
                    for y in range(0, h, max(1,int(step))):
                        self.canvas.create_line(0, y, w, y, fill="#f7f7f7")
            # draw wires (skip invalid wires)
            for w in self.wires:
                try:
                    if not isinstance(w.points, (list, tuple)) or len(w.points) < 2:
                        continue
                    pts = []
                    for p in w.points:
                        if not (isinstance(p, (list, tuple)) and len(p) >= 2):
                            continue
                        try:
                            pts.append(self.world_to_screen((float(p[0]), float(p[1]))))
                        except Exception:
                            continue
                    flat = []
                    for x,y in pts: flat.extend([x,y])
                    # only draw if we have at least two points (4 coords)
                    if len(flat) >= 4:
                        w.id_items = [self.canvas.create_line(*flat, fill="black", width=2)]
                except Exception:
                    # skip this wire if anything goes wrong
                    continue
            # rubber-band / current wire points
            if self.wire_points:
                pts = []
                for p in self.wire_points:
                    try:
                        pts.append(self.world_to_screen((float(p[0]), float(p[1]))))
                    except Exception:
                        continue
                if self.rubber_pos:
                    try:
                        pts.append(self.world_to_screen((float(self.rubber_pos[0]), float(self.rubber_pos[1]))))
                    except Exception:
                        pass
                flat = []
                for x,y in pts: flat.extend([x,y])
                if len(flat) >= 4:
                    self.canvas.create_line(*flat, fill="blue", dash=(4,2), width=2)
            # draw components
            for c in self.components:
                sx, sy = self.world_to_screen((c.x, c.y))
                ids = []
                kind = c.kind
                try:
                    if kind == "resistor":
                        ids = self.draw_resistor(c, sx, sy)
                    elif kind == "capacitor":
                        ids = self.draw_capacitor(c, sx, sy)
                    elif kind == "inductor":
                        ids = self.draw_inductor(c, sx, sy)
                    elif kind == "vsource":
                        ids = self.draw_vsource(c, sx, sy)
                    elif kind == "isource":
                        ids = self.draw_isource(c, sx, sy)
                    elif kind == "diode":
                        ids = self.draw_diode(c, sx, sy)
                    elif kind == "led":
                        ids = self.draw_led(c, sx, sy)
                    elif kind == "npn":
                        ids = self.draw_npn(c, sx, sy)
                    elif kind == "pnp":
                        ids = self.draw_pnp(c, sx, sy)
                    elif kind == "mosfet":
                        ids = self.draw_mosfet(c, sx, sy)
                    elif kind == "ground":
                        ids = self.draw_ground(c, sx, sy)
                    elif kind == "switch":
                        ids = self.draw_switch(c, sx, sy)
                    elif kind == "transformer":
                        ids = self.draw_transformer(c, sx, sy)
                    elif kind == "opamp":
                        ids = self.draw_opamp(c, sx, sy)
                    else:
                        ids = [self.canvas.create_rectangle(sx-12, sy-8, sx+12, sy+8, fill="#fff", outline="black")]
                except Exception:
                    ids = [self.canvas.create_rectangle(sx-12, sy-8, sx+12, sy+8, fill="#fff", outline="black")]
                lbl = f"{c.label}"
                if c.value is not None:
                    lbl += " " + (format_value(c.value, c.unit) if isinstance(c.value,(int,float)) else str(c.value))
                ids.append(self.canvas.create_text(sx, sy+20, text=lbl, font=("Arial", 9)))
                c.id_items = ids
                if c is self.selected or c in self.multi_selected:
                    self.canvas.create_rectangle(sx-20, sy-20, sx+20, sy+20, outline="red", dash=(3,2))
            # draw nodes
            for n in self.nodes:
                sx, sy = self.world_to_screen(n.coord)
                self.canvas.create_oval(sx-3, sy-3, sx+3, sy+3, fill="green")
                if n.voltage is not None:
                    self.canvas.create_text(sx+20, sy, text=format_value(n.voltage,"V"), anchor="w", font=("Arial",8))
            # draw probe rubber rectangle if active
            if self.mode == "probe" and self.region_start and self.rubber_pos:
                x0, y0 = self.world_to_screen(self.region_start)
                x1, y1 = self.world_to_screen(self.rubber_pos)
                self.canvas.create_rectangle(x0, y0, x1, y1, outline="blue", dash=(3,2))
            # status text
            self.canvas.create_text(10, 10, text=self.status.get(), anchor="nw", fill="#333", font=("Arial",9))
        except Exception as e:
            # Last-resort protection: print and show a short status but don't crash
            print("Redraw error:", e)
            self.status.set("Redraw error; see console.")

# Run the app
if __name__ == "__main__":
    root = tk.Tk()
    app = CircuitDesigner(root)
    root.mainloop()
