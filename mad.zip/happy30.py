#!/usr/bin/env python3
"""
Happiness Quote Generator — increased randomness

Key changes:
- When --seed is provided, selection is reproducible (deterministic RNG).
- When no --seed is provided, selection uses a secure SystemRandom shuffle so
  each run is different.
- Added optional --chaos to perform extra secure random swaps for more mixing.
- Selection shuffles the entire working pool (not just unseen subset) before picking.
- Small robustness improvements for seed handling.
"""

import argparse
import hashlib
import json
import os
import random
import secrets
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Set

STORE_PATH = Path("quotes.json")
SYS_RNG = secrets.SystemRandom()

DEFAULT_QUOTES: List[Dict[str, str]] = [
    {"text": "Happiness begins with a single grateful thought.", "category": "happiness"},
    {"text": "Choose joy in small moments and watch them multiply.", "category": "joy"},
    {"text": "A kind word is a tiny sunrise for someone else.", "category": "kindness"},
    {"text": "Gratitude makes ordinary days feel like gifts.", "category": "gratitude"},
    {"text": "Breathe deeply; the present is where peace lives.", "category": "mindfulness"},
    {"text": "Happiness grows when shared with another heart.", "category": "happiness"},
    {"text": "Celebrate progress, however small, and keep going.", "category": "resilience"},
    {"text": "Savor the simple: a cup, a laugh, a quiet street.", "category": "simplicity"},
    {"text": "Joy is a habit you can practice every morning.", "category": "joy"},
    {"text": "Kindness costs nothing and changes everything.", "category": "kindness"},
    {"text": "A grateful mind finds beauty in the ordinary.", "category": "gratitude"},
    {"text": "Let your smile be a small rebellion against gloom.", "category": "happiness"},
    {"text": "When you slow down, life reveals its treasures.", "category": "mindfulness"},
    {"text": "Courage is getting up and trying again with a softer heart.", "category": "resilience"},
    {"text": "Happiness is a practice, not a finish line.", "category": "happiness"},
    {"text": "Share a compliment; it echoes longer than you think.", "category": "kindness"},
    {"text": "Gratitude turns what you have into what you love.", "category": "gratitude"},
    {"text": "Find joy in the doing, not just the result.", "category": "joy"},
    {"text": "A calm breath can steady a stormy mind.", "category": "mindfulness"},
    {"text": "Small acts of care build a kinder world.", "category": "kindness"},
    {"text": "Resilience is a quiet muscle you strengthen daily.", "category": "resilience"},
    {"text": "Happiness often hides in the pause between tasks.", "category": "happiness"},
    {"text": "Collect moments, not things.", "category": "simplicity"},
    {"text": "Let gratitude be the soundtrack of your day.", "category": "gratitude"},
    {"text": "Joy is contagious; pass it on freely.", "category": "joy"},
    {"text": "Be present; the present is the only place to bloom.", "category": "mindfulness"},
    {"text": "A single kind gesture can rewrite someone's day.", "category": "kindness"},
    {"text": "When life bends you, practice gentle persistence.", "category": "resilience"},
    {"text": "Happiness is noticing the light in ordinary things.", "category": "happiness"},
    {"text": "Simplify to amplify what truly matters.", "category": "simplicity"},
    {"text": "Gratitude is the shortest path to contentment.", "category": "gratitude"},
    {"text": "Laugh loudly; it loosens the weight of the day.", "category": "joy"},
    {"text": "Mindfulness is listening to the world inside you.", "category": "mindfulness"},
    {"text": "Offer help without expectation; that's true kindness.", "category": "kindness"},
    {"text": "Rise after a fall with curiosity, not blame.", "category": "resilience"},
    {"text": "Happiness is a series of tiny, brave choices.", "category": "happiness"},
    {"text": "Clear space in your life for what feeds your soul.", "category": "simplicity"},
    {"text": "Gratitude waters the seeds of tomorrow's joy.", "category": "gratitude"},
    {"text": "Find a reason to smile before breakfast.", "category": "joy"},
    {"text": "Notice one good thing and let it grow inside you.", "category": "mindfulness"},
    {"text": "Kindness is the language everyone understands.", "category": "kindness"},
    {"text": "Strength is gentle when it knows its purpose.", "category": "resilience"},
    {"text": "Happiness is the art of appreciating small wins.", "category": "happiness"},
    {"text": "Live simply so others can simply live.", "category": "simplicity"},
    {"text": "Gratitude is a quiet revolution in the heart.", "category": "gratitude"},
    {"text": "Joy finds you when you stop chasing it.", "category": "joy"},
    {"text": "Be here now; the rest will follow.", "category": "mindfulness"},
    {"text": "A kind ear is sometimes the best medicine.", "category": "kindness"},
    {"text": "Resilience is patience in motion.", "category": "resilience"},
    {"text": "Happiness is choosing to see the good in today.", "category": "happiness"},
    {"text": "Simplicity clears the path to clarity.", "category": "simplicity"},
    {"text": "Gratitude turns scarcity into plenty.", "category": "gratitude"},
    {"text": "Let your joy be loud enough to wake your dreams.", "category": "joy"},
    {"text": "Mindfulness is the practice of returning home to yourself.", "category": "mindfulness"},
    {"text": "Kindness is a ripple that becomes a tide.", "category": "kindness"},
    {"text": "When you stumble, gather lessons, not shame.", "category": "resilience"},
    {"text": "Happiness is a warm habit of the heart.", "category": "happiness"},
    {"text": "Simplify your schedule to amplify your presence.", "category": "simplicity"},
    {"text": "Gratitude is the compass that points to joy.", "category": "gratitude"},
    {"text": "Celebrate small joys like they are festivals.", "category": "joy"},
    {"text": "Breathe in kindness, breathe out worry.", "category": "mindfulness"},
    {"text": "A single smile can start a chain reaction.", "category": "kindness"},
    {"text": "Resilience grows when you keep showing up for yourself.", "category": "resilience"},
    {"text": "Happiness is the echo of a life lived with care.", "category": "happiness"},
    {"text": "Less clutter, more room for wonder.", "category": "simplicity"},
    {"text": "Gratitude rewires the heart toward abundance.", "category": "gratitude"},
    {"text": "Joy is the soundtrack of a grateful life.", "category": "joy"},
    {"text": "Mindfulness turns routine into ritual.", "category": "mindfulness"},
    {"text": "Kindness is courage disguised as softness.", "category": "kindness"},
    {"text": "Stand up, try again, and be kinder to yourself.", "category": "resilience"},
    {"text": "Happiness is noticing how far you've come.", "category": "happiness"},
    {"text": "Simplicity is the luxury of clarity.", "category": "simplicity"},
    {"text": "Gratitude is a daily practice, not a one-time act.", "category": "gratitude"},
    {"text": "Let joy be the reason you get out of bed.", "category": "joy"},
    {"text": "Pay attention; life is whispering its gifts.", "category": "mindfulness"},
    {"text": "Kindness is the bridge between strangers.", "category": "kindness"},
    {"text": "Resilience is learning to bend without breaking.", "category": "resilience"},
    {"text": "Happiness is a light you can carry inside you.", "category": "happiness"},
    {"text": "Simplify decisions to free energy for living.", "category": "simplicity"},
    {"text": "Gratitude makes the ordinary feel sacred.", "category": "gratitude"},
    {"text": "Joy is found in wholehearted presence.", "category": "joy"},
    {"text": "Mindfulness is noticing the color of your breath.", "category": "mindfulness"},
    {"text": "A kind gesture is a seed of hope.", "category": "kindness"},
    {"text": "Resilience is patience wrapped in action.", "category": "resilience"},
    {"text": "Happiness is the quiet companion of contentment.", "category": "happiness"},
    {"text": "Simplicity invites space for what matters most.", "category": "simplicity"},
    {"text": "Gratitude is the lens that sharpens joy.", "category": "gratitude"},
    {"text": "Let your laughter be a daily ritual.", "category": "joy"},
    {"text": "Be mindful of the small miracles around you.", "category": "mindfulness"},
    {"text": "Kindness is the shortest route to connection.", "category": "kindness"},
    {"text": "Resilience is the art of gentle persistence.", "category": "resilience"},
    {"text": "Happiness is a habit of noticing good things.", "category": "happiness"},
    {"text": "Simplify to make room for wonder and rest.", "category": "simplicity"},
    {"text": "Gratitude is a quiet celebration of life.", "category": "gratitude"},
    {"text": "Joy grows when you share it without reason.", "category": "joy"},
    {"text": "Mindfulness is the practice of being kindly awake.", "category": "mindfulness"},
    {"text": "A small kindness can change a long day.", "category": "kindness"},
    {"text": "Resilience is rebuilding with a softer hand.", "category": "resilience"},
    {"text": "Happiness is the gentle echo of a grateful heart.", "category": "happiness"},
    {"text": "Simplicity is choosing what to keep and what to let go.", "category": "simplicity"},
    {"text": "Gratitude is the quiet fuel for a joyful life.", "category": "gratitude"},
    {"text": "Let joy be your compass, not your destination.", "category": "joy"},
    {"text": "Mindfulness turns ordinary moments into anchors.", "category": "mindfulness"},
    {"text": "Kindness is a habit that makes the world softer.", "category": "kindness"},
    {"text": "Resilience is the steady return to hope.", "category": "resilience"},
    {"text": "Happiness is a choice to notice the light.", "category": "happiness"},
    {"text": "Simplify your day; amplify your presence.", "category": "simplicity"},
    {"text": "Gratitude is the practice of saying yes to life.", "category": "gratitude"},
    {"text": "Joy is the echo of a life lived with love.", "category": "joy"},
    {"text": "Mindfulness is the gentle art of paying attention.", "category": "mindfulness"},
    {"text": "Kindness is the quiet revolution that heals.", "category": "kindness"},
    {"text": "Resilience is the courage to begin again kindly.", "category": "resilience"},
    {"text": "Happiness is noticing the small mercies of the day.", "category": "happiness"},
    {"text": "Simplicity frees the mind to wander and wonder.", "category": "simplicity"},
    {"text": "Gratitude is the shortest bridge to joy.", "category": "gratitude"},
    {"text": "Joy is a small fire you can kindle daily.", "category": "joy"},
    {"text": "Mindfulness is the practice of returning home to your senses.", "category": "mindfulness"},
    {"text": "Kindness is the currency that never devalues.", "category": "kindness"},
    {"text": "Resilience is the quiet faith that keeps you moving.", "category": "resilience"},
    {"text": "Happiness is a warm corner of your day.", "category": "happiness"},
    {"text": "Simplify to make room for what you love.", "category": "simplicity"},
    {"text": "Gratitude is noticing the good and saying thank you.", "category": "gratitude"},
    {"text": "Joy is the small rebellion against a hurried life.", "category": "joy"},
    {"text": "Mindfulness is noticing the space between stimulus and response.", "category": "mindfulness"},
    {"text": "Kindness is the shortest path to belonging.", "category": "kindness"},
    {"text": "Resilience is the practice of showing up again.", "category": "resilience"},
    {"text": "Happiness is a soft place to land after a hard day.", "category": "happiness"},
    {"text": "Simplicity is the art of subtracting the unnecessary.", "category": "simplicity"},
    {"text": "Gratitude is the quiet applause of the heart.", "category": "gratitude"},
    {"text": "Joy is the lightness that comes from being present.", "category": "joy"},
    {"text": "Mindfulness is the habit of noticing what matters.", "category": "mindfulness"},
    {"text": "Kindness is the practice of seeing another's worth.", "category": "kindness"},
    {"text": "Resilience is the steady work of small recoveries.", "category": "resilience"},
    {"text": "Happiness is a collection of tiny mercies.", "category": "happiness"},
    {"text": "Simplify your commitments to deepen your life.", "category": "simplicity"},
    {"text": "Gratitude is the gentle art of appreciation.", "category": "gratitude"},
    {"text": "Joy is the reward for paying attention to good things.", "category": "joy"},
    {"text": "Mindfulness is the practice of being kindly curious.", "category": "mindfulness"},
    {"text": "Kindness is the quiet work that changes the world.", "category": "kindness"},
    {"text": "Resilience is the habit of finding a way forward.", "category": "resilience"},
    {"text": "Happiness is the small yes you give to life.", "category": "happiness"},
    {"text": "Simplicity is the clarity that follows a clean desk.", "category": "simplicity"},
    {"text": "Gratitude is the daily practice of noticing gifts.", "category": "gratitude"},
    {"text": "Joy is the echo of a generous heart.", "category": "joy"},
    {"text": "Mindfulness is the practice of listening to now.", "category": "mindfulness"},
    {"text": "Kindness is the habit of offering warmth without asking why.", "category": "kindness"},
    {"text": "Resilience is the quiet rebuilding after the storm.", "category": "resilience"},
    {"text": "Happiness is the soft glow of contentment.", "category": "happiness"},
    {"text": "Simplicity is the space where creativity breathes.", "category": "simplicity"},
    {"text": "Gratitude is the small light that brightens days.", "category": "gratitude"},
    {"text": "Joy is the small celebration of being alive.", "category": "joy"},
    {"text": "Mindfulness is the practice of noticing without judging.", "category": "mindfulness"},
    {"text": "Kindness is the gentle courage of the heart.", "category": "kindness"},
    {"text": "Resilience is the steady heartbeat of recovery.", "category": "resilience"},
    {"text": "Happiness is the quiet contentment of a well-lived day.", "category": "happiness"},
    {"text": "Simplicity is the gift of fewer choices and more focus.", "category": "simplicity"},
    {"text": "Gratitude is the habit that turns noise into music.", "category": "gratitude"},
    {"text": "Joy is the small sun that warms ordinary moments.", "category": "joy"},
    {"text": "Mindfulness is the practice of returning to your breath.", "category": "mindfulness"},
    {"text": "Kindness is the steady hand that steadies others.", "category": "kindness"},
    {"text": "Resilience is the quiet confidence to try again tomorrow.", "category": "resilience"},
    {"text": "Happiness is the gentle companion of gratitude.", "category": "happiness"},
    {"text": "Simplicity is the clarity that lets your priorities shine.", "category": "simplicity"},
    {"text": "Gratitude is the small ritual that changes perspective.", "category": "gratitude"},
    {"text": "Joy is the small bell that rings inside you.", "category": "joy"},
    {"text": "Mindfulness is the practice of noticing the present with kindness.", "category": "mindfulness"},
    {"text": "Kindness is the quiet revolution that softens hard days.", "category": "kindness"},
    {"text": "Resilience is the patient work of rebuilding trust in yourself.", "category": "resilience"},
    {"text": "Happiness is the soft echo of a life lived with care.", "category": "happiness"},
    {"text": "Simplicity is the art of keeping what matters and letting go of the rest.", "category": "simplicity"},
    {"text": "Gratitude is the steady light that guides small choices.", "category": "gratitude"},
    {"text": "Joy is the small, persistent yes inside you.", "category": "joy"},
    {"text": "Mindfulness is the practice of being gently awake to life.", "category": "mindfulness"},
    {"text": "Kindness is the habit of noticing and acting on small needs.", "category": "kindness"},
    {"text": "Resilience is the quiet courage to continue after setbacks.", "category": "resilience"},
    {"text": "Happiness is the soft warmth of a grateful heart.", "category": "happiness"},
    {"text": "Simplicity is the freedom to choose what nourishes you.", "category": "simplicity"},
    {"text": "Gratitude is the daily practice that grows contentment.", "category": "gratitude"},
    {"text": "Joy is the small light you carry into the day.", "category": "joy"},
    {"text": "Mindfulness is the practice of returning to what matters.", "category": "mindfulness"},
    {"text": "Kindness is the quiet courage to be gentle in a harsh world.", "category": "kindness"},
    {"text": "Resilience is the steady practice of getting up again.", "category": "resilience"},
    {"text": "Happiness is the gentle reward of living with intention.", "category": "happiness"},
    {"text": "Simplicity is the clarity that lets your heart breathe.", "category": "simplicity"},
    {"text": "Gratitude is the small habit that changes everything.", "category": "gratitude"},
    {"text": "Joy is the small celebration of ordinary life.", "category": "joy"},
    {"text": "Mindfulness is the practice of noticing the good in the small.", "category": "mindfulness"},
    {"text": "Kindness is the quiet force that heals small wounds.", "category": "kindness"},
    {"text": "Resilience is the steady faith that tomorrow can be better.", "category": "resilience"},
    {"text": "Happiness is the soft glow of a life lived with care.", "category": "happiness"},
    {"text": "Simplicity is the space where your best work happens.", "category": "simplicity"},
    {"text": "Gratitude is the daily lens that sharpens joy.", "category": "gratitude"},
    {"text": "Joy is the small bell that rings when you notice beauty.", "category": "joy"},
    {"text": "Mindfulness is the practice of being present with kindness.", "category": "mindfulness"},
    {"text": "Kindness is the steady practice of seeing another's humanity.", "category": "kindness"},
    {"text": "Resilience is the quiet strength of continuing with hope.", "category": "resilience"},
]

# -------------------------
# Storage helpers
# -------------------------
def load_store() -> List[Dict[str, str]]:
    if STORE_PATH.exists():
        try:
            with STORE_PATH.open("r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except Exception:
            pass
    save_store(DEFAULT_QUOTES)
    return DEFAULT_QUOTES.copy()


def save_store(quotes: List[Dict[str, str]]) -> None:
    try:
        with STORE_PATH.open("w", encoding="utf-8") as f:
            json.dump(quotes, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Error saving store: {e}", file=sys.stderr)


def add_quote(text: str, category: str, quotes: List[Dict[str, str]]) -> None:
    entry = {"text": text.strip(), "category": category.strip().lower()}
    quotes.append(entry)
    save_store(quotes)


# -------------------------
# Seed helpers (robust)
# -------------------------
def seed_from_words(seed_words: Optional[str]) -> int:
    if seed_words is None:
        seed_words = ""
    if not isinstance(seed_words, str):
        seed_words = str(seed_words)
    h = hashlib.sha256(seed_words.encode("utf-8", errors="surrogatepass")).digest()
    return int.from_bytes(h[:8], "big")


# -------------------------
# Secure shuffle helper
# -------------------------
def secure_shuffle_inplace(seq: List, rng: Optional[random.Random] = None) -> None:
    """
    Shuffle in place. If rng is a random.Random instance, use its shuffle (deterministic).
    Otherwise use SystemRandom for secure non-deterministic shuffling.
    """
    if isinstance(rng, random.Random):
        rng.shuffle(seq)
        return

    # secure shuffle using SYS_RNG
    n = len(seq)
    for i in range(n - 1, 0, -1):
        j = SYS_RNG.randrange(i + 1)
        seq[i], seq[j] = seq[j], seq[i]


# -------------------------
# Selection (more random)
# -------------------------
def pick_quotes(
    quotes: List[Dict[str, str]],
    count: int = 1,
    category: Optional[str] = None,
    rng: Optional[random.Random] = None,
    session_seen: Optional[Set[str]] = None,
    chaos: int = 0,
) -> List[Dict[str, str]]:
    """
    - Uses provided rng (random.Random) for deterministic runs when seed is given.
    - Uses secure SystemRandom when rng is None.
    - Shuffles the entire working pool before selecting.
    - Applies extra secure random swaps controlled by chaos (0..50).
    """
    pool = [q for q in quotes if (category is None or q.get("category", "").lower() == category.lower())]
    if not pool:
        return []

    session_seen = session_seen or set()
    # unseen relative to this pool
    unseen = [q for q in pool if q.get("text", "") not in session_seen]

    # if unseen empty, clear only this pool's seen items so pool becomes available again
    if not unseen:
        pool_texts = {q.get("text", "") for q in pool}
        session_seen -= pool_texts
        unseen = list(pool)

    working = list(unseen)

    # shuffle entire working pool
    secure_shuffle_inplace(working, rng=rng)

    # extra chaotic secure swaps (always use SYS_RNG for chaos to increase unpredictability)
    chaos = max(0, min(50, int(chaos or 0)))
    n = len(working)
    for _ in range(chaos):
        if n < 2:
            break
        a = SYS_RNG.randrange(n)
        b = SYS_RNG.randrange(n)
        if a != b:
            working[a], working[b] = working[b], working[a]

    selected: List[Dict[str, str]] = []
    if len(working) >= count:
        selected = working[:count]
    else:
        selected.extend(working)
        remaining = count - len(selected)
        # fill remaining from pool (allow repeats if necessary)
        remaining_pool = [q for q in pool if q not in selected]
        if remaining_pool:
            secure_shuffle_inplace(remaining_pool, rng=rng)
            take = min(len(remaining_pool), remaining)
            selected.extend(remaining_pool[:take])
            remaining -= take
        for _ in range(remaining):
            if not pool:
                break
            idx = SYS_RNG.randrange(len(pool)) if rng is None else rng.randrange(len(pool))
            selected.append(pool[idx])

    return selected


# -------------------------
# Formatting & TTS
# -------------------------
def format_quote(q: Dict[str, str], index: Optional[int] = None) -> str:
    idx = f"{index}. " if index is not None else ""
    text = q.get("text", "")
    cat = q.get("category", "").capitalize()
    return f"{idx}{text} — {cat}"


def _run_command(cmd: List[str]) -> bool:
    try:
        subprocess.run(cmd, check=True)
        return True
    except Exception:
        return False


def speak_mac(text: str) -> bool:
    if shutil.which("say"):
        return _run_command(["say", text])
    return False


def speak_windows_powershell(text: str) -> bool:
    ps = (
        "Add-Type -AssemblyName System.speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        "$s.Speak([Console]::In.ReadToEnd());"
    )
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            input=text,
            text=True,
            check=True,
        )
        return proc.returncode == 0
    except Exception:
        return False


def speak_linux(text: str) -> bool:
    if shutil.which("espeak"):
        return _run_command(["espeak", text])
    if shutil.which("spd-say"):
        return _run_command(["spd-say", text])
    if shutil.which("festival"):
        try:
            proc = subprocess.run(["festival", "--tts"], input=text, text=True, check=True)
            return proc.returncode == 0
        except Exception:
            return False
    return False


def speak(text: str) -> bool:
    if not text:
        return False
    platform = sys.platform
    if platform == "darwin":
        return speak_mac(text)
    if platform.startswith("win"):
        return speak_windows_powershell(text)
    return speak_linux(text)


# -------------------------
# Program flow
# -------------------------
def run_once(quotes_store: List[Dict[str, str]], args, session_seen: Set[str], rng: Optional[random.Random]) -> Optional[str]:
    selected = pick_quotes(
        quotes_store,
        count=max(1, args.count),
        category=args.category,
        rng=rng,
        session_seen=session_seen,
        chaos=getattr(args, "chaos", 0),
    )
    if not selected:
        print("No quotes found for that category.", file=sys.stderr)
        return None

    for q in selected:
        session_seen.add(q.get("text", ""))

    lines = [format_quote(q, i + 1 if args.count > 1 else None) for i, q in enumerate(selected)]
    output = "\n".join(lines)
    print(output)

    if args.tts:
        speak_text = " ".join(q.get("text", "") for q in selected)
        ok = speak(speak_text)
        if not ok:
            print("(TTS not available on this system or required command not found.)", file=sys.stderr)

    if args.save:
        try:
            with open(args.save, "w", encoding="utf-8") as f:
                f.write(output + "\n")
            print(f"Saved to {args.save}")
        except Exception as e:
            print(f"Error saving file: {e}", file=sys.stderr)

    if args.export:
        try:
            with open(args.export, "w", encoding="utf-8") as f:
                json.dump(selected, f, ensure_ascii=False, indent=2)
            print(f"Exported JSON to {args.export}")
        except Exception as e:
            print(f"Error exporting JSON: {e}", file=sys.stderr)

    return output


def prompt_repeat_or_quit() -> bool:
    if not sys.stdin.isatty():
        return False
    try:
        while True:
            choice = input("\nType 'r' to repeat or 'q' to quit (Enter repeats): ").strip().lower()
            if choice == "" or choice == "r" or choice == "repeat":
                return True
            if choice in ("q", "quit"):
                return False
            print("Please type 'r' to repeat or 'q' to quit.")
    except (EOFError, KeyboardInterrupt):
        print("\nGoodbye.")
        return False


def main(argv=None):
    parser = argparse.ArgumentParser(description="Happiness Quote Generator — more random")
    parser.add_argument("--count", "-n", type=int, default=1, help="Number of quotes to print")
    parser.add_argument("--category", "-c", type=str, help="Category to filter by")
    parser.add_argument("--save", "-s", type=str, help="Save output to a file (text).")
    parser.add_argument("--export", "-e", type=str, help="Export selected quotes to JSON file.")
    parser.add_argument("--add", "-a", type=str, help='Add a new quote in the format "quote text|category"')
    parser.add_argument("--seed", type=str, help="Seed passphrase (words). Use a phrase to reproduce runs.")
    parser.add_argument("--chaos", type=int, default=0, help="Extra secure random swaps (0-50) to increase mixing.")
    parser.add_argument("--list-categories", action="store_true", help="List available categories")
    parser.add_argument("--tts", dest="tts", action="store_true", help="Speak the quote using system TTS")
    parser.add_argument("--no-tts", dest="tts", action="store_false", help="Disable TTS")
    parser.set_defaults(tts=True)
    args = parser.parse_args(argv)

    quotes = load_store()

    if args.list_categories:
        cats = sorted({q.get("category", "").lower() for q in quotes})
        print("Available categories:", ", ".join(cats))
        return

    if args.add:
        try:
            text, cat = args.add.split("|", 1)
        except ValueError:
            print("To add a quote use the format: \"quote text|category\"", file=sys.stderr)
            return
        add_quote(text, cat, quotes)
        print("Quote added.")
        return

    # Determine RNG: deterministic if seed provided, otherwise use secure randomness (rng=None)
    rng: Optional[random.Random] = None
    if args.seed is not None:
        try:
            run_seed_int = seed_from_words(args.seed)
            rng = random.Random(run_seed_int)
            print(f"(Using seed passphrase: '{args.seed}' -> numeric seed: {run_seed_int})")
        except Exception:
            rng = None
    else:
        # no seed -> rng stays None and secure shuffling will be used
        rng = None

    session_seen: Set[str] = set()

    while True:
        if args.category:
            pool_texts = {q.get("text", "") for q in quotes if q.get("category", "").lower() == args.category.lower()}
            if pool_texts and pool_texts.issubset(session_seen):
                session_seen -= pool_texts

        result = run_once(quotes, args, session_seen, rng)
        if result is None:
            return
        if not prompt_repeat_or_quit():
            print("Goodbye.")
            return


if __name__ == "__main__":
    main()
