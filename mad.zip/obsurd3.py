#!/usr/bin/env python3
"""
Absurd Random Quote Generator with simple TTS (no pip required).
TTS is enabled by default. Use --no-tts to disable.
"""

import json
import random
import argparse
import subprocess
import sys
import shutil
from pathlib import Path

DEFAULT_QUOTES = [
    "The moon borrowed my umbrella and never returned it.",
    "If socks could talk they'd unionize.",
    "I once taught a cactus to whistle; it still owes me rent.",
    "Time is just a suggestion wrapped in a paper hat.",
    "Never trust a pancake that smiles back.",
    "The chair insisted on a vacation and left a note.",
    "I put my thoughts in a blender and called it modern art.",
    "When the toaster sings, the spoons applaud.",
    "Reality took a day off; I filled in as understudy.",
    "Absurdity is just logic wearing a clown nose.",
    "My coffee filed a complaint about being too hot for its job.",
    "The bookshelf organized itself by mood swings.",
    "I mailed a postcard to yesterday and it never arrived.",
    "The cat negotiated a treaty with the houseplants.",
    "Clouds are just sky pillows with commitment issues.",
    "I found a map to my missing left sock; it was in Narnia.",
    "The alarm clock is training for a marathon at dawn.",
    "I asked the mirror for advice and it recommended sunglasses.",
    "The refrigerator hums lullabies to the leftovers.",
    "A single grape once ran for mayor of my lunchbox.",
    "My shadow took a sabbatical and left a forwarding address.",
    "The lamp prefers to work nights and write poetry.",
    "I taught my shoes to tango; now they refuse to walk straight.",
    "The calendar keeps skipping Tuesdays to avoid responsibility.",
    "I once traded a secret for a paperclip and regretted nothing.",
    "The elevator only goes sideways on Thursdays.",
    "My pen is on strike until it gets better metaphors.",
    "The spoon is convinced it's a tiny canoe.",
    "I planted a thought and harvested a small parade.",
    "The mailbox practices interpretive dance at noon.",
    "My pillow has a PhD in dream engineering.",
    "The kettle writes letters to the teapot in invisible ink.",
    "I hired a cloud to babysit my ideas; it rained confetti.",
    "The bicycle keeps asking for directions to the moon.",
    "My socks eloped with a pair of mittens last winter.",
    "The wallpaper is secretly composing an opera.",
    "I keep a tiny orchestra in my pocket for emergencies.",
    "The toaster refuses to toast anything that judges it.",
    "My keys formed a band and only play in minor keys.",
    "The moonlight left a tip under the doormat.",
    "I once negotiated peace between two arguing teaspoons.",
    "The clock is learning to speak whale.",
    "My umbrella moonlights as a small, disgruntled hat.",
    "The staircase prefers to be called 'vertical boulevard.'",
    "I taught my reflection to wink; now it flirts with strangers.",
    "The cactus writes postcards from the desert of forgotten ideas.",
    "My coffee mug is writing a memoir titled 'Warmth and Regret.'",
    "The toaster dreams of becoming a lighthouse.",
    "I keep a tiny library of lost excuses under the bed.",
    "The curtains applaud when the wind tells a good joke.",
    "My socks are filing for emancipation from the dryer.",
    "The spoon is lobbying for better soup representation.",
    "I once found a conspiracy of paperclips plotting a paper revolution.",
    "The moon is learning to knit sweaters for shy stars.",
    "My shoes keep a scrapbook of places they've refused to go.",
    "The refrigerator is an undercover philosopher.",
    "I taught my shadow to read; now it critiques my outfits.",
    "The teapot practices stand-up comedy between whistles.",
    "My thoughts are on backorder; expected delivery: someday.",
    "The mailbox is a portal for letters that forgot their purpose.",
    "I traded a yawn for a small, polite thunderstorm.",
    "The lamp collects secrets and returns them as warm light.",
    "My pillow hosts a nightly symposium on improbable dreams.",
    "The chair is writing a novel about upright living.",
    "I once found a tiny city of lost buttons under the couch.",
    "The calendar is learning to juggle holidays.",
    "My pen refuses to write anything that isn't slightly ridiculous.",
    "The kettle practices Morse code with steam.",
    "I keep a passport for my imagination; it's stamped in glitter.",
    "The clock is learning to tell stories instead of time.",
    "My socks are unionizing for better drawer conditions.",
    "The spoon is convinced it's a tiny spaceship.",
    "I once taught a teacup to whistle; it joined a brass band.",
    "The wallpaper hums old lullabies to the paint.",
    "My shoes are writing postcards from the places they won't go.",
    "The moon left a voicemail for the sun and never got a reply.",
    "I keep a small museum of almost-ideas in the attic.",
    "The toaster is secretly an abstract expressionist.",
    "My shadow is learning to salsa on rainy days.",
    "The mailbox practices calligraphy with invisible ink.",
    "I once found a committee of lost socks debating philosophy.",
    "The lamp prefers to be addressed as 'Your Brightness.'",
    "My coffee is writing a thesis on existential mornings.",
    "The curtains are rehearsing for a dramatic exit.",
    "I taught my spoon to tell fortunes; it predicts soup.",
    "The clock is on a diet of slow afternoons.",
    "My pillow writes postcards to the moon about my dreams.",
    "The chair is taking night classes in dignity.",
    "I keep a tiny orchestra of mismatched instruments in the closet.",
    "The refrigerator is composing a symphony of hums.",
    "My shoes are filing travelogues in invisible ink.",
    "The teapot is an undercover diplomat for the kitchenware union.",
    "I once found a tiny parliament of lost thoughts arguing politely.",
    "The moon is knitting a scarf for the horizon.",
    "My socks are writing a manifesto on foot freedom.",
    "The spoon is learning to waltz with the cereal bowl.",
    "I keep a map of imaginary places folded in my wallet.",
    "The lamp writes love letters to the dark corners.",
    "My coffee mug is plotting a gentle revolution at dawn.",
    "The wallpaper is secretly a mural of forgotten afternoons.",
    "I taught my shadow to whistle; now it leads parades.",
    "The mailbox is a philosopher in a boxy suit.",
    "My pillow hosts a book club for stray dreams.",
    "The toaster is painting tiny portraits of burnt toast.",
    "I once traded a sigh for a constellation of tiny paper boats.",
    "The clock is learning to speak in riddles.",
    "My shoes keep a diary of places they've politely declined.",
    "The teapot writes haikus about steam and patience.",
    "I keep a tiny garden of improbable ideas behind the radiator.",
    "The lamp is an undercover storyteller at midnight.",
    "My coffee is a diplomat between sleep and productivity.",
    "The curtains practice dramatic pauses for effect.",
    "I taught my spoon to be brave; it now stirs revolutions.",
    "The moon left a shopping list for the stars.",
    "My socks are secret agents on a mission to warm toes.",
    "The chair is writing postcards to chairs in other time zones.",
    "I keep a small fleet of paper airplanes for emergency flights.",
    "The refrigerator hums like a retired opera singer.",
    "My shadow collects tiny souvenirs from the places I forget.",
    "The teapot is learning to tango with the sugar bowl.",
    "I once found a tiny theater of lost ideas performing at dawn.",
    "The lamp practices accents to impress the night.",
    "My coffee mug is a tiny oracle of bitter truths.",
    "The wallpaper is a map of all the afternoons I've misplaced.",
    "I taught my shoes to be polite; they now refuse to stomp.",
    "The clock is learning to knit minutes into scarves.",
    "My pillow keeps a ledger of unfinished dreams.",
    "The spoon is writing a travel guide for soups.",
    "I keep a tiny lighthouse for wayward thoughts on my desk.",
    "The moon is learning to fold itself into paper cranes.",
    "My socks are writing postcards to the dryer about their adventures.",
    "The chair is practicing bowing for small, dignified exits.",
    "I once found a tiny orchestra of teaspoons playing lullabies.",
    "The lamp is a retired lighthouse with a fondness for novels.",
    "My coffee is composing a symphony in the key of morning.",
    "The wallpaper is a secret diary of quiet afternoons.",
    "I taught my shadow to tell jokes; it now performs at dusk.",
    "The mailbox keeps a guestbook for passing ideas.",
    "My pillow is a curator of soft, improbable memories.",
    "The toaster writes letters to the bread about bravery.",
    "I keep a tiny map of the places my curiosity has visited.",
    "The clock is learning to dance between seconds.",
    "My shoes are archivists of the sidewalks they've loved.",
    "The teapot is an ambassador of calm in a hectic kitchen.",
    "I once found a tiny city of lost commas and gave them homes.",
    "The moon is practicing calligraphy with moonlight.",
    "My socks are composing an epic about the laundry cycle.",
    "The chair is learning to tell stories about upright courage.",
    "I keep a small museum of polite regrets under the stairs.",
    "The lamp writes postcards to the morning about last night's dreams.",
    "My coffee mug is a tiny lighthouse for sleepy sailors.",
]

QUOTES_FILE = Path("absurd_quotes.json")


def speak(text: str):
    """Speak text using system TTS without external Python packages."""
    text = str(text)
    platform = sys.platform

    # macOS: use `say`
    if platform == "darwin":
        if shutil.which("say"):
            try:
                subprocess.run(["say", text], check=False)
            except Exception:
                pass
        return

    # Windows: use PowerShell System.Speech (no external modules)
    if platform.startswith("win"):
        # Escape single quotes for PowerShell single-quoted string by doubling them
        escaped = text.replace("'", "''")
        ps_cmd = (
            "Add-Type -AssemblyName System.Speech;"
            f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            f"$s.Speak('{escaped}');"
        )
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
        except Exception:
            pass
        return

    # Linux / other Unix: try espeak, then spd-say
    if shutil.which("espeak"):
        try:
            subprocess.run(["espeak", text], check=False)
        except Exception:
            pass
        return
    if shutil.which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=False)
        except Exception:
            pass
        return

    # If no TTS available, silently do nothing (or you could print a small notice)
    return


class QuotePool:
    def __init__(self, quotes=None):
        self._original = list(quotes or DEFAULT_QUOTES)
        self._pool = list(self._original)
        random.shuffle(self._pool)

    def draw(self, count=1, no_repeat=False):
        if not no_repeat:
            return [random.choice(self._original) for _ in range(count)]

        results = []
        for _ in range(count):
            if not self._pool:
                self._pool = list(self._original)
                random.shuffle(self._pool)
            results.append(self._pool.pop())
        return results

    def add(self, quote):
        quote = quote.strip()
        if not quote:
            return False
        self._original.append(quote)
        self._pool.append(quote)
        return True

    def to_list(self):
        return list(self._original)


def load_quotes(path: Path):
    if not path.exists():
        return None
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return [str(q) for q in data]
    except Exception:
        pass
    return None


def save_quotes(path: Path, quotes):
    try:
        with path.open("w", encoding="utf-8") as f:
            json.dump(quotes, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def parse_args():
    p = argparse.ArgumentParser(description="Absurd random quote generator with TTS")
    p.add_argument("-n", "--number", type=int, default=None, help="How many quotes to print (non-interactive)")
    p.add_argument("--no-repeat", action="store_true", help="Avoid repeating quotes until pool is exhausted")
    p.add_argument("--file", type=str, default=str(QUOTES_FILE), help="JSON file to load/save quotes")
    p.add_argument("--add", type=str, help="Add a new quote (wrap in quotes on the shell)")
    p.add_argument("--list", action="store_true", help="List all quotes and exit")
    p.add_argument("--no-tts", action="store_true", help="Disable text-to-speech")
    return p.parse_args()


def interactive_loop(pool: QuotePool, no_repeat: bool, tts_enabled: bool):
    try:
        while True:
            quote = pool.draw(count=1, no_repeat=no_repeat)[0]
            print(f"\n— {quote}\n")
            if tts_enabled:
                speak(quote)
            try:
                choice = input("Press Enter for another quote, or type 'q' then Enter to quit: ").strip().lower()
            except EOFError:
                print()
                break
            if choice == 'q':
                print("Goodbye.")
                break
    except KeyboardInterrupt:
        print("\nInterrupted. Goodbye.")


def main():
    args = parse_args()
    file_path = Path(args.file)

    loaded = load_quotes(file_path)
    quotes = loaded if loaded is not None else DEFAULT_QUOTES

    pool = QuotePool(quotes)

    # Add a quote and save, then exit
    if args.add:
        added = pool.add(args.add)
        if added:
            saved = save_quotes(file_path, pool.to_list())
            print("Added quote.")
            if saved:
                print(f"Saved to {file_path}")
            else:
                print("Could not save to file; running in-memory only.")
        else:
            print("Empty quote not added.")
        return

    # List all quotes and exit
    if args.list:
        for i, q in enumerate(pool.to_list(), 1):
            print(f"{i}. {q}")
        return

    tts_enabled = not args.no_tts

    # If user requested a specific number, print them once and exit (non-interactive)
    if args.number is not None:
        results = pool.draw(count=max(1, args.number), no_repeat=args.no_repeat)
        for q in results:
            print(f"— {q}")
            if tts_enabled:
                speak(q)
        return

    # Otherwise, interactive repeat-or-quit loop
    interactive_loop(pool, no_repeat=args.no_repeat, tts_enabled=tts_enabled)


if __name__ == "__main__":
    main()
