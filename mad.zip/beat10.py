# drum_fullkit_poly_no_pip.py
"""
Full drum kit polyphonic GUI (no pip).
Mixes simultaneous triggers into one WAV so multiple instruments play together.
"""

import sys, os, platform, wave, struct, math, random, tempfile, time, threading, subprocess, tkinter as tk
from tkinter import ttk
import json
from tkinter import filedialog, messagebox

# Audio settings
SAMPLE_RATE = 44100
SAMPLE_WIDTH = 2
MAX_AMPLITUDE = 32767

STEPS = 16
DEFAULT_BPM = 110
SYSTEM = platform.system().lower()

# --- WAV helpers ---
def write_wav(filename, samples, sample_rate=SAMPLE_RATE):
    with wave.open(filename, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(SAMPLE_WIDTH)
        wf.setframerate(sample_rate)
        frames = b''.join(struct.pack('<h', int(max(-MAX_AMPLITUDE, min(MAX_AMPLITUDE, s))))
                          for s in samples)
        wf.writeframes(frames)

def sine(freq, length, amp=1.0, sr=SAMPLE_RATE):
    out = []
    for n in range(int(sr * length)):
        t = n / sr
        out.append(amp * math.sin(2 * math.pi * freq * t) * MAX_AMPLITUDE)
    return out

def decay_envelope(samples, decay=0.01):
    out = []
    sr = SAMPLE_RATE
    for i, s in enumerate(samples):
        t = i / sr
        env = math.exp(-t / decay)
        out.append(s * env)
    return out

def noise(length, amp=1.0):
    out = []
    for _ in range(int(SAMPLE_RATE * length)):
        out.append((random.random() * 2 - 1) * amp * MAX_AMPLITUDE)
    return out

def band_limited_noise(length, low_hz, high_hz, amp=1.0):
    out = [0.0] * int(SAMPLE_RATE * length)
    step = max(1, int((high_hz - low_hz) / 12))
    for f in range(int(low_hz), int(high_hz), step):
        phase = random.random() * 2 * math.pi
        for n in range(len(out)):
            t = n / SAMPLE_RATE
            out[n] += amp * math.sin(2 * math.pi * f * t + phase) * (MAX_AMPLITUDE * 0.18)
    peak = max(abs(x) for x in out) or 1.0
    norm = (MAX_AMPLITUDE * amp) / peak
    return [x * norm for x in out]

# --- instrument synths (return numeric arrays) ---
def make_kick():
    length = 0.28
    out = []
    for n in range(int(SAMPLE_RATE * length)):
        t = n / SAMPLE_RATE
        freq = 120 * (0.4 ** (t / length))
        out.append(math.sin(2 * math.pi * freq * t) * (1 - t / length) * MAX_AMPLITUDE)
    return decay_envelope(out, decay=0.06)

def make_snare():
    n = noise(0.18, amp=0.9)
    tone = sine(220, 0.12, amp=0.5)
    out = []
    for i in range(max(len(n), len(tone))):
        a = n[i] if i < len(n) else 0
        b = tone[i] if i < len(tone) else 0
        out.append(a * 0.85 + b * 0.5)
    return decay_envelope(out, decay=0.08)

def make_hihat():
    return decay_envelope(band_limited_noise(0.06, 5000, 12000, amp=0.6), decay=0.02)

def make_tom(freq=120, length=0.18):
    out = []
    for n in range(int(SAMPLE_RATE * length)):
        t = n / SAMPLE_RATE
        f = freq * (1 + 0.02 * math.sin(2 * math.pi * 3 * t))
        out.append(math.sin(2 * math.pi * f * t) * (1 - t / length) * MAX_AMPLITUDE)
    return decay_envelope(out, decay=0.06)

def make_ride():
    return decay_envelope(band_limited_noise(0.6, 4000, 10000, amp=0.5), decay=0.25)

def make_crash():
    return decay_envelope(band_limited_noise(1.2, 2000, 12000, amp=0.6), decay=0.6)

def make_cowbell():
    length = 0.18
    partials = [880, 1320, 1760, 2200]
    out = [0.0] * int(SAMPLE_RATE * length)
    for p in partials:
        phase = random.random() * 2 * math.pi
        for n in range(len(out)):
            t = n / SAMPLE_RATE
            out[n] += 0.6 * math.sin(2 * math.pi * p * t + phase) * MAX_AMPLITUDE
    n = noise(0.02, amp=0.2)
    for i in range(min(len(out), len(n))):
        out[i] += n[i]
    return decay_envelope(out, decay=0.08)

def make_clap():
    total_len = 0.22
    out = [0.0] * int(SAMPLE_RATE * total_len)
    bursts = [0.0, 0.02, 0.05]
    for b in bursts:
        start = int(b * SAMPLE_RATE)
        burst = noise(0.06, amp=0.9)
        for i, v in enumerate(burst):
            if start + i < len(out):
                out[start + i] += v * (1 - i / len(burst))
    return decay_envelope(out, decay=0.06)

def make_shaker():
    n = band_limited_noise(0.12, 6000, 12000, amp=0.5)
    out = []
    for i, v in enumerate(n):
        t = i / SAMPLE_RATE
        env = 0.5 + 0.5 * math.sin(2 * math.pi * 30 * t)
        out.append(v * env)
    return decay_envelope(out, decay=0.08)

def make_cymbal():
    length = 0.9
    n = band_limited_noise(length, 4000, 14000, amp=0.7)
    partials = [6000, 8200, 10500]
    for p in partials:
        phase = random.random() * 2 * math.pi
        for i in range(len(n)):
            t = i / SAMPLE_RATE
            n[i] += 0.15 * math.sin(2 * math.pi * p * t + phase) * MAX_AMPLITUDE
    return decay_envelope(n, decay=0.28)

# --- platform playback ---
def play_async(filepath):
    if SYSTEM.startswith('windows'):
        import winsound
        winsound.PlaySound(filepath, winsound.SND_FILENAME | winsound.SND_ASYNC)
    elif SYSTEM.startswith('darwin'):
        subprocess.Popen(['afplay', filepath])
    else:
        for cmd in (['paplay', filepath], ['aplay', filepath]):
            try:
                subprocess.Popen(cmd)
                return
            except FileNotFoundError:
                continue
        try:
            subprocess.Popen(['ffplay', '-nodisp', '-autoexit', '-loglevel', 'quiet', filepath])
        except Exception:
            print("No suitable audio player found. Install 'aplay' or 'paplay'.")

# --- build in-memory samples and temp dir ---
tmpdir = tempfile.mkdtemp(prefix='py_drum_fullkit_poly_')

kick_samples = make_kick()
snare_samples = make_snare()
hihat_samples = make_hihat()
low_tom_samples = make_tom(freq=100, length=0.22)
mid_tom_samples = make_tom(freq=160, length=0.20)
high_tom_samples = make_tom(freq=240, length=0.18)
ride_samples = make_ride()
crash_samples = make_crash()
cowbell_samples = make_cowbell()
clap_samples = make_clap()
shaker_samples = make_shaker()
cymbal_samples = make_cymbal()

INSTRUMENTS = [
    {'name': 'Kick',   'samples': kick_samples,   'mute': False},
    {'name': 'Snare',  'samples': snare_samples,  'mute': False},
    {'name': 'HiHat',  'samples': hihat_samples,  'mute': False},
    {'name': 'LowTom', 'samples': low_tom_samples,'mute': False},
    {'name': 'MidTom', 'samples': mid_tom_samples,'mute': False},
    {'name': 'HighTom','samples': high_tom_samples,'mute': False},
    {'name': 'Ride',   'samples': ride_samples,   'mute': False},
    {'name': 'Crash',  'samples': crash_samples,  'mute': False},
    {'name': 'Cowbell','samples': cowbell_samples, 'mute': False},
    {'name': 'Clap',   'samples': clap_samples,   'mute': False},
    {'name': 'Shaker', 'samples': shaker_samples, 'mute': False},
    {'name': 'Cymbal', 'samples': cymbal_samples, 'mute': False},
]

# --- mix cache and helpers ---
_mix_cache = {}
_mix_lock = threading.Lock()
_mix_files = []

def mix_samples(indices):
    if not indices:
        return None
    key = tuple(sorted(indices))
    with _mix_lock:
        if key in _mix_cache:
            return _mix_cache[key]
    max_len = max(len(INSTRUMENTS[i]['samples']) for i in indices)
    mix = [0.0] * max_len
    for i in indices:
        s = INSTRUMENTS[i]['samples']
        for j, v in enumerate(s):
            mix[j] += v
    peak = max(abs(x) for x in mix) or 1.0
    norm = MAX_AMPLITUDE / peak
    mixed = [int(max(-MAX_AMPLITUDE, min(MAX_AMPLITUDE, x * norm))) for x in mix]
    tf = tempfile.NamedTemporaryFile(delete=False, suffix='.wav', dir=tmpdir)
    tf.close()
    write_wav(tf.name, mixed)
    with _mix_lock:
        _mix_cache[key] = tf.name
        _mix_files.append(tf.name)
    return tf.name

def mix_and_play(indices):
    path = mix_samples(indices)
    if path:
        play_async(path)

# --- render pattern to WAV and file helpers ---
def render_pattern_to_wav(path, loops=1):
    """Render the current grid pattern into one WAV file (loops times)."""
    out = []
    # compute step length in seconds based on current bpm
    with lock:
        local_bpm = bpm
    step_length_seconds = 60.0 / local_bpm / 4.0
    step_samples = int(SAMPLE_RATE * step_length_seconds)
    for _ in range(loops):
        for step in range(STEPS):
            active = [i for i in range(len(INSTRUMENTS)) if grid[i][step] and not INSTRUMENTS[i].get('mute', False)]
            if not active:
                out.extend([0] * step_samples)
                continue
            mix_path = mix_samples(active)
            samples = []
            try:
                with wave.open(mix_path, 'rb') as wf:
                    frames = wf.readframes(wf.getnframes())
                    # unpack 16-bit little-endian signed samples
                    fmt = '<' + 'h' * (len(frames) // 2)
                    samples = list(struct.unpack(fmt, frames))
            except Exception:
                samples = [0] * step_samples
            # trim or pad to step length
            if len(samples) < step_samples:
                samples = samples + [0] * (step_samples - len(samples))
            elif len(samples) > step_samples:
                samples = samples[:step_samples]
            out.extend(samples)
    # write final wav
    write_wav(path, out)
    return path

def open_path_with_default_app(path):
    """Open file or folder with the system default application."""
    try:
        if SYSTEM.startswith('windows'):
            os.startfile(path)
        elif SYSTEM.startswith('darwin'):
            subprocess.Popen(['open', path])
        else:
            subprocess.Popen(['xdg-open', path])
    except Exception:
        # fallback: try to play the file
        play_async(path)

def save_pattern_to_file(parent=None):
    """Export the grid and instrument mutes to JSON."""
    file = filedialog.asksaveasfilename(defaultextension='.json', filetypes=[('JSON','*.json')])
    if not file:
        return
    data = {
        'steps': STEPS,
        'bpm': bpm,
        'grid': grid,
        'mutes': [inst.get('mute', False) for inst in INSTRUMENTS],
        'instruments': [inst['name'] for inst in INSTRUMENTS],
    }
    try:
        with open(file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
        if parent:
            messagebox.showinfo('Export', f'Pattern saved to {file}', parent=parent)
    except Exception as e:
        messagebox.showerror('Export error', str(e), parent=parent)

def load_pattern_from_file(parent=None):
    """Import a saved pattern JSON file and apply it to the GUI/state."""
    file = filedialog.askopenfilename(filetypes=[('JSON','*.json')])
    if not file:
        return
    try:
        with open(file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        # steps check
        if data.get('steps') != STEPS:
            proceed = True
            if parent:
                proceed = messagebox.askyesno('Steps mismatch', 'Saved pattern has different step count. Try to load anyway?', parent=parent)
            if not proceed:
                return
        # load grid
        loaded_grid = data.get('grid')
        if loaded_grid and len(loaded_grid) == len(INSTRUMENTS):
            for r in range(len(INSTRUMENTS)):
                for c in range(min(STEPS, len(loaded_grid[r]))):
                    grid[r][c] = bool(loaded_grid[r][c])
                for c in range(len(loaded_grid[r]), STEPS):
                    grid[r][c] = False
        # load mutes
        mutes = data.get('mutes')
        if mutes and len(mutes) == len(INSTRUMENTS):
            for i, m in enumerate(mutes):
                INSTRUMENTS[i]['mute'] = bool(m)
        # load bpm
        if 'bpm' in data:
            with lock:
                global bpm
                bpm = int(data['bpm'])
        # update GUI if available
        if parent and hasattr(parent, 'refresh_grid_buttons'):
            try:
                parent.tempo.set(bpm)
            except Exception:
                pass
            try:
                for i, mv in enumerate(parent.mute_vars):
                    mv.set(bool(INSTRUMENTS[i].get('mute', False)))
            except Exception:
                pass
            parent.refresh_grid_buttons()
        if parent:
            messagebox.showinfo('Import', f'Pattern loaded from {file}', parent=parent)
    except Exception as e:
        messagebox.showerror('Import error', str(e), parent=parent)

# --- sequencer state ---
grid = [[False for _ in range(STEPS)] for _ in INSTRUMENTS]
# default simple pattern
grid[0][0] = True; grid[0][8] = True
grid[1][4] = True; grid[1][12] = True
for i in range(0, STEPS, 2): grid[2][i] = True
grid[3][10] = True
grid[4][14] = True
grid[6][8] = True
grid[8][6] = True
grid[11][15] = True  # cymbal example

playing = False
current_step = 0
bpm = DEFAULT_BPM
lock = threading.Lock()
stop_flag = False

def play_step(step_idx):
    active = [i for i in range(len(INSTRUMENTS)) if grid[i][step_idx] and not INSTRUMENTS[i].get('mute', False)]
    mix_and_play(active)

def sequencer_loop():
    global current_step
    while not stop_flag:
        with lock:
            is_playing = playing; local_bpm = bpm
        if is_playing:
            step_interval = 60.0 / local_bpm / 4.0
            play_step(current_step)
            current_step = (current_step + 1) % STEPS
            time.sleep(step_interval)
        else:
            time.sleep(0.05)

# --- live polyphonic keyboard support ---
# Map keys to instruments (one key per instrument). Edit as desired.
KEY_MAP = ['z','x','c','v','b','n','m',',','.','/','a','s']
_pressed_keys = set()

def play_chord_now_from_keys():
    indices = []
    for i, k in enumerate(KEY_MAP):
        if k in _pressed_keys and not INSTRUMENTS[i].get('mute', False):
            indices.append(i)
    if indices:
        mix_and_play(indices)

def play_instrument_now(idx):
    if 0 <= idx < len(INSTRUMENTS) and not INSTRUMENTS[idx].get('mute', False):
        mix_and_play([idx])

# --- GUI ---
class DrumGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Full Drum Kit — Polyphonic (no pip)")
        self.resizable(False, True)
        self.step_buttons = []
        self.mute_vars = []
        self.create_widgets()
        self.update_highlight()
        self.bind_all('<KeyPress>', self.on_key_press)
        self.bind_all('<KeyRelease>', self.on_key_release)

    def create_widgets(self):
        top = ttk.Frame(self, padding=8); top.grid(row=0, column=0, sticky='nsew')
        ctrl = ttk.Frame(top); ctrl.grid(row=0, column=0, sticky='w', pady=(0,8))
        self.play_btn = ttk.Button(ctrl, text='Play', command=self.toggle_play); self.play_btn.grid(row=0,column=0,padx=4)
        ttk.Button(ctrl, text='Stop', command=self.stop).grid(row=0,column=1,padx=4)
        ttk.Button(ctrl, text='Randomize', command=self.randomize).grid(row=0,column=2,padx=4)
        ttk.Button(ctrl, text='Clear', command=self.clear).grid(row=0,column=3,padx=4)
        ttk.Label(ctrl, text='Tempo').grid(row=0,column=4,padx=(12,2))
        self.tempo = tk.IntVar(value=bpm)
        ttk.Scale(ctrl, from_=40, to=240, orient='horizontal', variable=self.tempo, command=self.on_tempo_change, length=220).grid(row=0,column=5)

        # New buttons: Save WAV, Open Folder, Export, Import
        ttk.Button(ctrl, text='Save WAV', command=self.on_save_wav).grid(row=0,column=6,padx=4)
        ttk.Button(ctrl, text='Open Folder', command=self.on_open_folder).grid(row=0,column=7,padx=4)
        ttk.Button(ctrl, text='Export', command=lambda: save_pattern_to_file(self)).grid(row=0, column=8, padx=4)
        ttk.Button(ctrl, text='Import', command=lambda: load_pattern_from_file(self)).grid(row=0, column=9, padx=4)

        canvas_frame = ttk.Frame(top); canvas_frame.grid(row=1, column=0)
        canvas = tk.Canvas(canvas_frame, width=1100, height=420)
        scrollbar = ttk.Scrollbar(canvas_frame, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y'); canvas.pack(side='left')
        self.inner = ttk.Frame(canvas); canvas.create_window((0,0), window=self.inner, anchor='nw')
        self.inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        for r, inst in enumerate(INSTRUMENTS):
            row_frame = ttk.Frame(self.inner); row_frame.grid(row=r, column=0, pady=4, sticky='w')
            ttk.Label(row_frame, text=inst['name'], width=8).grid(row=0, column=0)
            btns = []
            for c in range(STEPS):
                b = tk.Button(row_frame, text='', width=3, relief='raised', command=lambda rr=r, cc=c: self.toggle_cell(rr, cc))
                b.grid(row=0, column=1+c, padx=2); btns.append(b)
            self.step_buttons.append(btns)
            mv = tk.BooleanVar(value=False)
            ttk.Checkbutton(row_frame, text='Mute', variable=mv, command=lambda rr=r, var=mv: self.set_mute(rr, var.get())).grid(row=0, column=1+STEPS, padx=(8,0))
            ttk.Button(row_frame, text='Play', width=6, command=lambda rr=r: play_instrument_now(rr)).grid(row=0, column=2+STEPS, padx=(8,0))
            key_label = KEY_MAP[r] if r < len(KEY_MAP) else '?'
            ttk.Label(row_frame, text=f'Key: {key_label}', width=8).grid(row=0, column=3+STEPS, padx=(8,0))
            self.mute_vars.append(mv)

        label_frame = ttk.Frame(self.inner); label_frame.grid(row=len(INSTRUMENTS), column=0, pady=(8,0), sticky='w')
        ttk.Label(label_frame, text='Steps:').grid(row=0, column=0)
        for c in range(STEPS):
            ttk.Label(label_frame, text=str(c), width=3).grid(row=0, column=1+c)

        self.status = ttk.Label(self, text='Ready', padding=6); self.status.grid(row=2, column=0, sticky='we')
        self.refresh_grid_buttons()

    def toggle_play(self):
        global playing, current_step
        with lock:
            playing = not playing
            if playing:
                current_step = 0; self.play_btn.config(text='Pause')
            else:
                self.play_btn.config(text='Play')
        self.update_status()

    def stop(self):
        global playing
        with lock:
            playing = False; self.play_btn.config(text='Play')
        self.update_status()

    def on_tempo_change(self, _=None):
        global bpm
        with lock:
            bpm = int(self.tempo.get())
        self.update_status()

    def toggle_cell(self, r, c):
        grid[r][c] = not grid[r][c]; self.refresh_grid_buttons()

    def set_mute(self, r, val):
        INSTRUMENTS[r]['mute'] = bool(val); self.update_status()

    def randomize(self):
        for r in range(len(INSTRUMENTS)):
            for c in range(STEPS):
                grid[r][c] = random.random() < 0.22
        self.refresh_grid_buttons()

    def clear(self):
        for r in range(len(INSTRUMENTS)):
            for c in range(STEPS):
                grid[r][c] = False
        self.refresh_grid_buttons()

    def refresh_grid_buttons(self):
        for r in range(len(INSTRUMENTS)):
            for c in range(STEPS):
                b = self.step_buttons[r][c]
                b.config(bg='#00b386' if grid[r][c] else 'SystemButtonFace')
        self.update_status()

    def update_status(self):
        with lock:
            s = f"BPM: {bpm}   Playing: {'Yes' if playing else 'No'}"
        self.status.config(text=s)

    def update_highlight(self):
        for r in range(len(INSTRUMENTS)):
            for c in range(STEPS):
                b = self.step_buttons[r][c]
                b.config(relief='sunken' if playing and c == current_step else 'raised')
        self.after(40, self.update_highlight)

    def on_key_press(self, event):
        key = event.keysym.lower()
        if not key: return
        if key in _pressed_keys: return
        _pressed_keys.add(key)
        play_chord_now_from_keys()

    def on_key_release(self, event):
        key = event.keysym.lower()
        if key in _pressed_keys:
            _pressed_keys.remove(key)

    # --- new GUI actions for saving and opening ---
    def on_save_wav(self):
        file = filedialog.asksaveasfilename(defaultextension='.wav', filetypes=[('WAV','*.wav')], initialdir=tmpdir)
        if not file:
            return
        try:
            # render two loops (2 bars) by default; change loops as desired
            render_pattern_to_wav(file, loops=2)
            messagebox.showinfo('Saved', f'WAV saved to {file}', parent=self)
            open_path_with_default_app(file)
        except Exception as e:
            messagebox.showerror('Save error', str(e), parent=self)

    def on_open_folder(self):
        open_path_with_default_app(tmpdir)

# --- start sequencer thread and GUI ---
seq_thread = threading.Thread(target=sequencer_loop, daemon=True)
seq_thread.start()

try:
    app = DrumGUI()
    app.mainloop()
finally:
    stop_flag = True
    seq_thread.join(timeout=1)
    # cleanup temp files
    try:
        with _mix_lock:
            for f in _mix_files:
                if os.path.exists(f): os.remove(f)
        os.rmdir(tmpdir)
    except Exception:
        pass
