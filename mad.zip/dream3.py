#!/usr/bin/env python3
"""
dream_quotes_interactive_tts.py
Interactive CLI that prints random dream-inspired quotes from a large built-in bank.
Adds Text To Speech (TTS) using only standard library and system TTS commands (no pip).
 - macOS: uses `say`
 - Windows: uses PowerShell System.Speech.Synthesis via subprocess
 - Linux: tries `spd-say` then `espeak` if available (may not be installed by default)
Features:
 - Large QUOTE_BANK across many themes
 - Interactive menu to choose theme, count, unique mode, and custom file
 - Shows quotes and then lets you repeat or quit
 - Save last shown output to a file
 - Play last shown output with TTS and toggle auto-read after showing quotes
"""

import random
import sys
import subprocess
from pathlib import Path
from typing import List, Dict, Optional
import shutil

# ---------------------------
# Large quote bank (sample)
# ---------------------------
QUOTE_BANK: Dict[str, List[str]] = {
    "surreal": [
        "The moon stitched my pockets with silver.",
        "I walked through a hallway of falling clocks.",
        "Clouds whispered the names I forgot.",
        "A mirror smiled and left the room without me.",
        "The ceiling opened like a book and read itself aloud.",
        "I drank a cup of sky and tasted yesterday.",
        "The stairs dissolved into a river of paper boats.",
        "A piano grew roots and hummed the weather.",
        "My shadow left a note on the refrigerator.",
        "The city rearranged itself while I blinked.",
        "A train ran on sentences instead of tracks.",
        "I found a door that led to the back of my own head.",
        "The sun folded itself into a small, polite square.",
        "I traded my shoes for a pair of small, honest clouds.",
        "A clock apologized for being late and then stopped.",
        "The wallpaper peeled itself to reveal a map of my childhood.",
        "I met a fish that remembered my name from another life.",
        "The elevator took me sideways into a memory I hadn't paid for.",
        "A pair of gloves knitted the wind into a scarf.",
        "The mirror offered me a different haircut and a secret.",
        "I woke up inside a photograph that was still developing.",
        "The moon borrowed my voice to sing to the trees.",
        "A staircase led to a room that smelled like the ocean at dawn.",
        "The rain arrived with a suitcase full of small, polite regrets.",
        "I found a key that opened the sound of distant laughter.",
        "A shadow taught me how to fold time into a paper crane.",
        "The stars rearranged themselves into a sentence I almost understood.",
        "A bicycle rode itself across the ceiling and waved.",
        "The clock hands braided themselves into a crown.",
        "I followed a ribbon of light into a room that had no walls.",
    ],
    "nostalgic": [
        "Old songs live in the corners of my sleep.",
        "I found my childhood in a pocket of the night.",
        "The house remembered my footsteps before I did.",
        "A photograph hummed like a distant train.",
        "The attic kept a small, patient version of me.",
        "I smelled summer and it was the same as the first time.",
        "The porch light blinked in Morse code with my name.",
        "A paper airplane carried a letter I never sent.",
        "The swing still knew the rhythm of my laughter.",
        "I opened a drawer and found a map of all the summers.",
        "The radio played a song that smelled like warm bread.",
        "A pair of sneakers waited by the door like an old friend.",
        "The kitchen clock ticked in the voice of my grandmother.",
        "I found a ticket stub that led to a memory of rain.",
        "The wallpaper still had the faint outline of a childhood drawing.",
        "A lost glove returned with a note that said 'sorry I left'.",
        "The attic light revealed a constellation of old promises.",
        "I tasted lemonade and it tasted like the first day of freedom.",
        "A postcard from a younger me arrived in the mail of my mind.",
        "The porch swing creaked out the chorus of a lullaby.",
        "I found my name carved into the underside of a table.",
        "The smell of crayons opened a door I thought was closed.",
        "A cassette tape played the voice of a summer I miss.",
        "The old coat still held the shape of a winter I survived.",
        "I traced the outline of a paper boat and remembered the river.",
        "A faded ticket to a fair still jingled with cotton candy.",
        "The attic clock wound itself and wound back time a little.",
        "I found a marble that rolled me back to a playground.",
        "The mailbox kept a letter addressed to the person I used to be.",
        "A patch of sunlight on the floor was a map to yesterday.",
    ],
    "mystical": [
        "Stars braided themselves into a crown for me.",
        "The river answered in a language of light.",
        "I traded my shadow for a map of the sky.",
        "A key grew from the roots of a dream.",
        "The wind taught me the names of things I had not yet met.",
        "A lantern showed me the way to a door that wasn't there.",
        "The mountain hummed a hymn that rearranged my bones.",
        "I found a stone that remembered the shape of the moon.",
        "A compass pointed to the place where I felt most myself.",
        "The forest folded its arms and whispered a secret treaty.",
        "A raven delivered a letter written in constellations.",
        "The lake reflected a sky that belonged to someone else.",
        "I learned to read the footprints of the stars.",
        "A candle burned backward and returned the night to day.",
        "The old oak offered me a seat and a prophecy.",
        "A bell tolled in a language only the heart could translate.",
        "I met a stranger who knew the ending of my story.",
        "The horizon bowed politely and let me pass.",
        "A small door in the earth opened onto a cathedral of roots.",
        "The moon lent me a coin stamped with silence.",
        "A map unfolded itself into a poem about home.",
        "The tide left messages written in shells and patience.",
        "A fox taught me how to keep a promise to myself.",
        "The stars stitched a seam between now and forever.",
        "I found a mirror that reflected the future like a kindly neighbor.",
        "A bellflower chimed and the world rearranged its colors.",
        "The sky folded into a pocket and kept my worries safe.",
        "A pilgrim's hat appeared on the shelf of my thoughts.",
        "The wind returned a lost word and it tasted like rain.",
        "A constellation winked and the path home lit up.",
    ],
    "calm": [
        "Soft rain taught me how to breathe again.",
        "The night folded me into a quiet pocket of time.",
        "A single lantern kept the whole world gentle.",
        "I learned patience from the slow turning of tides.",
        "The pillow remembered the shape of my sighs.",
        "A slow clock taught me the value of small pauses.",
        "The sea hummed a lullaby that smoothed my edges.",
        "A cup of tea held the map to a peaceful afternoon.",
        "The window framed a moment that refused to hurry.",
        "A blanket of fog softened the sharp corners of the day.",
        "The garden waited with the calm of someone who knows tomorrow.",
        "A soft chair cradled the weight of my small, honest thoughts.",
        "The kettle sang a steady, reassuring note.",
        "A single page turned itself and the story breathed out.",
        "The moon kept watch like a patient friend.",
        "A slow walk collected the scattered pieces of my mind.",
        "The lamp's glow made the room remember how to be kind.",
        "A quiet street held the echo of a gentle promise.",
        "The clock's tick matched the rhythm of my calm heart.",
        "A warm scarf wrapped me in the memory of safety.",
        "The tea steam drew a map of slow afternoons.",
        "A soft chair and a good book were the day's small triumph.",
        "The porch light waited without expectation.",
        "A lullaby of distant traffic soothed the edges of my day.",
        "The horizon exhaled and the sky relaxed.",
        "A slow breath became the most honest thing I did all day.",
        "The pillow accepted my worries and returned them softer.",
        "A quiet kitchen made room for small, steady rituals.",
        "The rain's rhythm taught my hands how to rest.",
        "A single star blinked and the world felt less urgent.",
    ],
    "romantic": [
        "She liked everything about me, even the silence.",
        "We danced on the edge of a whispered promise.",
        "His laugh built a small home inside my chest.",
        "We left footprints on the moon and called it ours.",
        "A single glance rearranged the furniture of my day.",
        "Her handwriting folded itself into the margins of my life.",
        "We shared a secret that tasted like warm coffee.",
        "His jacket smelled like a place I wanted to visit forever.",
        "We held hands and the city softened its edges.",
        "A late-night call stitched the distance into something smaller.",
        "Her smile was a map I learned by heart.",
        "We traded small lies for honest kisses.",
        "His voice was a room I wanted to live in.",
        "We planted a garden of small, stubborn promises.",
        "Her laugh was the punctuation my sentences needed.",
        "We wrote our names on the back of a cloud.",
        "His eyes kept the kind of patience that builds bridges.",
        "We shared an umbrella and the rain applauded.",
        "Her presence rearranged the furniture of my fears.",
        "We learned each other's silences and called them home.",
        "His hand fit mine like a sentence finishing itself.",
        "We left a trail of small, luminous memories.",
        "Her whisper was a compass that always pointed me back.",
        "We made a map of the places we would visit together.",
        "His promise was a small, steady lighthouse in my night.",
        "We found a song that only our two hearts knew.",
        "Her name tasted like the first page of a favorite book.",
        "We kept a jar of ordinary afternoons and called them treasure.",
        "His laugh rearranged the furniture of my doubts.",
        "We learned to be gentle with the parts that still hurt.",
    ],
    "introspective": [
        "I practice being brave in the quiet hours.",
        "The mirror keeps a ledger of the things I forgive.",
        "I carry small revolutions in the pocket of my chest.",
        "A question sat on the windowsill and refused to leave.",
        "I learned to listen to the slow voice under my hurry.",
        "A single thought grew roots and became a habit of kindness.",
        "I found a map to myself folded inside a song.",
        "The silence between my words taught me how to answer.",
        "I keep a small museum of the mistakes that taught me mercy.",
        "A private lighthouse guided me through fog I made myself.",
        "I practice saying the things my younger self needed to hear.",
        "A quiet courage lives in the margin of my plans.",
        "I learned to be a gentle witness to my own small changes.",
        "A notebook held the shape of the person I was becoming.",
        "I traded certainty for curiosity and the world opened.",
        "A small, steady honesty replaced the loudness of fear.",
        "I found a quiet map that led me back to wonder.",
        "The questions I ask now are kinder than the ones I asked before.",
        "I keep a list of small mercies and consult it often.",
        "A single breath taught me how to return to myself.",
        "I learned to be patient with the slow work of healing.",
        "A quiet voice inside me learned to speak without apology.",
        "I practice forgiveness like a craft, slowly and with care.",
        "A small light in my chest learned to guide me home.",
        "I learned to carry my history like a book, not a burden.",
        "A gentle curiosity replaced the need to always be right.",
        "I keep a map of the places I still want to meet myself.",
        "A soft resolve grew where impatience used to live.",
        "I learned to listen to the parts of me that whisper.",
        "A small, steady hope became the engine of my mornings.",
    ],
    "eerie": [
        "The house hummed with the memory of someone else's footsteps.",
        "A clock ticked in a room that had no doors.",
        "The portrait in the hallway blinked when I wasn't looking.",
        "A lullaby played from a room that had been empty for years.",
        "The mirror returned a face that remembered me differently.",
        "A shadow waited politely at the foot of my bed.",
        "The wind carried a name I had never heard before.",
        "A door opened to a corridor that led nowhere and everywhere.",
        "The telephone rang with a voice that knew my secrets.",
        "A pair of shoes walked across the ceiling and left no sound.",
        "The wallpaper's pattern shifted when I tried to count it.",
        "A child's laugh echoed down a staircase that had no children.",
        "The attic light blinked in a rhythm that spelled a warning.",
        "A key turned itself in a lock that had no door.",
        "The clock hands moved backward and the room grew colder.",
        "A photograph smiled with teeth it shouldn't have.",
        "The house kept a small, polite collection of lost afternoons.",
        "A whisper threaded itself through the curtains and stayed.",
        "The hallway lengthened like a thought that wouldn't end.",
        "A shadow wrote my name on the fogged window.",
        "The radio played a song that had never been written.",
        "A portrait's eyes followed the path of my regrets.",
        "The floorboards remembered a dance I had never learned.",
        "A single shoe sat on the porch as if waiting for a storm.",
        "The clock chimed thirteen times and the room held its breath.",
        "A whisper promised to return what it had borrowed.",
        "The mirror kept a small, polite grudge against the light.",
        "A door closed softly and the house forgot how to sleep.",
        "The night kept a list of things it would not tell me.",
        "A shadow left a footprint that led to the attic.",
    ],
    "whimsical": [
        "A teacup sailed across the table like a tiny ship.",
        "The cat wore a hat and read the morning paper.",
        "A cloud tied its shoelaces and went for a walk.",
        "The mailbox sang when it received a compliment.",
        "A pair of socks declared themselves philosophers.",
        "The lamp told jokes and the room laughed politely.",
        "A spoon learned to whistle and started a band.",
        "The garden grew tiny umbrellas for the ants.",
        "A bicycle learned to dance and taught the lampposts.",
        "The kettle practiced opera at dawn.",
        "A paper plane delivered a very important hello.",
        "The teapot winked and poured out a story.",
        "A pair of gloves went on a picnic and invited the moon.",
        "The bookshelf rearranged itself to make room for a joke.",
        "A small cloud rented a room above the bakery.",
        "The clock learned to tell stories instead of time.",
        "A pair of shoes went on strike for better sidewalks.",
        "The mailbox kept a diary of the letters it never sent.",
        "A pancake performed a small, triumphant flip.",
        "The umbrella opened itself to applause.",
        "A teacup and a saucer argued about the weather.",
        "The lamp knitted a scarf for the winter breeze.",
        "A pencil drew a map to the nearest giggle.",
        "The chair learned to hum and the room joined in.",
        "A cookie left a note that said 'be kind to crumbs'.",
        "The moon borrowed a hat and looked very distinguished.",
        "A small cloud practiced being a sheep for a day.",
        "The mailbox learned to blush when it received love letters.",
        "A teapot and a kettle started a polite debate club.",
        "The garden grew tiny lanterns to guide lost fireflies.",
    ],
    "adventurous": [
        "I packed a pocket of courage and left at dawn.",
        "The map had a dotted line that led to a grin.",
        "A suitcase full of questions waited at the station.",
        "I followed a compass that pointed to the next yes.",
        "The road promised surprises and kept its word.",
        "A small boat carried me across a sea of possibilities.",
        "I climbed a ladder that reached the edge of the sky.",
        "A backpack held the smell of distant rain and new cities.",
        "The horizon winked and I answered with my boots.",
        "A ticket to nowhere turned into a passport to everything.",
        "I learned to read the language of unfamiliar streets.",
        "A bridge invited me to cross and I did without fear.",
        "The trail kept a secret and shared it with my feet.",
        "A map folded itself into a paper bird and flew.",
        "I found a path that only opened for those who dared.",
        "A small compass spun until it found my curiosity.",
        "The train stopped at a station called 'Maybe'.",
        "I traded a plan for a pair of good walking shoes.",
        "A lighthouse winked and the sea told me a story.",
        "I followed a string of lanterns into a festival of stars.",
        "A backpack of small comforts made the long road kind.",
        "The mountain invited me to climb and I accepted with a smile.",
        "A ferry carried me across a river of new beginnings.",
        "I learned to say hello in the language of the road.",
        "A map with no names became the best kind of map.",
        "The path rewarded curiosity with a view I couldn't have planned.",
        "A small compass taught me how to choose the next adventure.",
        "I found a town that sold postcards of possible futures.",
        "A road sign pointed to 'Somewhere Good' and I turned.",
        "The journey kept a pocket of wonder for me to find.",
    ],
    "default": [
        "Dreams are postcards from a place we almost remember.",
        "In sleep I practice being brave.",
        "The mind paints in colors daylight has forgotten.",
        "Sometimes the quietest dreams are the loudest teachers.",
        "A single dream can rearrange the furniture of a week.",
        "Sleep is the small workshop where we fix our edges.",
        "A dream is a short story written by the heart.",
        "Night keeps a small library of the things we almost said.",
        "Dreams are the rehearsal for the life we haven't learned yet.",
        "A dream can be a small, honest revolution.",
        "Sleep folds the day into something softer and new.",
        "A dream is a postcard from the self you are becoming.",
        "Night is the studio where the imagination paints without rules.",
        "Dreams keep the parts of us that still want to play.",
        "A single dream can be a compass for a whole morning.",
        "Sleep is the quiet place where courage grows small and steady.",
        "Dreams are the quiet architects of tomorrow's courage.",
        "A dream can be a small, stubborn lighthouse in a foggy week.",
        "Night keeps the gentle work of rearranging our hopes.",
        "Dreams are the small, honest maps we draw for ourselves.",
        "A dream is a whisper that sometimes becomes a plan.",
        "Sleep is the place where the heart rehearses its next kindness.",
        "Dreams are the soft scaffolding for the day to come.",
        "A single dream can teach you how to be kinder to yourself.",
        "Night is the quiet gardener of the seeds we plant by day.",
        "Dreams are the small, secret libraries of the soul.",
        "A dream can be a tiny, fierce promise to try again.",
        "Sleep is the gentle editor of the day's rough drafts.",
        "Dreams are the small, bright tools we use to build courage.",
        "A dream can be the first line of a story you will write awake.",
    ],
}

# ---------------------------
# Utility functions
# ---------------------------
def load_quotes_from_file(path: Path) -> List[str]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]
    return lines

def build_pool(theme: str, extra_file: Optional[Path]) -> List[str]:
    pool: List[str] = []
    if theme and theme in QUOTE_BANK:
        pool.extend(QUOTE_BANK[theme])
    else:
        for quotes in QUOTE_BANK.values():
            pool.extend(quotes)
    if extra_file:
        pool.extend(load_quotes_from_file(extra_file))
    if not pool:
        pool = QUOTE_BANK.get("default", []).copy()
    return pool

def pick_quotes(pool: List[str], count: int, unique: bool) -> List[str]:
    if not pool:
        return []
    if unique:
        if count >= len(pool):
            return random.sample(pool, k=len(pool)) + [random.choice(pool) for _ in range(count - len(pool))]
        return random.sample(pool, k=count)
    else:
        return [random.choice(pool) for _ in range(count)]

# ---------------------------
# TTS helpers (no external packages)
# ---------------------------
def _run_subprocess(cmd: List[str]) -> None:
    try:
        subprocess.run(cmd, check=False)
    except Exception:
        pass

def tts_say(text: str) -> None:
    """
    Cross-platform TTS using only system tools and Python standard library.
    - macOS: uses `say`
    - Windows: uses PowerShell + System.Speech.Synthesis
    - Linux: tries `spd-say` then `espeak` if available
    """
    if not text:
        return

    # macOS
    if sys.platform == "darwin":
        if shutil.which("say"):
            _run_subprocess(["say", text])
            return

    # Windows
    if sys.platform.startswith("win"):
        # Use PowerShell to access System.Speech.Synthesis.SpeechSynthesizer
        # This uses only built-in Windows components and PowerShell.
        ps_script = (
            "Add-Type -AssemblyName System.speech;"
            f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            "$s.Rate = 0;"
            "$s.Volume = 100;"
            f"$s.Speak([Console]::In.ReadToEnd());"
        )
        try:
            # Pass text via stdin to avoid quoting issues
            proc = subprocess.Popen(
                ["powershell", "-NoProfile", "-Command", ps_script],
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                text=True,
            )
            proc.communicate(text)
            return
        except Exception:
            pass

    # Linux / other Unix-like
    # Try spd-say, then espeak
    if shutil.which("spd-say"):
        _run_subprocess(["spd-say", text])
        return
    if shutil.which("espeak"):
        _run_subprocess(["espeak", text])
        return

    # If no system TTS available, do nothing (graceful fallback)
    return

# ---------------------------
# Interactive main with TTS
# ---------------------------
def interactive_main():
    def prompt_theme() -> str:
        themes = sorted(QUOTE_BANK.keys())
        print("\nAvailable themes:", ", ".join(themes))
        t = input("Choose theme (leave blank for mixed): ").strip().lower()
        return t

    def prompt_count() -> int:
        try:
            n = int(input("How many quotes? (default 1): ").strip() or "1")
            return max(1, n)
        except ValueError:
            print("Invalid number, using 1.")
            return 1

    def prompt_unique() -> bool:
        ans = input("Prefer unique quotes when possible? (y/N): ").strip().lower()
        return ans == "y"

    def prompt_file() -> Optional[Path]:
        path = input("Path to custom quotes file (one quote per line, leave blank to clear): ").strip()
        if not path:
            return None
        p = Path(path)
        if p.exists():
            return p
        print("File not found. No custom file loaded.")
        return None

    def save_output(output_text: str):
        fname = input("Enter filename to save last output (leave blank to cancel): ").strip()
        if not fname:
            print("Save cancelled.")
            return
        try:
            Path(fname).write_text(output_text, encoding="utf-8")
            print(f"Saved to {fname}")
        except Exception as e:
            print("Failed to save file:", e)

    print("=== Dream Quotes Interactive with TTS ===")
    theme = ""
    count = 1
    unique = False
    extra_file: Optional[Path] = None
    last_output: Optional[str] = None
    auto_read = False  # If True, read aloud after showing quotes

    while True:
        print("\nOptions: [G]et quotes  [T]heme  [C]ount  [U]nique  [F]ile add/clear  [S]ave last  [R]ead last  [A]uto-read toggle  [Q]uit")
        choice = input("Choose an option (G/T/C/U/F/S/R/A/Q): ").strip().lower() or "g"

        if choice == "t":
            theme = prompt_theme()
            print(f"Theme set to: '{theme or 'mixed'}'")

        elif choice == "c":
            count = prompt_count()
            print(f"Count set to: {count}")

        elif choice == "u":
            unique = prompt_unique()
            print(f"Unique mode: {'ON' if unique else 'OFF'}")

        elif choice == "f":
            ef = prompt_file()
            extra_file = ef
            if extra_file:
                print(f"Custom file loaded: {extra_file}")
            else:
                print("Custom file cleared.")

        elif choice == "s":
            if last_output:
                save_output(last_output)
            else:
                print("No output to save yet. Get quotes first.")

        elif choice == "r":
            if last_output:
                print("Reading last output aloud...")
                tts_say(last_output)
            else:
                print("No output to read. Get quotes first.")

        elif choice == "a":
            auto_read = not auto_read
            print(f"Auto-read after showing quotes: {'ON' if auto_read else 'OFF'}")

        elif choice == "g":
            pool = build_pool(theme, extra_file)
            selected = pick_quotes(pool, count, unique)
            output = "\n".join(f"— {q}" for q in selected)
            last_output = output
            print("\n" + output + "\n")

            if auto_read:
                tts_say(output)

            post = input("Press Enter to return to menu (repeat) or type 'q' to quit: ").strip().lower()
            if post == "q":
                print("Goodbye.")
                sys.exit(0)
            # otherwise loop continues to menu

        elif choice == "q":
            print("Quitting. Take care.")
            break

        else:
            print("Unknown option. Try again.")

# ---------------------------
# Entry point
# ---------------------------
if __name__ == "__main__":
    interactive_main()
