#!/usr/bin/env python3
"""
Drunk Quote Generator — All features applied

Features:
- Large built-in QUOTES list
- Interactive repeat/quit mode (--repeat)
- Non-interactive count mode (--count N)
- Slur simulation with tunable drunk intensity (--drunk-intensity)
- Advanced slur behaviors: stutter, vowel elongation, consonant drop, repeats
- System TTS enabled by default (disable with --no-tts)
  - macOS: say (supports -v voice, -r rate)
  - Windows: PowerShell System.Speech (supports Rate, SelectVoice, SSML pitch)
  - Linux: espeak or spd-say (espeak supports -s speed, -p pitch, -v voice)
- TTS tuning flags: --tts-rate, --tts-voice, --tts-pitch
- No external Python packages required

Usage examples:
  python drunk_quotes.py
  python drunk_quotes.py --no-tts --count 5
  python drunk_quotes.py --repeat --drunk-intensity 0.9 --tts-rate 140
  python drunk_quotes.py --count 10 --slur --drunk-intensity 0.7
"""

import argparse
import random
import re
import shutil
import subprocess
import sys
import time

# -------------------------
# Full QUOTES list
# -------------------------
QUOTES = [
"Hey, did you ever notice how chairs are just polite tables?",
"I could swear my guitar knows more secrets than me.",
"Top man, top man, where's the top? I lost the top.",
"Copilot wants to help, but first, snacks.",
"Are you running Copilot as well, Harry? Or is that just me?",
"Go get a beer, man, and bring back a story.",
"We could write a program to get you drunk; step one: pour bytes.",
"Can you emulate being drunk? Sure, but I charge in hugs.",
"I'll put my guitar right here and then forget where here is.",
"I'm feeling depressed. Can I trip now, please? Asking for a friend.",
"It has to be in a special environment, like a blanket fort with plants.",
"They try to make the environment pretty comfortable; bring fuzzy socks.",
"Great testimonials, but do they include snacks and naps?",
"Why do socks disappear? Is there a sock economy I don't know about?",
"If life had a mute button I'd press it and then play guitar.",
"Sometimes I talk to my coffee and it judges me silently.",
"Music is just math that learned to dance.",
"Tell me a secret and I'll trade you a terrible joke.",
"I once tried to count the stars; they laughed and winked.",
"Do you think the moon gets lonely? I do, sometimes.",
"Hold my beer—metaphorically—I'm about to invent a new excuse.",
"I write songs for plants; they seem to prefer jazz.",
"Is it possible to be both lost and exactly where you need to be?",
"Why is everything sticky at 2 AM? Gravity's revenge, probably.",
"If I were a sandwich I'd be extra pickles and existential dread.",
"Sometimes I whisper to my guitar and it whispers back in chords.",
"Let's make a list of things we don't need and then buy them anyway.",
"Who decided socks should be single-file? Chaos would be better.",
"I could be a poet but my rhymes keep tripping over the couch.",
"Do you ever forget a word and then it becomes a new language?",
"Life hack: if you can't find the remote, become the remote.",
"That idea was brilliant until I tried to explain it out loud.",
"Keep your friends close and your snacks closer.",
"I have a PhD in almost remembering song lyrics.",
"Why do good ideas arrive when the lights are off? They're dramatic.",
"Sometimes the best plan is to nap and call it research.",
"If I had a dollar for every time I forgot, I'd still forget why.",
"Let's build a fort and declare it an independent nation.",
"Do you think plants gossip about us when we leave the room?",
"Pro tip: sing to your coffee; it might taste better.",
"I tried to be productive but my couch staged a protest.",
"Is it normal to have a favorite spoon? Asking for science.",
"That was a great idea until the idea asked for directions.",
"Keep calm and pretend you know the chords.",
"I could write a review but my pen is on strike.",
"Sometimes I misplace my keys and find a better life instead.",
"Why does the pizza always arrive faster than my motivation?",
"If you can't fix it, name it and call it art.",
"Let's be spontaneous tomorrow; plan it for 3 PM sharp.",
"My brain is buffering; please wait and try again later.",
"Do you ever feel like a character in someone else's playlist?",
"That thought was deep until I tripped on a pun.",
"Bring me coffee and I will consider forgiving you.",
"Who needs directions when you have confidence and a map app?",
"I have a very specific set of skills: losing pens, finding snacks.",
"Sometimes I speak fluent nonsense and it's surprisingly eloquent.",
"Let's make a mixtape for the plants and see what happens.",
"If life is a highway, mine has a lot of scenic detours.",
"Why do good ideas come with terrible timing? It's a conspiracy.",
"I could be an astronaut but I'm allergic to early mornings.",
"Do not disturb: genius at work; snacks required.",
"That was a brilliant plan until the cat vetoed it.",
"Keep your chin up and your coffee cup full.",
"I tried to be normal once; worst two minutes of my life.",
"Do you ever hug a pillow and feel like you solved a problem?",
"Let's invent a holiday where naps are mandatory and guilt is banned.",
"If music is food for the soul, I'm on a buffet diet.",
"Sometimes I write notes to myself and then forget where I put them.",
"Why is the best idea always the one you had in the shower?",
"I have a complicated relationship with my to-do list; it's complicated.",
"Be kind to your future self; they have to live with your choices.",
"I could tell you a secret but then I'd have to invent another one.",
"That joke was so bad it came back as a compliment.",
"Do you think clouds gossip about airplanes? Probably.",
"Let's make a plan to not make plans and call it progress.",
"If curiosity killed the cat, satisfaction brought it back with snacks.",
"I once tried to be serious; it didn't take.",
"Why is the remote always under the couch like it's hiding from responsibility?",
"Sometimes the best therapy is a ridiculous playlist and a window seat.",
"I have a theory that socks are tiny escape artists.",
"Keep your friends close and your playlists closer.",
"That idea was a masterpiece until I added glitter.",
"Do you ever feel like your thoughts are on shuffle?",
"Let's write a song about forgetting the chorus on purpose.",
"If life gives you lemons, make a lemon-themed mixtape.",
"I tried to be organized but my chaos had other plans.",
"Why do the best conversations happen at 3 AM? Time is dramatic.",
"Sometimes I practice being an adult and then I nap.",
"Bring me a pen and I will sign my own permission slip.",
"I could be a minimalist but I keep collecting feelings.",
"Do you ever apologize to inanimate objects? Me neither, mostly.",
"That was a great idea until the idea asked for coffee.",
"Keep your dreams big and your snacks within reach.",
"I once had a plan; it went on vacation without me.",
"Why is silence so loud when you're trying to think?",
"Let's make a list of things to forget and then forget the list.",
"If music had a flavor, mine would be midnight chocolate.",
"Sometimes I talk to my plants and they give better advice.",
"Do you ever lose time and find it in the couch cushions?",
"That thought was profound until I tripped on a pun.",
"I have a map of places I want to nap; it's very detailed.",
"Why do good ideas need a dramatic entrance? They're divas.",
"Keep your heart open and your playlist shuffled.",
"I tried to be punctual but my shoes had other ideas.",
"Do you ever feel like your brain is a browser with too many tabs?",
"Let's build a time machine out of coffee and optimism.",
"If life is a song, I'm still learning the bridge.",
"Sometimes the best plan is to improvise and call it art.",
"Why is the best advice always the hardest to follow?",
"I could be a philosopher but I prefer snack-based reasoning.",
"Do you ever write a note and then the note writes you back?",
"That was a brilliant thought until I added glitter and chaos.",
"Keep your curiosity loud and your worries on mute.",
"I tried to be decisive and then I took a nap to think it over.",
"Why do the best ideas arrive with terrible lighting?",
"Let's make a playlist for every mood and then ignore them all.",
"If you can't find the words, hum them until they show up.",
"Sometimes I forget the point and discover a better one instead.",
"Do you ever feel like your thoughts are on a scenic route?",
"That joke was so clever it needed a nap afterward.",
"I have a secret handshake with my coffee; it's complicated.",
"Why is the universe so dramatic? It loves an audience.",
"Keep your socks warm and your heart warmer.",
"I tried to be practical but my imagination filed a protest.",
"Do you ever misplace your patience and find it in the fridge?",
"Let's write a letter to our future selves and then misplace it.",
"If life had a pause button I'd use it for snack breaks.",
"Sometimes the best ideas are scribbled on napkins and forgotten.",
"Why do good plans require so many sticky notes?",
"I could be a morning person if mornings were optional.",
"Do you ever feel like your thoughts are on a coffee break?",
"That was a great idea until the idea asked for directions.",
"Keep your playlist weird and your coffee strong.",
"I tried to be serious but my socks laughed.",
"Do you ever talk to the moon and it answers in silence?",
"Let's make a pact to be delightfully unproductive sometimes.",
"If music were a color, mine would be midnight blue with glitter.",
"Sometimes I invent words and then use them with confidence.",
"Why is the best advice always wrapped in a terrible pun?",
"I could be a legend in my own lunchtime.",
"Do you ever lose an hour and find it in a song?",
"That thought was a masterpiece until I doodled on it.",
"Keep your curiosity messy and your plans flexible.",
"I tried to be efficient but my heart wanted to improvise.",
"Do you ever feel like your ideas are shy and need coaxing?",
"Let's celebrate small victories with big snacks.",
"If life is a puzzle, I'm missing a few corner pieces.",
"Sometimes the best conversations happen with the lights off.",
"Why do the best memories smell like coffee and rain?",
"I could be a superhero but my cape is in the laundry.",
"Do you ever write a list and then the list writes a novel?",
"That was a brilliant plan until the cat walked across the keyboard.",
"Keep your playlist loud and your doubts quiet.",
"I tried to be organized but my chaos had better handwriting.",
"Do you ever feel like your thoughts are on a scenic detour?",
"Let's make a mixtape for the future and label it 'maybe'.",
"If music had a language, I'd be fluent in humming.",
"Sometimes the best ideas arrive with a cup of tea and a nap."
]

# -------------------------
# Slur / drunk text transformation
# -------------------------
def slur_text(
    text,
    intensity=0.5,
    stutter_chance=0.12,
    elongate_chance=0.18,
    drop_consonant_chance=0.06,
    repeat_letter_base=0.12,
):
    """
    Transform text to sound more 'drunk' using multiple heuristics.
    intensity: 0.0-1.0 overall strength
    stutter_chance: base chance to stutter a word
    elongate_chance: base chance to elongate vowels
    drop_consonant_chance: base chance to drop consonants
    repeat_letter_base: base chance to repeat letters
    """
    if not text:
        return text

    def stutter_word(w):
        if len(w) > 1 and random.random() < stutter_chance * intensity:
            prefix_len = max(1, min(3, len(w) // 3))
            prefix = w[:prefix_len]
            # sometimes hyphenate, sometimes space
            sep = "-" if random.random() < 0.6 else " "
            return f"{prefix}{sep}{prefix}{w[prefix_len:]}"
        return w

    def elongate_vowels(w):
        if random.random() < elongate_chance * intensity:
            def repl(m):
                v = m.group(0)
                repeats = random.randint(2, 6 + int(6 * intensity))
                return v * repeats
            return re.sub(r'[aeiouAEIOU]', repl, w)
        return w

    def drop_consonants(w):
        if random.random() < drop_consonant_chance * intensity:
            out = []
            for ch in w:
                if ch.isalpha() and ch.lower() not in 'aeiou' and random.random() < 0.35 * intensity:
                    continue
                out.append(ch)
            return ''.join(out) or w
        return w

    def repeat_letters(w):
        out = []
        for ch in w:
            r = random.random()
            if ch.isalpha() and r < repeat_letter_base * intensity:
                repeats = random.randint(2, 4 + int(6 * intensity))
                out.append(ch * repeats)
            else:
                out.append(ch)
        return ''.join(out)

    words = re.split(r'(\s+)', text)  # keep whitespace tokens
    new_tokens = []
    for token in words:
        if token.isspace():
            new_tokens.append(token)
            continue
        w = token
        # small chance to mumble (drop whole word)
        if random.random() < 0.02 * intensity:
            # replace with a short mumble or filler
            mumble = random.choice(["...", "uh", "mm", "hic"])
            new_tokens.append(mumble)
            continue
        w = stutter_word(w)
        w = elongate_vowels(w)
        w = drop_consonants(w)
        w = repeat_letters(w)
        # random case mangling
        if random.random() < 0.06 * intensity:
            w = ''.join(ch.upper() if random.random() < 0.2 else ch for ch in w)
        new_tokens.append(w)

    s = ''.join(new_tokens)

    # insert hiccups/fillers mid-sentence sometimes
    if random.random() < 0.25 * intensity:
        fillers = ["hic", "uh", "mm", "huh", "bleh", "y'know"]
        pos = random.randint(0, len(s))
        s = s[:pos] + " " + random.choice(fillers) + " " + s[pos:]

    # add slurred punctuation and trailing ellipses
    if random.random() < 0.35 * intensity:
        s = re.sub(r'([,;:])', r'\1' + ('...' if random.random() < 0.6 else ''), s)
    if random.random() < 0.28 * intensity:
        s = s + ("..." * random.randint(1, 3))

    # mangle spacing occasionally
    if random.random() < 0.12 * intensity:
        s = s.replace(" ", "  ")

    # trim and return
    return s.strip()

# -------------------------
# Quote selection
# -------------------------
def random_quote(quotes, slur=False, intensity=0.5):
    q = random.choice(quotes)
    return slur_text(q, intensity=intensity) if slur else q

# -------------------------
# Cross-platform system TTS with rate/voice/pitch support
# -------------------------
def _tts_mac(text, rate=None, voice=None, pitch=None):
    # macOS 'say' supports -v voice and -r rate (words per minute)
    cmd = ["say"]
    if voice:
        cmd += ["-v", voice]
    if rate:
        # say uses -r for words per minute
        cmd += ["-r", str(int(rate))]
    # pitch not directly supported via say flags; could use 'osascript' or other tools for SSML
    cmd.append(text)
    try:
        subprocess.run(cmd, check=False)
        return True
    except Exception:
        return False

def _tts_windows(text, rate=None, voice=None, pitch=None):
    # Use PowerShell System.Speech.Synthesis.SpeechSynthesizer
    # Rate: -10..10 (int). Voice: name string. Pitch: use SSML prosody if provided.
    safe_text = text.replace('"', '`"')
    parts = []
    parts.append('Add-Type -AssemblyName System.Speech;')
    parts.append('$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;')
    if voice:
        # SelectVoice may throw if voice not found; that's okay
        parts.append(f'$s.SelectVoice("{voice}");')
    if rate is not None:
        # clamp rate to -10..10
        try:
            r = int(rate)
        except Exception:
            r = 0
        r = max(-10, min(10, r))
        parts.append(f'$s.Rate = {r};')
    if pitch is not None:
        # Use SSML to set pitch
        ssml = f'<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis"><prosody pitch="{pitch}">{safe_text}</prosody></speak>'
        # Use a here-string to pass SSML
        ps_cmd = ''.join(parts) + f'$s.SpeakSsml(@"{ssml}"@);'
    else:
        ps_cmd = ''.join(parts) + f'$s.Speak("{safe_text}");'
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
        return True
    except Exception:
        return False

def _tts_linux(text, rate=None, voice=None, pitch=None):
    # Try espeak first (supports -s speed, -p pitch, -v voice)
    if shutil.which("espeak"):
        cmd = ["espeak"]
        if rate:
            # espeak speed default ~175 wpm; -s sets words per minute
            cmd += ["-s", str(int(rate))]
        if pitch:
            # espeak pitch 0..99
            cmd += ["-p", str(int(pitch))]
        if voice:
            cmd += ["-v", voice]
        cmd += [text]
        try:
            subprocess.run(cmd, check=False)
            return True
        except Exception:
            pass
    # fallback to spd-say
    if shutil.which("spd-say"):
        cmd = ["spd-say"]
        if rate:
            cmd += ["-r", str(int(rate))]
        if voice:
            # spd-say voice selection is platform dependent; try passing as option
            cmd += ["-o", f"voice={voice}"]
        cmd += [text]
        try:
            subprocess.run(cmd, check=False)
            return True
        except Exception:
            pass
    return False

def speak_system(text, rate=None, voice=None, pitch=None):
    """Attempt to speak text using available system TTS. Returns True if spoken."""
    if not text or not text.strip():
        return False
    system = sys.platform
    try:
        if system == "darwin":
            return _tts_mac(text, rate=rate, voice=voice, pitch=pitch)
        if system.startswith("win"):
            return _tts_windows(text, rate=rate, voice=voice, pitch=pitch)
        # assume linux-like
        return _tts_linux(text, rate=rate, voice=voice, pitch=pitch)
    except Exception:
        return False

# -------------------------
# Interactive loop and main
# -------------------------
def interactive_loop(quotes, slur, intensity, delay, tts, tts_rate, tts_voice, tts_pitch):
    last = None
    while True:
        if last is None:
            last = random_quote(quotes, slur=slur, intensity=intensity)
        print("\n" + last)
        if tts:
            ok = speak_system(last, rate=tts_rate, voice=tts_voice, pitch=tts_pitch)
            if not ok:
                print("(TTS not available on this system or no TTS utility found.)")
        if delay:
            time.sleep(delay)
        try:
            choice = input("\nPress Enter for another, 'r' to repeat, 'q' to quit: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break
        if choice == 'q':
            print("Quitting. Cheers.")
            break
        if choice == 'r':
            # repeat same quote
            continue
        # any other input or empty means get a new quote
        last = None

def main(argv=None):
    parser = argparse.ArgumentParser(description="Random Drunk Quote Generator (TTS on by default)")
    parser.add_argument("--count", type=int, default=None, help="Number of quotes to print non-interactively")
    parser.add_argument("--slur", action="store_true", help="Enable slur simulation (alias for using drunk-intensity > 0)")
    parser.add_argument("--drunk-intensity", type=float, default=0.5, help="How drunk the slur should be 0.0-1.0 (default 0.5)")
    parser.add_argument("--delay", type=float, default=0.0, help="Delay between quotes in seconds")
    parser.add_argument("--repeat", action="store_true", help="Start interactive repeat/quit loop")
    # TTS enabled by default; --no-tts disables it
    parser.add_argument("--tts", dest="tts", action="store_true", help="Enable TTS (redundant; TTS is default)")
    parser.add_argument("--no-tts", dest="tts", action="store_false", help="Disable TTS")
    parser.set_defaults(tts=True)
    parser.add_argument("--tts-rate", type=float, default=None, help="TTS rate (platform-specific units)")
    parser.add_argument("--tts-voice", type=str, default=None, help="TTS voice name (platform-specific)")
    parser.add_argument("--tts-pitch", type=float, default=None, help="TTS pitch (platform-specific)")
    parser.add_argument("--file", type=str, default=None, help="Path to a text file with one quote per line")
    parser.add_argument("--no-randomize", action="store_true", help="If set with --count, will print the first N quotes instead of random ones")
    args = parser.parse_args(argv)

    # Normalize intensity and slur flag
    intensity = max(0.0, min(1.0, args.drunk_intensity))
    slur_flag = args.slur or (intensity > 0.0)

    quotes = QUOTES.copy()
    if args.file:
        try:
            with open(args.file, "r", encoding="utf-8") as f:
                file_quotes = [line.strip() for line in f if line.strip()]
                if file_quotes:
                    quotes = file_quotes
        except Exception as e:
            print(f"Warning: could not read file {args.file}: {e}", file=sys.stderr)

    # Non-interactive count mode
    if args.count is not None and not args.repeat:
        n = max(1, args.count)
        if args.no_randomize:
            # deterministic: first N quotes (wrap if needed)
            for i in range(n):
                q = quotes[i % len(quotes)]
                q_out = slur_text(q, intensity=intensity) if slur_flag else q
                print(q_out)
                if args.tts:
                    if not speak_system(q_out, rate=args.tts_rate, voice=args.tts_voice, pitch=args.tts_pitch):
                        print("(TTS not available on this system or no TTS utility found.)")
                if args.delay and i < n - 1:
                    time.sleep(args.delay)
        else:
            for i in range(n):
                q_out = random_quote(quotes, slur=slur_flag, intensity=intensity)
                print(q_out)
                if args.tts:
                    if not speak_system(q_out, rate=args.tts_rate, voice=args.tts_voice, pitch=args.tts_pitch):
                        print("(TTS not available on this system or no TTS utility found.)")
                if args.delay and i < n - 1:
                    time.sleep(args.delay)
        return

    # Interactive loop mode (default when no --count or when --repeat)
    interactive_loop(
        quotes,
        slur=slur_flag,
        intensity=intensity,
        delay=args.delay,
        tts=args.tts,
        tts_rate=args.tts_rate,
        tts_voice=args.tts_voice,
        tts_pitch=args.tts_pitch,
    )

if __name__ == "__main__":
    main()
