#!/usr/bin/env python3
"""
sloganizer.py — TTS toggle, seed-by-words narrowing, and dedicated RNG (no pip, no PIL)

Features:
- Cross-platform TTS using system tools (macOS `say`, Windows PowerShell System.Speech, Linux `espeak`/`spd-say`).
- Toggle automatic TTS on/off during interactive session with 't'.
- Set a reproducible random seed with --seed (int) or --seed-words (phrase).
- Seed words both produce a numeric seed and **narrow the quote pool** by matching words in quotes.
- Uses a dedicated `random.Random` instance derived from the seed so output is isolated and reproducible.
- Interactive controls:
    [Enter] = repeat
    a = add quote
    s = save last batch
    p = play last batch
    t = toggle auto-TTS
    e = enter seed words (deterministic + narrow pool)
    n = enter numeric seed (deterministic only)
    r = randomize seed (new random seed)
    c = change count
    q = quit
"""

import argparse
import random
import shutil
import subprocess
import sys
import hashlib
from pathlib import Path
from datetime import datetime

# Large built-in quotes list (restored)
QUOTES = [
    "Make it loud; make it matter.",
    "Break rules, build songs.",
    "Small amps, big heart.",
    "Turn the volume up on life.",
    "Chaos with a melody.",
    "Rebel, then repeat.",
    "Keep it raw, keep it real.",
    "Noise with purpose.",
    "Scratch the surface, find the truth.",
    "Fast chords, slow regrets.",
    "Ink-stained lyrics, neon nights.",
    "Distortion is a love language.",
    "Sing like the roof is on fire.",
    "Punk is patience in a hurry.",
    "Beat the drum, break the mold.",
    "Static on the radio, clarity in the soul.",
    "Shout soft, mean it loud.",
    "Grit, grace, and a broken string.",
    "Rhythms for restless hearts.",
    "Edge of the map, center of the song.",
    "Two chords and a revolution.",
    "Melody with a middle finger.",
    "Hustle in the verse, honesty in the chorus.",
    "Echoes of yesterday, anthems for tomorrow.",
    "Leather jacket, open mind.",
    "Fast life, honest lines.",
    "Sparks in the silence.",
    "Sing the city awake.",
    "Broken strings, whole stories.",
    "Rewind the past, remix the future.",
    "Pavement poetry, alleyway anthems.",
    "Gutter glam and neon truth.",
    "Rhythm is the rebellion.",
    "Keep the chorus, lose the fear.",
    "Louder than your doubts.",
    "Midnight riffs, morning clarity.",
    "Turn the static into signal.",
    "Anthems for the almost-famous.",
    "Make the chorus count.",
    "Noise that heals.",
    "Punk with a pulse.",
    "Sonic snapshots of the street.",
    "Sing like nobody's watching, play like everyone is.",
    "Velvet voice, iron will.",
    "Hollow chords, full hearts.",
    "Rattle the rafters, soften the edges.",
    "Gritty verses, golden hooks.",
    "Rebel rhythms, tender truths.",
    "Amplify the ordinary.",
    "Scream the question, hum the answer.",
    "Rhythms that refuse to sit down.",
    "Anthems stitched from midnight.",
    "Turn the mundane into magic.",
    "A chorus for the curious.",
    "Punk poetry, pop promise.",
    "Shards of sound, whole intentions.",
    "Sing the scratch marks off the map.",
    "Electric honesty.",
    "Make the bridge the destination.",
    "Noise that knows your name.",
    "Hymns for the half-awake.",
    "Beat-driven bravery.",
    "Sing like you mean it, play like you own it.",
    "Riffs that remember.",
    "Melodies with a mission.",
    "Streetlight serenades.",
    "Grit, glamour, and good timing.",
    "Turn the dial to defiant.",
    "Anthems for the in-between.",
    "Punk heart, pop hooks.",
    "Sing the small things loudly.",
    "Rhythms that refuse to apologize.",
    "Make the chorus a promise.",
    "Static hearts, steady hands.",
    "Noise that nurtures.",
    "Sing the cracks into constellations.",
    "Loud kindness.",
    "Rebel softly, sing boldly.",
    "Chords that cut clean.",
    "Melody as manifesto.",
    "Turn the chorus into a crowd.",
    "Hollow out the fear, fill it with sound.",
    "Anthems for the awake and aching.",
    "Play the truth, even if it hurts.",
    "Sonic snapshots of the soul.",
    "Punk is a question mark with a megaphone.",
    "Sing the city’s secrets.",
    "Riffs that refuse to retire.",
    "Make the bridge unforgettable.",
    "Noise with a neighborhood.",
    "Sing the streetlights are listening.",
    "Melodies that mend.",
    "Turn the chorus into a ritual.",
    "Punk is patience with a pulse.",
    "Anthems for the unpolished.",
    "Sing the edges into focus.",
    "Rattle the quiet, then soothe it.",
    "Make the verse a victory lap.",
    "Noise that remembers names.",
    "Sing the scars into stories.",
    "Melody with a backbone.",
    "Turn the chorus into a compass.",
    "Punk is a promise kept loud.",
    "Anthems for the restless and ready.",
    "Sing the small rebellions.",
    "Riffs that run like rivers.",
    "Make the bridge a beacon.",
    "Noise that invites you in.",
    "Sing the night into a map.",
    "Melodies that move mountains.",
    "Turn the chorus into a conversation.",
    "Punk is poetry with a pulse.",
    "Anthems for the almost-there.",
    "Sing the ordinary into legend.",
    "Riffs that refuse to be polite.",
    "Make the bridge a doorway.",
    "Noise that feels like home.",
    "Sing the silence awake.",
    "Melody that keeps its promises.",
    "Turn the chorus into a crowd-sourced truth.",
    "Punk is a wink and a war cry.",
    "Anthems for the unafraid.",
    "Sing the small victories loudly.",
    "Riffs that remember where you came from.",
    "Make the bridge a handshake.",
    "Noise that comforts and confronts.",
    "Sing the city into a chorus.",
    "Melodies that hold you up.",
    "Turn the chorus into a pact.",
    "Punk is a map with no borders.",
    "Anthems for the late-night thinkers.",
    "Sing the cracks into art.",
    "Riffs that refuse to be tamed.",
    "Make the bridge a promise kept.",
    "Noise that tells the truth softly.",
    "Sing the ordinary into something holy.",
    "Melodies that keep you moving.",
    "Turn the chorus into a lighthouse.",
    "Punk is a heartbeat in the dark.",
    "Anthems for the brave and bewildered.",
    "Sing the small rebellions into ritual.",
    "Riffs that run on caffeine and conviction.",
    "Make the bridge a shared secret.",
    "Noise that opens doors.",
    "Sing the night into a neighborhood.",
    "Melodies that mend the margins.",
    "Turn the chorus into a celebration.",
    "Punk is a promise to keep trying.",
    "Anthems for the hopeful misfits.",
    "Sing the cracks into constellations.",
    "Riffs that refuse to be forgotten.",
    "Make the bridge a place to land.",
    "Noise that heals in public.",
    "Sing the small things into legend.",
    "Melodies that make mornings possible.",
    "Turn the chorus into a community.",
    "Punk is a grin and a clenched fist.",
    "Anthems for the ones who keep going.",
    "Sing the ordinary into extraordinary.",
    "Riffs that remember the road.",
    "Make the bridge a shared heartbeat.",
    "Noise that invites you to stay.",
    "Sing the silence into sound.",
    "Melodies that carry you home.",
    "Turn the chorus into a promise.",
    "Punk is a spark that refuses to die.",
    "Anthems for the late-night dreamers.",
    "Sing the small rebellions into songs.",
    "Riffs that run on truth.",
    "Make the bridge a place of arrival.",
    "Noise that feels like a friend.",
    "Sing the city into a story.",
    "Melodies that keep the lights on.",
    "Turn the chorus into a vow.",
    "Punk is a light in the alley.",
    "Anthems for the ones who show up."
]

def load_quotes_from_file(path):
    p = Path(path)
    if not p.exists():
        return []
    return [line.strip() for line in p.read_text(encoding="utf-8").splitlines() if line.strip()]

def stylize(quote, style=None, emoji=None, hashtag=None, repeat=1, punctuation="!"):
    s = quote.strip()
    if style == "uppercase":
        s = s.upper()
    elif style == "title":
        s = s.title()
    elif style == "lower":
        s = s.lower()
    if not s.endswith(tuple(".!?")):
        s = s + punctuation
    parts = [s]
    if emoji:
        parts.insert(0, emoji)
    if hashtag:
        parts.append(f"#{hashtag}")
    slogan = " ".join(parts)
    if repeat > 1:
        slogan = " ".join([slogan] * repeat)
    return slogan

# -------------------------
# Seed-from-words utilities
# -------------------------
def seed_from_words(words: str, bits: int = 31) -> int:
    """
    Convert an arbitrary string into a deterministic integer seed.
    Uses SHA-256 and reduces to `bits` bits.
    """
    if words is None:
        words = ""
    h = hashlib.sha256(words.encode("utf-8")).hexdigest()
    val = int(h, 16) & ((1 << bits) - 1)
    return val

def filter_quotes_by_seed_words(quotes, seed_words, match_all=True):
    """
    Narrow the quote pool by seed_words.
    - seed_words: string of words/phrases (space separated)
    - match_all: if True, require all tokens to be present in a quote (AND).
                 if False, require any token to be present (OR).
    Matching is case-insensitive and checks for token substrings.
    Returns the filtered list (may be empty).
    """
    if not seed_words:
        return quotes.copy()
    tokens = [t.strip().lower() for t in seed_words.split() if t.strip()]
    if not tokens:
        return quotes.copy()
    filtered = []
    for q in quotes:
        ql = q.lower()
        if match_all:
            if all(tok in ql for tok in tokens):
                filtered.append(q)
        else:
            if any(tok in ql for tok in tokens):
                filtered.append(q)
    return filtered

# -------------------------
# Generation using a dedicated RNG
# -------------------------
def generate_slogans(quotes, count=3, rng=None, style=None, emoji=None, hashtag=None, repeat=1, unique=False):
    """
    Use the provided rng (random.Random instance) for all randomness.
    If rng is None, fall back to module-level random.
    """
    if not quotes:
        return []
    if rng is None:
        rng = random
    slogans = []
    if unique and count <= len(quotes):
        chosen = rng.sample(quotes, count)
        for q in chosen:
            slogans.append(stylize(q, style=style, emoji=emoji, hashtag=hashtag, repeat=repeat))
    else:
        for _ in range(count):
            q = rng.choice(quotes)
            slogans.append(stylize(q, style=style, emoji=emoji, hashtag=hashtag, repeat=repeat))
    return slogans

def save_slogans_to_file(slogans, path=None):
    if path is None:
        path = f"slogans_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    Path(path).write_text("\n".join(slogans), encoding="utf-8")
    return path

# -------------------------
# Simple cross-platform TTS
# -------------------------
def _has_cmd(cmd):
    return shutil.which(cmd) is not None

def speak_text(text, voice=None, rate=None):
    """
    Speak `text` using available OS tools.
    Returns True if a TTS backend was invoked, False otherwise.
    """
    if not text:
        return False

    platform = sys.platform
    # macOS: use `say`
    if platform == "darwin" and _has_cmd("say"):
        cmd = ["say"]
        if voice:
            cmd += ["-v", voice]
        if rate:
            cmd += ["-r", str(rate)]
        try:
            subprocess.run(cmd, input=text.encode("utf-8"), check=False)
            return True
        except Exception:
            return False

    # Windows: PowerShell System.Speech
    if platform.startswith("win"):
        ps_script = (
            "Add-Type -AssemblyName System.speech;"
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        )
        if voice:
            ps_script += f"try {{$s.SelectVoice('{voice}')}} catch {{}};"
        if rate is not None:
            ps_script += f"$s.Rate = {int(rate)};"
        ps_script += "$text = [Console]::In.ReadToEnd(); $s.Speak($text);"
        cmd = ["powershell", "-NoProfile", "-Command", ps_script]
        try:
            subprocess.run(cmd, input=text.encode("utf-8"), check=False)
            return True
        except Exception:
            return False

    # Linux: try espeak then spd-say
    if _has_cmd("espeak"):
        cmd = ["espeak"]
        if voice:
            cmd += ["-v", voice]
        if rate:
            cmd += ["-s", str(rate)]
        try:
            subprocess.run(cmd, input=text.encode("utf-8"), check=False)
            return True
        except Exception:
            return False
    if _has_cmd("spd-say"):
        cmd = ["spd-say"]
        if voice:
            cmd += ["-o", voice]
        try:
            subprocess.run(cmd + [text], check=False)
            return True
        except Exception:
            return False

    return False

# -------------------------
# CLI and interactive loop
# -------------------------
def parse_args():
    p = argparse.ArgumentParser(description="Turn quotes into slogans")
    p.add_argument("--file", help="Path to a text file with one quote per line")
    p.add_argument("--count", type=int, default=None, help="Number of slogans to generate per batch (if omitted you'll be prompted)")
    p.add_argument("--style", choices=["uppercase", "title", "lower"], help="Text style")
    p.add_argument("--emoji", help="Emoji to prepend")
    p.add_argument("--hashtag", help="Hashtag to append (without #)")
    p.add_argument("--repeat", type=int, default=1, help="Repeat slogan for emphasis")
    p.add_argument("--save", help="Save first generated batch to file and exit (optional)")
    p.add_argument("--unique", action="store_true", help="Try to make each batch unique (no duplicates within a batch)")
    p.add_argument("--tts", action="store_true", help="Start with auto-TTS enabled")
    p.add_argument("--tts-voice", help="Preferred TTS voice name (platform-dependent)")
    p.add_argument("--tts-rate", type=int, help="Preferred TTS rate (platform-dependent)")
    p.add_argument("--seed", type=int, default=None, help="Optional integer seed for reproducible output")
    p.add_argument("--seed-words", type=str, default=None, help="Optional seed phrase (words) for reproducible output and narrowing")
    p.add_argument("--seed-match-any", action="store_true", help="If set, seed words match any token (OR). Default is match all tokens (AND).")
    return p.parse_args()

def prompt_for_count(default=3):
    while True:
        try:
            raw = input(f"How many slogans per batch? (default {default}): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nNo input; using default.")
            return default
        if raw == "":
            return default
        try:
            n = int(raw)
            if n < 1:
                print("Please enter a positive integer.")
                continue
            return n
        except ValueError:
            print("Please enter a valid integer.")

def prompt_for_seed_words(default=None):
    try:
        raw = input(f"Enter seed words (blank to cancel){' ['+str(default)+']' if default else ''}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nNo input; seed words unchanged.")
        return None
    if raw == "":
        return None
    return raw

def prompt_for_numeric_seed(default=None):
    try:
        raw = input(f"Enter integer seed (blank to cancel){' ['+str(default)+']' if default is not None else ''}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nNo input; seed unchanged.")
        return None
    if raw == "":
        return None
    try:
        return int(raw)
    except ValueError:
        print("Invalid integer.")
        return None

def interactive_loop(quotes, args, batch_count, initial_seed_words, initial_seed_int, match_any):
    pool = quotes.copy()
    last_batch = []
    tts_enabled = bool(args.tts)

    # Track both forms: words and numeric seed
    seed_words = initial_seed_words
    numeric_seed = initial_seed_int

    # Create a dedicated RNG instance and filtered pool
    if seed_words is not None:
        numeric_seed = seed_from_words(seed_words)
        rng = random.Random(numeric_seed)
        filtered_pool = filter_quotes_by_seed_words(pool, seed_words, match_all=not match_any)
    elif numeric_seed is not None:
        rng = random.Random(numeric_seed)
        filtered_pool = pool.copy()
    else:
        rng = random.Random()  # non-deterministic
        filtered_pool = pool.copy()

    print("\n--- Sloganizer Interactive Mode ---")
    print("Controls after each batch: [Enter]=repeat, a=add quote, s=save last batch, p=play last batch, t=toggle auto-TTS, e=enter seed words, n=enter numeric seed, r=randomize seed, c=change count, q=quit\n")
    print(f"Auto-TTS is {'ON' if tts_enabled else 'OFF'} (toggle with 't').")
    if seed_words:
        print(f"Seed words: \"{seed_words}\"  -> numeric seed: {numeric_seed}")
        print(f"Filtered pool size: {len(filtered_pool)} (match {'ANY' if match_any else 'ALL'})")
    elif numeric_seed is not None:
        print(f"Numeric seed: {numeric_seed}")
    else:
        print("Seed: None (non-deterministic)")
    print()

    while True:
        # Decide which pool to use: filtered_pool if non-empty, otherwise fallback to full pool
        active_pool = filtered_pool if filtered_pool else pool
        if not active_pool:
            print("No quotes available to generate from.")
            break

        # Generate batch using the dedicated rng and the active pool
        last_batch = generate_slogans(
            active_pool,
            count=batch_count,
            rng=rng,
            style=args.style,
            emoji=args.emoji,
            hashtag=args.hashtag,
            repeat=max(1, args.repeat),
            unique=args.unique
        )

        print("\nGenerated slogans:\n")
        for i, s in enumerate(last_batch, 1):
            print(f"{i}. {s}")
        print()

        # Auto-TTS if enabled
        if tts_enabled:
            tts_worked = True
            for s in last_batch:
                ok = speak_text(s, voice=args.tts_voice, rate=args.tts_rate)
                if not ok:
                    tts_worked = False
                    break
            if not tts_worked:
                print("TTS backend not available or failed. Auto-TTS has been turned OFF.")
                tts_enabled = False

        try:
            cmd = input("Press Enter to repeat, 'a' to add quote, 's' to save last batch, 'p' to play last batch, 't' to toggle TTS, 'e' to enter seed words, 'n' to enter numeric seed, 'r' to randomize seed, 'c' to change count, 'q' to quit: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if cmd == "q":
            print("Quitting. Bye.")
            break
        elif cmd == "a":
            try:
                new = input("Type new quote to add (or press Enter to cancel): ").strip()
            except (EOFError, KeyboardInterrupt):
                new = ""
            if new:
                pool.append(new)
                # If seed words are active, re-filter to include the new quote if it matches
                if seed_words:
                    filtered_pool = filter_quotes_by_seed_words(pool, seed_words, match_all=not match_any)
                else:
                    filtered_pool = pool.copy()
                print("Added.")
            else:
                print("No quote added.")
        elif cmd == "s":
            if last_batch:
                filename = save_slogans_to_file(last_batch)
                print(f"Saved last batch to {filename}")
            else:
                print("Nothing to save.")
        elif cmd == "p":
            if last_batch:
                for s in last_batch:
                    ok = speak_text(s, voice=args.tts_voice, rate=args.tts_rate)
                    if not ok:
                        print("TTS backend not available or failed.")
                        break
            else:
                print("No batch to play.")
        elif cmd == "t":
            tts_enabled = not tts_enabled
            print(f"Auto-TTS is now {'ON' if tts_enabled else 'OFF'}.")
        elif cmd == "e":
            new_words = prompt_for_seed_words(default=seed_words)
            if new_words is not None:
                seed_words = new_words
                numeric_seed = seed_from_words(seed_words)
                rng = random.Random(numeric_seed)
                filtered_pool = filter_quotes_by_seed_words(pool, seed_words, match_all=not match_any)
                print(f"Seed words set to \"{seed_words}\" -> numeric seed {numeric_seed}.")
                print(f"Filtered pool size: {len(filtered_pool)} (match {'ANY' if match_any else 'ALL'})")
            else:
                print("Seed words unchanged.")
        elif cmd == "n":
            new_num = prompt_for_numeric_seed(default=numeric_seed)
            if new_num is not None:
                numeric_seed = new_num
                seed_words = None
                rng = random.Random(numeric_seed)
                filtered_pool = pool.copy()
                print(f"Numeric seed set to {numeric_seed}. Output is now reproducible.")
            else:
                print("Numeric seed unchanged.")
        elif cmd == "r":
            # create a new random seed using system randomness and apply it
            new_seed = random.SystemRandom().randint(0, 2**31 - 1)
            numeric_seed = new_seed
            seed_words = None
            rng = random.Random(numeric_seed)
            filtered_pool = pool.copy()
            print(f"Randomized numeric seed set to {numeric_seed}.")
        elif cmd == "c":
            batch_count = prompt_for_count(default=batch_count)
            print(f"Batch count set to {batch_count}.")
        else:
            # any other input (including empty) repeats the loop using the same count
            continue

def main():
    args = parse_args()
    quotes = QUOTES.copy()
    if args.file:
        file_quotes = load_quotes_from_file(args.file)
        if file_quotes:
            quotes = file_quotes

    # Determine batch count: prefer CLI arg; otherwise prompt the user
    if args.count is None:
        batch_count = prompt_for_count(default=3)
    else:
        batch_count = max(1, args.count)

    # Seed handling: prefer seed-words, then numeric seed, else None
    seed_words = None
    seed_int = None
    rng = None
    match_any = bool(args.seed_match_any)

    if args.seed_words:
        seed_words = args.seed_words
        seed_int = seed_from_words(seed_words)
        rng = random.Random(seed_int)
        print(f"Using seed words \"{seed_words}\" -> numeric seed {seed_int} for reproducible output.")
    elif args.seed is not None:
        seed_int = args.seed
        rng = random.Random(seed_int)
        print(f"Using numeric seed {seed_int} for reproducible output.")
    else:
        rng = random.Random()  # non-deterministic until user sets a seed

    # If user asked to save and exit immediately, generate once and save (use dedicated rng and filtering)
    if args.save:
        # apply seed-words narrowing if provided
        active_pool = filter_quotes_by_seed_words(quotes, args.seed_words, match_all=not match_any) if args.seed_words else quotes
        slogans = generate_slogans(
            active_pool,
            count=batch_count,
            rng=rng,
            style=args.style,
            emoji=args.emoji,
            hashtag=args.hashtag,
            repeat=max(1, args.repeat),
            unique=args.unique
        )
        Path(args.save).write_text("\n".join(slogans), encoding="utf-8")
        print(f"Saved {len(slogans)} slogans to {args.save}")
        # Optionally speak once if requested via --tts
        if args.tts:
            for s in slogans:
                if not speak_text(s, voice=args.tts_voice, rate=args.tts_rate):
                    print("TTS backend not available or failed.")
                    break
        return

    # Otherwise enter interactive repeat-and-quit loop (uses user-provided count and seed)
    interactive_loop(quotes, args, batch_count, seed_words, seed_int, match_any)

if __name__ == "__main__":
    main()
