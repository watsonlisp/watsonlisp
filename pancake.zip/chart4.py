#!/usr/bin/env python3
"""
plot_maker_pie_exact.py

Create pie charts and bar graphs from console input using only Python's standard
library (tkinter). This version ensures the pie chart slices exactly match the
displayed percentages which are rounded and adjusted to sum to 100.0%.

Usage:
    $ python plot_maker_pie_exact.py
    Chart type (pie/bar): pie
    Title (optional): Market share
    Number of categories: 3
    Category 1 label: A
    Category 1 value: 40
    Category 2 label: B
    Category 2 value: 35
    Category 3 label: C
    Category 3 value: 25
    Show percentages? (y/n) [y]: y
    Explode which slice (label or leave empty): B
    (Window opens showing the pie chart; slices correspond to rounded percentages summing to 100.0%)
"""

import sys
import math
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

# ---------------------------
# Input helpers
# ---------------------------


def prompt_loop(prompt, cast=str, validator=None, error_msg="Invalid input."):
    while True:
        try:
            raw = input(prompt).strip()
            if raw == "" and cast is str:
                val = ""
            else:
                val = cast(raw)
            if validator is None or validator(val):
                return val
        except Exception:
            pass
        print(error_msg)


def yes_no(prompt, default=True):
    raw = input(prompt).strip().lower()
    if raw == "":
        return default
    return raw in ("y", "yes")


def positive_int_validator(x):
    return isinstance(x, int) and x > 0


def numeric_validator(x):
    return isinstance(x, (int, float)) and not math.isnan(x)


def ensure_labels(labels):
    return [lbl if lbl and str(lbl).strip() != "" else f"Category {i+1}" for i, lbl in enumerate(labels)]


# ---------------------------
# Color palette
# ---------------------------

PALETTE = [
    "#4E79A7", "#F28E2B", "#E15759", "#76B7B2", "#59A14F",
    "#EDC948", "#B07AA1", "#FF9DA7", "#9C755F", "#BAB0AC"
]


def color_for(i):
    return PALETTE[i % len(PALETTE)]


# ---------------------------
# Percentage and angle adjustment
# ---------------------------


def compute_exact_percentages_and_angles(values, decimals=1):
    """
    Compute rounded percentages that sum exactly to 100.0 (to `decimals`) and
    compute angles (degrees) that sum exactly to 360.0 so slices match displayed percentages.

    Returns:
        rounded_percentages: list of floats (rounded to `decimals`) summing to 100.0
        angles: list of floats (degrees) summing to 360.0 corresponding to rounded_percentages
    """
    total = sum(values)
    if total <= 0 or not math.isfinite(total):
        raise ValueError("Values must sum to a positive finite number.")

    raw_pcts = [(v / total) * 100.0 for v in values]
    factor = 10 ** decimals

    # Round each percentage to the requested decimals
    rounded = [math.floor(p * factor + 0.5) / factor for p in raw_pcts]

    # Adjust rounding error so percentages sum to exactly 100.0
    pct_diff = round(100.0 - sum(rounded), decimals)
    if abs(pct_diff) > 0:
        max_idx = max(range(len(raw_pcts)), key=lambda i: raw_pcts[i])
        rounded[max_idx] = round(rounded[max_idx] + pct_diff, decimals)

    # Final safety: tiny residual fix
    total_rounded = round(sum(rounded), decimals)
    if total_rounded != round(100.0, decimals):
        residual = round(100.0 - total_rounded, decimals)
        max_idx = max(range(len(raw_pcts)), key=lambda i: raw_pcts[i])
        rounded[max_idx] = round(rounded[max_idx] + residual, decimals)

    # Compute angles from rounded percentages
    angles = [p / 100.0 * 360.0 for p in rounded]

    # Ensure angles sum to exactly 360.0 by adjusting the largest slice
    angle_sum = sum(angles)
    angle_residual = 360.0 - angle_sum
    if abs(angle_residual) > 1e-9:
        max_idx = max(range(len(angles)), key=lambda i: angles[i])
        angles[max_idx] = angles[max_idx] + angle_residual

    # Final numeric cleanup: round angles to a reasonable precision
    angles = [float(round(a, 10)) for a in angles]

    return rounded, angles


# ---------------------------
# Drawing with tkinter Canvas
# ---------------------------


class PlotWindow:
    def __init__(self, title="Chart", width=800, height=600, bg="white"):
        self.root = tk.Tk()
        self.root.title(title or "Chart")
        self.width = width
        self.height = height
        self.canvas = tk.Canvas(self.root, width=width, height=height, bg=bg)
        self.canvas.pack(fill="both", expand=True)
        toolbar = ttk.Frame(self.root)
        toolbar.pack(fill="x", side="bottom")
        self.save_btn = ttk.Button(toolbar, text="Save as PostScript", command=self.save_dialog)
        self.save_btn.pack(side="right", padx=6, pady=6)
        self.close_btn = ttk.Button(toolbar, text="Close", command=self.root.destroy)
        self.close_btn.pack(side="right", padx=6, pady=6)

    def save_dialog(self):
        name = input("Enter filename to save PostScript (e.g., chart.ps): ").strip()
        if not name:
            print("Save cancelled.")
            return
        if not name.lower().endswith(".ps"):
            name += ".ps"
        try:
            self.canvas.postscript(file=name)
            print(f"Saved canvas to {name} (PostScript). Convert externally to PNG/PDF if needed.")
            messagebox.showinfo("Saved", f"Saved PostScript to: {name}")
        except Exception as e:
            print("Error saving:", e)
            messagebox.showerror("Save error", str(e))

    def mainloop(self):
        self.root.mainloop()


def draw_pie(canvas, center, radius, labels, values, title="", show_percent=True, explode_label=None):
    """
    Draw a pie chart where displayed percentages and slice angles match exactly.
    """
    x0, y0 = center
    total = sum(values)
    if total <= 0 or not math.isfinite(total):
        raise ValueError("Pie values must sum to a positive finite number.")

    # Get percentages and angles that exactly match
    pct_list, angles = compute_exact_percentages_and_angles(values, decimals=1)

    start = 90.0  # start at top
    bbox = (x0 - radius, y0 - radius, x0 + radius, y0 + radius)

    # determine explode index
    explode_idx = None
    if explode_label:
        for i, lbl in enumerate(labels):
            if lbl.lower() == explode_label.lower():
                explode_idx = i
                break

    # draw slices using angles derived from rounded percentages
    for i, extent in enumerate(angles):
        offset_x = offset_y = 0.0
        if explode_idx == i:
            mid_angle = math.radians(start - extent / 2.0)
            offset_x = math.cos(mid_angle) * (radius * 0.08)
            offset_y = -math.sin(mid_angle) * (radius * 0.08)

        bx0 = bbox[0] + offset_x
        by0 = bbox[1] + offset_y
        bx1 = bbox[2] + offset_x
        by1 = bbox[3] + offset_y

        # draw slice
        canvas.create_arc(bx0, by0, bx1, by1, start=start, extent=extent, fill=color_for(i), outline="white", width=1)

        # label position: halfway along slice
        mid_angle = math.radians(start - extent / 2.0)
        label_r = radius * 0.65
        lx = x0 + math.cos(mid_angle) * label_r + offset_x
        ly = y0 - math.sin(mid_angle) * label_r + offset_y

        if show_percent:
            pct_text = f"{pct_list[i]:.1f}%"
            text = f"{labels[i]} ({pct_text})"
        else:
            text = labels[i]

        canvas.create_text(lx, ly, text=text, fill="black", font=("Arial", 10), anchor="center")
        start -= extent

    if title:
        canvas.create_text(x0, y0 - radius - 20, text=title, font=("Arial", 14, "bold"), anchor="s")


def draw_bar(canvas, origin, size, labels, values, title="", orientation="vertical", grouped=False, series_names=None):
    ox, oy = origin
    w, h = size
    left = ox + 60
    top = oy + 40
    right = ox + w - 20
    bottom = oy + h - 60
    plot_w = right - left
    plot_h = bottom - top
    canvas.create_rectangle(left - 1, top - 1, right + 1, bottom + 1, outline="#ddd", fill="#fff")
    n = len(labels)

    if not grouped:
        vals = values
        maxv = max(vals) if vals else 0
        maxv = max(maxv, 1e-6)
        if orientation == "vertical":
            bar_w = plot_w / (n * 1.2)
            spacing = (plot_w - n * bar_w) / (n + 1)
            for i, v in enumerate(vals):
                x1 = left + spacing + i * (bar_w + spacing)
                x2 = x1 + bar_w
                hgt = (v / maxv) * (plot_h * 0.9)
                y2 = bottom
                y1 = bottom - hgt
                canvas.create_rectangle(x1, y1, x2, y2, fill=color_for(i), outline="black")
                canvas.create_text((x1 + x2) / 2, y2 + 12, text=labels[i], anchor="n", font=("Arial", 9))
                canvas.create_text((x1 + x2) / 2, y1 - 8, text=f"{v:.2f}", anchor="s", font=("Arial", 9))
        else:
            bar_h = plot_h / (n * 1.2)
            spacing = (plot_h - n * bar_h) / (n + 1)
            for i, v in enumerate(vals):
                y1 = top + spacing + i * (bar_h + spacing)
                y2 = y1 + bar_h
                wdt = (v / maxv) * (plot_w * 0.9)
                x1 = left
                x2 = left + wdt
                canvas.create_rectangle(x1, y1, x2, y2, fill=color_for(i), outline="black")
                canvas.create_text(left - 8, (y1 + y2) / 2, text=labels[i], anchor="e", font=("Arial", 9))
                canvas.create_text(x2 + 18, (y1 + y2) / 2, text=f"{v:.2f}", anchor="w", font=("Arial", 9))
    else:
        series = values
        num_series = len(series)
        maxv = max(max(max(s) if s else 0 for s in series), 1e-6)
        if orientation == "vertical":
            group_w = plot_w / (n * 1.05)
            single_w = group_w / num_series * 0.9
            spacing = (plot_w - n * group_w) / (n + 1)
            for i in range(n):
                group_x = left + spacing + i * (group_w + spacing)
                for sidx in range(num_series):
                    v = series[sidx][i]
                    x1 = group_x + sidx * single_w
                    x2 = x1 + single_w * 0.9
                    hgt = (v / maxv) * (plot_h * 0.9)
                    y2 = bottom
                    y1 = bottom - hgt
                    canvas.create_rectangle(x1, y1, x2, y2, fill=color_for(sidx), outline="black")
                    canvas.create_text((group_x + group_x + group_w) / 2, bottom + 12, text=labels[i], anchor="n", font=("Arial", 9))
                    canvas.create_text((x1 + x2) / 2, y1 - 6, text=f"{v:.2f}", anchor="s", font=("Arial", 8))
        else:
            group_h = plot_h / (n * 1.05)
            single_h = group_h / num_series * 0.9
            spacing = (plot_h - n * group_h) / (n + 1)
            for i in range(n):
                group_y = top + spacing + i * (group_h + spacing)
                for sidx in range(num_series):
                    v = series[sidx][i]
                    y1 = group_y + sidx * single_h
                    y2 = y1 + single_h * 0.9
                    wdt = (v / maxv) * (plot_w * 0.9)
                    x1 = left
                    x2 = left + wdt
                    canvas.create_rectangle(x1, y1, x2, y2, fill=color_for(sidx), outline="black")
                    canvas.create_text(left - 8, group_y + group_h / 2, text=labels[i], anchor="e", font=("Arial", 9))
                    canvas.create_text(x2 + 12, (y1 + y2) / 2, text=f"{v:.2f}", anchor="w", font=("Arial", 8))

        if series_names:
            legend_x = right - 120
            legend_y = top + 6
            for sidx, name in enumerate(series_names):
                canvas.create_rectangle(legend_x, legend_y + sidx * 18, legend_x + 12, legend_y + 12 + sidx * 18, fill=color_for(sidx), outline="black")
                canvas.create_text(legend_x + 18, legend_y + 6 + sidx * 18, text=name, anchor="w", font=("Arial", 9))

    if title:
        canvas.create_text((left + right) / 2, oy + 18, text=title, font=("Arial", 14, "bold"), anchor="n")


# ---------------------------
# Input flows
# ---------------------------


def collect_pie():
    title = input("Title (optional): ").strip()
    n = prompt_loop("Number of categories: ", cast=int, validator=positive_int_validator, error_msg="Enter a positive integer.")
    labels = []
    values = []
    for i in range(1, n + 1):
        lbl = input(f"Category {i} label (leave empty for default): ").strip()
        val = prompt_loop(f"Category {i} value: ", cast=float, validator=numeric_validator, error_msg="Enter a numeric value.")
        labels.append(lbl)
        values.append(val)
    labels = ensure_labels(labels)
    show_percent = yes_no("Show percentages on slices? (y/n) [y]: ", default=True)
    explode_label = input("Explode which slice (enter label or leave empty): ").strip()
    if explode_label == "":
        explode_label = None
    return {
        "title": title,
        "labels": labels,
        "values": values,
        "show_percent": show_percent,
        "explode_label": explode_label
    }


def collect_bar():
    title = input("Title (optional): ").strip()
    n = prompt_loop("Number of categories: ", cast=int, validator=positive_int_validator, error_msg="Enter a positive integer.")
    labels = []
    for i in range(1, n + 1):
        labels.append(input(f"Category {i} label (leave empty for default): ").strip())
    labels = ensure_labels(labels)
    grouped = yes_no("Grouped bars (multiple series)? (y/n): ", default=False)
    orientation = prompt_loop("Orientation (vertical/horizontal): ", cast=str, validator=lambda s: s.lower() in ("vertical", "horizontal"), error_msg="Enter 'vertical' or 'horizontal'.").lower()
    if not grouped:
        values = []
        for i in range(1, n + 1):
            values.append(prompt_loop(f"Category {i} value: ", cast=float, validator=numeric_validator, error_msg="Enter a numeric value."))
        return {
            "title": title,
            "labels": labels,
            "values": values,
            "grouped": False,
            "orientation": orientation
        }
    else:
        num_series = prompt_loop("Number of series: ", cast=int, validator=positive_int_validator, error_msg="Enter a positive integer.")
        series_names = []
        series_values = []
        for s in range(1, num_series + 1):
            sname = input(f"Series {s} name (optional): ").strip()
            if not sname:
                sname = f"Series {s}"
            series_names.append(sname)
            vals = []
            print(f"Enter values for series '{sname}':")
            for i in range(1, n + 1):
                vals.append(prompt_loop(f"  Value for category {i} ({labels[i-1]}): ", cast=float, validator=numeric_validator, error_msg="Enter a numeric value."))
            series_values.append(vals)
        return {
            "title": title,
            "labels": labels,
            "values": series_values,
            "grouped": True,
            "orientation": orientation,
            "series_names": series_names
        }


# ---------------------------
# Main
# ---------------------------


def main():
    print("Plot Maker (standard library only) — create pie charts and bar graphs.")
    chart_type = prompt_loop("Chart type (pie/bar): ", cast=str, validator=lambda s: s.lower() in ("pie", "bar"), error_msg="Enter 'pie' or 'bar'.").lower()

    if chart_type == "pie":
        cfg = collect_pie()
        if all((v <= 0 or not math.isfinite(v)) for v in cfg["values"]):
            print("Error: All pie values are zero, negative, or invalid. Cannot create pie chart.")
            return
        win = PlotWindow(title=cfg["title"] or "Pie Chart", width=700, height=600)
        try:
            draw_pie(win.canvas, center=(350, 320), radius=220, labels=cfg["labels"], values=cfg["values"],
                     title=cfg["title"], show_percent=cfg["show_percent"], explode_label=cfg["explode_label"])
        except Exception as e:
            print("Error drawing pie:", e)
            win.root.destroy()
            return
        print("Displaying chart window. Use the Save button to save as PostScript if desired.")
        win.mainloop()

    else:
        cfg = collect_bar()
        if cfg["grouped"]:
            n = len(cfg["labels"])
            for s in cfg["values"]:
                if len(s) != n:
                    print("Error: Series length mismatch. Aborting.")
                    return
        else:
            if len(cfg["values"]) != len(cfg["labels"]):
                print("Error: Number of values does not match number of categories.")
                return
        win = PlotWindow(title=cfg["title"] or "Bar Chart", width=900, height=600)
        try:
            draw_bar(win.canvas, origin=(10, 10), size=(880, 520), labels=cfg["labels"], values=cfg["values"],
                     title=cfg["title"], orientation=cfg["orientation"], grouped=cfg["grouped"], series_names=cfg.get("series_names"))
        except Exception as e:
            print("Error drawing bar chart:", e)
            win.root.destroy()
            return
        print("Displaying chart window. Use the Save button to save as PostScript if desired.")
        win.mainloop()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
        sys.exit(0)
