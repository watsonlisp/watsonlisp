# rgb_wave_characteristics.py
import tkinter as tk
from tkinter import ttk, colorchooser
import colorsys

# Physical constants
C = 299_792_458.0  # speed of light in m/s
HC_EV_NM = 1239.841984  # hc in eV*nm

def clamp_int(text, lo=0, hi=255):
    try:
        v = int(text)
    except Exception:
        return None
    if v < lo: return lo
    if v > hi: return hi
    return v

def rgb_to_hex(r, g, b):
    return '#{:02x}{:02x}{:02x}'.format(r, g, b)

def rgb_to_hue(r, g, b):
    # r,g,b in 0..255 -> hue in degrees 0..360
    h, s, v = colorsys.rgb_to_hsv(r/255.0, g/255.0, b/255.0)
    return (h * 360.0) % 360.0, s, v

# Approximate piecewise mapping from hue to spectral wavelength (nm)
# This is an estimate for saturated colors only.
HUE_TO_WL = [
    # (hue_start, hue_end, wl_start_nm, wl_end_nm)
    (300, 360, 380.0, 450.0),  # violet (wrap)
    (240, 300, 450.0, 495.0),  # blue
    (120, 240, 495.0, 570.0),  # green
    (60, 120, 570.0, 590.0),   # yellow
    (30, 60, 590.0, 620.0),    # orange
    (0, 30, 620.0, 750.0),     # red
]

def hue_to_wavelength(hue_deg):
    h = hue_deg % 360.0
    for a, b, wl_min, wl_max in HUE_TO_WL:
        if a <= b:
            if a <= h < b:
                t = (h - a) / (b - a)
                return wl_min + t * (wl_max - wl_min)
        else:
            # wrap-around segment (e.g., 300..360)
            if h >= a or h < b:
                span = (360.0 - a) + b
                offset = (h - a) if h >= a else (360.0 - a + h)
                t = offset / span
                return wl_min + t * (wl_max - wl_min)
    return 550.0  # fallback (green)

def wavelength_to_freq_energy(wl_nm):
    # wl_nm in nanometers -> frequency in Hz and energy in eV
    freq_hz = C / (wl_nm * 1e-9)
    energy_ev = HC_EV_NM / wl_nm
    return freq_hz, energy_ev

class RGBWaveApp:
    def __init__(self, root):
        self.root = root
        root.title("RGB → Color Wave Characteristics")
        root.resizable(False, False)

        frm = ttk.Frame(root, padding=12)
        frm.grid(row=0, column=0)

        # Preview
        self.preview = tk.Canvas(frm, width=320, height=140, bd=1, relief='sunken', cursor='hand2')
        self.preview.grid(row=0, column=0, columnspan=4, pady=(0,10))
        self.preview.bind("<Button-1>", self.open_color_chooser)

        # Sliders
        self.r_var = tk.IntVar(value=255)
        self.g_var = tk.IntVar(value=0)
        self.b_var = tk.IntVar(value=0)

        ttk.Label(frm, text="R").grid(row=1, column=0, sticky='w')
        self.r_slider = ttk.Scale(frm, from_=0, to=255, orient='horizontal',
                                  variable=self.r_var, command=self.on_slider_change)
        self.r_slider.grid(row=1, column=1, columnspan=3, sticky='we', padx=(6,0))

        ttk.Label(frm, text="G").grid(row=2, column=0, sticky='w')
        self.g_slider = ttk.Scale(frm, from_=0, to=255, orient='horizontal',
                                  variable=self.g_var, command=self.on_slider_change)
        self.g_slider.grid(row=2, column=1, columnspan=3, sticky='we', padx=(6,0))

        ttk.Label(frm, text="B").grid(row=3, column=0, sticky='w')
        self.b_slider = ttk.Scale(frm, from_=0, to=255, orient='horizontal',
                                  variable=self.b_var, command=self.on_slider_change)
        self.b_slider.grid(row=3, column=1, columnspan=3, sticky='we', padx=(6,0))

        # Entries
        ttk.Label(frm, text="R").grid(row=4, column=0, sticky='e', pady=(8,0))
        ttk.Label(frm, text="G").grid(row=4, column=1, sticky='e', pady=(8,0))
        ttk.Label(frm, text="B").grid(row=4, column=2, sticky='e', pady=(8,0))

        self.r_str = tk.StringVar(value=str(self.r_var.get()))
        self.g_str = tk.StringVar(value=str(self.g_var.get()))
        self.b_str = tk.StringVar(value=str(self.b_var.get()))

        self.r_entry = ttk.Entry(frm, width=6, textvariable=self.r_str)
        self.g_entry = ttk.Entry(frm, width=6, textvariable=self.g_str)
        self.b_entry = ttk.Entry(frm, width=6, textvariable=self.b_str)

        self.r_entry.grid(row=5, column=0, padx=(0,6))
        self.g_entry.grid(row=5, column=1, padx=(0,6))
        self.b_entry.grid(row=5, column=2, padx=(0,6))

        # Bind Enter and FocusOut to apply entries
        for e in (self.r_entry, self.g_entry, self.b_entry):
            e.bind('<Return>', self.apply_entries)
            e.bind('<FocusOut>', self.apply_entries)

        # Hex and RGB display
        self.hex_label = ttk.Label(frm, text="Hex: #ff0000")
        self.hex_label.grid(row=6, column=0, columnspan=2, pady=(10,0), sticky='w')

        self.rgb_label = ttk.Label(frm, text="RGB: 255, 0, 0")
        self.rgb_label.grid(row=6, column=2, columnspan=2, pady=(10,0), sticky='e')

        # Wave characteristics display
        ttk.Separator(frm, orient='horizontal').grid(row=7, column=0, columnspan=4, sticky='we', pady=(10,6))
        self.wl_label = ttk.Label(frm, text="Dominant wavelength: — nm")
        self.wl_label.grid(row=8, column=0, columnspan=4, sticky='w')

        self.freq_label = ttk.Label(frm, text="Frequency: — THz")
        self.freq_label.grid(row=9, column=0, columnspan=4, sticky='w')

        self.energy_label = ttk.Label(frm, text="Photon energy: — eV")
        self.energy_label.grid(row=10, column=0, columnspan=4, sticky='w')

        # Buttons
        self.pick_btn = ttk.Button(frm, text="Pick Color...", command=self.open_color_chooser)
        self.pick_btn.grid(row=11, column=1, pady=(8,0))

        self.copy_btn = ttk.Button(frm, text="Copy Hex", command=self.copy_hex)
        self.copy_btn.grid(row=11, column=2, pady=(8,0))

        # Initialize preview and wave info
        self.update_preview_from_vars()

    def on_slider_change(self, _=None):
        r = int(self.r_var.get()); g = int(self.g_var.get()); b = int(self.b_var.get())
        # Sync entries and preview immediately when sliders move
        self.r_str.set(str(r)); self.g_str.set(str(g)); self.b_str.set(str(b))
        self.update_all(r, g, b)

    def apply_entries(self, event=None):
        # Called on Enter or FocusOut; validate and apply values to sliders and preview
        r_text = self.r_str.get().strip()
        g_text = self.g_str.get().strip()
        b_text = self.b_str.get().strip()

        r_val = clamp_int(r_text) if r_text != '' else self.r_var.get()
        g_val = clamp_int(g_text) if g_text != '' else self.g_var.get()
        b_val = clamp_int(b_text) if b_text != '' else self.b_var.get()

        # If parsing failed, fall back to current slider values
        if r_val is None: r_val = self.r_var.get()
        if g_val is None: g_val = self.g_var.get()
        if b_val is None: b_val = self.b_var.get()

        # Apply normalized values
        self.r_var.set(r_val); self.g_var.set(g_val); self.b_var.set(b_val)
        self.r_str.set(str(r_val)); self.g_str.set(str(g_val)); self.b_str.set(str(b_val))
        self.update_all(r_val, g_val, b_val)

    def update_all(self, r, g, b):
        hexcol = rgb_to_hex(r, g, b)
        self.update_preview(hexcol)
        self.update_wave_info(r, g, b)

    def update_preview(self, hexcol):
        self.preview.delete('all')
        self.preview.create_rectangle(0, 0, 320, 140, fill=hexcol, outline='')
        r = int(self.r_var.get()); g = int(self.g_var.get()); b = int(self.b_var.get())
        self.hex_label.config(text=f"Hex: {hexcol}")
        self.rgb_label.config(text=f"RGB: {r}, {g}, {b}")

    def update_wave_info(self, r, g, b):
        # Compute hue, saturation, value
        hue, sat, val = rgb_to_hue(r, g, b)
        # Estimate dominant wavelength from hue (approximate)
        wl_nm = hue_to_wavelength(hue)
        freq_hz, energy_ev = wavelength_to_freq_energy(wl_nm)
        freq_thz = freq_hz / 1e12

        # If color is low saturation or low value, mark as non-spectral-like
        if sat < 0.15 or val < 0.15:
            note = " (low saturation/value — non-spectral color)"
        else:
            note = ""

        self.wl_label.config(text=f"Dominant wavelength: {wl_nm:.1f} nm{note}")
        self.freq_label.config(text=f"Frequency: {freq_thz:.2f} THz")
        self.energy_label.config(text=f"Photon energy: {energy_ev:.3f} eV")

    def update_preview_from_vars(self):
        r = int(self.r_var.get()); g = int(self.g_var.get()); b = int(self.b_var.get())
        self.r_str.set(str(r)); self.g_str.set(str(g)); self.b_str.set(str(b))
        self.update_all(r, g, b)

    def open_color_chooser(self, event=None):
        current_hex = self.hex_label.cget("text").split()[-1]
        chosen = colorchooser.askcolor(color=current_hex, title="Choose color")
        if chosen and chosen[1]:
            r = clamp_int(int(chosen[0][0])); g = clamp_int(int(chosen[0][1])); b = clamp_int(int(chosen[0][2]))
            self.r_var.set(r); self.g_var.set(g); self.b_var.set(b)
            self.r_str.set(str(r)); self.g_str.set(str(g)); self.b_str.set(str(b))
            self.update_all(r, g, b)

    def copy_hex(self):
        hexcol = self.hex_label.cget("text").split()[-1]
        self.root.clipboard_clear()
        self.root.clipboard_append(hexcol)
        old = self.copy_btn.cget('text')
        self.copy_btn.config(text='Copied')
        self.root.after(900, lambda: self.copy_btn.config(text=old))

if __name__ == "__main__":
    root = tk.Tk()
    app = RGBWaveApp(root)
    root.mainloop()
