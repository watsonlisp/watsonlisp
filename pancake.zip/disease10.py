#!/usr/bin/env python3
"""
Big Random Disease Generator (all changes applied)
- Very large disease list
- Expanded symptoms_pool and treatments_pool
- Many templates and extensive keyword_map
- System TTS (macOS say, Windows PowerShell, Linux spd-say/espeak)
- Speech ON by default; includes disease, category, incubation, symptoms, treatments
- Interactive repeat/quit loop; optional --no-speak flag
Note: Informational only. Not medical advice.
"""
import random
import threading
import platform
import subprocess
import shutil
import shlex
import sys

# ---------- System TTS helper (no pip) ----------
def _run_nonblocking(cmd_list):
    try:
        subprocess.Popen(cmd_list, shell=False)
        return True
    except Exception:
        try:
            subprocess.Popen(" ".join(cmd_list), shell=True)
            return True
        except Exception:
            return False

def speak_text(text):
    if not text:
        return False
    system = platform.system()
    if system == "Darwin" and shutil.which("say"):
        return _run_nonblocking(["say", text])
    if system == "Windows":
        safe_text = text.replace("'", "''")
        ps_script = (
            "Add-Type -AssemblyName System.Speech;"
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            f"$s.Speak('{safe_text}');"
        )
        return _run_nonblocking(["powershell", "-NoProfile", "-Command", ps_script])
    if system in ("Linux", "FreeBSD"):
        if shutil.which("spd-say"):
            return _run_nonblocking(["spd-say", text])
        if shutil.which("espeak"):
            return _run_nonblocking(["espeak", text])
        if shutil.which("text2wave") and shutil.which("aplay"):
            safe = shlex.quote(text)
            cmd = ["bash", "-lc", f"echo {safe} | text2wave -o /tmp/tts.wav && aplay /tmp/tts.wav"]
            return _run_nonblocking(cmd)
    return False

def is_tts_available():
    system = platform.system()
    if system == "Darwin":
        return shutil.which("say") is not None
    if system == "Windows":
        return True
    if system in ("Linux", "FreeBSD"):
        return any(shutil.which(cmd) for cmd in ("spd-say", "espeak", "text2wave"))
    return False

TTS_AVAILABLE = is_tts_available()

# ---------- Very large disease list ----------
diseases = [
"Influenza","Common Cold","COVID-19","SARS","MERS","Pneumonia","Bronchitis","Tuberculosis",
"Whooping Cough","Sinusitis","Otitis Media","Conjunctivitis","Strep Throat","Scarlet Fever",
"Rheumatic Fever","Tonsillitis","Epiglottitis","Laryngitis","Pharyngitis","Croup",
"Chickenpox","Shingles","Measles","Mumps","Rubella","Hand-Foot-and-Mouth Disease",
"Mononucleosis","Cytomegalovirus Infection","Adenovirus Infection","Norovirus Infection",
"Rotavirus Infection","Gastroenteritis","Food Poisoning","Salmonellosis","Shigellosis",
"Campylobacteriosis","Cholera","Typhoid Fever","Paratyphoid Fever","Giardiasis","Amebiasis",
"Cryptosporidiosis","Hepatitis A","Hepatitis B","Hepatitis C","Hepatitis D","Hepatitis E",
"Fatty Liver Disease","Liver Cirrhosis","Alcoholic Hepatitis","Autoimmune Hepatitis",
"Pancreatitis","Gallstones","Peptic Ulcer Disease","Gastritis","GERD","Irritable Bowel Syndrome",
"Crohn's Disease","Ulcerative Colitis","Celiac Disease","Diverticulitis","Appendicitis",
"Urinary Tract Infection","Pyelonephritis","Interstitial Cystitis","Prostatitis","Benign Prostatic Hyperplasia",
"Epididymitis","Ovarian Cysts","Endometriosis","Polycystic Ovary Syndrome","Pelvic Inflammatory Disease",
"Preeclampsia","Eclampsia","Ectopic Pregnancy","Miscarriage","Infertility","Migraine","Tension Headache",
"Cluster Headache","Trigeminal Neuralgia","Epilepsy","Seizure Disorder","Stroke","Transient Ischemic Attack",
"Subarachnoid Hemorrhage","Intracerebral Hemorrhage","Ischemic Stroke","Parkinson's Disease",
"Alzheimer's Disease","Dementia","Multiple Sclerosis","Guillain-Barré Syndrome","Myasthenia Gravis",
"Amyotrophic Lateral Sclerosis","Bell's Palsy","Peripheral Neuropathy","Carpal Tunnel Syndrome",
"Vertigo","Meniere's Disease","Depression","Generalized Anxiety Disorder","Panic Disorder",
"Post Traumatic Stress Disorder","Bipolar Disorder","Schizophrenia","Insomnia","Narcolepsy",
"Hypertension","Hypotension","Atherosclerosis","Coronary Artery Disease","Angina","Myocardial Infarction",
"Heart Failure","Cardiomyopathy","Pericarditis","Endocarditis","Myocarditis","Arrhythmia",
"Atrial Fibrillation","Deep Vein Thrombosis","Pulmonary Embolism","Peripheral Arterial Disease",
"Anemia","Iron Deficiency Anemia","Vitamin B12 Deficiency","Aplastic Anemia","Sickle Cell Disease",
"Thalassemia","Hemophilia","Von Willebrand Disease","Leukemia","Lymphoma","Multiple Myeloma",
"Melanoma","Basal Cell Carcinoma","Squamous Cell Carcinoma","Breast Cancer","Lung Cancer",
"Colon Cancer","Rectal Cancer","Pancreatic Cancer","Liver Cancer","Prostate Cancer","Ovarian Cancer",
"Testicular Cancer","Thyroid Cancer","Bladder Cancer","Kidney Cancer","Brain Tumor","Skin Infection",
"Cellulitis","Impetigo","Erysipelas","Abscess","Necrotizing Fasciitis","Ringworm","Tinea Pedis",
"Tinea Cruris","Onychomycosis","Candidiasis","Oral Thrush","Vaginal Yeast Infection","Scabies","Head Lice",
"Psoriasis","Eczema","Atopic Dermatitis","Contact Dermatitis","Rosacea","Vitiligo","Alopecia Areata",
"Lupus","Scleroderma","Dermatomyositis","Rheumatoid Arthritis","Osteoarthritis","Ankylosing Spondylitis",
"Gout","Pseudogout","Fibromyalgia","Polymyalgia Rheumatica","Osteoporosis","Paget's Disease of Bone",
"Chronic Fatigue Syndrome","Sarcoidosis","Sjögren's Syndrome","Hashimoto's Thyroiditis","Graves' Disease",
"Hypothyroidism","Hyperthyroidism","Cushing's Syndrome","Addison's Disease","Diabetes Type 1",
"Diabetes Type 2","Prediabetes","Hypoglycemia","Hyperglycemia","Metabolic Syndrome","Obesity",
"Hyperlipidemia","Pancreatic Insufficiency","Heat Stroke","Heat Exhaustion","Frostbite","Hypothermia",
"Poison Ivy Dermatitis","Allergic Rhinitis","Food Allergy","Anaphylaxis","Bee Sting Allergy",
"Drug Allergy","Asthma","COPD","Emphysema","Bronchiectasis","Pulmonary Fibrosis","Sarcoidosis of Lung",
"Silicosis","Asbestosis","Pneumoconiosis","Occupational Asthma","Lead Poisoning","Mercury Poisoning",
"Carbon Monoxide Poisoning","Radiation Sickness","Prion Disease","Creutzfeldt-Jakob Disease","Kuru",
"Mad Cow Disease","Huntington's Disease","Fragile X Syndrome","Down Syndrome","Turner Syndrome",
"Klinefelter Syndrome","Marfan Syndrome","Ehlers-Danlos Syndrome","Hemochromatosis","Wilson Disease",
"Phenylketonuria","Gaucher Disease","Fabry Disease","Pompe Disease","Lysosomal Storage Disorder",
"Congenital Heart Disease","Cystic Fibrosis","Primary Ciliary Dyskinesia","Bronchopulmonary Dyskinesia",
"Neonatal Jaundice","SIDS","Rickets","Scurvy","Beriberi","Pellagra","Night Blindness","Otitis Externa",
"Chronic Sinusitis","Chronic Rhinosinusitis","Dental Abscess","Periodontitis","Temporomandibular Joint Disorder",
"Acne Vulgaris","Hidradenitis Suppurativa","Hyperhidrosis","Hypogonadism","Menopause Symptoms",
"Premenstrual Syndrome","Premenstrual Dysphoric Disorder","Polycystic Kidney Disease","Nephrotic Syndrome",
"Glomerulonephritis","Renal Tubular Acidosis","Acute Kidney Injury","Chronic Kidney Disease Stage 1",
"Chronic Kidney Disease Stage 2","Chronic Kidney Disease Stage 3","Chronic Kidney Disease Stage 4",
"End Stage Renal Disease","Urolithiasis","Hydronephrosis","Vasculitis","Temporal Arteritis","Behcet's Disease",
"Takayasu Arteritis","Kawasaki Disease","Henoch-Schonlein Purpura","Eosinophilic Esophagitis",
"Barrett's Esophagus","Achalasia","Gastroparesis","Small Intestinal Bacterial Overgrowth",
"Short Bowel Syndrome","Malabsorption","Lactose Intolerance","Fructose Intolerance","Hemorrhoids",
"Anal Fissure","Rectal Prolapse","Diverticular Disease","Ileus","Bowel Obstruction","Intussusception",
"Mesenteric Ischemia","Portal Hypertension","Variceal Bleed","Splenomegaly","Thyroid Nodule",
"Goiter","Hyperparathyroidism","Hypoparathyroidism","Adrenal Insufficiency","Pheochromocytoma",
"Carcinoid Syndrome","Systemic Mastocytosis","Chronic Myelogenous Leukemia","Acute Lymphoblastic Leukemia",
"Acute Myelogenous Leukemia","Chronic Lymphocytic Leukemia","Myelodysplastic Syndrome","Myelofibrosis",
"Essential Thrombocythemia","Polycythemia Vera","Autoimmune Hemolytic Anemia","Cold Agglutinin Disease",
"Thrombotic Thrombocytopenic Purpura","Hemolytic Uremic Syndrome","Idiopathic Pulmonary Hypertension",
"Pulmonary Hypertension Group 1","Pulmonary Hypertension Group 2","Pulmonary Hypertension Group 3",
"Pulmonary Hypertension Group 4","Pulmonary Hypertension Group 5","Primary Biliary Cholangitis",
"Primary Sclerosing Cholangitis","Cholangitis","Biliary Colic","Cholecystitis","Acute Viral Myositis",
"Polymyositis","Dermatomyositis","Eosinophilic Granulomatosis with Polyangiitis","Churg-Strauss Syndrome",
"Goodpasture Syndrome","Wegener's Granulomatosis","Granulomatosis with Polyangiitis","Behcet Syndrome"
]

# ---------- Expanded symptoms pool ----------
symptoms_pool = [
"fever","low-grade fever","high fever","chills","rigors","night sweats","fatigue","malaise","weakness",
"myalgia","muscle aches","joint pain","arthralgia","stiffness","swelling","localized pain","headache",
"throbbing headache","pressure-like headache","unilateral headache","bilateral headache","photophobia",
"phonophobia","nausea","vomiting","retching","diarrhea","loose stools","constipation","abdominal pain",
"cramping","bloating","early satiety","loss of appetite","weight loss","weight gain","dysphagia","odynophagia",
"heartburn","acid reflux","belching","flatulence","hiccups","cough","dry cough","productive cough",
"blood-tinged sputum","hemoptysis","shortness of breath","dyspnea on exertion","orthopnea","paroxysmal nocturnal dyspnea",
"wheezing","stridor","chest pain","pleuritic chest pain","palpitations","tachycardia","bradycardia",
"dizziness","lightheadedness","syncope","near-syncope","vertigo","imbalance","ataxia","tremor","tremulousness",
"numbness","paresthesia","tingling","weakness in limb","focal weakness","speech difficulty","slurred speech",
"vision changes","blurred vision","double vision","loss of vision","eye pain","red eye","discharge from eye",
"hearing loss","tinnitus","ear pain","ear fullness","nasal congestion","runny nose","sore throat","hoarseness",
"swollen lymph nodes","neck stiffness","stiff neck","back pain","lower back pain","pelvic pain","scrotal pain",
"testicular pain","vaginal discharge","vaginal bleeding","menstrual irregularity","hot flashes","night sweats",
"urinary frequency","urinary urgency","dysuria","hematuria","incontinence","urinary retention","polyuria",
"polydipsia","dry mouth","thirst","edema","peripheral edema","facial swelling","ascites","jaundice",
"pale stools","dark urine","pruritus","itching","rash","maculopapular rash","urticarial rash","vesicular rash",
"pustular lesions","blisters","scaling","peeling skin","eczema-like rash","psoriasiform plaques","acneiform lesions",
"alopecia","hair loss","nail changes","easy bruising","bleeding","epistaxis","gum bleeding","petechiae",
"purpura","lymphadenopathy","enlarged spleen","enlarged liver","difficulty sleeping","insomnia","excessive sleepiness",
"confusion","memory loss","cognitive decline","mood changes","irritability","anxiety","depression","panic attacks",
"hallucinations","delusions","suicidal ideation","sexual dysfunction","loss of libido","menstrual pain",
"recurrent infections","slow wound healing","cold intolerance","heat intolerance","sweating","flushing",
"changes in taste","metallic taste","bad breath","halitosis","bad odor from wound","foul-smelling stool",
"blood in stool","melena","rectal bleeding","difficulty breathing while lying down","orthostatic symptoms",
"exercise intolerance","exercise-induced symptoms","poor feeding (infants)","failure to thrive","developmental delay"
]

# ---------- Expanded treatments pool ----------
treatments_pool = [
"rest and oral hydration","increased fluid intake","oral rehydration solution","clear liquids","advance diet as tolerated",
"antipyretics such as acetaminophen or ibuprofen","analgesics for pain control","topical emollients and moisturizers",
"topical corticosteroid for inflammatory rash when prescribed","topical antifungal cream for fungal infections",
"topical antibacterial ointment for localized skin infection","systemic antibiotic therapy guided by culture and sensitivity",
"empiric antibiotic therapy when clinically indicated","antiviral therapy when indicated by clinician","systemic antifungal therapy when indicated",
"inhaled bronchodilator (short-acting) for wheeze","inhaled corticosteroid for airway inflammation","systemic corticosteroid taper when prescribed",
"oxygen therapy for hypoxemia","supplemental oxygen via nasal cannula or mask","nebulized bronchodilator therapy",
"intravenous fluids and electrolyte replacement","oral electrolyte replacement","antiemetic medication for nausea and vomiting",
"antidiarrheal therapy when appropriate","probiotic supplementation","nutritional support and dietitian referral",
"insulin therapy and glucose management","oral hypoglycemic agents as prescribed","lipid-lowering therapy (statin) when indicated",
"antihypertensive therapy as prescribed","anticoagulation for thromboembolism when indicated","thrombolytic therapy in selected acute ischemic stroke cases",
"cardiac monitoring and telemetry","cardiology referral and evaluation","surgical consultation for operative management",
"wound care and local debridement","incision and drainage for abscess","suture repair when needed","vaccination for prevention where available",
"smoking cessation counseling and pharmacotherapy","physical therapy and rehabilitation","occupational therapy","speech therapy",
"behavioral therapy and counseling","psychotropic medication when indicated","epinephrine intramuscular for anaphylaxis emergency",
"urine testing and culture","urine-directed antibiotic therapy","urology referral for recurrent urinary issues",
"imaging studies (X-ray, CT, MRI) for diagnostic evaluation","laboratory testing and targeted diagnostics","biopsy for histologic diagnosis",
"oncology referral and staging workup","chemotherapy when indicated","radiation therapy when indicated","surgical oncology referral",
"endocrinology referral and hormone replacement when indicated","thyroid hormone replacement therapy","glucocorticoid replacement when indicated",
"adrenal support and specialist care","dialysis for renal failure when indicated","renal referral and nephrology follow-up",
"hydration and electrolyte monitoring for dehydration","monitoring and outpatient follow-up with clinician","specialist referral as appropriate",
"preventive counseling and lifestyle modification","weight management and nutritional counseling","exercise prescription and physical activity plan",
"sleep hygiene measures","hearing or vision referral","dental referral for oral disease","allergy testing and immunotherapy referral",
"avoidance of known triggers and allergens","protective measures and PPE for occupational exposures","supportive palliative care and symptom management",
"advance care planning and hospice referral when appropriate","close monitoring for red flag symptoms and urgent re-evaluation",
"activated charcoal for certain ingestions (time-dependent)","antidotes when available","decontamination and supportive toxicology care",
"immunoglobulin replacement when indicated","immunomodulatory therapy for autoimmune disease","disease-modifying antirheumatic drugs (DMARDs)"
]

# ---------- Expanded templates (category -> realistic symptoms and treatments) ----------
templates = {
    "respiratory": {
        "symptoms": [
            "fever","cough","sore throat","shortness of breath","wheezing","productive cough",
            "dry cough","hemoptysis","pleuritic chest pain","nasal congestion","runny nose"
        ],
        "treatments": [
            "rest and oral hydration","antipyretics (acetaminophen/ibuprofen)","clinical evaluation and chest imaging",
            "oxygen therapy if hypoxic","inhaled bronchodilators for wheeze","antibiotics when bacterial infection is confirmed",
            "antiviral therapy when indicated by clinician","smoking cessation counseling"
        ]
    },
    "gastrointestinal": {
        "symptoms": [
            "nausea","vomiting","diarrhea","abdominal pain","cramping","bloating","loss of appetite",
            "blood in stool","melena","dehydration risk"
        ],
        "treatments": [
            "oral rehydration and electrolyte replacement","antiemetics for nausea","dietary modification",
            "antibiotics when bacterial infection is confirmed","antidiarrheal therapy when appropriate",
            "endoscopy or imaging for severe/bleeding cases","surgical consultation for obstruction or perforation"
        ]
    },
    "neurological": {
        "symptoms": [
            "headache","dizziness","focal weakness","numbness","paresthesia","seizures","confusion",
            "memory loss","speech difficulty","visual disturbance"
        ],
        "treatments": [
            "rest in quiet/dark environment for headaches","acute migraine therapies as prescribed",
            "anticonvulsant therapy when indicated","neuroimaging for focal deficits","neurology referral",
            "stroke pathway activation and reperfusion when eligible","rehabilitation and PT/OT"
        ]
    },
    "dermatologic": {
        "symptoms": [
            "rash","pruritus","erythema","vesicles","pustules","scaling","blisters","ulceration","dry skin"
        ],
        "treatments": [
            "topical emollients and barrier creams","topical corticosteroids for inflammatory dermatoses",
            "topical or systemic antifungals for tinea/candidiasis","topical or systemic antibiotics for bacterial skin infection",
            "wound care and debridement when needed","avoidance of triggers and allergen control"
        ]
    },
    "systemic_infectious": {
        "symptoms": [
            "fever","chills","night sweats","fatigue","lymphadenopathy","weight loss","malaise"
        ],
        "treatments": [
            "bloodwork and cultures for diagnosis","targeted antimicrobial therapy when pathogen identified",
            "supportive care (fluids, antipyretics)","hospitalization for sepsis or hemodynamic instability",
            "infectious disease referral for complex infections"
        ]
    },
    "genitourinary": {
        "symptoms": [
            "dysuria","urinary frequency","urgency","hematuria","flank pain","suprapubic pain","urinary incontinence"
        ],
        "treatments": [
            "urinalysis and urine culture","antibiotic therapy guided by culture","analgesia for dysuria",
            "hydration and bladder care","urology referral for recurrent or complicated disease"
        ]
    },
    "endocrine": {
        "symptoms": [
            "polyuria","polydipsia","weight change","fatigue","heat intolerance","cold intolerance","hair changes"
        ],
        "treatments": [
            "laboratory evaluation (glucose, TSH, cortisol, electrolytes)","insulin or oral hypoglycemic therapy when indicated",
            "thyroid hormone replacement or antithyroid therapy as appropriate","endocrinology referral",
            "lifestyle modification and dietary counseling"
        ]
    },
    "cardiovascular": {
        "symptoms": [
            "chest pain","palpitations","dyspnea on exertion","orthopnea","edema","syncope","claudication"
        ],
        "treatments": [
            "ECG and cardiac enzymes for chest pain","antiplatelet and anticoagulation when indicated",
            "antihypertensive therapy","diuretics for volume overload","cardiology referral and imaging (echo, stress test)",
            "revascularization or surgical consultation when indicated"
        ]
    },
    "hematologic": {
        "symptoms": [
            "easy bruising","bleeding","petechiae","fatigue","pallor","lymphadenopathy"
        ],
        "treatments": [
            "complete blood count and peripheral smear","iron/folate/B12 replacement when deficient",
            "transfusion support when indicated","hematology referral for cytopenias or malignancy",
            "immunosuppressive therapy for autoimmune cytopenias when appropriate"
        ]
    },
    "musculoskeletal": {
        "symptoms": [
            "joint pain","joint swelling","stiffness","reduced range of motion","muscle pain","back pain"
        ],
        "treatments": [
            "rest and activity modification","NSAIDs or acetaminophen for pain control","physical therapy and exercise program",
            "intra-articular steroid injection when indicated","rheumatology referral for inflammatory arthritis",
            "orthopedic referral for structural problems"
        ]
    },
    "infectious_vectorborne": {
        "symptoms": [
            "fever","myalgia","arthralgia","rash","headache","lymphadenopathy","fatigue"
        ],
        "treatments": [
            "vector exposure history and targeted testing","supportive care (fluids, antipyretics)",
            "antimicrobial therapy when indicated (e.g., doxycycline for certain tick-borne infections)",
            "hospitalization for severe systemic disease","public health notification when required"
        ]
    },
    "pediatric": {
        "symptoms": [
            "fever","irritability","poor feeding","vomiting","diarrhea","rash","cough"
        ],
        "treatments": [
            "age-appropriate dosing of antipyretics","oral rehydration for dehydration","pediatric evaluation for red flags",
            "immunization review and catch-up","referral to pediatric specialist when needed"
        ]
    },
    "obstetric": {
        "symptoms": [
            "vaginal bleeding","abdominal pain","reduced fetal movement","hypertension","edema"
        ],
        "treatments": [
            "obstetric evaluation and fetal monitoring","blood pressure control and magnesium sulfate for preeclampsia when indicated",
            "urgent obstetric or surgical consultation for hemorrhage or ectopic pregnancy","prenatal care and specialist referral"
        ]
    },
    "ophthalmologic": {
        "symptoms": [
            "eye pain","red eye","vision changes","discharge","photophobia","floaters"
        ],
        "treatments": [
            "urgent ophthalmology referral for vision-threatening signs","topical antibiotics for bacterial conjunctivitis",
            "topical antivirals when indicated","intraocular pressure control for glaucoma","protective measures and patching when appropriate"
        ]
    },
    "otologic_ent": {
        "symptoms": [
            "ear pain","hearing loss","tinnitus","nasal congestion","sore throat","hoarseness"
        ],
        "treatments": [
            "analgesia and local care for otitis externa/media","decongestants and nasal saline for congestion",
            "ENT referral for persistent or complicated disease","audiology referral for hearing loss"
        ]
    },
    "psychiatric": {
        "symptoms": [
            "depressed mood","anxiety","insomnia","panic attacks","hallucinations","suicidal ideation"
        ],
        "treatments": [
            "safety assessment and crisis intervention for acute risk","psychotherapy and counseling","pharmacotherapy when indicated",
            "referral to psychiatry for severe or refractory illness","supportive community resources"
        ]
    },
    "toxicologic": {
        "symptoms": [
            "nausea","vomiting","altered mental status","respiratory distress","cardiac arrhythmia","metabolic disturbance"
        ],
        "treatments": [
            "remove exposure and decontamination","activated charcoal when appropriate and within timeframe",
            "antidotes when available","supportive care and monitoring","toxicology/poison control consultation"
        ]
    },
    "metabolic": {
        "symptoms": [
            "polyuria","polydipsia","weight change","fatigue","muscle cramps","electrolyte abnormalities"
        ],
        "treatments": [
            "laboratory evaluation of metabolic panel and endocrine tests","insulin or glucose management",
            "electrolyte repletion","dietary counseling and metabolic specialist referral"
        ]
    },
    "renal": {
        "symptoms": [
            "reduced urine output","edema","hematuria","flank pain","fatigue","nausea"
        ],
        "treatments": [
            "urinalysis and renal function testing","fluid and electrolyte management","renal ultrasound when indicated",
            "nephrology referral and dialysis when required","treat reversible causes"
        ]
    },
    "hepatic": {
        "symptoms": [
            "jaundice","dark urine","pale stools","pruritus","abdominal pain","fatigue"
        ],
        "treatments": [
            "liver function testing and viral hepatitis serologies","avoid hepatotoxins and alcohol","supportive care",
            "hepatology referral for chronic liver disease","consider imaging and biopsy when indicated"
        ]
    },
    "oncologic": {
        "symptoms": [
            "unintentional weight loss","fatigue","localized pain","palpable mass","night sweats","anemia"
        ],
        "treatments": [
            "diagnostic imaging and biopsy for tissue diagnosis","multidisciplinary oncology referral",
            "surgical, medical (chemotherapy), and radiation options as appropriate","palliative care for symptom control"
        ]
    },
    "immunologic": {
        "symptoms": [
            "recurrent infections","fever","lymphadenopathy","autoimmune manifestations","rash"
        ],
        "treatments": [
            "immune workup and specialist referral","immunoglobulin replacement when indicated","immunomodulatory therapy",
            "infection prevention and vaccination review"
        ]
    },
    "rheumatologic": {
        "symptoms": [
            "joint pain","morning stiffness","symmetric arthritis","systemic fatigue","rash"
        ],
        "treatments": [
            "NSAIDs and analgesics for symptom control","disease-modifying antirheumatic drugs (DMARDs) when indicated",
            "rheumatology referral and immunosuppressive therapy","physical therapy and joint protection strategies"
        ]
    },
    "occupational": {
        "symptoms": [
            "respiratory symptoms after exposure","dermatitis at contact site","neurologic symptoms after toxin exposure","hearing loss"
        ],
        "treatments": [
            "remove from exposure and use PPE","occupational health referral","workplace hazard mitigation",
            "symptomatic treatment and specialist referral as needed","reporting to appropriate agencies"
        ]
    }
}

# ---------- Extensive keyword map (many substrings -> template categories) ----------
keyword_map = {
    # respiratory and ENT
    "pneumonia": "respiratory", "bronch": "respiratory", "bronchiol": "respiratory",
    "influenza": "respiratory", "flu": "respiratory", "covid": "respiratory", "sars": "respiratory",
    "mers": "respiratory", "bronchitis": "respiratory", "laryngitis": "respiratory",
    "pharyngitis": "respiratory", "tonsillitis": "respiratory", "croup": "respiratory",
    "sinus": "otologic_ent", "rhinosinusitis": "otologic_ent", "otitis": "otologic_ent",
    "conjunctivitis": "ophthalmologic", "epiglottitis": "respiratory",

    # gastrointestinal
    "gastro": "gastrointestinal", "enteritis": "gastrointestinal", "colitis": "gastrointestinal",
    "hepatitis": "hepatic", "pancreatitis": "gastrointestinal", "ulcer": "gastrointestinal",
    "gastritis": "gastrointestinal", "appendicitis": "gastrointestinal", "diverticul": "gastrointestinal",
    "cholera": "gastrointestinal", "salmonella": "gastrointestinal", "norovirus": "gastrointestinal",
    "rotavirus": "gastrointestinal", "giardia": "gastrointestinal", "amebiasis": "gastrointestinal",

    # neurological
    "migraine": "neurological", "headache": "neurological", "stroke": "neurological",
    "cva": "neurological", "seizure": "neurological", "epilep": "neurological",
    "parkinson": "neurological", "alzheimer": "neurological", "dementia": "neurological",
    "neuropathy": "neurological", "guillain": "neurological", "myasthenia": "neurological",
    "meniere": "neurological", "vertigo": "neurological", "trigeminal": "neurological",

    # dermatologic
    "psoriasis": "dermatologic", "eczema": "dermatologic", "dermatitis": "dermatologic",
    "tinea": "dermatologic", "ringworm": "dermatologic", "cellulitis": "dermatologic",
    "impetigo": "dermatologic", "scabies": "dermatologic", "acne": "dermatologic",
    "hidradenitis": "dermatologic", "urticaria": "dermatologic", "psoriatic": "dermatologic",

    # systemic / infectious
    "sepsis": "systemic_infectious", "bacteremia": "systemic_infectious", "endocarditis": "systemic_infectious",
    "lyme": "infectious_vectorborne", "malaria": "infectious_vectorborne", "dengue": "infectious_vectorborne",
    "zika": "infectious_vectorborne", "ebola": "systemic_infectious", "rabies": "systemic_infectious",
    "hiv": "systemic_infectious", "aids": "systemic_infectious", "mononucleosis": "systemic_infectious",
    "tuberculosis": "respiratory", "tb": "respiratory",

    # genitourinary / renal / obstetric
    "urinary": "genitourinary", "uti": "genitourinary", "cystitis": "genitourinary",
    "pyelonephritis": "genitourinary", "nephritis": "renal", "nephrotic": "renal",
    "pre-eclampsia": "obstetric", "preeclampsia": "obstetric", "eclampsia": "obstetric",
    "ectopic": "obstetric", "miscarriage": "obstetric", "ovarian": "genitourinary",
    "prostatitis": "genitourinary", "benign prostatic": "genitourinary",

    # endocrine / metabolic
    "diabetes": "endocrine", "hyperglyc": "endocrine", "hypoglyc": "endocrine",
    "thyroid": "endocrine", "cushing": "endocrine", "addison": "endocrine",
    "pheochromocytoma": "endocrine", "hyperparathyroid": "endocrine", "hypoparathyroid": "endocrine",

    # cardiovascular / pulmonary vascular
    "hypertension": "cardiovascular", "htn": "cardiovascular", "heart failure": "cardiovascular",
    "myocardial": "cardiovascular", "mi": "cardiovascular", "angina": "cardiovascular",
    "arrhythmia": "cardiovascular", "atrial fibrillation": "cardiovascular",
    "pulmonary embolism": "cardiovascular", "dvt": "cardiovascular", "thromboembolism": "cardiovascular",
    "pulmonary hypertension": "cardiovascular",

    # hematologic / oncologic
    "anemia": "hematologic", "leukemia": "hematologic", "lymphoma": "hematologic",
    "myeloma": "hematologic", "melanoma": "oncologic", "carcinoma": "oncologic",
    "sarcoma": "oncologic", "metastatic": "oncologic", "cancer": "oncologic",

    # musculoskeletal / rheumatologic
    "arthritis": "musculoskeletal", "rheumatoid": "rheumatologic", "osteoarthritis": "musculoskeletal",
    "gout": "musculoskeletal", "fibromyalgia": "musculoskeletal", "polymyalgia": "musculoskeletal",
    "vasculitis": "rheumatologic", "temporal arteritis": "rheumatologic",

    # psychiatric
    "depression": "psychiatric", "anxiety": "psychiatric", "bipolar": "psychiatric",
    "schizophrenia": "psychiatric", "ptsd": "psychiatric", "suicidal": "psychiatric",

    # toxicologic / environmental
    "poisoning": "toxicologic", "overdose": "toxicologic", "carbon monoxide": "toxicologic",
    "lead": "toxicologic", "mercury": "toxicologic", "radiation": "toxicologic",

    # pediatric / congenital / genetic
    "congenital": "pediatric", "cystic fibrosis": "pediatric", "down syndrome": "pediatric",
    "turner": "pediatric", "klinefelter": "pediatric", "marfan": "pediatric",

    # ENT / dental / ophthalmologic
    "otitis": "otologic_ent", "tonsillitis": "otologic_ent", "sinusitis": "otologic_ent",
    "dental": "occupational", "periodontitis": "occupational", "glaucoma": "ophthalmologic",
    "conjunctivitis": "ophthalmologic", "retinopathy": "ophthalmologic",

    # occupational / environmental / tropical
    "asbestosis": "occupational", "silicosis": "occupational", "pneumoconiosis": "occupational",
    "schistosomiasis": "infectious_vectorborne", "leishmania": "infectious_vectorborne", "chagas": "infectious_vectorborne",

    # autoimmune / immunologic / rheumatologic
    "lupus": "rheumatologic", "scleroderma": "rheumatologic", "sjogren": "rheumatologic",
    "hashimoto": "endocrine", "graves": "endocrine", "autoimmune": "immunologic",

    # renal / hepatic specifics
    "cirrhosis": "hepatic", "hepatocellular": "hepatic", "hepatoma": "hepatic",
    "nephrolithiasis": "renal", "urolithiasis": "renal", "hydronephrosis": "renal",

    # metabolic / nutritional
    "rickets": "metabolic", "scurvy": "metabolic", "beriberi": "metabolic", "pellagra": "metabolic",

    # generic fallbacks
    "infection": "systemic_infectious", "infectious": "systemic_infectious", "syndrome": "systemic_infectious",
    "disorder": "systemic_infectious", "disease": "systemic_infectious", "fever": "systemic_infectious",
    "tumor": "oncologic", "neoplasm": "oncologic"
}

# ---------- Classification and generation helpers ----------
def classify(name):
    low = name.lower()
    for k, v in keyword_map.items():
        if k in low:
            return v
    return random.choice(list(templates.keys()))

def generate_symptoms_for_disease(name, min_count=2, max_count=6):
    cat = classify(name)
    base = templates.get(cat, {}).get("symptoms", [])
    chosen = []
    if base:
        # pick up to 2 from base template
        chosen.extend(random.sample(base, k=min(len(base), 2)))
    remaining = random.randint(max(0, min_count - len(chosen)), max_count - len(chosen))
    pool = [s for s in symptoms_pool if s not in chosen]
    if remaining > 0 and pool:
        chosen.extend(random.sample(pool, k=min(remaining, len(pool))))
    return chosen

def generate_treatments_for_disease(name, min_count=1, max_count=3):
    # pick realistic general treatments
    count = random.randint(min_count, max_count)
    return random.sample(treatments_pool, k=min(count, len(treatments_pool)))

def estimate_incubation(name):
    cat = classify(name)
    if cat == "respiratory":
        return random.randint(1,14)
    if cat == "gastrointestinal":
        return random.randint(0,7)
    if cat == "infectious_vectorborne":
        return random.randint(3,21)
    return random.randint(0,30)

def generate_case():
    disease = random.choice(diseases)
    category = classify(disease)
    symptoms = generate_symptoms_for_disease(disease)
    treatments = generate_treatments_for_disease(disease)
    incubation = estimate_incubation(disease)
    return {
        "disease": disease,
        "category": category,
        "incubation_days_estimate": incubation,
        "symptoms": symptoms,
        "suggested_treatments": treatments
    }

# ---------- Output helpers ----------
def pretty_print_case(case, speak=True):
    print("\n=== Random Disease Case ===")
    print(f"Disease: {case['disease']}")
    print(f"Category: {case['category']}")
    print(f"Estimated incubation (days): {case['incubation_days_estimate']}")
    print("Symptoms: " + ", ".join(case['symptoms']))
    print("Suggested treatments: " + "; ".join(case['suggested_treatments']))
    if speak:
        symptoms_text = ", ".join(case['symptoms'])
        treatments_text = "; ".join(case['suggested_treatments'])
        text = (
            f"{case['disease']}. Category: {case['category']}. "
            f"Estimated incubation: {case['incubation_days_estimate']} days. "
            f"Symptoms: {symptoms_text}. "
            f"Treatments: {treatments_text}."
        )
        threading.Thread(target=speak_text, args=(text,), daemon=True).start()

# ---------- CLI interactive loop ----------
def main():
    # default: speech ON
    speak = True
    args = sys.argv[1:]
    if "--no-speak" in args or "-ns" in args:
        speak = False

    print("Big Random Disease Generator — many diseases, symptoms, treatments")
    if speak and not TTS_AVAILABLE:
        print("System TTS not detected. Speech will be attempted but may fail.")
    print("Note: Informational only. Not medical advice.")

    try:
        while True:
            case = generate_case()
            pretty_print_case(case, speak=speak)
            try:
                user_input = input("\nPress Enter to generate again, or type 'q' then Enter to quit: ").strip().lower()
            except (KeyboardInterrupt, EOFError):
                print("\nExiting.")
                break
            if user_input == 'q':
                print("Goodbye.")
                break
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
