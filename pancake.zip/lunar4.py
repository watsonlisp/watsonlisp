# lunar_lander_forward_thrust_upright.py
import tkinter as tk
import math
import random
import time

# --- Configuration ---
WIDTH, HEIGHT = 900, 700
FPS = 60

GRAVITY = 120.0         # pixels / s^2 (downwards)
THRUST_ACCEL = 300.0    # pixels / s^2 when thrusting (forward along nose)
ROTATION_SPEED = 120.0  # degrees / s
FUEL_CONSUMPTION = 12.0 # units / s while thrusting
INITIAL_FUEL = 100.0

SAFE_LANDING_VY = 60.0   # pixels / s
SAFE_LANDING_ANGLE = 12  # degrees from vertical (used for non-pad landings)

# --- Helper functions ---
def rotate_point(px, py, cx, cy, angle_deg):
    a = math.radians(angle_deg)
    s, c = math.sin(a), math.cos(a)
    px -= cx; py -= cy
    xnew = px * c - py * s
    ynew = px * s + py * c
    return xnew + cx, ynew + cy

def point_line_distance(px, py, a, b):
    (x1, y1), (x2, y2) = a, b
    dx = x2 - x1; dy = y2 - y1
    if dx == dy == 0:
        return math.hypot(px - x1, py - y1), (x1, y1)
    t = ((px - x1) * dx + (py - y1) * dy) / (dx*dx + dy*dy)
    t = max(0.0, min(1.0, t))
    projx = x1 + t * dx
    projy = y1 + t * dy
    return math.hypot(px - projx, py - projy), (projx, projy)

# --- Terrain generation ---
def generate_terrain(width, height, segments=14, variance=70):
    points = []
    step = width // segments
    base_y = height - 120
    for i in range(segments + 1):
        jitter = random.randint(-variance, variance)
        y = max(120, min(height - 40, base_y + jitter))
        points.append((i * step, y))
    pad_index = random.randint(2, segments - 2)
    pad_x = pad_index * step
    pad_w = step
    pad_y = (points[pad_index][1] + points[pad_index+1][1]) // 2
    points[pad_index] = (points[pad_index][0], pad_y)
    points[pad_index+1] = (points[pad_index+1][0], pad_y)
    pad_w = int(pad_w * 1.2)
    return points, (pad_x + pad_w//2, pad_y, pad_w)

# --- Lander class ---
class Lander:
    def __init__(self, x, y):
        self.reset(x, y)

    def reset(self, x, y):
        self.x = x
        self.y = y
        self.vx = 0.0
        self.vy = 0.0
        # Start upright: nose pointing up -> angle = 270 degrees (0 = right)
        self.angle = 270.0
        self.fuel = INITIAL_FUEL
        self.width = 28
        self.height = 40
        self.alive = True
        self.landed = False
        self.score = 0

    def bottom_point(self):
        return rotate_point(self.x, self.y + self.height//2, self.x, self.y, self.angle)

    def nose_point(self):
        # nose is the forward tip (used for flame direction)
        return rotate_point(self.x + self.width//2, self.y, self.x, self.y, self.angle)

    def update(self, dt, keys):
        if not self.alive or self.landed:
            return
        # Rotation: left = rotate counterclockwise, right = clockwise
        if keys.get('left'):
            self.angle -= ROTATION_SPEED * dt
        if keys.get('right'):
            self.angle += ROTATION_SPEED * dt

        # Keep angle normalized
        self.angle %= 360.0

        # Thrust: forward along nose (0 degrees = right)
        thrusting = keys.get('up') and self.fuel > 0
        if thrusting:
            rad = math.radians(self.angle)
            ax = math.cos(rad) * THRUST_ACCEL
            ay = math.sin(rad) * THRUST_ACCEL
            self.vx += ax * dt
            self.vy += ay * dt
            self.fuel -= FUEL_CONSUMPTION * dt
            if self.fuel < 0:
                self.fuel = 0.0

        # Gravity (always down)
        self.vy += GRAVITY * dt

        # Integrate position
        self.x += self.vx * dt
        self.y += self.vy * dt

        # Horizontal wrap
        if self.x < -50:
            self.x = WIDTH + 50
        elif self.x > WIDTH + 50:
            self.x = -50

# --- Main App ---
class App:
    def __init__(self, root):
        self.root = root
        root.title("Lunar Lander — Upright Start")
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg='black')
        self.canvas.pack()
        self.terrain_points, self.pad = generate_terrain(WIDTH, HEIGHT)
        self.terrain_segs = [(self.terrain_points[i], self.terrain_points[i+1]) for i in range(len(self.terrain_points)-1)]
        self.lander = Lander(WIDTH//2, 120)
        self.keys = {}
        self.message = ""
        self.message_time = 0.0
        self.last_time = time.time()
        root.bind("<KeyPress>", self.on_key_down)
        root.bind("<KeyRelease>", self.on_key_up)
        self.running = True
        self.loop()

    def on_key_down(self, event):
        k = event.keysym.lower()
        if k in ('left', 'right', 'up'):
            self.keys[k] = True
        if k == 'r':
            self.reset_game()

    def on_key_up(self, event):
        k = event.keysym.lower()
        if k in ('left', 'right', 'up'):
            self.keys[k] = False

    def reset_game(self):
        self.terrain_points, self.pad = generate_terrain(WIDTH, HEIGHT)
        self.terrain_segs = [(self.terrain_points[i], self.terrain_points[i+1]) for i in range(len(self.terrain_points)-1)]
        self.lander.reset(WIDTH//2, 120)
        self.message = ""
        self.message_time = 0.0

    def check_collision_and_landing(self):
        bottom = self.lander.bottom_point()
        pad_cx, pad_y, pad_w = self.pad
        pad_left = pad_cx - pad_w//2
        pad_right = pad_cx + pad_w//2
        vertical_tolerance = 10

        # Prioritize pad contact: if bottom point is over pad within tolerance, success (unless catastrophic speed)
        if pad_left <= bottom[0] <= pad_right and abs(bottom[1] - pad_y) <= vertical_tolerance:
            if abs(self.lander.vy) <= 300.0:
                self.lander.landed = True
                self.lander.vx = 0.0
                self.lander.vy = 0.0
                self.lander.score += int(1000 + self.lander.fuel * 5 - abs(self.lander.angle)*2)
                self.message = "Successful landing on pad! Press R to restart."
                self.message_time = 5.0
                return
            else:
                self.lander.alive = False
                self.message = "Crashed on pad! Press R to try again."
                self.message_time = 5.0
                return

        # Otherwise check terrain collisions
        for a, b in self.terrain_segs:
            dist, proj = point_line_distance(bottom[0], bottom[1], a, b)
            if dist < 6:
                vertical_speed = self.lander.vy
                angle_from_vertical = abs((self.lander.angle - 270) % 360)  # convert to degrees from up
                if angle_from_vertical > 180:
                    angle_from_vertical = 360 - angle_from_vertical
                safe_speed = abs(vertical_speed) <= SAFE_LANDING_VY
                safe_angle = angle_from_vertical <= SAFE_LANDING_ANGLE
                if safe_speed and safe_angle:
                    self.lander.landed = True
                    self.lander.vx = 0.0
                    self.lander.vy = 0.0
                    self.lander.score += int(500 + self.lander.fuel * 3)
                    self.message = "Nice landing! Press R to restart."
                    self.message_time = 5.0
                    return
                else:
                    self.lander.alive = False
                    self.message = "Crashed! Press R to try again."
                    self.message_time = 5.0
                    return

    def draw(self):
        self.canvas.delete("all")
        # terrain fill
        pts = [(0, HEIGHT)] + self.terrain_points + [(WIDTH, HEIGHT)]
        flat = []
        for x,y in pts:
            flat.extend((x,y))
        self.canvas.create_polygon(flat, fill='#0b3d91', outline='')
        # terrain lines
        for a,b in self.terrain_segs:
            self.canvas.create_line(a[0], a[1], b[0], b[1], fill='white', width=2)
        # pad
        pad_cx, pad_y, pad_w = self.pad
        self.canvas.create_rectangle(pad_cx - pad_w//2, pad_y - 6, pad_cx + pad_w//2, pad_y + 6, fill='#2ecc71', outline='')
        # lander (triangle with nose pointing according to angle)
        cx, cy = self.lander.x, self.lander.y
        # define triangle relative to center with nose to the right (angle=0)
        nose = (cx + self.lander.width//2, cy)
        left = (cx - self.lander.width//2, cy - self.lander.height//2)
        right = (cx - self.lander.width//2, cy + self.lander.height//2)
        nose = rotate_point(nose[0], nose[1], cx, cy, self.lander.angle)
        left = rotate_point(left[0], left[1], cx, cy, self.lander.angle)
        right = rotate_point(right[0], right[1], cx, cy, self.lander.angle)
        self.canvas.create_polygon(nose[0], nose[1], left[0], left[1], right[0], right[1], fill='white')
        # legs
        leg1 = rotate_point(cx - self.lander.width//2, cy + self.lander.height//2 + 8, cx, cy, self.lander.angle)
        leg2 = rotate_point(cx - self.lander.width//2, cy - self.lander.height//2 - 8, cx, cy, self.lander.angle)
        self.canvas.create_line(left[0], left[1], leg1[0], leg1[1], fill='gray', width=3)
        self.canvas.create_line(right[0], right[1], leg2[0], leg2[1], fill='gray', width=3)
        # thrust flame: draw behind the nose (opposite direction)
        if self.keys.get('up') and self.lander.fuel > 0 and self.lander.alive and not self.lander.landed:
            rad = math.radians(self.lander.angle + 180)
            flame_tip_x = cx + math.cos(rad) * (self.lander.width + 18)
            flame_tip_y = cy + math.sin(rad) * (self.lander.width + 18)
            self.canvas.create_line(cx, cy, flame_tip_x, flame_tip_y, fill='orange', width=4)
        # HUD
        self.canvas.create_text(10, 10, anchor='nw', text=f"Fuel: {self.lander.fuel:.1f}", fill='yellow', font=('Consolas', 14))
        self.canvas.create_text(10, 30, anchor='nw', text=f"Vx: {self.lander.vx:.1f}", fill='white', font=('Consolas', 12))
        self.canvas.create_text(10, 50, anchor='nw', text=f"Vy: {self.lander.vy:.1f}", fill='white', font=('Consolas', 12))
        self.canvas.create_text(10, 70, anchor='nw', text=f"Angle: {self.lander.angle:.1f}° (270° = up)", fill='white', font=('Consolas', 12))
        self.canvas.create_text(10, 90, anchor='nw', text=f"Score: {self.lander.score}", fill='white', font=('Consolas', 12))
        self.canvas.create_text(WIDTH-10, HEIGHT-20, anchor='se', text="Controls: Left/Right rotate  Up thrust (forward)  R restart", fill='gray', font=('Consolas', 12))
        if self.message:
            color = 'green' if 'land' in self.message.lower() else 'red'
            self.canvas.create_text(WIDTH//2, 20, text=self.message, fill=color, font=('Consolas', 16))

    def loop(self):
        now = time.time()
        dt = now - self.last_time
        if dt > 0.1:
            dt = 0.1
        self.last_time = now
        # update
        self.lander.update(dt, self.keys)
        if self.lander.alive and not self.lander.landed:
            self.check_collision_and_landing()
        # message timer
        if self.message_time > 0:
            self.message_time -= dt
            if self.message_time <= 0:
                self.message = ""
        # draw
        self.draw()
        if self.running:
            self.root.after(int(1000 / FPS), self.loop)

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
