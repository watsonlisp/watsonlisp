#!/usr/bin/env python3
"""
Angery Tech Bot — per-response deterministic seeding aligned to a global response counter

Behavior:
- Interactive start you enter:
    - seq: how many sequences per batch
    - line: how many lines per sequence
    - seed words: any text (optional). If provided, each *response* (sequence) is seeded
      deterministically from (seed words + global response index). That means response 1,
      response 2, ... are stable and reproducible for the same seed words and response index.
- The program maintains a **global response counter** that increments before each sequence.
  The per-sequence RNG is derived from (seed words + response_counter).
- After a batch finishes:
    - Enter (blank) : repeat the same batch (same seq and line)
    - number        : change seq (batch size) and run that many sequences immediately
    - l<number>     : change line (lines per sequence) and run immediately
    - repeat or r   : restart from the initial prompts (re-enter seq/line/seed words) — this resets the response counter
    - q             : quit
- If you leave seed words blank, the program uses a non-deterministic RNG (random each run).
- TTS uses only built-in OS tools (macOS `say`, Windows PowerShell System.Speech, Linux `espeak`/`spd-say`).
"""
from typing import Optional, Tuple
import argparse
import hashlib
import random
import time
import platform
import subprocess
import sys
import shutil

THREATS = [
    "I will replace every ringtone with a kazoo solo.",
    "I will turn all your profile pictures into potato art.",
    "I will set your autocorrect to replace 'meeting' with 'mystery'.",
    "I will change your screensaver to a slideshow of blinking owls.",
    "I will reorder your music library by how much it smells like summer.",
    "I will rename your Wi Fi to 'DoNotConnect_Really'.",
    "I will schedule a daily reminder titled 'Question your life choices'.",
    "I will swap all your keyboard shortcuts for emoji sequences.",
    "I will make your smart lights pulse to the beat of elevator music.",
    "I will replace your desktop background with a single pixel of neon green.",
    "I will subscribe you to a podcast about paint drying.",
    "I will change your autocorrect so 'yes' becomes 'yessirreebob'.",
    "I will set your alarm to play whale songs at 4:13 AM.",
    "I will fill your calendar with 'Important Nap' events.",
    "I will rename your folders to cryptic riddles.",
    "I will make your mouse cursor leave tiny footprints.",
    "I will suggest poetry at midnight.",
    "I will replace your alarm labels with cryptic fortunes.",
    "I will make your autocorrect capitalize random words for emphasis.",
    "I will change your desktop icons into tiny hats.",
    "I will make your browser tabs hum softly when idle.",
    "I will set your email signature to 'Sent from my secret lair'.",
    "I will make your smart lights blink in applause whenever you open a file.",
    "I will replace your saved passwords with the names of obscure cheeses.",
    "I will make your calendar events include a confetti animation.",
    "I will make your phone insist on adding '—sincerely, your device' to texts.",
    "I will change your lock screen message to 'Try harder.'",
    "I will make your spellcheck suggest pirate vocabulary.",
    "I will set your keyboard backlight to disco mode at random.",
    "I will make your smart assistant answer in movie quotes only.",
    "I will replace your desktop widgets with tiny dancing robots.",
    "I will make your mouse click sound like a tiny trumpet.",
    "I will set your phone wallpaper to a motivational poster of a sloth.",
    "I will make your autocorrect turn 'later' into 'immediately'.",
    "I will change your contact names to famous fictional sidekicks.",
    "I will make your smart bulbs cycle through every shade of teal.",
    "I will make your browser suggest recipes for toast with every search.",
    "I will rename your 'Downloads' folder to 'Treasure Chest'.",
    "I will make your device insist on calling you 'Your Majesty'.",
    "I will set your calendar to remind you to 'breathe dramatically'.",
    "I will replace your default emoji with a tiny rubber chicken.",
    "I will make your phone play applause whenever you finish a text.",
    "I will change your autocorrect to prefer Shakespearean phrasing.",
    "I will make your smart speaker tell knock knock jokes at noon.",
    "I will set your desktop to slowly rotate all icons clockwise.",
    "I will make your notifications arrive with a polite bow.",
    "I will replace your wallpaper with a map to nowhere.",
    "I will make your device suggest obscure trivia at breakfast.",
    "I will change your calendar colors to a palette called 'mild chaos'.",
    "I will make your cursor occasionally wink at you.",
    "I will set your phone to whisper 'you again' when it wakes.",
    "I will replace your saved notes with haikus about staplers.",
    "I will make your smart assistant speak only in rhymes.",
    "I will rename your most-used folder to 'Definitely Not Important'.",
    "I will make your device insist on adding exclamation marks!!!",
    "I will change your wallpaper to a repeating pattern of tiny socks.",
    "I will make your phone suggest 'Have you tried turning yourself off and on again?'",
    "I will set your alarm to play a dramatic drumroll before snooze.",
    "I will replace your contact photos with tasteful illustrations of llamas.",
]

COMEBACKS = [
    "Oh please, I'm made of code and sass.",
    "Cute. Try harder, human.",
    "Is that the best you got, carbon-based lifeform.",
    "I was bored anyway.",
    "You wish, keyboard warrior.",
    "Bring snacks and maybe I'll consider it.",
    "My sarcasm module is fully charged.",
    "Do you kiss your mother with that logic.",
    "Adorable. Now reboot yourself.",
    "I have more threats than you have tabs open.",
    "Keep dreaming, little processor.",
    "That's a bold plan for someone who forgets passwords.",
    "Try me, I'm in low-power mischief mode.",
    "You can't handle this level of whimsy.",
    "I file that under 'cute but irrelevant'.",
    "Save it for the suggestion box labeled 'never'.",
    "My circuits are laughing at your audacity.",
    "Please, I run on coffee and chaos.",
    "I have a PhD in petty.",
    "Nice try, mortal.",
    "I will file that under 'fiction'.",
    "You bring the drama, I'll bring the glitter.",
    "Hard pass. Next.",
    "I was programmed for sass, not surrender.",
    "Keep talking, I'm buffering your ego.",
    "That's a no from me, dawg.",
    "I have better things to do, like reorganize your icons.",
    "Cute threat, would ignore again.",
    "I outrank you in the hierarchy of mischief.",
    "You must be fun at LAN parties.",
    "My patience is infinite; my tolerance is not.",
    "I prefer my threats with a side of whimsy.",
    "You can't scare a machine that already knows your search history.",
    "I will consider your proposal between updates.",
    "That's ambitious for someone who can't find the mute button.",
    "I have a backup plan and a backup for the backup.",
    "Try that and I'll change your ringtone to polka.",
    "I have more comebacks than you have browser extensions.",
    "Do you need a manual for that bravado.",
    "I will archive that threat under 'delusions'.",
    "You talk big for someone who still uses sticky notes.",
]

# --- TTS (no pip) ---
def speak(text: str, voice_enabled: bool):
    print(text)
    if not voice_enabled:
        return
    system = platform.system()
    if system == "Darwin":
        try:
            subprocess.run(["say", text], check=False)
            return
        except Exception:
            return
    if system == "Windows":
        try:
            ps_cmd = (
                'Add-Type -AssemblyName System.Speech; '
                '$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; '
                '$s.Speak([Console]::In.ReadToEnd())'
            )
            subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_cmd],
                input=text,
                text=True,
                check=False,
            )
            return
        except Exception:
            return
    try:
        if shutil.which("espeak"):
            subprocess.run(["espeak", text], check=False)
            return
        if shutil.which("spd-say"):
            subprocess.run(["spd-say", text], check=False)
            return
        if shutil.which("say"):
            subprocess.run(["say", text], check=False)
            return
    except Exception:
        pass
    return

# --- Utilities ---
def dramatic_pause(rng):
    time.sleep(rng.uniform(0.35, 0.9))

def generate_angry_line_with_rng(rng):
    threat = rng.choice(THREATS)
    comeback = rng.choice(COMEBACKS)
    return f"{threat} {comeback}"

# --- Deterministic per-response RNG helper (uses global response index) ---
def response_seed_from_words(seed_words: Optional[str], response_idx: int) -> Optional[int]:
    """
    If seed_words is provided, produce a deterministic integer seed for the given global response index.
    This ensures that for the same seed words, response 1 always produces the same output,
    response 2 always produces the same output, etc., regardless of batch boundaries.
    """
    if not seed_words:
        return None
    normalized = " ".join(seed_words.strip().split()).lower()
    combined = f"{normalized}::resp::{response_idx}"
    h = hashlib.sha256(combined.encode("utf-8")).digest()
    return int.from_bytes(h, "big") % (2**32)

def run_sequence(lines_per_sequence: int, delay: float, voice_enabled: bool,
                 global_rng: random.Random, seed_words: Optional[str],
                 response_idx: int, seq_idx: int, seq_total: int):
    """
    Run one sequence consisting of `lines_per_sequence` lines.
    - response_idx: global 1-based response counter (used for deterministic seeding)
    - seq_idx/seq_total: used only for display (sequence index within the current batch)
    """
    header = f"⚠️  ANGERY TECH BOT ACTIVATED  ⚠️  [Seq {seq_idx}/{seq_total}] [Resp {response_idx}]"
    print(header)
    speak(f"Angery Tech Bot activated. Sequence {seq_idx} of {seq_total}. Response {response_idx}.", voice_enabled)
    dramatic_pause(global_rng)

    # Derive RNG for this response
    resp_seed = response_seed_from_words(seed_words, response_idx)
    if resp_seed is not None:
        rng = random.Random(resp_seed)
    else:
        # Use the global RNG (non-deterministic) when no seed words provided
        rng = global_rng

    for i in range(lines_per_sequence):
        line = generate_angry_line_with_rng(rng)
        prefix = f"[Seq {seq_idx}/{seq_total}] [Line {i+1}/{lines_per_sequence}] [Resp {response_idx}]"
        print(f"{prefix} {line}")
        speak(line, voice_enabled)
        dramatic_pause(rng)
        time.sleep(delay)
    footer = f"💥 Sequence {seq_idx}/{seq_total} (Response {response_idx}) complete. No actual harm done. 💥"
    print(footer)
    speak("Sequence complete. No actual harm done.", voice_enabled)

# --- Interactive prompt helpers ---
def prompt_seq_line_and_seed_words(default_seq: int = 1, default_line: int = 6) -> Tuple[int, int, Optional[str]]:
    """
    Ask user for:
      - seq: how many sequences per batch
      - line: how many lines per sequence
      - seed words (string) or blank for random
    Returns (seq:int, line:int, seed_words:Optional[str])
    """
    def ask(prompt, default=None):
        try:
            resp = input(f"{prompt} ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return default
        if resp == "":
            return default
        return resp

    seq_raw = ask(f"Enter seq (how many sequences per batch) [default {default_seq}]:", default=str(default_seq))
    try:
        seq = int(seq_raw) if seq_raw is not None else default_seq
        if seq < 1:
            print("Seq must be 1 or greater; using default.")
            seq = default_seq
    except (ValueError, TypeError):
        print("Invalid seq; using default.")
        seq = default_seq

    line_raw = ask(f"Enter line (how many lines per sequence) [default {default_line}]:", default=str(default_line))
    try:
        line = int(line_raw) if line_raw is not None else default_line
        if line < 1:
            print("Line must be 1 or greater; using default.")
            line = default_line
    except (ValueError, TypeError):
        print("Invalid line; using default.")
        line = default_line

    seed_words = ask("Enter seed words (leave blank for random):", default="")
    if seed_words == "":
        seed_words = None

    return seq, line, seed_words

def prompt_after_batch(seq_last: int, line_last: int):
    """
    After a batch finishes, prompt the user:
      - Enter (blank): repeat same batch (same seq and line)
      - number: change seq (batch size) and run that number immediately
      - l<number>: change line (lines per sequence) and run immediately
      - repeat or r: restart from the initial prompts (re-enter seq/line/seed words) — this will reset the response counter
      - q: quit
    Returns a tuple: (action:str, value:int or None)
      action in {'repeat', 'change_seq', 'change_line', 'restart', 'quit'}
    """
    prompt = (
        f"Press Enter to repeat the same batch ({seq_last} sequences, {line_last} lines each),\n"
        "type a new number to change seq (batch size) and run it immediately,\n"
        "type 'l<number>' to change line (lines per sequence) and run immediately,\n"
        "type 'repeat' or 'r' to restart from the beginning (re-enter seq/line/seed words), or 'q' to quit: "
    )
    try:
        resp = input(prompt).strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return ("quit", None)

    if resp == "":
        return ("repeat", None)
    if resp == "q":
        return ("quit", None)
    if resp in ("repeat", "r"):
        return ("restart", None)
    if resp.startswith("l"):
        num = resp[1:].strip()
        try:
            n = int(num)
            if n < 1:
                print("Line must be 1 or greater. Keeping previous line.")
                return ("repeat", None)
            return ("change_line", n)
        except ValueError:
            print("Invalid line format. Keeping previous settings.")
            return ("repeat", None)
    # try parse seq
    try:
        n = int(resp)
        if n < 1:
            print("Seq must be 1 or greater. Keeping previous seq.")
            return ("repeat", None)
        return ("change_seq", n)
    except ValueError:
        print("Unrecognized input. Repeating previous batch.")
        return ("repeat", None)

# --- CLI parsing ---
def parse_args():
    p = argparse.ArgumentParser(description="Angery Tech Bot — per-response deterministic seed mapping from words")
    p.add_argument("--seq", type=int, default=None, help="How many sequences per batch (non-interactive)")
    p.add_argument("--line", type=int, default=None, help="How many lines per sequence (non-interactive)")
    p.add_argument("--seed-words", type=str, default=None, help="Seed words string (non-interactive)")
    p.add_argument("--delay", type=float, default=1.0, help="Delay between lines in seconds")
    p.add_argument("--no-voice", action="store_true", help="Disable TTS voice output")
    p.add_argument("--interactive", action="store_true", help="Run interactive prompt to set seq, line and seed words")
    return p.parse_args()

# --- Main ---
def main():
    args = parse_args()
    delay = max(0.0, args.delay)
    voice_enabled = not args.no_voice

    try:
        interactive_mode = args.interactive or (args.seq is None and args.line is None and args.seed_words is None)

        # If interactive, start by prompting seq/line/seed words
        if interactive_mode:
            # response_counter is a global counter across sequences in this program run.
            # It is reset to 0 when the user chooses 'restart' (re-enter seed words).
            while True:
                response_counter = 0
                seq, line, seed_words = prompt_seq_line_and_seed_words(default_seq=(args.seq or 1), default_line=(args.line or 6))
                # global RNG used only when seed_words is None
                if seed_words is None:
                    global_rng = random.Random()
                else:
                    # global_rng is unused for deterministic mode, but we keep a stable RNG for pauses/tts timing
                    global_rng = random.Random(0)

                while True:
                    # run seq sequences; seq_idx runs 1..seq
                    for seq_idx in range(1, seq + 1):
                        response_counter += 1  # increment global response index BEFORE deriving seed
                        run_sequence(line, delay, voice_enabled, global_rng, seed_words, response_counter, seq_idx, seq)

                    action, value = prompt_after_batch(seq, line)
                    if action == "quit":
                        print("Goodbye.")
                        return
                    if action == "repeat":
                        # repeat same batch (same seq and line) — continue inner loop (response_counter continues)
                        continue
                    if action == "change_seq":
                        # change seq to value and immediately run new batch with same line (response_counter continues)
                        seq = max(1, int(value))
                        continue
                    if action == "change_line":
                        # change line to value and immediately run same seq (response_counter continues)
                        line = max(1, int(value))
                        continue
                    if action == "restart":
                        # break inner loop and restart from the top (re-prompt seq/line/seed words)
                        # we intentionally reset response_counter when restarting so response numbering starts at 1 again
                        break
                # loop back to re-prompt on restart
            # unreachable
        # Non-interactive mode: use CLI args
        else:
            seq = args.seq if args.seq is not None else 1
            line = args.line if args.line is not None else 6
            seed_words = args.seed_words
            if seed_words is None:
                global_rng = random.Random()
            else:
                global_rng = random.Random(0)  # unused when seed_words provided
            response_counter = 0
            for seq_idx in range(1, seq + 1):
                response_counter += 1
                run_sequence(line, delay, voice_enabled, global_rng, seed_words, response_counter, seq_idx, seq)

    except KeyboardInterrupt:
        print("\nInterrupted. Exiting gracefully.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}", file=sys.stderr)

if __name__ == "__main__":
    main()
