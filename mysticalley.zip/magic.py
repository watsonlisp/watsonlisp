import random

# List of all 20 Magic 8-Ball responses
responses = [
    "It is certain.",
    "It is decidedly so.",
    "Without a doubt.",
    "Yes – definitely.",
    "You may rely on it.",
    "As I see it, yes.",
    "Most likely.",
    "Outlook good.",
    "Yes.",
    "Signs point to yes.",
    "Reply hazy, try again.",
    "Ask again later.",
    "Better not tell you now.",
    "Cannot predict now.",
    "Concentrate and ask again.",
    "Don't count on it.",
    "My reply is no.",
    "My sources say no.",
    "Outlook not so good.",
    "Very doubtful."
]

# Simulate shaking the Magic 8-Ball
def magic_8_ball():
    print("🎱 Magic 8-Ball says:", random.choice(responses))

# Run the program
if __name__ == "__main__":
    input("Ask your yes/no question and press Enter to shake the Magic 8-Ball... ")
    magic_8_ball()
#sentence2 = str(input('pause '))
