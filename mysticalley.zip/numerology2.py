def numerology_analysis(name):
    name = name.lower()
    numerology_dict = {
        'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9,
        'j': 1, 'k': 2, 'l': 3, 'm': 4, 'n': 5, 'o': 6, 'p': 7, 'q': 8, 'r': 9,
        's': 1, 't': 2, 'u': 3, 'v': 4, 'w': 5, 'x': 6, 'y': 7, 'z': 8
    }
    total = sum(numerology_dict.get(char, 0) for char in name if char.isalpha())
    while total >= 10 and total not in {11, 22}:
        total = sum(int(digit) for digit in str(total))
    return total

number_meanings = {
    1: "Leadership, independence, and new beginnings",
    2: "Balance, partnership, and duality",
    3: "Creativity, communication, and joy",
    4: "Stability, organization, and foundation",
    5: "Freedom, adventure, and change",
    6: "Nurturing, responsibility, and compassion",
    7: "Introspection, spirituality, and wisdom",
    8: "Abundance, authority, and success",
    9: "Completion, universal love, and humanitarianism",
    11: "Spiritual insight, intuition, and enlightenment",
    22: "Master builder, vision, and large-scale achievement"
}

def get_number_meaning(number):
    return number_meanings.get(number, "No meaning found")

# Single input call
name = input("Enter a name or word: ")
number = numerology_analysis(name)
print("The numerology number is:", number)
print("Meaning:", get_number_meaning(number))

#sentence2 = str(input('pause '))
