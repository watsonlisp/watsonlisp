import random

def ouija_board():
    options = ['yes', 'no'] + list('ABCDEFGHIJKLMNOPQRSTUVWXYZ') + list('0123456789')
    return random.choice(options)

def ouija_word(length=10):
    word = ''
    while len(word) < length:
        char = ouija_board()
        if len(char) == 1:  # Only add single-character responses
            word += char
    return word

print("Ouija board spells:", ouija_word())
#sentence2 = str(input('pause '))
