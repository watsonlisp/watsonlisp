import random

# Define Major Arcana
major_arcana = {
    "The Fool": "New beginnings, adventure, innocence.",
    "The Magician": "Skill, manifestation, resourcefulness.",
    "The High Priestess": "Intuition, mystery, subconscious mind.",
    "The Empress": "Fertility, beauty, nature.",
    "The Emperor": "Authority, structure, control.",
    "The Hierophant": "Tradition, conformity, spiritual guidance.",
    "The Lovers": "Union, choices, harmony.",
    "The Chariot": "Determination, victory, willpower.",
    "Strength": "Courage, inner strength, compassion.",
    "The Hermit": "Reflection, solitude, inner wisdom.",
    "Wheel of Fortune": "Cycles, fate, turning points.",
    "Justice": "Fairness, truth, law.",
    "The Hanged Man": "Sacrifice, perspective, surrender.",
    "Death": "Transformation, endings, rebirth.",
    "Temperance": "Balance, moderation, purpose.",
    "The Devil": "Temptation, materialism, bondage.",
    "The Tower": "Sudden change, upheaval, revelation.",
    "The Star": "Hope, inspiration, serenity.",
    "The Moon": "Illusion, intuition, uncertainty.",
    "The Sun": "Joy, success, vitality.",
    "Judgement": "Awakening, reckoning, inner calling.",
    "The World": "Completion, wholeness, achievement."
}

# Define Minor Arcana
suits = {
    "Cups": "Emotions, relationships, intuition.",
    "Pentacles": "Material wealth, career, physical health.",
    "Swords": "Intellect, conflict, truth.",
    "Wands": "Creativity, passion, action."
}

rank_meanings = {
    "Ace": "a new beginning",
    "Two": "balance and duality",
    "Three": "growth and collaboration",
    "Four": "stability or stagnation",
    "Five": "conflict or loss",
    "Six": "harmony and generosity",
    "Seven": "challenge and perseverance",
    "Eight": "movement and mastery",
    "Nine": "fruition and intensity",
    "Ten": "completion and burden",
    "Page": "curiosity and messages",
    "Knight": "action and pursuit",
    "Queen": "nurturing and wisdom",
    "King": "authority and mastery"
}


minor_arcana = {}
for suit, theme in suits.items():
    for rank, meaning in rank_meanings.items():
        card_name = f"{rank} of {suit}"
        description = f"{theme} — represents {meaning} within the realm of {suit.lower()}."
        minor_arcana[card_name] = description

# Combine full deck
tarot_deck = {**major_arcana, **minor_arcana}

# Draw random cards
reading = random.sample(list(tarot_deck.items()), 3)

# Display the draw
for position, card in zip(["Past", "Present", "Future"], reading):
    print(f"{position}: {card[0]} - {card[1]}")

#sentence2 = str(input('pause'))

