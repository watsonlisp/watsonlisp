import random

# Symbols and their interpretations
tea_symbols = {
    "leaf": "leaves at crossroads.",
    "stem": "Steady growth ahead.",
    "seed": "New potentials.",
    "flower": "Success in bloom.",
    "bubble": "Ephemeral joys."
}

def read_tea_leaves():
    pattern = random.choices(list(tea_symbols.keys()), k=5)
    print("Tea leaves pattern:", pattern)
    print("Interpretations:")
    for symbol in pattern:
        print(f"{symbol}: {tea_symbols[symbol]}")

read_tea_leaves()
#sentence2 = str(input('pause '))
