import tkinter as tk
import os

def execute_program():
    selected_program = var.get()
    if selected_program == "Program 1":
        os.system("c:/python/battleship8.py")
    elif selected_program == "Program 2":
        os.system("c:/python/biblerandom.py")
    elif selected_program == "Program 3":
        os.system("c:/python/forunecookie2.py")
    elif selected_program == "Program 4":
        os.system("c:/python/horiscope9.py")
    elif selected_program == "Program 5":
        os.system("c:/python/latinmajic.py")
    elif selected_program == "Program 6":
        os.system("c:/python/piglatin2.py")
    elif selected_program == "Program 7":
        os.system("c:/python/powerball.py")
    elif selected_program == "Program 8":
        os.system("c:/python/spinyourluck.py")
    elif selected_program == "Program 9":
        os.system("c:/python/typoencryption4.py")



# Create the main window
root = tk.Tk()
root.title("Program Selector")

# Create a Tkinter variable
var = tk.StringVar(value="Program 1")

# Create radio buttons
radio1 = tk.Radiobutton(root, text="battleship", variable=var, value="Program 1")
radio2 = tk.Radiobutton(root, text="biblerandom", variable=var, value="Program 2")
radio3 = tk.Radiobutton(root, text="forunecookie", variable=var, value="Program 3")
radio4 = tk.Radiobutton(root, text="horiscope", variable=var, value="Program 4")
radio5 = tk.Radiobutton(root, text="latinmajic", variable=var, value="Program 5")
radio6 = tk.Radiobutton(root, text="piglatin", variable=var, value="Program 6")
radio7 = tk.Radiobutton(root, text="powerball", variable=var, value="Program 7")
radio8 = tk.Radiobutton(root, text="spinyourluck", variable=var, value="Program 8")
radio9 = tk.Radiobutton(root, text="typoencryption", variable=var, value="Program 9")



# Pack the radio buttons
radio1.pack(anchor=tk.W)
radio2.pack(anchor=tk.W)
radio3.pack(anchor=tk.W)
radio4.pack(anchor=tk.W)
radio5.pack(anchor=tk.W)
radio6.pack(anchor=tk.W)
radio7.pack(anchor=tk.W)
radio8.pack(anchor=tk.W)
radio9.pack(anchor=tk.W)



# Create a button to execute the selected program
execute_button = tk.Button(root, text="Execute", command=execute_program)
execute_button.pack()

# Run the main loop
root.mainloop()
