import random

def handle_spin(result, player):
    if result == "Whammy":
        print("💥 WHAMMY! You hit a Whammy!")
        if player["winnings"] == 0:
            print("😱 You're already broke—now officially bankrupt!\n")
            player["status"] = "Bankrupt"
        else:
            print("💸 You lost all your winnings!\n")
            player["winnings"] = 0
        player["vacations"] = 0
        player["whammies"] += 1
    elif result == "Vacation":
        print("🌴 Vacation won! Pack your bags!\n")
        player["vacations"] += 1
    elif isinstance(result, int):
        player["winnings"] += result
        print(f"💰 You won ${result}! Total is now ${player['winnings']}\n")
    else:
        print("❓ Unknown spin result.\n")

    # Display status
    print("📊 playa's Status:")
    print(f"Total Winnings: ${player['winnings']}")
    print(f"Vacations Won: {player['vacations']}")
    print(f"Whammies: {player['whammies']}")
    if player["status"] == "Bankrupt":
        print("⚠️ Status: Bankrupt")
    print()


# Setup
player = {"winnings": 0, "vacations": 0, "whammies": 0, "status": ""}
spin_options = ["Whammy", "Vacation", 600, 2400, 1200, 900]

# Game loop
while True:
    test1 = input("🎯 Press Enter to spin or type 'exit' to quit: ")
    if test1.lower() == "exit":
        print("👋 Thanks for playing! Final stats:")
        print(f"Total Winnings: ${player['winnings']}")
        print(f"Vacations Won: {player['vacations']}")
        print(f"Whammies: {player['whammies']}")
        break
    result = random.choice(spin_options)
    print(f"playa spun: {result}")
    handle_spin(result, player)
