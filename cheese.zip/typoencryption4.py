print ('TYPO ENCRYPTION')

import random
import string

def replace_random_char(sentence):
    words = sentence.split()
    replaced_words = []
    
    for word in words:
        if len(word) > 1:
            rand_index = random.randint(0, len(word) - 1)
            rand_char = random.choice(string.ascii_letters)
            letter =  rand_char
            capitalized_letter = letter.upper()
            rand_char = capitalized_letter
            
            new_word = word[:rand_index] + rand_char + word[rand_index + 1:]
            replaced_words.append(new_word)
        else:
            replaced_words.append(word)
            
    new_sentence = ' '.join(replaced_words)
    return new_sentence

# Test the function

sentence = str(input('Enter string '))

sentence = (replace_random_char(sentence))

print (sentence)

sentence2 = str(input('Copy to clipboard? '))

if sentence2 == ("yes"):
    print (sentence)

    import os
def addToClipBoard(text):
    command = 'echo ' + text.strip() + '| clip'
    os.system(command)
addToClipBoard(sentence)
print (' copied ')
