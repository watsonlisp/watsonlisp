import random

# Zodiac logic
def get_zodiac_sign(day, month):
    zodiac_dates = [
        ('Capricorn', (12, 22), (1, 19)),
        ('Aquarius', (1, 20), (2, 18)),
        ('Pisces', (2, 19), (3, 20)),
        ('Aries', (3, 21), (4, 19)),
        ('Taurus', (4, 20), (5, 20)),
        ('Gemini', (5, 21), (6, 20)),
        ('Cancer', (6, 21), (7, 22)),
        ('Leo', (7, 23), (8, 22)),
        ('Virgo', (8, 23), (9, 22)),
        ('Libra', (9, 23), (10, 22)),
        ('Scorpio', (10, 23), (11, 21)),
        ('Sagittarius', (11, 22), (12, 21))
    ]
    for sign, start, end in zodiac_dates:
        start_month, start_day = start
        end_month, end_day = end
        if (month == start_month and day >= start_day) or (month == end_month and day <= end_day):
            return sign
    return 'Capricorn'

# Horoscope generator
def generate_horoscope(sign):
    horoscope_readings = {
        'Aries': [
            "Today is a day for new beginnings.",
            "Your boldness will open doors.",
            "Take charge—your energy is contagious.",
            "A spark inside you wants to leap. Let it.",
            "Someone needs your fire today.",
            "The stars dare you to be the first."
        ],
        'Taurus': [
            "Patience will reward you today.",
            "Stability brings peace.",
            "Indulge in something comforting.",
            "The earth hums in your favor.",
            "A slow step is still progress.",
            "Beauty hides in repetition—notice it."
        ],
        'Gemini': [
            "Embrace your curiosity.",
            "Your words carry power today.",
            "A surprise conversation may shift your perspective.",
            "Duality is your superpower.",
            "You’re the echo and the voice—use both.",
            "A clever twist is waiting in your inbox."
        ],
        'Cancer': [
            "Family brings joy.",
            "Let your emotions guide you.",
            "Nurture your space—it reflects your soul.",
            "The moon whispers secrets tonight.",
            "A memory wants to be revisited.",
            "Your softness is your strength."
        ],
        'Leo': [
            "Shine brightly, Leo.",
            "Your confidence inspires others.",
            "Step into the spotlight—you’ve earned it.",
            "A roar is not always loud.",
            "Someone admires you more than you know.",
            "The sun is your mirror—look again."
        ],
        'Virgo': [
            "Details matter today.",
            "Precision leads to success.",
            "Organize your thoughts before you act.",
            "A list will save your day.",
            "You’re building something invisible—trust it.",
            "Perfection is a direction, not a destination."
        ],
        'Libra': [
            "Seek balance in all things.",
            "Harmony is your strength.",
            "A beautiful moment awaits—notice it.",
            "Two sides want your attention—choose both.",
            "Your grace is contagious.",
            "A quiet compromise will echo loudly."
        ],
        'Scorpio': [
            "Trust your intuition.",
            "Mystery surrounds you—lean in.",
            "Your passion is magnetic today.",
            "A secret wants to be shared.",
            "Depth is your playground.",
            "You see what others miss—don’t ignore it."
        ],
        'Sagittarius': [
            "Adventure awaits!",
            "Freedom fuels your spirit.",
            "Say yes to spontaneity.",
            "A map is optional today.",
            "Your laughter is a compass.",
            "The horizon is waving at you."
        ],
        'Capricorn': [
            "Focus on your goals.",
            "Discipline brings rewards.",
            "Your ambition finds traction today.",
            "A mountain is just a staircase in disguise.",
            "Someone respects your hustle.",
            "You’re closer than you think."
        ],
        'Aquarius': [
            "Innovative ideas flow.",
            "Think outside the box.",
            "Your vision sparks change.",
            "A strange idea might be genius.",
            "You’re the glitch in the matrix—own it.",
            "The future is listening."
        ],
        'Pisces': [
            "Let your creativity soar.",
            "Dreams hold hidden truths.",
            "A poetic moment is unfolding—embrace it.",
            "Water remembers—so do you.",
            "Your intuition is painting today’s canvas.",
            "A daydream might be a prophecy."
        ]
    }
    return random.choice(horoscope_readings.get(sign, ["Follow your heart."]))

# Horoscope loop
def run_horoscope_game():
    print("🌟 Welcome to the Cosmic Horoscope Generator 🌟")
    while True:
        try:
            day = int(input("\nEnter your birth day (1–31): "))
            month = int(input("Enter your birth month (1–12): "))
            sign = get_zodiac_sign(day, month)
            reading = generate_horoscope(sign)
            print(f"\n🔮 Your zodiac sign is: {sign}")
            print(f"✨ Your horoscope: {reading}")
        except ValueError:
            print("Oops! Please enter valid numbers for day and month.")
        
        again = input("\nWould you like another reading? (yes/no): ").strip().lower()
        if again not in ['yes', 'y']:
            print("\nThanks for visiting the stars. Until next time! 🌌")
            break

# Start the game
if __name__ == "__main__":
    run_horoscope_game()
