import string

def to_pig_latin(word):
    vowels = "aeiou"
    prefix = ''
    suffix = ''
    while word and word[0] in string.punctuation:
        prefix += word[0]
        word = word[1:]
    while word and word[-1] in string.punctuation:
        suffix = word[-1] + suffix
        word = word[:-1]

    if not word:
        return prefix + suffix

    first_letter = word[0]
    is_capitalized = word[0].isupper()
    word = word.lower()

    if first_letter in vowels:
        pig = word + "way"
    else:
        pig = word[1:] + word[0] + "ay"

    if is_capitalized:
        pig = pig.capitalize()

    return prefix + pig + suffix

def translate_sentence(sentence):
    words = sentence.split()
    pig_latin_words = [to_pig_latin(word) for word in words]
    return " ".join(pig_latin_words)

# Loop until user types 'exit'
while True:
    sentence = input("\nEnter a sentence to translate into Pig Latin (or type 'exit' to quit):\n")
    if sentence.lower() == "exit":
        print("Goodbye! 🐷")
        break
    translated = translate_sentence(sentence)
    print("\nPig Latin translation:\n" + translated)
