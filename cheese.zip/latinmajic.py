import random

def modify_word(word):
    prefixes = ["un", "re", "in", "dis", "pre", "mis", "over", "under", "sub", "inter"]
    suffixes = ["able", "ible", "ation", "ment", "ness", "ity", "ize", "ise", "ify", "ly"]

    prefix = random.choice(prefixes)
    suffix = random.choice(suffixes)

    return prefix + word + suffix

while True:
    user_word = input("Enter a word (type 'exit' to quit): ")
    if user_word.lower() == 'exit':
        break
    modified_word = modify_word(user_word)
    print("Modified word:", modified_word)
