import random

def quick_pick():
    main_numbers = random.sample(range(1, 70), 5)
    powerball = random.randint(1, 26)
    return sorted(main_numbers), powerball

main_numbers, powerball = quick_pick()
print("Main numbers:", main_numbers)
print("Powerball:", powerball)
sentence2 = str(input('pause '))
