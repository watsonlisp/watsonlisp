import random

def create_grid():
    return [['-' for _ in range(10)] for _ in range(10)]

def print_grid(grid, reveal=False):
    print("  " + " ".join(str(i) for i in range(10)))
    for idx, row in enumerate(grid):
        display_row = []
        for cell in row:
            if cell == 'S' and not reveal:
                display_row.append('-')
            else:
                display_row.append(cell)
        print(str(idx) + " " + " ".join(display_row))

def place_ship(grid, length):
    placed = False
    while not placed:
        orientation = random.choice([0, 1])  # 0 = horizontal, 1 = vertical
        if orientation == 0:
            row = random.randint(0, 9)
            col = random.randint(0, 10 - length)
            if all(grid[row][col + i] == '-' for i in range(length)):
                for i in range(length):
                    grid[row][col + i] = 'S'
                placed = True
        else:
            row = random.randint(0, 10 - length)
            col = random.randint(0, 9)
            if all(grid[row + i][col] == '-' for i in range(length)):
                for i in range(length):
                    grid[row + i][col] = 'S'
                placed = True

def count_hits(grid):
    return sum(row.count('H') for row in grid)

def computer_guess(previous_guesses):
    while True:
        row = random.randint(0, 9)
        col = random.randint(0, 9)
        if (row, col) not in previous_guesses:
            previous_guesses.add((row, col))
            return row, col

# Setup
player_grid = create_grid()
computer_grid = create_grid()
ships = [5, 4, 3, 3, 2]

for ship_length in ships:
    place_ship(player_grid, ship_length)
    place_ship(computer_grid, ship_length)

computer_guesses = set()

print("🚢 Welcome to Battleship: Man vs Machine!")
print("Your fleet is ready. Here's your ocean:")
print_grid(player_grid, reveal=True)

# Gameplay Loop
for turn in range(100):
    print(f"\n🌊 Turn {turn + 1}")

    # Player's Turn
    try:
        guess_row = int(input("Guess Row (0–9): "))
        guess_col = int(input("Guess Col (0–9): "))
    except ValueError:
        print("⚠️ Please enter valid numbers.")
        continue

    if not (0 <= guess_row < 10 and 0 <= guess_col < 10):
        print("🚫 That's not even in the ocean.")
        continue

    cell = computer_grid[guess_row][guess_col]
    if cell == 'S':
        print("💥 Direct hit! The enemy ship shudders.")
        computer_grid[guess_row][guess_col] = 'H'
    elif cell in ['H', 'X']:
        print("🔁 You've already fired there.")
    else:
        print("🌫️ Miss. The sea swallows your shot.")
        computer_grid[guess_row][guess_col] = 'X'

    print("\nEnemy Waters:")
    print_grid(computer_grid)

    if count_hits(computer_grid) == sum(ships):
        print("🎉 Victory! The enemy fleet is sunk.")
        break

    # Computer's Turn
    comp_row, comp_col = computer_guess(computer_guesses)
    cell = player_grid[comp_row][comp_col]
    print(f"\n🤖 Computer fires at {comp_row},{comp_col}...")
    if cell == 'S':
        print("💢 Your ship is hit! The hull groans.")
        player_grid[comp_row][comp_col] = 'H'
    elif cell in ['H', 'X']:
        print("🌀 The machine repeats a shot. Glitch?")
    else:
        print("🌊 Miss. Your fleet remains hidden.")
        player_grid[comp_row][comp_col] = 'X'

    print("\nYour Fleet:")
    print_grid(player_grid, reveal=True)

    if count_hits(player_grid) == sum(ships):
        print("💀 Defeat. Your fleet lies beneath the waves.")
        break
else:
    print("⏳ Stalemate. The ocean keeps its secrets.")

sentence2 = str(input('pause '))
