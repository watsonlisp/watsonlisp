#!/usr/bin/env python3
"""
cribbage_complete.py

Single-file Tkinter Cribbage implementing a full, robust game flow:
- Deal 6, discard 2 to crib, cut starter, full pegging loop with Go rules,
  scoring for hands and crib, pegboard animation, always-visible selectable hand.
- Ctrl+click toggles selection. Reset and Pass buttons included.
- Robust pass/Go handling and CPU play loop to avoid hangs.

Run:
    python cribbage_complete.py
"""
import tkinter as tk
from tkinter import messagebox
import random
from collections import Counter

# -------------------------
# Configuration
# -------------------------
WINDOW_W, WINDOW_H = 1280, 720
CARD_W, CARD_H = 100, 140
CARD_MARGIN = 12
RANKS = "A23456789TJQK"
SUITS = "CDHS"
TARGET_SCORE = 121

PEGBOARD_X = 40
PEGBOARD_Y = 80
PEG_HOLES_PER_ROW = 31
PEG_HOLE_SPACING = 18
PEG_ROWS = 4
PEG_TRACK_LENGTH = TARGET_SCORE

SUIT_COLORS = {"C": "black", "D": "red", "H": "red", "S": "black"}

# -------------------------
# Utilities and scoring
# -------------------------
def new_deck():
    return [r + s for r in RANKS for s in SUITS]

def pip_value(rank):
    if rank in "TJQK":
        return 10
    if rank == "A":
        return 1
    return int(rank)

def score_fifteens(cards):
    vals = [pip_value(r) for r, s in cards]
    count = 0
    n = len(vals)
    for mask in range(1, 1 << n):
        s = sum(vals[i] for i in range(n) if (mask >> i) & 1)
        if s == 15:
            count += 1
    return count * 2

def score_pairs(cards):
    ranks = [r for r, s in cards]
    c = Counter(ranks)
    pts = 0
    for v in c.values():
        if v >= 2:
            pts += v * (v - 1)
    return pts

def score_runs(cards):
    rank_to_num = {r: i+1 for i, r in enumerate(RANKS)}
    nums = sorted(rank_to_num[r] for r, s in cards)
    counts = Counter(nums)
    longest = 0
    total_points = 0
    unique = sorted(set(nums))
    for length in range(3, len(unique) + 1):
        for i in range(len(unique) - length + 1):
            window = unique[i:i+length]
            if window[-1] - window[0] == length - 1:
                mult = 1
                for r in window:
                    mult *= counts[r]
                if length > longest:
                    longest = length
                    total_points = mult * length
                elif length == longest:
                    total_points += mult * length
    return total_points

def score_flush(cards, is_crib=False):
    if len(cards) < 5:
        return 0
    suits_first4 = [s for r, s in cards[:-1]]
    if len(set(suits_first4)) == 1:
        if cards[-1][1] == suits_first4[0]:
            return 5
        return 4 if not is_crib else 0
    return 0

def score_nobs(cards):
    starter = cards[-1]
    for r, s in cards[:-1]:
        if r == "J" and s == starter[1]:
            return 1
    return 0

def score_hand(hand_cards, starter_card, is_crib=False):
    cards = hand_cards + [starter_card]
    points = 0
    points += score_fifteens(cards)
    points += score_pairs(cards)
    points += score_runs(cards)
    points += score_flush(cards, is_crib=is_crib)
    points += score_nobs(cards)
    return points

# -------------------------
# Pegging helpers
# -------------------------
def pegging_score(sequence, new_card):
    vals = [pip_value(c[0]) for c in sequence] + [pip_value(new_card[0])]
    total = sum(vals)
    points = 0
    if total == 15:
        points += 2
    if total == 31:
        points += 2
    ranks = [c[0] for c in sequence] + [new_card[0]]
    last = ranks[::-1]
    pair_count = 1
    for i in range(1, len(last)):
        if last[i] == last[0]:
            pair_count += 1
        else:
            break
    if pair_count >= 2:
        points += pair_count * (pair_count - 1)
    max_run = 0
    for L in range(3, min(len(ranks), 7) + 1):
        tail = ranks[-L:]
        nums = sorted([RANKS.index(r) for r in tail])
        if nums[-1] - nums[0] == L - 1 and len(set(nums)) == L:
            max_run = L
    points += max_run
    return points, total

# -------------------------
# CPU heuristics
# -------------------------
def cpu_choose_discard(hand):
    # simple heuristic: keep 5s, pairs, runs; discard lowest pip-value
    return sorted(hand, key=lambda c: (pip_value(c[0]), RANKS.index(c[0])))[:2]

def cpu_play_card(hand, current_count):
    playable = [c for c in hand if pip_value(c[0]) + current_count <= 31]
    if not playable:
        return None
    # prefer plays that make 15 or 31
    for c in playable:
        if pip_value(c[0]) + current_count in (15, 31):
            return c
    # prefer pairs
    ranks = [c[0] for c in hand]
    for c in playable:
        if ranks.count(c[0]) > 1:
            return c
    # otherwise random playable
    return random.choice(playable)

# -------------------------
# Game state
# -------------------------
class GameState:
    def __init__(self):
        self.scores = {"player": 0, "cpu": 0}
        self.dealer_is_cpu = False
        self.reset_round()

    def reset_round(self):
        self.deck = new_deck()
        random.shuffle(self.deck)
        self.player_hand = []
        self.cpu_hand = []
        self.crib = []
        self.starter = None
        self.pile = []
        self.current_count = 0
        self.passed = {"player": False, "cpu": False}
        self.last_player_to_play = None

    def deal(self):
        self.player_hand = [self.deck.pop() for _ in range(6)]
        self.cpu_hand = [self.deck.pop() for _ in range(6)]

    def player_discard(self, indices):
        indices = sorted(indices, reverse=True)
        for i in indices:
            if 0 <= i < len(self.player_hand):
                self.crib.append(self.player_hand.pop(i))

    def cpu_discard(self, discards):
        for c in discards:
            if c in self.cpu_hand:
                self.cpu_hand.remove(c)
                self.crib.append(c)

    def cut_starter(self):
        self.starter = self.deck.pop()
        return self.starter

    def start_pegging(self):
        self.pile = []
        self.current_count = 0
        self.passed = {"player": False, "cpu": False}
        self.last_player_to_play = None

    def play_card(self, who, card):
        if card is None:
            return 0, False
        val = pip_value(card[0])
        if val + self.current_count > 31:
            return 0, False
        pts, new_total = pegging_score(self.pile, card)
        self.pile.append(card)
        self.current_count = new_total
        if who == "player":
            if card in self.player_hand:
                self.player_hand.remove(card)
        else:
            if card in self.cpu_hand:
                self.cpu_hand.remove(card)
        self.last_player_to_play = who
        self.passed[who] = False
        return pts, True

    def score_showdown(self):
        non_dealer = "cpu" if self.dealer_is_cpu else "player"
        dealer = "player" if self.dealer_is_cpu else "cpu"
        hand_nd = self.cpu_hand if non_dealer == "cpu" else self.player_hand
        hand_d = self.player_hand if dealer == "player" else self.cpu_hand
        pts_nd = score_hand(hand_nd, self.starter, is_crib=False)
        self.scores[non_dealer] += pts_nd
        pts_d = score_hand(hand_d, self.starter, is_crib=False)
        self.scores[dealer] += pts_d
        pts_crib = score_hand(self.crib, self.starter, is_crib=True)
        self.scores[dealer] += pts_crib
        return {non_dealer: pts_nd, dealer: pts_d, "crib": pts_crib}

    def toggle_dealer(self):
        self.dealer_is_cpu = not self.dealer_is_cpu

# -------------------------
# Drawing helpers
# -------------------------
def draw_card_face(canvas, x, y, card, face_up=True, tag=None):
    rect = canvas.create_rectangle(x, y, x + CARD_W, y + CARD_H,
                                   fill="white" if face_up else "#2b6f2b",
                                   outline="black", width=2, tags=(tag,))
    if not face_up:
        for i in range(3):
            canvas.create_oval(x + 8 + i*18, y + 12 + i*12, x + 28 + i*18, y + 32 + i*12, fill="#004", outline="", tags=(tag,))
        return rect
    rank, suit = card[0], card[1]
    # map single-letter suits to Unicode symbols
    suit_symbols = {"C": "♣", "D": "♦", "H": "♥", "S": "♠"}
    symbol = suit_symbols.get(suit, suit)
    color = SUIT_COLORS.get(suit, "black")
    # corner ranks
    canvas.create_text(x + 10, y + 12, text=rank, anchor="nw", font=("Arial", 14, "bold"), fill=color, tags=(tag,))
    canvas.create_text(x + CARD_W - 10, y + CARD_H - 12, text=rank, anchor="se", font=("Arial", 14, "bold"), fill=color, tags=(tag,))
    # large centered suit symbol
    canvas.create_text(x + CARD_W/2, y + CARD_H/2, text=symbol, font=("Arial", 36), fill=color, tags=(tag,))
    return rect

# -------------------------
# PegBoard
# -------------------------
class PegBoard:
    def __init__(self, canvas, x=PEGBOARD_X, y=PEGBOARD_Y):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.hole_radius = 5
        self.holes = []
        self.peg_items = {"player_front": None, "player_back": None, "cpu_front": None, "cpu_back": None}
        self.positions = {"player": 0, "cpu": 0}
        self._build_board()

    def _build_board(self):
        self.holes.clear()
        gap = PEG_HOLE_SPACING
        rows = PEG_ROWS
        per_row = PEG_HOLES_PER_ROW
        sx = self.x
        sy = self.y
        idx = 0
        col = 0
        while idx < PEG_TRACK_LENGTH:
            base_x = sx + col * (per_row * gap + 40)
            for r in range(rows):
                for i in range(per_row):
                    if idx >= PEG_TRACK_LENGTH:
                        break
                    hx = base_x + i * gap
                    hy = sy + r * (gap + 6)
                    self.holes.append((hx, hy))
                    idx += 1
                if idx >= PEG_TRACK_LENGTH:
                    break
            col += 1
        for (hx, hy) in self.holes:
            self.canvas.create_oval(hx - self.hole_radius, hy - self.hole_radius,
                                    hx + self.hole_radius, hy + self.hole_radius,
                                    fill="#ddd", outline="#666", tags=("peg_hole",))
        # clear any existing peg items
        for k, item in list(self.peg_items.items()):
            if item is not None:
                try:
                    self.canvas.delete(item)
                except Exception:
                    pass
            self.peg_items[k] = None
        self._create_pegs()

    def _create_pegs(self):
        # Place pegs according to current stored positions
        self._place_peg("player_front", self.positions["player"], "green", dx=-6, dy=-10)
        self._place_peg("player_back", self.positions["player"], "darkgreen", dx=6, dy=-10)
        self._place_peg("cpu_front", self.positions["cpu"], "orange", dx=-6, dy=10)
        self._place_peg("cpu_back", self.positions["cpu"], "darkorange", dx=6, dy=10)

    def _place_peg(self, name, hole_index, color, dx=0, dy=0):
        hole_index = max(0, min(hole_index, len(self.holes) - 1))
        hx, hy = self.holes[hole_index]
        px = hx + dx
        py = hy + dy
        r = 7
        # create new peg and store its item id
        item = self.canvas.create_oval(px - r, py - r, px + r, py + r, fill=color, outline="black", width=1, tags=("peg", name))
        self.peg_items[name] = item

    def move_player_to(self, who, new_score, animate=True):
        new_score = max(0, min(new_score, PEG_TRACK_LENGTH - 1))
        old = self.positions[who]
        if old == new_score:
            return

        # Determine peg names and offsets
        if who == "player":
            front_name, back_name = "player_front", "player_back"
            dx_front, dx_back = -6, 6
            dy_front, dy_back = -10, -10
        else:
            front_name, back_name = "cpu_front", "cpu_back"
            dx_front, dx_back = -6, 6
            dy_front, dy_back = 10, 10

        # Ensure back peg sits at the old position (instant)
        self._move_peg_to(back_name, old, dx=dx_back, dy=dy_back)

        # Animate front peg from old to new (or jump if animate=False)
        if animate:
            step = 1 if new_score > old else -1
            for pos in range(old + step, new_score + step, step):
                self._move_peg_to(front_name, pos, dx=dx_front, dy=dy_front)
                self.canvas.update()
                self.canvas.after(18)
        else:
            self._move_peg_to(front_name, new_score, dx=dx_front, dy=dy_front)

        # Update stored score
        self.positions[who] = new_score

        # Swap the item ids so the peg that moved becomes the "back" peg next time
        self.peg_items[front_name], self.peg_items[back_name] = (
            self.peg_items[back_name],
            self.peg_items[front_name],
        )

    def _move_peg_to(self, peg_name, hole_index, dx=0, dy=0):
        hole_index = max(0, min(hole_index, len(self.holes) - 1))
        hx, hy = self.holes[hole_index]
        px = hx + dx
        py = hy + dy
        item = self.peg_items.get(peg_name)
        if item is None:
            return
        coords = self.canvas.coords(item)
        if not coords or len(coords) < 4:
            return
        cx = (coords[0] + coords[2]) / 2
        cy = (coords[1] + coords[3]) / 2
        dx_move = px - cx
        dy_move = py - cy
        self.canvas.move(item, dx_move, dy_move)

# -------------------------
# UI
# -------------------------
class CribbageUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Cribbage - Complete")
        self.root.geometry(f"{WINDOW_W}x{WINDOW_H}")
        self.canvas = tk.Canvas(root, width=WINDOW_W, height=WINDOW_H, bg="#2b6f2b")
        self.canvas.pack(fill="both", expand=True)

        self.game = GameState()
        self.card_tag_prefix = "player_card_"
        self.selected_for_discard = []
        self.selected_for_play = None

        self.pegboard = PegBoard(self.canvas, x=PEGBOARD_X, y=PEGBOARD_Y)
        self._build_controls()
        self.new_round()

    def _build_controls(self):
        frame = tk.Frame(self.root, bg="#2b6f2b")
        frame.place(x=10, y=10)
        self.deal_btn = tk.Button(frame, text="Deal", command=self.on_deal)
        self.deal_btn.pack(side="left", padx=4)
        self.discard_btn = tk.Button(frame, text="Discard to Crib", command=self.on_discard, state="disabled")
        self.discard_btn.pack(side="left", padx=4)
        self.cut_btn = tk.Button(frame, text="Cut Starter", command=self.on_cut, state="disabled")
        self.cut_btn.pack(side="left", padx=4)
        self.play_btn = tk.Button(frame, text="Play Selected", command=self.on_play, state="disabled")
        self.play_btn.pack(side="left", padx=4)
        self.pass_btn = tk.Button(frame, text="Pass", command=self.on_pass, state="disabled")
        self.pass_btn.pack(side="left", padx=4)
        self.reset_btn = tk.Button(frame, text="Reset Game", command=self.on_reset)
        self.reset_btn.pack(side="left", padx=8)
        self.info_label = tk.Label(self.root, text="Mode: idle", bg="#2b6f2b", fg="white")
        self.info_label.place(x=10, y=50)
        tips = ("Tips: Ctrl+click toggles selection; discard carefully; peg 15s/31s; "
                "use Pass when you cannot play.")
        self.tips_label = tk.Label(self.root, text=tips, bg="#2b6f2b", fg="white")
        self.tips_label.place(x=10, y=72)
        self.score_label = tk.Label(self.root, text="You: 0   CPU: 0", bg="#2b6f2b", fg="white")
        self.score_label.place(x=WINDOW_W - 220, y=10)

        # --- ADD: pegging count label ---
        self.count_label = tk.Label(self.root, text="Count: 0", bg="#2b6f2b", fg="white")
        self.count_label.place(x=WINDOW_W - 220, y=36)

    def new_round(self):
        self.game.reset_round()
        self.selected_for_discard = []
        self.selected_for_play = None
        self.pegboard.move_player_to("player", self.game.scores["player"], animate=False)
        self.pegboard.move_player_to("cpu", self.game.scores["cpu"], animate=False)
        self.draw_static()
        self.draw_hand()
        self.deal_btn.config(state="normal")
        self.discard_btn.config(state="disabled")
        self.cut_btn.config(state="disabled")
        self.play_btn.config(state="disabled")
        self.pass_btn.config(state="disabled")
        self.info_label.config(text="Mode: idle")
        self.update_score_label()
        if hasattr(self, "count_label"):
            self.update_count_label()

    def draw_static(self):
        self.canvas.delete("static")
        self.canvas.create_text(WINDOW_W/2, 40, text="CPU Hand", fill="white", font=("Arial", 16), tags=("static",))
        self.canvas.create_text(WINDOW_W/2, WINDOW_H - 40, text="Your Hand", fill="white", font=("Arial", 16), tags=("static",))
        self.canvas.create_text(120, WINDOW_H/2 - 60, text="Crib", fill="white", tags=("static",))
        self.canvas.create_text(WINDOW_W - 120, WINDOW_H/2 - 60, text="Pile", fill="white", tags=("static",))

    def draw_hand(self):
        # dynamic elements only
        self.canvas.delete("dynamic")
        # CPU face-down
        cpu_count = len(self.game.cpu_hand)
        cpu_total_width = cpu_count * CARD_W + max(0, cpu_count - 1) * CARD_MARGIN
        cpu_x0 = max(20, (WINDOW_W - cpu_total_width) / 2)
        for i, c in enumerate(self.game.cpu_hand):
            x = cpu_x0 + i * (CARD_W + CARD_MARGIN)
            draw_card_face(self.canvas, x, 60, c, face_up=False, tag="dynamic")
        # Player hand always visible
        ph_count = len(self.game.player_hand)
        total_width = ph_count * CARD_W + max(0, ph_count - 1) * CARD_MARGIN
        x0 = max(20, (WINDOW_W - total_width) / 2)
        y = WINDOW_H - CARD_H - 20
        for i, c in enumerate(self.game.player_hand):
            x = x0 + i * (CARD_W + CARD_MARGIN)
            tag = f"{self.card_tag_prefix}{i}"
            draw_card_face(self.canvas, x, y, c, face_up=True, tag=tag)
            # bind to tag so binding persists across redraws
            self.canvas.tag_bind(tag, "<Button-1>", lambda ev, idx=i: self.on_player_card_click(ev, idx))
        # crib (unchanged)
        crib_x = 20 + 10
        crib_y = WINDOW_H/2 - 100
        for i, c in enumerate(self.game.crib):
            draw_card_face(self.canvas, crib_x + i*24, crib_y, c, face_up=False, tag="dynamic")

        # pile - show more recent cards, fanned horizontally
        pile_cards = list(self.game.pile)
        max_show = 8  # change this to show more or fewer cards
        show = pile_cards[-max_show:] if pile_cards else []
        pile_spacing = 22  # horizontal offset between stacked pile cards
        # compute leftmost x so the rightmost card sits near the right edge
        right_edge_x = WINDOW_W - 20 - CARD_W
        left_x = right_edge_x - (len(show) - 1) * pile_spacing if show else right_edge_x
        pile_y = WINDOW_H/2 - 100
        for i, c in enumerate(show):
            x = left_x + i * pile_spacing
            # draw older cards slightly lower so newer cards appear on top visually
            y_offset = (len(show) - 1 - i) * 6
            draw_card_face(self.canvas, x, pile_y + y_offset, c, face_up=True, tag="dynamic")
        # if there are more cards than shown, display a small counter badge
        if len(pile_cards) > max_show:
            badge_x = right_edge_x + CARD_W - 28
            badge_y = pile_y - 8
            self.canvas.create_oval(badge_x - 12, badge_y - 12, badge_x + 12, badge_y + 12,
                                    fill="black", outline="white", tags=("dynamic",))
            self.canvas.create_text(badge_x, badge_y, text=str(len(pile_cards)), fill="white",
                                    font=("Arial", 10, "bold"), tags=("dynamic",))

        # starter
        if self.game.starter:
            sx = WINDOW_W/2 - CARD_W/2
            sy = WINDOW_H/2 - CARD_H/2
            draw_card_face(self.canvas, sx, sy, self.game.starter, face_up=True, tag="dynamic")
        # highlight selections
        if self.discard_btn['state'] == 'normal':
            self._highlight_indices(self.selected_for_discard, x0)
        else:
            if self.selected_for_play is not None:
                self._highlight_indices([self.selected_for_play], x0)

        # Update count label at end of redraw
        if hasattr(self, "count_label"):
            self.update_count_label()

    def _highlight_indices(self, indices, x0):
        for i in indices:
            if 0 <= i < len(self.game.player_hand):
                x = x0 + i * (CARD_W + CARD_MARGIN)
                self.canvas.create_rectangle(x-3, WINDOW_H - CARD_H - 24, x + CARD_W + 3, WINDOW_H - 18,
                                             outline="yellow", width=3, tags=("dynamic",))

    # -------------------------
    # Input handlers and game flow
    # -------------------------
    def on_deal(self):
        self.game.deal()
        self.selected_for_discard = []
        self.selected_for_play = None
        self.info_label.config(text="Mode: discard (select up to 2; Ctrl toggles)")
        self.draw_hand()
        self.deal_btn.config(state="disabled")
        self.discard_btn.config(state="normal")
        self.cut_btn.config(state="disabled")
        self.play_btn.config(state="disabled")
        self.pass_btn.config(state="disabled")

    def on_player_card_click(self, event, idx):
        ctrl_held = bool(event.state & 0x0004)
        if self.discard_btn['state'] == 'normal':
            if ctrl_held:
                if idx in self.selected_for_discard:
                    self.selected_for_discard.remove(idx)
                else:
                    if len(self.selected_for_discard) >= 2:
                        messagebox.showinfo("Selection", "Already selected two cards. Ctrl-click to deselect.")
                        return
                    self.selected_for_discard.append(idx)
            else:
                if idx in self.selected_for_discard:
                    self.selected_for_discard.remove(idx)
                else:
                    if len(self.selected_for_discard) >= 2:
                        messagebox.showinfo("Selection", "Already selected two cards. Use Ctrl to toggle.")
                        return
                    self.selected_for_discard.append(idx)
            self.draw_hand()
        else:
            # play stage: single select; Ctrl toggles
            if ctrl_held:
                if self.selected_for_play == idx:
                    self.selected_for_play = None
                else:
                    self.selected_for_play = idx
            else:
                self.selected_for_play = idx
            self.draw_hand()

    def on_discard(self):
        if len(self.selected_for_discard) != 2:
            messagebox.showinfo("Discard", "Select exactly two cards to discard to the crib.")
            return
        if any(i < 0 or i >= len(self.game.player_hand) for i in self.selected_for_discard):
            messagebox.showinfo("Discard", "Invalid selection.")
            return
        self.game.player_discard(self.selected_for_discard)
        cpu_discards = cpu_choose_discard(self.game.cpu_hand)
        self.game.cpu_discard(cpu_discards)
        self.selected_for_discard = []
        self.draw_hand()
        self.discard_btn.config(state="disabled")
        self.cut_btn.config(state="normal")
        self.info_label.config(text="Mode: idle")
        messagebox.showinfo("Cut", "Click 'Cut Starter' to reveal the starter card.")

    def on_cut(self):
        starter = self.game.cut_starter()
        self.draw_hand()
        self.cut_btn.config(state="disabled")
        self.game.start_pegging()
        self.play_btn.config(state="normal")
        self.pass_btn.config(state="normal")
        self.info_label.config(text="Mode: play (select 1; Ctrl toggles)")
        self.draw_hand()
        if hasattr(self, "count_label"):
            self.update_count_label()
        messagebox.showinfo("Pegging", "Pegging begins. Select a card and click 'Play Selected' to play, or click Pass if you cannot play.")

    def on_play(self):
        # Validate selection
        if self.selected_for_play is None:
            messagebox.showinfo("Play", "Select one card to play.")
            return
        if self.selected_for_play < 0 or self.selected_for_play >= len(self.game.player_hand):
            messagebox.showinfo("Play", "Invalid selection.")
            return
        # Attempt player play
        card = self.game.player_hand[self.selected_for_play]
        pts, ok = self.game.play_card("player", card)
        if not ok:
            messagebox.showinfo("Invalid", "That play would bust the count.")
            return
        # Successful play
        self.game.last_player_to_play = "player"
        self.game.passed["player"] = False
        if pts:
            self.game.scores["player"] += pts
            self.pegboard.move_player_to("player", self.game.scores["player"], animate=True)
            messagebox.showinfo("Pegging", f"You scored {pts} pegging points.")
        self.selected_for_play = None
        self.draw_hand()
        if hasattr(self, "count_label"):
            self.update_count_label()
        # CPU responds: play as long as it can until it passes
        while True:
            cpu_card = cpu_play_card(self.game.cpu_hand, self.game.current_count)
            if cpu_card is None:
                self.game.passed["cpu"] = True
                break
            pts_cpu, ok_cpu = self.game.play_card("cpu", cpu_card)
            if not ok_cpu:
                self.game.passed["cpu"] = True
                break
            # CPU played successfully
            self.game.last_player_to_play = "cpu"
            self.game.passed["cpu"] = False
            if pts_cpu:
                self.game.scores["cpu"] += pts_cpu
                self.pegboard.move_player_to("cpu", self.game.scores["cpu"], animate=True)
                messagebox.showinfo("Pegging", f"CPU scored {pts_cpu} pegging points.")
            self.draw_hand()
            if hasattr(self, "count_label"):
                self.update_count_label()
            # continue loop to see if CPU can play again
        # After both had chance, check Go condition
        self._handle_go_and_reset_if_needed()
        # Showdown if both hands empty
        if not self.game.player_hand and not self.game.cpu_hand:
            self._do_showdown_and_next()
        else:
            self.update_score_label()

    def on_pass(self):
        # Player chooses to pass (cannot play)
        self.game.passed["player"] = True
        # CPU plays as long as it can
        while True:
            cpu_card = cpu_play_card(self.game.cpu_hand, self.game.current_count)
            if cpu_card is None:
                self.game.passed["cpu"] = True
                break
            pts_cpu, ok_cpu = self.game.play_card("cpu", cpu_card)
            if not ok_cpu:
                self.game.passed["cpu"] = True
                break
            self.game.last_player_to_play = "cpu"
            self.game.passed["cpu"] = False
            if pts_cpu:
                self.game.scores["cpu"] += pts_cpu
                self.pegboard.move_player_to("cpu", self.game.scores["cpu"], animate=True)
                messagebox.showinfo("Pegging", f"CPU scored {pts_cpu} pegging points.")
            self.draw_hand()
            if hasattr(self, "count_label"):
                self.update_count_label()
        # After CPU plays, handle Go/reset
        self._handle_go_and_reset_if_needed()
        # If both hands empty -> showdown
        if not self.game.player_hand and not self.game.cpu_hand:
            self._do_showdown_and_next()
        else:
            self.update_score_label()

    def _handle_go_and_reset_if_needed(self):
        # If both passed, award Go to last_player_to_play (if any), then reset pile/count
        if self.game.passed["player"] and self.game.passed["cpu"]:
            if self.game.last_player_to_play:
                # Award 1 point for Go (unless last play was 31 which already gave 2)
                self.game.scores[self.game.last_player_to_play] += 1
                self.pegboard.move_player_to(self.game.last_player_to_play, self.game.scores[self.game.last_player_to_play], animate=True)
                messagebox.showinfo("Go", f"{self.game.last_player_to_play.capitalize()} scores 1 point for Go.")
            # Reset pile and count and passed flags
            self.game.pile = []
            self.game.current_count = 0
            self.game.passed = {"player": False, "cpu": False}
            self.game.last_player_to_play = None
            self.draw_hand()
            if hasattr(self, "count_label"):
                self.update_count_label()

    def _do_showdown_and_next(self):
        pts = self.game.score_showdown()
        # animate final scoring
        self.pegboard.move_player_to("player", self.game.scores["player"], animate=True)
        self.pegboard.move_player_to("cpu", self.game.scores["cpu"], animate=True)
        messagebox.showinfo("Showdown", f"Hand scores:\nYou: {pts.get('player',0)}\nCPU: {pts.get('cpu',0)}\nCrib: {pts.get('crib',0)}")
        self.update_score_label()
        if self.game.scores["player"] >= TARGET_SCORE or self.game.scores["cpu"] >= TARGET_SCORE:
            winner = "You" if self.game.scores["player"] >= TARGET_SCORE else "CPU"
            messagebox.showinfo("Game Over", f"{winner} wins!")
            self.root.quit()
        else:
            self.game.toggle_dealer()
            self.new_round()

    def on_reset(self):
        # Reset scores and start a fresh game
        self.game.scores = {"player": 0, "cpu": 0}
        self.new_round()
        self.pegboard.move_player_to("player", 0, animate=False)
        self.pegboard.move_player_to("cpu", 0, animate=False)
        messagebox.showinfo("Reset", "Game and scores have been reset.")

    def update_score_label(self):
        """Refresh the score label and ensure pegboard reflects scores."""
        self.score_label.config(text=f"You: {self.game.scores.get('player', 0)}   CPU: {self.game.scores.get('cpu', 0)}")
        # Keep pegboard in sync (non-animated update)
        try:
            self.pegboard.move_player_to("player", self.game.scores.get("player", 0), animate=False)
            self.pegboard.move_player_to("cpu", self.game.scores.get("cpu", 0), animate=False)
        except Exception:
            pass

    def update_count_label(self):
        """Update the pegging count label to reflect game.current_count."""
        self.count_label.config(text=f"Count: {self.game.current_count}")

# -------------------------
# Entry point
# -------------------------
def main():
    root = tk.Tk()
    app = CribbageUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
