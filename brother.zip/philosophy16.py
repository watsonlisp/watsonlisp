#!/usr/bin/env python3
"""
philosophy_advisor_aligned_search_full_maps.py
Improved alignment: searches across all advice lines and scores them by overlap
with the user's input (words, bigrams, and keyword matches). Deterministic
seeding from user input; automatic TTS when available; repeat/quit supported.

This version restores the full PHILOSOPHY_MAP and KEYWORD_MAP, includes a
session interaction count, repeats the search using the count to cycle
through top candidates when the user repeats advice, and when the user enters
'c' or 'count' it repeats the search that number of times for the last prompt.

Note: Next-step suggestions have been deduplicated and the "Turn off notifications..."
suggestion removed. Next-step selection now uses system randomness for greater unpredictability.
"""

from __future__ import annotations
import random
import secrets
import textwrap
import argparse
import subprocess
import platform
import sys
import hashlib
import re
from typing import List, Tuple, Dict

# ---------------------------
# PHILOSOPHY_MAP (full, restored)
# ---------------------------
PHILOSOPHY_MAP: Dict[str, Dict[str, List[str] or str]] = {
    "stoicism": {
        "advice": [
            "Focus on what you can control and accept what you cannot.",
            "Turn obstacles into practice: treat difficulty as training for character.",
            "Name the facts, then choose one small, constructive action.",
            "Practice a brief pause before reacting; that pause is your power.",
            "Reframe setbacks as opportunities to exercise patience and skill.",
            "Keep a short list of core principles and consult it when shaken.",
            "When overwhelmed, ask: 'Is this within my control?' and act accordingly.",
            "Use a nightly review: what did you control well today and what will you improve?"
        ],
        "prompt": "What is one small thing in this situation that is within your control?"
    },
    "epictetus": {
        "advice": [
            "Remember: it's not events that disturb us but our judgments about them.",
            "Separate impressions from actions; choose your response deliberately.",
            "Practice saying 'I can accept this' to reduce resistance and wasted energy.",
            "Ask which belief about this situation is helping you and which is harming you.",
            "Use short maxims to steady your mind: 'This too is indifferent.'",
            "When upset, list three facts and one action you can take now.",
            "Treat desires as requests, not commands; decide which to honor."
        ],
        "prompt": "Which judgment could you reframe to reduce distress?"
    },
    "seneca": {
        "advice": [
            "Value time as your most precious resource; protect it from trivialities.",
            "When overwhelmed, cut one nonessential task and notice the relief.",
            "Practice gratitude for small things to shift perspective from lack to plenty.",
            "Write a short 'what matters' list and use it to prune your day.",
            "Remember that anxiety often comes from fearing future loss; ground yourself in now.",
            "Simplify commitments for a week and observe how clarity returns."
        ],
        "prompt": "What small thing can you stop doing today to reclaim time?"
    },
    "marcus_aurelius": {
        "advice": [
            "Observe your thoughts like clouds; they pass and are not you.",
            "Return to the present moment and the task at hand with calm attention.",
            "Remind yourself of the larger story: your role is small but meaningful.",
            "Use short meditative phrases to steady the mind during stress.",
            "Practice compassion for others; it often softens your own distress.",
            "When tempted to complain, ask what action would be more useful."
        ],
        "prompt": "What immediate action aligns with your principles right now?"
    },
    "existentialism": {
        "advice": [
            "Meaning is created through choices; choose deliberately and accept responsibility.",
            "When life feels absurd, commit to a project that expresses your values.",
            "Face freedom as an opportunity rather than a burden; small choices matter.",
            "Name the value you want to embody and take one concrete step toward it.",
            "If stuck, try a short experiment that expresses a value you admire.",
            "Use creative acts to make meaning rather than waiting for it to appear."
        ],
        "prompt": "What choice could you make now that would feel authentically yours?"
    },
    "sartre": {
        "advice": [
            "You are condemned to be free; use that freedom to define yourself.",
            "Avoid bad faith by naming the choice you are avoiding and why.",
            "Own your commitments; responsibility is the soil of authenticity.",
            "When tempted to blame, ask what choice you could have made instead.",
            "Practice small acts of authorship: decide, commit, and follow through."
        ],
        "prompt": "What choice are you postponing because it feels risky?"
    },
    "camus": {
        "advice": [
            "Accept the tension between desire for meaning and an indifferent world.",
            "Rebel by creating small acts of meaning and joy despite absurdity.",
            "Find dignity in persistence: keep working on what matters to you.",
            "Use humor and creativity to defy despair and reclaim agency.",
            "When meaning feels absent, build it through relationships and projects."
        ],
        "prompt": "What small creative act could defy the sense of meaninglessness?"
    },
    "utilitarianism": {
        "advice": [
            "Weigh outcomes and favor the option that increases overall well-being.",
            "Consider both immediate and downstream effects on those affected.",
            "Estimate benefits and harms and choose the option with the best net effect.",
            "When uncertain, pick the action that reduces the most suffering.",
            "Balance short-term gains against long-term consequences for the group."
        ],
        "prompt": "Which option likely produces the greatest good for the most people?"
    },
    "bentham": {
        "advice": [
            "Estimate pleasures and pains; small changes can shift net utility.",
            "Ask who benefits and who bears costs before deciding.",
            "Use simple calculations to compare likely outcomes when possible.",
            "Remember that distribution matters: consider intensity and duration of effects."
        ],
        "prompt": "Who gains and who loses from your likely choice?"
    },
    "mill": {
        "advice": [
            "Consider higher pleasures—those that cultivate human flourishing.",
            "Balance individual liberty with the welfare of others.",
            "Protect space for personal development while minimizing harm to others.",
            "When in doubt, favor options that promote long-term human flourishing."
        ],
        "prompt": "Which option best promotes long-term flourishing?"
    },
    "deontology": {
        "advice": [
            "Act according to duties and principles you could will as universal.",
            "Consider whether your action respects persons as ends, not means.",
            "When tempted to compromise, ask whether the rule would be acceptable if universalized.",
            "Honor promises and obligations even when outcomes are uncertain."
        ],
        "prompt": "What principle would you want everyone to follow in this situation?"
    },
    "kant": {
        "advice": [
            "Ask whether your maxim could be a universal law.",
            "Treat others as ends in themselves; check for instrumentalization.",
            "Use reason to test whether your action respects autonomy and dignity.",
            "When tempted to lie or cheat, imagine a world where everyone did the same."
        ],
        "prompt": "Would you will your action as a universal rule?"
    },
    "virtue_ethics": {
        "advice": [
            "Cultivate character through repeated, small virtuous acts.",
            "Ask what a person of practical wisdom would do and practice that.",
            "Focus on becoming the kind of person who naturally makes good choices.",
            "Use role models to shape habits and moral imagination."
        ],
        "prompt": "Which virtue would you like to strengthen this week?"
    },
    "aristotle": {
        "advice": [
            "Aim for the mean between excess and deficiency in your actions.",
            "Practice habits that shape your character toward flourishing.",
            "Reflect on your telos—what kind of life you aim to live—and act accordingly.",
            "Use small, repeated choices to move toward eudaimonia."
        ],
        "prompt": "Where might moderation improve your current approach?"
    },
    "buddhism": {
        "advice": [
            "Notice breath and bodily sensations; presence reduces reactivity.",
            "Observe thoughts without clinging and let them pass like clouds.",
            "Practice compassion for yourself and others as a daily discipline.",
            "Recognize impermanence to reduce attachment and suffering.",
            "Use a short breathing anchor when emotions feel overwhelming."
        ],
        "prompt": "Can you sit for two minutes and simply observe your breath?"
    },
    "zen": {
        "advice": [
            "Simplify and return to direct experience; small rituals ground you.",
            "Use a koan-like question to interrupt habitual thinking and open insight.",
            "Practice doing one thing fully and without distraction.",
            "Let go of conceptual clutter and notice what remains."
        ],
        "prompt": "What simple practice could bring you back to presence now?"
    },
    "taoism": {
        "advice": [
            "Flow with circumstances rather than forcing outcomes; yield when wise.",
            "Balance action and non-action; sometimes yielding is the stronger move.",
            "Cultivate softness and flexibility; rigid plans break under pressure.",
            "Notice where effort is wasted and where gentle attention suffices."
        ],
        "prompt": "Where might letting go produce a better result than pushing?"
    },
    "confucianism": {
        "advice": [
            "Honor relationships and small rituals; they shape moral life.",
            "Lead by example; consistent respectful acts build trust.",
            "Attend to duties in family and community as a path to harmony.",
            "Use modest, steady acts of respect to repair strained ties."
        ],
        "prompt": "What small respectful act could improve a key relationship?"
    },
    "pragmatism": {
        "advice": [
            "Try what works: run a small experiment and learn from the result.",
            "Treat beliefs as tools—keep what helps, discard what doesn't.",
            "Focus on practical consequences when choosing between options.",
            "Iterate quickly: small tests reveal what is useful in context."
        ],
        "prompt": "What small experiment could test your next step?"
    },
    "peirce": {
        "advice": [
            "Use inquiry and fallibilism: test, revise, and iterate your beliefs.",
            "Small, repeatable tests beat grand untested theories.",
            "Record results and refine your approach based on evidence."
        ],
        "prompt": "What tiny test could give you useful evidence this week?"
    },
    "epicureanism": {
        "advice": [
            "Seek simple, sustainable pleasures and avoid excess that causes pain.",
            "Prioritize calm, steady pleasures over fleeting highs.",
            "Distinguish between necessary and unnecessary desires to reduce suffering.",
            "Cultivate friendships and modest comforts as sources of lasting joy."
        ],
        "prompt": "What modest pleasure could you enjoy today that won't cause harm later?"
    },
    "nihilism": {
        "advice": [
            "If nothing has inherent meaning, you are free to create your own.",
            "Use the absence of given meaning as permission to experiment.",
            "Build small projects that feel meaningful to you alone.",
            "Treat meaning as a craft you practice rather than a discovery you wait for."
        ],
        "prompt": "If nothing were required of you, what would you choose to do?"
    },
    "nihilism_variant": {
        "advice": [
            "Recognize the freedom that comes from the absence of inherent meaning.",
            "Try small projects that feel meaningful to you alone."
        ],
        "prompt": "What small project would you start if no one judged you?"
    },
    "phenomenology": {
        "advice": [
            "Describe your experience carefully before interpreting it; clarity reduces bias.",
            "Attend to how things appear to you and note the structures of perception.",
            "Use careful description to separate sensation from story."
        ],
        "prompt": "How would you describe your experience right now in neutral terms?"
    },
    "heidegger": {
        "advice": [
            "Notice how your concerns disclose your world; authenticity begins with awareness.",
            "Name the practical involvements that shape your mood and choices.",
            "Reflect on what 'matters' in your current situation and act from that clarity."
        ],
        "prompt": "What practical concern is most present for you now?"
    },
    "postmodernism": {
        "advice": [
            "Question grand narratives and be alert to how language shapes truth.",
            "Embrace plurality of perspectives and the contingency of meanings.",
            "Be wary of single-story explanations; seek multiple viewpoints."
        ],
        "prompt": "What dominant story are you assuming that might be partial?"
    },
    "feminist_ethics": {
        "advice": [
            "Consider power dynamics and aim to reduce harm from inequality.",
            "Center voices historically marginalized and value lived experience.",
            "Ask who benefits and who is silenced by the current choice."
        ],
        "prompt": "Whose perspective might you be overlooking in this situation?"
    },
    "care_ethics": {
        "advice": [
            "Prioritize relationships and responsiveness over abstract rules.",
            "Attend to concrete needs and the context of each person involved.",
            "Small acts of attention often matter more than grand principles."
        ],
        "prompt": "Who in your circle needs attention, and what would help them most?"
    },
    "humanism": {
        "advice": [
            "Center human dignity and reason when making choices.",
            "Cultivate empathy and practical compassion in everyday acts.",
            "Use reason to balance competing claims while preserving dignity."
        ],
        "prompt": "How can you act to preserve dignity for someone today?"
    },
    "existential_psychology": {
        "advice": [
            "Face anxiety as a signal about freedom and responsibility, not just a symptom.",
            "Use meaning-making practices to transform dread into purposeful action.",
            "Commit to small projects that anchor your sense of purpose."
        ],
        "prompt": "What small commitment could reduce your sense of existential anxiety?"
    },
    "mindfulness": {
        "advice": [
            "Return attention to the present moment whenever you notice distraction.",
            "Label emotions gently and let them pass without identifying with them.",
            "Use short anchors—breath, sound, sensation—to return to now."
        ],
        "prompt": "Can you notice one emotion now and name it without judgment?"
    },
    "virtue_ethics_modern": {
        "advice": [
            "Identify role models and practice the habits they embody.",
            "Small daily acts compound into a virtuous character over time.",
            "Design micro-habits that express the person you want to become."
        ],
        "prompt": "Which daily habit would most clearly express the person you want to be?"
    },
    "care_of_self": {
        "advice": [
            "Treat self-care as a moral practice, not a luxury.",
            "Small, consistent habits often matter more than dramatic changes.",
            "Set tiny, nonnegotiable rituals that protect your baseline energy."
        ],
        "prompt": "What tiny habit could you keep for a week to support yourself?"
    },
    "aesthetics": {
        "advice": [
            "Consider how beauty, form, and meaning shape your emotional life.",
            "Use creative practice to explore values and express what matters.",
            "Make a small aesthetic choice today to lift your mood."
        ],
        "prompt": "What creative act could help you process this feeling?"
    },
    "care_of_others": {
        "advice": [
            "Listen first; practical help follows clear understanding.",
            "Small acts of attention often matter more than grand gestures.",
            "Ask what would be most useful rather than assuming."
        ],
        "prompt": "Who could use a small, concrete act of care from you today?"
    },
    "default": {
        "advice": [
            "Break the situation into facts, feelings, and options; act on one clear option.",
            "Reflect on your values, then choose a small step aligned with them.",
            "If stuck, pick the smallest possible next action and try it."
        ],
        "prompt": "Which of your values is most relevant to this situation?"
    }
}

# ---------------------------
# KEYWORD_MAP (full, restored)
# ---------------------------
KEYWORD_MAP: Dict[str, List[str]] = {
    "stoicism": ["control", "calm", "accept", "endure", "resilience", "stoic", "virtue", "imperturbable", "fortitude"],
    "stoic_practice": ["dichotomy of control", "premeditation", "negative visualization", "memento mori", "practice", "exercise"],
    "epictetus": ["epictetus", "judgment", "externals", "internals"],
    "seneca": ["seneca", "time", "letters", "tranquil", "memento mori"],
    "marcus_aurelius": ["marcus", "aurelius", "meditations", "reflection", "daily practice"],
    "existentialism": ["meaning", "purpose", "exist", "authentic", "choice", "absurd", "freedom", "responsibility", "angst"],
    "existential_crisis": ["angst", "dread", "meaningless", "identity", "purpose crisis", "existential", "void"],
    "sartre": ["sartre", "freedom", "bad faith", "existentialism", "condemned to be free"],
    "camus": ["camus", "absurd", "sisyphus", "revolt", "absurdism"],
    "nihilism": ["nothing matters", "meaningless", "nihil", "void", "nihilism", "absurdity", "no meaning"],
    "nihilism_variant": ["nihilism", "meaningless", "nothing matters", "void", "nihilistic"],
    "absurdism": ["absurd", "sisyphus", "absurdity", "revolt", "camus", "absurdism"],
    "buddhism": ["mindful", "meditate", "suffering", "breath", "present", "buddha", "karma", "dharma", "samsara"],
    "zen": ["zazen", "koan", "wu wei", "simplicity", "nonduality", "zen", "mindfulness"],
    "mindfulness": ["present", "attention", "mindful", "awareness", "observe", "breath", "nonjudgmental"],
    "meditation": ["sit", "breath", "practice", "guided", "silent", "focus", "meditate"],
    "pragmatism": ["works", "practical", "useful", "test", "experiment", "pragmatic", "instrumental"],
    "peirce": ["peirce", "inquiry", "fallibilism", "abduction"],
    "utilitarianism": ["greatest good", "utility", "consequence", "outcome", "benefit", "maximize", "aggregate welfare"],
    "bentham": ["bentham", "hedonic calculus", "pleasure", "pain"],
    "mill": ["mill", "higher pleasures", "liberty", "harm principle"],
    "deontology": ["duty", "rule", "obligation", "categorical", "principle", "rights", "moral law"],
    "kant": ["kant", "categorical imperative", "universalize", "autonomy"],
    "virtue_ethics": ["virtue", "character", "habit", "moral", "excellence", "flourish", "arete"],
    "aristotle": ["aristotle", "golden mean", "eudaimonia", "telos"],
    "care_ethics": ["care", "relationship", "responsiveness", "nurture", "attend", "relational", "context"],
    "feminist_ethics": ["power", "inequality", "marginalized", "feminist", "intersectionality", "voice", "patriarchy"],
    "libertarianism": ["freedom", "autonomy", "liberty", "noncoercion", "individual rights", "self-ownership"],
    "communitarianism": ["community", "common good", "communal", "shared", "solidarity", "belonging"],
    "humanism": ["dignity", "human", "compassion", "reason", "humanist", "secular ethics"],
    "transcendentalism": ["nature", "intuition", "self-reliance", "thoreau", "emerson", "solitude", "inner voice"],
    "romanticism": ["wonder", "imagination", "awe", "emotion", "sublime", "romantic", "beauty"],
    "aesthetics": ["beauty", "art", "aesthetic", "form", "taste", "creative", "poetry", "music"],
    "epistemology": ["know", "knowledge", "justify", "epistemic", "belief", "evidence", "certainty", "skepticism"],
    "logical_positivism": ["testable", "verify", "empirical", "logical positivism", "verification", "observable"],
    "postmodernism": ["narrative", "language", "power", "postmodern", "deconstruct", "relativism", "plurality"],
    "structuralism": ["structure", "system", "pattern", "underlying", "binary", "structure", "relations"],
    "phenomenology": ["experience", "appear", "phenomenon", "perception", "intentionality", "lived experience"],
    "metaphysics": ["being", "identity", "causation", "time", "existence", "metaphysical", "substance"],
    "heidegger": ["heidegger", "being", "authenticity", "dasein"],
    "existential_psychology": ["anxiety", "dread", "meaning-making", "existential", "freedom", "responsibility", "therapy"],
    "therapy": ["therapy", "counseling", "psychotherapy", "CBT", "talk therapy", "support", "therapist"],
    "self_care": ["self-care", "habit", "routine", "wellbeing", "care", "rest", "sleep", "nutrition"],
    "care_of_self": ["self-care", "habit", "routine", "wellbeing", "care", "self compassion"],
    "wellbeing": ["wellbeing", "wellness", "flourish", "balance", "health", "resilience"],
    "resilience": ["bounce back", "resilience", "grit", "adapt", "cope", "endure", "recover"],
    "grief": ["grief", "loss", "bereavement", "mourning", "sadness", "loss of", "farewell"],
    "loss": ["loss", "bereavement", "breakup", "separation", "grief", "missing"],
    "love": ["love", "affection", "romance", "intimacy", "attachment", "care", "passion"],
    "relationships": ["relationship", "partner", "friend", "family", "communication", "boundaries", "conflict"],
    "ethics": ["ethics", "moral", "right", "wrong", "good", "bad", "normative"],
    "morality": ["moral", "virtue", "vice", "duty", "conscience", "moral dilemma"],
    "decision": ["decide", "choice", "option", "weigh", "tradeoff", "dilemma", "deciding"],
    "choice": ["choice", "choose", "select", "option", "commit", "decision"],
    "freedom": ["freedom", "autonomy", "liberty", "free will", "constraint", "choice"],
    "autonomy": ["autonomy", "self-govern", "independence", "agency", "self-determination"],
    "duty": ["duty", "obligation", "responsibility", "commitment", "promise", "deontic"],
    "responsibility": ["responsibility", "accountability", "answerable", "duty", "care"],
    "meaning": ["meaning", "purpose", "significance", "value", "sense", "why", "meaningful"],
    "purpose": ["purpose", "mission", "calling", "goal", "aim", "direction"],
    "anxiety": ["anxiety", "worry", "nervous", "panic", "unease", "stress", "overwhelm"],
    "depression": ["depressed", "sad", "hopeless", "low mood", "anhedonia", "withdrawal"],
    "stress": ["stress", "overwhelm", "pressure", "burnout", "tense", "deadline"],
    "joy": ["joy", "happiness", "delight", "pleasure", "contentment", "bliss"],
    "pleasure": ["pleasure", "enjoy", "delight", "savor", "epicure", "hedonism"],
    "suffering": ["suffering", "pain", "hardship", "sorrow", "suffer", "samsara"],
    "samsara": ["samsara", "cycle", "rebirth", "attachment", "suffering"],
    "nirvana": ["nirvana", "liberation", "awakening", "enlightenment", "freedom from suffering"],
    "wu_wei": ["wu wei", "nonaction", "effortless", "flow", "yield", "letting go"],
    "flow": ["flow", "in the zone", "absorption", "engagement", "optimal experience"],
    "habit": ["habit", "routine", "practice", "ritual", "consistency", "habit loop"],
    "ritual": ["ritual", "ceremony", "routine", "habit", "practice", "small ritual"],
    "virtue": ["virtue", "goodness", "excellence", "moral habit", "character"],
    "vice": ["vice", "temptation", "excess", "addiction", "harmful habit"],
    "character": ["character", "integrity", "honor", "trustworthiness", "reputation"],
    "identity": ["identity", "self", "who am i", "role", "persona", "authenticity"],
    "self": ["self", "ego", "self-concept", "self-image", "inner voice"],
    "ego": ["ego", "pride", "selfish", "defense", "egoic"],
    "authenticity": ["authentic", "genuine", "true self", "honest", "real"],
    "awe": ["awe", "wonder", "sublime", "astonishment", "reverence"],
    "beauty": ["beauty", "sublime", "aesthetic", "beautiful", "artful"],
    "creativity": ["create", "creative", "imagine", "invent", "artist", "maker"],
    "imagination": ["imagination", "fantasy", "vision", "dream", "invent"],
    "poetry": ["poetry", "verse", "lyric", "poem", "metaphor"],
    "music": ["music", "song", "melody", "rhythm", "sound", "listen"],
    "nature": ["nature", "outdoors", "wilderness", "forest", "sea", "natural"],
    "solitude": ["solitude", "alone", "retreat", "quiet", "reflection"],
    "community": ["community", "neighbors", "group", "belonging", "collective"],
    "justice": ["justice", "fairness", "equity", "law", "retribution", "restorative"],
    "rights": ["rights", "entitlement", "claim", "civil rights", "human rights"],
    "equality": ["equality", "equal", "parity", "equitable", "non-discrimination"],
    "power": ["power", "influence", "authority", "domination", "control"],
    "oppression": ["oppression", "marginalize", "subjugate", "exploit", "systemic"],
    "privilege": ["privilege", "advantage", "unearned", "access", "entitlement"],
    "intersectionality": ["intersectionality", "overlap", "multiple identities", "compound disadvantage"],
    "care": ["care", "nurture", "support", "attend", "tend"],
    "nurture": ["nurture", "raise", "foster", "cultivate", "support"],
    "parenting": ["parent", "child", "caregiving", "discipline", "nurture", "attachment"],
    "friendship": ["friend", "ally", "companion", "trust", "loyalty"],
    "empathy": ["empathy", "understand", "feel with", "perspective taking", "compassion"],
    "compassion": ["compassion", "kindness", "mercy", "care", "altruism"],
    "forgiveness": ["forgive", "forgiveness", "let go", "reconcile", "repair"],
    "gratitude": ["gratitude", "thankful", "appreciation", "count blessings"],
    "mindset": ["mindset", "growth", "fixed mindset", "attitude", "beliefs"],
    "growth": ["growth", "improve", "learn", "develop", "progress"],
    "fixed_mindset": ["fixed mindset", "can't change", "stuck", "immutable"],
    "default": ["situation", "problem", "feel", "think", "decide", "question"]
}

# ---------------------------
# Text utilities
# ---------------------------
_WORD_RE = re.compile(r"\b[a-zA-Z0-9']+\b")

STOPWORDS = {
    "the", "is", "and", "a", "an", "to", "of", "in", "on", "for", "with", "that", "this",
    "it", "as", "are", "was", "were", "be", "by", "at", "from", "or", "but", "if", "then",
    "so", "i", "you", "we", "they", "he", "she", "my", "your", "their", "our"
}

def normalize_text(text: str) -> str:
    return " ".join(text.lower().split())

def tokenize(text: str) -> List[str]:
    text = normalize_text(text)
    return [w for w in _WORD_RE.findall(text) if w not in STOPWORDS]

def bigrams(tokens: List[str]) -> List[Tuple[str, str]]:
    return [(tokens[i], tokens[i+1]) for i in range(len(tokens)-1)] if len(tokens) > 1 else []

# ---------------------------
# Matching utilities
# ---------------------------
def find_matched_keywords(user_text: str) -> Dict[str, List[str]]:
    text = normalize_text(user_text)
    matches: Dict[str, List[str]] = {}
    for theme, keywords in KEYWORD_MAP.items():
        matched = []
        for kw in keywords:
            if kw and kw.lower() in text:
                matched.append(kw)
        if matched:
            matches[theme] = matched
    return matches

def seed_from_text(text: str) -> int:
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")

def score_advice_candidate(advice: str, user_tokens: List[str], user_bigrams: List[Tuple[str,str]], matched_keywords: List[str], theme_match_boost: float) -> float:
    adv_tokens = tokenize(advice)
    adv_bigrams = bigrams(adv_tokens)

    word_score = 0.0
    user_set = set(user_tokens)
    for t in adv_tokens:
        if t in user_set:
            word_score += max(1.0, len(t) / 3.0)

    bigram_score = 0.0
    user_bigram_set = set(user_bigrams)
    for bg in adv_bigrams:
        if bg in user_bigram_set:
            bigram_score += 2.0

    kw_score = 0.0
    for kw in matched_keywords:
        if kw.lower() in advice.lower():
            kw_score += max(1.0, len(kw) / 4.0)
        else:
            if kw.lower().split():
                if any(part in advice.lower() for part in kw.lower().split()):
                    kw_score += 0.5

    total = (1.0 * word_score) + (1.8 * bigram_score) + (2.5 * kw_score) + theme_match_boost
    return total

# ---------------------------
# New search across all advice lines
# ---------------------------
def search_responses(user_text: str, top_n: int = 6) -> List[Dict]:
    norm = normalize_text(user_text)
    user_tokens = tokenize(user_text)
    user_bgs = bigrams(user_tokens)
    matched_map = find_matched_keywords(user_text)

    primary_theme = None
    if matched_map:
        def theme_score(kws):
            return (len(kws), sum(len(k) for k in kws))
        primary_theme = max(matched_map.keys(), key=lambda t: theme_score(matched_map[t]))

    candidates = []
    for theme, entry in PHILOSOPHY_MAP.items():
        adv_list = entry.get("advice", [])
        prompt = entry.get("prompt", PHILOSOPHY_MAP["default"]["prompt"])
        matched_keywords = matched_map.get(theme, [])
        theme_boost = 3.0 if theme == primary_theme else 0.0

        for adv in adv_list:
            score = score_advice_candidate(adv, user_tokens, user_bgs, matched_keywords, theme_boost)
            candidates.append({
                "theme": theme,
                "advice": adv,
                "prompt": prompt,
                "score": score,
                "matched_keywords": matched_keywords
            })

    if not candidates:
        default_entry = PHILOSOPHY_MAP["default"]
        return [{
            "theme": "default",
            "advice": default_entry["advice"][0],
            "prompt": default_entry["prompt"],
            "score": 0.0,
            "matched_keywords": []
        }]

    candidates.sort(key=lambda c: c["score"], reverse=True)
    return candidates[:top_n]

# ---------------------------
# Advice generation (uses search_responses)
# ---------------------------
def generate_advice(user_text: str, count: int, override_seed: int | None = None):
    seed = override_seed if override_seed is not None else seed_from_text(user_text)
    rng = random.Random(seed)

    candidates = search_responses(user_text, top_n=6)

    if not candidates:
        entry = PHILOSOPHY_MAP["default"]
        advice = entry["advice"][0]
        prompt = entry["prompt"]
        return f"{advice} (Based on your note: \"{user_text.strip()}\")", prompt, rng, "default", [], 0.0, 0, 1

    total = len(candidates)
    idx = (count - 1) % total if count >= 1 else 0
    chosen = candidates[idx]

    if chosen["score"] == 0.0:
        chosen = candidates[0]
        idx = 0

    personalized = f"{chosen['advice']} (Based on your note: \"{user_text.strip()}\")"
    return personalized, chosen["prompt"], rng, chosen["theme"], chosen["matched_keywords"], chosen["score"], idx, total

# ---------------------------
# TTS and printing helpers
# ---------------------------
def pretty_print(title: str, body: str):
    print("\n" + "=" * 60)
    print(title)
    print("-" * 60)
    print(textwrap.fill(body, width=72))
    print("=" * 60 + "\n")

def speak(text: str) -> bool:
    if not text:
        return False
    system = platform.system()
    try:
        if system == "Darwin":
            subprocess.run(["say", text], check=False)
            return True
        if system == "Windows":
            safe = text.replace("'", "''")
            ps_cmd = (
                "Add-Type -AssemblyName System.Speech;"
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                f"$s.Speak('{safe}');"
            )
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return True
        for cmd in (["spd-say", text], ["espeak", text]):
            try:
                subprocess.run(cmd, check=False)
                return True
            except FileNotFoundError:
                continue
    except Exception:
        pass
    return False

# ---------------------------
# Interaction helpers
# ---------------------------
def list_schools():
    keys = sorted([k for k in PHILOSOPHY_MAP.keys() if k != "default"])
    print("\nAvailable philosophical perspectives:")
    for k in keys:
        print(f"- {k}")
    print()

def prompt_action():
    print("Actions: [r]epeat last advice (cycles)  [c]ount-repeat  [q]uit  [enter] give a new prompt")
    return input("Choose an action (r/c/q or press Enter): ").strip().lower()

def auto_speak_and_print(advice: str, prompt: str, rng: random.Random, theme: str, matched_keywords: List[str], score: float, interaction_count: int, chosen_index: int, total_candidates: int):
    pretty_print("Philosophical Advice", advice)
    pretty_print("Reflective Question", prompt)
    if matched_keywords:
        print("Matched keywords:", ", ".join(matched_keywords))
    print(f"Relevance score: {score:.2f}\n")
    print(f"Advice count (session): {interaction_count}")
    print(f"Selected candidate {chosen_index + 1} of {total_candidates}\n")

    # Deduplicated next_steps list (no repeats, "Turn off notifications..." removed)
    next_steps = [
        "Write a one-sentence action you can take in the next hour.",
        "Try a two-minute breathing exercise and notice how you feel.",
        "List one assumption you can test this week.",
        "Do one small, kind thing for someone else today.",
        "Take five deep breaths and notice how your body responds.",
        "Set a 15-minute timer and work on the smallest next task.",
        "Write down one thing you can let go of this week.",
        "Reach out to one person and say something kind.",
        "Stand up and stretch for two minutes to reset your body.",
        "Take a short walk outside and notice three things you see.",
        "Write a quick gratitude list of three small things.",
        "Name one boundary you need and practice saying it once.",
        "Try a 60-second grounding exercise: name 5 things you can see.",
        "Schedule a 10-minute block to do the smallest next step.",
        "Write a brief note to yourself offering compassion.",
        "Identify one assumption and write how you might test it.",
        "Do a 2-minute body scan and notice tension without judging it.",
        "Put your phone away for the next 30 minutes and focus on one task.",
        "Make a tiny plan: what you will do in the next 10 minutes.",
        "List one thing you can simplify in your day and remove it.",
        "Breathe in for 4, hold 4, out 6 — repeat five times.",
        "Write a short 'if-then' plan for a likely stressor this week.",
        "Choose one small pleasure to savor for five minutes.",
        "Identify a tiny habit to start tomorrow and commit to one day.",
        "Ask someone for a small piece of feedback and note one takeaway.",
        "Write a single sentence describing your priority for today.",
        "Take a moment to notice your posture and adjust it mindfully.",
        "Make a cup of tea and drink it slowly, noticing the taste.",
        "List three things you did well this week, however small.",
        "Set a timer for 25 minutes and work without interruption (Pomodoro).",
        "Write a short letter to your future self about this moment.",
        "Do one small act of repair in a relationship (a text, a call).",
        "Spend five minutes sketching or doodling without judgment.",
        "Name one fear and write a single tiny step to face it.",
        "Practice saying 'not now' to one nonessential demand on your time.",
        "Identify one value and one action that expresses it today.",
        "Take three slow, deliberate breaths before responding to the next message.",
        "Stand in the sun for a minute and notice how it feels on your skin.",
        "Make a short playlist of one song that lifts your mood and play it.",
        "Write down one thing you can delegate or ask help with.",
        "List one resource (person, book, tool) that could help you this week.",
        "Try a 3-minute creative exercise: write a six-word story about today.",
        "Notice one judgment you hold and rephrase it as a question.",
        "Plan a 20-minute break later today and protect that time.",
        "Identify one small boundary to test and practice it once.",
        "Write a brief 'if this happens, then I'll...' coping plan.",
        "Do a quick tidy of one small area to reduce visual clutter.",
        "Say aloud one thing you appreciate about yourself right now.",
        "Take a photo of something that makes you smile and save it.",
        "List one habit to pause for a week and observe the change.",
        "Try a short mindful eating exercise with one small snack.",
        "Write a single sentence describing what 'good enough' looks like here.",
        "Offer yourself permission to rest for 10 minutes without guilt.",
        "Identify one small boundary you can communicate clearly today.",
        "Make a short list of three possible next steps and pick one.",
        "Spend two minutes noticing sounds around you without labeling them.",
        "Write down one question you can ask to gain clarity in this situation.",
        "Take one small action that aligns with a value you care about."
    ]

    # Use system-level randomness for more unpredictable selection
    suggested = secrets.choice(next_steps)
    print("Suggested next step:", suggested)
    spoken = speak(f"{advice} {prompt} {suggested}")
    if not spoken:
        print("(TTS not available on this system; showing text only.)\n")

# ---------------------------
# Main
# ---------------------------
def main():
    parser = argparse.ArgumentParser(description="Philosophy Advisor with content-aligned search and full maps.")
    parser.add_argument("--list", action="store_true", help="List available philosophical perspectives")
    parser.add_argument("--seed", type=int, help="Optional numeric seed to override input-based seeding")
    args = parser.parse_args()

    override_seed = args.seed if args.seed is not None else None

    if args.list:
        list_schools()
        return

    print("Philosophy Advisor — type a short description of how you feel or a question.")
    print("Responses are chosen by searching across all advice lines and aligning to your words.")
    print("Repeating advice cycles through the top aligned responses based on the session count.")
    print("Enter 'c' or 'count' to repeat the search a specific number of times for the last prompt.\n")

    last_user_text = None
    last_advice = None
    last_prompt = None
    last_rng = None
    last_theme = None
    last_matched_keywords: List[str] = []
    last_score = 0.0

    interaction_count = 0

    try:
        while True:
            if last_user_text is not None:
                action = prompt_action()
            else:
                action = input("Choose an action ([q]uit or press Enter to give a new prompt): ").strip().lower()

            if action in ("q", "quit", "exit"):
                print("\nGoodbye — take care.")
                return

            if action in ("r", "repeat"):
                if last_user_text is None:
                    print("No previous advice to repeat. Please enter a prompt first.")
                    continue
                interaction_count += 1
                advice, prompt, rng, theme, matched_keywords, score, chosen_index, total_candidates = generate_advice(last_user_text, interaction_count, override_seed=override_seed)
                last_advice = advice
                last_prompt = prompt
                last_rng = rng
                last_theme = theme
                last_matched_keywords = matched_keywords
                last_score = score
                auto_speak_and_print(advice, prompt, rng, theme, matched_keywords, score, interaction_count, chosen_index, total_candidates)
                continue

            if action in ("c", "count"):
                if last_user_text is None:
                    print("No previous prompt to repeat. Enter a prompt first, then use 'c' to repeat its search.")
                    continue
                raw = input("Repeat the search how many times? Enter a positive integer: ").strip()
                try:
                    n = int(raw)
                    if n <= 0:
                        print("Please enter a positive integer greater than zero.")
                        continue
                except ValueError:
                    print("That's not a valid integer. Try again.")
                    continue

                for i in range(1, n + 1):
                    interaction_count += 1
                    advice, prompt, rng, theme, matched_keywords, score, chosen_index, total_candidates = generate_advice(last_user_text, i, override_seed=override_seed)
                    last_advice = advice
                    last_prompt = prompt
                    last_rng = rng
                    last_theme = theme
                    last_matched_keywords = matched_keywords
                    last_score = score
                    auto_speak_and_print(advice, prompt, rng, theme, matched_keywords, score, interaction_count, chosen_index, total_candidates)
                continue

            user_text = action if action else input("\nTell me what's on your mind (or type 'q' to quit): ").strip()
            if not user_text:
                print("You didn't type anything. Try again when you're ready.")
                continue
            if user_text.lower() in ("q", "quit", "exit"):
                print("\nGoodbye — take care.")
                return
            if user_text.lower() in ("r", "repeat"):
                if last_user_text is None:
                    print("No previous advice to repeat. Please enter a prompt first.")
                    continue
                interaction_count += 1
                advice, prompt, rng, theme, matched_keywords, score, chosen_index, total_candidates = generate_advice(last_user_text, interaction_count, override_seed=override_seed)
                last_advice = advice
                last_prompt = prompt
                last_rng = rng
                last_theme = theme
                last_matched_keywords = matched_keywords
                last_score = score
                auto_speak_and_print(advice, prompt, rng, theme, matched_keywords, score, interaction_count, chosen_index, total_candidates)
                continue
            if user_text.lower() in ("c", "count"):
                if last_user_text is None:
                    print("No previous prompt to repeat. Enter a prompt first, then use 'c' to repeat its search.")
                    continue
                raw = input("Repeat the search how many times? Enter a positive integer: ").strip()
                try:
                    n = int(raw)
                    if n <= 0:
                        print("Please enter a positive integer greater than zero.")
                        continue
                except ValueError:
                    print("That's not a valid integer. Try again.")
                    continue
                for i in range(1, n + 1):
                    interaction_count += 1
                    advice, prompt, rng, theme, matched_keywords, score, chosen_index, total_candidates = generate_advice(last_user_text, i, override_seed=override_seed)
                    last_advice = advice
                    last_prompt = prompt
                    last_rng = rng
                    last_theme = theme
                    last_matched_keywords = matched_keywords
                    last_score = score
                    auto_speak_and_print(advice, prompt, rng, theme, matched_keywords, score, interaction_count, chosen_index, total_candidates)
                continue

            last_user_text = user_text
            interaction_count += 1
            advice, prompt, rng, theme, matched_keywords, score, chosen_index, total_candidates = generate_advice(user_text, interaction_count, override_seed=override_seed)

            last_advice = advice
            last_prompt = prompt
            last_rng = rng
            last_theme = theme
            last_matched_keywords = matched_keywords
            last_score = score

            auto_speak_and_print(advice, prompt, rng, theme, matched_keywords, score, interaction_count, chosen_index, total_candidates)

    except KeyboardInterrupt:
        print("\n\nGoodbye — take care.")
    except Exception as e:
        print("Sorry, something went wrong:", str(e), file=sys.stderr)

if __name__ == "__main__":
    main()
