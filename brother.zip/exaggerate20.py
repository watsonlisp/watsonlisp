#!/usr/bin/env python3
"""
exaggerate_templates_tts_count_control_windows_ps1_fix_full_templates.py

This script:
- Restores the full DEFAULT_TEMPLATES list.
- Provides robust cross-platform TTS with a Windows PowerShell .ps1 fix
  to avoid "ReadAllText" and "PlaySync" invocation errors.
- Interactive: prompts for {input} and optional {count}, supports repeat/restart,
  Enter-to-keep-previous, numeric count entry at post-playback prompt, and TTS toggles.
- No external Python packages required.
"""

from pathlib import Path
import re
import argparse
import random
import subprocess
import sys
import shutil
import tempfile
import os
import time

# --- FULL DEFAULT_TEMPLATES restored (use {input} and/or {count} as placeholders) ---
DEFAULT_TEMPLATES = [
    "I gave {input} 3 cookies and 2 apples.",
    "{input} ran 3-5 miles every day last week.",
    "{input} used 12.5% of the battery in 2 hours.",
    "This is {input} 1st attempt at baking 2 cakes.",
    "{input} invited three friends and twenty neighbors.",
    "{input} owns 1 car, 2 bikes, and a hundred tiny scooters.",
    "{input} and {input} split 4 pizzas among 3 people.",
    "{input} paid $5 for a coffee and $12 for a sandwich.",
    "There were 7 lights on in {input}'s house at midnight.",
    "{input} read 2 books and 15 articles yesterday.",
    "On average {input} drinks 1.5 cups of tea per hour.",
    "{input} scored 98 out of 100 on the test.",
    "{input} has 2 cats, 3 dogs, and 14 fish.",
    "{input} waited in line for 45 minutes and then left.",
    "{input} traveled 120 miles to see the concert.",
    "{input} baked twenty cupcakes for the bake sale.",
    "{input} saved 10% on groceries and 5% on gas.",
    "{input} owns 4 pairs of shoes and 1 hat.",
    "{input} plants 6 trees every spring and 2 in fall.",
    "{input} ran 10k in 42.5 minutes last month.",
    "{input} drank 0.5 liters of water every hour.",
    "{input} borrowed 3-4 books from the library.",
    "{input} has been to 12 countries and plans 8 more.",
    "{input} paid 1st place prize money of $2500.",
    "{input} ate three slices of pizza and twenty fries.",
    "{input} watched 2 seasons and 10 episodes in a weekend.",
    "{input} owns a collection of 100 vinyl records.",
    "{input} walked 2,000 steps before breakfast.",
    "{input} scored 7 goals in 3 matches.",
    "{input} donated $50 to 5 different charities.",
    "{input} sleeps 6-8 hours depending on the week.",
    "{input} brewed 2 gallons of kombucha last month.",
    "{input} has 1,234 followers and gained 56 today.",
    "{input} paid 0.75 of the bill and {input} paid the rest.",
    "{input} ordered 3 large pizzas for 10 people.",
    "{input} ran a marathon in 3 hours and 30 minutes.",
    "{input} owns 2 houses and 10 rental units.",
    "{input} scored ninety-nine percent on the final exam.",
    "{input} spent $1,000 on tools and $200 on paint.",
    "{input} caught 5 fish and released 4 back.",
    "{input} has 7 siblings and 14 cousins.",
    "{input} cycles 15 miles to work every day.",
    "{input} paid 3 installments of $300 each.",
    "{input} grew 20 tomatoes and 50 basil plants.",
    "{input} has been married for 12 years and counting.",
    "{input} rehearsed for 6 hours and still forgot lines.",
    "{input} owns a tiny car that gets 40 mpg.",
    "{input} scored 2 touchdowns and 1 field goal.",
    "{input} bought 100 balloons for the party.",
    "{input} has 0 tolerance for bad coffee.",
    "{input} ran 1.2 miles before breakfast and 2.4 after.",
    "{input} found 3 typos in a 200-page manuscript.",
    "{input} paid 15% tip on a $60 bill.",
    "{input} has 8 plants and waters them 3 times a week.",
    "{input} read one hundred and twenty pages last night.",
    "{input} owns 2 guitars and 1 drum set.",
    "{input} spent 4 hours assembling a 12-piece shelf.",
    "{input} scored 88 on the midterm and 92 on the final.",
    "{input} baked 24 cookies and ate 6 immediately.",
    "{input} ran 5 miles, then 3 miles, then 2 miles.",
    "{input} has 3 degrees and 1 honorary doctorate.",
    "{input} paid 0.25 of the rent and promised the rest next week.",
    "{input} sold 30 tickets in 2 hours.",
    "{input} has 20 unread emails and 5 urgent ones.",
    "{input} owns a hundred-dollar watch and a $5 keychain.",
    "{input} rehearsed 10 scenes and memorized 2 lines.",
    "{input} drank 3 cups of coffee and 2 energy drinks.",
    "{input} has 4 plants that need repotting every 6 months.",
    "{input} ran 2 laps and then sprinted 100 meters.",
    "{input} paid 7 dollars for parking and 3 for snacks.",
    "{input} has 9 apps open and 2 frozen windows.",
    "{input} donated 2 boxes of clothes to 3 shelters.",
    "{input} owns 50 comic books and 1 rare edition.",
    "{input} took 3 trains and 1 bus to get home.",
    "{input} has 6 meetings and 2 coffee breaks today.",
    "{input} baked 1 cake for each of 8 birthdays.",
    "{input} saved $200 a month for 12 months.",
    "{input} ran 100 meters in 12.3 seconds.",
    "{input} has 2 left shoes and 1 right shoe missing.",
    "{input} bought 3 tickets, 2 snacks, and 1 souvenir.",
    "{input} read three hundred and sixty pages in a day.",
    "{input} owns 7 pairs of sunglasses and 1 umbrella.",
    "{input} paid 4 fines and received 2 warnings.",
    "{input} planted 100 bulbs and 25 saplings this season.",
    "{input} has 11 stamps in a collection and 1 rare stamp.",
    "{input} rehearsed for 120 minutes and took a 15-minute break.",
    "{input} scored 5 stars on 3 different review sites.",
    "{input} ran 2 marathons and 5 half-marathons last year.",
    "{input} bought 6 tickets for 4 adults and 2 kids.",
    "{input} has 3 unfinished projects and 12 ideas.",
    "{input} owns 1 tiny boat and 2 inflatable kayaks.",
    "{input} paid 0% interest on a 12-month plan.",
    "{input} ate 2,000 calories and burned 500 on the treadmill.",
    "{input} has 14 unread messages and 1 urgent voicemail.",
    "{input} brewed 12 cups of coffee and spilled 1.",
    "{input} scored 100% on a 50-question quiz.",
    "{input} has 3 plants, 2 pets, and 1 very loud neighbor.",
    "{input} ran 7 kilometers and then took a 30-minute nap.",
    "{input} bought 8 candles and lit 4 for ambiance.",
    "{input} owns 2 vintage cameras and 20 rolls of film.",
    "{input} paid 3 installments and still owes 2 more.",
    "{input} has 5 bookmarks and 1 overdue library book.",
    "{input} rehearsed 4 songs and learned 2 new chords.",
    "{input} donated $5 to 100 people in need.",
    "{input} has 1 million reasons to smile and 2 small worries.",
    "{input} baked 500 cookies for a charity bake-off.",
    "{input} ran 0.75 of a mile before breakfast.",
    "{input} owns 3 tiny succulents and 1 giant fern.",
    "{input} paid 2 dollars for a lottery ticket and won 0.",
    "{input} has 24 hours to finish 12 tasks.",
    "{input} bought 9 notebooks and 3 pens for the semester.",
    "{input} has 2 broken chairs and 1 wobbly table.",
    "{input} rehearsed 20 minutes and then improvised for 10.",
    "{input} owns 4 laptops and 1 ancient desktop.",
    "{input} paid 6 dollars for a sandwich and 0 for the smile.",
    "{input} has 3 umbrellas and 2 of them are missing.",
    "{input} ran 15 miles in a single weekend.",
    "{input} bought 100 raffle tickets and lost them all."
]

# --- small variation helpers (kept lightweight and safe) ---
SYNONYMS = {
    "gave": ["gave", "handed", "gifted"],
    "ran": ["ran", "jogged", "sprinted"],
    "used": ["used", "burned through", "consumed"],
    "baked": ["baked", "made", "whipped up"],
    "invited": ["invited", "asked", "welcomed"],
    "owns": ["owns", "has", "keeps"],
    "split": ["split", "shared", "divided"],
    "paid": ["paid", "spent", "covered"],
    "read": ["read", "skimmed", "devoured"],
    "drinks": ["drinks", "sips", "enjoys"],
    "scored": ["scored", "earned", "got"],
    "donated": ["donated", "gave away", "contributed"],
    "saved": ["saved", "set aside", "put away"],
    "bought": ["bought", "purchased", "grabbed"],
    "watched": ["watched", "binge-watched", "viewed"],
    "walked": ["walked", "strolled", "marched"],
    "found": ["found", "spotted", "discovered"],
    "sold": ["sold", "moved", "shifted"],
    "brewed": ["brewed", "made", "prepared"],
}

ADVERBS = ["quickly", "happily", "quietly", "surprisingly", "barely", "eagerly"]
NUM_JITTER = (-2, -1, 0, 1, 2)

WORD_RE = re.compile(r"\b\w+\b")
NUMBER_TOKEN_RE = re.compile(r"\b\d{1,3}(?:,\d{3})*(?:\.\d+)?\b")

def _maybe_replace_word(token):
    key = token.lower()
    if key in SYNONYMS and random.random() < 0.35:
        choice = random.choice(SYNONYMS[key])
        if token[0].isupper():
            choice = choice.capitalize()
        return choice
    return token

def _apply_numeric_jitter(match):
    s = match.group(0)
    s_clean = s.replace(',', '').lstrip('$')
    try:
        if '.' in s_clean:
            val = float(s_clean)
            if random.random() < 0.15:
                jitter = random.choice(NUM_JITTER)
                val = max(0, val + jitter)
                if float(val).is_integer():
                    return str(int(val))
                return f"{val:.2f}".rstrip('0').rstrip('.')
            return s
        else:
            val = int(s_clean)
            if random.random() < 0.20:
                jitter = random.choice(NUM_JITTER)
                newv = max(0, val + jitter)
                return f"{newv:,}"
            return s
    except Exception:
        return s

def randomize_template(template):
    t = NUMBER_TOKEN_RE.sub(_apply_numeric_jitter, template)
    out = []
    i = 0
    for m in WORD_RE.finditer(t):
        start, end = m.span()
        if i < start:
            out.append(t[i:start])
        token = t[start:end]
        newtok = _maybe_replace_word(token)
        out.append(newtok)
        if token.lower() in SYNONYMS and random.random() < 0.18:
            adv = random.choice(ADVERBS)
            out.append(" " + adv)
        i = end
    if i < len(t):
        out.append(t[i:])
    t2 = "".join(out)
    if random.random() < 0.08:
        if "," in t2:
            parts = [p.strip() for p in t2.split(",") if p.strip()]
            random.shuffle(parts)
            t2 = ", ".join(parts)
        elif " and " in t2.lower():
            parts = re.split(r'\band\b', t2, flags=re.IGNORECASE)
            parts = [p.strip() for p in parts if p.strip()]
            if len(parts) > 1:
                random.shuffle(parts)
                t2 = " and ".join(parts)
    if random.random() < 0.03:
        if t2.endswith("."):
            t2 = t2[:-1] + random.choice(["!", "..."])
    return t2

# --- number parsing and exaggeration (unchanged) ---
SIMPLE_NUM_WORDS = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
    "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13,
    "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
    "nineteen": 19, "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60,
    "seventy": 70, "eighty": 80, "ninety": 90, "hundred": 100, "thousand": 1000, "million": 1000000
}

def words_to_number(text):
    text = text.lower().replace('-', ' ').replace(' and ', ' ')
    parts = text.split()
    if not parts:
        return None
    total = 0
    current = 0
    for p in parts:
        if p not in SIMPLE_NUM_WORDS:
            return None
        val = SIMPLE_NUM_WORDS[p]
        if val == 100:
            if current == 0:
                current = 1
            current *= 100
        elif val == 1000 or val == 1000000:
            if current == 0:
                current = 1
            current *= val
            total += current
            current = 0
        else:
            current += val
    total += current
    return total

NUMBER_RE = re.compile(r"""
    (?P<number>
        (?:
            \$?                               
            \d{1,3}(?:,\d{3})*(?:\.\d+)?      
            |
            \$?\d+(?:\.\d+)?                  
        )
    )
    (?P<mult>[kKmM])?                         
    (?:%|st|nd|rd|th)?                        
""", re.VERBOSE)

RANGE_RE = re.compile(r'(?P<a>\d+(?:\.\d+)?)[\s]*[-–—][\s]*(?P<b>\d+(?:\.\d+)?)')

WORD_NUMBER_RE = re.compile(
    r'\b(' + '|'.join(re.escape(w) for w in SIMPLE_NUM_WORDS.keys()) +
    r')(?:[\s-](' + '|'.join(re.escape(w) for w in SIMPLE_NUM_WORDS.keys()) + r'))*\b',
    re.IGNORECASE
)

def parse_number_token(tok, mult_char=None):
    s = tok
    suffix = ''
    if s.endswith('%'):
        suffix = '%'
        s = s[:-1]
    m = re.match(r'^(?P<num>[\$]?[\d,]+(?:\.\d+)?)(?P<ord>st|nd|rd|th)?$', s, re.IGNORECASE)
    if m:
        s = m.group('num')
        if m.group('ord'):
            suffix = m.group('ord')
    s = s.replace(',', '').lstrip('$')
    try:
        val = float(s) if '.' in s else int(s)
        if mult_char:
            if mult_char.lower() == 'k':
                val = val * 1_000
            elif mult_char.lower() == 'm':
                val = val * 1_000_000
        return val, suffix, tok
    except ValueError:
        return None, '', tok

def exaggerate_value(val, mode, factor):
    if mode == 'scale':
        return val * factor
    elif mode == 'wild':
        max_mult = max(2, factor)
        mult = random.uniform(factor, factor * max_mult)
        return val * mult
    elif mode == 'sarcastic':
        if isinstance(val, (int, float)):
            if abs(val) >= 10_000_000:
                return "about a gazillion"
            if abs(val) >= 10_000:
                return f"roughly {int(val * factor):,}"
            if abs(val) >= 1_000:
                return val * factor
            if 0 < abs(val) < 1:
                return "practically nothing"
            if val == 0:
                return "zero, as always"
            return val * factor
        return val
    else:
        return val * factor

def format_exaggerated(orig, newval, suffix):
    if isinstance(newval, str):
        return newval
    if suffix == '%':
        if isinstance(newval, float) and not newval.is_integer():
            return f"{newval:.1f}%"
        try:
            ival = int(round(newval))
            return f"{ival}%"
        except Exception:
            return f"{newval}%"
    if isinstance(newval, float) and not newval.is_integer():
        s = f"{newval:.2f}".rstrip('0').rstrip('.')
        return s
    try:
        ival = int(round(newval))
        return f"{ival:,}"
    except Exception:
        return str(newval)

def exaggerate_sentence(sentence, mode='scale', factor=3.0):
    def range_repl(m):
        a = float(m.group('a'))
        b = float(m.group('b'))
        new_a = exaggerate_value(a, mode, factor)
        new_b = exaggerate_value(b, mode, factor)
        fa = format_exaggerated('', new_a, '')
        fb = format_exaggerated('', new_b, '')
        return f"{fa}-{fb}"
    sentence = RANGE_RE.sub(range_repl, sentence)

    def num_repl(m):
        num_tok = m.group('number')
        mult_char = m.group('mult')
        val, suffix, orig = parse_number_token(num_tok, mult_char)
        if val is None:
            return m.group(0)
        newval = exaggerate_value(val, mode, factor)
        return format_exaggerated(orig, newval, suffix)
    sentence = NUMBER_RE.sub(num_repl, sentence)

    def wordnum_repl(m):
        text = m.group(0)
        val = words_to_number(text)
        if val is None:
            return text
        newval = exaggerate_value(val, mode, factor)
        return format_exaggerated(text, newval, '')
    sentence = WORD_NUMBER_RE.sub(wordnum_repl, sentence)

    return sentence

# --- template utilities (shuffle + randomize + optional sampling) ---
def apply_templates(templates, user_input, count=None, max_sentences=None):
    templates_copy = templates.copy()
    random.shuffle(templates_copy)

    if max_sentences is not None and max_sentences > 0:
        filled = []
        idx = 0
        while len(filled) < max_sentences:
            t = templates_copy[idx % len(templates_copy)]
            t_rand = randomize_template(t)
            try:
                if count is None:
                    filled.append(t_rand.format(input=user_input))
                else:
                    filled.append(t_rand.format(input=user_input, count=count))
            except Exception:
                s = t_rand.replace("{input}", user_input)
                if count is not None:
                    s = s.replace("{count}", str(count))
                filled.append(s)
            idx += 1
        return filled

    filled = []
    for t in templates_copy:
        t_rand = randomize_template(t)
        try:
            if count is None:
                filled.append(t_rand.format(input=user_input))
            else:
                filled.append(t_rand.format(input=user_input, count=count))
        except Exception:
            s = t_rand.replace("{input}", user_input)
            if count is not None:
                s = s.replace("{count}", str(count))
            filled.append(s)
    return filled

def load_templates_from_file(path):
    p = Path(path)
    if not p.exists():
        return []
    lines = [line.strip() for line in p.read_text(encoding='utf-8').splitlines() if line.strip()]
    return lines

# --- robust TTS utilities with Windows PowerShell .ps1 fix ---
def _which_any(names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return None

def _play_file_with_known_players(path):
    path_str = str(path)
    if sys.platform == "darwin":
        afplay = shutil.which("afplay")
        if afplay:
            try:
                subprocess.run([afplay, path_str], check=True)
                return True, "Played with afplay"
            except subprocess.CalledProcessError:
                pass
    for player in ("paplay", "aplay", "play", "ffplay", "mpg123", "mplayer"):
        exe = shutil.which(player)
        if not exe:
            continue
        try:
            if player == "ffplay":
                subprocess.run([exe, "-nodisp", "-autoexit", path_str], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.run([exe, path_str], check=True)
            return True, f"Played with {player}"
        except subprocess.CalledProcessError:
            continue
    return False, "No player succeeded"

def _write_and_play_via_platform(text, out_path):
    plat = sys.platform
    out_path = Path(out_path)
    if plat == "darwin":
        say = shutil.which("say")
        if not say:
            return False, "'say' not found on macOS"
        try:
            subprocess.run([say, "-o", str(out_path), text], check=True)
        except subprocess.CalledProcessError as e:
            return False, f"'say' failed to write file: {e}"
        afplay = shutil.which("afplay")
        if afplay:
            try:
                subprocess.run([afplay, str(out_path)], check=True)
                return True, "Saved and played via say + afplay"
            except subprocess.CalledProcessError:
                return True, "Saved file with say; playback failed with afplay"
        return True, "Saved file with say; no afplay found to play it automatically"

    if plat.startswith("win"):
        # Use a temporary .txt for the text and a temporary .ps1 script to avoid quoting issues.
        powershell = shutil.which("powershell") or shutil.which("pwsh")
        if not powershell:
            return False, "PowerShell not found on PATH"
        tmp_fd, tmp_txt = tempfile.mkstemp(suffix=".txt")
        os.close(tmp_fd)
        ps_fd, tmp_ps1 = tempfile.mkstemp(suffix=".ps1")
        os.close(ps_fd)
        try:
            # Write the text file as UTF-8
            with open(tmp_txt, "w", encoding="utf-8") as f:
                f.write(text)

            # Prepare PowerShell script content.
            # Use explicit UTF8 read and ensure disposal before playback.
            # Use single-quoted literals for paths; escape single quotes by doubling them.
            safe_out = str(out_path).replace("'", "''")
            safe_tmp = str(tmp_txt).replace("'", "''")
            ps_script = f"""
Add-Type -AssemblyName System.speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
# Ensure the output directory exists
$dir = [System.IO.Path]::GetDirectoryName('{safe_out}')
if (-not [string]::IsNullOrEmpty($dir) -and -not (Test-Path $dir)) {{
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
}}
$s.SetOutputToWaveFile('{safe_out}')
# Read the text explicitly as UTF8 to avoid encoding issues
$text = [System.IO.File]::ReadAllText('{safe_tmp}', [System.Text.Encoding]::UTF8)
$s.Speak($text)
$s.Dispose()
# Play the generated WAV synchronously
$player = New-Object System.Media.SoundPlayer('{safe_out}')
$player.PlaySync()
"""
            # Write the .ps1 script as UTF-8 (no BOM)
            with open(tmp_ps1, "w", encoding="utf-8") as f:
                f.write(ps_script)

            # Run the PowerShell script using -NoProfile and -ExecutionPolicy Bypass to avoid policy issues.
            subprocess.run([powershell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", tmp_ps1], check=True)
            return True, "Saved and played via PowerShell System.Speech + SoundPlayer"
        except subprocess.CalledProcessError as e:
            return False, f"PowerShell TTS/playback failed: {e}"
        except Exception as e:
            return False, f"PowerShell TTS/playback unexpected error: {e}"
        finally:
            # Clean up temporary files
            try:
                os.remove(tmp_txt)
            except Exception:
                pass
            try:
                os.remove(tmp_ps1)
            except Exception:
                pass

    if plat.startswith("linux") or plat.startswith("freebsd") or plat.startswith("aix"):
        espeak = shutil.which("espeak")
        spd = shutil.which("spd-say")
        if espeak:
            try:
                subprocess.run([espeak, "-w", str(out_path), text], check=True)
            except subprocess.CalledProcessError as e:
                return False, f"espeak failed to write file: {e}"
            ok, msg = _play_file_with_known_players(out_path)
            if ok:
                return True, f"Saved with espeak and {msg}"
            return True, "Saved with espeak; no player succeeded automatically"
        if spd:
            try:
                subprocess.run([spd, text], check=True)
                return True, "Spoken via spd-say"
            except subprocess.CalledProcessError:
                pass
        return False, "No espeak or spd-say available on Linux to produce audio"

    return False, f"Unsupported platform: {plat}"

def speak_text(text, save_path=None, verbose=True):
    if not text:
        return False, "No text to speak"
    plat = sys.platform
    if save_path:
        out = Path(save_path)
        out.parent.mkdir(parents=True, exist_ok=True)
    else:
        suffix = ".wav" if not plat == "darwin" else ".aiff"
        fd, tmp = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        out = Path(tmp)
    ok, msg = _write_and_play_via_platform(text, out)
    if ok:
        if not save_path:
            try:
                time.sleep(0.1)
                out.unlink(missing_ok=True)
            except Exception:
                pass
        return True, msg
    tried = []
    # Fallbacks (attempt direct speak commands if file-based approach failed)
    if plat == "darwin":
        say = shutil.which("say")
        if say:
            try:
                subprocess.run([say, text], check=True)
                return True, "Spoken via say (fallback)"
            except subprocess.CalledProcessError as e:
                tried.append(f"say failed: {e}")
    elif plat.startswith("win"):
        # Try PowerShell direct speak fallback (less reliable than .ps1 file approach)
        powershell = shutil.which("powershell") or shutil.which("pwsh")
        if powershell:
            safe_text = text.replace("'", "''")
            ps_cmd = (
                "Add-Type -AssemblyName System.speech;"
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                f"$s.Speak('{safe_text}');"
                "$s.Dispose();"
            )
            try:
                subprocess.run([powershell, "-NoProfile", "-Command", ps_cmd], check=True)
                return True, "Spoken via PowerShell (fallback)"
            except subprocess.CalledProcessError as e:
                tried.append(f"PowerShell speak failed: {e}")
    else:
        spd = shutil.which("spd-say")
        espeak = shutil.which("espeak")
        if spd:
            try:
                subprocess.run([spd, text], check=True)
                return True, "Spoken via spd-say (fallback)"
            except subprocess.CalledProcessError as e:
                tried.append(f"spd-say failed: {e}")
        if espeak:
            try:
                subprocess.run([espeak, text], check=True)
                return True, "Spoken via espeak (fallback)"
            except subprocess.CalledProcessError as e:
                tried.append(f"espeak failed: {e}")
    espeak = shutil.which("espeak")
    if espeak:
        try:
            subprocess.run([espeak, "-w", str(out), text], check=True)
            ok2, msg2 = _play_file_with_known_players(out)
            if ok2:
                if not save_path:
                    try:
                        out.unlink(missing_ok=True)
                    except Exception:
                        pass
                return True, f"Saved with espeak and played with fallback player ({msg2})"
            return True, "Saved with espeak; playback with known players failed"
        except subprocess.CalledProcessError as e:
            tried.append(f"espeak -w failed: {e}")
    detail = "; ".join(tried) if tried else "unknown error"
    if not save_path:
        try:
            out.unlink(missing_ok=True)
        except Exception:
            pass
    return False, f"TTS failed: {detail}"

# --- interactive helpers ---
def prompt_for_input_and_count(default_input=None, default_count=None):
    try:
        prompt_text = "Enter the text to insert for {input}"
        if default_input:
            prompt_text += f" [Enter to keep '{default_input}']"
        prompt_text += " (or type 'quit' to exit): "
        user_input_raw = input(prompt_text).strip()
    except (EOFError, KeyboardInterrupt):
        return None, None

    if user_input_raw.lower() == "quit":
        return "QUIT", None

    if user_input_raw == "":
        user_input = default_input
    else:
        user_input = user_input_raw

    if not user_input:
        return None, None

    try:
        count_prompt = "Enter a numeric count for {count}"
        if default_count is not None:
            count_prompt += f" [Enter to keep '{default_count}']"
        count_prompt += " (press Enter to skip): "
        count_raw = input(count_prompt).strip()
    except (EOFError, KeyboardInterrupt):
        return None, None

    if count_raw.lower() == "quit":
        return "QUIT", None

    if count_raw == "":
        count = default_count
    else:
        try:
            if '.' in count_raw:
                count = float(count_raw)
                if count.is_integer():
                    count = int(count)
            else:
                count = int(count_raw)
            if isinstance(count, (int, float)) and count < 0:
                print("Negative count not allowed; ignoring.")
                count = default_count
        except ValueError:
            print("Invalid count entered; ignoring and proceeding with default/none.")
            count = default_count

    return user_input, count

def per_sentence_playback(sentences, tts_enabled, auto_count=None, prev_input=None, prev_count=None):
    total = len(sentences)
    if auto_count is not None:
        to_read = int(auto_count) if isinstance(auto_count, (int, float)) else None
        if to_read is None or to_read <= 0:
            return "OK", tts_enabled, False, None, None
        read = 0
        for sent in sentences:
            if read >= to_read:
                break
            print(f"- {sent}")
            if tts_enabled:
                ok, msg = speak_text(sent, save_path=None)
                print(f"  [TTS] {msg}")
            read += 1
            time.sleep(0.15)
        return "OK", tts_enabled, False, None, None

    index = 0
    while index < total:
        sent = sentences[index]
        print(f"- {sent}")
        if tts_enabled:
            ok, msg = speak_text(sent, save_path=None)
            print(f"  [TTS] {msg}")
        while True:
            try:
                cmd = input("Press Enter to continue, or type 'stop', 'repeat', 'restart', 'tts off', 'tts on', or 'quit': ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                return "QUIT", tts_enabled, False, None, None
            if cmd == "" or cmd == "next":
                index += 1
                break
            if cmd == "stop":
                return "STOP", tts_enabled, False, None, None
            if cmd == "repeat":
                print("Provide new values for repeating (press Enter to keep previous values, or type 'quit' to cancel):")
                new_ui, new_cnt = prompt_for_input_and_count(default_input=prev_input, default_count=prev_count)
                if new_ui is None and new_cnt is None:
                    print("Repeat cancelled; continuing current playback.")
                    continue
                if new_ui == "QUIT":
                    return "QUIT", tts_enabled, False, None, None
                return "REPEAT", tts_enabled, True, new_ui, new_cnt
            if cmd == "restart":
                print("Restarting playback from the beginning with previous settings...")
                index = 0
                break
            if cmd == "tts off":
                tts_enabled = False
                print("TTS disabled.")
                continue
            if cmd == "tts on":
                tts_enabled = True
                print("TTS enabled.")
                ok, msg = speak_text(sent, save_path=None)
                print(f"  [TTS] {msg}")
                continue
            if cmd == "quit":
                return "QUIT", tts_enabled, False, None, None
            print("Unknown command. Press Enter to continue, or type 'stop', 'repeat', 'restart', 'tts off', 'tts on', or 'quit'.")
    return "OK", tts_enabled, False, None, None

def restart_program():
    python = sys.executable
    args = [python] + sys.argv
    print("Restarting program...")
    try:
        os.execv(python, args)
    except Exception as e:
        print(f"Restart failed: {e}")
        sys.exit(1)

# --- CLI / main (keeps previous behavior) ---
def main():
    parser = argparse.ArgumentParser(description="Insert input into templates, exaggerate numbers, and speak one sentence at a time.")
    parser.add_argument('--text', type=str, default=None, help='Single template containing {input}.')
    parser.add_argument('--templates-file', type=str, default=None, help='File with one template per line (use {input} and {count}).')
    parser.add_argument('--use-default-templates', action='store_true', help='Use built-in templates.')
    parser.add_argument('--input', type=str, default=None, help='Text to insert for {input} (skips prompt).')
    parser.add_argument('--count', type=float, default=None, help='Numeric value to insert for {count} (skips prompt). If provided, the program will auto-read that many sentences.')
    parser.add_argument('--mode', choices=['scale','wild','sarcastic'], default='scale', help='Exaggeration mode.')
    parser.add_argument('--factor', type=float, default=3.0, help='Scale factor for numeric exaggeration.')
    parser.add_argument('--seed', type=int, default=None, help='Random seed for wild mode.')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--tts', dest='tts', action='store_true', help='Speak each exaggerated sentence aloud (best-effort).')
    group.add_argument('--no-tts', dest='tts', action='store_false', help='Do not speak sentences aloud.')
    parser.set_defaults(tts=True)
    parser.add_argument('--tts-file', type=str, default=None, help='Save last generated audio to this path (WAV/AIFF).')
    args = parser.parse_args()

    if args.seed is not None:
        random.seed(args.seed)

    templates = []
    if args.text:
        templates.append(args.text)
    if args.templates_file:
        templates.extend(load_templates_from_file(args.templates_file))
    if args.use_default_templates or not templates:
        templates = templates or DEFAULT_TEMPLATES.copy()

    tts_enabled = bool(args.tts)

    def run_playback_for_input(user_input, count):
        nonlocal tts_enabled
        max_sentences = int(count) if isinstance(count, (int, float)) else None
        filled = apply_templates(templates, user_input, count=count, max_sentences=max_sentences)
        sentences = [exaggerate_sentence(s, mode=args.mode, factor=args.factor) for s in filled]
        auto_count = count if isinstance(count, (int, float)) else None
        prev_input = user_input
        prev_count = count
        while True:
            status, tts_enabled, repeat_flag, new_ui, new_cnt = per_sentence_playback(
                sentences, tts_enabled, auto_count=auto_count, prev_input=prev_input, prev_count=prev_count
            )
            if status == "QUIT":
                return "QUIT"
            if status == "STOP":
                return "STOP"
            if repeat_flag:
                if new_ui == "QUIT":
                    return "QUIT"
                prev_input = new_ui
                prev_count = new_cnt
                user_input = new_ui
                count = new_cnt
                max_sentences = int(count) if isinstance(count, (int, float)) else None
                filled = apply_templates(templates, user_input, count=count, max_sentences=max_sentences)
                sentences = [exaggerate_sentence(s, mode=args.mode, factor=args.factor) for s in filled]
                auto_count = count if isinstance(count, (int, float)) else None
                continue
            return "OK"

    # If CLI provided both input and templates, run once and exit (with count support)
    if args.input is not None and (args.templates_file or args.text or args.use_default_templates):
        result = run_playback_for_input(args.input, args.count)
        if args.tts_file and result != "QUIT":
            filled = apply_templates(templates, args.input, count=args.count, max_sentences=(int(args.count) if isinstance(args.count, (int, float)) else None))
            sentences = [exaggerate_sentence(s, mode=args.mode, factor=args.factor) for s in filled]
            if sentences:
                out_path = Path(args.tts_file)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                ok, msg = speak_text(sentences[-1], save_path=out_path)
                print(f"\nTTS file: {msg}")
        if result == "QUIT":
            print("Goodbye.")
        return

    last_input = None
    last_count = None

    while True:
        ui, cnt = prompt_for_input_and_count(default_input=last_input, default_count=last_count)
        if ui is None and cnt is None:
            print("No input provided. Exiting.")
            return
        if ui == "QUIT":
            print("Goodbye.")
            return

        last_input = ui
        last_count = cnt

        status = run_playback_for_input(last_input, last_count)
        if status == "QUIT":
            print("Goodbye.")
            return

        if args.tts_file:
            filled = apply_templates(templates, last_input, count=last_count, max_sentences=(int(last_count) if isinstance(last_count, (int, float)) else None))
            sentences = [exaggerate_sentence(s, mode=args.mode, factor=args.factor) for s in filled]
            if sentences:
                out_path = Path(args.tts_file)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                ok, msg = speak_text(sentences[-1], save_path=out_path)
                print(f"\nTTS file: {msg}")

        while True:
            try:
                cmd = input("\nPress Enter to repeat with the last settings (from the beginning), type a number to set a new count and repeat, or type 'new', 'tts on', 'tts off', 'restart', or 'quit': ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye.")
                return

            if cmd == "" or cmd == "repeat":
                if last_input is None:
                    print("No previous settings to repeat.")
                    continue
                print("\nRepeating with previous values from the beginning (press Enter at prompts to keep them):")
                status = run_playback_for_input(last_input, last_count)
                if status == "QUIT":
                    print("Goodbye.")
                    return
                continue

            def parse_number(s):
                try:
                    if '.' in s:
                        v = float(s)
                        if v.is_integer():
                            return int(v)
                        return v
                    return int(s)
                except Exception:
                    return None

            num = parse_number(cmd)
            if num is not None:
                last_count = num
                print(f"\nRepeating with previous input and new count = {last_count} (from the beginning):")
                status = run_playback_for_input(last_input, last_count)
                if status == "QUIT":
                    print("Goodbye.")
                    return
                continue

            if cmd == "new":
                break
            elif cmd == "quit":
                print("Goodbye.")
                return
            elif cmd == "tts on":
                tts_enabled = True
                print("TTS enabled.")
                continue
            elif cmd == "tts off":
                tts_enabled = False
                print("TTS disabled.")
                continue
            elif cmd == "restart":
                if last_input is None:
                    print("No previous settings to restart.")
                    continue
                print("\nRestarting playback from the beginning with previous values:")
                status = run_playback_for_input(last_input, last_count)
                if status == "QUIT":
                    print("Goodbye.")
                    return
                continue
            else:
                print("Unknown command. Press Enter to repeat, type a number to change count and repeat, or use 'new', 'tts on', 'tts off', 'restart', or 'quit'.")

if __name__ == "__main__":
    main()
