import random
import sys
import platform
import subprocess
import shutil

# -------------------------
# Very large trivia database: Rock Star, Band Name, Song Title
# Each entry: question, correct, wrong (3 items), explanation (optional)
# -------------------------
TRIVIA = {
    "Rock Star": [
        {"question":"Which singer was the lead vocalist of Queen?","correct":"Freddie Mercury","wrong":["Robert Plant","Mick Jagger","David Bowie"],"explanation":"Freddie Mercury was Queen's charismatic frontman."},
        {"question":"Which guitarist is famous for the song 'Purple Haze'?","correct":"Jimi Hendrix","wrong":["Eric Clapton","Jimmy Page","Carlos Santana"],"explanation":"Jimi Hendrix popularized 'Purple Haze'."},
        {"question":"Who was the lead singer of Nirvana?","correct":"Kurt Cobain","wrong":["Eddie Vedder","Chris Cornell","Layne Staley"],"explanation":"Kurt Cobain fronted Nirvana."},
        {"question":"Which rock star is known as the 'King of Rock and Roll'?","correct":"Elvis Presley","wrong":["Chuck Berry","Little Richard","Buddy Holly"],"explanation":"Elvis Presley is widely called the King of Rock and Roll."},
        {"question":"Which singer founded the band The Police?","correct":"Sting","wrong":["Bono","Peter Gabriel","Phil Collins"],"explanation":"Sting (Gordon Sumner) was The Police's lead singer and bassist."},
        {"question":"Which frontman is associated with The Rolling Stones?","correct":"Mick Jagger","wrong":["John Lennon","Paul McCartney","Roger Daltrey"],"explanation":"Mick Jagger is the lead singer of The Rolling Stones."},
        {"question":"Which singer-songwriter led The Doors?","correct":"Jim Morrison","wrong":["Iggy Pop","Lou Reed","Tom Waits"],"explanation":"Jim Morrison was The Doors' iconic vocalist."},
        {"question":"Which guitarist is known for the riff in 'Smoke on the Water'?","correct":"Ritchie Blackmore","wrong":["Tony Iommi","Angus Young","Brian May"],"explanation":"Ritchie Blackmore wrote the riff for Deep Purple's 'Smoke on the Water'."},
        {"question":"Which rock star was the lead singer of AC/DC before Brian Johnson?","correct":"Bon Scott","wrong":["Axl Rose","Bono","Ozzy Osbourne"],"explanation":"Bon Scott was AC/DC's original lead singer."},
        {"question":"Which singer is the primary songwriter and frontman of U2?","correct":"Bono","wrong":["Brett Anderson","Thom Yorke","Sting"],"explanation":"Bono is U2's lead vocalist and principal songwriter."},
        {"question":"Which guitarist co-founded Led Zeppelin?","correct":"Jimmy Page","wrong":["Jeff Beck","Eric Clapton","Pete Townshend"],"explanation":"Jimmy Page was Led Zeppelin's guitarist and founder."},
        {"question":"Which singer was the face of The Who?","correct":"Roger Daltrey","wrong":["Pete Townshend","John Entwistle","Keith Moon"],"explanation":"Roger Daltrey is The Who's lead vocalist."},
        {"question":"Which rock star fronted Blondie?","correct":"Debbie Harry","wrong":["Chrissie Hynde","Siouxsie Sioux","Stevie Nicks"],"explanation":"Debbie Harry was Blondie's lead singer."},
        {"question":"Which singer is known for the album 'Born to Run'?","correct":"Bruce Springsteen","wrong":["Tom Petty","Bob Dylan","Neil Young"],"explanation":"Bruce Springsteen released 'Born to Run' in 1975."},
        {"question":"Which vocalist led Soundgarden?","correct":"Chris Cornell","wrong":["Eddie Vedder","Kurt Cobain","Scott Weiland"],"explanation":"Chris Cornell was Soundgarden's lead singer."},
        {"question":"Who was the lead singer of The Clash?","correct":"Joe Strummer","wrong":["Mick Jones","Paul Simonon","Johnny Rotten"],"explanation":"Joe Strummer was The Clash's frontman."},
        {"question":"Which artist is known for 'Space Oddity' and many reinventions?","correct":"David Bowie","wrong":["Elton John","Rod Stewart","Phil Collins"],"explanation":"David Bowie was known for constant reinvention."},
        {"question":"Who fronted R.E.M.?","correct":"Michael Stipe","wrong":["Bono","Thom Yorke","Billy Corgan"],"explanation":"Michael Stipe was R.E.M.'s lead singer."},
        {"question":"Who was the lead vocalist of The Smiths?","correct":"Morrissey","wrong":["Ian Curtis","Robert Smith","Bono"],"explanation":"Morrissey fronted The Smiths."},
        {"question":"Who fronted The Velvet Underground?","correct":"Lou Reed","wrong":["Iggy Pop","Patti Smith","Tom Verlaine"],"explanation":"Lou Reed was the principal singer-songwriter for The Velvet Underground."},
        {"question":"Which singer wrote and performed the album 'Tapestry'?","correct":"Carole King","wrong":["Joni Mitchell","Carly Simon","Laura Nyro"],"explanation":"Carole King's 'Tapestry' is a landmark album."},
        {"question":"Which singer led The Police and later had a solo career?","correct":"Sting","wrong":["Peter Gabriel","Phil Collins","Bono"],"explanation":"Sting led The Police and later had a successful solo career."},
        {"question":"Which singer was the poetic frontman of The Doors?","correct":"Jim Morrison","wrong":["Iggy Pop","Patti Smith","Tom Waits"],"explanation":"Jim Morrison was known for his poetry and stage presence."},
        {"question":"Which rock star sang '(I Can't Get No) Satisfaction'?","correct":"Mick Jagger","wrong":["Keith Richards","John Lennon","Paul McCartney"],"explanation":"Mick Jagger sang that song with The Rolling Stones."},
        {"question":"Who led The Kinks as singer-songwriter?","correct":"Ray Davies","wrong":["Dave Davies","Pete Townshend","John Entwistle"],"explanation":"Ray Davies was The Kinks' lead singer and songwriter."},
        {"question":"Which singer is known for 'Purple Rain' and a flamboyant stage persona?","correct":"Prince","wrong":["David Bowie","Elvis Presley","Freddie Mercury"],"explanation":"Prince was known for 'Purple Rain' and his distinctive style."},
        {"question":"Who was the lead singer of Joy Division?","correct":"Ian Curtis","wrong":["Morrissey","Robert Smith","Bono"],"explanation":"Ian Curtis fronted Joy Division."},
        {"question":"Which singer led The Cure?","correct":"Robert Smith","wrong":["Morrissey","Ian Curtis","Brett Anderson"],"explanation":"Robert Smith is the lead singer of The Cure."},
        {"question":"Which rock star fronted the Sex Pistols?","correct":"Johnny Rotten","wrong":["Joe Strummer","Billy Idol","Sid Vicious"],"explanation":"Johnny Rotten (John Lydon) was the Sex Pistols' lead singer."},
        {"question":"Which singer is associated with 'American Woman' and The Guess Who?","correct":"Burton Cummings","wrong":["Randy Bachman","Neil Young","Gordon Lightfoot"],"explanation":"Burton Cummings was the lead singer of The Guess Who."},
        {"question":"Who was the lead singer of The Doors and also a poet?","correct":"Jim Morrison","wrong":["Iggy Pop","Patti Smith","Tom Waits"],"explanation":"Jim Morrison combined poetry with performance."},
        {"question":"Which singer led the band Heart?","correct":"Ann Wilson","wrong":["Nancy Wilson","Stevie Nicks","Pat Benatar"],"explanation":"Ann Wilson is Heart's lead vocalist."},
        {"question":"Which singer is known for the song 'Piece of My Heart' with Big Brother and the Holding Company?","correct":"Janis Joplin","wrong":["Grace Slick","Patti Smith","Joni Mitchell"],"explanation":"Janis Joplin's powerful vocals defined that era."},
        {"question":"Who was the lead singer of The Band and later a solo star?","correct":"Robbie Robertson","wrong":["Levon Helm","Rick Danko","Garth Hudson"],"explanation":"Robbie Robertson was the primary songwriter and guitarist; Levon Helm was the lead vocalist on many tracks."},
        {"question":"Which singer is known for the song 'Roxanne' with The Police?","correct":"Sting","wrong":["Bono","Peter Gabriel","Phil Collins"],"explanation":"Sting wrote and sang 'Roxanne'."},
        {"question":"Which singer led the band The Doors and died in 1971?","correct":"Jim Morrison","wrong":["Jimi Hendrix","Janis Joplin","Kurt Cobain"],"explanation":"Jim Morrison died in 1971 in Paris."},
        {"question":"Which singer is the lead vocalist of Aerosmith?","correct":"Steven Tyler","wrong":["Joe Perry","Tom Hamilton","Brad Whitford"],"explanation":"Steven Tyler is Aerosmith's frontman."},
        {"question":"Which singer is the lead vocalist of Metallica?","correct":"James Hetfield","wrong":["Lars Ulrich","Kirk Hammett","Robert Trujillo"],"explanation":"James Hetfield is Metallica's lead singer and rhythm guitarist."},
        {"question":"Which singer led the band The Police and later released 'Fields of Gold' as a solo artist?","correct":"Sting","wrong":["Bono","Peter Gabriel","Phil Collins"],"explanation":"Sting had a successful solo career including 'Fields of Gold'."},
        {"question":"Which singer was the lead vocalist of The Jimi Hendrix Experience?","correct":"Jimi Hendrix","wrong":["Eric Clapton","Jeff Beck","Jimmy Page"],"explanation":"Jimi Hendrix fronted his own band, The Jimi Hendrix Experience."},
        {"question":"Which singer is known for the song 'Losing My Religion' as R.E.M.'s frontman?","correct":"Michael Stipe","wrong":["Bono","Thom Yorke","Morrissey"],"explanation":"Michael Stipe sang 'Losing My Religion'."},
        {"question":"Which singer was the lead vocalist of The Doors and wrote poetry?","correct":"Jim Morrison","wrong":["Lou Reed","Iggy Pop","Patti Smith"],"explanation":"Jim Morrison combined poetry and performance."}
    ],
    "Band Name": [
        {"question":"Which band recorded 'Dark Side of the Moon'?","correct":"Pink Floyd","wrong":["Led Zeppelin","The Who","The Rolling Stones"],"explanation":"'Dark Side of the Moon' is by Pink Floyd."},
        {"question":"Which band released 'Stairway to Heaven'?","correct":"Led Zeppelin","wrong":["Deep Purple","Black Sabbath","Aerosmith"],"explanation":"'Stairway to Heaven' is by Led Zeppelin."},
        {"question":"Which band released 'Nevermind'?","correct":"Nirvana","wrong":["Soundgarden","Alice in Chains","Pearl Jam"],"explanation":"'Nevermind' was Nirvana's breakthrough album."},
        {"question":"Which band recorded 'Paint It Black'?","correct":"The Rolling Stones","wrong":["The Beatles","The Kinks","The Doors"],"explanation":"'Paint It Black' was released by The Rolling Stones."},
        {"question":"Which band recorded 'Hotel California'?","correct":"Eagles","wrong":["Fleetwood Mac","The Byrds","The Doobie Brothers"],"explanation":"'Hotel California' is by the Eagles."},
        {"question":"Which band released 'Rumours'?","correct":"Fleetwood Mac","wrong":["Eagles","Heart","The Pretenders"],"explanation":"'Rumours' is Fleetwood Mac's famous 1977 album."},
        {"question":"Which band recorded 'Back in Black'?","correct":"AC/DC","wrong":["Guns N' Roses","Van Halen","Aerosmith"],"explanation":"'Back in Black' is AC/DC's best-selling album."},
        {"question":"Which act recorded 'Born to Run' with the E Street Band?","correct":"Bruce Springsteen and the E Street Band","wrong":["Tom Petty and the Heartbreakers","The Band","Creedence Clearwater Revival"],"explanation":"Bruce Springsteen recorded 'Born to Run' with the E Street Band."},
        {"question":"Which band had 'Sweet Child o' Mine'?","correct":"Guns N' Roses","wrong":["Bon Jovi","Aerosmith","Def Leppard"],"explanation":"'Sweet Child o' Mine' is by Guns N' Roses."},
        {"question":"Which band recorded 'Abbey Road'?","correct":"The Beatles","wrong":["The Rolling Stones","The Who","The Kinks"],"explanation":"'Abbey Road' is a Beatles album."},
        {"question":"Which band is known for 'Paranoid'?","correct":"Black Sabbath","wrong":["Deep Purple","Led Zeppelin","Judas Priest"],"explanation":"'Paranoid' is a signature Black Sabbath song."},
        {"question":"Which band released 'London Calling'?","correct":"The Clash","wrong":["Sex Pistols","The Jam","Buzzcocks"],"explanation":"'London Calling' is by The Clash."},
        {"question":"Which band had 'Losing My Religion'?","correct":"R.E.M.","wrong":["U2","The Cure","Depeche Mode"],"explanation":"'Losing My Religion' is by R.E.M."},
        {"question":"Which band recorded 'Sgt. Pepper's Lonely Hearts Club Band'?","correct":"The Beatles","wrong":["The Rolling Stones","The Who","Pink Floyd"],"explanation":"That album is by The Beatles."},
        {"question":"Which band is known for 'Comfortably Numb'?","correct":"Pink Floyd","wrong":["Genesis","Yes","King Crimson"],"explanation":"'Comfortably Numb' is a Pink Floyd classic."},
        {"question":"Which band released 'Appetite for Destruction'?","correct":"Guns N' Roses","wrong":["Metallica","Skid Row","Mötley Crüe"],"explanation":"'Appetite for Destruction' launched Guns N' Roses."},
        {"question":"Which band had 'Come As You Are'?","correct":"Nirvana","wrong":["Soundgarden","Alice in Chains","Stone Temple Pilots"],"explanation":"'Come As You Are' is a Nirvana single."},
        {"question":"Which duo recorded 'Bridge Over Troubled Water'?","correct":"Simon & Garfunkel","wrong":["The Byrds","Crosby, Stills & Nash","The Mamas & the Papas"],"explanation":"Simon & Garfunkel recorded that song."},
        {"question":"Which band recorded 'Bohemian Rhapsody'?","correct":"Queen","wrong":["Electric Light Orchestra","Genesis","Yes"],"explanation":"'Bohemian Rhapsody' is by Queen."},
        {"question":"Which band released 'Parachutes' as their debut album?","correct":"Coldplay","wrong":["Radiohead","Keane","Travis"],"explanation":"Coldplay's debut album was 'Parachutes'."},
        {"question":"Which band recorded 'The Joshua Tree'?","correct":"U2","wrong":["R.E.M.","The Police","INXS"],"explanation":"U2 released 'The Joshua Tree' in 1987."},
        {"question":"Which band is associated with 'My Generation'?","correct":"The Who","wrong":["The Kinks","The Beatles","The Rolling Stones"],"explanation":"'My Generation' is by The Who."},
        {"question":"Which band released 'Electric Ladyland'?","correct":"The Jimi Hendrix Experience","wrong":["Cream","Jeff Beck Group","The Yardbirds"],"explanation":"The Jimi Hendrix Experience released 'Electric Ladyland'."},
        {"question":"Which band had the album 'Ten'?","correct":"Pearl Jam","wrong":["Soundgarden","Alice in Chains","Stone Temple Pilots"],"explanation":"'Ten' is Pearl Jam's debut album."},
        {"question":"Which band recorded 'A Night at the Opera'?","correct":"Queen","wrong":["The Beatles","The Rolling Stones","Led Zeppelin"],"explanation":"'A Night at the Opera' is a Queen album."},
        {"question":"Which band recorded 'Highway to Hell'?","correct":"AC/DC","wrong":["KISS","Aerosmith","Van Halen"],"explanation":"'Highway to Hell' is an AC/DC classic."},
        {"question":"Which band released 'Never Mind the Bollocks'?","correct":"Sex Pistols","wrong":["The Clash","Buzzcocks","The Damned"],"explanation":"The Sex Pistols released that punk landmark."},
        {"question":"Which band released 'OK Computer'?","correct":"Radiohead","wrong":["Blur","Oasis","Pulp"],"explanation":"'OK Computer' is a Radiohead album."},
        {"question":"Which band is known for 'Sweet Home Alabama'?","correct":"Lynyrd Skynyrd","wrong":["The Allman Brothers Band","ZZ Top","Creedence Clearwater Revival"],"explanation":"'Sweet Home Alabama' is by Lynyrd Skynyrd."},
        {"question":"Which band recorded 'Born in the U.S.A.'?","correct":"Bruce Springsteen and the E Street Band","wrong":["Tom Petty and the Heartbreakers","John Mellencamp","Bob Seger"],"explanation":"Bruce Springsteen recorded 'Born in the U.S.A.' with the E Street Band."},
        {"question":"Which band released 'The Wall'?","correct":"Pink Floyd","wrong":["Genesis","Yes","King Crimson"],"explanation":"Pink Floyd released the rock opera 'The Wall'."},
        {"question":"Which band recorded 'Led Zeppelin IV'?","correct":"Led Zeppelin","wrong":["Black Sabbath","Deep Purple","The Who"],"explanation":"Led Zeppelin's untitled fourth album is commonly called 'Led Zeppelin IV'."},
        {"question":"Which band released 'Back in Black' in 1980?","correct":"AC/DC","wrong":["Guns N' Roses","Van Halen","Aerosmith"],"explanation":"'Back in Black' followed Bon Scott's death and Brian Johnson's arrival."},
        {"question":"Which band recorded 'Electric' (album) and had the hit 'I Want to Break Free'?","correct":"Queen","wrong":["The Police","Duran Duran","Depeche Mode"],"explanation":"Queen recorded many hits including 'I Want to Break Free'."},
        {"question":"Which band released 'Doolittle' in 1989?","correct":"Pixies","wrong":["Sonic Youth","The Smiths","R.E.M."],"explanation":"'Doolittle' is a landmark Pixies album."},
        {"question":"Which band recorded 'Disintegration'?","correct":"The Cure","wrong":["Depeche Mode","New Order","The Smiths"],"explanation":"'Disintegration' is a major album by The Cure."},
        {"question":"Which band released 'Achtung Baby'?","correct":"U2","wrong":["R.E.M.","The Police","INXS"],"explanation":"'Achtung Baby' is a U2 album from 1991."}
    ],
    "Song Title": [
        {"question":"Which song begins with 'Is this the real life? Is this just fantasy?'","correct":"Bohemian Rhapsody","wrong":["Killer Queen","Somebody to Love","We Will Rock You"],"explanation":"Those opening lines are from Queen's 'Bohemian Rhapsody'."},
        {"question":"Which song contains 'There's a lady who's sure all that glitters is gold'?","correct":"Stairway to Heaven","wrong":["Kashmir","Whole Lotta Love","Black Dog"],"explanation":"That line opens 'Stairway to Heaven' by Led Zeppelin."},
        {"question":"Which song includes the chorus 'We don't need no education'?","correct":"Another Brick in the Wall","wrong":["Comfortably Numb","Money","Wish You Were Here"],"explanation":"Pink Floyd's 'Another Brick in the Wall' features that chorus."},
        {"question":"Which song title is also the name of Fleetwood Mac's 1977 album?","correct":"Rumours","wrong":["Tusk","Fleetwood Mac","Mirage"],"explanation":"Fleetwood Mac's 1977 album 'Rumours' is one of their best-known works."},
        {"question":"Which Beatles song ends with 'And in the end the love you take is equal to the love you make'?","correct":"The End","wrong":["Hey Jude","Let It Be","Come Together"],"explanation":"That closing line appears in 'The End' from Abbey Road."},
        {"question":"Which song opens 'Load up on guns, bring your friends'?","correct":"Smells Like Teen Spirit","wrong":["Come As You Are","Lithium","In Bloom"],"explanation":"Those are the opening words of Nirvana's 'Smells Like Teen Spirit'."},
        {"question":"Which song features 'I see a little silhouetto of a man'?","correct":"Bohemian Rhapsody","wrong":["Somebody to Love","Don't Stop Me Now","We Are the Champions"],"explanation":"That line is part of Queen's 'Bohemian Rhapsody'."},
        {"question":"Which song title is 'Hotel California'?","correct":"Hotel California","wrong":["Take It Easy","Desperado","Life in the Fast Lane"],"explanation":"'Hotel California' is the Eagles' signature song."},
        {"question":"Which song opens 'Hello darkness, my old friend'?","correct":"The Sound of Silence","wrong":["Bridge Over Troubled Water","Mrs. Robinson","Scarborough Fair"],"explanation":"'The Sound of Silence' opens with that line (Simon & Garfunkel)."},
        {"question":"Which Led Zeppelin song features an acoustic intro and a long build?","correct":"Stairway to Heaven","wrong":["Kashmir","Ramble On","Black Dog"],"explanation":"'Stairway to Heaven' begins with a famous acoustic intro."},
        {"question":"Which Rolling Stones song asks 'Can you hear me knockin''?","correct":"Can You Hear Me Knocking","wrong":["Gimme Shelter","Sympathy for the Devil","Jumpin' Jack Flash"],"explanation":"'Can You Hear Me Knocking' is a Rolling Stones track."},
        {"question":"Which Who song includes 'I hope I die before I get old'?","correct":"My Generation","wrong":["Baba O'Riley","Pinball Wizard","Won't Get Fooled Again"],"explanation":"That line is from The Who's 'My Generation'."},
        {"question":"Which Pink Floyd song asks 'Hello, is there anybody in there?'","correct":"Comfortably Numb","wrong":["Time","Money","Wish You Were Here"],"explanation":"The line appears in 'Comfortably Numb'."},
        {"question":"Which song title is 'Sweet Child o' Mine'?","correct":"Sweet Child o' Mine","wrong":["November Rain","Paradise City","Welcome to the Jungle"],"explanation":"'Sweet Child o' Mine' is a hit by Guns N' Roses."},
        {"question":"Which Beatles song repeats 'All you need is love'?","correct":"All You Need Is Love","wrong":["She Loves You","Help!","Hey Jude"],"explanation":"The Beatles released 'All You Need Is Love' in 1967."},
        {"question":"Which song title is 'Born to Run'?","correct":"Born to Run","wrong":["Thunder Road","Dancing in the Dark","Glory Days"],"explanation":"'Born to Run' is a Bruce Springsteen classic."},
        {"question":"Which Bob Dylan song asks 'How does it feel to be on your own?'","correct":"Like a Rolling Stone","wrong":["Blowin' in the Wind","The Times They Are A-Changin'","Tangled Up in Blue"],"explanation":"'Like a Rolling Stone' contains that line."},
        {"question":"Which song title is 'Free Bird'?","correct":"Free Bird","wrong":["Sweet Home Alabama","Simple Man","Gimme Three Steps"],"explanation":"'Free Bird' is a signature Lynyrd Skynyrd song."},
        {"question":"Which Clash song is titled after a city?","correct":"London Calling","wrong":["Rock the Casbah","Should I Stay or Should I Go","Train in Vain"],"explanation":"'London Calling' is The Clash's title track."},
        {"question":"Which AC/DC song title is 'Back in Black'?","correct":"Back in Black","wrong":["Highway to Hell","You Shook Me All Night Long","Hells Bells"],"explanation":"'Back in Black' is AC/DC's title track."},
        {"question":"Which Queen song is a multi-part suite and one of their most famous tracks?","correct":"Bohemian Rhapsody","wrong":["Killer Queen","Somebody to Love","Don't Stop Me Now"],"explanation":"'Bohemian Rhapsody' is a multi-section Queen epic."},
        {"question":"Which Rolling Stones song is 'Paint It Black'?","correct":"Paint It Black","wrong":["Ruby Tuesday","Jumpin' Jack Flash","Gimme Shelter"],"explanation":"'Paint It Black' is by The Rolling Stones."},
        {"question":"Which Beatles song closes the Abbey Road medley with the line about love you take?","correct":"The End","wrong":["Here Comes the Sun","Golden Slumbers","Carry That Weight"],"explanation":"'The End' closes the Abbey Road medley."},
        {"question":"Which Black Sabbath song title is 'Paranoid'?","correct":"Paranoid","wrong":["Iron Man","War Pigs","Children of the Grave"],"explanation":"'Paranoid' is a Black Sabbath classic."},
        {"question":"Which Bruce Springsteen song title is 'Born in the U.S.A.'?","correct":"Born in the U.S.A.","wrong":["Dancing in the Dark","Glory Days","Thunder Road"],"explanation":"Bruce Springsteen's 'Born in the U.S.A.' is a well-known track."},
        {"question":"Which Jimi Hendrix song title is 'Purple Haze'?","correct":"Purple Haze","wrong":["Voodoo Child","Hey Joe","All Along the Watchtower"],"explanation":"'Purple Haze' is a Jimi Hendrix song."},
        {"question":"Which Beatles song title is 'Hey Jude'?","correct":"Hey Jude","wrong":["Let It Be","Yesterday","Come Together"],"explanation":"'Hey Jude' is a Beatles single written by Paul McCartney."},
        {"question":"Which Pink Floyd song title is 'Comfortably Numb'?","correct":"Comfortably Numb","wrong":["Wish You Were Here","Time","Money"],"explanation":"'Comfortably Numb' is by Pink Floyd."},
        {"question":"Which Led Zeppelin song title is 'Kashmir'?","correct":"Kashmir","wrong":["Immigrant Song","Ramble On","Dazed and Confused"],"explanation":"'Kashmir' is a Led Zeppelin track."},
        {"question":"Which Rolling Stones song title is 'Gimme Shelter'?","correct":"Gimme Shelter","wrong":["Paint It Black","Satisfaction","Jumpin' Jack Flash"],"explanation":"'Gimme Shelter' is a classic Stones song."},
        {"question":"Which Nirvana song title is 'Smells Like Teen Spirit'?","correct":"Smells Like Teen Spirit","wrong":["Come As You Are","Lithium","In Bloom"],"explanation":"Nirvana's breakthrough single was 'Smells Like Teen Spirit'."},
        {"question":"Which song title is 'Sweet Home Alabama'?","correct":"Sweet Home Alabama","wrong":["Free Bird","Simple Man","Tuesday's Gone"],"explanation":"Lynyrd Skynyrd recorded 'Sweet Home Alabama'."},
        {"question":"Which song title is 'November Rain'?","correct":"November Rain","wrong":["Don't Cry","Paradise City","Sweet Child o' Mine"],"explanation":"'November Rain' is a Guns N' Roses ballad."},
        {"question":"Which song title is 'Heroes'?","correct":"Heroes","wrong":["Space Oddity","Life on Mars?","Changes"],"explanation":"David Bowie recorded 'Heroes' in 1977."},
        {"question":"Which song title is 'London Calling'?","correct":"London Calling","wrong":["Rock the Casbah","Should I Stay or Should I Go","Train in Vain"],"explanation":"The Clash's title track 'London Calling' is iconic."},
        {"question":"Which song title is 'Whole Lotta Love'?","correct":"Whole Lotta Love","wrong":["Immigrant Song","Black Dog","Ramble On"],"explanation":"Led Zeppelin's 'Whole Lotta Love' is a signature riff-driven song."},
        {"question":"Which song title is 'Layla'?","correct":"Layla","wrong":["Wonderful Tonight","Cocaine","Tears in Heaven"],"explanation":"Eric Clapton wrote 'Layla' with Derek and the Dominos."},
        {"question":"Which song title is 'Light My Fire'?","correct":"Light My Fire","wrong":["Riders on the Storm","Break on Through","People Are Strange"],"explanation":"The Doors had a major hit with 'Light My Fire'."}
    ]
}

# -------------------------
# TTS helper using only stdlib and system utilities (no pip)
# -------------------------
def _which(cmd):
    return shutil.which(cmd) is not None

def speak_via_powershell(text):
    safe = text.replace("'", "''")
    ps = (
        "Add-Type -AssemblyName System.Speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        f"$s.Speak('{safe}');"
    )
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False

def speak_via_say(text):
    try:
        subprocess.run(["say", text], check=True)
        return True
    except Exception:
        return False

def speak_via_spd_say(text):
    try:
        subprocess.run(["spd-say", text], check=True)
        return True
    except Exception:
        return False

def speak_via_espeak(text):
    try:
        subprocess.run(["espeak", text], check=True)
        return True
    except Exception:
        return False

def speak(text):
    system = platform.system()
    if system == "Windows":
        return speak_via_powershell(text)
    if system == "Darwin":
        if _which("say"):
            return speak_via_say(text)
        return False
    if system in ("Linux", "FreeBSD", "OpenBSD"):
        if _which("spd-say"):
            return speak_via_spd_say(text)
        if _which("espeak"):
            return speak_via_espeak(text)
        return False
    return False

# -------------------------
# Game functions
# -------------------------
def choose_category():
    categories = list(TRIVIA.keys())
    print("\nChoose a category:")
    for i, cat in enumerate(categories, 1):
        print(f"  {i}. {cat}")
    while True:
        choice = input("Enter number (or 'q' to quit): ").strip()
        if choice.lower() == 'q':
            sys.exit("Goodbye!")
        if choice.isdigit() and 1 <= int(choice) <= len(categories):
            return categories[int(choice) - 1]
        print("Invalid choice. Try again.")

def ask_questions(category, tts_enabled=False, num_questions=12):
    questions = TRIVIA[category][:]
    random.shuffle(questions)
    questions = questions[:min(num_questions, len(questions))]
    score = 0
    for idx, q in enumerate(questions, 1):
        options = q["wrong"] + [q["correct"]]
        random.shuffle(options)
        prompt = f"Question {idx}: {q['question']}"
        print("\n" + prompt)
        if tts_enabled:
            speak(prompt)
        for i, opt in enumerate(options, 1):
            line = f"  {i}. {opt}"
            print(line)
            if tts_enabled:
                speak(line)
        while True:
            ans = input("Your answer (number): ").strip()
            if ans.isdigit() and 1 <= int(ans) <= len(options):
                chosen = options[int(ans) - 1]
                break
            print("Please enter a valid option number.")
        if chosen == q["correct"]:
            result = "Correct!"
            print(result)
            if tts_enabled:
                speak(result)
            score += 1
        else:
            result = f"Wrong. The correct answer is: {q['correct']}"
            print(result)
            if tts_enabled:
                speak(result)
        if q.get("explanation"):
            note = f"Note: {q['explanation']}"
            print(note)
            if tts_enabled:
                speak(note)
    return score, len(questions)

def main():
    print("=== Rock and Roll Trivia (Very Large Bank) ===")
    tts_enabled = False
    while True:
        ans = input("Enable text-to-speech? (y/n): ").strip().lower()
        if ans in ('y', 'n'):
            tts_enabled = (ans == 'y')
            break
        print("Please enter y or n.")
    if tts_enabled:
        ok = speak("Text to speech enabled.")
        if not ok:
            print("TTS requested but no system TTS found. Continuing without speech.")
            tts_enabled = False
    while True:
        category = choose_category()
        print(f"\nStarting category: {category}")
        score, total = ask_questions(category, tts_enabled=tts_enabled, num_questions=12)
        print(f"\nYou scored {score} out of {total}.")
        if tts_enabled:
            speak(f"You scored {score} out of {total}.")
        again = input("\nPlay again? (y/n): ").strip().lower()
        if again != 'y':
            print("Thanks for playing! Rock on.")
            if tts_enabled:
                speak("Thanks for playing. Rock on.")
            break

if __name__ == "__main__":
    main()
