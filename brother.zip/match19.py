#!/usr/bin/env python3
"""
match_cards_32_cards.py
Memory match game with character face cards drawn using tkinter primitives.
This version displays exactly 32 cards (16 pairs) by default (4 rows x 8 columns).
Every card has exactly one matching partner. Includes Matches panel,
Auto Win button, and "Show Matches Only" toggle.
No external libraries required.
"""

import random
import tkinter as tk
from tkinter import messagebox

# --- Display exactly 32 cards ---
# 32 cards = 16 pairs. Default layout: 4 rows x 8 columns (you can change ROWS/COLS
# only if their product remains 32).
ROWS = 4
COLS = 8
assert ROWS * COLS == 32, "ROWS * COLS must equal 32 for this build."

CARD_W = 160
CARD_H = 220
PADDING = 8
FLIP_DELAY_MS = 700

# Base symbol pool used to create pairs. If the board needs more unique symbols,
# the deck builder will deterministically generate extra labels.
BASE_SYMBOLS = list(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789"
    "!@#$%^&*()_+-=[]{};:<>/?"
)

# --- Simple deterministic style helpers ---
def deterministic_choice(seed, options):
    return options[seed % len(options)]

def color_from_seed(seed):
    palette = ["#f2d0b3","#f7c6a3","#e6b89c","#d9a07b","#f1e0c9","#d1bfa7","#c68642","#8d5524"]
    return deterministic_choice(seed, palette)

def hair_color_from_seed(seed):
    palette = ["#2b2b2b","#5c3a21","#a65b2a","#d9a441","#6b3fa0","#2b6b9a"]
    return deterministic_choice(seed+3, palette)

def accessory_color(seed):
    palette = ["#ff6b6b","#6BCB77","#ffd166","#7aa2ff","#b388ff"]
    return deterministic_choice(seed+7, palette)

# --- Drawing helpers (scaled) ---
def draw_rounded_rect(canvas, x1, y1, x2, y2, r, **kwargs):
    canvas.create_rectangle(x1+r, y1, x2-r, y2, **kwargs)
    canvas.create_rectangle(x1, y1+r, x2, y2-r, **kwargs)
    canvas.create_arc(x1, y1, x1+2*r, y1+2*r, start=90, extent=90, style='pieslice', **kwargs)
    canvas.create_arc(x2-2*r, y1, x2, y1+2*r, start=0, extent=90, style='pieslice', **kwargs)
    canvas.create_arc(x1, y2-2*r, x1+2*r, y2, start=180, extent=90, style='pieslice', **kwargs)
    canvas.create_arc(x2-2*r, y2-2*r, x2, y2, start=270, extent=90, style='pieslice', **kwargs)

# --- Minimal face drawing (fast) ---
def draw_face_base(canvas, x, y, w, h, skin):
    hx1 = x + w*0.12; hy1 = y + h*0.12
    hx2 = x + w*0.88; hy2 = y + h*0.78
    canvas.create_oval(hx1, hy1, hx2, hy2, fill=skin, outline="#000000", width=max(1, int(w*0.003)))

def draw_eyes(canvas, cx, cy, card_w, card_h, style):
    eye_w = int(0.06*card_w); eye_h = int(0.04*card_h)
    left = (cx - int(0.11*card_w), cy - int(0.03*card_h))
    right = (cx + int(0.11*card_w), cy - int(0.03*card_h))
    if style == 0:
        canvas.create_oval(left[0]-eye_w, left[1]-eye_h, left[0]+eye_w, left[1]+eye_h, fill="white", outline="")
        canvas.create_oval(right[0]-eye_w, right[1]-eye_h, right[0]+eye_w, right[1]+eye_h, fill="white", outline="")
        canvas.create_oval(left[0]-eye_w//2, left[1]-eye_h//2, left[0]+eye_w//2, left[1]+eye_h//2, fill="#2b2b2b", outline="")
        canvas.create_oval(right[0]-eye_w//2, right[1]-eye_h//2, right[0]+eye_w//2, right[1]+eye_h//2, fill="#2b2b2b", outline="")
    else:
        canvas.create_line(left[0]-eye_w, left[1], left[0]+eye_w, left[1], width=max(1, int(card_w*0.006)))
        canvas.create_line(right[0]-eye_w, right[1], right[0]+eye_w, right[1], width=max(1, int(card_w*0.006)))

def draw_mouth(canvas, cx, cy, card_w, card_h, style):
    if style == 0:
        canvas.create_arc(cx-int(0.11*card_w), cy-int(0.03*card_h), cx+int(0.11*card_w), cy+int(0.08*card_h),
                          start=180, extent=180, style='arc', width=max(1, int(card_w*0.006)))
    else:
        canvas.create_line(cx-int(0.09*card_w), cy+int(0.03*card_h), cx+int(0.09*card_w), cy+int(0.03*card_h), width=max(1, int(card_w*0.006)))

def draw_hair(canvas, x, y, w, h, hair_style, hair_color):
    hx1 = x + w*0.08; hy1 = y + h*0.02; hx2 = x + w*0.92; hy2 = y + h*0.5
    if hair_style % 2 == 0:
        canvas.create_arc(hx1, hy1, hx2, hy2, start=0, extent=180, fill=hair_color, outline=hair_color)
    else:
        canvas.create_rectangle(hx1, hy1 + h*0.06, hx2, hy2, fill=hair_color, outline=hair_color)

def draw_accessory(canvas, cx, cy, acc_type, color, card_w, card_h):
    if acc_type == 0:
        canvas.create_oval(cx-int(0.20*card_w), cy-int(0.06*card_h), cx-int(0.06*card_w), cy+int(0.06*card_h), outline=color, width=max(1, int(card_w*0.01)))
        canvas.create_oval(cx+int(0.06*card_w), cy-int(0.06*card_h), cx+int(0.20*card_w), cy+int(0.06*card_h), outline=color, width=max(1, int(card_w*0.01)))
    elif acc_type == 1:
        canvas.create_oval(cx+int(0.28*card_w), cy+int(0.06*card_h), cx+int(0.32*card_w), cy+int(0.10*card_h), fill=color, outline="")
    else:
        canvas.create_rectangle(cx-int(0.22*card_w), cy+int(0.60*card_h), cx+int(0.22*card_w), cy+int(0.66*card_h), fill=color, outline="")

# --- Robust deck builder: ensures every card has a matching pair ---
def _generate_extra_symbols(start_index, count):
    out = []
    idx = start_index
    while len(out) < count:
        letter = BASE_SYMBOLS[idx % len(BASE_SYMBOLS)]
        suffix = (idx // len(BASE_SYMBOLS)) + 1
        out.append(f"{letter}{suffix}")
        idx += 1
    return out

def make_deck(rows, cols):
    total = rows * cols
    if total % 2 != 0:
        raise ValueError("Board must have an even number of cells.")
    needed_pairs = total // 2

    pool = BASE_SYMBOLS.copy()
    if needed_pairs > len(pool):
        extra_needed = needed_pairs - len(pool)
        pool.extend(_generate_extra_symbols(len(pool), extra_needed))

    chosen = pool[:needed_pairs]

    deck = []
    for s in chosen:
        deck.append(s)
        deck.append(s)
    random.shuffle(deck)

    board = [deck[i * cols:(i + 1) * cols] for i in range(rows)]
    return board

# --- Card widget with match highlight support ---
class CardCanvas(tk.Canvas):
    def __init__(self, master, r, c, width, height, **kwargs):
        super().__init__(master, width=width, height=height, highlightthickness=0, **kwargs)
        self.r = r; self.c = c
        self.is_matched = False

    def draw_back(self):
        self.is_matched = False
        self.delete("all")
        w = int(self['width']); h = int(self['height'])
        draw_rounded_rect(self, 4, 4, w-4, h-4, max(8, int(w*0.04)), fill='#2B6CB0', outline='#ffffff', width=max(2, int(w*0.01)))
        step = max(12, int(w*0.05))
        for i in range(-h, w, step):
            self.create_line(i, 0, i + h, h, fill='#ffffff', width=1, stipple='gray25')
        self.create_text(w//2, h//2, text="?", fill="white", font=("Helvetica", int(h*0.18), "bold"))

    def draw_character(self, symbol, highlight=False):
        if highlight:
            self.is_matched = True
        self.delete("all")
        w = int(self['width']); h = int(self['height'])
        seed = ord(symbol[0]) + (int(symbol[1]) if len(symbol)>1 and symbol[1].isdigit() else 0)
        skin = color_from_seed(seed); hair = hair_color_from_seed(seed)
        hair_style = seed % 4; eye_style = seed % 2; mouth_style = seed % 2; acc_type = seed % 3; acc_col = accessory_color(seed)

        draw_rounded_rect(self, 4, 4, w-4, h-4, max(8, int(w*0.04)), fill="#f7f7f7", outline="#cccccc", width=max(2, int(w*0.01)))
        draw_face_base(self, 0, 0, w, h, skin)
        draw_hair(self, 0, 0, w, h, hair_style, hair)
        cx = w//2; cy = int(h*0.45)
        draw_eyes(self, cx, cy, w, h, eye_style)
        draw_mouth(self, cx, int(h*0.58), w, h, mouth_style)
        self.create_polygon(cx, int(h*0.5)-int(0.01*h), cx-int(0.025*w), int(h*0.52)+int(0.02*h), cx+int(0.025*w), int(h*0.52)+int(0.02*h), fill="#d08b6a", outline="")
        draw_accessory(self, cx, int(h*0.45), acc_type, acc_col, w, h)
        self.create_text(w//2, int(h*0.88), text=symbol, fill="#333333", font=("Helvetica", max(8, int(h*0.07)), "bold"))

        if highlight:
            self.create_rectangle(2, 2, w-2, h-2, outline="#2ecc71", width=max(4, int(w*0.02)))

# --- Match game with matches panel, Auto Win, and "Show Matches Only" toggle ---
class MatchGame(tk.Tk):
    def __init__(self, rows=ROWS, cols=COLS, card_w=CARD_W, card_h=CARD_H):
        super().__init__()
        self.title("Memory Match — 32 Cards")
        self.rows = rows; self.cols = cols; self.card_w = card_w; self.card_h = card_h
        self.board = make_deck(rows, cols)
        self.revealed = [[False]*cols for _ in range(rows)]
        self.widgets = [[None]*cols for _ in range(rows)]
        self.first = None; self.locked = False; self.pairs_found = 0
        self.total_pairs = (rows*cols)//2; self.turns = 0
        self.matched_symbols = []
        self.show_matches_only = False

        main = tk.Frame(self); main.pack(fill="both", expand=True)
        board_frame = tk.Frame(main); board_frame.pack(side="left", fill="both", expand=True, padx=6, pady=6)
        matches_frame = tk.Frame(main, width=240); matches_frame.pack(side="right", fill="y", padx=6, pady=6)
        matches_frame.pack_propagate(False)

        top = tk.Frame(board_frame); top.pack(fill="x")
        self.status = tk.Label(top, text=self.status_text(), font=("Arial", 12)); self.status.pack(side="left")
        reset_btn = tk.Button(top, text="Reset", command=self.reset_game); reset_btn.pack(side="right", padx=4)
        auto_btn = tk.Button(top, text="Auto Win", command=self.auto_win); auto_btn.pack(side="right", padx=4)
        self.toggle_btn = tk.Button(top, text="Show Matches Only", command=self.toggle_show_matches)
        self.toggle_btn.pack(side="right", padx=4)

        container = tk.Frame(board_frame); container.pack(fill="both", expand=True)
        canvas = tk.Canvas(container, bg=self['bg']); vbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview); hbar = tk.Scrollbar(container, orient="horizontal", command=canvas.xview)
        canvas.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        vbar.pack(side="right", fill="y"); hbar.pack(side="bottom", fill="x"); canvas.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(canvas, bg=self['bg'])
        canvas_window = canvas.create_window((0,0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(canvas_window, width=e.width))

        for r in range(rows):
            for c in range(cols):
                canvas_card = CardCanvas(inner, r, c, self.card_w, self.card_h, bg=self['bg'])
                canvas_card.grid(row=r, column=c, padx=PADDING//2, pady=PADDING//2)
                canvas_card.draw_back()
                canvas_card.bind("<Button-1>", lambda e, rr=r, cc=c: self.on_click(rr, cc))
                self.widgets[r][c] = canvas_card

        tk.Label(matches_frame, text="Matches", font=("Arial", 14, "bold")).pack(pady=(6,4))
        self.matches_count_label = tk.Label(matches_frame, text="0 / " + str(self.total_pairs), font=("Arial", 12))
        self.matches_count_label.pack()
        self.matches_list = tk.Frame(matches_frame)
        self.matches_list.pack(fill="both", expand=True, pady=8)

        self.update_idletasks()
        sw = self.winfo_screenwidth(); sh = self.winfo_screenheight()
        win_w = min(int(sw*0.95), max(800, (self.card_w+PADDING)*min(self.cols, 10) + 260))
        win_h = min(int(sh*0.9), max(500, (self.card_h+PADDING)*min(self.rows, 8)))
        x = (sw - win_w)//2; y = (sh - win_h)//2
        self.geometry(f"{win_w}x{win_h}+{x}+{y}")

        self._matches_frame = self.matches_list

    def status_text(self):
        return f"Pairs: {self.pairs_found}/{self.total_pairs}   Turns: {self.turns}"

    def on_click(self, r, c):
        if self.locked or self.revealed[r][c]:
            return
        sym = self.board[r][c]
        self.widgets[r][c].draw_character(sym)
        self.revealed[r][c] = True

        if self.first is None:
            self.first = (r, c)
            return

        r1, c1 = self.first
        if (r1, c1) == (r, c):
            return

        self.locked = True
        self.turns += 1
        sym1 = self.board[r1][c1]
        sym2 = self.board[r][c]

        if sym1 == sym2:
            # mark matched and update UI
            self.widgets[r1][c1].draw_character(sym1, highlight=True)
            self.widgets[r][c].draw_character(sym2, highlight=True)
            self.widgets[r1][c1].is_matched = True
            self.widgets[r][c].is_matched = True
            self.pairs_found += 1
            if sym1 not in self.matched_symbols:
                self.matched_symbols.append(sym1)
                self._add_match_preview(sym1)
            self.first = None
            self.locked = False
            self.status.config(text=self.status_text())
            self.matches_count_label.config(text=f"{self.pairs_found} / {self.total_pairs}")
            # if "show matches only" is active, hide non-matched cards now
            if self.show_matches_only:
                self._apply_show_matches_only()
            if self.pairs_found == self.total_pairs:
                messagebox.showinfo("You win!", f"All pairs found in {self.turns} turns.")
        else:
            self.after(FLIP_DELAY_MS, lambda: self.hide_cards((r1, c1), (r, c)))
            self.status.config(text=self.status_text())

    def hide_cards(self, a, b):
        (r1, c1), (r2, c2) = a, b
        self.revealed[r1][c1] = False
        self.revealed[r2][c2] = False
        self.widgets[r1][c1].draw_back()
        self.widgets[r2][c2].draw_back()
        self.first = None
        self.locked = False

    def _add_match_preview(self, symbol):
        preview_w = 96; preview_h = 132
        frame = tk.Frame(self._matches_frame, pady=6)
        frame.pack(fill="x", padx=6)
        preview = tk.Canvas(frame, width=preview_w, height=preview_h, highlightthickness=0, bg=self['bg'])
        preview.pack(side="left")
        seed = ord(symbol[0]) + (int(symbol[1]) if len(symbol)>1 and symbol[1].isdigit() else 0)
        skin = color_from_seed(seed); hair = hair_color_from_seed(seed)
        draw_rounded_rect(preview, 2, 2, preview_w-2, preview_h-2, 8, fill="#f7f7f7", outline="#cccccc", width=2)
        draw_face_base(preview, 0, 0, preview_w, preview_h, skin)
        draw_hair(preview, 0, 0, preview_w, preview_h, seed%4, hair)
        cx = preview_w//2; cy = int(preview_h*0.45)
        draw_eyes(preview, cx, cy, preview_w, preview_h, seed%2)
        draw_mouth(preview, cx, int(preview_h*0.58), preview_w, preview_h, seed%2)
        preview.create_rectangle(2, 2, preview_w-2, preview_h-2, outline="#2ecc71", width=3)
        lbl = tk.Label(frame, text=f"Symbol: {symbol}", anchor="w")
        lbl.pack(side="left", padx=8, fill="x", expand=True)

    def reset_game(self):
        self.board = make_deck(self.rows, self.cols)
        self.revealed = [[False] * self.cols for _ in range(self.rows)]
        self.pairs_found = 0; self.turns = 0; self.first = None; self.locked = False
        self.matched_symbols = []
        for child in self._matches_frame.winfo_children():
            child.destroy()
        self.matches_count_label.config(text=f"{self.pairs_found} / {self.total_pairs}")
        # reset widgets and ensure all are visible
        for r in range(self.rows):
            for c in range(self.cols):
                w = self.widgets[r][c]
                w.is_matched = False
                w.draw_back()
                try:
                    w.grid()
                except Exception:
                    pass
        self.show_matches_only = False
        self.toggle_btn.config(text="Show Matches Only")
        self.status.config(text=self.status_text())

    def auto_win(self):
        """Reveal and mark every pair as matched immediately."""
        self.locked = True
        positions = {}
        for r in range(self.rows):
            for c in range(self.cols):
                sym = self.board[r][c]
                positions.setdefault(sym, []).append((r, c))
        for sym, pos_list in positions.items():
            for (r, c) in pos_list:
                self.widgets[r][c].draw_character(sym, highlight=True)
                self.widgets[r][c].is_matched = True
                self.revealed[r][c] = True
            if sym not in self.matched_symbols:
                self.matched_symbols.append(sym)
                self._add_match_preview(sym)
        self.pairs_found = self.total_pairs
        self.matches_count_label.config(text=f"{self.pairs_found} / {self.total_pairs}")
        self.status.config(text=self.status_text())
        self.locked = False
        if self.show_matches_only:
            self._apply_show_matches_only()
        messagebox.showinfo("You win!", f"All pairs revealed. You auto-won the game in {self.turns} turns.")

    # --- Show Matches Only feature ---
    def toggle_show_matches(self):
        self.show_matches_only = not self.show_matches_only
        if self.show_matches_only:
            self.toggle_btn.config(text="Show All Cards")
            self._apply_show_matches_only()
        else:
            self.toggle_btn.config(text="Show Matches Only")
            self._restore_all_cards()

    def _apply_show_matches_only(self):
        """Hide every card widget that is not matched (grid_remove preserves grid info)."""
        for r in range(self.rows):
            for c in range(self.cols):
                w = self.widgets[r][c]
                if not getattr(w, "is_matched", False):
                    try:
                        w.grid_remove()
                    except Exception:
                        pass
                else:
                    try:
                        w.grid()
                    except Exception:
                        pass

    def _restore_all_cards(self):
        """Restore visibility of all card widgets."""
        for r in range(self.rows):
            for c in range(self.cols):
                w = self.widgets[r][c]
                try:
                    w.grid()
                except Exception:
                    pass

if __name__ == "__main__":
    app = MatchGame(rows=ROWS, cols=COLS, card_w=CARD_W, card_h=CARD_H)
    app.mainloop()
