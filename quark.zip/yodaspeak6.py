import random

def yoda_speak(sentence):
    words = sentence.split()
    if len(words) < 4:
        return "Hmm. Speak more, you must."

    # Invert sentence halves for Yoda-style syntax
    split_point = len(words) // 2
    first_half = words[split_point:]
    second_half = words[:split_point]
    yoda_sentence = ' '.join(first_half + second_half)

    # Add a Yoda-style ending
    yoda_flair = random.choice([
        "Strong in the Force, you are.",
        "Much to learn, you still have.",
        "Hmm.",
        "Yes, hmmm.",
        "The dark side clouds everything.",
        "Do or do not. There is no try."
    ])
    return f"{yoda_sentence}. {yoda_flair}"

# Loop until user exits
while True:
    input_string = input("Speak a sentence, you must (or type 'exit' to leave): ")
    if input_string.lower() in ['exit', 'quit']:
        print("Farewell, young Padawan.")
        break
    translated = yoda_speak(input_string)
    print("Yoda says:", translated)
