import random

snoop_quotes = [
    "If it's flipping hamburgers at McDonald's, be the best hamburger flipper in the world.",
    "You've got to always go back in time if you want to move forward.",
    "Be your own leader, be your own self, step out of my shadows and be your own person.",
    "The more medicated, the more dedicated.",
    "You might not have a car or a big gold chain, stay true to yourself and things will change.",
    "Life is about growing and evolving. I’m not who I was a decade ago.",
    "U don't know where u goin unless u know where u come from.",
    "It ain't no fun if the homies can't have none.",
    "My mind on my money, my money on my mind.",
    "Rolling down the street, smoking indo, sippin’ on gin and juice.",
    "Every dog has his day, so I’m barkin’ up the right tree.",
    "With so much drama in the L-B-C, it’s kinda hard bein’ Snoop D-O-double-G.",
    "The best advice I’ve ever got is to be yourself.",
    "Don’t get upset girl, that’s how it goes.",
    "I’m not just a rapper, I’m a brand.",
    "I’m trying to be the best me I can be.",
    "You’ve got to always stay true to yourself.",
    "I’m a spiritual man and I believe in karma.",
    "I’m a grown man, I do what I want.",
    "I’m here to entertain and inspire.",
    "I’m just trying to be somebody in a world full of nobodies.",
    "I’m not a role model, I’m a real model.",
    "I’m living proof that dreams come true.",
    "I’m loyal to the soil.",
    "I’m a product of my environment.",
    "I’m a hustler, baby.",
    "I’m a smooth operator.",
    "I’m a boss player.",
    "I’m a doggfather.",
    "I’m a lion in the jungle.",
    "I’m a soldier in the game.",
    "I’m a king without a crown.",
    "I’m a poet with a beat.",
    "I’m a legend in my own time.",
    "I’m a survivor of the streets.",
    "I’m a teacher of the truth.",
    "I’m a messenger of love.",
    "I’m a warrior of peace.",
    "I’m a student of life.",
    "I’m a master of my destiny.",
    "I’m a creator of vibes.",
    "I’m a conductor of rhythm.",
    "I’m a preacher of funk.",
    "I’m a prophet of cool.",
    "I’m a magician of flow.",
    "I’m a guardian of style.",
    "I’m a rebel with a cause.",
    "I’m a dreamer with a mic.",
    "I’m a thinker with a groove.",
    "I’m a healer with a verse.",
    "I’m a builder of bridges.",
    "I’m a breaker of chains.",
    "I’m a lover of life.",
    "I’m a seeker of truth.",
    "I’m a giver of game.",
    "I’m a rider of rhythm.",
    "I’m a flyer of funk.",
    "I’m a slinger of slang.",
    "I’m a dealer of dope beats.",
    "I’m a chef of soul food.",
    "I’m a pilot of the vibe.",
    "I’m a captain of cool.",
    "I’m a navigator of notes.",
    "I’m a sculptor of sound.",
    "I’m a painter of poetry.",
    "I’m a tailor of tone.",
    "I’m a weaver of words.",
    "I’m a spinner of stories.",
    "I’m a whisperer of wisdom.",
    "I’m a guardian of groove.",
    "I’m a keeper of the funk."
]

def snoop_quote():
    return random.choice(snoop_quotes)

def main():
    print("🎤 Welcome to the Snoop Dogg Quote Generator!")
    print("Type 'exit' or 'quit' to stop.\n")
    while True:
        user_input = input("Press Enter for a quote (or type 'exit'): ").strip().lower()
        if user_input in ['exit', 'quit']:
            print("✌️ Peace out. Stay funky.")
            break
        print(f"💬 Snoop says: \"{snoop_quote()}\"\n")

if __name__ == "__main__":
    main()
