import random

einstein_quotes = [
    "Imagination is more important than knowledge.",
    "Life is like riding a bicycle. To keep your balance you must keep moving.",
    "Try not to become a man of success, but rather try to become a man of value.",
    "The important thing is not to stop questioning. Curiosity has its own reason for existing.",
    "I have no special talent. I am only passionately curious.",
    "A person who never made a mistake never tried anything new.",
    "Reality is merely an illusion, albeit a very persistent one.",
    "If you can't explain it simply, you don't understand it well enough.",
    "Logic will get you from A to B. Imagination will take you everywhere.",
    "The true sign of intelligence is not knowledge but imagination.",
    "Strive not to be a success, but rather to be of value.",
    "Only a life lived for others is a life worthwhile.",
    "Peace cannot be kept by force; it can only be achieved by understanding.",
    "It's not that I'm so smart, it's just that I stay with problems longer.",
    "No problem can be solved from the same level of consciousness that created it.",
    "Weak people revenge. Strong people forgive. Intelligent people ignore.",
    "We can't solve problems by using the same kind of thinking we used when we created them.",
    "The difference between stupidity and genius is that genius has its limits.",
    "The world will not be destroyed by those who do evil, but by those who watch them without doing anything.",
    "Education is what remains after one has forgotten what one has learned in school.",
    "In the middle of difficulty lies opportunity.",
    "I never teach my pupils. I only attempt to provide the conditions in which they can learn.",
    "The measure of intelligence is the ability to change.",
    "The only source of knowledge is experience.",
    "Once you stop learning, you start dying.",
    "A clever person solves a problem. A wise person avoids it.",
    "Small is the number of people who see with their eyes and think with their minds.",
    "The value of a man should be seen in what he gives and not in what he is able to receive.",
    "It is the supreme art of the teacher to awaken joy in creative expression and knowledge.",
    "The monotony and solitude of a quiet life stimulates the creative mind.",
    "I live in that solitude which is painful in youth, but delicious in the years of maturity.",
    "The pursuit of truth and beauty is a sphere of activity in which we are permitted to remain children all our lives.",
    "The most beautiful thing we can experience is the mysterious.",
    "Science without religion is lame, religion without science is blind.",
    "I believe in intuition and inspiration.",
    "The only thing that you absolutely have to know, is the location of the library.",
    "It has become appallingly obvious that our technology has exceeded our humanity.",
    "I am enough of an artist to draw freely upon my imagination.",
    "The hardest thing in the world to understand is the income tax.",
    "Not everything that can be counted counts, and not everything that counts can be counted.",
    "Any fool can know. The point is to understand.",
    "Creativity is intelligence having fun.",
    "The most incomprehensible thing about the world is that it is comprehensible.",
    "I speak to everyone in the same way, whether he is the garbage man or the president of the university.",
    "You never fail until you stop trying.",
    "Blind belief in authority is the greatest enemy of truth.",
    "The only real valuable thing is intuition.",
    "I do not believe in the God of theology who rewards good and punishes evil.",
    "The important thing is not to stop questioning.",
    "The intuitive mind is a sacred gift and the rational mind is a faithful servant.",
    "We should take care not to make the intellect our god.",
    "The most powerful force in the universe is compound interest.",
    "I love to travel, but I hate to arrive.",
    "I am not only a pacifist but a militant pacifist.",
    "The tragedy of life is what dies inside a man while he lives.",
    "You can't blame gravity for falling in love.",
    "I think and think for months and years. Ninety-nine times, the conclusion is false. The hundredth time I am right.",
    "The distinction between past, present and future is only a stubbornly persistent illusion.",
    "I would teach peace rather than war. I would inculcate love rather than hate.",
    "The ideals which have always shone before me and filled me with joy are goodness, beauty, and truth.",
    "The only way to escape the corruptible effect of praise is to go on working.",
    "The most important decision we make is whether we believe we live in a friendly or hostile universe.",
    "I am by heritage a Jew, by citizenship a Swiss, and by makeup a human being.",
    "I am not a genius, I am just curious.",
    "I have reached an age where, if someone tells me to wear socks, I don't have to.",
    "You ask me if I keep a notebook to record my great ideas. I've only ever had one.",
    "I never came upon any of my discoveries through the process of rational thinking.",
    "I do not carry such information in my mind since it is readily available in books.",
    "I do not like to state ideas until I am reasonably sure of them."
    
    # Your 70 quotes go here...
]

def random_einstein_quote():
    quote = random.choice(einstein_quotes)
    print(f"\n💬 Einstein says: \"{quote}\"\n")

def run_quote_loop():
    print("🔁 Einstein Quote Generator is ready. Type 'exit' to stop.")
    while True:
        random_einstein_quote()
        user_input = input("Press Enter for another quote or type 'exit' to quit: ").strip().lower()
        if user_input == 'exit':
            print("👋 Farewell! May your curiosity never stop.")
            break

# Start the loop
run_quote_loop()
