import tkinter as tk
import os

def execute_program():
    selected_program = var.get()
    if selected_program == "Program 1":
        os.system("c:/python/peeweegenorator3.py")
    elif selected_program == "Program 2":
        os.system("c:/python/flanders2.py")
    elif selected_program == "Program 3":
        os.system("c:/python/snoop3.py")
    elif selected_program == "Program 4":
        os.system("c:/python/einstein2.py")
    elif selected_program == "Program 5":
        os.system("c:/python/yodaspeak6.py")
    elif selected_program == "Program 6":
        os.system("c:/python/cargenerater2.py")
    elif selected_program == "Program 7":
        os.system("c:/python/morsecode3.py")
    elif selected_program == "Program 8":
        os.system("c:/python/cliches2.py")
    elif selected_program == "Program 9":
        os.system("c:/python/brew.py")
    elif selected_program == "Program 10":
        os.system("c:/python/bitbyte41.py")
    elif selected_program == "Program 11":
        os.system("c:/python/snake7.py")

# Create the main window
root = tk.Tk()
root.title("Program Selector")

# Create a Tkinter variable
var = tk.StringVar(value="Program 1")

# Create radio buttons
radio1 = tk.Radiobutton(root, text="peewee genorator", variable=var, value="Program 1")
radio2 = tk.Radiobutton(root, text="flanders genorator", variable=var, value="Program 2")
radio3 = tk.Radiobutton(root, text="snoop genorator", variable=var, value="Program 3")
radio4 = tk.Radiobutton(root, text="einstein genorator", variable=var, value="Program 4")
radio5 = tk.Radiobutton(root, text="yoda speak", variable=var, value="Program 5")
radio6 = tk.Radiobutton(root, text="car generater", variable=var, value="Program 6")
radio7 = tk.Radiobutton(root, text="morse code", variable=var, value="Program 7")
radio8 = tk.Radiobutton(root, text="cliches", variable=var, value="Program 8")
radio9 = tk.Radiobutton(root, text="brew", variable=var, value="Program 9")
radio10 = tk.Radiobutton(root, text="bitbyte", variable=var, value="Program 10")
radio11 = tk.Radiobutton(root, text="snake", variable=var, value="Program 11")

# Pack the radio buttons
radio1.pack(anchor=tk.W)
radio2.pack(anchor=tk.W)
radio3.pack(anchor=tk.W)
radio4.pack(anchor=tk.W)
radio5.pack(anchor=tk.W)
radio6.pack(anchor=tk.W)
radio7.pack(anchor=tk.W)
radio8.pack(anchor=tk.W)
radio9.pack(anchor=tk.W)
radio10.pack(anchor=tk.W)
radio11.pack(anchor=tk.W)

# Create a button to execute the selected program
execute_button = tk.Button(root, text="Execute", command=execute_program)
execute_button.pack()

# Run the main loop
root.mainloop()
