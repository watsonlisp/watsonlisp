import random

car_names = [
    "Thunderbolt GT", "Crimson Cruiser", "Nebula X", "Phantom V8", "Solar Drift",
    "Iron Stallion", "Echo Racer", "Quantum LX", "Velvet Torque", "Obsidian Trail",
    "Falcon ZR", "Aurora Pulse", "Titan Mirage", "Shadowline", "Nova Trek",
    "Blizzard Runner", "Inferno SX", "Zephyr Glide", "Midnight Howl", "Radiant Bolt",
    "Turbo Specter", "Lunar Stride", "Chrome Phantom", "Storm Chaser", "Vortex Edge",
    "Gravity Shift", "Pulsefire", "Eclipse GT", "Tempest R", "Savage Drift",
    "Cobalt Flash", "Wild Ember", "Ghostline", "Alpha Surge", "Retro Blaze",
    "Mystic Hauler", "Diesel Whisper", "Jagged Orbit", "Frostbite", "Magnetron",
    "Warp Drive", "Neon Trail", "Echo Hauler", "Steel Mirage", "Turbo Tundra",
    "Crater Cruiser", "Nimbus LX", "Rogue Runner", "Spectra SX", "Zenith Trek",
    "Oblivion GT", "Solar Hauler", "Twilight Racer", "Hypernova", "Grizzly Pulse"
]

def generate_car_name():
    return random.choice(car_names)

print("Welcome to the Random Car Name Generator!")
print("Type 'exit' to quit.\n")

while True:
    user_input = input("Press Enter to generate a car name or type 'exit': ").strip().lower()
    if user_input == "exit":
        print("Goodbye! Drive safe out there.")
        break
    print("🚗 Your random car name is:", generate_car_name(), "\n")
