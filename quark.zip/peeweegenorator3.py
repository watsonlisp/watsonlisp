import random

peewee_quotes = [
    # Classic Pee-wee lines
    "I know you are, but what am I?",
    "That's my name, don't wear it out!",
    "Why don't you take a picture? It'll last longer!",
    "I'm a loner, Dottie. A rebel.",
    "I meant to do that.",
    "Paging Mr. Herman...",
    "The mind reels!",
    "It's not for sale, Francis!",
    "I don't make monkeys, I just train 'em!",
    "I'm trying to use the phone!",
    "I love that story!",
    "You don't wanna get mixed up with a guy like me.",
    
    # Recursive identity riffs
    "I’m a rebel, a loner, a dreamer.",
    "I’m a Pee Wee, a chamewab, a bog dweller.",
    "I’m a box whisperer, a quote collector, a regenerator.",
    "I’m a P-regenerator, a Paul Neu-Paul Rubens remix.",
    "I’m the luckiest boy in the world!",
    "I’m listening to reason!",
    "I’m a rebel, a loner, a dreamer, a Pee Wee.",
    "I’m a rebel, a loner, a dreamer, a Pee Wee, a chamewab.",
    "I’m a rebel, a loner, a dreamer, a Pee Wee, a chamewab, a bog dweller.",
    "I’m a rebel, a loner, a dreamer, a Pee Wee, a chamewab, a bog dweller, a box whisperer.",
    "I’m a rebel, a loner, a dreamer, a Pee Wee, a chamewab, a bog dweller, a box whisperer, a quote collector.",
    "I’m a rebel, a loner, a dreamer, a Pee Wee, a chamewab, a bog dweller, a box whisperer, a quote collector, a generator.",
    "I’m a rebel, a loner, a dreamer, a Pee Wee, a chamewab, a bog dweller, a box whisperer, a quote collector, a generator, a regenerator.",
    "I’m a rebel, a loner, a dreamer, a Pee Wee, a chamewab, a bog dweller, a box whisperer, a quote collector, a generator, a regenerator, a P-regenerator.",
    "I’m a rebel, a loner, a dreamer, a Pee Wee, a chamewab, a bog dweller, a box whisperer, a quote collector, a generator, a regenerator, a P-regenerator, a Paul Neu-Paul Rubens remix.",
    
    # Surreal expansions
    "I’m a breakfast rebel, a cereal surrealist.",
    "I’m a chair dancer, a scream whisperer, a giggle architect.",
    "I’m a rubber chicken philosopher, a bowtie bard.",
    "I’m a Playhouse prophet, a puppet confidant.",
    "I’m a Pee Wee echo, a laugh loop, a bicycle oracle.",
    "I’m a breakfast machine operator, a talking couch therapist.",
    "I’m a puppet’s dream, a cowboy’s giggle, a genie’s hiccup.",
    "I’m a Pee Wee palindrome: me, we, wee, me.",
    "I’m a remix, a rerun, a rewind, a rewind, a rewind.",
    "I’m a scream in a box, a whisper in a bowtie.",
    "I’m a Paul, a Reubens, a Rubens, a remix of a remix.",
    
    # Pee-wee philosophy
    "Let’s make a big deal out of having fun!",
    "Imagination is the key to happiness!",
    "Never lose your sense of wonder!",
    "Adventure awaits if you just look around!",
    "There’s no age limit to having fun!",
    "Childlike curiosity fuels the spark of creativity!",
    "Let your imagination run wild!",
    "The world is a magical place when you see it through a child’s eyes.",
    "You could learn a lot from a kid!",
    "Being happy is not about what you have, it’s about who you are!",
    "Sometimes you have to be a little silly to enjoy life!",
    "I think being funny is what I do best!",
    "I love being a kid! Life is one big adventure.",
    
    # Paul Reubens reflections
    "I’m just trying to illustrate that it’s okay to be different.",
    "I enjoy getting to be arty and quirky and weird.",
    "You just sort of use what you got.",
    "People read so much into what I do.",
    "I’ve always felt like a kid, and I still feel like a kid.",
    "I think my entire career path was determined when I was 6.",
    "It’s a lot easier to say you’re a comic than a performance artist.",
    "I’ve never had any problem tapping into my childhood.",
    "I don’t expect that I’m going to be any different.",
    "I still feel 20.",
    
    # Bonus absurdities
    "I’m a giggle in a blender, a hiccup in a hammock.",
    "I’m a bowtie in a thunderstorm, a puppet in a paradox.",
    "I’m a Pee Wee in a pickle, a rebel in a rubber boot.",
    "I’m a whisper in a wind-up toy, a scream in a snow globe.",
    "I’m a rerun of a rerun of a rerun.",
    "I’m a quote inside a quote inside a quote.",
    "I’m a Pee Wee, a me-wee, a we-we-we.",
    "I’m a dreamer in a box, a rebel in a rhyme.",
    "I’m a Pee Wee in a poem, a Paul in a paradox.",
    "I’m a remix of a remix of a remix of a remix."
]

def peewee_generator():
    print("🎉 Welcome to the Pee Wee Generator! 🎉")
    while True:
        quote = random.choice(peewee_quotes)
        print("\n🗯️ Pee Wee says:", quote)
        user_input = input("\nType 'exit' to leave the bog, or press Enter for another quote: ").strip().lower()
        if user_input == "exit":
            print("\n👋 Bye y'all! Peace, peace, peace, peace, peace.")
            break

peewee_generator()
