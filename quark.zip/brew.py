import random
import time

# A bubbling list of spooky ingredients
ingredients = [
    "bat wing", "ghost tear", "zombie toenail", "witch's whisper", "vampire fang",
    "slimy moss", "cursed pearl", "ghoul breath", "phantom fog", "skeleton dust",
    "demon scale", "rotting root", "shadow silk", "moon venom", "haunted honey",
    "eyeball jelly", "specter spit", "mummy wrap", "howling hair", "graveyard soil"
]

# Expand to hundreds of ingredients
while len(ingredients) < 200:
    new_ingredient = f"{random.choice(['evil', 'slimy', 'haunted', 'rotting', 'cursed'])} {random.choice(['slime', 'bone', 'mist', 'flesh', 'ooze'])} #{len(ingredients)+1}"
    ingredients.append(new_ingredient)

# The bubbling brew
witches_brew = []

print("🧙‍♀️ Welcome to Witch's Brew! Type 'exit' anytime to stop the spell.\n")

for ingredient in random.sample(ingredients, len(ingredients)):
    time.sleep(0.4)
    response = input(f"Shall we add '{ingredient}' to the brew? (yes/no/exit): ").strip().lower()
    if response == "yes":
        witches_brew.append(ingredient)
        print(f"💀 '{ingredient}' added! The brew grows darker...\n")
    elif response == "no":
        print(f"🕸️ '{ingredient}' rejected. The spirits stir...\n")
    elif response in ["exit", "quit"]:
        print("\n🔮 The cauldron quiets... the ritual ends.\n")
        break
    else:
        print("🌀 The spirits don't understand. We'll skip this one.\n")

print("🧪 Final Witch's Brew:")
for item in witches_brew:
    print(f" - {item}")

print("\n🌑 May your potion bring chaos and cackles!") 
sentence2 = str(input('pause '))
