import os
import time
import random
import msvcrt

# Game settings
WIDTH = 40
HEIGHT = 20
SNAKE_CHAR = 'O'
FOOD_CHAR = '*'
EMPTY_CHAR = ' '
DELAY = 0.1

def draw_board(snake, food, score):
    os.system('cls')
    print('+' + '-' * WIDTH + '+')
    for y in range(HEIGHT):
        row = ''
        for x in range(WIDTH):
            if [x, y] == food:
                row += FOOD_CHAR
            elif [x, y] in snake:
                row += SNAKE_CHAR
            else:
                row += EMPTY_CHAR
        print('|' + row + '|')
    print('+' + '-' * WIDTH + '+')
    print(f"Score: {score}   Press Q to quit")

def get_direction(current_dir):
    if msvcrt.kbhit():
        key = msvcrt.getch().decode('utf-8').lower()
        if key == 'w' and current_dir != [0, 1]:
            return [0, -1]
        elif key == 's' and current_dir != [0, -1]:
            return [0, 1]
        elif key == 'a' and current_dir != [1, 0]:
            return [-1, 0]
        elif key == 'd' and current_dir != [-1, 0]:
            return [1, 0]
        elif key == 'q':
            return 'quit'
    return current_dir

def play_game():
    snake = [[WIDTH // 2, HEIGHT // 2]]
    direction = [1, 0]
    food = [random.randint(0, WIDTH - 1), random.randint(0, HEIGHT - 1)]
    score = 0

    while True:
        draw_board(snake, food, score)
        new_dir = get_direction(direction)
        if new_dir == 'quit':
            print("🌘 The serpent coils into memory...")
            return False
        direction = new_dir

        new_head = [snake[-1][0] + direction[0], snake[-1][1] + direction[1]]

        if (new_head in snake or
            new_head[0] < 0 or new_head[0] >= WIDTH or
            new_head[1] < 0 or new_head[1] >= HEIGHT):
            draw_board(snake, food, score)
            print("💀 Game Over! The snake has met its fate.")
            time.sleep(1)
            return True

        snake.append(new_head)

        if new_head == food:
            score += 1
            food = [random.randint(0, WIDTH - 1), random.randint(0, HEIGHT - 1)]
        else:
            snake.pop(0)

        time.sleep(DELAY)

def main():
    while True:
        game_over = play_game()
        print("\n🔁 Play again? (Y/N): ", end='', flush=True)
        while True:
            if msvcrt.kbhit():
                choice = msvcrt.getch().decode('utf-8').lower()
                if choice == 'y':
                    break
                elif choice == 'n':
                    print("🌒 Farewell, brave Serpent-Wanderer...")
                    return

main()
