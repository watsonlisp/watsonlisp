import os
import time
import random
import msvcrt  # For real-time keyboard input on Windows

# Game settings
WIDTH, HEIGHT = 20, 20
DOT = '.'
EMPTY = ' '
WALL = '#'
bitbyte = 'C'
GHOST = 'G'
SUPER_BIT = '*'
NUM_GHOSTS = 9
HUNT_DURATION = 50

def generate_maze():
    maze = []
    for y in range(HEIGHT):
        row = []
        for x in range(WIDTH):
            r = random.random()
            if r < 0.2:
                row.append(WALL)
            elif r < 0.5:
                row.append(EMPTY)
            elif r < 0.55:
                row.append(SUPER_BIT)
            else:
                row.append(DOT)
        maze.append(row)
    return maze

def check_win():
    bits_remaining = any(DOT in row or SUPER_BIT in row for row in maze)
    ghosts_remaining = len(ghosts) > 0
    return not bits_remaining or not ghosts_remaining


def get_key():
    if msvcrt.kbhit():
        return msvcrt.getch().decode('utf-8').lower()
    return ''

# Replay loop
while True:
    LIVES = 7
    hunt_mode = False
    hunt_timer = 0
    maze = generate_maze()

    # Place Pac-Man
    while True:
        pac_x, pac_y = random.randint(0, WIDTH - 1), random.randint(0, HEIGHT - 1)
        if maze[pac_y][pac_x] in (DOT, SUPER_BIT):
            maze[pac_y][pac_x] = bitbyte
            break

    # Place ghosts
    ghosts = []
    for _ in range(NUM_GHOSTS):
        while True:
            gx, gy = random.randint(0, WIDTH - 1), random.randint(0, HEIGHT - 1)
            if maze[gy][gx] in (DOT, SUPER_BIT) and (gx, gy) != (pac_x, pac_y):
                ghosts.append([gx, gy])
                maze[gy][gx] = GHOST
                break

    def draw_maze():
        os.system('cls' if os.name == 'nt' else 'clear')
        print('+' + '-' * (2 * WIDTH - 1) + '+')
        for row in maze:
            print('|' + ' '.join(row) + '|')
        print('+' + '-' * (2 * WIDTH - 1) + '+')
        print(f"\nLives remaining: {LIVES}")
        if hunt_mode:
            print(f"Hunt mode active! {hunt_timer} steps remaining.")
        print("Use W/A/S/D to move, O to shift, Q to quit.")

    def move(dx, dy):
        global pac_x, pac_y, LIVES, hunt_mode, hunt_timer, ghosts
        new_x = pac_x + dx
        new_y = pac_y + dy
        if 0 <= new_x < WIDTH and 0 <= new_y < HEIGHT:
            target = maze[new_y][new_x]
            if target == WALL:
                return
            if target == DOT or target == SUPER_BIT:
                if target == SUPER_BIT:
                    hunt_mode = True
                    hunt_timer = HUNT_DURATION
                    print("✨ Super Bit consumed! You can hunt ghosts for a while.")
                maze[new_y][new_x] = EMPTY
            if target == GHOST:
                if hunt_mode:
                    maze[new_y][new_x] = EMPTY
                    ghosts = [g for g in ghosts if g != [new_x, new_y]]
                    print("👻 Ghost banished by Super Bit power!")
                    time.sleep(0.5)
                else:
                    LIVES -= 1
                    maze[pac_y][pac_x] = EMPTY
                    print(f"💥 A ghost strikes! Lives remaining: {LIVES}")
                    time.sleep(1)
                    if LIVES <= 0:
                        pac_x, pac_y = new_x, new_y
                        maze[pac_y][pac_x] = bitbyte
                        draw_maze()
                        print("👻 Your final breath echoes through the maze. Game over.")
                        input('Press Enter to continue...')
                        return 'game_over'
                    else:
                        while True:
                            new_px, new_py = random.randint(0, WIDTH - 1), random.randint(0, HEIGHT - 1)
                            if maze[new_py][new_px] in (DOT, SUPER_BIT):
                                pac_x, pac_y = new_px, new_py
                                maze[pac_y][pac_x] = bitbyte
                                break
                        return
            maze[pac_y][pac_x] = EMPTY
            pac_x, pac_y = new_x, new_y
            maze[pac_y][pac_x] = bitbyte

            if check_win():
                draw_maze()
                print("🎯 Every bit consumed! The maze exhales. Peace returns. You win!")
                input('Press Enter to continue...')
                return 'win'

    def move_ghosts():
        for ghost in ghosts:
            gx, gy = ghost
            directions = [(0, -1), (0, 1), (-1, 0), (1, 0)]
            dx, dy = random.choice(directions)
            new_x = gx + dx
            new_y = gy + dy
            if 0 <= new_x < WIDTH and 0 <= new_y < HEIGHT:
                target = maze[new_y][new_x]
                if target not in (GHOST, WALL, bitbyte):
                    maze[gy][gx] = EMPTY
                    ghost[0], ghost[1] = new_x, new_y
                    maze[new_y][new_x] = GHOST

    steps = 0
    while True:
        draw_maze()
        start_time = time.time()
        while True:
            command = get_key()
            if command:
                break
            if time.time() - start_time > 0.1:
                break

        if command == 'q':
            print("\n🌘 The spirits retreat. Pac-Man fades into the mist...\n")
            time.sleep(1)
            break
        elif command == 'w':
            result = move(0, -1)
        elif command == 's':
            result = move(0, 1)
        elif command == 'a':
            result = move(-1, 0)
        elif command == 'd':
            result = move(1, 0)
        elif command == 'o':
            print("✨ Forced shift selected")
            result = None
        else:
            continue

        move_ghosts()
        steps += 1
        if hunt_mode:
            hunt_timer -= 1
            if hunt_timer <= 0:
                hunt_mode = False
                print("⏳ Super Bit power fades. Ghosts are dangerous again.")

        if steps % 1000 == 0 or command == 'o':
            maze = generate_maze()
            maze[pac_y][pac_x] = bitbyte
            for gx, gy in ghosts:
                maze[gy][gx] = GHOST
            print("✨ The maze has shifted...")
            time.sleep(1)

        if result in ['win', 'game_over']:
            break

    choice = input("\n🔁 Play again? (y/n): ").strip().lower()
    if choice != 'y':
        print("🌒 Farewell, brave Pac-Wanderer...")
        break
