# Morse code dictionary
MORSE_CODE_DICT = {
    'A': '.-',     'B': '-...',   'C': '-.-.', 
    'D': '-..',    'E': '.',      'F': '..-.',
    'G': '--.',    'H': '....',   'I': '..',
    'J': '.---',   'K': '-.-',    'L': '.-..',
    'M': '--',     'N': '-.',     'O': '---',
    'P': '.--.',   'Q': '--.-',   'R': '.-.',
    'S': '...',    'T': '-',      'U': '..-',
    'V': '...-',   'W': '.--',    'X': '-..-',
    'Y': '-.--',   'Z': '--..',
    '0': '-----',  '1': '.----',  '2': '..---',
    '3': '...--',  '4': '....-',  '5': '.....',
    '6': '-....',  '7': '--...',  '8': '---..',
    '9': '----.',
    '.': '.-.-.-', ',': '--..--', '?': '..--..',
    "'": '.----.', '!': '-.-.--', '/': '-..-.',
    '(': '-.--.',  ')': '-.--.-', '&': '.-...',
    ':': '---...', ';': '-.-.-.', '=': '-...-',
    '+': '.-.-.',  '-': '-....-', '_': '..--.-',
    '"': '.-..-.', '$': '...-..-', '@': '.--.-.',
    ' ': '/'  # Use '/' to separate words
}

# Reverse dictionary for decoding
REVERSE_MORSE_CODE_DICT = {v: k for k, v in MORSE_CODE_DICT.items()}

def text_to_labeled_morse(text):
    labeled = []
    for char in text.upper():
        code = MORSE_CODE_DICT.get(char, '?')
        labeled.append(f"{char}: {code}")
    return '   '.join(labeled)

def morse_to_labeled_text(morse_code):
    labeled = []
    for code in morse_code.strip().split():
        letter = REVERSE_MORSE_CODE_DICT.get(code, '?')
        labeled.append(f"{code}: {letter}")
    return '   '.join(labeled)

# Loop until user exits
if __name__ == "__main__":
    print("Type something to convert to Morse code or decode Morse. Type 'exit' or 'quit' to stop.")
    while True:
        user_input = input(">> ")
        if user_input.lower() in ['exit', 'quit']:
            print("Goodbye, traveler of dots and dashes.")
            break
        if all(c in ['.', '-', ' ', '/'] for c in user_input.strip()):
            print("Decoded with labels:")
            print(morse_to_labeled_text(user_input))
        else:
            print("Encoded with labels:")
            print(text_to_labeled_morse(user_input))
