#!/usr/bin/env python3
"""
Yin-Yang Spinner — faster spin (Tkinter, standard library only)

- Same behavior as before but spins faster by default.
- No external libraries required.
"""

import tkinter as tk
import math
import random
import time
from threading import Thread

# ---------- Configuration ----------
WINDOW_W = 1000
WINDOW_H = 700
CIRCLE_DIAMETER = 520
FPS = 60
# Increased default rotation speed (degrees per second)
ROTATION_SPEED_DEG_PER_SEC = 360.0
MONTE_CARLO_SAMPLES = 40000  # total samples attempted (we only count those inside circle and right-half)

# ---------- Geometry helpers ----------
def rotate_point(x, y, cx, cy, angle_deg):
    """Rotate point (x,y) around center (cx,cy) by angle_deg degrees clockwise."""
    a = math.radians(-angle_deg)
    dx = x - cx
    dy = y - cy
    rx = dx * math.cos(a) - dy * math.sin(a)
    ry = dx * math.sin(a) + dy * math.cos(a)
    return cx + rx, cy + ry

def is_point_in_circle(px, py, cx, cy, r):
    dx = px - cx
    dy = py - cy
    return dx*dx + dy*dy <= r*r

def is_point_dark(px, py, cx, cy, r, angle_deg):
    """
    Analytic test whether a point (px,py) inside the main circle belongs to the dark (Yin)
    or light (Yang) region for a Yin-Yang rotated by angle_deg degrees clockwise.
    """
    ux, uy = rotate_point(px, py, cx, cy, -angle_deg)

    r_big = r
    small_r = r_big / 2.0
    top_small_cx = cx
    top_small_cy = cy - r_big / 2.0
    bottom_small_cx = cx
    bottom_small_cy = cy + r_big / 2.0

    # If outside main circle (in rotated coords) treat as not dark (shouldn't be sampled)
    if not is_point_in_circle(ux, uy, cx, cy, r_big):
        return False

    # Top small circle -> white (Yang)
    if is_point_in_circle(ux, uy, top_small_cx, top_small_cy, small_r):
        return False

    # Bottom small circle -> black (Yin)
    if is_point_in_circle(ux, uy, bottom_small_cx, bottom_small_cy, small_r):
        return True

    # Otherwise left half is black, right half is white
    return ux < cx

# ---------- GUI and drawing ----------
class YinYangApp:
    def __init__(self, root):
        self.root = root
        root.title("Yin-Yang — Right-of-arm percentages (faster spin)")

        # Layout
        self.top_frame = tk.Frame(root, bg="#111111")
        self.top_frame.pack(side="top", fill="x")
        self.canvas = tk.Canvas(root, width=WINDOW_W, height=WINDOW_H - 80, bg="#1e1e1e", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        # Controls
        btn_style = {"padx":8, "pady":6, "bg":"#2b2b2b", "fg":"#fff", "bd":0, "activebackground":"#3a3a3a"}
        tk.Button(self.top_frame, text="Reset (R)", command=self.reset_rotation, **btn_style).pack(side="left", padx=6, pady=8)
        tk.Button(self.top_frame, text="Stop/Start (Space / Click)", command=self.toggle_rotation, **btn_style).pack(side="left", padx=6, pady=8)
        tk.Button(self.top_frame, text="Compute Now", command=self.compute_now, **btn_style).pack(side="left", padx=6, pady=8)
        tk.Button(self.top_frame, text="Repeat", command=self.repeat_compute, **btn_style).pack(side="left", padx=6, pady=8)

        # Speed control (optional slider to let you adjust speed interactively)
        self.speed_var = tk.DoubleVar(value=ROTATION_SPEED_DEG_PER_SEC)
        speed_slider = tk.Scale(self.top_frame, from_=0, to=1440, orient="horizontal", length=260,
                                label="Spin speed (deg/sec)", variable=self.speed_var)
        speed_slider.pack(side="left", padx=8)

        # center and radius
        self.cx = WINDOW_W // 2
        self.cy = (WINDOW_H - 80) // 2
        self.r = CIRCLE_DIAMETER / 2.0

        # rotation state
        self.angle = 0.0
        self.rotating = True
        self.last_time = time.time()

        # status & labels
        self.status_text = self.canvas.create_text(12, 12, anchor="nw", fill="#ddd", font=("Segoe UI", 11),
                                                   text="Click canvas or press SPACE to stop/start. Percentages are for area to the right of the arm.")
        self.samples_text = self.canvas.create_text(WINDOW_W//2, (WINDOW_H - 80) - 18, anchor="center", fill="#bdbdbd",
                                                    font=("Segoe UI", 11), text="Samples: —")

        # curve-aligned labels (follow seam)
        self.yin_label_id = self.canvas.create_text(self.cx - int(self.r*0.5), self.cy, text="Yin: —%", fill="#fff",
                                                    font=("Segoe UI", 12, "bold"))
        self.yang_label_id = self.canvas.create_text(self.cx + int(self.r*0.5), self.cy, text="Yang: —%", fill="#000",
                                                     font=("Segoe UI", 12, "bold"))

        # explicit right-of-arm stats label
        self.right_label = tk.Label(self.top_frame, text="Right-of-arm: Yin —%   Yang —%", bg="#111111", fg="#fff", font=("Segoe UI", 10, "bold"))
        self.right_label.pack(side="right", padx=12)

        # state for computed values
        self.computed = False
        self.yin_pct = None
        self.yang_pct = None
        self.samples_used = 0

        # bindings
        root.bind("<space>", lambda e: self.toggle_rotation())
        root.bind("<Key-r>", lambda e: self.reset_rotation())
        root.bind("<Key-R>", lambda e: self.reset_rotation())
        root.bind("<Escape>", lambda e: self.quit())
        self.canvas.bind("<Button-1>", lambda e: self.toggle_rotation())

        # start animation
        self.running = True
        self.root.after(0, self.animation_step)

    def draw_yinyang(self):
        self.canvas.delete("yinyang")
        self.canvas.delete("pointer")

        # white base
        self.canvas.create_oval(self.cx - self.r, self.cy - self.r, self.cx + self.r, self.cy + self.r,
                                fill="#ffffff", outline="", tags="yinyang")

        # black semicircle (left half), rotated
        start_angle = 90 + self.angle
        self.canvas.create_arc(self.cx - self.r, self.cy - self.r, self.cx + self.r, self.cy + self.r,
                               start=start_angle, extent=180, fill="#000000", outline="", tags="yinyang")

        # inner small circles
        small_r = self.r / 2.0
        top_cx0, top_cy0 = self.cx, self.cy - self.r/2.0
        bottom_cx0, bottom_cy0 = self.cx, self.cy + self.r/2.0
        top_cx, top_cy = rotate_point(top_cx0, top_cy0, self.cx, self.cy, self.angle)
        bottom_cx, bottom_cy = rotate_point(bottom_cx0, bottom_cy0, self.cx, self.cy, self.angle)

        self.canvas.create_oval(top_cx - small_r, top_cy - small_r, top_cx + small_r, top_cy + small_r,
                                fill="#ffffff", outline="", tags="yinyang")
        self.canvas.create_oval(bottom_cx - small_r, bottom_cy - small_r, bottom_cx + small_r, bottom_cy + small_r,
                                fill="#000000", outline="", tags="yinyang")

        # dots
        dot_r = max(6, int(self.r / 12.0))
        self.canvas.create_oval(top_cx - dot_r, top_cy - dot_r, top_cx + dot_r, top_cy + dot_r,
                                fill="#000000", outline="", tags="yinyang")
        self.canvas.create_oval(bottom_cx - dot_r, bottom_cy - dot_r, bottom_cx + dot_r, bottom_cy + dot_r,
                                fill="#ffffff", outline="", tags="yinyang")

        # border
        self.canvas.create_oval(self.cx - self.r, self.cy - self.r, self.cx + self.r, self.cy + self.r,
                                outline="#000000", width=2, tags="yinyang")

        # stationary pointer (points up)
        arm_len = self.r * 0.9
        end_x = self.cx
        end_y = self.cy - arm_len
        self.canvas.create_line(self.cx + 2, self.cy + 2, end_x + 2, end_y + 2, fill="#111111", width=6, capstyle="round", tags="pointer")
        self.canvas.create_line(self.cx, self.cy, end_x, end_y, fill="#ff6666", width=4, capstyle="round", tags="pointer")
        self.canvas.create_oval(self.cx - 8, self.cy - 8, self.cx + 8, self.cy + 8, fill="#dddddd", outline="", tags="pointer")

        # update curve-aligned labels
        offset = self.r * 0.55
        yin_px0, yin_py0 = self.cx - offset, self.cy
        yang_px0, yang_py0 = self.cx + offset, self.cy
        yin_px, yin_py = rotate_point(yin_px0, yin_py0, self.cx, self.cy, self.angle)
        yang_px, yang_py = rotate_point(yang_px0, yang_py0, self.cx, self.cy, self.angle)

        def outward(px, py, amount):
            vx = px - self.cx
            vy = py - self.cy
            norm = math.hypot(vx, vy)
            if norm == 0:
                return px, py
            return px + (vx / norm) * amount, py + (vy / norm) * amount

        outward_amount = max(12, int(self.r * 0.06))
        yin_px_o, yin_py_o = outward(yin_px, yin_py, outward_amount)
        yang_px_o, yang_py_o = outward(yang_px, yang_py, outward_amount)

        if self.computed and self.yin_pct is not None:
            yin_text = f"Yin: {self.yin_pct:.2f}%"
            yang_text = f"Yang: {self.yang_pct:.2f}%"
        else:
            yin_text = "Yin: —%"
            yang_text = "Yang: —%"

        self.canvas.coords(self.yin_label_id, yin_px_o, yin_py_o)
        self.canvas.itemconfigure(self.yin_label_id, text=yin_text, fill="#ffffff")
        self.canvas.coords(self.yang_label_id, yang_px_o, yang_py_o)
        self.canvas.itemconfigure(self.yang_label_id, text=yang_text, fill="#000000")

    def animation_step(self):
        if not self.running:
            return
        now = time.time()
        dt = now - self.last_time
        self.last_time = now
        # use slider value for speed so user can adjust interactively
        speed = float(self.speed_var.get())
        if self.rotating:
            self.angle = (self.angle + speed * dt) % 360.0

        self.draw_yinyang()
        status = "Rotating" if self.rotating else "Stopped"
        self.canvas.itemconfigure(self.status_text, text=f"Status: {status}  Speed: {speed:.0f}°/s")

        if self.computed and self.yin_pct is not None:
            self.canvas.itemconfigure(self.samples_text, text=f"Samples: {self.samples_used}")
        else:
            self.canvas.itemconfigure(self.samples_text, text="Samples: —")

        self.root.after(int(1000 / FPS), self.animation_step)

    def toggle_rotation(self):
        self.rotating = not self.rotating
        if not self.rotating:
            self.canvas.itemconfigure(self.samples_text, text="Samples: running")
            Thread(target=self.compute_right_of_arm_background, daemon=True).start()
        else:
            self.computed = False
            self.yin_pct = self.yang_pct = None
            self.samples_used = 0
            self.right_label.config(text="Right-of-arm: Yin —%   Yang —%")

    def reset_rotation(self):
        self.angle = 0.0
        self.rotating = True
        self.computed = False
        self.yin_pct = self.yang_pct = None
        self.samples_used = 0
        self.right_label.config(text="Right-of-arm: Yin —%   Yang —%")

    def quit(self):
        self.running = False
        self.root.quit()

    def compute_now(self):
        self.canvas.itemconfigure(self.samples_text, text="Samples: running")
        Thread(target=self.compute_right_of_arm_background, daemon=True).start()

    def repeat_compute(self):
        self.canvas.itemconfigure(self.samples_text, text="Samples: running")
        Thread(target=self.compute_right_of_arm_background, daemon=True).start()

    def compute_right_of_arm_background(self):
        """
        Sample uniformly inside the main circle but only count points whose canvas x > cx
        (the half-plane to the right of the stationary arm). This yields Yin/Yang percentages
        restricted to the right-of-arm area.
        """
        samples = MONTE_CARLO_SAMPLES
        cx, cy, r = self.cx, self.cy, self.r
        angle = self.angle
        dark = 0
        light = 0
        counted = 0
        is_dark_fn = is_point_dark

        # We'll sample uniformly in the circle using polar sampling, but only count points with px > cx
        for i in range(samples):
            u = random.random()
            rad = math.sqrt(u) * r
            theta = random.random() * 2 * math.pi
            px = cx + rad * math.cos(theta)
            py = cy + rad * math.sin(theta)
            # restrict to right-of-arm half-plane (canvas coords)
            if px <= cx:
                continue
            counted += 1
            if is_dark_fn(px, py, cx, cy, r, angle):
                dark += 1
            else:
                light += 1
            if (i & 2047) == 0 and i > 0:
                # show progress: how many samples counted so far (not attempts)
                self.canvas.after(1, lambda c=counted: self.canvas.itemconfigure(self.samples_text, text=f"Samples counted: {c}"))

        # If no points were counted (shouldn't happen unless samples very small), avoid division by zero
        if counted == 0:
            yin_pct = yang_pct = 0.0
        else:
            yin_pct = (dark / counted) * 100.0
            yang_pct = (light / counted) * 100.0

        def finish():
            self.computed = True
            self.yin_pct = yin_pct
            self.yang_pct = yang_pct
            self.samples_used = counted
            self.right_label.config(text=f"Right-of-arm: Yin {yin_pct:.2f}%   Yang {yang_pct:.2f}%")
            self.canvas.itemconfigure(self.samples_text, text=f"Samples counted: {counted}")
            print(f"Right-of-arm computed (angle={angle:.2f}°): Yin={yin_pct:.4f}% Yang={yang_pct:.4f}% counted={counted}")
        self.canvas.after(10, finish)

# ---------- Run ----------
def main():
    root = tk.Tk()
    root.geometry(f"{WINDOW_W}x{WINDOW_H}")
    app = YinYangApp(root)
    try:
        root.mainloop()
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
