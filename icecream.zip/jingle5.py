#!/usr/bin/env python3
"""
Interactive Jingle Quote Generator with built-in TTS (no pip)
- macOS uses `say`
- Windows uses PowerShell System.Speech
- Linux tries `spd-say` then `espeak`
- Type 'q' to quit. Type 'r' at the seed prompt to repeat last generation.
- The last entered seed phrase is used as the default for the next seed prompt.
- Default for TTS prompts is now 'y'.
"""

import random
import sys
import subprocess
import shutil

# --- Expanded template bank (120 templates) ---
TEMPLATES = [
    "{seed} — feel the beat, feel the glow",
    "Wake up smiling with {seed}",
    "{seed}: small joy, big day",
    "Brighten your moment with {seed}",
    "Sing along: {seed} for you",
    "{seed} makes the morning sing",
    "Turn it up, turn it on, {seed} all day long",
    "{seed}, simple, sweet, and true",
    "Catch the vibe, catch the light, catch {seed}",
    "One taste of {seed}, and you're home",
    "{seed} — where happy starts",
    "Keep it close, keep it kind: {seed}",
    "Fresh feels, fresh starts, {seed}",
    "{seed} — your pocket of sunshine",
    "Love the little things: {seed}",
    "Step into joy with {seed}",
    "{seed} — bright, bold, and better",
    "Make it yours: {seed}",
    "A wink, a smile, a {seed}",
    "{seed} — because you deserve it",
    "Light the day with {seed}",
    "Breathe in calm, breathe out {seed}",
    "Find your groove with {seed}",
    "{seed} — tiny magic, big mood",
    "From dawn to dusk, it's {seed}",
    "Keep moving, keep smiling, keep {seed}",
    "{seed} — the friendly choice",
    "Savor the moment, savor {seed}",
    "Good vibes only: {seed}",
    "{seed} — made for moments",
    "Turn ordinary into {seed}",
    "A little spark called {seed}",
    "{seed} — feel-good in a bottle",
    "Whistle while you work with {seed}",
    "Bright ideas start with {seed}",
    "{seed} — your daily delight",
    "Pop the day with {seed}",
    "Shine on with {seed}",
    "{seed} — small wonder, big grin",
    "Keep it cozy, keep it {seed}",
    "Say hello to {seed}",
    "Make waves with {seed}",
    "{seed} — the sound of happy",
    "A hug in a line: {seed}",
    "Play it loud: {seed}",
    "Soft moments, strong memories: {seed}",
    "{seed} — the little lift you need",
    "Step up your day with {seed}",
    "Bright, breezy, {seed}",
    "Find your smile with {seed}",
    "{seed} — crafted for you",
    "Every day tastes like {seed}",
    "Spark joy with {seed}",
    "{seed} — the friendly flavor",
    "Keep it fresh, keep it {seed}",
    "A chorus of cheer: {seed}",
    "{seed} — where comfort meets cool",
    "Make it pop with {seed}",
    "From me to you: {seed}",
    "The secret's out: {seed}",
    "{seed} — small package, big heart",
    "Turn the dial to {seed}",
    "Feel the rhythm of {seed}",
    "{seed} — your pocket-sized party",
    "Brighten the beat with {seed}",
    "A little love called {seed}",
    "{seed} — the spark in your step",
    "Keep calm and choose {seed}",
    "Fresh starts begin with {seed}",
    "{seed} — the friendly spark",
    "Sing it soft: {seed}",
    "Bold taste, gentle touch: {seed}",
    "{seed} — made to make you smile",
    "Catch the moment, catch {seed}",
    "A brighter day with {seed}",
    "{seed} — the tune you hum",
    "Small wonder, big cheer: {seed}",
    "Turn the ordinary into {seed}",
    "{seed} — your daily sunshine",
    "Playful, peppy, perfect: {seed}",
    "A little pep called {seed}",
    "{seed} — the happy habit",
    "Light up life with {seed}",
    "Keep it real, keep it {seed}",
    "{seed} — the friendly fix",
    "Whisper sweet: {seed}",
    "Bold mornings start with {seed}",
    "{seed} — the smile starter",
    "Bright beats, bright treats: {seed}",
    "A pocket of joy: {seed}",
    "{seed} — the tune of today",
    "Make it memorable with {seed}",
    "Fresh, fun, and {seed}",
    "{seed} — your go-to glow",
    "Turn the page to {seed}",
    "A little pep in every {seed}",
    "{seed} — the cheerful choice",
    "Step into sunshine with {seed}",
    "Sing it proud: {seed}",
    "{seed} — tiny treat, huge grin",
    "Keep the good times rolling with {seed}",
    "A bright beat for your day: {seed}",
    "{seed} — the friendly note",
    "Make every moment {seed}",
    "A sprinkle of joy: {seed}",
    "{seed} — the sound of smiles",
    "Fresh flavor, fresh start: {seed}",
    "Turn up the charm with {seed}",
    "{seed} — your daily pick-me-up",
    "A little rhythm, a little {seed}",
    "{seed} — where warmth meets wonder",
    "Sing, dance, smile: {seed}",
    "{seed} — the tiny triumph",
    "Keep it light, keep it {seed}",
    "Brighten the beat of your day with {seed}",
]

# --- Generation functions ---
def template_generate(seed, count=10, templates=None):
    templates = templates or TEMPLATES
    out = []
    for _ in range(count):
        t = random.choice(templates)
        out.append(t.format(seed=seed))
    return out

# --- TTS helper using only system tools ---
def speak_text(text):
    """
    Speak text using built-in OS facilities. Returns True if spoken, False if not available.
    """
    platform = sys.platform
    # macOS
    if platform == "darwin":
        try:
            subprocess.run(["say", text], check=True)
            return True
        except Exception:
            return False

    # Windows
    if platform.startswith("win"):
        safe = text.replace("'", "''")
        ps_cmd = (
            "Add-Type -AssemblyName System.Speech;"
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            f"$s.Speak('{safe}');"
        )
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=True)
            return True
        except Exception:
            return False

    # Linux and other Unix-like: try spd-say then espeak
    if shutil.which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=True)
            return True
        except Exception:
            pass
    if shutil.which("espeak"):
        try:
            subprocess.run(["espeak", text], check=True)
            return True
        except Exception:
            pass

    # No TTS available
    return False

# --- I/O helpers ---
def prompt_input(prompt_text, default=None):
    try:
        val = input(prompt_text).strip()
    except (EOFError, KeyboardInterrupt):
        print("\nGoodbye.")
        sys.exit(0)
    if val.lower() == 'q':
        print("Goodbye.")
        sys.exit(0)
    if val == "" and default is not None:
        return default
    return val

def generate_and_print(seed, count):
    results = template_generate(seed, count)
    for i, line in enumerate(results, start=1):
        print(f"{i:03d}. {line}")
    return results

# --- Interactive loop (last seed becomes default) ---
def interactive_loop():
    print("Interactive Jingle Quote Generator with built-in TTS")
    print("Type 'q' at any prompt to quit. Type 'r' at the seed prompt to repeat last generation.")
    last = {"seed": None, "count": 10}

    while True:
        # Use last['seed'] as default if available, otherwise "Sunshine"
        default_seed = last["seed"] if last["seed"] else "Sunshine"
        seed_prompt = f"Enter seed phrase (or 'r' to repeat last, 'q' to quit) [default: {default_seed}]: "
        seed_in = prompt_input(seed_prompt, default=default_seed)

        if seed_in.lower() == 'r':
            if last["seed"] is None:
                print("No previous generation to repeat. Please enter a seed.")
                continue
            seed = last["seed"]
            count = last["count"]
            print(f"Repeating with seed='{seed}', count={count}")
            results = generate_and_print(seed, count)
        else:
            seed = seed_in

            count_prompt = f"How many jingles to generate (number) [default: {last['count'] or 10}]: "
            count_in = prompt_input(count_prompt, default=str(last['count'] or 10))
            try:
                count = int(count_in)
                if count < 1:
                    print("Count must be at least 1. Using 10.")
                    count = 10
            except ValueError:
                print("Invalid number; using default 10.")
                count = 10

            # Save last settings (so seed becomes default next time)
            last.update({"seed": seed, "count": count})
            results = generate_and_print(seed, count)

        # Ask whether to speak the results (default now 'y')
        tts_prompt = "Play jingles aloud with TTS? (y/n) [default: y]: "
        tts_in = prompt_input(tts_prompt, default="y").lower()
        if tts_in == 'y':
            print("Attempting to speak each jingle...")
            any_spoken = False
            for line in results:
                ok = speak_text(line)
                if ok:
                    any_spoken = True
                else:
                    print("TTS not available for this line; continuing.")
            if not any_spoken:
                print("No TTS engine available on your system or speaking failed.")

        # After generation, allow repeat or continue; seed default will be last['seed']
        post_prompt = "Press Enter to generate again, 'r' to repeat last, or 'q' to quit: "
        post = prompt_input(post_prompt, default="")
        if post.lower() == 'r':
            if last["seed"] is None:
                print("No previous generation to repeat.")
                continue
            print(f"Repeating with seed='{last['seed']}', count={last['count']}")
            results = generate_and_print(last['seed'], last['count'])
            # immediate TTS prompt again (default 'y')
            tts_in2 = prompt_input("Play jingles aloud with TTS? (y/n) [default: y]: ", default="y").lower()
            if tts_in2 == 'y':
                for line in results:
                    speak_text(line)
        # loop continues; next seed prompt will show last['seed'] as default

if __name__ == "__main__":
    interactive_loop()
