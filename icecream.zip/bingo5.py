import random
import platform
import subprocess
import shutil
import time
import sys
from math import ceil

BINGO_RANGES = {
    0: range(1, 16),    # B
    1: range(16, 31),   # I
    2: range(31, 46),   # N
    3: range(46, 61),   # G
    4: range(61, 76),   # O
}

def generate_card():
    card = [[None]*5 for _ in range(5)]
    for col in range(5):
        if col == 2:
            nums = random.sample(list(BINGO_RANGES[col]), 4)
            idx = 0
            for row in range(5):
                if row == 2:
                    card[row][col] = 'FREE'
                else:
                    card[row][col] = nums[idx]
                    idx += 1
        else:
            nums = random.sample(list(BINGO_RANGES[col]), 5)
            for row in range(5):
                card[row][col] = nums[row]
    return card

def make_mark_grid():
    marks = [[False]*5 for _ in range(5)]
    marks[2][2] = True
    return marks

def mark_number(card, marks, number):
    for r in range(5):
        for c in range(5):
            if card[r][c] == number:
                marks[r][c] = True

def is_winner(marks):
    for r in range(5):
        if all(marks[r][c] for c in range(5)):
            return True
    for c in range(5):
        if all(marks[r][c] for r in range(5)):
            return True
    if all(marks[i][i] for i in range(5)):
        return True
    if all(marks[i][4-i] for i in range(5)):
        return True
    return False

def _format_cell(val, marked):
    if val == 'FREE':
        s = "FREE"
    else:
        s = f"{val:2d}"
    return f"[{s}]" if marked else f" {s} "

def print_cards_grid(cards, marks_list, title_prefix="Card", per_row=3):
    """
    Print multiple bingo cards side-by-side.
    - cards: list of card matrices
    - marks_list: list of corresponding mark matrices
    - per_row: how many cards to show per horizontal row
    """
    if not cards:
        return

    total = len(cards)
    rows_of_groups = ceil(total / per_row)

    for group in range(rows_of_groups):
        start = group * per_row
        end = min(start + per_row, total)
        chunk_cards = cards[start:end]
        chunk_marks = marks_list[start:end]
        # Title line
        titles = [f"--- {title_prefix} #{i+start+1} ---" for i in range(len(chunk_cards))]
        # Normalize title widths
        max_title_len = max(len(t) for t in titles)
        titles = [t.ljust(max_title_len) for t in titles]
        print("   ".join(titles))

        # Column headers for each card
        header = " B  | I  | N  | G  | O "
        headers = [header.ljust(max_title_len) for _ in chunk_cards]
        print("   ".join(headers))
        print("   ".join(["-"*len(header)].ljust(max_title_len) if False else ["-"*len(header) for _ in chunk_cards]))

        # 5 rows of card content
        for r in range(5):
            line_parts = []
            for card, marks in zip(chunk_cards, chunk_marks):
                cells = [_format_cell(card[r][c], marks[r][c]) for c in range(5)]
                line = " | ".join(cells)
                # pad to title width so columns align
                line_parts.append(line.ljust(max_title_len))
            print("   ".join(line_parts))
        print()  # blank line between groups

def speak(text):
    system = platform.system()
    try:
        if system == "Darwin":
            if shutil.which("say"):
                subprocess.run(["say", str(text)], check=False)
                return True
        elif system == "Windows":
            safe_text = str(text).replace("'", "''")
            cmd = [
                "powershell",
                "-NoProfile",
                "-Command",
                f"Add-Type -AssemblyName System.Speech; "
                f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe_text}');"
            ]
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            return True
        else:
            if shutil.which("spd-say"):
                subprocess.run(["spd-say", str(text)], check=False)
                return True
            if shutil.which("espeak"):
                subprocess.run(["espeak", str(text)], check=False)
                return True
    except Exception:
        pass
    print(f"(TTS unavailable) {text}")
    return False

def play_game(player_cards_count=1, computer_cards_count=1, tts=True, verbose=True, auto_play=False, seed=None, per_row=3):
    if seed is not None:
        random.seed(seed)

    player_cards = [generate_card() for _ in range(player_cards_count)]
    player_marks = [make_mark_grid() for _ in range(player_cards_count)]
    computer_cards = [generate_card() for _ in range(computer_cards_count)]
    computer_marks = [make_mark_grid() for _ in range(computer_cards_count)]

    pool = list(range(1, 76))
    random.shuffle(pool)

    draws = []
    winner = None
    winner_info = None

    try:
        while pool and winner is None:
            number = pool.pop(0)
            draws.append(number)

            col_letter = None
            for col, rng in BINGO_RANGES.items():
                if number in rng:
                    col_letter = "BINGO"[col]
                    break
            speak_text = f"{col_letter} {number}" if col_letter else str(number)
            if tts:
                speak(speak_text)
                time.sleep(0.12)

            for i, card in enumerate(player_cards):
                mark_number(card, player_marks[i], number)
                if is_winner(player_marks[i]):
                    winner = "Player"
                    winner_info = ("Player", i, number)
                    if tts:
                        speak("Bingo")
                        speak("Player wins")
                    break
            if winner:
                break

            for i, card in enumerate(computer_cards):
                mark_number(card, computer_marks[i], number)
                if is_winner(computer_marks[i]):
                    winner = "Computer"
                    winner_info = ("Computer", i, number)
                    if tts:
                        speak("Bingo")
                        speak("Computer wins")
                    break

            if verbose and not winner:
                print(f"Drawn: {number} ({speak_text})\n")
                print("Your cards:")
                print_cards_grid(player_cards, player_marks, title_prefix="Your Card", per_row=per_row)
                print("Computer cards:")
                print_cards_grid(computer_cards, computer_marks, title_prefix="Computer Card", per_row=per_row)
                if not auto_play:
                    try:
                        input("Press Enter to draw next number...")
                    except EOFError:
                        pass

    except KeyboardInterrupt:
        print("\nGame interrupted by user.")
        return

    if winner:
        who, idx, last_num = winner_info
        print(f"\n{who} wins! Winning card index: {idx+1}. Winning number: {last_num}")
    else:
        print("\nNo winner. All numbers drawn.")

    print("\nFinal draws:", draws)
    print("\nYour cards:")
    print_cards_grid(player_cards, player_marks, title_prefix="Your Card", per_row=per_row)
    print("\nComputer cards:")
    print_cards_grid(computer_cards, computer_marks, title_prefix="Computer Card", per_row=per_row)

def ask_int(prompt, default=1):
    try:
        val = input(prompt).strip()
        if val == "":
            return default
        n = int(val)
        return max(1, n)
    except Exception:
        return default

if __name__ == "__main__":
    print("Welcome to Terminal Bingo with multi-card display")
    while True:
        p = ask_int("How many player cards would you like? [default 1] ", 1)
        c = ask_int("How many computer cards? [default 1] ", 1)
        tts_choice = input("Enable TTS? (Y/n) [default Y] ").strip().lower()
        tts_enabled = (tts_choice != "n")
        auto_choice = input("Auto-play (no Enter prompts)? (y/N) [default N] ").strip().lower()
        auto_play = (auto_choice == "y")
        seed_input = input("Optional seed for reproducible game (press Enter to skip): ").strip()
        seed_val = int(seed_input) if seed_input.isdigit() else None
        per_row_input = input("Cards per row when displaying (default 3): ").strip()
        per_row_val = int(per_row_input) if per_row_input.isdigit() and int(per_row_input) > 0 else 3

        print(f"Starting game with {p} player card(s) and {c} computer card(s). TTS={'on' if tts_enabled else 'off'}")
        play_game(player_cards_count=p, computer_cards_count=c, tts=tts_enabled, verbose=True, auto_play=auto_play, seed=seed_val, per_row=per_row_val)

        again = input("Play again? (Y/n) [default Y] ").strip().lower()
        if again == "n":
            print("Thanks for playing Bingo!")
            break
