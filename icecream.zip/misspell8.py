#!/usr/bin/env python3
"""
misspeller_tts_no_colons.py

- TTS is enabled by default (use --no-tts to start with it disabled).
- Interactive commands do NOT use colons. Use plain words:
    tts on|off|toggle|status
    speak
    quit / exit
"""
import argparse
import random
import re
import string
import shutil
import subprocess
import sys
from typing import List, Callable, Optional, Dict

# --- keyboard adjacency (letters only) ---
_KEYBOARD_ADJ: Dict[str, List[str]] = {
    'q': ['w', 'a'], 'w': ['q', 'e', 's'], 'e': ['w', 'r', 's', 'd'],
    'r': ['e', 't', 'd', 'f'], 't': ['r', 'y', 'f', 'g'], 'y': ['t', 'u', 'g', 'h'],
    'u': ['y', 'i', 'h', 'j'], 'i': ['u', 'o', 'j', 'k'], 'o': ['i', 'p', 'k', 'l'],
    'p': ['o', 'l'], 'a': ['q', 's', 'z'], 's': ['a', 'd', 'w', 'x', 'e'],
    'd': ['s', 'f', 'e', 'c', 'r', 'v'], 'f': ['d', 'g', 'r', 'v', 't'],
    'g': ['f', 'h', 't', 'b', 'y'], 'h': ['g', 'j', 'y', 'n', 'u'],
    'j': ['h', 'k', 'u', 'm', 'i'], 'k': ['j', 'l', 'i', 'o'],
    'l': ['k', 'p', 'o'], 'z': ['a', 'x'], 'x': ['z', 'c', 's'],
    'c': ['x', 'v', 'd'], 'v': ['c', 'b', 'f'], 'b': ['v', 'n', 'g'],
    'n': ['b', 'm', 'h'], 'm': ['n', 'j']
}

_PHONETIC_SWAPS = [
    ('ph', 'f'), ('ck', 'k'), ('ie', 'ei'), ('ght', 't'), ('th', 't'),
    ('s', 'z'), ('z', 's')
]

_WORD_RE = re.compile(r"\b[^\W\d_]+(?:['-][^\W\d_]+)?\b", flags=re.UNICODE)

class Misspeller:
    def __init__(
        self,
        intensity: float = 0.12,
        seed: Optional[int] = None,
        enable_deletion: bool = True,
        enable_insertion: bool = True,
        enable_substitution: bool = True,
        enable_transpose: bool = True,
        enable_duplication: bool = True,
        enable_phonetic: bool = True,
        force_all: bool = True
    ):
        self.intensity = max(0.0, min(1.0, intensity))
        self.rng = random.Random(seed)
        self.enable_deletion = enable_deletion
        self.enable_insertion = enable_insertion
        self.enable_substitution = enable_substitution
        self.enable_transpose = enable_transpose
        self.enable_duplication = enable_duplication
        self.enable_phonetic = enable_phonetic
        self.force_all = force_all

    def _random_choice(self, seq):
        return self.rng.choice(seq) if seq else None

    def _substitute_char(self, ch: str) -> str:
        lower = ch.lower()
        if lower in _KEYBOARD_ADJ and self.rng.random() < 0.9:
            sub = self._random_choice(_KEYBOARD_ADJ[lower])
        else:
            sub = chr(self.rng.randint(ord('a'), ord('z')))
        return sub.upper() if ch.isupper() else sub

    def _apply_original_casing(self, original: str, mutated: str) -> str:
        if not original:
            return mutated
        if original.isupper():
            return mutated.upper()
        if original.islower():
            return mutated.lower()
        if original[0].isupper() and original[1:].islower():
            return mutated.capitalize()
        out_chars = []
        for i, c in enumerate(mutated):
            if i < len(original) and original[i].isupper():
                out_chars.append(c.upper())
            else:
                out_chars.append(c.lower())
        return ''.join(out_chars)

    def _force_change_on_chars(self, chars: List[str], original: str) -> None:
        if not chars:
            return
        alpha_indices = [i for i, c in enumerate(chars) if c.isalpha()]
        if alpha_indices:
            i = self.rng.choice(alpha_indices)
            orig_char = original[i] if i < len(original) else chars[i]
            new = self._substitute_char(chars[i])
            new = new.upper() if orig_char.isupper() else new.lower()
            chars[i] = new
            return
        chars.insert(0, chars[0])

    def _apply_phonetic_swap(self, word: str) -> Optional[str]:
        if not self.enable_phonetic:
            return None
        if self.rng.random() >= self.intensity * 0.6:
            return None
        lw = word.lower()
        for a, b in _PHONETIC_SWAPS:
            idx = lw.find(a)
            if idx >= 0:
                before = word[:idx]
                after = word[idx + len(a):]
                repl = b
                if word[idx].isupper():
                    repl = repl.capitalize()
                return before + repl + after
        return None

    def _apply_to_word(self, word: str) -> str:
        original = word
        phon = self._apply_phonetic_swap(word)
        if phon is not None:
            return phon

        chars = list(word)
        i = 0
        changed = False

        while i < len(chars):
            ch = chars[i]
            p = self.intensity
            if i == 0 or i == len(chars) - 1:
                p *= 0.8
            if self.rng.random() < p:
                actions: List[Callable[[], int]] = []

                if self.enable_deletion:
                    def delete(i=i):
                        chars.pop(i)
                        return 0
                    actions.append(delete)

                if self.enable_insertion:
                    def insert(i=i):
                        chars.insert(i, self._random_choice(string.ascii_lowercase))
                        return 2
                    actions.append(insert)

                if self.enable_substitution and ch.isalpha():
                    def sub(i=i, ch=ch):
                        chars[i] = self._substitute_char(ch)
                        return 1
                    actions.append(sub)

                if self.enable_transpose and i + 1 < len(chars):
                    def trans(i=i, ch=ch):
                        chars[i], chars[i+1] = chars[i+1], ch
                        return 2
                    actions.append(trans)

                if self.enable_duplication and ch.isalpha():
                    def dup(i=i, ch=ch):
                        chars.insert(i, ch)
                        return 2
                    actions.append(dup)

                if actions:
                    step = self._random_choice(actions)()
                    changed = True
                    i += step
                    continue
            i += 1

        if self.rng.random() < self.intensity * 0.05:
            chars.append(self._random_choice([';', ',', '.', "'", '"', '?']))
            changed = True

        if self.force_all and not changed:
            self._force_change_on_chars(chars, original)

        return ''.join(chars)

    def misspell_text(self, text: str) -> str:
        def repl(match):
            word = match.group(0)
            mutated = self._apply_to_word(word)
            return self._apply_original_casing(word, mutated)
        return _WORD_RE.sub(repl, text)

# --- Cross-platform TTS helper (standard library only) ---
def _speak_mac(text: str) -> bool:
    cmd = shutil.which("say")
    if not cmd:
        return False
    try:
        subprocess.run([cmd, text], check=False)
        return True
    except Exception:
        return False

def _speak_windows(text: str) -> bool:
    ps = shutil.which("powershell") or shutil.which("pwsh")
    if not ps:
        return False
    safe = text.replace("'", "''")
    ps_cmd = (
        "Add-Type -AssemblyName System.Speech;"
        f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe}');"
    )
    try:
        subprocess.run([ps, "-NoProfile", "-Command", ps_cmd], check=False)
        return True
    except Exception:
        return False

def _speak_linux(text: str) -> bool:
    if shutil.which("espeak"):
        try:
            subprocess.run(["espeak", text], check=False)
            return True
        except Exception:
            pass
    if shutil.which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=False)
            return True
        except Exception:
            pass
    if shutil.which("festival"):
        try:
            p = subprocess.Popen(["festival", "--tts"], stdin=subprocess.PIPE)
            p.communicate(input=text.encode("utf-8"))
            return True
        except Exception:
            pass
    return False

def speak_text(text: str) -> bool:
    if sys.platform.startswith("darwin"):
        return _speak_mac(text)
    if sys.platform.startswith("win"):
        return _speak_windows(text)
    return _speak_linux(text)

# --- CLI and interactive loop with TTS toggle (no colons) ---
def parse_args():
    parser = argparse.ArgumentParser(description="Misspeller with runtime TTS toggle (no colons).")
    parser.add_argument("-t", "--text", help="Text to misspell. If omitted, program enters interactive mode.")
    parser.add_argument("-f", "--file", help="Path to a text file to read and misspell.")
    parser.add_argument("-i", "--intensity", type=float, default=0.12, help="Error intensity 0.0-1.0.")
    parser.add_argument("-s", "--seed", type=int, default=None, help="Random seed for reproducible output.")
    parser.add_argument("--no-phonetic", action="store_true", help="Disable phonetic swaps.")
    parser.add_argument("--no-insert", action="store_true", help="Disable insertions.")
    parser.add_argument("--no-delete", action="store_true", help="Disable deletions.")
    parser.add_argument("--no-sub", action="store_true", help="Disable substitutions.")
    parser.add_argument("--no-transpose", action="store_true", help="Disable transpositions.")
    parser.add_argument("--no-dup", action="store_true", help="Disable duplications.")
    parser.add_argument("--no-force", action="store_true", help="Do not force every word to change.")
    # Default TTS is ON; provide --no-tts to disable at startup
    parser.add_argument("--no-tts", action="store_true", help="Start with TTS disabled.")
    return parser.parse_args()

def process_and_print(m: Misspeller, text: str, tts_enabled: bool):
    out = m.misspell_text(text)
    print("Original:", text)
    print("Misspelled:", out)
    print()
    if tts_enabled:
        ok = speak_text(out)
        if not ok:
            print("TTS not available on this system (no supported backend found).")
    return out

def interactive_loop(m: Misspeller, tts_enabled: bool):
    last_output = ""
    print("Interactive misspeller. Commands: tts on|off|toggle|status, speak, quit")
    while True:
        try:
            s = input("> ")
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            break

        cmd = s.strip()
        if not cmd:
            continue

        parts = cmd.split()
        # Recognize single-word commands first
        if parts[0].lower() in ("quit", "exit"):
            print("Goodbye.")
            break
        if parts[0].lower() == "speak":
            if last_output:
                ok = speak_text(last_output)
                if not ok:
                    print("TTS not available on this system (no supported backend found).")
            else:
                print("No previous misspelled output to speak.")
            continue
        if parts[0].lower() == "tts":
            arg = parts[1].lower() if len(parts) > 1 else None
            if arg in ("on", "true", "1"):
                tts_enabled = True
                print("TTS enabled.")
            elif arg in ("off", "false", "0"):
                tts_enabled = False
                print("TTS disabled.")
            elif arg == "toggle":
                tts_enabled = not tts_enabled
                print("TTS enabled." if tts_enabled else "TTS disabled.")
            elif arg == "status" or arg is None:
                print("TTS is currently enabled." if tts_enabled else "TTS is currently disabled.")
            else:
                print("Usage: tts on|off|toggle|status")
            continue

        # Otherwise treat input as text to misspell
        last_output = process_and_print(m, s, tts_enabled)

def main():
    args = parse_args()
    m = Misspeller(
        intensity=args.intensity,
        seed=args.seed,
        enable_deletion=not args.no_delete,
        enable_insertion=not args.no_insert,
        enable_substitution=not args.no_sub,
        enable_transpose=not args.no_transpose,
        enable_duplication=not args.no_dup,
        enable_phonetic=not args.no_phonetic,
        force_all=not args.no_force
    )

    # Default TTS is ON unless user passed --no-tts
    tts_default = not bool(args.no_tts)

    if args.file:
        try:
            with open(args.file, "r", encoding="utf-8") as fh:
                content = fh.read()
            out = m.misspell_text(content)
            print(out)
            if tts_default:
                if not speak_text(out):
                    print("TTS not available on this system (no supported backend found).")
        except Exception as e:
            print("Error reading file:", e)
        return

    if args.text:
        process_and_print(m, args.text, tts_default)
        return

    interactive_loop(m, tts_default)

if __name__ == "__main__":
    main()
