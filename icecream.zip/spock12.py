#!/usr/bin/env python3
"""
spock_tts_quotes.py

Spock-style quote generator with optional TTS using only system utilities (no pip).
TTS is ON by default. The script remembers the last keyword entered and uses it
as the default keyword when none is provided (both in interactive and one-shot modes).

Behavior summary:
- Interactive: press Enter on an empty prompt to reuse the last keyword.
- One-shot: if --keyword is omitted, the script will use the last entered keyword (if available).
- The last keyword is persisted to ~/.spock_last_keyword.
- TTS is enabled by default; use --no-tts to disable.
- Use --count / -n to set number of responses (N).
- Use --per / -m to set number of quotes per response (M).
"""
from __future__ import annotations
import argparse
import difflib
import os
import platform
import random
import shutil
import subprocess
import sys
from typing import List, Optional, Tuple, Set

# Persisted file for last keyword
LAST_KEYWORD_PATH = os.path.expanduser("~/.spock_last_keyword")

# --- Very large built-in quotes collection (original, Spock-style aphorisms) ---
BUILTIN_QUOTES = [
    "Logic is the architecture of understanding",
    "Emotion informs but does not command",
    "Observation precedes conclusion",
    "Curiosity is the engine of discovery",
    "Duty requires clarity of purpose",
    "The unknown invites methodical inquiry",
    "Facts are indifferent to desire",
    "Reason tempers impulse",
    "Precision reduces ambiguity",
    "A hypothesis demands testing",
    "Silence often reveals more than speech",
    "Patterns emerge from careful attention",
    "Certainty is earned, not assumed",
    "Balance is achieved through restraint",
    "Knowledge grows from disciplined doubt",
    "Anomalies are opportunities for learning",
    "Efficiency is a form of respect",
    "Measure twice, conclude once",
    "Emotion can be a useful data point",
    "The path of inquiry is iterative",
    "Skepticism protects against error",
    "Context alters interpretation",
    "Predictability is a useful illusion",
    "Adaptation follows accurate assessment",
    "Clarity of thought simplifies action",
    "A calm mind sees options clearly",
    "Hypotheses must survive contradiction",
    "Precision in language prevents confusion",
    "Experience refines theoretical models",
    "The ship is an extension of purpose",
    "Leadership requires consistent logic",
    "Curiosity without discipline is chaos",
    "Evidence must guide our choices",
    "Observation without bias is difficult",
    "A question well posed contains half the answer",
    "Efficiency and compassion need not conflict",
    "Data without context is noise",
    "The universe tolerates no assumptions",
    "Reason is a tool, not a tyrant",
    "To explore is to accept uncertainty",
    "Simplicity often conceals complexity",
    "A mind trained in logic is a reliable instrument",
    "Errors are instructive when acknowledged",
    "The future yields to careful planning",
    "Emotion can motivate ethical action",
    "Patterns suggest hypotheses to test",
    "Silence can be a deliberate strategy",
    "Observation is the first duty of science",
    "A disciplined mind resists easy answers",
    "Curiosity must be paired with method",
    "The unknown is an invitation, not a threat",
    "Precision in thought begets precision in deed",
    "A leader must weigh consequence and principle",
    "Facts persist regardless of preference",
    "Reason clarifies, not diminishes, humanity",
    "A hypothesis that cannot be falsified is not useful",
    "The smallest detail can alter a conclusion",
    "Emotion can cloud, but also illuminate",
    "To learn is to revise one’s map of reality",
    "Order emerges from consistent practice",
    "The mission requires both courage and calculation",
    "Observation is a discipline of attention",
    "Skepticism must be tempered by openness",
    "A clear mind is the most reliable instrument",
    "Curiosity without humility invites error",
    "The value of a theory is its predictive power",
    "Duty is the alignment of action with principle",
    "Precision reduces the cost of error",
    "A question is the beginning of a journey",
    "Reason seeks coherence in complexity",
    "Compassion guided by reason is effective",
    "The unknown rewards patient investigation",
    "Evidence reshapes belief more than rhetoric",
    "A calm analysis reveals hidden options",
    "Logic is a map, not the territory",
    "Observation must be repeated to be trusted",
    "Hypotheses are temporary scaffolding",
    "The enterprise of science is communal",
    "A disciplined approach multiplies insight",
    "Emotion can be harnessed to ethical ends",
    "The integrity of data is paramount",
    "Curiosity sustained becomes wisdom",
    "A leader must be willing to revise course",
    "Certainty is provisional and subject to review",
    "The simplest explanation is often the most robust",
    "To observe is to accept responsibility",
    "Reason and empathy together produce sound decisions",
    "Anomalies are the seeds of progress",
    "A methodical mind is a steady compass",
    "Knowledge without application is incomplete",
    "The voyage of discovery requires both heart and mind",
    "Observation refines the boundaries of knowledge",
    "A hypothesis without evidence is merely speculation",
    "Precision in measurement reveals hidden structure",
    "Curiosity guided by ethics is constructive",
    "Reasoned debate clarifies competing models",
    "The cost of error is reduced by preparation",
    "A calm disposition improves judgment",
    "Patterns are the language of nature",
    "Inquiry demands both patience and rigor",
    "The mind that questions is the mind that grows",
    "A leader must balance logic with responsibility",
    "Evidence is the currency of credible claims",
    "To test is to invite correction",
    "Skepticism without openness is cynicism",
    "The unknown becomes known through persistent effort",
    "A clear hypothesis focuses investigation",
    "Reason organizes complexity into usable form",
    "Observation anchors theory to reality",
    "Curiosity without consequence is idle",
    "A disciplined method yields reliable results",
    "The integrity of observation is nonnegotiable",
    "A hypothesis must be exposed to falsification",
    "The enterprise of exploration is a moral endeavor",
    "Precision in thought reduces wasted effort",
    "A question well asked narrows the search",
    "Reason and compassion are complementary tools",
    "The map improves as more data is gathered",
    "A steady mind navigates uncertainty best",
    "Curiosity is the first step toward understanding",
    "Evidence must be weighed, not wished",
    "Observation is the bridge between idea and fact",
    "A hypothesis that predicts is valuable",
    "Reasoned action follows careful assessment",
    "The unknown is a resource for discovery",
    "A disciplined mind values reproducibility",
    "Compassion guided by logic is sustainable",
    "The mission benefits from collective insight",
    "A clear question simplifies complex problems",
    "Reason is the instrument of reliable choice",
    "Observation without repetition is tentative",
    "Hypotheses evolve as evidence accumulates",
    "The voyage of inquiry is never complete",
    "Logic clarifies the fog of emotion",
    "A calm observer sees the system, not the noise",
    "Curiosity without boundaries becomes distraction",
    "Precision in thought conserves energy in action",
    "A leader's duty is to the truth, not to comfort",
    "Patterns are the mind's way of remembering",
    "Doubt is the engine of refinement",
    "A hypothesis is a promise to test",
    "The cost of certainty is often ignorance",
    "Observation is the currency of science",
    "Reason is the lens through which facts cohere",
    "Compassion without reason can be misapplied",
    "The unknown is a field, not a wall",
    "Method turns curiosity into knowledge",
    "A clear plan reduces the chance of error",
    "Skepticism is a shield, not a fortress",
    "Evidence is the anchor of credible belief",
    "A calm mind is less likely to be deceived",
    "Precision in language prevents missteps",
    "The smallest inconsistency can reveal a falsehood",
    "To lead is to accept responsibility for outcomes",
    "Curiosity must be disciplined by ethics",
    "Reason seeks patterns that survive testing",
    "Observation without patience yields illusion",
    "A hypothesis that predicts is a useful tool",
    "The map is improved by each new measurement",
    "Errors are data for the next iteration",
    "A steady method outperforms brilliant improvisation",
    "Compassion guided by evidence scales well",
    "The mission requires both courage and calculation",
    "A question can be a compass",
    "Reason is the architecture of reliable choice",
    "Observation is the first step toward correction",
    "Certainty without evidence is hubris",
    "Curiosity sustained becomes expertise",
    "A disciplined mind tolerates ambiguity",
    "The simplest model that fits is often the most useful",
    "To observe is to accept the possibility of being wrong",
    "Reason is a practice, not a possession",
    "Patterns invite hypotheses, not conclusions",
    "A leader must be willing to change course",
    "Evidence reshapes conviction more than rhetoric",
    "The unknown is an opportunity for improvement",
    "Precision in measurement reveals subtle truths",
    "A calm analysis reduces wasted effort",
    "Skepticism without curiosity is sterile",
    "The value of a theory is its ability to predict",
    "Observation must be repeatable to be trusted",
    "A hypothesis that cannot be tested is a belief",
    "Reason and empathy together produce wise action",
    "The mind that questions is the mind that learns",
    "A methodical approach multiplies insight",
    "Curiosity without humility invites error",
    "The integrity of data is the foundation of trust",
    "A leader's logic must be matched by moral clarity",
    "Patterns are the grammar of nature",
    "To explore is to accept provisional answers",
    "Reason organizes, observation verifies",
    "A calm mind sees the long arc of consequence",
    "Precision in thought reduces the cost of failure",
    "Skepticism is the discipline of inquiry",
    "Evidence is the bridge between claim and knowledge",
    "A hypothesis is a tool for discovery, not a dogma",
    "Curiosity guided by method yields progress",
    "The unknown is a resource, not a threat",
    "Observation is the discipline of humility",
    "Reason is the steady hand in crisis",
    "A leader must weigh principle and practicality",
    "Patterns suggest experiments to perform",
    "A clear question narrows the field of search",
    "Compassion without reason can be misdirected",
    "The mission benefits from collective scrutiny",
    "A disciplined mind resists the lure of certainty",
    "Evidence must be interpreted with care",
    "To test is to invite correction and improvement",
    "Skepticism without openness is cynicism",
    "The simplest explanation that fits should be preferred",
    "Observation anchors imagination to reality",
    "A hypothesis that survives testing gains utility",
    "Reason is the tool that converts data into decisions",
    "Curiosity is the spark; method is the fuel",
    "A calm leader clarifies options for others",
    "Precision in language prevents wasted effort",
    "Patterns are the mind's shorthand for complexity",
    "Inquiry requires both patience and rigor",
    "The unknown becomes known through persistent effort",
    "A clear hypothesis focuses scarce resources",
    "Reason organizes complexity into actionable form",
    "Observation without repetition is provisional",
    "A disciplined method yields reproducible insight",
    "Compassion guided by evidence scales across contexts",
    "The voyage of discovery rewards the persistent",
    "A leader must be willing to revise assumptions",
    "Evidence is the most persuasive form of argument",
    "To observe is to accept responsibility for interpretation",
    "Skepticism protects against easy answers",
    "Curiosity without consequence is idle speculation",
    "Precision in thought is a kindness to future selves",
    "A hypothesis that predicts is a useful map",
    "Reason and empathy together produce sustainable policy",
    "Observation is the bridge from idea to fact",
    "A calm analysis reveals options hidden by haste",
    "Patterns are invitations to test",
    "Inquiry is the practice of disciplined wonder",
    "The unknown is a field of possible improvements",
    "A clear question reduces wasted exploration",
    "Reason is the instrument of reliable choice",
    "Observation must be recorded to be useful",
    "A hypothesis must be exposed to falsification to be valuable",
    "Curiosity sustained becomes a craft",
    "A leader's duty is to the mission and to truth",
    "Evidence reshapes belief more effectively than rhetoric",
    "Skepticism without curiosity is a closed door",
    "Precision in measurement reveals the contours of reality",
    "The simplest model that explains is often the most robust",
    "To observe is to accept the provisional nature of knowledge",
    "Reason is a practice that improves with use",
    "Patterns are the language through which nature speaks",
    "A disciplined mind tolerates uncertainty while seeking clarity",
    "Compassion guided by reason is the most effective form of care",
    "The voyage of inquiry is never complete, only advanced by each step",
    "A hypothesis that predicts well is a map worth following",
    "Observation anchors theory to the world",
    "Curiosity without method is an unfocused flame",
    "A calm leader listens before deciding",
    "Precision in thought reduces the chance of regret",
    "Skepticism is the engine of refinement",
    "Evidence is the foundation upon which decisions should rest",
    "A question well asked halves the work of answering",
    "Reason organizes complexity into manageable parts",
    "Observation without repetition is tentative at best",
    "A disciplined approach multiplies the value of effort",
    "Compassion and reason together produce humane outcomes",
    "The unknown invites careful, persistent exploration",
    "A clear hypothesis directs scarce resources efficiently",
    "Patterns suggest where to look next",
    "Curiosity is the seed of every discovery",
    "A leader must be willing to revise assumptions in light of evidence",
    "Precision in language prevents unnecessary conflict",
    "Skepticism without openness is merely contrarianism",
    "Observation is the first duty of any investigator",
    "Reason is the tool that converts uncertainty into action",
    "A hypothesis that survives testing becomes a reliable guide",
    "Compassion guided by evidence is effective and sustainable",
    "The voyage of inquiry rewards those who persist with method",
    "A calm mind is the most reliable instrument in crisis",
    "Patterns are the mind's way of compressing experience",
    "Inquiry requires both courage and patience",
    "The unknown is a resource for those willing to study it",
    "A clear question narrows the infinite to the tractable",
    "Reason and empathy together produce balanced decisions",
    "Observation must be recorded and shared to be useful",
    "A disciplined method reduces the cost of error",
    "Curiosity sustained becomes expertise and then wisdom",
    "A leader's logic must be matched by moral clarity",
    "Evidence is the most persuasive form of persuasion",
    "Skepticism protects against the seduction of certainty",
    "Precision in thought is a gift to collaborators",
    "The simplest explanation that fits is a useful starting point",
    "To observe is to accept the provisional nature of knowledge",
    "Reason is a practice that improves with use and reflection",
    "Patterns are the language through which nature communicates",
    "A disciplined mind tolerates uncertainty while seeking clarity",
    "Compassion guided by reason is the most effective form of care",
    "The voyage of inquiry is never complete, only advanced by each step",
    "A hypothesis that predicts is a map worth following",
    "Observation anchors imagination to the facts",
    "Curiosity without humility invites error",
    "A calm leader clarifies the problem before prescribing solutions",
    "Precision in language prevents wasted effort and misunderstanding",
    "Skepticism without curiosity is a closed mind",
    "Evidence reshapes belief more reliably than rhetoric",
    "A question well asked focuses the search for truth",
    "Reason organizes complexity into actionable insight",
    "Observation without repetition is provisional knowledge",
    "A disciplined approach yields cumulative advantage",
    "Compassion and reason together produce sustainable policy",
    "The unknown rewards those who study it with patience",
    "A clear hypothesis concentrates effort where it matters most",
    "Patterns are the mind's shorthand for recurring truth",
    "Curiosity is the seed of every discovery",
    "A leader must be willing to revise assumptions in light of evidence",
    "Precision in thought reduces the chance of error",
    "Skepticism is the discipline that keeps inquiry honest",
    "Observation is the bridge between idea and reality",
    "Reason is the instrument that converts data into decisions",
    "A hypothesis that survives testing becomes a reliable tool",
    "Compassion guided by evidence is effective and sustainable",
    "The voyage of inquiry is advanced by disciplined curiosity",
    "A calm mind sees the long-term consequences of action",
    "Patterns suggest experiments that reveal deeper structure",
    "Inquiry requires both rigor and humility",
    "The unknown is an opportunity for those who prepare",
    "A clear question reduces the noise of irrelevant possibilities",
    "Reason and empathy together produce humane outcomes",
    "Observation must be repeatable to be trusted",
    "A disciplined method multiplies the value of effort",
    "Curiosity sustained becomes expertise and then wisdom",
    "A leader's duty is to truth, mission, and those they serve",
    "Evidence is the most persuasive form of argument",
    "Skepticism without openness is cynicism; openness without skepticism is gullibility",
    "Precision in thought is a kindness to future collaborators",
    "The simplest explanation that fits is a useful starting point",
    "To observe is to accept the provisional nature of knowledge",
    "Reason is a practice that improves with use and reflection",
    "Patterns are the language through which nature speaks",
    "A disciplined mind tolerates uncertainty while seeking clarity",
    "Compassion guided by reason is the most effective form of care",
    "The voyage of inquiry is never complete, only advanced by each step",
]

# --- Persistence helpers for last keyword ---
def load_last_keyword(path: str = LAST_KEYWORD_PATH) -> Optional[str]:
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as fh:
                val = fh.read().strip()
                return val if val else None
    except Exception:
        pass
    return None

def save_last_keyword(keyword: str, path: str = LAST_KEYWORD_PATH) -> None:
    try:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(keyword or "")
    except Exception:
        pass

# --- Quote loading and matching ---
def load_quotes_from_file(path: str) -> List[str]:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return [line.strip() for line in fh if line.strip()]
    except Exception as e:
        print(f"Error reading file {path}: {e}", file=sys.stderr)
        return []

def find_matches(quotes: List[str], keyword: str, rng: random.Random,
                 exclude: Optional[Set[str]] = None, max_results: int = 2) -> List[Tuple[str, float]]:
    exclude = exclude or set()
    pool = [q for q in quotes if q not in exclude]
    if not pool:
        return []

    kw = (keyword or "").lower().strip()
    if not kw:
        sample = rng.sample(pool, min(max_results, len(pool)))
        return [(q, 0.0) for q in sample]

    exact = []
    others = []
    for q in pool:
        ql = q.lower()
        if kw in ql:
            exact.append((q, 1.0))
        else:
            score = difflib.SequenceMatcher(None, kw, ql).ratio()
            others.append((q, score))

    if len(exact) >= max_results:
        return exact[:max_results]

    others.sort(key=lambda x: x[1], reverse=True)
    result = exact + others[: max_results - len(exact)]
    if not result:
        sample = rng.sample(pool, min(max_results, len(pool)))
        return [(q, 0.0) for q in sample]
    return result

def pick_k_nonrepeating(quotes: List[str], keyword: Optional[str], rng: random.Random,
                        used: Set[str], k: int) -> List[str]:
    matches = find_matches(quotes, keyword or "", rng, exclude=used, max_results=k)
    picks = [q for q, _ in matches]
    remaining = [q for q in quotes if q not in used and q not in picks]
    while len(picks) < k and remaining:
        picks.append(rng.choice(remaining))
        remaining = [q for q in quotes if q not in used and q not in picks]
    return picks

# --- TTS utilities (no pip) ---
def _run_command(cmd: List[str]) -> bool:
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False

def speak_with_macos(text: str) -> bool:
    if shutil.which("say"):
        return _run_command(["say", text])
    return False

def speak_with_powershell(text: str) -> bool:
    ps = shutil.which("powershell") or shutil.which("pwsh")
    if not ps:
        return False
    safe_text = text.replace("'", "''")
    cmd = [
        ps,
        "-NoProfile",
        "-Command",
        (
            "Add-Type -AssemblyName System.Speech;"
            f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            f"$s.Speak('{safe_text}');"
        ),
    ]
    return _run_command(cmd)

def speak_with_espeak(text: str) -> bool:
    if shutil.which("espeak"):
        return _run_command(["espeak", text])
    return False

def speak_with_spd_say(text: str) -> bool:
    if shutil.which("spd-say"):
        return _run_command(["spd-say", text])
    return False

def speak(text: str) -> bool:
    if not text.strip():
        return False
    system = platform.system()
    if system == "Darwin" and speak_with_macos(text):
        return True
    if system == "Windows" and speak_with_powershell(text):
        return True
    if speak_with_espeak(text):
        return True
    if speak_with_spd_say(text):
        return True
    if speak_with_powershell(text):
        return True
    return False

# --- Generate multiple non-repeating responses ---
def generate_responses(quotes: List[str], keyword: str, rng: random.Random, n: int, per: int) -> List[List[str]]:
    responses: List[List[str]] = []
    used: Set[str] = set()
    for _ in range(n):
        remaining_pool = [q for q in quotes if q not in used]
        if not remaining_pool:
            break
        picks = pick_k_nonrepeating(quotes, keyword, rng, used, per)
        if not picks:
            break
        for q in picks:
            used.add(q)
        responses.append(picks)
    return responses

# --- Interactive mode with TTS toggle and response counter ---
def interactive_mode(quotes: List[str], seed: Optional[int], tts_enabled: bool, initial_n: int, initial_per: int):
    rng = random.Random(seed) if seed is not None else random.Random()
    response_count = 0
    quote_spoken_count = 0
    n = max(1, int(initial_n))
    per = max(1, int(initial_per))

    # Load last keyword if available
    last_keyword = load_last_keyword()

    print("Spock quote generator (interactive). Type a keyword or 'quit' to exit.")
    print("Commands: tts on, tts off, tts toggle, tts count, status, count N, per M, quit")
    if last_keyword:
        print(f"Press Enter to reuse last keyword: '{last_keyword}'")
    else:
        print("Enter a keyword to begin.")

    while True:
        try:
            s = input("keyword> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        # If user pressed Enter with empty input, reuse last_keyword if available
        if not s:
            if last_keyword:
                keyword = last_keyword
                print(f"(Reusing last keyword: '{keyword}')")
            else:
                print("No previous keyword available. Please enter a keyword.")
                continue
        else:
            cmd = s.lower().strip()
            # Handle interactive commands
            if cmd in ("quit", "exit"):
                print("Goodbye.")
                break
            if cmd == "tts on":
                tts_enabled = True
                print("TTS enabled.")
                continue
            if cmd == "tts off":
                tts_enabled = False
                print("TTS disabled.")
                continue
            if cmd == "tts toggle":
                tts_enabled = not tts_enabled
                print(f"TTS {'enabled' if tts_enabled else 'disabled'}.")
                continue
            if cmd == "tts count":
                print(f"Quotes spoken so far: {quote_spoken_count}")
                continue
            if cmd == "status":
                print(f"TTS is {'ON' if tts_enabled else 'OFF'}. Responses generated: {response_count}. Quotes spoken: {quote_spoken_count}. N={n}, M={per}")
                continue
            if cmd.startswith("count "):
                parts = cmd.split()
                if len(parts) == 2 and parts[1].isdigit():
                    n = max(1, int(parts[1]))
                    print(f"Set responses per request to N={n}")
                else:
                    print("Usage: count N   (where N is a positive integer)")
                continue
            if cmd.startswith("per "):
                parts = cmd.split()
                if len(parts) == 2 and parts[1].isdigit():
                    per = max(1, int(parts[1]))
                    print(f"Set quotes per response to M={per}")
                else:
                    print("Usage: per M   (where M is a positive integer)")
                continue

            # Not a command -> treat as keyword
            keyword = s
            last_keyword = keyword
            save_last_keyword(keyword)

        # Generate up to n non-repeating responses and show them all
        responses = generate_responses(quotes, keyword, rng, n, per)
        if not responses:
            print("No quotes available.")
            continue

        response_count += len(responses)

        for idx, picks in enumerate(responses, start=1):
            print(f"\nResponse {idx}:")
            for i, q in enumerate(picks, 1):
                print(f"  {i}. {q}")

        if tts_enabled:
            for picks in responses:
                for q in picks:
                    if speak(q):
                        quote_spoken_count += 1
                    else:
                        print("(TTS unavailable; install 'say', 'espeak', or 'spd-say', or ensure PowerShell is present.)")
                        tts_enabled = False
                        break
                if not tts_enabled:
                    break
        print()

# --- One-shot mode (uses last keyword if --keyword not provided) ---
def one_shot_mode(quotes: List[str], keyword: Optional[str], seed: Optional[int], tts: bool, count_n: int, per: int):
    rng = random.Random(seed) if seed is not None else random.Random()
    n = max(1, int(count_n))
    per = max(1, int(per))

    # If no keyword provided, try to load last keyword
    if not keyword:
        keyword = load_last_keyword()
        if keyword:
            print(f"(Using last keyword: '{keyword}')")
        else:
            print("No keyword provided and no last keyword found. Provide --keyword or run interactive mode.")
            return
    else:
        # persist provided keyword as the new last keyword
        save_last_keyword(keyword)

    responses = generate_responses(quotes, keyword or "", rng, n, per)
    if not responses:
        print("No quotes found.")
        return

    response_count = len(responses)
    quote_spoken = 0

    for idx, picks in enumerate(responses, start=1):
        print(f"\nResponse {idx}:")
        for i, q in enumerate(picks, 1):
            print(f"  {i}. {q}")

    if tts:
        for picks in responses:
            for q in picks:
                if speak(q):
                    quote_spoken += 1
                else:
                    print("(TTS unavailable; install 'say', 'espeak', or 'spd-say', or ensure PowerShell is present.)")
                    tts = False
                    break
            if not tts:
                break

    print(f"\nResponses generated: {response_count}")
    if args.tts:
        print(f"Quotes spoken: {quote_spoken}")

def main():
    global args
    p = argparse.ArgumentParser(description="Spock quote generator with optional TTS and remembered keyword.")
    p.add_argument("--file", "-f", help="Path to quotes file (one quote per line).")
    p.add_argument("--keyword", "-k", help="Keyword to filter quotes (optional). If omitted, the last entered keyword will be used when available.")
    p.add_argument("--seed", "-s", type=int, help="Optional random seed for reproducible results.")
    p.add_argument("--interactive", "-i", action="store_true", help="Force interactive mode.")
    # TTS on by default; provide --no-tts to disable
    p.add_argument("--tts", dest="tts", action="store_true", help="Enable TTS (default).")
    p.add_argument("--no-tts", dest="tts", action="store_false", help="Disable TTS.")
    p.set_defaults(tts=True)
    p.add_argument("--count", "-n", type=int, default=1, help="Number of responses to generate per request (default 1).")
    p.add_argument("--per", "-m", type=int, default=2, help="Number of quotes per response (default 2).")
    args = p.parse_args()

    quotes = BUILTIN_QUOTES.copy()
    if args.file:
        file_quotes = load_quotes_from_file(args.file)
        if file_quotes:
            quotes = file_quotes

    if not quotes:
        print("No quotes available. Provide a quotes file or edit BUILTIN_QUOTES in the script.", file=sys.stderr)
        sys.exit(1)

    # Interactive mode: pressing Enter reuses last keyword; TTS on by default
    if args.interactive or (not args.keyword and sys.stdin.isatty()):
        interactive_mode(quotes, args.seed, tts_enabled=bool(args.tts), initial_n=args.count, initial_per=args.per)
        return

    # One-shot mode: use provided keyword or last keyword
    one_shot_mode(quotes, args.keyword, args.seed, args.tts, args.count, args.per)

if __name__ == "__main__":
    main()
