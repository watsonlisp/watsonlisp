import tkinter as tk
import os

def execute_program():
    selected_program = var.get()
    if selected_program == "Program 1":
        os.system("c:/python/jingle5.py")
    elif selected_program == "Program 2":
        os.system("c:/python/chemistry4.py")
    elif selected_program == "Program 3":
        os.system("c:/python/misspell8.py")
    elif selected_program == "Program 4":
        os.system("c:/python/spock12.py")
    elif selected_program == "Program 5":
        os.system("c:/python/yinyang14.py")
    elif selected_program == "Program 6":
        os.system("c:/python/bingo5.py")


# Create the main window
root = tk.Tk()
root.title("Program Selector")

# Create a Tkinter variable
var = tk.StringVar(value="Program 1")

# Create radio buttons
radio1 = tk.Radiobutton(root, text="jingle", variable=var, value="Program 1")
radio2 = tk.Radiobutton(root, text="chemistry", variable=var, value="Program 2")
radio3 = tk.Radiobutton(root, text="misspell", variable=var, value="Program 3")
radio4 = tk.Radiobutton(root, text="spock", variable=var, value="Program 4")
radio5 = tk.Radiobutton(root, text="yinyang", variable=var, value="Program 5")
radio6 = tk.Radiobutton(root, text="bingo__________________________", variable=var, value="Program 6")
# Pack the radio buttons

radio1.pack(anchor=tk.W)
radio2.pack(anchor=tk.W)
radio3.pack(anchor=tk.W)
radio4.pack(anchor=tk.W)
radio5.pack(anchor=tk.W)
radio6.pack(anchor=tk.W)

# Create a button to execute the selected program
execute_button = tk.Button(root, text="Execute", command=execute_program)
execute_button.pack()

# Run the main loop
root.mainloop()
