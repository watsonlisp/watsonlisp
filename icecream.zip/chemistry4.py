import platform
import shutil
import subprocess
import random
import time

CHEM_PREFIXES = [
    "mono", "di", "tri", "tetra", "penta", "hexa",
    "hepta", "octa", "nona", "deca", "iso", "sec", "tert",
    "cyclo", "n", "neo", "benzyl", "methyl", "ethyl", "propyl"
]

CHEM_SUFFIXES = [
    "ane", "ene", "yne", "ol", "al", "one", "oic acid",
    "amine", "amide", "ester", "ether", "ide", "oxide",
    "thiol", "nitrile", "sulfate", "phosphate"
]

def add_chem_affixes(text,
                     prefixes=None,
                     suffixes=None,
                     hyphenate_prefix=True,
                     hyphenate_suffix=True,
                     capitalize=False):
    if prefixes is None:
        prefixes = CHEM_PREFIXES
    if suffixes is None:
        suffixes = CHEM_SUFFIXES

    prefix = random.choice(prefixes)
    suffix = random.choice(suffixes)

    pre_sep = "-" if hyphenate_prefix and not prefix.endswith("-") else ""
    suf_sep = "-" if hyphenate_suffix and not suffix.startswith(" ") and not suffix.startswith("-") else ""
    if " " in suffix:
        suf_sep = "-" if hyphenate_suffix else " "

    core = text.strip()
    result = f"{prefix}{pre_sep}{core}{suf_sep}{suffix}"
    if capitalize:
        result = result.capitalize()
    return result

# -------------------------
# Cross-platform TTS
# -------------------------
def _run_cmd(cmd):
    try:
        subprocess.run(cmd, check=True)
        return True
    except Exception:
        return False

def speak(text):
    """
    Speak text using system TTS. Returns True if spoken, False otherwise.
    """
    system = platform.system()
    # macOS: 'say'
    if system == "Darwin":
        if shutil.which("say"):
            return _run_cmd(["say", text])
        return False

    # Windows: use PowerShell + System.Speech
    if system == "Windows":
        safe_text = text.replace("'", "''")
        ps_cmd = (
            "Add-Type -AssemblyName System.Speech;"
            f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            f"$s.Speak('{safe_text}');"
        )
        return _run_cmd(["powershell", "-NoProfile", "-Command", ps_cmd])

    # Linux / other: try espeak or spd-say
    if shutil.which("espeak"):
        return _run_cmd(["espeak", text])
    if shutil.which("spd-say"):
        return _run_cmd(["spd-say", text])
    return False

# -------------------------
# Speak all variants helper
# -------------------------
def speak_variants(variants, pause_seconds=0.6):
    """
    Speak each string in variants in order.
    - pause_seconds: seconds to wait between variants.
    Returns True if at least one variant was spoken, False if TTS unavailable.
    """
    any_spoken = False
    for v in variants:
        spoken = speak(v)
        if spoken:
            any_spoken = True
            time.sleep(pause_seconds)
        else:
            # If a backend fails for one variant, assume TTS not available and stop trying.
            return any_spoken
    return any_spoken

# -------------------------
# Interactive loop with TTS for all variants
# -------------------------
def interactive_loop():
    print("Chemistry Affix Adder with TTS — type 'quit' or 'exit' to stop.")
    print("Commands: 'repeat' to regenerate variants; 'count N' to set number of variants; 'tts on/off' to toggle speech.\n")

    variants_count = 5
    last_input = None
    tts_enabled = True
    pause_between = 0.6  # seconds between spoken variants

    while True:
        if not last_input:
            user_input = input("Enter base name: ").strip()
            if not user_input:
                print("Please enter some text.")
                continue
            if user_input.lower() in ("quit", "exit"):
                print("Goodbye!")
                break
            if user_input.lower().startswith("count "):
                try:
                    variants_count = max(1, int(user_input.split()[1]))
                    print(f"Variants per input set to {variants_count}.")
                except Exception:
                    print("Invalid count. Use: count N")
                continue
            if user_input.lower() in ("tts off", "tts off\n"):
                tts_enabled = False
                print("TTS disabled.")
                continue
            if user_input.lower() in ("tts on", "tts on\n"):
                tts_enabled = True
                print("TTS enabled.")
                continue
            last_input = user_input

        variants = [add_chem_affixes(last_input, capitalize=True) for _ in range(variants_count)]
        print("\nVariants:")
        for v in variants:
            print(" -", v)
        print()

        if tts_enabled:
            spoken_any = speak_variants(variants, pause_seconds=pause_between)
            if not spoken_any:
                print("TTS not available on this system or required command not found.")
                tts_enabled = False

        action = input("Press Enter for a new base name, type 'repeat' to regenerate, 'count N' to change number, 'tts on/off', or 'quit' to exit: ").strip()
        if action.lower() in ("quit", "exit"):
            print("Goodbye!")
            break
        if action.lower().startswith("count "):
            try:
                variants_count = max(1, int(action.split()[1]))
                print(f"Variants per input set to {variants_count}.")
                last_input = None
                continue
            except Exception:
                print("Invalid count. Use: count N")
                last_input = None
                continue
        if action.lower() == "repeat":
            continue
        if action.lower() == "tts off":
            tts_enabled = False
            last_input = None
            continue
        if action.lower() == "tts on":
            tts_enabled = True
            last_input = None
            continue
        last_input = None

if __name__ == "__main__":
    interactive_loop()
