#!/usr/bin/env python3
"""
Glitch Host — Multi Image Animator (single TTS call, fractional FPS and speech-speed).
Tiles synchronized to speech: each spoken letter will display its mapped tile (if available)
and the mouth openness will follow per-letter timing. No Pillow required.
Added: Paste button to insert clipboard contents into the input box.
Added: Pause/Resume button for speech (best-effort TTS process suspend/resume).
Save as glitch_talker_multiframe.py and run: python3 glitch_talker_multiframe.py
"""

import tkinter as tk
from tkinter import filedialog, messagebox
import platform, subprocess, shutil, threading, time, random, os, signal, ctypes

PLATFORM = platform.system()

def speak_process(text, speed=1.0):
    text = str(text).strip()
    if not text:
        return None
    try:
        speed = float(speed)
    except Exception:
        speed = 1.0
    speed = max(0.1, min(4.0, speed))

    if PLATFORM == "Darwin":
        base_wpm = 175.0
        wpm = int(max(20, base_wpm * speed))
        try:
            p = subprocess.Popen(["say", "-r", str(wpm), text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return p
        except Exception:
            return None

    if PLATFORM == "Windows":
        rate_val = int(round((speed - 1.0) * 7.5))
        rate_val = max(-10, min(10, rate_val))
        safe = text.replace('"', '""')
        ps_script = (
            'Add-Type -AssemblyName System.Speech;'
            f'$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;'
            f'$s.Rate = {rate_val};'
            f'$s.Speak("{safe}")'
        )
        for pw in ("pwsh", "powershell"):
            try:
                p = subprocess.Popen([pw, "-NoProfile", "-Command", ps_script], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return p
            except Exception:
                continue
        return None

    if shutil.which("espeak"):
        base_wpm = 175.0
        wpm = int(max(20, base_wpm * speed))
        try:
            p = subprocess.Popen(["espeak", "-s", str(wpm), text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return p
        except Exception:
            return None

    if shutil.which("spd-say"):
        base_wpm = 175.0
        wpm = int(max(20, base_wpm * speed))
        try:
            p = subprocess.Popen(["spd-say", "--rate", str(wpm), text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return p
        except Exception:
            try:
                p = subprocess.Popen(["spd-say", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return p
            except Exception:
                return None

    return None

# --- Helpers for suspending/resuming processes (best-effort) ---
def _suspend_process(pid):
    """Best-effort suspend process by pid. POSIX: SIGSTOP. Windows: try NtSuspendProcess via ntdll."""
    try:
        if PLATFORM != "Windows":
            os.kill(pid, signal.SIGSTOP)
            return True
        else:
            # Try to call NtSuspendProcess from ntdll
            try:
                ntdll = ctypes.WinDLL("ntdll")
                NtSuspendProcess = ntdll.NtSuspendProcess
                handle = ctypes.windll.kernel32.OpenProcess(0x0002 | 0x0400, False, pid)  # PROCESS_SUSPEND_RESUME not defined everywhere; use PROCESS_TERMINATE|PROCESS_QUERY_INFORMATION fallback
                if not handle:
                    return False
                res = NtSuspendProcess(handle)
                ctypes.windll.kernel32.CloseHandle(handle)
                return res == 0
            except Exception:
                return False
    except Exception:
        return False

def _resume_process(pid):
    """Best-effort resume process by pid. POSIX: SIGCONT. Windows: try NtResumeProcess via ntdll."""
    try:
        if PLATFORM != "Windows":
            os.kill(pid, signal.SIGCONT)
            return True
        else:
            try:
                ntdll = ctypes.WinDLL("ntdll")
                NtResumeProcess = ntdll.NtResumeProcess
                handle = ctypes.windll.kernel32.OpenProcess(0x0002 | 0x0400, False, pid)
                if not handle:
                    return False
                res = NtResumeProcess(handle)
                ctypes.windll.kernel32.CloseHandle(handle)
                return res == 0
            except Exception:
                return False
    except Exception:
        return False

# --- Helpers for lip-sync timing ---
VOWELS = set("aeiouAEIOU")

def count_vowel_groups(word):
    groups = 0
    prev_v = False
    for ch in word:
        is_v = ch in VOWELS
        if is_v and not prev_v:
            groups += 1
        prev_v = is_v
    return max(1, groups)

def letter_strength(letter):
    if not letter or not letter.isalpha():
        return 0.08
    l = letter.lower()
    if l in "aeiou":
        return 1.0
    if l in "y":
        return 0.7
    if l in "rlmwn":
        return 0.55
    if l in "bdgp":
        return 0.45
    return 0.25

def estimate_letter_durations(text, speech_speed, base_syllable_ms=180.0):
    words = text.split()
    letters = []
    durations = []
    strengths = []
    for wi, w in enumerate(words):
        syl = count_vowel_groups(w)
        word_ms = (syl * base_syllable_ms) / max(1.0, float(speech_speed))
        word_ms = max(50.0, word_ms)
        if len(w) == 0:
            continue
        per_letter_ms = word_ms / len(w)
        for ch in w:
            letters.append(ch)
            durations.append(per_letter_ms / 1000.0)
            strengths.append(letter_strength(ch))
        if wi < len(words) - 1:
            letters.append(" ")
            durations.append(0.06 / float(speech_speed))
            strengths.append(0.08)
    cumulative = []
    t = 0.0
    for d in durations:
        t += d
        cumulative.append(t)
    return letters, cumulative, strengths

# --- Main application ---
class MultiFrameTalker(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Glitch Host — Multi Image Animator")
        self.canvas_w = 480
        self.canvas_h = 640

        # Compact two-row control layout
        top_outer = tk.Frame(self)
        top_outer.pack(padx=6, pady=6, fill="x")

        row1 = tk.Frame(top_outer)
        row1.pack(fill="x", pady=(0,4))
        left_grp = tk.Frame(row1); left_grp.pack(side="left", anchor="w")
        tk.Button(left_grp, text="Load Images", width=10, command=self.load_images).pack(side="left", padx=(0,4))
        tk.Button(left_grp, text="Load Grid", width=10, command=self.load_letter_grid_no_pil).pack(side="left")

        mid_grp = tk.Frame(row1); mid_grp.pack(side="left", padx=8)
        tk.Label(mid_grp, text="Lip Sync", font=("TkDefaultFont", 9)).pack(side="left", padx=(0,2))
        self.lipsync_var = tk.BooleanVar(value=True)
        tk.Checkbutton(mid_grp, variable=self.lipsync_var).pack(side="left", padx=(0,6))
        tk.Label(mid_grp, text="Draw Mouth", font=("TkDefaultFont", 9)).pack(side="left", padx=(0,2))
        self.draw_mouth_var = tk.BooleanVar(value=False)
        tk.Checkbutton(mid_grp, variable=self.draw_mouth_var).pack(side="left", padx=(0,6))
        self.shuffle_var = tk.BooleanVar(value=False)
        tk.Checkbutton(mid_grp, text="Shuffle", variable=self.shuffle_var).pack(side="left", padx=(0,6))
        self.loop_var = tk.BooleanVar(value=True)
        tk.Checkbutton(mid_grp, text="Loop", variable=self.loop_var).pack(side="left")

        right_grp = tk.Frame(row1); right_grp.pack(side="right", anchor="e")
        tk.Label(right_grp, text="FPS", font=("TkDefaultFont", 9)).pack(side="left", padx=(0,2))
        self.framerate_var = tk.DoubleVar(value=6.0)
        self.framerate_spin = tk.Spinbox(right_grp, from_=0.1, to=240.0, increment=0.1, width=6, textvariable=self.framerate_var)
        self.framerate_spin.pack(side="left", padx=(0,6))
        tk.Label(right_grp, text="Speech", font=("TkDefaultFont", 9)).pack(side="left", padx=(0,2))
        self.speech_speed_var = tk.DoubleVar(value=1.0)
        self.speech_speed_spin = tk.Spinbox(right_grp, from_=0.5, to=2.5, increment=0.05, width=5, textvariable=self.speech_speed_var, format="%.2f")
        self.speech_speed_spin.pack(side="left")

        row2 = tk.Frame(top_outer); row2.pack(fill="x")
        stutter_grp = tk.Frame(row2); stutter_grp.pack(side="left", anchor="w")
        tk.Label(stutter_grp, text="Stutter", font=("TkDefaultFont", 9)).pack(side="left", padx=(0,4))
        self.stutter_enabled = tk.BooleanVar(value=True)
        tk.Checkbutton(stutter_grp, variable=self.stutter_enabled).pack(side="left", padx=(0,6))
        self.stutter_intensity = tk.DoubleVar(value=0.45)
        self.stutter_spin = tk.Spinbox(stutter_grp, from_=0.0, to=1.0, increment=0.05, width=5, textvariable=self.stutter_intensity, format="%.2f")
        self.stutter_spin.pack(side="left")
        self.stutter_label = tk.Label(stutter_grp, text="45%", font=("TkDefaultFont", 9))
        self.stutter_label.pack(side="left", padx=(6,0))

        input_grp = tk.Frame(row2); input_grp.pack(side="left", padx=12, fill="x", expand=True)
        tk.Label(input_grp, text="Input (single box)", font=("TkDefaultFont", 9)).pack(anchor="w")
        self.input_text = tk.Text(input_grp, width=48, height=4, wrap="word", font=("TkDefaultFont", 9))
        self.input_text.pack(side="left", fill="both", expand=True)
        input_scroll = tk.Scrollbar(input_grp, orient="vertical", command=self.input_text.yview)
        input_scroll.pack(side="left", fill="y")
        self.input_text.config(yscrollcommand=input_scroll.set)

        # input buttons: Load Txt, Paste, Clear
        input_btns = tk.Frame(row2)
        input_btns.pack(side="right", anchor="e")
        tk.Button(input_btns, text="Load Txt", width=8, command=self.load_text_file_into_input).pack(pady=(0,4))
        tk.Button(input_btns, text="Paste", width=8, command=self.paste_from_clipboard).pack(pady=(0,4))
        tk.Button(input_btns, text="Clear", width=8, command=self.clear_input).pack()

        bottom_info = tk.Frame(self); bottom_info.pack(fill="x", padx=6)
        self.char_count_label = tk.Label(bottom_info, text="0 chars", font=("TkDefaultFont", 9))
        self.char_count_label.pack(side="left")
        self.input_source_label = tk.Label(bottom_info, text="Using: input area", font=("TkDefaultFont", 9))
        self.input_source_label.pack(side="left", padx=(8,0))

        pl_frame = tk.Frame(self); pl_frame.pack(padx=6, pady=(6,4), fill="x")
        tk.Label(pl_frame, text="Playlist", font=("TkDefaultFont", 10)).pack(anchor="w")
        self.playlist_lb = tk.Listbox(pl_frame, width=72, height=4, selectmode="browse", font=("TkDefaultFont", 9))
        self.playlist_lb.pack(side="left", fill="x", expand=True)
        self.playlist_lb.bind("<<ListboxSelect>>", self.on_playlist_select)
        pl_scroll = tk.Scrollbar(pl_frame, orient="vertical", command=self.playlist_lb.yview)
        pl_scroll.pack(side="right", fill="y")
        self.playlist_lb.config(yscrollcommand=pl_scroll.set)

        mid_controls = tk.Frame(self); mid_controls.pack(padx=6, pady=(0,6), fill="x")
        self.speak_btn = tk.Button(mid_controls, text="Speak", width=10, command=self.start_speaking, state="disabled")
        self.speak_btn.pack(side="left")
        self.pause_btn = tk.Button(mid_controls, text="Pause", width=10, command=self.toggle_pause, state="disabled")
        self.pause_btn.pack(side="left", padx=(6,0))
        self.stop_btn = tk.Button(mid_controls, text="Stop", width=10, command=self.stop_speaking, state="disabled")
        self.stop_btn.pack(side="left", padx=(6,0))

        self.canvas = tk.Canvas(self, width=self.canvas_w, height=self.canvas_h, bg="black", highlightthickness=0)
        self.canvas.pack(padx=6, pady=(0,8))

        # State
        self.images = []
        self.current_index = 0
        self.image_id = None
        self.mouth_id = None
        self.glitch_items = []
        self.scanline_items = []
        self.speaking = False
        self.paused = False
        self.speech_thread = None
        self.mouth_coords = None
        self.default_mouth_frac = (0.5, 0.72, 0.22, 0.06)
        self.tts_process = None
        self.letter_id = None
        self.letter_map = {}

        # traces
        try:
            self.framerate_var.trace_add("write", lambda *a: self._update_delay_label())
            self.speech_speed_var.trace_add("write", lambda *a: self._update_speech_label())
            self.stutter_intensity.trace_add("write", lambda *a: self._update_stutter_label())
            self.draw_mouth_var.trace_add("write", lambda *a: self._on_draw_mouth_toggle())
        except Exception:
            try:
                self.framerate_var.trace("w", lambda *a: self._update_delay_label())
                self.speech_speed_var.trace("w", lambda *a: self._update_speech_label())
                self.stutter_intensity.trace("w", lambda *a: self._update_stutter_label())
                self.draw_mouth_var.trace("w", lambda *a: self._on_draw_mouth_toggle())
            except Exception:
                pass

        # ensure mouth is removed at startup if Draw Mouth is off
        self._on_draw_mouth_toggle()
        self._update_delay_label()
        self._update_speech_label()
        self._update_stutter_label()
        self._update_input_counter()

    # --- Image slicing (no PIL) ---
    def load_letter_grid_no_pil(self):
        path = filedialog.askopenfilename(title="Select letter grid image", filetypes=[("Image files","*.png;*.jpg;*.jpeg;*.gif;*.bmp"),("All files","*.*")])
        if not path:
            return
        try:
            full = tk.PhotoImage(file=path)
        except Exception as e:
            messagebox.showerror("Error", f"Could not load image with Tkinter PhotoImage: {e}\nConvert to PNG/GIF if needed.")
            return
        GRID_COLS = 4
        GRID_ROWS = 7
        try:
            w = int(full.width()); h = int(full.height())
        except Exception:
            try:
                w = int(self.tk.call(full, 'width')); h = int(self.tk.call(full, 'height'))
            except Exception as e:
                messagebox.showerror("Error", f"Could not determine image size: {e}")
                return
        tile_w = w // GRID_COLS; tile_h = h // GRID_ROWS
        tiles = []
        for r in range(GRID_ROWS):
            for c in range(GRID_COLS):
                if len(tiles) >= 26:
                    break
                left = c * tile_w; upper = r * tile_h
                right = left + tile_w; lower = upper + tile_h
                if c == GRID_COLS - 1: right = w
                if r == GRID_ROWS - 1: lower = h
                try:
                    new_img = tk.PhotoImage()
                    self.tk.call(new_img, 'copy', full, '-from', left, upper, right-1, lower-1)
                    iw = int(new_img.width()); ih = int(new_img.height())
                    scale = min(1.0, min(self.canvas_w / iw, self.canvas_h / ih))
                    if scale < 1.0:
                        factor = max(1, int(1/scale))
                        try:
                            new_img = new_img.subsample(factor, factor)
                        except Exception:
                            pass
                    tiles.append(new_img)
                except Exception:
                    continue
            if len(tiles) >= 26:
                break
        if not tiles:
            messagebox.showerror("Error", "No tiles extracted. Use PNG/GIF if your Tk build lacks JPEG support.")
            return
        letters = [chr(ord('A') + i) for i in range(26)]
        added = 0
        for tkimg in tiles:
            if added >= 26: break
            letter = letters[added]
            name = f"{letter}_tile"
            pixel_cache = self._make_pixel_cache(tkimg)
            self.images.append({'path': name, 'photo': tkimg, 'pixel_cache': pixel_cache})
            self.playlist_lb.insert(tk.END, name)
            added += 1
        if self.images:
            self.letter_map = self.build_letter_index_map()
            self.playlist_lb.selection_clear(0, tk.END)
            self.playlist_lb.selection_set(0)
            self.playlist_lb.activate(0)
            self.on_playlist_select()
            self.display_image(0)
            self.speak_btn.config(state="normal")
            self.pause_btn.config(state="disabled")
            self.stop_btn.config(state="disabled")
            self.remove_btn = getattr(self, "remove_btn", None)
            if self.remove_btn:
                self.remove_btn.config(state="normal")

    # --- Playlist management ---
    def load_images(self):
        paths = filedialog.askopenfilenames(title="Select portrait images", filetypes=[("PNG images","*.png"),("All images","*.*")])
        if not paths:
            return
        for p in paths:
            try:
                img = tk.PhotoImage(file=p)
            except Exception:
                continue
            iw, ih = img.width(), img.height()
            scale = min(self.canvas_w / iw, self.canvas_h / ih, 1.0)
            if scale < 1.0:
                factor = int(1/scale)
                if factor > 1:
                    try:
                        img = img.subsample(factor, factor)
                    except Exception:
                        pass
            pixel_cache = self._make_pixel_cache(img)
            self.images.append({'path': os.path.basename(p), 'photo': img, 'pixel_cache': pixel_cache})
            self.playlist_lb.insert(tk.END, os.path.basename(p))
        if self.images:
            self.letter_map = self.build_letter_index_map()
            self.playlist_lb.selection_clear(0, tk.END)
            self.playlist_lb.selection_set(0)
            self.playlist_lb.activate(0)
            self.on_playlist_select()
            self.display_image(0)
            self.speak_btn.config(state="normal")
            self.pause_btn.config(state="disabled")
            self.stop_btn.config(state="disabled")

    def on_playlist_select(self, event=None):
        sel = self.playlist_lb.curselection()
        if sel:
            idx = sel[0]
            self.current_index = idx
            self.display_image(idx)

    def remove_selected(self):
        sel = self.playlist_lb.curselection()
        if not sel: return
        idx = sel[0]
        self.playlist_lb.delete(idx)
        del self.images[idx]
        self.letter_map = self.build_letter_index_map()
        if self.images:
            new_idx = max(0, min(len(self.images)-1, idx))
            self.playlist_lb.selection_set(new_idx)
            self.playlist_lb.activate(new_idx)
            self.on_playlist_select()
        else:
            self.clear_canvas()
            self.speak_btn.config(state="disabled")
            self.pause_btn.config(state="disabled")
            self.stop_btn.config(state="disabled")
            self.letter_map = {}

    def move_selected(self, delta):
        sel = self.playlist_lb.curselection()
        if not sel: return
        idx = sel[0]
        new = idx + delta
        if new < 0 or new >= len(self.images): return
        self.images[idx], self.images[new] = self.images[new], self.images[idx]
        text = self.playlist_lb.get(idx); text2 = self.playlist_lb.get(new)
        self.playlist_lb.delete(idx); self.playlist_lb.insert(idx, text2)
        self.playlist_lb.delete(new); self.playlist_lb.insert(new, text)
        self.playlist_lb.selection_clear(0, tk.END)
        self.playlist_lb.selection_set(new)
        self.playlist_lb.activate(new)
        self.letter_map = self.build_letter_index_map()
        self.on_playlist_select()

    # --- Display helpers ---
    def _make_pixel_cache(self, photo):
        cache = []
        for f in (6,4,3,2):
            try:
                small = photo.subsample(f, f)
                try:
                    big = small.zoom(f, f)
                except Exception:
                    big = small
                cache.append(big)
            except Exception:
                continue
        cache.append(photo)
        return cache

    def display_image(self, idx):
        if not self.images: return
        idx = max(0, min(len(self.images)-1, idx))
        self.current_index = idx
        img = self.images[idx]['photo']
        if self.image_id:
            self.canvas.itemconfig(self.image_id, image=img)
        else:
            self.image_id = self.canvas.create_image(self.canvas_w//2, self.canvas_h//2, image=img)
        self.canvas.image_ref = img
        bbox = self.canvas.bbox(self.image_id)
        if bbox:
            x1,y1,x2,y2 = bbox
            iw_disp = x2 - x1; ih_disp = y2 - y1
            cx_frac, cy_frac, w_frac, h_frac = self.default_mouth_frac
            cx = x1 + iw_disp * cx_frac; cy = y1 + ih_disp * cy_frac
            w = iw_disp * w_frac; h = ih_disp * h_frac
            self.mouth_coords = (cx, cy, w, h)
        else:
            self.mouth_coords = None
        self._create_scanlines()

    def clear_canvas(self):
        self.canvas.delete("all")
        self.image_id = None
        self.mouth_id = None
        self.glitch_items = []
        self.scanline_items = []

    def _create_scanlines(self):
        for it in self.scanline_items:
            try: self.canvas.delete(it)
            except Exception: pass
        self.scanline_items = []
        if not self.image_id: return
        bbox = self.canvas.bbox(self.image_id)
        if not bbox: return
        x1,y1,x2,y2 = bbox
        for y in range(y1, y2, 4):
            it = self.canvas.create_rectangle(x1, y, x2, y+1, fill="#000000", outline="", stipple="gray50")
            self.scanline_items.append(it)
        for it in self.scanline_items:
            self.canvas.tag_lower(it, self.image_id)

    def draw_mouth(self, openness):
        if not self.mouth_coords: return
        cx, cy, w, h = self.mouth_coords
        hw = w/2
        hh = h/2 + h * openness * 1.1
        x1, y1, x2, y2 = cx - hw + random.randint(-2,2), cy - hh + random.randint(-2,2), cx + hw + random.randint(-2,2), cy + hh + random.randint(-2,2)
        if self.mouth_id:
            try: self.canvas.delete(self.mouth_id)
            except Exception: pass
        self.mouth_id = self.canvas.create_oval(x1, y1, x2, y2, fill="#0b0b0b", outline="")
        inner = self.canvas.create_rectangle(x1+2, cy-2, x2-2, y2-2, fill="#2b2b2b", outline="")
        self.canvas.tag_lower(inner, self.mouth_id)

    def clear_glitches(self):
        for it in list(self.glitch_items):
            try: self.canvas.delete(it)
            except Exception: pass
        self.glitch_items = []

    def spawn_glitch_burst(self):
        self.clear_glitches()
        if not self.image_id: return
        bbox = self.canvas.bbox(self.image_id)
        if not bbox: return
        x1,y1,x2,y2 = bbox
        iw = x2 - x1; ih = y2 - y1
        for _ in range(random.randint(1,4)):
            y = random.randint(y1, y2); h = random.randint(1,4)
            color = random.choice(["#00ffff","#ff00ff","#ffff00","#ffffff"])
            r = self.canvas.create_rectangle(x1, y, x2, y+h, fill=color, outline="")
            self.glitch_items.append(r)
        for _ in range(random.randint(0,3)):
            gx = random.randint(x1, x2); gw = random.randint(2,8)
            gy1 = random.randint(y1, y2); gy2 = min(y2, gy1 + random.randint(6, max(6, ih//6)))
            color = random.choice(["#00ffff","#ff00ff","#ffff00"])
            r = self.canvas.create_rectangle(gx, gy1, gx+gw, gy2, fill=color, outline="")
            self.glitch_items.append(r)
        dx = random.randint(-3,3); dy = random.randint(-2,2)
        if dx or dy:
            self.canvas.move(self.image_id, dx, dy)
            if self.mouth_id: self.canvas.move(self.mouth_id, dx, dy)
            self.after(80 + random.randint(0,120), lambda: self.canvas.move(self.image_id, -dx, -dy))

    def apply_pixelation(self, intensity=0.6):
        if not self.images: return
        idx = self.current_index
        cache = self.images[idx]['pixel_cache']
        if not cache: return
        sel = int((1.0 - intensity) * (len(cache)-1))
        sel = max(0, min(len(cache)-1, sel))
        img = cache[sel]
        if self.image_id:
            self.canvas.itemconfig(self.image_id, image=img)
            self.canvas.image_ref = img

    def apply_rgb_split(self):
        if not self.image_id: return
        bbox = self.canvas.bbox(self.image_id)
        if not bbox: return
        x1,y1,x2,y2 = bbox
        iw = x2 - x1
        slice_w = random.randint(max(6, iw//30), max(12, max(12, iw//12)))
        sx = random.randint(x1, x2 - slice_w)
        r = self.canvas.create_rectangle(sx-2, y1, sx+slice_w-2, y2, fill="#ff0000", outline="")
        g = self.canvas.create_rectangle(sx+2, y1, sx+slice_w+2, y2, fill="#00ff00", outline="")
        b = self.canvas.create_rectangle(sx, y1, sx+slice_w, y2, fill="#00ffff", outline="")
        self.glitch_items.extend([r,g,b])
        self.after(90 + random.randint(0,160), lambda: [self._safe_delete(it) for it in (r,g,b)])

    def _safe_delete(self, item):
        try:
            self.canvas.delete(item)
            if item in self.glitch_items:
                self.glitch_items.remove(item)
        except Exception:
            pass

    # --- Ambient tick ---
    def _ambient_tick(self):
        if self.speaking and random.random() < 0.22:
            self.spawn_glitch_burst()
        if self.scanline_items and random.random() < 0.12:
            for it in self.scanline_items:
                self.canvas.move(it, random.randint(-1,1), 0)
            self.after(80, lambda: [self.canvas.move(it, 0, 0) for it in self.scanline_items])
        self.after(120, self._ambient_tick)

    # --- Stutter generator ---
    def stutter_bursts_with_frames(self, text):
        words = text.split()
        bursts = []
        enabled = bool(self.stutter_enabled.get())
        intensity = float(self.stutter_intensity.get()) if enabled else 0.0
        p_longword_cut = 0.45 * intensity
        p_half_word_repeat = 0.5 * intensity
        p_insert_short = 0.28 * intensity
        p_random_token = 0.18 * intensity

        for w in words:
            if len(w) > 4 and random.random() < p_longword_cut:
                cut = random.randint(1, len(w)-2)
                a, b = w[:cut], w[cut:]
                bursts.append(a + "-")
                if random.random() < p_half_word_repeat:
                    bursts.append(a + "-")
                bursts.append(b)
            else:
                if random.random() < p_insert_short:
                    bursts.append(w)
                    bursts.append(w[:max(2, len(w)//2)] + "-")
                else:
                    bursts.append(w)
            if random.random() < p_random_token:
                bursts.append(random.choice(["glitch", "static", "…", "!!"]))
        utterances = []
        i = 0
        while i < len(bursts):
            bl = random.choice([1,1,2,2,3])
            utterances.append(" ".join(bursts[i:i+bl]))
            i += bl
        return utterances

    # --- Letter overlay helpers ---
    def draw_letter_overlay(self, letter):
        try:
            display = (letter or "").upper()
            if self.letter_id:
                self.canvas.itemconfig(self.letter_id, text=display)
            else:
                x = self.canvas_w // 2
                y = int(self.canvas_h * 0.88)
                self.letter_id = self.canvas.create_text(x, y, text=display, fill="#ffffff", font=("Helvetica", 28, "bold"))
                self.canvas.tag_raise(self.letter_id)
        except Exception:
            self.letter_id = None

    def clear_letter_overlay(self):
        if self.letter_id:
            try: self.canvas.delete(self.letter_id)
            except Exception: pass
            self.letter_id = None

    def _on_draw_mouth_toggle(self, *args):
        if not getattr(self, "draw_mouth_var", tk.BooleanVar()).get():
            if self.mouth_id:
                try: self.canvas.delete(self.mouth_id)
                except Exception: pass
                self.mouth_id = None

    def build_letter_index_map(self):
        mapping = {}
        for i, info in enumerate(self.images):
            name = info.get('path', '')
            if name:
                first = name.strip()[0:1].upper()
                if 'A' <= first <= 'Z' and first not in mapping:
                    mapping[first] = i
        return mapping

    # --- Tiles synchronized to speech ---
    def animate_and_speak(self, text):
        if not self.images:
            return
        self.speaking = True
        self.paused = False
        self.pause_btn.config(text="Pause", state="normal")
        self.stop_btn.config(state="normal")
        self.speak_btn.config(state="disabled")

        bursts = self.stutter_bursts_with_frames(text)
        full_text = " ".join(bursts)

        # Build letter map fresh
        self.letter_map = self.build_letter_index_map()

        indices = list(range(len(self.images)))
        if self.shuffle_var.get():
            random.shuffle(indices)

        try:
            framerate = float(self.framerate_var.get())
        except Exception:
            framerate = 6.0
        framerate = max(0.1, framerate)
        frame_delay = 1.0 / framerate

        try:
            speech_speed = float(self.speech_speed_var.get())
        except Exception:
            speech_speed = 1.0
        speech_speed = max(0.1, min(4.0, speech_speed))

        # per-letter estimated timings
        letters, cumulative, letter_strengths = estimate_letter_durations(full_text, speech_speed, base_syllable_ms=180.0)
        estimated_total = cumulative[-1] if cumulative else 0.0

        # Start TTS subprocess
        self.tts_process = speak_process(full_text, speech_speed)

        # Small startup delay to allow TTS engine to begin speaking (helps sync)
        tts_startup_delay = 0.10
        time.sleep(tts_startup_delay)

        start_time = time.time()
        visual_letter_idx = 0

        try:
            while self.speaking:
                # If paused, wait here until resumed; keep UI responsive
                if self.paused:
                    # attempt to keep TTS suspended (best-effort)
                    time.sleep(0.08)
                    continue

                # If TTS process exists and finished, break out (speech ended)
                if self.tts_process is not None and self.tts_process.poll() is not None:
                    break

                now = time.time()
                elapsed = now - start_time

                # Advance visual letter index based on elapsed time (keeps letters synced to speech time)
                if self.lipsync_var.get():
                    while visual_letter_idx < len(cumulative) and elapsed > cumulative[visual_letter_idx]:
                        visual_letter_idx += 1

                # Determine which tile to show:
                idx = 0
                if self.lipsync_var.get() and visual_letter_idx < len(letters):
                    current_letter = letters[visual_letter_idx]
                    if isinstance(current_letter, str) and len(current_letter.strip()) == 1 and current_letter.isalpha():
                        L = current_letter.upper()
                        mapped_idx = self.letter_map.get(L)
                        if mapped_idx is not None:
                            idx = mapped_idx
                        else:
                            if indices:
                                frame_pos = int(elapsed / frame_delay)
                                idx = indices[frame_pos % len(indices)]
                            else:
                                idx = 0
                    else:
                        if indices:
                            frame_pos = int(elapsed / frame_delay)
                            idx = indices[frame_pos % len(indices)]
                        else:
                            idx = 0
                else:
                    if indices:
                        frame_pos = int(elapsed / frame_delay)
                        idx = indices[frame_pos % len(indices)]
                    else:
                        idx = 0

                # Determine openness for mouth drawing
                if self.lipsync_var.get() and visual_letter_idx < len(letter_strengths):
                    base = letter_strengths[visual_letter_idx]
                    openness = max(0.05, min(1.0, base * (0.6 + random.random()*0.6)))
                    current_letter_display = letters[visual_letter_idx]
                else:
                    openness = 0.08 + random.random()*0.18
                    current_letter_display = ""

                # Display chosen image
                self.display_image(idx)

                # Visual effects (unchanged)
                if random.random() < 0.28:
                    self.apply_rgb_split()
                if random.random() < 0.22:
                    self.spawn_glitch_burst()
                if random.random() < 0.12:
                    self.apply_pixelation(intensity=random.uniform(0.4, 0.9))
                    self.after(60 + random.randint(0,120), lambda: self.apply_pixelation(intensity=0.0))

                # Draw mouth only if enabled
                if self.draw_mouth_var.get():
                    self.draw_mouth(openness)
                else:
                    if self.mouth_id:
                        try: self.canvas.delete(self.mouth_id)
                        except Exception: pass
                        self.mouth_id = None

                # Letter overlay only if lipsync enabled
                if self.lipsync_var.get():
                    self.draw_letter_overlay(current_letter_display.upper() if current_letter_display.strip() else "")
                else:
                    self.clear_letter_overlay()

                # Sleep a short time to yield to UI and keep timing accurate
                time.sleep(min(frame_delay, 0.02))

            # end speaking loop
        finally:
            # Ensure TTS process is cleaned up if still running
            if self.tts_process is not None:
                try:
                    if self.tts_process.poll() is None:
                        try: self.tts_process.terminate()
                        except Exception: pass
                        time.sleep(0.12)
                        if self.tts_process.poll() is None:
                            try:
                                if hasattr(os, "kill") and PLATFORM != "Windows":
                                    os.kill(self.tts_process.pid, signal.SIGKILL)
                                else:
                                    self.tts_process.kill()
                            except Exception: pass
                except Exception: pass
                finally:
                    self.tts_process = None

            self.speaking = False
            self.paused = False
            self.pause_btn.config(text="Pause", state="disabled")
            self.clear_glitches()
            if self.mouth_id:
                try: self.canvas.delete(self.mouth_id)
                except Exception: pass
                self.mouth_id = None
            self.clear_letter_overlay()
            try:
                self.stop_btn.config(state="disabled")
                self.speak_btn.config(state="normal")
            except Exception: pass

    # --- Controls ---
    def start_speaking(self):
        text = self.input_text.get("1.0", "end").strip()
        if not text: return
        if self.speech_thread and self.speech_thread.is_alive(): return
        # rebuild letter map in case playlist changed
        self.letter_map = self.build_letter_index_map()
        self.speech_thread = threading.Thread(target=self.animate_and_speak, args=(text,), daemon=True)
        self.speech_thread.start()
        # enable pause button once speaking starts
        self.pause_btn.config(state="normal", text="Pause")

    def toggle_pause(self):
        """Toggle pause/resume. Pauses visuals and attempts to suspend TTS process (best-effort)."""
        if not self.speaking:
            return
        if not self.paused:
            # Pause now
            self.paused = True
            self.pause_btn.config(text="Resume")
            # best-effort suspend TTS process
            if self.tts_process is not None:
                try:
                    _suspend_process(self.tts_process.pid)
                except Exception:
                    pass
        else:
            # Resume
            self.paused = False
            self.pause_btn.config(text="Pause")
            # best-effort resume TTS process
            if self.tts_process is not None:
                try:
                    _resume_process(self.tts_process.pid)
                except Exception:
                    pass

    def stop_speaking(self):
        # Stop speaking and ensure TTS process is terminated
        self.speaking = False
        self.paused = False
        self.pause_btn.config(text="Pause", state="disabled")
        if self.tts_process is not None:
            try:
                if self.tts_process.poll() is None:
                    try: self.tts_process.terminate()
                    except Exception: pass
                    time.sleep(0.08)
                    if self.tts_process.poll() is None:
                        try:
                            if hasattr(os, "kill") and PLATFORM != "Windows":
                                os.kill(self.tts_process.pid, signal.SIGKILL)
                            else:
                                self.tts_process.kill()
                        except Exception: pass
            except Exception: pass
            finally:
                self.tts_process = None
        self.clear_letter_overlay()
        if self.mouth_id:
            try: self.canvas.delete(self.mouth_id)
            except Exception: pass
            self.mouth_id = None
        self.stop_btn.config(state="disabled")
        self.speak_btn.config(state="normal")

    def load_text_file_into_input(self):
        path = filedialog.askopenfilename(title="Select text file", filetypes=[("Text files","*.txt"),("All files","*.*")])
        if not path: return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = f.read()
            self.input_text.delete("1.0", "end")
            self.input_text.insert("1.0", data)
        except Exception as e:
            messagebox.showerror("Error", f"Could not load file: {e}")

    def paste_from_clipboard(self):
        """Paste text from the system clipboard into the input box at the current insert position."""
        try:
            clip = self.clipboard_get()
        except Exception:
            clip = ""
        if not clip:
            return
        try:
            # Insert at current cursor position; fallback to end
            try:
                self.input_text.insert("insert", clip)
            except Exception:
                self.input_text.insert("end", clip)
        except Exception:
            try:
                self.input_text.delete("1.0", "end")
                self.input_text.insert("1.0", clip)
            except Exception:
                pass

    def clear_input(self):
        self.input_text.delete("1.0", "end")

    def _update_input_counter(self):
        txt = self.input_text.get("1.0", "end")
        n = len(txt) - 1
        cap = 20000
        if cap > 0 and n > cap:
            self.char_count_label.config(text=f"{n} chars (cap {cap})", fg="red")
        else:
            self.char_count_label.config(text=f"{n} chars", fg="black")
        self.after(300, self._update_input_counter)

    def _update_delay_label(self):
        try: fr = float(self.framerate_var.get())
        except Exception: fr = 6.0
        fr = max(0.1, fr)
        ms = 1000.0 / fr
        # compact UI: no separate delay label; framerate shown in spinbox

    def _update_speech_label(self):
        try: s = float(self.speech_speed_var.get())
        except Exception: s = 1.0
        # compact UI: speech speed shown in spinbox

    def _update_stutter_label(self):
        try: v = float(self.stutter_intensity.get())
        except Exception: v = 0.0
        self.stutter_label.config(text=f"{int(v*100)}%")

# --- Run app ---
if __name__ == "__main__":
    app = MultiFrameTalker()
    app.mainloop()
