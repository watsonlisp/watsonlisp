#!/usr/bin/env python3
"""
Angry Parrot — TTS without pip

Features:
 - Uses system TTS: macOS 'say', Windows PowerShell SAPI, Linux 'spd-say' or 'espeak' if available.
 - Interactive: press Enter to repeat, type 'q' or 'exit' to quit.
 - Auto mode: repeat every -i seconds until count reached or interrupted.
 - Options: -c/--count, --auto, -i/--interval, -s/--seed, -o/--output, --no-tts

Usage examples:
  python angry_parrot_no_pip.py            # interactive (press Enter to repeat)
  python angry_parrot_no_pip.py --auto -i 1.5   # auto-repeat every 1.5s
  python angry_parrot_no_pip.py -c 5 --no-tts   # print 5 quotes, no speech
  python angry_parrot_no_pip.py -o out.txt -c 3
"""
import argparse
import random
import time
import sys
import shutil
import subprocess
from datetime import datetime
from shlex import quote as shquote

QUOTES = [
    "If you keep that up the Wi‑Fi will mysteriously stop working.",
    "I didn't raise you to be a walking 'later'.",
    "Do you think money grows on the neighbor's tree?",
    "I asked for one thing and you gave me a creative interpretation.",
    "When I said 'clean your room' I didn't mean 'decorate the floor'.",
    "You call that a plan? My toaster has better strategy.",
    "I will not repeat myself. I will not repeat myself. I will not repeat myself.",
    "This is not a suggestion box; it's a 'do it now' box.",
    "If procrastination were an Olympic sport you'd still be late to the podium.",
    "I didn't sign up to be your personal GPS for life choices.",
    "If you break it, you fix it; if you lose it, you replace it.",
    "I can hear the excuses forming from here.",
    "You have one job and it's not optional.",
    "Do you want me to come over there and show you how it's done?",
    "I didn't raise you to be a professional couch tester.",
    "Your future self will thank you if you start now.",
    "This house is not a museum for your clutter.",
    "I didn't give you life so you could waste it on snacks and screens.",
    "If you think I'm joking, try me.",
    "You don't need a permission slip to be responsible.",
    "I didn't raise you to be a human snooze button.",
    "If you want respect, start by showing some.",
    "You can either do it now or do it later and regret it twice.",
    "I didn't raise you to be a walking 'I'll do it tomorrow'.",
    "The floor is not a storage solution.",
    "I didn't raise you to be a professional negotiator with yourself.",
    "If you want dessert, earn it with behavior, not bargaining.",
    "I didn't raise you to be a living reminder of my unfinished tasks.",
    "You have two ears and one mouth; use them in that ratio.",
    "I didn't raise you to be a collector of half-finished projects.",
    "If you want privileges, treat them like privileges, not rights.",
    "I didn't raise you to be a master of excuses.",
    "You can either be part of the solution or part of the problem.",
    "I didn't raise you to be a professional 'maybe'.",
    "If you want to be trusted, start by being trustworthy.",
    "I didn't raise you to be a walking 'I'll get to it'.",
    "The trash can is not decorative; it has a purpose.",
    "I didn't raise you to be a curator of chaos.",
    "If you want to borrow my patience, return it in the same condition.",
    "I didn't raise you to be a living 'I'll think about it'.",
    "You don't need a trophy for showing up; you need one for doing the work.",
    "I didn't raise you to be a professional 'later'.",
    "If you want to argue, take it to the debate club, not the dinner table.",
    "I didn't raise you to be a walking 'I'll try'.",
    "The laundry basket is not a suggestion, it's a destination.",
    "I didn't raise you to be a human reminder app.",
    "If you want to be treated like an adult, start acting like one.",
    "I didn't raise you to be a collector of unfinished sentences.",
    "You can either do the right thing or do the easy thing; choose wisely.",
    "I didn't raise you to be a professional 'I'll do it eventually'.",
    "If you want to keep your things, keep track of them.",
    "I didn't raise you to be a living 'maybe later'.",
    "The calendar exists for a reason; use it.",
    "I didn't raise you to be a professional 'I'll think about it'.",
    "If you want help, ask for it before the problem becomes a disaster.",
    "I didn't raise you to be a walking 'I'll get to it someday'.",
    "You don't get extra points for dramatic entrances; be on time.",
    "I didn't raise you to be a human pause button.",
    "If you want to keep privileges, don't treat them like permanent fixtures.",
    "I didn't raise you to be a professional 'I'll do it when I feel like it'.",
    "The dishes won't wash themselves and neither will your future.",
    "I didn't raise you to be a living 'I'll do it after one more episode'.",
    "If you want respect, stop asking for it and start earning it.",
    "I didn't raise you to be a professional 'I'll start tomorrow'.",
    "You can either clean up now or clean up later and be angrier about it.",
    "I didn't raise you to be a walking 'I'll get to it eventually'.",
    "If you want to keep your phone, keep your responsibilities.",
    "I didn't raise you to be a human 'I'll do it later' alarm.",
    "The rules aren't optional because you don't like them.",
    "I didn't raise you to be a professional 'I'll do it when I'm ready'.",
    "If you want freedom, show you can handle responsibility.",
    "I didn't raise you to be a living 'I'll do it after this level'.",
    "You don't get to rewrite the schedule because you changed your mind.",
    "I didn't raise you to be a professional 'I'll do it after a snack'.",
    "If you want to be trusted with keys, start by being trusted with chores.",
    "I didn't raise you to be a walking 'I'll do it later' manifesto.",
    "The word 'later' is not a plan; it's a delay tactic.",
    "I didn't raise you to be a professional 'I'll do it when I feel like it'.",
    "If you want to keep privileges, stop treating them like guarantees.",
    "I didn't raise you to be a living 'I'll do it after one more thing'.",
    "You can either be helpful or be in the way; pick one.",
    "I didn't raise you to be a professional 'I'll do it eventually'.",
    "If you want to borrow my car someday, start by borrowing responsibility now.",
    "I didn't raise you to be a walking 'I'll do it later' exhibit.",
    "The 'I'll start Monday' plan has ruined more weekends than anything else.",
    "I didn't raise you to be a professional 'I'll do it when I'm in the mood'.",
    "If you want to be taken seriously, stop treating tasks like suggestions.",
    "I didn't raise you to be a living 'I'll do it after this game'.",
    "You don't get to negotiate bedtime like it's a business deal.",
    "I didn't raise you to be a professional 'I'll do it after one more thing'.",
    "If you want to keep your room, keep it clean.",
    "I didn't raise you to be a walking 'I'll do it later' philosophy.",
    "The world doesn't pause because you forgot to plan.",
    "I didn't raise you to be a professional 'I'll do it when I remember'.",
    "If you want to be independent, start by being dependable.",
    "I didn't raise you to be a living 'I'll do it after this notification'.",
    "You can either follow through or explain why you didn't; explanations don't replace action.",
    "I didn't raise you to be a professional 'I'll do it tomorrow' advocate",
    "If you want privileges, treat them like privileges, not entitlements.",
    "I didn't raise you to be a walking 'I'll do it later' monument",
    "The sooner you start, the sooner you stop stressing about it.",
    "I didn't raise you to be a professional 'I'll do it when I feel like it' philosopher",
    "If you want to keep your stuff, stop leaving it where the dog can find it."
]

def detect_tts():
    """Return a tuple (platform_name, method) or (None, None) if no TTS available.
       method: 'say', 'powershell', 'spd-say', 'espeak'"""
    if sys.platform.startswith("darwin"):
        if shutil.which("say"):
            return ("mac", "say")
    elif sys.platform.startswith("win"):
        # Windows: use PowerShell SAPI (no external binary required)
        return ("windows", "powershell")
    else:
        # Linux/other: prefer spd-say, then espeak
        if shutil.which("spd-say"):
            return ("linux", "spd-say")
        if shutil.which("espeak"):
            return ("linux", "espeak")
    return (None, None)

def tts_speak(method, text):
    """Invoke system TTS for a single text string. Returns True if invoked, False otherwise."""
    try:
        if method == "say":
            # macOS: use say
            subprocess.run(["say", text], check=False)
            return True
        if method == "powershell":
            # Windows: call PowerShell to use System.Speech.Synthesis.SpeechSynthesizer
            # Use -EncodedCommand to avoid quoting issues for long text
            ps_script = (
                'Add-Type -AssemblyName System.Speech;'
                '$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;'
                '$s.Speak([Console]::In.ReadToEnd());'
            )
            # Pass text via stdin to PowerShell
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_script],
                           input=text.encode("utf-8"), check=False)
            return True
        if method == "spd-say":
            # spd-say accepts text argument
            subprocess.run(["spd-say", text], check=False)
            return True
        if method == "espeak":
            subprocess.run(["espeak", text], check=False)
            return True
    except Exception:
        return False
    return False

def safe_speak(method, text):
    """Split long text into smaller chunks for some TTS backends."""
    if method in ("say", "spd-say", "espeak"):
        # these can handle moderate lengths; still split by sentence if very long
        chunks = []
        if len(text) > 300:
            # naive split on sentences
            import re
            parts = re.split(r'(?<=[.!?])\s+', text)
            for p in parts:
                if p:
                    chunks.append(p)
        else:
            chunks = [text]
    elif method == "powershell":
        chunks = [text]
    else:
        chunks = [text]
    ok = False
    for c in chunks:
        if tts_speak(method, c):
            ok = True
        else:
            ok = ok or False
    return ok

def timestamped_line(index, quote):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return f"{index}. {quote}  [{ts}]"

def append_to_file(path, text):
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write(text + "\n")
    except Exception as e:
        print(f"Error writing to file: {e}")

def main():
    parser = argparse.ArgumentParser(description="Angry Parrot — TTS without pip")
    parser.add_argument("-c", "--count", type=int, default=0, help="number of quotes to print (0 = interactive default 1 or unlimited in auto mode)")
    parser.add_argument("-i", "--interval", type=float, default=2.0, help="seconds between quotes in auto mode")
    parser.add_argument("-s", "--seed", type=int, help="random seed for reproducible output")
    parser.add_argument("-o", "--output", type=str, help="append quotes to a file")
    parser.add_argument("--auto", action="store_true", help="auto-repeat without prompting until count reached or interrupted")
    parser.add_argument("--no-tts", action="store_true", help="disable text to speech and only print")
    args = parser.parse_args()

    if args.seed is not None:
        random.seed(args.seed)

    platform_name, method = detect_tts()
    tts_available = (method is not None) and (not args.no_tts)

    if not tts_available:
        if args.no_tts:
            print("TTS disabled by --no-tts; printing only.")
        else:
            print("No system TTS detected; falling back to print-only.")

    index = 1
    try:
        if args.auto:
            total = args.count if args.count > 0 else None
            while True:
                quote = random.choice(QUOTES)
                line = timestamped_line(index, quote)
                print(line)
                if args.output:
                    append_to_file(args.output, line)
                if tts_available:
                    safe_speak(method, quote)
                if total is not None and index >= total:
                    break
                index += 1
                time.sleep(max(0.0, args.interval))
        else:
            total = args.count if args.count > 0 else None
            while True:
                quote = random.choice(QUOTES)
                line = timestamped_line(index, quote)
                print(line)
                if args.output:
                    append_to_file(args.output, line)
                if tts_available:
                    safe_speak(method, quote)
                if total is not None and index >= total:
                    break
                resp = input("Press Enter to repeat, or type 'q' / 'exit' then Enter to quit: ").strip().lower()
                if resp in ("q", "quit", "exit"):
                    break
                index += 1
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
    print("Angry Parrot exiting. Goodbye.")

if __name__ == "__main__":
    main()
