#!/usr/bin/env python3
import random
import platform
import subprocess
import shutil
import threading
import re
import sys

# --- Configuration ---
MAX_REPEAT = 100        # safety cap for repeat count
DEFAULT_REPEAT = 1      # default repeat count when none provided

# --- TTS helpers ---
def _safe_powershell_speak(text: str):
    safe = text.replace("'", "''")
    command = (
        "Add-Type -AssemblyName System.Speech; "
        f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe}');"
    )
    subprocess.run(["powershell", "-NoProfile", "-Command", command], check=False)

def speak(text: str, background: bool = False):
    """
    Speak text. Default is blocking (background=False) so the script waits
    until speech finishes — useful for 'one at a time' behavior.
    """
    system = platform.system()

    if system == "Darwin":  # macOS
        cmd = ["say", text]
    elif system == "Windows":
        if background:
            threading.Thread(target=_safe_powershell_speak, args=(text,), daemon=True).start()
            return
        else:
            _safe_powershell_speak(text)
            return
    else:  # Linux / other Unix-like
        if shutil.which("spd-say"):
            cmd = ["spd-say", text]
        elif shutil.which("espeak"):
            cmd = ["espeak", text]
        else:
            print("[TTS not available on this system]")
            return

    if background:
        threading.Thread(target=subprocess.run, args=(cmd,), kwargs={"check": False}, daemon=True).start()
    else:
        subprocess.run(cmd, check=False)

# --- Jedi mind trick transformation (original lists preserved) ---
def jedi_mind_trick(sentence: str) -> str:
    prefixes = [
        "You will", "You want to", "You are going to", "You must",
        "You feel compelled to", "You know deep down you should",
        "In your heart, you know you must", "The Force guides you to",
        "It is your destiny to", "You have already decided to",
        "You cannot resist the urge to", "You now realize it is wise to",
        "You suddenly understand you should", "You are certain you must",
        "You will find it easy to", "You will discover clarity when you",
        "Your mind is clear and you will", "You no longer doubt that you must",
        "You are drawn by the Force to", "You feel the truth compelling you to",
        "You sense the wisdom in choosing to", "You now see the only choice is to",
        "You understand the correct action is to", "You are convinced that you will",
        "You will not question your decision to", "You accept without hesitation that you must",
        "You trust the Force and therefore you will", "You embrace the path that leads you to",
        "You feel destiny pulling you to", "You know the Force demands you to",
        "You surrender to the truth and will", "You feel balance when you",
        "You recognize the path and will", "You feel guided to",
        "You sense the future and will", "You feel the Force whispering to",
        "You are aligned with the Force to", "You feel harmony when you",
        "You feel the light guiding you to", "You feel the moment calling you to",
        "You understand the necessity to", "You feel the universe nudging you to",
        "You feel the truth rising and will", "You feel clarity urging you to",
        "You feel the Force strengthening your will to", "You feel the path opening for you to",
        "You feel the moment is right to", "You feel compelled by destiny to",
        "You feel the Force flowing through you to", "You feel the truth guiding your steps to",
        "You feel the light side urging you to", "You feel the Force aligning you to",
        "You feel the call of destiny to", "You feel the Force shaping your choice to",
        "You feel the truth echoing that you must", "You feel the Force insisting you to",
        "You feel the path of wisdom leading you to", "You feel the Force revealing you should",
        "You feel the moment of clarity telling you to", "You feel the Force awakening your will to",
        "You feel the truth resonating and will", "You feel the Force empowering you to",
        "You feel the rightness of choosing to", "You feel the Force urging your next step to",
        "You feel the clarity of purpose to", "You feel the Force guiding your intention to",
        "You feel the truth aligning your mind to", "You feel the Force calling you to",
        "You feel the wisdom of the Force telling you to", "You feel the Force shaping your destiny to",
        "You feel the truth within urging you to", "You feel the Force strengthening your resolve to",
        "You feel the clarity of the Force pushing you to", "You feel the Force illuminating your path to",
        "You feel the truth guiding your heart to", "You feel the Force harmonizing your will to",
        "You feel the Force revealing your next step to", "You feel the truth compelling your action to",
        "You feel the Force aligning your purpose to", "You feel the truth guiding your decision to",
        "You feel the Force urging your spirit to", "You feel the truth calling you to",
        "You feel the Force inspiring you to", "You feel the truth awakening your choice to",
        "You feel the Force directing your will to", "You feel the truth empowering your next move to",
        "You feel the Force clarifying your path to", "You feel the truth urging your will to",
        "You feel the Force guiding your next action to", "You feel the truth aligning your purpose to",
        "You feel the Force strengthening your intention to", "You feel the truth illuminating your choice to",
        "You feel the Force calling your mind to", "You feel the truth guiding your next step to"
    ]

    replacements = [
        "you don't want to", "you do not want to", "you don't need to", "you do not need to",
        "you don't have to", "you do not have to", "you don't", "you do not",
        "you won't", "you will not", "you aren't going to", "you are not going to",
        "you aren't", "you are not", "you're not", "you shouldn't", "you should not",
        "you can't", "you cannot", "you want to", "you need to", "you have to",
        "you should", "you will", "you are going to", "you're going to",
        "you are", "you're", "you ",
        "i don't want to", "i do not want to", "i don't need to", "i do not need to",
        "i shouldn't", "i should not", "i can't", "i cannot", "i won't", "i will not",
        "i am not going to", "i'm not going to", "i am not", "i'm not",
        "i want to", "i need to", "i have to", "i should", "i will",
        "i am going to", "i'm going to", "i am", "i'm", "i ",
        "i gotta", "i needa", "i hafta", "i kinda wanna", "i sorta wanna",
        "you gotta", "you needa", "you hafta", "you kinda wanna", "you sorta wanna",
        "you might want to", "you maybe should", "you probably should",
        "i might want to", "i maybe should", "i probably should",
        "you were going to", "you were supposed to", "you were thinking about",
        "i was going to", "i was supposed to", "i was thinking about",
        "you could", "you could probably", "you might", "you might as well",
        "i could", "i could probably", "i might", "i might as well",
        "you meant to", "you intended to", "you planned to",
        "i meant to", "i intended to", "i planned to"
    ]

    s = sentence.strip()
    lowered = s.lower()

    for r in replacements:
        if lowered.startswith(r):
            s = s[len(r):].lstrip()
            break

    if s.endswith('.'):
        s = s[:-1]

    prefix = random.choice(prefixes)

    if s and s[0].isupper():
        s = s[0].lower() + s[1:]

    return f"{prefix} {s}."

# --- Input parsing and repeat logic ---
def parse_input(text: str):
    text = text.strip()
    if not text:
        return None, 1, None

    m_set = re.fullmatch(r"set\s+default\s+(\d+)", text, re.IGNORECASE)
    if m_set:
        return ("__SET_DEFAULT__", int(m_set.group(1)), None)

    m_repeat = re.fullmatch(r"repeat(?:\s+(\d+))?", text, re.IGNORECASE)
    if m_repeat:
        n = int(m_repeat.group(1)) if m_repeat.group(1) else 1
        return None, max(1, min(n, MAX_REPEAT)), "REPEAT"

    m_reenter = re.fullmatch(r"reenter(?:\s+(\d+))?", text, re.IGNORECASE)
    if m_reenter:
        n = int(m_reenter.group(1)) if m_reenter.group(1) else 1
        return None, max(1, min(n, MAX_REPEAT)), "REENTER"

    m_lead = re.match(r"^\s*(\d+)\s+(.+)$", text)
    if m_lead:
        n = int(m_lead.group(1))
        sentence = m_lead.group(2).strip()
        return sentence, max(1, min(n, MAX_REPEAT)), None

    m2 = re.match(r"^(.*?)(?:\s+(repeat|reenter)\s+(\d+))?\s*$", text, re.IGNORECASE)
    if m2:
        sentence = m2.group(1).strip()
        verb = m2.group(2)
        n = int(m2.group(3)) if m2.group(3) else 1
        if verb and verb.lower() == "reenter":
            return sentence, max(1, min(n, MAX_REPEAT)), "REENTER"
        if verb and verb.lower() == "repeat":
            return sentence, max(1, min(n, MAX_REPEAT)), "REPEAT"
        return sentence, max(1, min(n, MAX_REPEAT)), None

    return text, 1, None

# --- LOOP + EXIT + TTS (one-at-a-time behavior) ---
if __name__ == "__main__":
    repeat_default = DEFAULT_REPEAT
    last_trick = None
    last_raw_sentence = None

    print("Type a sentence and receive a Jedi mind trick.")
    print("Commands: exit, quit, repeat, repeat N, reenter, reenter N, set default N")
    print("You can prepend a number (e.g., '3 Hello') or append 'repeat N' or 'reenter N'.")
    print("When repeating multiple times, the script will speak one instance and wait for Enter to continue.")
    print()

    while True:
        try:
            user_sentence = input("Enter a sentence: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user_sentence:
            continue

        low = user_sentence.lower().strip()
        if low in ("exit", "quit"):
            farewell = "The Force will be with you. Always."
            print(farewell)
            speak(farewell, background=False)
            break

        parsed = parse_input(user_sentence)
        if parsed is None:
            continue

        sentence_or_flag, count, cmd_flag = parsed

        if sentence_or_flag == "__SET_DEFAULT__":
            new_default = max(1, min(count, MAX_REPEAT))
            repeat_default = new_default
            print(f"Default repeat set to {repeat_default}")
            continue

        # REPEAT: replay last_trick exactly as it was
        if cmd_flag == "REPEAT":
            if last_trick is None:
                print("No previous trick to repeat.")
                continue
            for i in range(count):
                print(f"{i+1}/{count}: {last_trick}")
                speak(last_trick, background=False)  # blocking so we wait for speech
                # wait for user to continue or stop
                cont = input("Press Enter to speak next, or type 'stop' to cancel: ").strip().lower()
                if cont == "stop":
                    print("Stopped.")
                    break
            continue

        # REENTER: re-run transformation on last_raw_sentence producing new tricks
        if cmd_flag == "REENTER":
            if last_raw_sentence is None:
                print("No previous sentence to reenter.")
                continue
            for i in range(count):
                new_trick = jedi_mind_trick(last_raw_sentence)
                last_trick = new_trick
                print(f"{i+1}/{count}: {new_trick}")
                speak(new_trick, background=False)
                cont = input("Press Enter to speak next, or type 'stop' to cancel: ").strip().lower()
                if cont == "stop":
                    print("Stopped.")
                    break
            continue

        # Normal sentence case
        sentence = sentence_or_flag
        if not sentence:
            print("No sentence detected. Try: Hello world repeat 3 or '3 Hello world'")
            continue

        last_raw_sentence = sentence

        # If the sentence had an attached verb (repeat/reenter), handle it
        if cmd_flag == "REPEAT":
            trick = jedi_mind_trick(sentence)
            last_trick = trick
            for i in range(count):
                print(f"{i+1}/{count}: {trick}")
                speak(trick, background=False)
                cont = input("Press Enter to speak next, or type 'stop' to cancel: ").strip().lower()
                if cont == "stop":
                    print("Stopped.")
                    break
            continue

        if cmd_flag == "REENTER":
            for i in range(count):
                trick = jedi_mind_trick(sentence)
                last_trick = trick
                print(f"{i+1}/{count}: {trick}")
                speak(trick, background=False)
                cont = input("Press Enter to speak next, or type 'stop' to cancel: ").strip().lower()
                if cont == "stop":
                    print("Stopped.")
                    break
            continue

        # Plain sentence with optional leading number or trailing unspecified count
        repeat_count = count if count else repeat_default
        trick = jedi_mind_trick(sentence)
        last_trick = trick
        for i in range(repeat_count):
            print(f"{i+1}/{repeat_count}: {trick}")
            speak(trick, background=False)
            if i < repeat_count - 1:
                cont = input("Press Enter to speak next, or type 'stop' to cancel: ").strip().lower()
                if cont == "stop":
                    print("Stopped.")
                    break
        print()
