"""
Alchemy Recipe Generator — 100 Handcrafted Ingredients
- Run: python alchemy_100_handcrafted.py
- Enter symptoms (comma separated) when prompted, e.g.:
    cough, fatigue
- Type 'exit', 'quit', or 'q' at any prompt to quit.
This version builds a full INGREDIENTS dictionary with 100 distinct entries.
"""

import random
import textwrap
import sys

random.seed(42)

# --- Symptom pool and benefit phrase templates (same as before) ---
SYMPTOMS = [
    "fatigue", "insomnia", "anxiety", "cough", "sore throat", "cold",
    "wounds", "headache", "nausea", "digestion", "poison", "strength",
    "focus", "memory", "fever", "inflammation", "allergy", "stress",
    "muscle ache", "joint pain", "dizziness", "respiratory", "skin rash",
    "bleeding", "chill", "thirst", "hunger", "clarity", "calm", "vision"
]

BENEFIT_PHRASES = {
    "fatigue": "restores energy and clears mental fog",
    "insomnia": "induces restful sleep and quiets the mind",
    "anxiety": "calms racing thoughts and soothes nerves",
    "cough": "soothes the throat and reduces coughing fits",
    "sore throat": "coats and calms inflamed throat tissue",
    "cold": "warms the body and eases congestion",
    "wounds": "promotes clotting and accelerates tissue repair",
    "headache": "eases tension and dulls throbbing pain",
    "nausea": "settles the stomach and reduces queasiness",
    "digestion": "soothes cramps and aids digestion",
    "poison": "counteracts common toxins and neutralizes venoms",
    "strength": "temporarily boosts physical resilience",
    "focus": "sharpens attention and reduces mental fog",
    "memory": "improves recall and mental clarity",
    "fever": "cools the body and reduces elevated temperature",
    "inflammation": "reduces swelling and eases heat",
    "allergy": "reduces hist-like reactions and calms irritation",
    "stress": "lowers stress response and steadies breathing",
    "muscle ache": "relaxes tense muscles and eases soreness",
    "joint pain": "lubricates joints and reduces stiffness",
    "dizziness": "stabilizes balance and clears head fog",
    "respiratory": "opens airways and eases breathing",
    "skin rash": "soothes irritated skin and reduces redness",
    "bleeding": "helps staunch bleeding and strengthen vessels",
    "chill": "restores warmth and counters shivering",
    "thirst": "replenishes fluids and soothes dry mouth",
    "hunger": "stimulates appetite gently",
    "clarity": "brings mental clarity and removes haze",
    "calm": "induces calm without heavy sedation",
    "vision": "sharpens sight and reduces eye strain"
}

# --- A handcrafted set of 100 ingredients ---
# Each entry: "description", "benefits" (symptom -> short phrase), "rarity" (1-10)
INGREDIENTS = {
    "Moonwort": {
        "description": "Silver-leaved herb that glows faintly under moonlight.",
        "benefits": {"insomnia": "calms the mind and eases sleep", "fatigue": "restorative tonic"},
        "rarity": 2
    },
    "DragonScale Powder": {
        "description": "Fine dust from shed dragon scales; warm to the touch.",
        "benefits": {"wounds": "promotes rapid clotting and tissue mending", "strength": "temporary boost to resilience"},
        "rarity": 9
    },
    "Amberdew": {
        "description": "Sticky golden resin collected at dawn from ancient pines.",
        "benefits": {"cough": "soothes throat and reduces coughing", "sore throat": "coats inflamed tissue"},
        "rarity": 4
    },
    "Starlit Moss": {
        "description": "Soft moss that shimmers with tiny specks like stars.",
        "benefits": {"wounds": "antiseptic and cooling", "headache": "eases tension"},
        "rarity": 3
    },
    "Phoenix Ash": {
        "description": "Ash from a phoenix feather; faintly warm and fragrant.",
        "benefits": {"fatigue": "revives energy and clears mental fog", "poison": "antidotal properties"},
        "rarity": 10
    },
    "Glimmerroot": {
        "description": "A root with veins of pale light; tastes faintly sweet.",
        "benefits": {"digestion": "soothes stomach cramps", "nausea": "settles queasy stomach"},
        "rarity": 2
    },
    "Nightbloom Petals": {
        "description": "Black-violet petals that open only at night.",
        "benefits": {"insomnia": "induces deep sleep", "anxiety": "calming aroma"},
        "rarity": 5
    },
    "Ironbark Shavings": {
        "description": "Hard shavings from an ancient ironwood tree.",
        "benefits": {"wounds": "adds structural strength to salves", "strength": "improves endurance"},
        "rarity": 3
    },
    "Silverleaf": {
        "description": "Thin leaves with a silver sheen; cool when crushed.",
        "benefits": {"fever": "cools the body", "inflammation": "reduces swelling"},
        "rarity": 4
    },
    "Sunpetal": {
        "description": "Bright yellow petals that hold warmth from sunlight.",
        "benefits": {"chill": "restores warmth", "fatigue": "gentle energizer"},
        "rarity": 2
    },
    "Frostvine": {
        "description": "A creeping vine that crystallizes in cold air.",
        "benefits": {"fever": "lowers temperature", "inflammation": "eases heat"},
        "rarity": 6
    },
    "Stormberry": {
        "description": "Small dark berries that crackle faintly when crushed.",
        "benefits": {"respiratory": "opens airways", "cough": "reduces spasms"},
        "rarity": 5
    },
    "Shadowmoss": {
        "description": "Deep green moss found in shaded grottos.",
        "benefits": {"skin rash": "soothes irritated skin", "wounds": "mild antiseptic"},
        "rarity": 3
    },
    "Brightreed": {
        "description": "Tall reed with a luminous core used in tonics.",
        "benefits": {"clarity": "brings mental clarity", "focus": "sharpens attention"},
        "rarity": 2
    },
    "Gloomroot": {
        "description": "Dark, fibrous root that tastes bitter and grounding.",
        "benefits": {"anxiety": "calms nerves", "stress": "lowers stress response"},
        "rarity": 4
    },
    "Seaspray Salt": {
        "description": "Crystalline salt harvested from storm-tossed shores.",
        "benefits": {"thirst": "replenishes electrolytes", "skin rash": "cleansing when diluted"},
        "rarity": 1
    },
    "Oakheart Bark": {
        "description": "Thick bark from an ancient oak, heavy and fibrous.",
        "benefits": {"bleeding": "helps staunch bleeding", "strength": "adds resilience"},
        "rarity": 3
    },
    "Pineamber": {
        "description": "Amber-like resin with a pine scent.",
        "benefits": {"respiratory": "clears congestion", "cough": "soothes airways"},
        "rarity": 4
    },
    "Embergrain": {
        "description": "Tiny ember-like seeds that glow faintly when heated.",
        "benefits": {"cold": "generates internal warmth", "chill": "counters shivering"},
        "rarity": 6
    },
    "Ashflower": {
        "description": "Pale flower that grows in volcanic soil.",
        "benefits": {"fever": "cools and steadies temperature", "inflammation": "reduces swelling"},
        "rarity": 7
    },
    "Crystal Dew": {
        "description": "Morning dew collected from crystal petals.",
        "benefits": {"thirst": "replenishes fluids", "clarity": "clears head fog"},
        "rarity": 2
    },
    "Thornvine Sap": {
        "description": "Sticky sap from a thorned vine; bitter and potent.",
        "benefits": {"wounds": "antiseptic and sealing", "bleeding": "helps clotting"},
        "rarity": 5
    },
    "Pearlshard": {
        "description": "Tiny iridescent fragments from deep-sea pearls.",
        "benefits": {"vision": "reduces eye strain", "clarity": "sharpens perception"},
        "rarity": 8
    },
    "Reedmist": {
        "description": "A light mist condensed from marsh reeds.",
        "benefits": {"respiratory": "eases breathing", "cough": "soothes throat"},
        "rarity": 2
    },
    "Bitterleaf": {
        "description": "Astringent leaf with a strong bitter taste.",
        "benefits": {"digestion": "aids digestion", "nausea": "reduces queasiness"},
        "rarity": 1
    },
    "Honeyspice": {
        "description": "Sweet, warm spice crystals often used in syrups.",
        "benefits": {"sore throat": "coats and calms", "cough": "reduces irritation"},
        "rarity": 2
    },
    "Velvetmoss": {
        "description": "Soft moss that cushions and cools skin.",
        "benefits": {"skin rash": "soothes redness", "wounds": "gentle antiseptic"},
        "rarity": 3
    },
    "Ironroot": {
        "description": "Dense root with metallic flecks; tastes faintly of iron.",
        "benefits": {"strength": "boosts endurance", "bleeding": "supports vessel strength"},
        "rarity": 4
    },
    "Lavendusk": {
        "description": "Dusky lavender buds that smell of dusk and rain.",
        "benefits": {"anxiety": "calming aroma", "insomnia": "promotes sleep"},
        "rarity": 2
    },
    "Cinderpetal": {
        "description": "Charred-looking petal that retains warmth.",
        "benefits": {"muscle ache": "relaxes tense muscles", "joint pain": "eases stiffness"},
        "rarity": 6
    },
    "Mirthroot": {
        "description": "A knotted root said to lift the spirits.",
        "benefits": {"stress": "lowers stress response", "anxiety": "soothes nerves"},
        "rarity": 3
    },
    "Glassfern": {
        "description": "A fern with translucent fronds that tinkle faintly.",
        "benefits": {"headache": "eases tension", "clarity": "clears mental haze"},
        "rarity": 5
    },
    "Sagegrain": {
        "description": "Tiny seeds with a sharp, savory scent.",
        "benefits": {"digestion": "aids digestion", "memory": "supports recall"},
        "rarity": 2
    },
    "Willowash": {
        "description": "A pale sap from willow branches, slightly bitter.",
        "benefits": {"fever": "reduces temperature", "inflammation": "eases swelling"},
        "rarity": 3
    },
    "Mossheart": {
        "description": "A dense cushion of moss found in hidden hollows.",
        "benefits": {"wounds": "promotes healing", "skin rash": "soothes irritation"},
        "rarity": 2
    },
    "Brambleberry": {
        "description": "Tart berries that stain fingers purple.",
        "benefits": {"hunger": "stimulates appetite", "thirst": "refreshing when stewed"},
        "rarity": 1
    },
    "Sootleaf": {
        "description": "Dark leaf with a faint smoky scent.",
        "benefits": {"respiratory": "clears airways", "cough": "reduces phlegm"},
        "rarity": 4
    },
    "Goldpetal": {
        "description": "Soft golden petals prized for ceremonial tonics.",
        "benefits": {"fatigue": "gentle restorative", "clarity": "improves focus"},
        "rarity": 7
    },
    "Hearthroot": {
        "description": "A warming root often used in winter brews.",
        "benefits": {"cold": "generates internal warmth", "chill": "counters shivering"},
        "rarity": 2
    },
    "Mistbloom": {
        "description": "A pale bloom that forms only in foggy valleys.",
        "benefits": {"insomnia": "soft sedative", "anxiety": "calming influence"},
        "rarity": 6
    },
    "Thundersap": {
        "description": "A viscous sap that hums faintly when poured.",
        "benefits": {"strength": "temporary vigor boost", "fatigue": "restorative when diluted"},
        "rarity": 9
    },
    "Coppershard": {
        "description": "Small metallic flakes with a warm glow.",
        "benefits": {"bleeding": "helps clotting", "strength": "supports stamina"},
        "rarity": 6
    },
    "Iceroot": {
        "description": "A pale root that chills the hand when held.",
        "benefits": {"fever": "cools rapidly", "inflammation": "reduces heat"},
        "rarity": 5
    },
    "Marigold Dust": {
        "description": "Powdered marigold petals used in poultices.",
        "benefits": {"skin rash": "reduces redness", "wounds": "promotes surface healing"},
        "rarity": 2
    },
    "Breezeleaf": {
        "description": "Thin leaves that flutter even in still air.",
        "benefits": {"respiratory": "opens airways", "dizziness": "stabilizes balance"},
        "rarity": 3
    },
    "Sootroot": {
        "description": "Dark, charcoal-like root used in strong salves.",
        "benefits": {"poison": "aids detoxification", "wounds": "cleanses infection"},
        "rarity": 8
    },
    "Ambergrain": {
        "description": "Small amber-like seeds with a sweet scent.",
        "benefits": {"thirst": "replenishes fluids", "hunger": "mild appetite stimulant"},
        "rarity": 2
    },
    "Nightglass": {
        "description": "A brittle crystal that absorbs moonlight.",
        "benefits": {"vision": "sharpens sight at night", "clarity": "clears mental haze"},
        "rarity": 9
    },
    "Sundew Syrup": {
        "description": "Sticky syrup collected from sun-drenched plants.",
        "benefits": {"sore throat": "coats and soothes", "cough": "reduces irritation"},
        "rarity": 3
    },
    "Basilisk Scale": {
        "description": "A rare scale fragment with a faint shimmer.",
        "benefits": {"poison": "neutralizes certain venoms", "strength": "restores vigor"},
        "rarity": 10
    },
    "Willowbloom": {
        "description": "Delicate white blooms from river willows.",
        "benefits": {"insomnia": "gentle sleep aid", "stress": "calming"},
        "rarity": 3
    },
    "Copperleaf": {
        "description": "Leaves with a faint metallic taste.",
        "benefits": {"bleeding": "supports clotting", "iron deficiency": "mild tonic"},
        "rarity": 4
    },
    "Fennelspice": {
        "description": "Aromatic seeds used to settle the stomach.",
        "benefits": {"digestion": "aids digestion", "nausea": "reduces queasiness"},
        "rarity": 1
    },
    "Gale Petal": {
        "description": "Thin petals that flutter like a breeze.",
        "benefits": {"dizziness": "stabilizes balance", "clarity": "clears head fog"},
        "rarity": 5
    },
    "Mosswine": {
        "description": "A fermented moss extract used in small doses.",
        "benefits": {"fatigue": "restorative tonic", "hunger": "stimulates appetite"},
        "rarity": 6
    },
    "Sableroot": {
        "description": "Dark root prized by apothecaries for potency.",
        "benefits": {"pain": "reduces muscle ache", "joint pain": "eases stiffness"},
        "rarity": 7
    },
    "Ivorypetal": {
        "description": "Pale petals that feel like silk to the touch.",
        "benefits": {"anxiety": "calming", "insomnia": "promotes restful sleep"},
        "rarity": 6
    },
    "Thornash": {
        "description": "Powdered ash from thorn bushes; sharp scent.",
        "benefits": {"wounds": "cleans and dries", "bleeding": "helps staunch"},
        "rarity": 4
    },
    "Moonwater": {
        "description": "Water collected under a full moon; faintly luminous.",
        "benefits": {"clarity": "clears mental haze", "vision": "sharpens sight"},
        "rarity": 8
    },
    "Sagebloom": {
        "description": "A fragrant bloom used in memory tonics.",
        "benefits": {"memory": "improves recall", "focus": "sharpens attention"},
        "rarity": 3
    },
    "Ravenfeather Dust": {
        "description": "Fine black dust from ritual feathers.",
        "benefits": {"poison": "aids neutralization", "clarity": "removes haze"},
        "rarity": 9
    },
    "Copperroot": {
        "description": "Root with coppery veins; earthy taste.",
        "benefits": {"bleeding": "supports clotting", "strength": "adds resilience"},
        "rarity": 5
    },
    "Dewvine": {
        "description": "A vine that collects heavy morning dew.",
        "benefits": {"thirst": "replenishes fluids", "skin rash": "soothes irritation"},
        "rarity": 2
    },
    "Sootpetal": {
        "description": "Dark petal with a faint smoky aftertaste.",
        "benefits": {"respiratory": "eases breathing", "cough": "reduces phlegm"},
        "rarity": 4
    },
    "Glimmerleaf": {
        "description": "Leaves that glint like tiny mirrors.",
        "benefits": {"vision": "reduces eye strain", "clarity": "improves focus"},
        "rarity": 6
    },
    "Brambleash": {
        "description": "Powdered bramble stems used in strong poultices.",
        "benefits": {"wounds": "promotes surface healing", "skin rash": "reduces redness"},
        "rarity": 3
    },
    "Sunsap": {
        "description": "Warm sap that tastes faintly of citrus.",
        "benefits": {"fatigue": "gentle energizer", "hunger": "stimulates appetite"},
        "rarity": 2
    },
    "Nightpepper": {
        "description": "Small dark pods with a sharp, warming bite.",
        "benefits": {"cold": "generates warmth", "digestion": "aids digestion"},
        "rarity": 5
    },
    "Frostpetal": {
        "description": "Pale blue petals that feel cool to the touch.",
        "benefits": {"fever": "cools quickly", "inflammation": "reduces swelling"},
        "rarity": 6
    },
    "Stonebloom": {
        "description": "A tough bloom that grows from rocky soil.",
        "benefits": {"joint pain": "eases stiffness", "strength": "supports endurance"},
        "rarity": 4
    },
    "Mireleaf": {
        "description": "A heavy leaf from marsh plants, slightly oily.",
        "benefits": {"skin rash": "soothes irritation", "respiratory": "clears mucus"},
        "rarity": 3
    },
    "Goldroot": {
        "description": "A bright root used in ceremonial remedies.",
        "benefits": {"fatigue": "restorative tonic", "clarity": "sharpens mind"},
        "rarity": 8
    },
    "Windshard": {
        "description": "A sliver of glass-like mineral that hums in wind.",
        "benefits": {"dizziness": "stabilizes balance", "clarity": "clears head fog"},
        "rarity": 7
    },
    "Mender's Thread": {
        "description": "Fibrous thread used to bind wounds in folk remedies.",
        "benefits": {"wounds": "supports closure", "bleeding": "helps staunch"},
        "rarity": 2
    },
    "Sootgrain": {
        "description": "Dark grain with a smoky aroma when toasted.",
        "benefits": {"hunger": "stimulates appetite", "thirst": "satisfying when brewed"},
        "rarity": 1
    },
    "Lunarglass": {
        "description": "A pale glass fragment that cools skin on contact.",
        "benefits": {"fever": "cools rapidly", "inflammation": "reduces heat"},
        "rarity": 9
    },
    "Breezeberry": {
        "description": "Light, airy berries that pop with a breeze-like snap.",
        "benefits": {"dizziness": "stabilizes balance", "clarity": "clears head fog"},
        "rarity": 3
    },
    "Stoneleaf": {
        "description": "Thick, leathery leaves that resist decay.",
        "benefits": {"joint pain": "eases stiffness", "muscle ache": "relaxes soreness"},
        "rarity": 4
    },
    "Elderbloom": {
        "description": "Fragrant elderflower used in many household remedies.",
        "benefits": {"cold": "eases congestion", "fever": "reduces temperature"},
        "rarity": 2
    },
    "Nightroot": {
        "description": "A deep purple root harvested at midnight.",
        "benefits": {"insomnia": "promotes sleep", "anxiety": "calms nerves"},
        "rarity": 6
    },
    "Searing Petal": {
        "description": "A red petal that warms quickly when handled.",
        "benefits": {"muscle ache": "relaxes tense muscles", "cold": "adds warmth"},
        "rarity": 5
    },
    "Mender's Balm": {
        "description": "A thick balm base used to combine healing herbs.",
        "benefits": {"wounds": "supports healing", "skin rash": "soothes irritation"},
        "rarity": 2
    },
    "Glimmergrain": {
        "description": "Tiny shimmering seeds used in clarity tonics.",
        "benefits": {"focus": "sharpens attention", "memory": "supports recall"},
        "rarity": 7
    },
    "Fallowroot": {
        "description": "A pale root found in fallow fields, earthy and mild.",
        "benefits": {"digestion": "aids digestion", "nausea": "settles stomach"},
        "rarity": 1
    },
    "Sablepetal": {
        "description": "Dark velvety petals prized for calming infusions.",
        "benefits": {"anxiety": "calms nerves", "insomnia": "induces sleep"},
        "rarity": 6
    },
    "Verdant Sap": {
        "description": "A bright green sap that smells of fresh cut grass.",
        "benefits": {"inflammation": "reduces swelling", "skin rash": "soothes redness"},
        "rarity": 3
    },
    "Hollow Reed": {
        "description": "A hollow reed used to distill light essences.",
        "benefits": {"respiratory": "opens airways", "cough": "soothes throat"},
        "rarity": 2
    },
    "Morningshade": {
        "description": "A pale herb gathered at first light.",
        "benefits": {"fatigue": "gentle restorative", "clarity": "clears morning fog"},
        "rarity": 2
    },
    "Tidepearl": {
        "description": "Small pearls formed in tidal pools, cool and smooth.",
        "benefits": {"vision": "reduces eye strain", "clarity": "sharpens perception"},
        "rarity": 8
    },
    "Bitterbloom": {
        "description": "A sharp-flavored bloom used sparingly in tonics.",
        "benefits": {"digestion": "aids digestion", "nausea": "reduces queasiness"},
        "rarity": 2
    },
    "Wyrmroot": {
        "description": "A gnarled root rumored to have dragon-touched properties.",
        "benefits": {"strength": "boosts resilience", "poison": "aids neutralization"},
        "rarity": 10
    },
    "Silversap": {
        "description": "A pale sap that leaves a cooling film on skin.",
        "benefits": {"fever": "cools quickly", "inflammation": "reduces heat"},
        "rarity": 5
    },
    "Hearthpetal": {
        "description": "A warm-hued petal often used in comfort brews.",
        "benefits": {"fatigue": "restorative", "hunger": "stimulates appetite"},
        "rarity": 2
    },
    "Galegrain": {
        "description": "Light grains that whistle when poured.",
        "benefits": {"dizziness": "stabilizes balance", "clarity": "clears head fog"},
        "rarity": 4
    },
    "Mender's Threadseed": {
        "description": "Tiny seeds used to thicken salves and bind poultices.",
        "benefits": {"wounds": "supports closure", "skin rash": "soothes"},
        "rarity": 1
    },
    "Starvine": {
        "description": "A vine that blooms with tiny star-shaped flowers.",
        "benefits": {"vision": "sharpens sight", "clarity": "improves focus"},
        "rarity": 6
    },
    "Dawnpetal": {
        "description": "Soft petals that open at first light, faintly sweet.",
        "benefits": {"insomnia": "gentle sleep aid", "anxiety": "calming"},
        "rarity": 3
    },
    "Riftstone": {
        "description": "A dark stone with a faint inner glow.",
        "benefits": {"strength": "supports endurance", "fatigue": "restorative when powdered"},
        "rarity": 9
    },
    "Mossamber": {
        "description": "Amber infused with mossy scents, warm and resinous.",
        "benefits": {"sore throat": "coats and soothes", "cough": "reduces irritation"},
        "rarity": 4
    },
    "Quietleaf": {
        "description": "A soft leaf that muffles sound when crushed.",
        "benefits": {"anxiety": "calms racing thoughts", "stress": "lowers tension"},
        "rarity": 3
    },
    "Frostgrain": {
        "description": "Pale grains that chill the tongue when eaten.",
        "benefits": {"fever": "cools body", "inflammation": "reduces heat"},
        "rarity": 5
    },
    "Sundew Petal": {
        "description": "A sticky petal that traps small insects; sweet aroma.",
        "benefits": {"sore throat": "coats and calms", "cough": "soothes"},
        "rarity": 4
    },
    "Ebonroot": {
        "description": "A deep black root used in potent antidotes.",
        "benefits": {"poison": "strong antidotal properties", "fatigue": "restorative"},
        "rarity": 10
    }
}

# --- Utility functions (same logic as earlier) ---
def normalize_symptom(s):
    return s.strip().lower()

def score_ingredient_for_symptoms(ingredient, symptoms):
    benefits = INGREDIENTS[ingredient]["benefits"]
    score = 0
    for s in symptoms:
        if s in benefits:
            score += 10
    score -= INGREDIENTS[ingredient].get("rarity", 0) * 0.5
    score += random.uniform(-1, 1)
    return score

def suggest_recipe(symptoms, n_ingredients=3):
    symptoms = [normalize_symptom(s) for s in symptoms if s.strip()]
    if not symptoms:
        symptoms = ["fatigue"]

    scored = []
    for ing in INGREDIENTS:
        sc = score_ingredient_for_symptoms(ing, symptoms)
        scored.append((sc, ing))
    scored.sort(reverse=True, key=lambda x: x[0])

    top_pool = [ing for _, ing in scored[:max(6, n_ingredients)]]
    chosen = []
    while len(chosen) < n_ingredients and top_pool:
        pick = random.choice(top_pool)
        if pick not in chosen:
            chosen.append(pick)
        else:
            top_pool.remove(pick)

    recipe = []
    for ing in chosen:
        benefits = INGREDIENTS[ing]["benefits"]
        matched = [f"**{s}**: {benefits[s]}" for s in symptoms if s in benefits]
        if matched:
            reason = "; ".join(matched)
        else:
            primary = list(benefits.items())[:2]
            reason = "; ".join(f"**{k}**: {v}" for k, v in primary)
        recipe.append((ing, INGREDIENTS[ing]["description"], reason))
    return recipe

def format_recipe(recipe, symptoms):
    header = f"Alchemy Recipe for: {', '.join(symptoms)}"
    lines = [header, "-" * len(header)]
    for i, (name, desc, reason) in enumerate(recipe, 1):
        lines.append(f"{i}. {name} — {desc}")
        lines.append(f"   Benefits: {reason}")
    return "\n".join(lines)

def prompt_int(prompt_text, default):
    while True:
        val = input(prompt_text).strip()
        if val.lower() in ("exit", "quit", "q"):
            return None
        if val == "":
            return default
        try:
            n = int(val)
            return max(1, n)
        except ValueError:
            print("Invalid number, please enter an integer, or press Enter for default, or type 'exit' to quit.")

def parse_symptoms_input(user_input):
    if not user_input:
        return []
    return [s for s in user_input.split(",")]

# --- Main loop with repeat and exit ---
def main():
    print("=== Alchemy Recipe Generator (100 handcrafted ingredients) ===")
    print("Type 'exit', 'quit', or 'q' at any prompt to quit.")
    while True:

        print ("\nfatigue,", "insomnia,", "anxiety,", "cough,", "sore throat,", "cold,",
    "wounds,", "headache,", "nausea,", "digestion,", "poison,", "strength,",
    "focus,", "memory,", "fever,", "inflammation,", "allergy,", "stress,",
    "muscle ache,", "joint pain,", "dizziness,", "respiratory,", "skin rash,",
    "bleeding,", "chill,", "thirst,", "hunger,", "clarity,", "calm,", "vision")

        user_input = input("\nEnter symptoms (comma separated), or press Enter for a general tonic: ").strip()
        if user_input.lower() in ("exit", "quit", "q"):
            print("\nGoodbye. Stay curious.")
            break

        symptoms = parse_symptoms_input(user_input)
        n = prompt_int("How many ingredients? (press Enter for 3): ", 3)
        if n is None:
            print("\nGoodbye. Stay curious.")
            break

        recipe = suggest_recipe(symptoms, n_ingredients=n)
        print()
        print(format_recipe(recipe, [normalize_symptom(s) for s in symptoms if s.strip()] or ["fatigue"]))
        print()
        print(textwrap.fill("Tip: press Enter to generate another recipe, or type 'exit' to quit. Remove random.seed for more variety.", 70))
        cont = input("\nPress Enter to generate another recipe, or type 'exit' to quit: ").strip()
        if cont.lower() in ("exit", "quit", "q"):
            print("\nGoodbye. Stay curious.")
            break

if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\n\nGoodbye. Stay curious.")
        sys.exit(0)
