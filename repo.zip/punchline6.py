#!/usr/bin/env python3
"""
random_joke_generator_100_tts_one_by_one.py
Speak one random joke at a time. Press Enter for the next joke, type 'exit' to quit.
Uses system TTS (macOS say, Linux spd-say/espeak, Windows PowerShell System.Speech).
No external Python packages required.
"""

import random
import platform
import subprocess
import argparse
import sys
import os
from datetime import datetime

# --- 100-joke library (unchanged) ---
LIBRARY = [
    "I told my computer I needed a break; it said 'No problem, I'll go to sleep.'",
    "Parallel lines have so much in common. It’s a shame they’ll never meet.",
    "My boss told me to have a good day, so I went home.",
    "I used to play piano by ear, but now I use my hands.",
    "I’m reading a book about anti-gravity. It’s impossible to put down.",
    "I asked the librarian if the library had books on paranoia. She whispered, 'They're right behind you.'",
    "I told my wife she was drawing her eyebrows too high. She looked surprised.",
    "I have a split personality,' said Tom, being Frank.",
    "I stayed up all night to see where the sun went. Then it dawned on me.",
    "I told a chemistry joke. There was no reaction.",
    "I used to be a baker, but I couldn't make enough dough.",
    "I don't trust stairs — they're always up to something.",
    "I tried to catch fog yesterday. I mist.",
    "I told my suitcase there will be no vacation this year. Now I'm dealing with emotional baggage.",
    "I have a photographic memory; I just haven't developed it yet.",
    "I once swallowed a dictionary. It gave me thesaurus throat I've ever had.",
    "I asked the gym instructor if he could teach me to do the splits. He said, 'How flexible are you?' I said, 'I can't make Tuesdays.'",
    "I told my phone it was being dramatic. It started buffering.",
    "I used to be indecisive. Now I'm not sure.",
    "I bought some shoes from a drug dealer. I don't know what he laced them with, but I was tripping all day.",
    "I told my computer I needed a break; it installed updates.",
    "I named my dog 'Five Miles' so I can tell people I walk Five Miles every day.",
    "I asked the scarecrow if he was happy. He said he was outstanding in his field.",
    "I told my calendar I was busy. It gave me a date anyway.",
    "I tried to write a joke about a broken pencil but it was pointless.",
    "Why did the chicken cross the road? To get to the other side.",
    "Why don't scientists trust atoms? Because they make up everything.",
    "Why did the scarecrow win an award? Because he was outstanding in his field.",
    "Why don't skeletons fight each other? They don't have the guts.",
    "Why did the math book look sad? It had too many problems.",
    "Why did the tomato blush? Because it saw the salad dressing.",
    "Why did the bicycle fall over? It was two tired.",
    "Why did the golfer bring two pairs of pants? In case he got a hole in one.",
    "Why did the coffee file a police report? It got mugged.",
    "Why did the cookie go to the doctor? It felt crummy.",
    "Why did the computer go to the doctor? It had a virus.",
    "Why did the stadium get hot after the game? All the fans left.",
    "Why did the picture go to jail? Because it was framed.",
    "Why did the student eat his homework? Because the teacher said it was a piece of cake.",
    "Why did the mushroom get invited to the party? Because he's a fungi.",
    "Why did the belt go to jail? For holding up a pair of pants.",
    "Why did the calendar go to therapy? Its days were numbered.",
    "Why did the cookie cry? Because his mom was a wafer so long.",
    "Why did the computer show up at work late? It had a hard drive.",
    "Why did the music teacher need a ladder? To reach the high notes.",
    "Why did the bee get married? Because he found his honey.",
    "Why did the pencil cross the road? To get to the point.",
    "Why did the astronaut break up with his girlfriend? He needed space.",
    "Why did the grape stop in the middle of the road? It ran out of juice.",
    "Why did the frog take the bus to work? His car got toad away.",
    "Knock knock. Who's there? Lettuce. Lettuce who? Lettuce in, it's cold out here!",
    "Knock knock. Who's there? Boo. Boo who? Don't cry, it's just a joke.",
    "Knock knock. Who's there? Cow says. Cow says who? No, cow says mooooo!",
    "Knock knock. Who's there? Tank. Tank who? You're welcome.",
    "Knock knock. Who's there? Olive. Olive who? Olive you and I miss you.",
    "Person A: 'I have a split personality.' Person B: 'Me too.'",
    "A: 'I told my wife she should embrace her mistakes.' B: 'She gave me a hug.'",
    "A: 'I have a joke about construction.' B: 'I'm still working on it.'",
    "A: 'I used to be a baker.' B: 'What happened?' A: 'I couldn't make enough dough.'",
    "A: 'I got a job at the bakery.' B: 'Nice.' A: 'I kneaded it.'",
    "A: 'My friend wants to become an archaeologist.' B: 'That's a dig idea.'",
    "A: 'I got a job at the orange juice factory.' B: 'How's it going?' A: 'I can't concentrate.'",
    "A: 'I tried to catch fog.' B: 'How'd that go?' A: 'I mist.'",
    "A: 'I told a joke about a roof.' B: 'How'd it land?' A: 'It went over their heads.'",
    "A: 'I used to be a banker.' B: 'Why did you leave?' A: 'I lost interest.'",
    "A: 'I bought a boat.' B: 'How's it going?' A: 'It's a sail of two cities.'",
    "A: 'I started a band called 999 Megabytes.' B: 'How's that?' A: 'We haven't gotten a gig yet — we only have 999.'",
    "A: 'I got a job at a calendar factory.' B: 'Is it steady?' A: 'Yeah, days are numbered.'",
    "A: 'I told my dog a joke.' B: 'Did he laugh?' A: 'He barked up the wrong tree.'",
    "A: 'I tried to write a joke about time travel.' B: 'How'd it go?' A: 'You already heard it.'",
    "A man walks into a bar. Ouch.",
    "A termite walks into a bar and asks, 'Is the bartender here?'",
    "A dyslexic man walks into a bra.",
    "A magician was driving down the road and turned into a driveway.",
    "Two antennas met on a roof, fell in love and got married. The ceremony wasn't much, but the reception was excellent.",
    "I told my wife she should embrace her mistakes. She hugged me.",
    "I asked the gym instructor if he could teach me to do the splits. He said, 'How flexible are you?' I said, 'I can't make Tuesdays.'",
    "A sandwich walks into a bar. The bartender says, 'Sorry, we don't serve food here.'",
    "A man asked the librarian if the library had books on turtles. She said, 'Hardback.'",
    "A man tried to sue an airline for losing his luggage. He lost his case.",
    "A man told his doctor he broke his arm in two places. The doctor told him to stop going to those places.",
    "A man put his money in the blender. He wanted to make liquid assets.",
    "A man told his wife she was drawing her eyebrows too high. She looked surprised.",
    "A man asked his dog what's two minus two. The dog said nothing.",
    "A man told his computer he needed a break. It installed updates.",
    "That's what she said.",
    "Take my wife, please.",
    "I get no respect.",
    "If at first you don't succeed, then skydiving definitely isn't for you.",
    "I told my wife she should embrace her mistakes. She gave me a hug.",
    "My memory has gotten so bad it has actually caused me to lose my train of thought twice.",
    "I used to be a people person, but people ruined that for me.",
    "If life gives you melons, you might be dyslexic.",
    "I told my computer a joke about recursion. It laughed and called itself.",
    "I wanted to be a monk, but I never got the chants.",
    "I tried to write a joke about infinity, but it never ended.",
    "I told my calendar a joke. It laughed every day.",
    "I asked the ocean if it was salty. It said, 'Yes, I'm a little tide.'",
    "I told my alarm clock a secret. It woke up everyone.",
    "I asked the moon if it wanted to hang out. It said, 'I'm just going through phases.'"
]

assert len(LIBRARY) == 100, f"Library must contain 100 jokes, found {len(LIBRARY)}"

# --- Platform helpers (no pip) ---
SYSTEM = platform.system()

def _run(cmd):
    try:
        subprocess.run(cmd, check=True)
        return True
    except Exception:
        return False

def speak_macos(text, voice=None, rate=None):
    cmd = ["say"]
    if voice:
        cmd += ["-v", voice]
    if rate:
        cmd += ["-r", str(rate)]
    cmd.append(text)
    return _run(cmd)

def speak_linux(text):
    if _run(["spd-say", text]):
        return True
    return _run(["espeak", text])

def speak_windows(text, rate=0):
    safe = text.replace("'", "''")
    ps = (
        "Add-Type -AssemblyName System.Speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        f"$s.Rate = {int(rate)};"
        f"$s.Speak('{safe}');"
    )
    return _run(["powershell", "-NoProfile", "-Command", ps])

def speak_text(text, voice=None, rate=None, no_tts=False):
    if no_tts:
        return True
    if SYSTEM == "Darwin":
        return speak_macos(text, voice=voice, rate=rate)
    if SYSTEM == "Linux":
        return speak_linux(text)
    if SYSTEM == "Windows":
        r = rate if rate is not None else 0
        return speak_windows(text, rate=r)
    return False

# --- Main: one joke at a time ---
def random_joke():
    return random.choice(LIBRARY)

def main():
    parser = argparse.ArgumentParser(description="Speak one random joke at a time. Press Enter for next joke.")
    parser.add_argument("--no-tts", action="store_true", help="Print jokes only, do not speak")
    parser.add_argument("--voice", type=str, default=None, help="Voice name (macOS only)")
    parser.add_argument("--rate", type=int, default=None, help="Speech rate (platform dependent)")
    args = parser.parse_args()

    no_tts = args.no_tts
    voice = args.voice
    rate = args.rate

    print("Press Enter to hear a joke. Type 'exit' and press Enter to quit.")
    try:
        while True:
            user = input("\nReady? Press Enter for a joke or type 'exit' to quit: ").strip().lower()
            if user == "exit":
                print("Goodbye.")
                break
            joke = random_joke()
            # print timestamped joke header for clarity
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"\n[{ts}] {joke}")
            ok = speak_text(joke, voice=voice, rate=rate, no_tts=no_tts)
            if not ok:
                print("\nText-to-speech failed or required system tools are missing.")
                print("macOS: 'say' is built-in. Windows: PowerShell is used. Linux: install 'spd-say' or 'espeak'.")
                # continue so user can still press Enter for next printed joke
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting.")
        sys.exit(0)

if __name__ == "__main__":
    main()
