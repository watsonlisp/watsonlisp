# mini_donkey_kong_sticky_girders.py
import tkinter as tk
import random
import time
import math

WIDTH, HEIGHT = 640, 720
FPS = 55
GRAVITY = 0.6
PLAYER_JUMP_V = -8
BARREL_SPEED = 3
BARREL_SPAWN_INTERVAL = 3000  # ms
INVULN_SECONDS = 0

# chance to spawn a double barrel (0.0 - 1.0)
DOUBLE_BARREL_CHANCE = 0.25  # 25% chance to spawn a second barrel immediately

# extra gap between double barrels (center-to-center, pixels)
GAP_BETWEEN_DOUBLE_BARRELS = 0.25

ACCEL = 0.18
FRICTION = 0.85
MAX_SPEED = 2.0

VERBOSE = False
DEBUG_DRAW_COLLISION_RECTS = False

MAX_BARRELS = 10
SWITCH_DURATION = 0.0  # seconds a girder stays switched (non-solid) after touch

GIRDER_EXTRA_GAP = 28

PLATFORMS = [
    (40, 640, 595, 20),
    (0, 540, 460, 16),
    (180, 420, 460, 16),
    (0, 300, 460, 16),
    (180, 180, 460, 16),
]
LADDERS = [
    (240, 500, 640),
    (320, 350, 540),
    (380, 180, 350),
]
# place princess just to the right of Donkey (Donkey initial x=80, y=220)
# rectangle = (gx, gy, gw, gh)
GOAL_RECT = (140, 180, 60, 60)

SNAP_THRESHOLD = 12
DOMINANCE_PERSIST_SECONDS = 1.0
SPAN_TOLERANCE = 2
END_PAD = 3  # pixels near girder end where running-off is allowed

def interp_y_on_segment(x, x1, y1, x2, y2):
    if x2 == x1:
        return min(y1, y2)
    t = (x - x1) / (x2 - x1)
    return y1 + t * (y2 - y1)

def point_on_segment(x, x1, x2):
    return min(x1, x2) - 0.0001 <= x <= max(x1, x2) + 0.0001

class Girder:
    def __init__(self, x1, y1, x2, y2, stroke=8):
        self.x1, self.y1 = x1, y1
        self.x2, self.y2 = x2, y2
        self.stroke = stroke
        self.poly_ids = []
        self.collision_rect = None
        self.switched_until = 0.0
        self.dominant = False
        self.last_touched = 0.0

    def is_switched(self):
        return time.time() < self.switched_until

    def toggle_switched(self, duration=SWITCH_DURATION):
        if self.is_switched():
            self.switched_until = time.time()
        else:
            self.switched_until = time.time() + duration

    def set_dominant(self, v=True):
        self.dominant = bool(v)
        if self.dominant:
            self.last_touched = time.time()

    def decay_dominance_if_needed(self):
        if self.dominant and (time.time() - self.last_touched) > DOMINANCE_PERSIST_SECONDS:
            self.dominant = False

    def delete_graphics(self, canvas):
        for iid in list(self.poly_ids):
            try:
                canvas.delete(iid)
            except Exception:
                pass
        self.poly_ids.clear()

class Entity:
    def __init__(self, canvas):
        self.canvas = canvas
        self.id = None
    def delete(self):
        if self.id:
            try:
                self.canvas.delete(self.id)
            except tk.TclError:
                pass

class Player(Entity):
    def __init__(self, canvas, x, y):
        super().__init__(canvas)
        self.w, self.h = 20, 24
        self.x, self.y = x, y
        self.vx, self.vy = 0.0, 0.0
        self.on_ground = False
        self.climbing = False
        self.lives = 6
        self.score = 0
        self.invuln_until = 0.0
        self.create()

    def create(self):
        if getattr(self, 'parts', None):
            for pid in list(self.parts):
                try:
                    self.canvas.delete(pid)
                except Exception:
                    pass
        self.parts = []

        x, y = self.x, self.y
        w, h = self.w, self.h

        torso = self.canvas.create_rectangle(x - w//2 + 1, y - h + 8, x + w//2 - 1, y - 6, fill='#0B5E4A', outline='')
        self.parts.append(torso)

        shirt = self.canvas.create_rectangle(x - w//2 + 2, y - h + 8, x + w//2 - 2, y - h//2 + 2, fill='#F59E0B', outline='')
        self.parts.append(shirt)

        head_r = 5
        head = self.canvas.create_oval(x - head_r, y - h - head_r + 8, x + head_r, y - h + head_r + 8, fill='#F7D6A5', outline='')
        self.parts.append(head)

        hat_brim = self.canvas.create_rectangle(x - head_r - 1, y - h + 6, x + head_r + 1, y - h + 8, fill='#FBBF24', outline='')
        hat_top = self.canvas.create_oval(x - head_r, y - h - head_r + 6, x + head_r, y - h + 8, fill='#F59E0B', outline='')
        self.parts.extend([hat_brim, hat_top])

        eye_l = self.canvas.create_oval(x - 3, y - h + 6, x - 2, y - h + 7, fill='white', outline='')
        eye_r = self.canvas.create_oval(x + 2, y - h + 6, x + 3, y - h + 7, fill='white', outline='')
        pupil_l = self.canvas.create_oval(x - 2.6, y - h + 6.2, x - 2.1, y - h + 6.7, fill='black', outline='')
        pupil_r = self.canvas.create_oval(x + 2.1, y - h + 6.2, x + 2.6, y - h + 6.7, fill='black', outline='')
        self.parts.extend([eye_l, eye_r, pupil_l, pupil_r])

        nose = self.canvas.create_rectangle(x - 0.5, y - h + 7, x + 0.5, y - h + 8, fill='#DD9F6B', outline='')
        self.parts.append(nose)

        arm_l = self.canvas.create_rectangle(x - w//2 - 1, y - h + 10, x - w//2 + 2, y - h + 14, fill='#F59E0B', outline='')
        arm_r = self.canvas.create_rectangle(x + w//2 - 1, y - h + 10, x + w//2 + 2, y - h + 14, fill='#F59E0B', outline='')
        self.parts.extend([arm_l, arm_r])

        left_leg = self.canvas.create_rectangle(x - 5, y - 6, x - 1, y + 6, fill='#264653', outline='')
        right_leg = self.canvas.create_rectangle(x + 1, y - 6, x + 5, y + 6, fill='#264653', outline='')
        self.parts.extend([left_leg, right_leg])

        boot_l = self.canvas.create_rectangle(x - 6, y + 6, x - 1, y + 9, fill='#1F2937', outline='')
        boot_r = self.canvas.create_rectangle(x + 1, y + 6, x + 6, y + 9, fill='#1F2937', outline='')
        self.parts.extend([boot_l, boot_r])

        belt = self.canvas.create_rectangle(x - 5, y - 2, x + 5, y, fill='#8B5E3C', outline='')
        self.parts.append(belt)

        shadow = self.canvas.create_oval(x - w//2 + 1, y + 8, x + w//2 - 1, y + 11, fill='#071019', outline='')
        self.parts.append(shadow)

    def bbox(self):
        x1 = self.x - self.w//2; y1 = self.y - self.h; x2 = self.x + self.w//2; y2 = self.y
        return (x1, y1, x2, y2)

    def update_graphics(self):
        if not getattr(self, 'parts', None):
            return
        x, y = self.x, self.y
        w, h = self.w, self.h
        try:
            idx = 0
            self.canvas.coords(self.parts[idx], x - w//2 + 1, y - h + 8, x + w//2 - 1, y - 6); idx += 1
            self.canvas.coords(self.parts[idx], x - w//2 + 2, y - h + 8, x + w//2 - 2, y - h//2 + 2); idx += 1
            head_r = 5
            self.canvas.coords(self.parts[idx], x - head_r, y - h - head_r + 8, x + head_r, y - h + head_r + 8); idx += 1
            self.canvas.coords(self.parts[idx], x - head_r - 1, y - h + 6, x + head_r + 1, y - h + 8); idx += 1
            self.canvas.coords(self.parts[idx], x - head_r, y - h - head_r + 6, x + head_r, y - h + 8); idx += 1
            self.canvas.coords(self.parts[idx], x - 3, y - h + 6, x - 2, y - h + 7); idx += 1
            self.canvas.coords(self.parts[idx], x + 2, y - h + 6, x + 3, y - h + 7); idx += 1
            self.canvas.coords(self.parts[idx], x - 2.6, y - h + 6.2, x - 2.1, y - h + 6.7); idx += 1
            self.canvas.coords(self.parts[idx], x + 2.1, y - h + 6.2, x + 2.6, y - h + 6.7); idx += 1
            self.canvas.coords(self.parts[idx], x - 0.5, y - h + 7, x + 0.5, y - h + 8); idx += 1
            self.canvas.coords(self.parts[idx], x - w//2 - 1, y - h + 10, x - w//2 + 2, y - h + 14); idx += 1
            self.canvas.coords(self.parts[idx], x + w//2 - 1, y - h + 10, x + w//2 + 2, y - h + 14); idx += 1
            self.canvas.coords(self.parts[idx], x - 5, y - 6, x - 1, y + 6); idx += 1
            self.canvas.coords(self.parts[idx], x + 1, y - 6, x + 5, y + 6); idx += 1
            self.canvas.coords(self.parts[idx], x - 6, y + 6, x - 1, y + 9); idx += 1
            self.canvas.coords(self.parts[idx], x + 1, y + 6, x + 6, y + 9); idx += 1
            self.canvas.coords(self.parts[idx], x - 5, y - 2, x + 5, y); idx += 1
            self.canvas.coords(self.parts[idx], x - w//2 + 1, y + 8, x + w//2 - 1, y + 11); idx += 1
        except Exception:
            pass

    def delete(self):
        if getattr(self, 'parts', None):
            for pid in list(self.parts):
                try:
                    self.canvas.delete(pid)
                except Exception:
                    pass
            self.parts = []

    def respawn(self):
        self.x, self.y = 60, 640
        self.vx = self.vy = 0
        self.invuln_until = time.time() + INVULN_SECONDS
        self.create()

class Donkey(Entity):
    def __init__(self, canvas, x, y):
        super().__init__(canvas)
        self.x, self.y = x, y
        self.cool = 0
        self.create()
    def create(self):
        # remove old id if present
        if getattr(self, 'id', None):
            try:
                self.canvas.delete(self.id)
            except Exception:
                pass

        # gorilla body parameters (relative to self.x, self.y which is base)
        x, y = self.x, self.y
        body_w = 56
        body_h = 48
        shoulder_w = body_w + 12
        head_r = 16
        arm_w = 18
        arm_h = 34
        fist_r = 8

        # main body (rounded rectangle as two ovals + rect)
        body_left = x - body_w//2
        body_right = x + body_w//2
        body_top = y - body_h
        body_bottom = y

        # draw torso (dark brown)
        try:
            # torso top ellipse
            top_id = self.canvas.create_oval(body_left, body_top, body_right, body_top + body_h*0.7, fill='#5A2F07', outline='')
            # torso bottom ellipse (for roundness)
            bot_id = self.canvas.create_oval(body_left, body_top + body_h*0.3, body_right, body_bottom + 6, fill='#5A2F07', outline='')
            # central rect to join ellipses
            mid_id = self.canvas.create_rectangle(body_left, body_top + body_h*0.25, body_right, body_bottom, fill='#5A2F07', outline='')

            # chest patch (lighter)
            chest_id = self.canvas.create_oval(x - body_w*0.28, body_top + 6, x + body_w*0.28, body_top + body_h*0.7, fill='#8B5E3C', outline='')

            # wide shoulders (slightly darker rim)
            shoulder_left = x - shoulder_w//2
            shoulder_right = x + shoulder_w//2
            sh_left_id = self.canvas.create_oval(shoulder_left, body_top - 6, shoulder_left + 28, body_top + 18, fill='#5A2F07', outline='')
            sh_right_id = self.canvas.create_oval(shoulder_right - 28, body_top - 6, shoulder_right, body_top + 18, fill='#5A2F07', outline='')

            # head (round, centered above torso)
            head_cx = x
            head_cy = body_top - head_r + 2
            head_id = self.canvas.create_oval(head_cx - head_r, head_cy - head_r, head_cx + head_r, head_cy + head_r, fill='#4C2304', outline='')

            # face lighter area
            face_id = self.canvas.create_oval(head_cx - head_r//1.4, head_cy - head_r//4, head_cx + head_r//1.4, head_cy + head_r//1.6, fill='#E3C39A', outline='')

            # eyes
            eye_l = self.canvas.create_oval(head_cx - 7, head_cy - 4, head_cx - 3, head_cy, fill='white', outline='')
            eye_r = self.canvas.create_oval(head_cx + 3, head_cy - 4, head_cx + 7, head_cy, fill='white', outline='')
            pupil_l = self.canvas.create_oval(head_cx - 6, head_cy - 3, head_cx - 4, head_cy - 1, fill='black', outline='')
            pupil_r = self.canvas.create_oval(head_cx + 4, head_cy - 3, head_cx + 6, head_cy - 1, fill='black', outline='')

            # nostrils / nose ridge
            nose = self.canvas.create_rectangle(head_cx - 3, head_cy, head_cx + 3, head_cy + 6, fill='#C69C6D', outline='')

            # mouth line
            mouth = self.canvas.create_line(head_cx - 6, head_cy + 10, head_cx + 6, head_cy + 10, fill='#3B2011', width=2, capstyle='round')

            # arms (big, slightly angled down)
            arm_left_x1 = body_left - 8
            arm_left_y1 = body_top + 6
            arm_left_x2 = arm_left_x1 + arm_w
            arm_left_y2 = arm_left_y1 + arm_h
            arm_left_id = self.canvas.create_oval(arm_left_x1, arm_left_y1, arm_left_x2, arm_left_y2, fill='#5A2F07', outline='')

            arm_right_x2 = body_right + 8
            arm_right_y1 = body_top + 6
            arm_right_x1 = arm_right_x2 - arm_w
            arm_right_y2 = arm_right_y1 + arm_h
            arm_right_id = self.canvas.create_oval(arm_right_x1, arm_right_y1, arm_right_x2, arm_right_y2, fill='#5A2F07', outline='')

            # fists (round, at ends)
            fist_left = self.canvas.create_oval(arm_left_x1 - fist_r//2, arm_left_y2 - fist_r//2, arm_left_x1 + fist_r, arm_left_y2 + fist_r//2, fill='#3B2011', outline='')
            fist_right = self.canvas.create_oval(arm_right_x2 - fist_r, arm_right_y2 - fist_r//2, arm_right_x2 + fist_r//2, arm_right_y2 + fist_r//2, fill='#3B2011', outline='')

            # subtle highlight lines
            hl1 = self.canvas.create_line(body_left + 6, body_top + 8, x, body_top + 18, fill='#7A3A10', width=1)
            hl2 = self.canvas.create_line(x, body_top + 18, body_right - 6, body_top + 8, fill='#7A3A10', width=1)

            # store ids as a single grouped id list so tag_raise works in draw cycle
            self.id = self.canvas.create_rectangle(x-1, y-1, x+1, y+1, outline='')  # invisible anchor id
            # keep parts for layering / deletion: attach to entity so other code can tag_raise
            self.parts = [top_id, bot_id, mid_id, chest_id, sh_left_id, sh_right_id, head_id, face_id,
                          eye_l, eye_r, pupil_l, pupil_r, nose, mouth,
                          arm_left_id, arm_right_id, fist_left, fist_right, hl1, hl2, self.id]
        except Exception:
            # fallback simple rect if something fails
            try:
                self.id = self.canvas.create_rectangle(self.x - 28, self.y - 40, self.x + 28, self.y, fill='#7C4A00', outline='')
            except Exception:
                self.id = None

    def throw_barrel(self):
        if self.cool <= 0:
            self.cool = 0
            return Barrel(self.canvas, self.x + 10, self.y - 8)
        return None
    def tick(self):
        if self.cool > 0:
            self.cool -= 1

class Barrel(Entity):
    def __init__(self, canvas, x, y):
        super().__init__(canvas)
        self.r = 9
        self.x, self.y = x, y
        self.vx = BARREL_SPEED if random.choice([True, False]) else -BARREL_SPEED
        self.vy = 0.0
        self.on_ground = False
        # Flag to mark a landing transition so we only set direction once per landing
        self.landed = False
        self.create()
    def create(self):
        if getattr(self, 'id', None):
            try:
                self.canvas.delete(self.id)
            except Exception:
                pass
        self.id = self.canvas.create_oval(self.x - self.r, self.y - self.r, self.x + self.r, self.y + self.r, fill='#AA5A00', outline='')
    def bbox(self):
        return (self.x - self.r, self.y - self.r, self.x + self.r, self.y + self.r)
    def update_graphics(self):
        x1, y1, x2, y2 = self.bbox()
        try:
            self.canvas.coords(self.id, x1, y1, x2, y2)
        except tk.TclError:
            pass

class Game:
    def __init__(self, root):
        self.root = root
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg='#282828')
        self.canvas.pack()
        self.root.update()
        try:
            self.root.focus_force()
        except Exception:
            pass
        self.canvas.focus_set()
        self.root.bind_all('<KeyPress>', self.on_key)
        self.root.bind_all('<KeyRelease>', self.on_key_release)
        self.root.protocol("WM_DELETE_WINDOW", self.quit)

        self.keys = set()
        self.player = Player(self.canvas, 60, 640)
        self.donkey = Donkey(self.canvas, 80, 220)
        self.barrels = []
        self.running = True

        # New: level tracking and per-level barrel speed
        self.level = 1
        self.barrel_speed = BARREL_SPEED

        self.girders = []
        self.platform_rects = []
        self.ladder_rects = []

        self._barrel_job = None

        # Create level (this clears canvas) then immediately create persistent UI texts so they survive across levels
        self.create_level()

        # persistent UI text items (created after create_level so they are not cleared)
        self.lives_text = self.canvas.create_text(60, 20, text=f"Lives: {self.player.lives}", fill='white', font=('Arial', 14))
        self.score_text = self.canvas.create_text(WIDTH - 80, 20, text=f"Score: {self.player.score}", fill='white', font=('Arial', 14))
        self.level_text = self.canvas.create_text(WIDTH//2, 20, text=f"Level: {self.level}", fill='white', font=('Arial', 14))

        self.draw_ui()
        try:
            self._barrel_job = self.root.after(BARREL_SPAWN_INTERVAL, self.spawn_barrel)
        except Exception:
            self._barrel_job = None
        self.last_update = time.time()
        self.loop()

    def create_level(self):
        try:
            self.canvas.delete('all')
        except Exception:
            pass

        self.girders.clear()
        self.platform_rects.clear()
        self.ladder_rects.clear()

        stroke = 8
        for idx, (px, py, pw, ph) in enumerate(PLATFORMS):
            y_base = py - (idx * GIRDER_EXTRA_GAP)
            tilt = int((pw / 10) % 60)
            direction = 1 if (px + py + idx) % 2 == 0 else -1
            offset = direction * min(tilt, 48)
            x1, y1 = px, y_base
            x2, y2 = px + pw, y_base - offset
            g = Girder(x1, y1, x2, y2, stroke=stroke)

            angle = math.atan2(y2 - y1, x2 - x1)
            dx = math.sin(angle) * stroke
            dy = math.cos(angle) * stroke
            poly_coords = (x1 - dx, y1 + dy, x1 + dx, y1 - dy, x2 + dx, y2 - dy, x2 - dx, y2 + dy)

            g.delete_graphics(self.canvas)
            main_id = self.canvas.create_polygon(poly_coords, fill='#B91C1C', outline='#7F1D1D')
            g.poly_ids.append(main_id)

            try:
                top_line = self.canvas.create_line(x1 - dx, y1 + dy, x2 - dx, y2 + dy, fill='#6B0F0F', width=1)
                bot_line = self.canvas.create_line(x1 + dx, y1 - dy, x2 + dx, y2 - dy, fill='#6B0F0F', width=1)
                g.poly_ids.append(top_line)
                g.poly_ids.append(bot_line)
            except Exception:
                pass

            seg_len = math.hypot(x2 - x1, y2 - y1)
            panels = max(2, int(seg_len // 80))
            for i in range(1, panels):
                t = i / panels
                vx = x1 + (x2 - x1) * t
                ty_top = interp_y_on_segment(vx, x1, y1, x2, y2) - stroke * 0.6
                ty_bot = interp_y_on_segment(vx, x1, y1, x2, y2) + stroke * 0.6
                try:
                    vid = self.canvas.create_line(vx, ty_top, vx, ty_bot, fill='#7F1D1D', width=2)
                    g.poly_ids.append(vid)
                except Exception:
                    pass

            for i in range(panels):
                t0 = i / panels
                t1 = (i + 1) / panels
                x0 = x1 + (x2 - x1) * t0
                x1n = x1 + (x2 - x1) * t1
                top0 = interp_y_on_segment(x0, g.x1, g.y1, g.x2, g.y2) - stroke * 0.55
                bot0 = interp_y_on_segment(x0, g.x1, g.y1, g.x2, g.y2) + stroke * 0.55
                top1 = interp_y_on_segment(x1n, g.x1, g.y1, g.x2, g.y2) - stroke * 0.55
                bot1 = interp_y_on_segment(x1n, g.x1, g.y1, g.x2, g.y2) + stroke * 0.55
                try:
                    if i % 2 == 0:
                        diag = self.canvas.create_line(x0, top0, x1n, bot1, fill='#7F1D1D', width=2)
                    else:
                        diag = self.canvas.create_line(x0, bot0, x1n, top1, fill='#7F1D1D', width=2)
                    g.poly_ids.append(diag)
                except Exception:
                    pass

            left = min(x1, x2)
            right = max(x1, x2)
            bottom = max(y1, y2)
            rect_h = max(8, ph // 3)
            rect_y = bottom - rect_h
            g.collision_rect = (left, rect_y, right, rect_y + rect_h)

            self.girders.append(g)
            self.platform_rects.append(g.collision_rect)

            if DEBUG_DRAW_COLLISION_RECTS:
                try:
                    l, t, r, b = g.collision_rect
                    self.canvas.create_rectangle(l, t, r, b, outline='yellow')
                except Exception:
                    pass

        for lx, top, bottom in LADDERS:
            rail_color = '#7C4A24'
            rung_color = '#DAB67A'
            rail_width = 4
            rung_spacing = 12

            rail_half = 10
            left_rail_x = lx - rail_half
            right_rail_x = lx + rail_half

            try:
                left_id = self.canvas.create_line(left_rail_x, top, left_rail_x, bottom, fill=rail_color, width=rail_width, capstyle='projecting')
                right_id = self.canvas.create_line(right_rail_x, top, right_rail_x, bottom, fill=rail_color, width=rail_width, capstyle='projecting')
            except Exception:
                left_id = right_id = None

            rung_ids = []
            try:
                y = top + rung_spacing
                while y < bottom - rung_spacing:
                    rid = self.canvas.create_line(left_rail_x, y, right_rail_x, y, fill=rung_color, width=3, capstyle='projecting')
                    rung_ids.append(rid)
                    y += rung_spacing
            except Exception:
                pass

            self.ladder_rects.append((lx-12, top, lx+12, bottom))

        gx, gy, gw, gh = GOAL_RECT
        self.draw_princess(gx, gy, gw, gh)

        try:
            self.player.create()
            self.donkey.create()
        except Exception:
            pass

        # Because create_level clears the canvas, ensure persistent UI items exist now.
        # If they already exist we recreate them so references are valid after clearing.
        try:
            if getattr(self, 'lives_text', None):
                try:
                    self.canvas.delete(self.lives_text)
                except Exception:
                    pass
            if getattr(self, 'score_text', None):
                try:
                    self.canvas.delete(self.score_text)
                except Exception:
                    pass
            if getattr(self, 'level_text', None):
                try:
                    self.canvas.delete(self.level_text)
                except Exception:
                    pass
        except Exception:
            pass

        # create fresh persistent UI items
        self.lives_text = self.canvas.create_text(60, 20, text=f"Lives: {getattr(self.player,'lives',0)}", fill='white', font=('Arial', 14))
        self.score_text = self.canvas.create_text(WIDTH - 80, 20, text=f"Score: {getattr(self.player,'score',0)}", fill='white', font=('Arial', 14))
        self.level_text = self.canvas.create_text(WIDTH//2, 20, text=f"Level: {getattr(self,'level',1)}", fill='white', font=('Arial', 14))

        self.draw_ui()
        try:
            if getattr(self.player, 'parts', None):
                for pid in self.player.parts:
                    try:
                        self.canvas.tag_raise(pid)
                    except Exception:
                        pass
            if getattr(self.donkey, 'id', None):
                self.canvas.tag_raise(self.donkey.id)
        except Exception:
            pass

    def normalize_key(self, event):
        ch = getattr(event, 'char', '') or ''
        ks = getattr(event, 'keysym', '') or ''
        if ch and ch.isprintable():
            return ch.lower()
        return ks.lower()

    def on_key(self, event):
        k = self.normalize_key(event)
        if k in ('w', 'a', 's', 'd', 'j', 'r', 'escape'):
            self.keys.add(k)
        if k == 'r':
            self.restart()
        if k == 'escape':
            self.quit()

    def on_key_release(self, event):
        k = self.normalize_key(event)
        if k in self.keys:
            self.keys.remove(k)

    def spawn_barrel(self):
        try:
            if len(self.barrels) < MAX_BARRELS:
                b = self.donkey.throw_barrel()
                if b:
                    # primary throw position
                    throw_x = self.donkey.x + 10
                    throw_y = self.donkey.y - 8

                    b.x, b.y = throw_x, throw_y
                    # set horizontal speed from current level barrel_speed
                    b.vx = self.barrel_speed if random.choice([True, False]) else -self.barrel_speed
                    self.barrels.append(b)

                    # maybe spawn a second barrel immediately (double barrel)
                    if random.random() < DOUBLE_BARREL_CHANCE and len(self.barrels) < MAX_BARRELS:
                        b2 = Barrel(self.canvas, throw_x, throw_y)
                        # match horizontal direction to the first barrel so they land side-by-side
                        b2.vx = b.vx

                        # Space centers by exactly one diameter (center-to-center) plus a small gap
                        sep = (b.r + b2.r) + GAP_BETWEEN_DOUBLE_BARRELS
                        # place them left/right of throw point so their centers are sep apart
                        # use sign from vx to pick which barrel is on which side visually (keeps flow)
                        if b.vx >= 0:
                            # moving right: place b slightly left, b2 slightly right
                            b.x = throw_x - sep/2
                            b2.x = throw_x + sep/2
                        else:
                            # moving left: place b slightly right, b2 slightly left
                            b.x = throw_x + sep/2
                            b2.x = throw_x - sep/2

                        # clamp to world bounds
                        b.x = max(b.r, min(WIDTH - b.r, b.x))
                        b2.x = max(b2.r, min(WIDTH - b2.r, b2.x))

                        self.barrels.append(b2)
        except Exception:
            pass
        try:
            self._barrel_job = self.root.after(BARREL_SPAWN_INTERVAL, self.spawn_barrel)
        except Exception:
            self._barrel_job = None

    def rects_collide(self, a, b):
        ax1, ay1, ax2, ay2 = a
        bx1, by1, bx2, by2 = b
        return not (ax2 < bx1 or ax1 > bx2 or ay2 < by1 or ay1 > by2)

    def ladder_check(self):
        px = self.player.x
        feet_y = self.player.y
        head_y = self.player.y - self.player.h
        for lx1, top, lx2, bottom in self.ladder_rects:
            horiz_ok = (lx1 <= px <= lx2)
            vert_ok = (head_y < bottom and feet_y > top)
            if horiz_ok and vert_ok:
                return True
        return False

    def rect_overlaps_any_ladder(self, rect):
        rx1, ry1, rx2, ry2 = rect
        for lx1, ltop, lx2, lbottom in self.ladder_rects:
            if not (rx2 < lx1 or rx1 > lx2):
                return True
        return False

    def slope_under_player(self):
        px = self.player.x
        best = None
        best_dy = None
        for g in self.girders:
            left = min(g.x1, g.x2) - SPAN_TOLERANCE
            right = max(g.x1, g.x2) + SPAN_TOLERANCE
            if left <= px <= right:
                surf_y = interp_y_on_segment(px, g.x1, g.y1, g.x2, g.y2)
                dy = abs(self.player.y - surf_y)
                if best is None or dy < best_dy:
                    best = g
                    best_dy = dy
        if best is not None:
            angle = math.atan2(best.y2 - best.y1, best.x2 - best.x1)
            surf_y = interp_y_on_segment(px, best.x1, best.y1, best.x2, best.y2)
            return (best, surf_y, angle)
        return (None, None, None)

    def find_closest_lower_girder(self, x, y):
        for g in self.girders:
            g.decay_dominance_if_needed()
            if g.dominant:
                left = min(g.x1, g.x2)
                right = max(g.x1, g.x2)
                clamped_x = min(max(x, left), right)
                surf_y = interp_y_on_segment(clamped_x, g.x1, g.y1, g.x2, g.y2)
                if surf_y > y + 1:
                    return (g, clamped_x, surf_y)

        candidates = []
        for g in self.girders:
            left = min(g.x1, g.x2)
            right = max(g.x1, g.x2)
            clamped_x = min(max(x, left), right)
            surf_y = interp_y_on_segment(clamped_x, g.x1, g.y1, g.x2, g.y2)
            if surf_y > y + 1:
                dy = surf_y - y
                candidates.append((dy, g, clamped_x, surf_y))
        if not candidates:
            return None
        candidates.sort(key=lambda t: t[0])
        _, gsel, sel_x, sel_y = candidates[0]
        return (gsel, sel_x, sel_y)

    def girder_directly_below(self, x, y, threshold=SNAP_THRESHOLD):
        for g in self.girders:
            left = min(g.x1, g.x2) - SPAN_TOLERANCE
            right = max(g.x1, g.x2) + SPAN_TOLERANCE
            if left <= x <= right:
                surf_y = interp_y_on_segment(x, g.x1, g.y1, g.x2, g.y2)
                if 0 < (surf_y - y) <= threshold:
                    return (g, x, surf_y)
        return None

    def girder_touched_by_player(self):
        touched = []
        feet_y = self.player.y
        for g in self.girders:
            span_left = min(g.x1, g.x2) - SPAN_TOLERANCE
            span_right = max(g.x1, g.x2) + SPAN_TOLERANCE
            if span_left <= self.player.x <= span_right:
                surf_y = interp_y_on_segment(self.player.x, g.x1, g.y1, g.x2, g.y2)
                if feet_y >= surf_y - 2 and feet_y <= surf_y + g.stroke + 6:
                    touched.append(g)
        return touched

    def update_girder_visuals_and_collision(self):
        self.platform_rects.clear()
        for g in self.girders:
            g.decay_dominance_if_needed()
            is_sw = g.is_switched()
            try:
                if g.poly_ids:
                    main_id = g.poly_ids[0]
                    fill_col = '#DC2626' if is_sw else '#B91C1C'
                    outline_col = '#FFD166' if g.dominant else '#7F1D1D'
                    self.canvas.itemconfig(main_id, fill=fill_col, outline=outline_col)
                    try:
                        self.canvas.itemconfig(main_id, width=3 if g.dominant else 1)
                    except Exception:
                        pass
            except Exception:
                pass
            if not is_sw and g.collision_rect is not None:
                self.platform_rects.append(g.collision_rect)

    def platform_collision(self, bbox):
        for rect in self.platform_rects:
            if self.rects_collide(bbox, rect):
                return rect
        return None

    def check_barrel_collisions(self):
        for b in list(self.barrels):
            bx1, by1, bx2, by2 = b.bbox()
            px1, py1, px2, py2 = self.player.bbox()
            if not (bx2 < px1 or bx1 > px2 or by2 < py1 or by1 > py2):
                if time.time() > self.player.invuln_until:
                    self.player.lives -= 1
                    self.player.respawn()
                    if self.player.lives <= 0:
                        self.game_over()

    def game_over(self):
        self.running = False
        try:
            self.canvas.create_text(WIDTH//2, HEIGHT//2, text="GAME OVER - Press R to restart", fill='white', font=('Arial', 18))
        except Exception:
            pass

    def level_won(self):
        # show level-up message briefly, then advance level
        try:
            msg_id = self.canvas.create_text(WIDTH//2, HEIGHT//2 - 20,
                                             text=f"Level {self.level} Complete!",
                                             fill='white', font=('Arial', 18))
            sub_id = self.canvas.create_text(WIDTH//2, HEIGHT//2 + 10,
                                             text="Preparing next level...",
                                             fill='white', font=('Arial', 12))
            self.canvas.update()
        except Exception:
            msg_id = sub_id = None

        # small pause so player sees the message
        try:
            self.root.update()
            time.sleep(0.8)
        except Exception:
            pass

        try:
            if msg_id:
                self.canvas.delete(msg_id)
            if sub_id:
                self.canvas.delete(sub_id)
        except Exception:
            pass

        # advance level and increase difficulty
        self.level += 1
        # e.g., increase barrel speed by 12% each level
        self.barrel_speed *= 1.12

        # clear existing barrels
        try:
            for b in self.barrels:
                b.delete()
        except Exception:
            pass
        self.barrels.clear()

        # respawn player and donkey (keep lives/score)
        try:
            self.player.delete()
            self.donkey.delete()
        except Exception:
            pass
        self.player = Player(self.canvas, 60, 640)
        self.donkey = Donkey(self.canvas, 80, 220)

        # recreate level visuals (girders/platforms/ladder) and UI
        self.create_level()
        self.draw_ui()

        # restart barrel spawner (respect BARREL_SPAWN_INTERVAL)
        try:
            if getattr(self, '_barrel_job', None):
                self.root.after_cancel(self._barrel_job)
            self._barrel_job = self.root.after(BARREL_SPAWN_INTERVAL, self.spawn_barrel)
        except Exception:
            self._barrel_job = None

        # continue running
        self.running = True

    def restart(self):
        try:
            if getattr(self, '_barrel_job', None):
                self.root.after_cancel(self._barrel_job)
                self._barrel_job = None
        except Exception:
            pass
        try:
            for b in self.barrels:
                b.delete()
        except Exception:
            pass
        self.barrels.clear()
        try:
            self.player.delete()
            self.donkey.delete()
        except Exception:
            pass
        self.player = Player(self.canvas, 60, 640)
        self.donkey = Donkey(self.canvas, 80, 220)
        self.running = True
        # reset level and barrel speed on full restart
        self.level = 1
        self.barrel_speed = BARREL_SPEED
        self.create_level()
        self.draw_ui()
        try:
            self._barrel_job = self.root.after(BARREL_SPAWN_INTERVAL, self.spawn_barrel)
        except Exception:
            self._barrel_job = None

    def draw_ui(self):
        try:
            # update existing persistent UI items
            try:
                self.canvas.itemconfig(self.lives_text, text=f"Lives: {self.player.lives}")
                self.canvas.itemconfig(self.score_text, text=f"Score: {self.player.score}")
                self.canvas.itemconfig(self.level_text, text=f"Level: {self.level}")
            except Exception:
                pass

            try:
                # keep UI on top
                self.canvas.tag_raise(self.lives_text)
                self.canvas.tag_raise(self.score_text)
                self.canvas.tag_raise(self.level_text)
            except Exception:
                pass

            # ensure player and donkey art are above UI background elements
            try:
                if getattr(self.player, 'parts', None):
                    for pid in self.player.parts:
                        try:
                            self.canvas.tag_raise(pid)
                        except Exception:
                            pass
                if getattr(self.donkey, 'id', None):
                    self.canvas.tag_raise(self.donkey.id)
            except Exception:
                pass
        except Exception:
            pass

    def draw_princess(self, gx, gy, gw, gh):
        """Draw a small princess inside the goal rect area scaled to the player size (Mario)."""
        # Target size: match Player width/height
        target_w = getattr(self.player, 'w', 20)
        target_h = getattr(self.player, 'h', 24)

        # center position inside the goal rect
        cx = gx + gw // 2
        # we want the princess base (feet) to align similarly to player's y reference:
        # Player uses y as the base (bottom). We'll treat princess bottom at cy_base.
        cy_base = gy + gh  # bottom of goal rect

        # compute top y for drawing based on target_h
        top_y = cy_base - target_h

        # head
        head_r = 5
        head_cx = cx
        head_cy = top_y + head_r + 1

        # draw skirt/dress as a small trapezoid/oval scaled to target_w/target_h
        skirt_w = int(target_w * 0.9)
        skirt_h = int(target_h * 0.45)
        skirt_top = top_y + int(target_h * 0.35)

        try:
            self.canvas.create_oval(cx - skirt_w//2, skirt_top,
                                    cx + skirt_w//2, skirt_top + skirt_h,
                                    fill='#F472B6', outline='#C0266E')  # pink dress

            # torso (small)
            torso_h = int(target_h * 0.25)
            self.canvas.create_rectangle(cx - skirt_w//6, skirt_top - torso_h,
                                         cx + skirt_w//6, skirt_top,
                                         fill='#FBCFE8', outline='')  # light torso

            # arms
            arm_w = 4
            arm_h = int(torso_h * 0.9)
            self.canvas.create_oval(cx - skirt_w//6 - arm_w - 1, skirt_top - torso_h + 2,
                                    cx - skirt_w//6 - 1, skirt_top - torso_h + 2 + arm_h,
                                    fill='#FBCFE8', outline='')
            self.canvas.create_oval(cx + skirt_w//6 + 1, skirt_top - torso_h + 2,
                                    cx + skirt_w//6 + arm_w + 1, skirt_top - torso_h + 2 + arm_h,
                                    fill='#FBCFE8', outline='')

            # head / face
            self.canvas.create_oval(head_cx - head_r, head_cy - head_r,
                                    head_cx + head_r, head_cy + head_r,
                                    fill='#FFEDD5', outline='')  # face

            # hair (fringe + side)
            hair_h = head_r + 2
            self.canvas.create_arc(head_cx - head_r - 2, head_cy - hair_h,
                                   head_cx + head_r + 2, head_cy + hair_h,
                                   start=200, extent=140, fill='#7C3AED', outline='')  # purple hair

            # eyes (tiny)
            eye_w = 2
            self.canvas.create_oval(head_cx - eye_w - 1, head_cy - 1, head_cx - 1, head_cy + 1, fill='white', outline='')
            self.canvas.create_oval(head_cx + 1, head_cy - 1, head_cx + eye_w + 1, head_cy + 1, fill='white', outline='')
            self.canvas.create_oval(head_cx - 1, head_cy - 0, head_cx - 0.2, head_cy + 0.5, fill='black', outline='')
            self.canvas.create_oval(head_cx + 0.3, head_cy - 0, head_cx + 1, head_cy + 0.5, fill='black', outline='')

            # small smile
            self.canvas.create_arc(head_cx - 4, head_cy, head_cx + 4, head_cy + 4, start=180, extent=180, style='arc', outline='#9A3412', width=1)

            # little crown (tiny)
            crown_w = head_r * 1.6
            crown_h = max(3, int(head_r * 0.35))
            crown_x1 = head_cx - crown_w//2
            crown_x2 = head_cx + crown_w//2
            crown_y1 = head_cy - head_r - crown_h + 1
            self.canvas.create_rectangle(crown_x1, crown_y1, crown_x2, crown_y1 + crown_h, fill='#FCD34D', outline='#B45309')
            # crown points
            p1 = (crown_x1 + 2, crown_y1)
            p2 = (crown_x1 + crown_w * 0.28, crown_y1 - crown_h)
            p3 = (crown_x1 + crown_w * 0.55, crown_y1)
            p4 = (crown_x1 + crown_w * 0.78, crown_y1 - crown_h)
            p5 = (crown_x2 - 2, crown_y1)
            self.canvas.create_polygon(p1 + p2 + p3 + p4 + p5, fill='#FCD34D', outline='#B45309')

            # tiny heart on dress
            heart_w = max(4, int(skirt_w * 0.25))
            hx = cx
            hy = skirt_top + skirt_h // 3
            self.canvas.create_polygon(
                hx, hy,
                hx - heart_w//2, hy - heart_w//4,
                hx - heart_w, hy + heart_w//3,
                hx, hy + heart_w,
                hx + heart_w, hy + heart_w//3,
                hx + heart_w//2, hy - heart_w//4,
                fill='#EF4444', outline=''
            )
        except Exception:
            pass

    def loop(self):
        now = time.time()
        dt = now - getattr(self, 'last_update', now)
        self.last_update = now
        if self.running:
            self.update_game(dt)
        try:
            self.root.after(int(1000 / FPS), self.loop)
        except Exception:
            pass

    def update_game(self, dt):
        keys = self.keys
        w_pressed = 'w' in keys
        s_pressed = 's' in keys
        a_pressed = 'a' in keys
        d_pressed = 'd' in keys
        jump_pressed = 'j' in keys

        self.update_girder_visuals_and_collision()

        in_ladder_area = self.ladder_check()
        engaging_ladder = in_ladder_area and (w_pressed or s_pressed)
        allow_pass_across_girder = in_ladder_area and not (a_pressed or d_pressed)

        if engaging_ladder:
            if not self.player.climbing:
                self.player.vx = 0
            self.player.climbing = True
            self.player.on_ground = False
        else:
            self.player.climbing = False

        if self.player.climbing:
            self.player.vx = 0
        else:
            if a_pressed and not d_pressed:
                self.player.vx -= ACCEL * (dt * FPS)
            elif d_pressed and not a_pressed:
                self.player.vx += ACCEL * (dt * FPS)
            else:
                self.player.vx *= (FRICTION ** (dt * FPS))
            if self.player.vx > MAX_SPEED: self.player.vx = MAX_SPEED
            if self.player.vx < -MAX_SPEED: self.player.vx = -MAX_SPEED

        g_under, surf_y, angle = self.slope_under_player()

        # If snapped to a girder but player moved past its span, clear on_ground (allow falling)
        if g_under is not None:
            left = min(g_under.x1, g_under.x2) - SPAN_TOLERANCE
            right = max(g_under.x1, g_under.x2) + SPAN_TOLERANCE
            if not (left <= self.player.x <= right):
                self.player.on_ground = False

        if self.player.climbing:
            if w_pressed or s_pressed:
                cx = self.player.x
                for lx1, top, lx2, bottom in self.ladder_rects:
                    if lx1 <= cx <= lx2:
                        ladder_center = (lx1 + lx2) / 2
                        self.player.x += (ladder_center - cx) * 0.25
                        break
            if w_pressed and not s_pressed:
                self.player.vy = -2.5
            elif s_pressed and not w_pressed:
                self.player.vy = 2.5
            else:
                self.player.vy = 0

            if (a_pressed or d_pressed):
                direct = self.girder_directly_below(self.player.x, self.player.y, threshold=SNAP_THRESHOLD)
                if direct is not None:
                    g_below, target_x, surf_below = direct
                    self.player.x = target_x
                    self.player.y = surf_below + 1
                    self.player.vy = 0
                    self.player.climbing = False
                    self.player.on_ground = True
                else:
                    result = self.find_closest_lower_girder(self.player.x, self.player.y)
                    if result is not None:
                        g_below, target_x, surf_below = result
                        self.player.x = target_x
                        self.player.y = surf_below + 1
                        self.player.vy = 0
                        self.player.climbing = False
                        self.player.on_ground = True
                    else:
                        self.player.climbing = False
                        self.player.on_ground = False

            if self.player.climbing:
                self.player.y += self.player.vy
            else:
                self.player.vy += GRAVITY
                self.player.y += self.player.vy

        else:
            if jump_pressed and self.player.on_ground and not engaging_ladder:
                self.player.vy = PLAYER_JUMP_V
                self.player.on_ground = False

            if in_ladder_area:
                self.player.vy = 0
            else:
                self.player.vy += GRAVITY

            self.player.y += self.player.vy

        # ---- Updated: bounce on head-hit against all girders/platforms ----
        # When moving upward and the player's head intersects any platform collision rect,
        # apply an immediate downward bounce velocity instead of passing through.
        try:
            if self.player.vy < 0 and not self.player.climbing and not engaging_ladder:
                px1, py1, px2, py2 = self.player.bbox()
                # head area: slightly above player's top (a bit wider to catch angled collisions)
                head_box = (px1 + 2, py1 - 6, px2 - 2, py1 + 2)
                collided_head = self.platform_collision(head_box)
                if collided_head:
                    # compute a bounce velocity (downwards). Use a moderate value so the bounce is noticeable.
                    BOUNCE_VY = 6.0
                    # place player just below the platform rect bottom to avoid immediate re-collision
                    _, _, _, rect_bottom = collided_head
                    self.player.y = rect_bottom + self.player.h + 1
                    # set downward velocity (bounce) and clear on_ground
                    self.player.vy = BOUNCE_VY
                    self.player.on_ground = False
        except Exception:
            pass
        # ---- end head bounce block ----

        # horizontal movement: allow running off girder ends
        if not self.player.climbing and not engaging_ladder and not allow_pass_across_girder:
            self.player.x += self.player.vx
            mid_box = (self.player.x - self.player.w//2 + 1,
                       self.player.y - self.player.h//2,
                       self.player.x + self.player.w//2 - 1,
                       self.player.y + 2)
            collided = self.platform_collision(mid_box)
            if collided:
                px1, py1, px2, py2 = collided

                # find owner girder for this rect (if any)
                owner_girder = None
                for g in self.girders:
                    if g.collision_rect == collided:
                        owner_girder = g
                        break

                blocked = False
                if owner_girder is not None:
                    g_left = min(owner_girder.x1, owner_girder.x2)
                    g_right = max(owner_girder.x1, owner_girder.x2)

                    # if moving right and player is past (or very near) the right end, allow pass
                    if self.player.vx > 0 and self.player.x > (g_right - END_PAD):
                        blocked = False
                    # if moving left and player is past (or very near) the left end, allow pass
                    elif self.player.vx < 0 and self.player.x < (g_left + END_PAD):
                        blocked = False

                if blocked:
                    # Only block horizontally when player's vertical extent overlaps the platform rect;
                    # otherwise allow stepping off even if owner_girder lookup fails.
                    player_top = self.player.y - self.player.h
                    player_bottom = self.player.y
                    rect_top = py1
                    rect_bottom = py2
                    vertical_overlap = not (player_bottom < rect_top + 2 or player_top > rect_bottom - 2)

                    if vertical_overlap:
                        if self.player.vx > 0:
                            self.player.x = px1 - self.player.w//2
                            self.player.vx = 0
                        elif self.player.vx < 0:
                            self.player.x = px2 + self.player.w//2
                            self.player.vx = 0
                    # else: allow pass (no horizontal block)
        elif self.player.climbing and (w_pressed or s_pressed):
            cx = self.player.x
            for lx1, top, lx2, bottom in self.ladder_rects:
                if lx1 <= cx <= lx2:
                    ladder_center = (lx1 + lx2) / 2
                    self.player.x += (ladder_center - cx) * 0.2
                    break

        # feet probe: if it no longer collides, clear on_ground so you fall
        feet_box = (self.player.x - self.player.w//2 + 2,
                    self.player.y - 2,
                    self.player.x + self.player.w//2 - 2,
                    self.player.y + 4)

        if not self.player.climbing:
            collided_feet = self.platform_collision(feet_box)
            if collided_feet is None:
                self.player.on_ground = False

        if g_under is not None and not self.player.climbing and not allow_pass_across_girder:
            x1, y1, x2, y2 = g_under.x1, g_under.y1, g_under.x2, g_under.y2
            expected_y = interp_y_on_segment(self.player.x, x1, y1, x2, y2)
            feet_y = self.player.y
            if (feet_y >= expected_y - 2.0) and (self.player.vy >= -6):
                self.player.y = expected_y
                self.player.vy = 0
                self.player.on_ground = True
                slope_angle = math.atan2(y2 - y1, x2 - x1)
                slide = math.sin(slope_angle) * 0.12
                self.player.vx += slide
            else:
                self.player.on_ground = False

        if not self.player.climbing and not engaging_ladder and not allow_pass_across_girder:
            collided = self.platform_collision(feet_box)
            if collided:
                px1, py1, px2, py2 = collided
                if self.player.vy > 0:
                    self.player.y = py1
                    self.player.vy = 0
                    self.player.on_ground = True
                elif self.player.vy < 0:
                    self.player.y = py2 + self.player.h
                    self.player.vy = 0

        if self.player.x - self.player.w//2 < 0:
            self.player.x = self.player.w//2
            self.player.vx = 0
        if self.player.x + self.player.w//2 > WIDTH:
            self.player.x = WIDTH - self.player.w//2
            self.player.vx = 0
        if self.player.y > HEIGHT + 200:
            self.player.lives -= 1
            self.player.respawn()
            if self.player.lives <= 0:
                self.game_over()

        # ---------- Barrel handling: run-off -> fall, natural landing on lower girder ----------
        for b in list(self.barrels):
            try:
                # integrate gravity
                b.vy += GRAVITY

                # horizontal motion and side collisions (helps slide off ends)
                b.x += b.vx
                bx1, by1, bx2, by2 = b.bbox()
                for rect in self.platform_rects:
                    # let barrels ignore platform rects that intersect ladder zones
                    if self.rect_overlaps_any_ladder(rect):
                        continue
                    if self.rects_collide((bx1, by1, bx2, by2), rect):
                        rx1, ry1, rx2, ry2 = rect
                        # only flip when we actually collide horizontally from side (penetration heuristic)
                        if b.vx > 0 and bx2 > rx1 + 1 and bx1 < rx1:
                            b.x = rx1 - b.r
                            b.vx *= -1
                        elif b.vx < 0 and bx1 < rx2 - 1 and bx2 > rx2:
                            b.x = rx2 + b.r
                            b.vx *= -1

                # vertical motion
                b.y += b.vy
                bx1, by1, bx2, by2 = b.bbox()

                # top-of-rect landing (platform_rects)
                landed_on_rect = False
                for rect in self.platform_rects:
                    # let barrels ignore platform rects that intersect ladder zones
                    if self.rect_overlaps_any_ladder(rect):
                        continue
                    rx1, ry1, rx2, ry2 = rect
                    if by2 >= ry1 and by1 < ry1 and (bx2 > rx1 and bx1 < rx2) and b.vy >= 0:
                        b.y = ry1 - b.r
                        b.vy = 0.0
                        landed_on_rect = True
                        b.landed = True

                # girder alignment and end-run detection
                on_any_girder = False
                just_ran_off = False
                for g in self.girders:
                    if point_on_segment(b.x, g.x1, g.x2):
                        surf_y = interp_y_on_segment(b.x, g.x1, g.y1, g.x2, g.y2)
                        if b.y + b.r >= surf_y - 1 and b.vy >= 0:
                            if not g.is_switched():
                                on_any_girder = True

                                # Determine true physical ends
                                g_left = min(g.x1, g.x2)
                                g_right = max(g.x1, g.x2)

                                # Consider the barrel's radius so its edge reaches the girder end
                                eps = 0.5
                                ran_off_right = (b.vx > 0 and (b.x + b.r) >= (g_right - eps + END_PAD))
                                ran_off_left  = (b.vx < 0 and (b.x - b.r) <= (g_left + eps - END_PAD))

                                if ran_off_left or ran_off_right:
                                    # mark as falling off this girder this frame
                                    b.landed = False
                                    just_ran_off = True

                                    # try to drop directly to any lower girder under this x
                                    candidate = self.find_closest_lower_girder(b.x, b.y + b.r)
                                    if candidate is not None:
                                        tgt_g, tgt_x, tgt_y = candidate
                                        # only snap if the target is meaningfully below the current surface
                                        if tgt_y > surf_y + 1:
                                            # land on the lower girder immediately (preserve horizontal velocity sign)
                                            b.x = min(max(tgt_x, min(tgt_g.x1, tgt_g.x2)), max(tgt_g.x1, tgt_g.x2))
                                            b.y = tgt_y - b.r
                                            b.vy = 0.0
                                            b.landed = True
                                            if tgt_g.x2 > tgt_g.x1:
                                                b.vx = abs(b.vx) if (tgt_g.y2 > tgt_g.y1) else -abs(b.vx)
                                            else:
                                                b.vx = -abs(b.vx) if (tgt_g.y2 > tgt_g.y1) else abs(b.vx)
                                            # skip the usual fall adjustment
                                            break

                                    # fallback: give a small downward kick so it leaves the surface cleanly
                                    b.vy = max(b.vy, GRAVITY * 1.0)
                                    # don't snap to this girder anymore; break to let it fall
                                    break

                                # Normal landing transition (only set on initial landing)
                                if not getattr(b, 'landed', False):
                                    b.y = surf_y - b.r
                                    b.vy = 0.0
                                    b.landed = True
                                    # choose vx sign from slope but preserve current sign where sensible
                                    if g.x2 > g.x1:
                                        b.vx = abs(b.vx) if (g.y2 > g.y1) else -abs(b.vx)
                                    else:
                                        b.vx = -abs(b.vx) if (g.y2 > g.y1) else abs(b.vx)
                                    # smaller nudge so barrels don't get held back visually
                                    b.x += math.copysign(0.2, b.vx)
                                else:
                                    # keep snapped
                                    b.y = surf_y - b.r
                                break

                # If we just ran off a girder, begin falling behavior (skip immediate re-snag)
                if just_ran_off:
                    # move slightly down to avoid re-detection in the same frame
                    b.y += 1.2
                    bx1, by1, bx2, by2 = b.bbox()

                # Falling-mode: while not landed and not on a platform rect, try to land on a lower girder naturally
                if not getattr(b, 'landed', False) and not landed_on_rect:
                    # find best candidate lower girder under this x (if any)
                    candidate = self.find_closest_lower_girder(b.x, b.y + b.r)
                    if candidate is not None:
                        tgt_g, tgt_x, tgt_y = candidate
                        # if the barrel's bottom overlaps the target surface this tick, snap to it
                        # i.e., when barrel falls to or past the surface
                        if (b.y + b.r) >= tgt_y - 1:
                            # land on the target girder naturally (preserve horizontal velocity)
                            b.x = min(max(tgt_x, min(tgt_g.x1, tgt_g.x2)), max(tgt_g.x1, tgt_g.x2))
                            b.y = tgt_y - b.r
                            b.vy = 0.0
                            b.landed = True
                            # adjust horizontal direction lightly to match slope orientation
                            if tgt_g.x2 > tgt_g.x1:
                                b.vx = abs(b.vx) if (tgt_g.y2 > tgt_g.y1) else -abs(b.vx)
                            else:
                                b.vx = -abs(b.vx) if (tgt_g.y2 > tgt_g.y1) else abs(b.vx)
                            b.x += math.copysign(0.2, b.vx)

                # If the barrel isn't on any girder or rect, ensure landed flag cleared
                if not on_any_girder and not landed_on_rect:
                    b.landed = False

                # prevent upward vy from being retained
                if b.vy < 0:
                    b.vy = 0.0

                # world bounds and cleanup
                if b.x - b.r <= 0:
                    b.x = b.r
                    b.vx = abs(b.vx)
                if b.x + b.r >= WIDTH:
                    b.x = WIDTH - b.r
                    b.vx = -abs(b.vx)
                if b.y - b.r > HEIGHT + 100:
                    b.delete()
                    try:
                        self.barrels.remove(b)
                    except ValueError:
                        pass
                    self.player.score += 10

                b.update_graphics()
            except Exception:
                try:
                    b.delete()
                    if b in self.barrels:
                        self.barrels.remove(b)
                except Exception:
                    pass
        # ---------- end barrel handling ----------

        self.donkey.tick()
        self.check_barrel_collisions()

        touched = self.girder_touched_by_player()
        if touched:
            feet_y = self.player.y
            best = None
            best_dy = None
            for g in touched:
                left = min(g.x1, g.x2)
                right = max(g.x1, g.x2)
                clamped_x = min(max(self.player.x, left), right)
                surf_y = interp_y_on_segment(clamped_x, g.x1, g.y1, g.x2, g.y2)
                dy = abs(feet_y - surf_y)
                if best is None or dy < best_dy:
                    best = g
                    best_dy = dy
            for g in self.girders:
                g.set_dominant(False)
            if best is not None:
                best.set_dominant(True)
            for g in touched:
                g.toggle_switched(SWITCH_DURATION)
                g.last_touched = time.time()
                if VERBOSE:
                    print("Toggled girder at", g.x1, g.y1, "-> switched until", g.switched_until, "dominant?", g.dominant)

        self.update_girder_visuals_and_collision()

        gx, gy, gw, gh = GOAL_RECT
        px1, py1, px2, py2 = self.player.bbox()
        if not (px2 < gx or px1 > gx + gw or py2 < gy or py1 > gy + gh):
            self.level_won()

        self.player.update_graphics()
        self.draw_ui()

    def quit(self):
        try:
            if getattr(self, '_barrel_job', None):
                self.root.after_cancel(self._barrel_job)
                self._barrel_job = None
        except Exception:
            pass
        try:
            self.root.destroy()
        except tk.TclError:
            pass

if __name__ == '__main__':
    root = tk.Tk()
    root.title("Mini Donkey Kong — sticky girders")
    game = Game(root)
    root.mainloop()
