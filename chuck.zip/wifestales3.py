#!/usr/bin/env python3
import random
import json
import os
import sys
from typing import List, Dict

TALES: List[Dict[str, str]] = [
    {"text": "If you break a mirror you get seven years bad luck.", "category": "luck"},
    {"text": "Don’t open an umbrella indoors or you’ll invite bad luck.", "category": "household"},
    {"text": "Finding a four-leaf clover brings you good luck.", "category": "luck"},
    {"text": "If you swallow gum it stays in your stomach for seven years.", "category": "health"},
    {"text": "A black cat crossing your path means misfortune.", "category": "animals"},
    {"text": "Placing bread crusts under a pillow will make you dream of your future partner.", "category": "love"},
    {"text": "If you step on a crack you’ll break your mother’s back.", "category": "playful"},
    {"text": "Carrying a rabbit’s foot brings good luck.", "category": "luck"},
    {"text": "Don’t put shoes on a table — it brings bad luck.", "category": "household"},
    {"text": "If your ears are burning, someone is talking about you.", "category": "people"},
    {"text": "Spilling salt is unlucky; throw a pinch over your left shoulder to cancel it.", "category": "luck"},
    {"text": "If you say 'rabbit' on the first of the month you’ll have good luck all month.", "category": "luck"},
    {"text": "Itchy palms mean money is coming (right) or going (left).", "category": "fortune"},
    {"text": "Whistling indoors will call bad spirits or bad luck.", "category": "household"},
    {"text": "If a bird flies into your house it foretells a death in the family.", "category": "omens"},
    {"text": "Cutting your hair during a full moon makes it grow faster.", "category": "beauty"},
    {"text": "If you dream of losing teeth, someone close will die or you’ll face loss.", "category": "dreams"},
    {"text": "Hanging a horseshoe above the door brings protection if the open end faces up.", "category": "protection"},
    {"text": "If you drop a knife, a man will visit; if you drop a fork, a woman will visit.", "category": "visitors"},
    {"text": "Eat fish on Friday for good luck and safe voyages.", "category": "food"},
    {"text": "If you wash your hair on Sunday it brings bad luck for the week.", "category": "beauty"},
    {"text": "Pregnant women should avoid pickles if they want a calm baby.", "category": "pregnancy"},
    {"text": "If a pregnant woman craves sour things, the baby will be strong-willed.", "category": "pregnancy"},
    {"text": "Leave a broom by the door to sweep away bad luck.", "category": "household"},
    {"text": "If you wear a hat indoors you’ll become infertile or disrespect family spirits.", "category": "household"},
    {"text": "A ringing in the left ear means good news; the right ear means bad news.", "category": "omens"},
    {"text": "If you sneeze once it’s good luck; sneezing multiple times means someone is gossiping about you.", "category": "people"},
    {"text": "Never hang wet clothes on a Monday or you’ll invite misfortune.", "category": "household"},
    {"text": "If your wedding ring slips off a finger it’s a sign of trouble.", "category": "love"},
    {"text": "To keep away evil eye, wear red or tie a red string on a child.", "category": "protection"},
    {"text": "If the palm of your hand itches you’ll receive money soon.", "category": "fortune"},
    {"text": "If you put new shoes on the table, your family will quarrel.", "category": "household"},
    {"text": "Seeing a spider in the morning means a visitor; at night it means money.", "category": "omens"},
    {"text": "If a pregnant woman steps over a baby, the baby will be slow to crawl.", "category": "pregnancy"},
    {"text": "If you spill wine on the table, you will have company.", "category": "visitors"},
    {"text": "Don’t sew on a Sunday or you’ll sew bad luck into the week.", "category": "household"},
    {"text": "If you find a penny face up it brings good luck; face down, flip it.", "category": "fortune"},
    {"text": "Putting new shoes on a bed will stop you from getting married soon.", "category": "love"},
    {"text": "If your left eye twitches, someone is praising you; right eye, someone is angry.", "category": "omens"},
    {"text": "Never whistle at sea or you’ll raise a storm.", "category": "superstition"},
    {"text": "Eating carrots helps you see in the dark; good for night vision.", "category": "food"},
    {"text": "If a child walks backward, they will have a hard life ahead.", "category": "children"},
    {"text": "Open a window when you argue to let arguments leave the house.", "category": "household"},
    {"text": "If a mirror fogs but no one’s breathing on it, a spirit is present.", "category": "omens"},
    {"text": "Throwing coins into a fountain makes wishes come true.", "category": "wishes"},
    {"text": "If you hear a rooster crow at night, it foretells an illness.", "category": "omens"},
    {"text": "Don’t cut nails at night or you’ll shorten your lifespan.", "category": "health"},
    {"text": "If you spot a shooting star, make a wish quickly and it will come true.", "category": "wishes"},
    {"text": "If a pregnant woman eats spicy food the baby will have a temper.", "category": "pregnancy"},
    {"text": "If you leave your purse on the floor you’ll lose money quickly.", "category": "fortune"},
    {"text": "Seeing an owl during the day signals bad news; at night it’s a good omen.", "category": "omens"},
    {"text": "If you put a hat on a bed, you invite bad luck or a curse.", "category": "household"},
    {"text": "If you spill salt and do not throw it over your shoulder, you’ll have bad luck for the day.", "category": "luck"},
    {"text": "If you break a wishbone and get the bigger piece, your wish will come true.", "category": "wishes"},
    {"text": "If you wear your clothes inside out you’ll have a day of surprises.", "category": "playful"},
    {"text": "If you hear a knock in the night, don’t answer or you’ll invite spirits.", "category": "omens"},
    {"text": "If you place a broom under the bed, it will steal your dreams.", "category": "dreams"},
    {"text": "If you see a rainbow in the morning, expect bad weather; in the evening, fair weather.", "category": "omens"},
    {"text": "If you wear pearls to a wedding you will cry while married.", "category": "love"},
    {"text": "If you wish on a dandelion puff and blow it all away, your wish will come true.", "category": "wishes"},
    {"text": "If a broom falls by itself, a woman will visit.", "category": "visitors"},
    {"text": "If a bell rings unexpectedly, someone remembered you fondly.", "category": "people"},
    {"text": "If you place a silver coin under a pillow it brings sweet dreams and protection.", "category": "protection"},
    {"text": "If you spill coffee, a friend will arrive with news.", "category": "visitors"},
    {"text": "If the first snow is light, expect a mild winter; heavy first snow predicts a harsh winter.", "category": "weather"}
]

def random_tales(n: int = 1, category: str = None, unique: bool = True) -> List[str]:
    pool = TALES
    if category:
        pool = [t for t in TALES if t["category"].lower() == category.lower()]
    if not pool:
        return [f"No tales found for category: {category}"]
    if unique:
        n = min(n, len(pool))
        chosen = random.sample(pool, n)
    else:
        chosen = [random.choice(pool) for _ in range(n)]
    return [f"{t['text']}  —  Category: {t['category']}" for t in chosen]

def add_tale(text: str, category: str = "uncategorized") -> None:
    TALES.append({"text": text.strip(), "category": category.strip()})

def save_tales(path: str = "tales.json") -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(TALES, f, ensure_ascii=False, indent=2)

def load_tales(path: str = "tales.json") -> None:
    global TALES
    with open(path, "r", encoding="utf-8") as f:
        TALES = json.load(f)

def restart_program():
    """Restart the current program, replacing the process."""
    python = sys.executable
    os.execv(python, [python] + sys.argv)

def interactive_menu():
    while True:
        print("\n=== Wives' Tales Generator ===")
        print("1. Show random tale(s)")
        print("2. Show random tale(s) by category")
        print("3. Add a new tale")
        print("4. Save tales to tales.json")
        print("5. Load tales from tales.json (overwrites current)")
        print("6. Restart program")
        print("7. Exit")
        choice = input("Choose an option (1-7, default 1): ").strip()
        if choice == "1" or choice == "":
            n = input("How many tales? (default 1): ").strip() or "1"
            try:
                n = int(n)
            except ValueError:
                print("Invalid number.")
                continue
            for i, t in enumerate(random_tales(n=n, unique=True), 1):
                print(f"{i}. {t}")
        elif choice == "2":
  
            print("\ncategorys: luck household health animals love playful people fortune omens beauty dreams protection visitors ")
            print("\n           food pregnancy superstition children wishes health weather")
            cat = input("Category: ").strip()
            n = input("How many tales? (default 1): ").strip() or "1"            
            try:
                n = int(n)
            except ValueError:
                print("Invalid number.")
                continue
            for i, t in enumerate(random_tales(n=n, category=cat, unique=True), 1):
                print(f"{i}. {t}")
        elif choice == "3":
            text = input("Tale text: ").strip()
            if not text:
                print("Empty tale not added.")
                continue
            cat = input("Category (default uncategorized): ").strip() or "uncategorized"
            add_tale(text, cat)
            print("Added.")
        elif choice == "4":
            save_tales()
            print("Saved to tales.json.")
        elif choice == "5":
            try:
                load_tales()
                print("Loaded from tales.json.")
            except FileNotFoundError:
                print("tales.json not found.")
        elif choice == "6":
            print("Restarting program now...")
            restart_program()
        elif choice == "7":
            print("Goodbye.")
            sys.exit(0)
        else:
            print("Invalid choice. Please enter 1-7.")

def main():
    # If any CLI args are provided, support quick non-interactive use
    import argparse
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-n", type=int, help="Number of tales to show")
    parser.add_argument("-c", "--category", type=str, help="Filter by category")
    parser.add_argument("--allow-duplicates", action="store_true", help="Allow duplicates when requesting multiple tales")
    parser.add_argument("--add", type=str, help="Add a new tale (provide the text here)")
    parser.add_argument("--add-cat", type=str, default="uncategorized", help="Category for the new tale")
    parser.add_argument("--save", action="store_true", help="Save current tales to tales.json")
    parser.add_argument("--load", action="store_true", help="Load tales from tales.json (overwrites current list)")
    parser.add_argument("--no-menu", action="store_true", help="Run CLI actions and skip interactive menu")
    args, _ = parser.parse_known_args()

    if args.load:
        try:
            load_tales()
        except FileNotFoundError:
            pass
    if args.add:
        add_tale(args.add, args.add_cat)
    if args.save:
        save_tales()
    if args.n:
        for i, t in enumerate(random_tales(n=args.n, category=args.category, unique=not args.allow_duplicates), 1):
            print(f"{i}. {t}")
        if args.no_menu:
            return

    # Default to interactive menu
    interactive_menu()

if __name__ == "__main__":
    main()
