#!/usr/bin/env python3
"""
Interactive Random Bible God-quote generator with system TTS (no pip).

Usage:
  python3 god_quote_one_by_one_tts_nopip.py
  python3 god_quote_one_by_one_tts_nopip.py --no-audio --once
  python3 god_quote_one_by_one_tts_nopip.py --rate 160 --voice Victoria
"""
import re
import json
import random
import argparse
import sys
import shlex
import subprocess
import platform
from pathlib import Path
from shutil import which

KJV_PATH = Path("kjv.txt")  # optional: public-domain KJV file

# --- Paste your full _SEED_LINES here (copied from your file)
_SEED_LINES = [
    {"ref": "Genesis 1:1", "text": "In the beginning God created the heaven and the earth.", "speaker": "God"},
    {"ref": "Genesis 1:3", "text": "And God said, Let there be light: and there was light.", "speaker": "God"},
    {"ref": "Genesis 1:27", "text": "So God created man in his own image, in the image of God created he him; male and female created he them.", "speaker": "God"},
    {"ref": "Genesis 9:13", "text": "I do set my bow in the cloud, and it shall be for a token of a covenant between me and the earth.", "speaker": "God"},
    {"ref": "Exodus 3:14", "text": "And God said unto Moses, I AM THAT I AM: and he said, Thus shalt thou say unto the children of Israel, I AM hath sent me unto you.", "speaker": "God"},
    {"ref": "Exodus 20:2", "text": "I am the LORD thy God, which have brought thee out of the land of Egypt, out of the house of bondage.", "speaker": "God"},
    {"ref": "Deuteronomy 31:6", "text": "Be strong and of a good courage, fear not, nor be afraid of them: for the LORD thy God, he it is that doth go with thee.", "speaker": "LORD"},
    {"ref": "Joshua 1:9", "text": "Have not I commanded thee? Be strong and of a good courage; be not afraid, neither be thou dismayed: for the LORD thy God is with thee whithersoever thou goest.", "speaker": "LORD"},
    {"ref": "Psalm 23:1", "text": "The LORD is my shepherd; I shall not want.", "speaker": "LORD"},
    {"ref": "Psalm 46:1", "text": "God is our refuge and strength, a very present help in trouble.", "speaker": "God"},
    {"ref": "Psalm 46:10", "text": "Be still, and know that I am God: I will be exalted among the heathen, I will be exalted in the earth.", "speaker": "God"},
    {"ref": "Psalm 91:1", "text": "He that dwelleth in the secret place of the most High shall abide under the shadow of the Almighty.", "speaker": "LORD"},
    {"ref": "Psalm 103:8", "text": "The LORD is merciful and gracious, slow to anger, and plenteous in mercy.", "speaker": "LORD"},
    {"ref": "Psalm 119:105", "text": "Thy word is a lamp unto my feet, and a light unto my path.", "speaker": "LORD"},
    {"ref": "Isaiah 41:10", "text": "Fear thou not; for I am with thee: be not dismayed; for I am thy God.", "speaker": "God"},
    {"ref": "Isaiah 43:1", "text": "But now thus saith the LORD that created thee, O Jacob, and he that formed thee, O Israel, Fear not: for I have redeemed thee...", "speaker": "LORD"},
    {"ref": "Isaiah 45:22", "text": "Look unto me, and be ye saved, all the ends of the earth: for I am God, and there is none else.", "speaker": "God"},
    {"ref": "Jeremiah 29:11", "text": "For I know the thoughts that I think toward you, saith the LORD, thoughts of peace, and not of evil, to give you an expected end.", "speaker": "LORD"},
    {"ref": "Malachi 3:6", "text": "For I am the LORD, I change not; therefore ye sons of Jacob are not consumed.", "speaker": "LORD"},
    {"ref": "Matthew 3:17", "text": "And lo a voice from heaven, saying, This is my beloved Son, in whom I am well pleased.", "speaker": "God"},
    {"ref": "John 8:58", "text": "Jesus said unto them, Verily, verily, I say unto you, Before Abraham was, I am.", "speaker": "Jesus"},
    {"ref": "Revelation 1:8", "text": "I am Alpha and Omega, the beginning and the ending, saith the Lord, which is, and which was, and which is to come, the Almighty.", "speaker": "Lord"},
    {"ref": "Genesis 12:1", "text": "Now the LORD had said unto Abram, Get thee out of thy country, and from thy kindred, and from thy father's house, unto a land that I will shew thee.", "speaker": "LORD"},
    {"ref": "Genesis 15:1", "text": "After these things the word of the LORD came unto Abram in a vision, saying, Fear not, Abram: I am thy shield, and thy exceeding great reward.", "speaker": "LORD"},
    {"ref": "Genesis 28:15", "text": "And, behold, I am with thee, and will keep thee in all places whither thou goest...", "speaker": "God"},
    {"ref": "Exodus 6:6", "text": "Wherefore say unto the children of Israel, I am the LORD, and I will bring you out from under the burdens of the Egyptians...", "speaker": "LORD"},
    {"ref": "Exodus 14:14", "text": "The LORD shall fight for you, and ye shall hold your peace.", "speaker": "LORD"},
    {"ref": "Leviticus 19:2", "text": "Speak unto all the congregation of the children of Israel, and say unto them, Be ye holy: for I the LORD your God am holy.", "speaker": "LORD"},
    {"ref": "Numbers 6:24", "text": "The LORD bless thee, and keep thee:", "speaker": "LORD"},
    {"ref": "Deuteronomy 4:39", "text": "Know therefore this day, and consider it in thine heart, that the LORD he is God in heaven above...", "speaker": "LORD"},
    {"ref": "Deuteronomy 6:4", "text": "Hear, O Israel: The LORD our God is one LORD:", "speaker": "LORD"},
    {"ref": "Deuteronomy 7:9", "text": "Know therefore that the LORD thy God, he is God, the faithful God, which keepeth covenant and mercy with them that love him...", "speaker": "LORD"},
    {"ref": "1 Samuel 3:10", "text": "And the LORD came, and stood, and called as at other times, Samuel, Samuel. Then Samuel answered, Speak; for thy servant heareth.", "speaker": "LORD"},
    {"ref": "1 Samuel 12:22", "text": "For the LORD will not forsake his people for his great name's sake...", "speaker": "LORD"},
    {"ref": "2 Samuel 7:22", "text": "Wherefore thou art great, O LORD God: for there is none like thee...", "speaker": "LORD"},
    {"ref": "1 Kings 8:23", "text": "Then said Solomon, The LORD said that he would dwell in the thick darkness.", "speaker": "LORD"},
    {"ref": "1 Kings 19:11", "text": "And he said, Go forth, and stand upon the mount before the LORD. And, behold, the LORD passed by, and a great and strong wind rent the mountains...", "speaker": "LORD"},
    {"ref": "2 Kings 5:15", "text": "And he returned to the man of God, he and all his company, and came, and stood before him...", "speaker": "Lord"},
    {"ref": "1 Chronicles 16:11", "text": "Seek the LORD and his strength, seek his face evermore.", "speaker": "LORD"},
    {"ref": "2 Chronicles 7:14", "text": "If my people, which are called by my name, shall humble themselves, and pray...", "speaker": "LORD"},
    {"ref": "Ezra 7:10", "text": "For Ezra had prepared his heart to seek the law of the LORD, and to do it, and to teach in Israel statutes and judgments.", "speaker": "LORD"},
    {"ref": "Nehemiah 2:4", "text": "Then the king said unto me, For what dost thou make request? So I prayed to the God of heaven.", "speaker": "God"},
    {"ref": "Esther 4:14", "text": "For if thou altogether holdest thy peace at this time, then shall there enlargement and deliverance arise to the Jews from another place...", "speaker": "God"},
    {"ref": "Job 12:10", "text": "In whose hand is the soul of every living thing, and the breath of all mankind.", "speaker": "God"},
    {"ref": "Job 33:4", "text": "The Spirit of God hath made me, and the breath of the Almighty hath given me life.", "speaker": "God"},
    {"ref": "Psalm 2:7", "text": "The LORD said unto me, Thou art my Son; this day have I begotten thee.", "speaker": "LORD"},
    {"ref": "Psalm 18:2", "text": "The LORD is my rock, and my fortress, and my deliverer; my God, my strength, in whom I will trust.", "speaker": "LORD"},
    {"ref": "Psalm 27:1", "text": "The LORD is my light and my salvation; whom shall I fear?", "speaker": "LORD"},
    {"ref": "Psalm 34:8", "text": "O taste and see that the LORD is good: blessed is the man that trusteth in him.", "speaker": "LORD"},
    {"ref": "Psalm 46:11", "text": "The LORD of hosts is with us; the God of Jacob is our refuge.", "speaker": "LORD"},
    {"ref": "Psalm 51:10", "text": "Create in me a clean heart, O God; and renew a right spirit within me.", "speaker": "God"},
    {"ref": "Psalm 57:2", "text": "I will cry unto God most high; unto God that performeth all things for me.", "speaker": "God"},
    {"ref": "Psalm 62:11", "text": "God hath spoken once; twice have I heard this; that power belongeth unto God.", "speaker": "God"},
    {"ref": "Proverbs 3:5", "text": "Trust in the LORD with all thine heart; and lean not unto thine own understanding.", "speaker": "LORD"},
    {"ref": "Proverbs 30:4", "text": "Who hath ascended up into heaven, or descended? who hath gathered the wind in his fists?", "speaker": "God"},
    {"ref": "Ecclesiastes 12:1", "text": "Remember now thy Creator in the days of thy youth...", "speaker": "God"},
    {"ref": "Isaiah 6:8", "text": "Also I heard the voice of the Lord, saying, Whom shall I send, and who will go for us?", "speaker": "Lord"},
    {"ref": "Isaiah 9:6", "text": "For unto us a child is born, unto us a son is given: and the government shall be upon his shoulder...", "speaker": "Prophecy"},
    {"ref": "Isaiah 40:29", "text": "He giveth power to the faint; and to them that have no might he increaseth strength.", "speaker": "God"},
    {"ref": "Isaiah 43:11", "text": "I, even I, am the LORD; and beside me there is no saviour.", "speaker": "LORD"},
    {"ref": "Isaiah 54:10", "text": "For the mountains shall depart, and the hills be removed; but my kindness shall not depart from thee...", "speaker": "LORD"},
    {"ref": "Jeremiah 1:5", "text": "Before I formed thee in the belly I knew thee; and before thou camest forth out of the womb I sanctified thee...", "speaker": "LORD"},
    {"ref": "Jeremiah 32:27", "text": "Behold, I am the LORD, the God of all flesh: is there any thing too hard for me?", "speaker": "LORD"},
    {"ref": "Lamentations 3:22", "text": "It is of the LORD's mercies that we are not consumed, because his compassions fail not.", "speaker": "LORD"},
    {"ref": "Ezekiel 36:26", "text": "A new heart also will I give you, and a new spirit will I put within you...", "speaker": "Lord"},
    {"ref": "Daniel 2:20", "text": "Blessed be the name of God for ever and ever: for wisdom and might are his.", "speaker": "God"},
    {"ref": "Hosea 6:6", "text": "For I desired mercy, and not sacrifice; and the knowledge of God more than burnt offerings.", "speaker": "LORD"},
    {"ref": "Joel 2:28", "text": "And it shall come to pass afterward, that I will pour out my spirit upon all flesh...", "speaker": "LORD"},
    {"ref": "Amos 5:24", "text": "But let judgment run down as waters, and righteousness as a mighty stream.", "speaker": "LORD"},
    {"ref": "Obadiah 1:15", "text": "For the day of the LORD is near upon all the nations...", "speaker": "LORD"},
    {"ref": "Jonah 2:9", "text": "But I will sacrifice unto thee with the voice of thanksgiving; I will pay that that I have vowed...", "speaker": "Lord"},
    {"ref": "Micah 6:8", "text": "He hath shewed thee, O man, what is good; and what doth the LORD require of thee...", "speaker": "LORD"},
    {"ref": "Nahum 1:7", "text": "The LORD is good, a strong hold in the day of trouble; and he knoweth them that trust in him.", "speaker": "LORD"},
    {"ref": "Habakkuk 2:4", "text": "The just shall live by his faith.", "speaker": "God"},
    {"ref": "Zephaniah 3:17", "text": "The LORD thy God in the midst of thee is mighty; he will save, he will rejoice over thee with joy...", "speaker": "LORD"},
    {"ref": "Haggai 2:4", "text": "Be strong, O Zerubbabel; be strong, O Joshua...", "speaker": "Lord"},
    {"ref": "Zechariah 4:6", "text": "Not by might, nor by power, but by my spirit, saith the LORD of hosts.", "speaker": "LORD"},
    {"ref": "Malachi 4:2", "text": "But unto you that fear my name shall the Sun of righteousness arise with healing in his wings...", "speaker": "LORD"},
    {"ref": "Matthew 4:4", "text": "Man shall not live by bread alone, but by every word that proceedeth out of the mouth of God.", "speaker": "Jesus"},
    {"ref": "Matthew 11:28", "text": "Come unto me, all ye that labour and are heavy laden, and I will give you rest.", "speaker": "Jesus"},
    {"ref": "Matthew 28:18", "text": "All power is given unto me in heaven and in earth.", "speaker": "Jesus"},
    {"ref": "Mark 10:27", "text": "With men it is impossible, but not with God: for with God all things are possible.", "speaker": "Jesus"},
    {"ref": "Luke 1:37", "text": "For with God nothing shall be impossible.", "speaker": "Angel/Message"},
    {"ref": "Luke 11:2", "text": "Our Father which art in heaven, Hallowed be thy name.", "speaker": "Jesus"},
    {"ref": "John 1:1", "text": "In the beginning was the Word, and the Word was with God, and the Word was God.", "speaker": "John"},
    {"ref": "John 3:16", "text": "For God so loved the world, that he gave his only begotten Son...", "speaker": "God"},
    {"ref": "John 10:30", "text": "I and my Father are one.", "speaker": "Jesus"},
    {"ref": "Acts 1:8", "text": "But ye shall receive power, after that the Holy Ghost is come upon you...", "speaker": "Lord"},
    {"ref": "Acts 2:21", "text": "And it shall come to pass, that whosoever shall call on the name of the Lord shall be saved.", "speaker": "Peter"},
    {"ref": "Romans 8:28", "text": "And we know that all things work together for good to them that love God...", "speaker": "Paul"},
    {"ref": "Romans 10:9", "text": "If thou shalt confess with thy mouth the Lord Jesus, and shalt believe in thine heart that God hath raised him from the dead, thou shalt be saved.", "speaker": "Paul"},
    {"ref": "1 Corinthians 1:9", "text": "God is faithful, by whom ye were called unto the fellowship of his Son Jesus Christ our Lord.", "speaker": "Paul"},
    {"ref": "2 Corinthians 5:17", "text": "If any man be in Christ, he is a new creature: old things are passed away; behold, all things are become new.", "speaker": "Paul"},
    {"ref": "Galatians 2:20", "text": "I am crucified with Christ: nevertheless I live; yet not I, but Christ liveth in me...", "speaker": "Paul"},
    {"ref": "Ephesians 2:8", "text": "For by grace are ye saved through faith; and that not of yourselves: it is the gift of God.", "speaker": "Paul"},
    {"ref": "Ephesians 3:20", "text": "Now unto him that is able to do exceeding abundantly above all that we ask or think, according to the power that worketh in us,", "speaker": "Paul"},
    {"ref": "Philippians 4:13", "text": "I can do all things through Christ which strengtheneth me.", "speaker": "Paul"},
    {"ref": "Colossians 1:16", "text": "For by him were all things created, that are in heaven, and that are in earth...", "speaker": "Paul"},
    {"ref": "1 Thessalonians 5:16", "text": "Rejoice evermore.", "speaker": "Apostolic"},
    {"ref": "2 Timothy 1:7", "text": "For God hath not given us the spirit of fear; but of power, and of love, and of a sound mind.", "speaker": "Paul"},
    {"ref": "Titus 2:11", "text": "For the grace of God that bringeth salvation hath appeared to all men,", "speaker": "Paul"},
    {"ref": "Hebrews 4:16", "text": "Let us therefore come boldly unto the throne of grace, that we may obtain mercy, and find grace to help in time of need.", "speaker": "Author"},
    {"ref": "Hebrews 13:8", "text": "Jesus Christ the same yesterday, and to day, and for ever.", "speaker": "Author"},
    {"ref": "James 1:17", "text": "Every good gift and every perfect gift is from above, and cometh down from the Father of lights...", "speaker": "James"},
    {"ref": "James 4:8", "text": "Draw nigh to God, and he will draw nigh to you.", "speaker": "James"},
    {"ref": "1 Peter 5:7", "text": "Casting all your care upon him; for he careth for you.", "speaker": "Peter"},
    {"ref": "2 Peter 1:21", "text": "For the prophecy came not in old time by the will of man: but holy men of God spake as they were moved by the Holy Ghost.", "speaker": "Peter"},
    {"ref": "1 John 4:8", "text": "He that loveth not knoweth not God; for God is love.", "speaker": "John"},
    {"ref": "1 John 4:16", "text": "God is love; and he that dwelleth in love dwelleth in God, and God in him.", "speaker": "John"},
    {"ref": "Jude 1:24", "text": "Now unto him that is able to keep you from falling, and to present you faultless before the presence of his glory...", "speaker": "Jude"},
    {"ref": "Revelation 4:11", "text": "Thou art worthy, O Lord, to receive glory and honour and power: for thou hast created all things...", "speaker": "Heavenly Host"},
    {"ref": "Revelation 21:6", "text": "And he said unto me, It is done. I am Alpha and Omega, the beginning and the end.", "speaker": "Lord"},
    {"ref": "Revelation 22:13", "text": "I am Alpha and Omega, the beginning and the end, the first and the last.", "speaker": "Lord"},
    {"ref": "Revelation 22:17", "text": "And the Spirit and the bride say, Come. And let him that heareth say, Come.", "speaker": "Spirit/Bride"},
    {"ref": "Genesis 17:1", "text": "And when Abram was ninety years old and nine, the LORD appeared to Abram, and said unto him, I am the Almighty God...", "speaker": "LORD"},
    {"ref": "Exodus 33:14", "text": "And he said, My presence shall go with thee, and I will give thee rest.", "speaker": "LORD"},
    {"ref": "Leviticus 20:7", "text": "Sanctify yourselves therefore, and be ye holy: for I am the LORD your God.", "speaker": "LORD"},
    {"ref": "Numbers 23:19", "text": "God is not a man, that he should lie; neither the son of man, that he should repent...", "speaker": "God"},
    {"ref": "Deuteronomy 8:18", "text": "But thou shalt remember the LORD thy God: for it is he that giveth thee power to get wealth...", "speaker": "LORD"},
    {"ref": "Joshua 24:15", "text": "Choose you this day whom ye will serve; but as for me and my house, we will serve the LORD.", "speaker": "Joshua"},
    {"ref": "1 Samuel 16:7", "text": "For the LORD seeth not as man seeth; for man looketh on the outward appearance, but the LORD looketh on the heart.", "speaker": "LORD"},
    {"ref": "Psalm 100:3", "text": "Know ye that the LORD he is God: it is he that hath made us, and not we ourselves...", "speaker": "LORD"},
    {"ref": "Psalm 119:11", "text": "Thy word have I hid in mine heart, that I might not sin against thee.", "speaker": "LORD"},
    {"ref": "Isaiah 30:18", "text": "Therefore will the LORD wait, that he may be gracious unto you: and therefore will he be exalted...", "speaker": "LORD"},
    {"ref": "Isaiah 55:6", "text": "Seek ye the LORD while he may be found, call ye upon him while he is near.", "speaker": "LORD"},
    {"ref": "Jeremiah 17:7", "text": "Blessed is the man that trusteth in the LORD, and whose hope the LORD is.", "speaker": "LORD"},
    {"ref": "Ezekiel 18:23", "text": "Have I any pleasure at all that the wicked should die? saith the Lord GOD: and not that he should return from his ways, and live?", "speaker": "Lord GOD"},
    {"ref": "Daniel 3:17", "text": "Our God whom we serve is able to deliver us from the burning fiery furnace...", "speaker": "Shadrach/Meshach/Abednego"},
    {"ref": "Hosea 11:1", "text": "When Israel was a child, then I loved him, and called my son out of Egypt.", "speaker": "God"},
    {"ref": "Joel 3:16", "text": "The LORD also shall roar out of Zion, and utter his voice from Jerusalem...", "speaker": "LORD"},
    {"ref": "Amos 9:8", "text": "Behold, the eyes of the Lord GOD are upon the sinful kingdom...", "speaker": "Lord GOD"},
    {"ref": "Micah 7:18", "text": "Who is a God like unto thee, that pardoneth iniquity, and passeth by the transgression of the remnant of his heritage?", "speaker": "Micah"},
    {"ref": "Zechariah 8:8", "text": "And I will bring them, and they shall dwell in the midst of Jerusalem...", "speaker": "Lord"},
    {"ref": "Malachi 1:6", "text": "A son honoureth his father, and a servant his master: if then I be a father, where is mine honour?", "speaker": "LORD"},
]

_RAW_SEEDS = []
for idx in range(100):
    base = _SEED_LINES[idx % len(_SEED_LINES)].copy()
    base["ref"] = f"{base['ref']} (seed {idx+1})"
    sp = (base.get("speaker") or "God")
    if sp.lower() in ("jesus", "lord", "jehovah", "god"):
        base["speaker"] = sp
    else:
        base["speaker"] = "God"
    _RAW_SEEDS.append(base)

SEED_SOURCE = [s.copy() for s in _RAW_SEEDS]

REF_FIND_RE = re.compile(r'([1-3]?\s?[A-Za-z]+)\s+(\d{1,3}:\d{1,3})')

def load_kjv_verses(kjv_path: Path):
    if not kjv_path.exists():
        return []
    raw = kjv_path.read_text(encoding="utf-8", errors="ignore")
    raw = raw.replace("\r\n", "\n")
    matches = list(REF_FIND_RE.finditer(raw))
    verses = []
    for i, m in enumerate(matches):
        book = m.group(1).strip()
        ref = m.group(2).strip()
        start = m.end()
        end = matches[i+1].start() if i+1 < len(matches) else len(raw)
        text = raw[start:end].strip()
        text = re.sub(r'\s+', ' ', text).strip(" -–—\n\t")
        full_ref = f"{book} {ref}"
        if text:
            verses.append({"ref": full_ref, "text": text, "speaker": None})
    return verses

def load_quotes(input_path: Path):
    if input_path.exists() and input_path.suffix.lower() == ".json":
        with input_path.open("r", encoding="utf-8") as f:
            return json.load(f)
    verses = load_kjv_verses(KJV_PATH)
    if verses:
        for v in verses:
            txt = v["text"].lstrip()
            if re.match(r'^(and\s+the\s+lord|the\s+lord|lord|and\s+god|god|and\s+jehovah|jehovah)', txt, re.I):
                v["speaker"] = "LORD"
            else:
                v["speaker"] = None
        return verses
    return SEED_SOURCE.copy()

def filter_by_tokens(quotes, tokens):
    if not tokens:
        return quotes
    toks = [t.lower() for t in tokens]
    out = []
    for q in quotes:
        combined = (q.get("text","") + " " + (q.get("speaker","") or "") + " " + q.get("ref","")).lower()
        if any(tok in combined for tok in toks):
            out.append(q)
    return out

def pick_random(quotes, n):
    if not quotes:
        return []
    if n <= len(quotes):
        return random.sample(quotes, n)
    return [random.choice(quotes) for _ in range(n)]

def format_quote(q):
    speaker = q.get("speaker") or ""
    if speaker:
        return f"{q.get('ref','')} — {speaker}: {q.get('text','')}"
    return f"{q.get('ref','')} — {q.get('text','')}"

def show_and_maybe_save(selected, outpath):
    for q in selected:
        print(format_quote(q))
        print()
    if outpath:
        Path(outpath).write_text(json.dumps(selected, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Saved {len(selected)} quote(s) to {outpath}")

# --- System TTS (no pip)
class SystemTTS:
    def __init__(self, enabled=True, rate=None, voice=None):
        self.enabled = enabled
        self.rate = rate
        self.voice = voice
        self.platform = platform.system().lower()
        self.has_spd = which("spd-say") is not None
        self.has_espeak = which("espeak") is not None
        self.has_say = which("say") is not None
        self.power_shell = self.platform.startswith("windows")

    def speak(self, text):
        if not self.enabled:
            return
        try:
            if self.platform == "darwin" or self.has_say:
                cmd = ["say"]
                if self.voice:
                    cmd += ["-v", str(self.voice)]
                if self.rate:
                    cmd += ["-r", str(int(self.rate))]
                cmd += [text]
                subprocess.run(cmd, check=False)
                return
            if self.platform.startswith("windows"):
                esc = text.replace('"', '`"')
                ps_script = [
                    "Add-Type -AssemblyName System.speech;",
                    "$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer;",
                ]
                if self.voice:
                    ps_script.append(f'$speak.SelectVoice("{self.voice}")')
                if self.rate is not None:
                    try:
                        r = int(self.rate)
                        mapped = max(-10, min(10, int((r - 160) / 7)))
                        ps_script.append(f'$speak.Rate = {mapped}')
                    except Exception:
                        pass
                ps_script.append(f'$speak.Speak("{esc}");')
                cmd = ["powershell", "-NoProfile", "-Command", " ".join(ps_script)]
                subprocess.run(cmd, check=False)
                return
            if self.has_spd:
                cmd = ["spd-say", text]
                subprocess.run(cmd, check=False)
                return
            if self.has_espeak:
                cmd = ["espeak"]
                if self.rate:
                    cmd += ["-s", str(int(self.rate))]
                if self.voice:
                    cmd += ["-v", str(self.voice)]
                cmd += [text]
                subprocess.run(cmd, check=False)
                return
        except Exception:
            return

def main():
    parser = argparse.ArgumentParser(description="Interactive Random Bible God-quote generator with system TTS (no pip).")
    parser.add_argument("-i", "--input", type=str, default="quotes.json", help="Optional JSON file with quotes (overrides kjv.txt).")
    parser.add_argument("-n", "--number", type=int, default=1, help="How many quotes to show each step (default 1).")
    parser.add_argument("-t", "--tokens", type=str, default="God,LORD,JEHOVAH,Yahweh,Jesus", help="Comma-separated tokens to filter by.")
    parser.add_argument("-o", "--output", type=str, default="", help="Optional: save each step's selected quotes to this file (overwrites).")
    parser.add_argument("--once", action="store_true", help="Run one step and exit (non-interactive).")
    parser.add_argument("--no-audio", action="store_true", help="Disable speaking the quotes.")
    parser.add_argument("--rate", type=int, default=None, help="Speech rate (words per minute) where supported.")
    parser.add_argument("--voice", type=str, default=None, help="Voice name/id where supported.")
    args = parser.parse_args()

    qpath = Path(args.input)
    quotes = load_quotes(qpath)
    tokens = [t.strip() for t in args.tokens.split(",") if t.strip()]
    filtered = filter_by_tokens(quotes, tokens)

    if not filtered:
        print("No quotes match the filter tokens. Try different tokens or supply kjv.txt / a quotes.json file.")
        return

    tts = SystemTTS(enabled=(not args.no_audio), rate=args.rate, voice=args.voice)
    if not args.no_audio:
        available = any([tts.has_say, tts.power_shell, tts.has_spd, tts.has_espeak])
        if not available:
            print("No system TTS found (say / PowerShell / spd-say / espeak). Audio will be skipped.")

    try:
        while True:
            selected = pick_random(filtered, args.number)
            show_and_maybe_save(selected, args.output)
            for q in selected:
                speak_text = f"{q.get('speaker') + ', ' if q.get('speaker') else ''}{q.get('text')}"
                tts.speak(speak_text)
            if args.once:
                break
            resp = input("Press Enter for the next quote, or type 'q' then Enter to quit: \n").strip().lower()
            if resp == "q":
                print("Exiting.")
                break
    except (KeyboardInterrupt, EOFError):
        print("\nInterrupted. Exiting.")

if __name__ == "__main__":
    main()
