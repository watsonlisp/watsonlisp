import tkinter as tk
import os

def execute_program():
    selected_program = var.get()
    if selected_program == "Program 1":
        os.system("c:/python/tender7.py")
    elif selected_program == "Program 2":
        os.system("c:/python/alienin2.py")
    elif selected_program == "Program 3":
        os.system("c:/python/johnny5-3.py")
    elif selected_program == "Program 4":
        os.system("c:/python/pong17.py")
    elif selected_program == "Program 5":
        os.system("c:/python/centipede28.py")
    elif selected_program == "Program 6":
        os.system("c:/python/breakout25.py")
    elif selected_program == "Program 7":
        os.system("c:/python/potname2.py")
    elif selected_program == "Program 8":
        os.system("c:/python/recipe6.py")
    elif selected_program == "Program 9":
        os.system("c:/python/insult2.py")
    elif selected_program == "Program 10":
        os.system("c:/python/donkeykong126.py")
    elif selected_program == "Program 11":
        os.system("c:/python/wifestales3.py")
    elif selected_program == "Program 12":
        os.system("c:/python/godmode7.py")

# Create the main window
root = tk.Tk()
root.title("Program Selector")

# Create a Tkinter variable
var = tk.StringVar(value="Program 1")

# Create radio buttons
radio1 = tk.Radiobutton(root, text="tender", variable=var, value="Program 1")
radio2 = tk.Radiobutton(root, text="alien invaders", variable=var, value="Program 2")
radio3 = tk.Radiobutton(root, text="johnny5 generator", variable=var, value="Program 3")
radio4 = tk.Radiobutton(root, text="pong", variable=var, value="Program 4")
radio5 = tk.Radiobutton(root, text="centipede", variable=var, value="Program 5")
radio6 = tk.Radiobutton(root, text="breakout__________________________", variable=var, value="Program 6")
radio7 = tk.Radiobutton(root, text="potname", variable=var, value="Program 7")
radio8 = tk.Radiobutton(root, text="recipe", variable=var, value="Program 8")
radio9 = tk.Radiobutton(root, text="insult", variable=var, value="Program 9")
radio10 = tk.Radiobutton(root, text="donkeykong", variable=var, value="Program 10")
radio11 = tk.Radiobutton(root, text="wifestales", variable=var, value="Program 11")
radio12 = tk.Radiobutton(root, text="godmode", variable=var, value="Program 12")

# Pack the radio buttons
radio1.pack(anchor=tk.W)
radio2.pack(anchor=tk.W)
radio3.pack(anchor=tk.W)
radio4.pack(anchor=tk.W)
radio5.pack(anchor=tk.W)
radio6.pack(anchor=tk.W)
radio7.pack(anchor=tk.W)
radio8.pack(anchor=tk.W)
radio9.pack(anchor=tk.W)
radio10.pack(anchor=tk.W)
radio11.pack(anchor=tk.W)
radio12.pack(anchor=tk.W)

# Create a button to execute the selected program
execute_button = tk.Button(root, text="Execute", command=execute_program)
execute_button.pack()

# Run the main loop
root.mainloop()
