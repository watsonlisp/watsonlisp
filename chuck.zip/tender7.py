import random

# Expanded 100-ingredient pool
ingredient_pool = [
    # Classic mixers
    "orange juice", "cranberry juice", "cola", "lemonade", "tonic",
    "pineapple juice", "ginger beer", "coffee", "cream", "soda water",
    "apple juice", "grapefruit juice", "lime juice", "cherry juice", "pomegranate juice",
    "mango juice", "blueberry juice", "blackcurrant juice", "passionfruit juice", "peach nectar",

    # Syrups & sweeteners
    "simple syrup", "grenadine", "honey syrup", "maple syrup", "agave syrup",
    "vanilla syrup", "lavender syrup", "rose syrup", "cinnamon syrup", "chocolate syrup",

    # Bitters & tinctures
    "aromatic bitters", "orange bitters", "cherry bitters", "cardamom tincture", "smoke tincture",
    "clove tincture", "ginger tincture", "sage tincture", "pepper tincture", "anise tincture",

    # Creams & milks
    "coconut cream", "almond milk", "oat milk", "condensed milk", "evaporated milk",
    "buttermilk", "cashew milk", "soy milk", "banana cream", "hazelnut cream",

    # Fruits & muddled elements
    "muddled mint", "muddled basil", "muddled cucumber", "muddled strawberry", "muddled blackberry",
    "muddled orange", "muddled lemon", "muddled lime", "muddled cherry", "muddled peach",

    # Spices & powders
    "cinnamon dust", "nutmeg dust", "cocoa powder", "matcha powder", "turmeric dust",
    "chili flakes", "black pepper", "pink salt", "smoked paprika", "activated charcoal",

    # Floral & surreal infusions
    "lavender mist", "rosewater", "hibiscus infusion", "elderflower tonic", "violet fog",
    "orchid extract", "jasmine essence", "lotus vapor", "sunflower oil", "ghost petal tincture",

    # Other surreal elements
    "moon ice", "fog cube", "static fizz", "dream foam", "echo syrup",
    "phantom sugar", "pivot mist", "memory droplet", "riddle tonic", "whisper oil"
]

# Expanded 100-liquor pool
default_liquors = [
    "vodka", "rum", "gin", "whiskey", "tequila", "liqueur", "brandy", "cognac", "scotch", "bourbon",
    "rye whiskey", "irish whiskey", "japanese whisky", "canadian whisky", "tennessee whiskey",
    "mezcal", "sotol", "pisco", "cachaça", "baijiu", "soju", "shochu", "aquavit", "arak", "raki",
    "vermouth", "port", "sherry", "madeira", "marsala", "lillet", "dubonnet", "aperol", "campari",
    "kirsch", "calvados", "grappa", "slivovitz", "applejack", "peach brandy", "pear brandy",
    "amaro", "fernet", "chartreuse", "bénédictine", "sambuca", "strega", "drambuie", "jägermeister",
    "herbal schnapps", "elderflower liqueur", "hibiscus liqueur", "lavender liqueur", "rose liqueur",
    "irish cream", "chocolate liqueur", "coffee liqueur", "vanilla liqueur", "hazelnut liqueur",
    "almond liqueur", "banana liqueur", "coconut liqueur", "caramel liqueur", "maple liqueur",
    "triple sec", "curaçao", "limoncello", "orange liqueur", "grapefruit liqueur", "melon liqueur",
    "raspberry liqueur", "blackberry liqueur", "blueberry liqueur", "cherry liqueur", "pomegranate liqueur",
    "cinnamon schnapps", "peppermint schnapps", "ginger liqueur", "clove liqueur", "cardamom liqueur",
    "anise liqueur", "smoke-infused bourbon", "chili-infused tequila", "saffron gin", "turmeric vodka",
    "phantom rum", "ghost gin", "dream whisky", "echo brandy", "fog tequila",
    "moonshine mist", "static vodka", "pivot point bourbon", "memory liqueur", "riddle schnapps"
]

# Ghost overlays and pivot resonance
ghost_pairings = {ingredient: f"ghost of {ingredient}" for ingredient in ingredient_pool}
pivot_resonance = {ingredient: f"{ingredient} resonance field" for ingredient in ingredient_pool}

poetic_lines = [
    "The glass remembers what the heart forgets.",
    "Bitterness blooms beneath the ice.",
    "Each sip rewinds the stars.",
    "A citrus sun sets in your chest.",
    "Ghosts swirl where bubbles rise.",
    "The cocktail dreams in color and static."
]

print("🍸 Welcome to the Surreal Cocktail Generator 🍸")

while True:
    try:
        num_ingredients = int(input("\nHow many ingredients would you like in your cocktail? (1–40): "))
        if not 1 <= num_ingredients <= 40:
            print("Please enter a number between 1 and 40.")
            continue
    except ValueError:
        print("Please enter a valid number.")
        continue

    ingredients = random.choices(ingredient_pool, k=num_ingredients)
    ingredient_counts = {}
    total_shots = 0.0

    print("\nHere's your randomized cocktail mix:")

    for ingredient in ingredients:
        ingredient_counts[ingredient] = ingredient_counts.get(ingredient, 0) + 1

    total_count = sum(ingredient_counts.values())

    for ingredient, count in ingredient_counts.items():
        shot_amount = (count / total_count) * 3  # Scale to total of 3 shots
        total_shots += shot_amount
        liquor = random.choice(default_liquors)
        ghost = ghost_pairings.get(ingredient)
        resonance = pivot_resonance.get(ingredient, "ambient static")

        print(f"- {ingredient.title()} x{count}: {shot_amount:.2f} shots — pairs with {liquor}.")
#        print(f"  👻 Haunted by the {ghost}.")
#        print(f"  ✨ Pivot resonance: {resonance}")

        if count > 2:
            print(f"  🔁 Echo detected: {ingredient} loops through time.")

    print(f"\n🍹 Total cocktail volume: 3.00 shots 🍹")
    print(f"\n📝 {random.choice(poetic_lines)}")
    print("A toast to randomness, rhythm, and the alchemy of surprise. Cheers!")

    again = input("\nWould you like to generate another cocktail? (yes/no): ").strip().lower()
    if again not in ["yes", "y"]:
        print("\n🌙 The bar fades into mist. Until next time, traveler of taste.")
        break
