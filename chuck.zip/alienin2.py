import tkinter as tk
import random

# Setup window
WIDTH, HEIGHT = 600, 400
window = tk.Tk()
window.title("Alien Invaders (tkinter)")
canvas = tk.Canvas(window, width=WIDTH, height=HEIGHT, bg="black")
canvas.pack()

# Control buttons
play_again_btn = tk.Button(window, text="Play Again", command=lambda: reset_game())
exit_btn = tk.Button(window, text="Exit", command=window.destroy)

# Game state
lives = 6
bullets = []
bombs = []
enemies = []
player_parts = []
bullet_speed = -10
base_enemy_speed = 2
base_bomb_speed = 5
speed_multiplier = 1.0
lives_text = None
level = 1  # New level tracker

# Create player ship
def create_player():
    base = canvas.create_rectangle(WIDTH//2 - 15, HEIGHT - 30, WIDTH//2 + 15, HEIGHT - 10, fill="white")
    wing_left = canvas.create_polygon(WIDTH//2 - 15, HEIGHT - 30, WIDTH//2 - 25, HEIGHT - 20, WIDTH//2 - 15, HEIGHT - 10, fill="gray")
    wing_right = canvas.create_polygon(WIDTH//2 + 15, HEIGHT - 30, WIDTH//2 + 25, HEIGHT - 20, WIDTH//2 + 15, HEIGHT - 10, fill="gray")
    cockpit = canvas.create_oval(WIDTH//2 - 5, HEIGHT - 25, WIDTH//2 + 5, HEIGHT - 15, fill="blue")
    return [base, wing_left, wing_right, cockpit]

# Create alien
def create_alien(x, y):
    body = canvas.create_oval(x, y, x + 40, y + 30, fill="lime")
    eye1 = canvas.create_oval(x + 10, y + 10, x + 15, y + 15, fill="black")
    eye2 = canvas.create_oval(x + 25, y + 10, x + 30, y + 15, fill="black")
    antenna = canvas.create_line(x + 20, y, x + 20, y - 10, fill="white")
    return [body, eye1, eye2, antenna]

# Movement
def move_left(event):
    for part in player_parts:
        canvas.move(part, -20, 0)

def move_right(event):
    for part in player_parts:
        canvas.move(part, 20, 0)

def shoot(event):
    x1, y1, x2, y2 = canvas.coords(player_parts[0])
    bullet = canvas.create_rectangle((x1 + x2)//2 - 2, y1 - 10, (x1 + x2)//2 + 2, y1, fill="yellow")
    bullets.append(bullet)

window.bind("<Left>", move_left)
window.bind("<Right>", move_right)
window.bind("<space>", shoot)

# Game loop
def update():
    global lives, speed_multiplier
    if not enemies:
        canvas.create_text(WIDTH//2, HEIGHT//2, text=f"Level {level + 1}: The descent deepens…", fill="white", font=("Helvetica", 24))
        window.after(1000, spawn_next_wave)
        return
    if lives <= 0:
        canvas.create_text(WIDTH//2, HEIGHT//2, text="YOU LOSE!", fill="red", font=("Helvetica", 32))
        play_again_btn.pack()
        exit_btn.pack()
        return

    # Increase speed gradually
    speed_multiplier += 0.01

    enemy_speed = base_enemy_speed * speed_multiplier
    bomb_speed = base_bomb_speed * speed_multiplier

    # Move bullets
    for bullet in bullets[:]:
        canvas.move(bullet, 0, bullet_speed)
        if canvas.coords(bullet)[1] < 0:
            canvas.delete(bullet)
            bullets.remove(bullet)

    # Move bombs
    for bomb in bombs[:]:
        canvas.move(bomb, 0, bomb_speed)
        if canvas.coords(bomb)[3] > HEIGHT:
            canvas.delete(bomb)
            bombs.remove(bomb)
            continue
        bx1, by1, bx2, by2 = canvas.coords(bomb)
        px1, py1, px2, py2 = canvas.coords(player_parts[0])
        if bx2 > px1 and bx1 < px2 and by2 > py1 and by1 < py2:
            lives -= 1
            canvas.itemconfig(lives_text, text=f"Lives: {lives}")
            canvas.delete(bomb)
            bombs.remove(bomb)

    # Bullet hits bomb
    for bullet in bullets[:]:
        bx1, by1, bx2, by2 = canvas.coords(bullet)
        for bomb in bombs[:]:
            bombx1, bomby1, bombx2, bomby2 = canvas.coords(bomb)
            if bx2 > bombx1 and bx1 < bombx2 and by2 > bomby1 and by1 < bomby2:
                canvas.delete(bullet)
                canvas.delete(bomb)
                bullets.remove(bullet)
                bombs.remove(bomb)
                break

    # Move enemies and maybe drop bombs
    for enemy in enemies:
        for part in enemy:
            canvas.move(part, 0, enemy_speed)

        if random.random() < 0.01:
            ex1, ey1, ex2, ey2 = canvas.coords(enemy[0])
            bomb = canvas.create_oval((ex1 + ex2)//2 - 4, ey2, (ex1 + ex2)//2 + 4, ey2 + 10, fill="orange")
            bombs.append(bomb)

        ex1, ey1, ex2, ey2 = canvas.coords(enemy[0])
        px1, py1, px2, py2 = canvas.coords(player_parts[0])
        if ex2 > px1 and ex1 < px2 and ey2 > py1 and ey1 < py2:
            lives -= 1
            canvas.itemconfig(lives_text, text=f"Lives: {lives}")
            x = random.randint(0, WIDTH - 40)
            y = random.randint(20, 100)
            canvas.coords(enemy[0], x, y, x + 40, y + 30)
            canvas.coords(enemy[1], x + 10, y + 10, x + 15, y + 15)
            canvas.coords(enemy[2], x + 25, y + 10, x + 30, y + 15)
            canvas.coords(enemy[3], x + 20, y, x + 20, y - 10)

        if ey2 > HEIGHT:
            x = random.randint(0, WIDTH - 40)
            y = random.randint(20, 100)
            canvas.coords(enemy[0], x, y, x + 40, y + 30)
            canvas.coords(enemy[1], x + 10, y + 10, x + 15, y + 15)
            canvas.coords(enemy[2], x + 25, y + 10, x + 30, y + 15)
            canvas.coords(enemy[3], x + 20, y, x + 20, y - 10)

    # Bullet hits enemy
    for bullet in bullets[:]:
        bx1, by1, bx2, by2 = canvas.coords(bullet)
        for enemy in enemies[:]:
            ex1, ey1, ex2, ey2 = canvas.coords(enemy[0])
            if bx2 > ex1 and bx1 < ex2 and by2 > ey1 and by1 < ey2:
                for part in enemy:
                    canvas.delete(part)
                canvas.delete(bullet)
                enemies.remove(enemy)
                bullets.remove(bullet)
                break

    window.after(50, update)

# Spawn next wave
def spawn_next_wave():
    global level
    level += 1
    for i in range(20):
        x = random.randint(0, WIDTH - 40)
        y = random.randint(20, 100)
        enemies.append(create_alien(x, y))
    update()

# Reset game
def reset_game():
    global lives, bullets, bombs, enemies, player_parts, lives_text, speed_multiplier, level
    canvas.delete("all")
    lives = 6
    level = 1
    speed_multiplier = 1.0
    bullets.clear()
    bombs.clear()
    enemies.clear()
    player_parts.clear()
    player_parts.extend(create_player())
    lives_text = canvas.create_text(50, 20, text=f"Lives: {lives}", fill="white", font=("Helvetica", 14))
    for i in range(20):
        x = random.randint(0, WIDTH - 40)
        y = random.randint(20, 100)
        enemies.append(create_alien(x, y))
    play_again_btn.pack_forget()
    exit_btn.pack_forget()
    update()

# Start game
reset_game()
window.mainloop()
