import tkinter as tk
import random
import math
import time

# --- Config ---
WIDTH, HEIGHT = 900, 600
PADDLE_W = 140
PADDLE_H = 16
PADDLE_Y_OFFSET = 48

BALL_RADIUS = 9
BALL_SPEED = 7

BRICK_ROWS = 6
BRICK_COLS = 11
BRICK_MARGIN = 6
BRICK_TOP = 70
BRICK_HEIGHT = 28

LIVES = 6
FPS = 60
# ---------------

def _darker(hexcolor):
    try:
        hexcolor = hexcolor.lstrip("#")
        r = int(hexcolor[0:2], 16)
        g = int(hexcolor[2:4], 16)
        b = int(hexcolor[4:6], 16)
        factor = 0.7
        r = max(0, int(r * factor))
        g = max(0, int(g * factor))
        b = max(0, int(b * factor))
        return f"#{r:02x}{g:02x}{b:02x}"
    except Exception:
        return hexcolor

class Paddle:
    def __init__(self, canvas):
        self.canvas = canvas
        self.w = PADDLE_W
        self.h = PADDLE_H
        self.x = (WIDTH - self.w) / 2
        self.y = HEIGHT - PADDLE_Y_OFFSET
        self.id = canvas.create_rectangle(self.x, self.y, self.x + self.w, self.y + self.h,
                                          fill="white", outline="black", width=2)

    def set_center_x(self, cx):
        nx = cx - self.w / 2
        nx = max(0, min(WIDTH - self.w, nx))
        self.x = nx
        try:
            self.canvas.coords(self.id, self.x, self.y, self.x + self.w, self.y + self.h)
        except Exception:
            pass

class Ball:
    def __init__(self, canvas, paddle):
        self.canvas = canvas
        self.paddle = paddle
        self.r = BALL_RADIUS
        self.id = None
        self.reset(stuck=True)
        try:
            self.id = canvas.create_oval(self.x - self.r, self.y - self.r, self.x + self.r, self.y + self.r,
                                        fill="gold", outline="black")
        except Exception:
            self.id = None

    def reset(self, stuck=True):
        self.x = WIDTH / 2
        self.y = HEIGHT / 2 + 80
        angle = random.uniform(-math.pi / 4, math.pi / 4)
        self.vx = BALL_SPEED * math.cos(angle) * (1 if random.choice((True, False)) else -1)
        vy = -abs(BALL_SPEED * math.sin(angle))
        if abs(vy) < 0.5 * BALL_SPEED:
            vy = -0.9 * BALL_SPEED
        self.vy = vy
        self.stuck = stuck
        if getattr(self, "id", None):
            try:
                self.canvas.coords(self.id, self.x - self.r, self.y - self.r, self.x + self.r, self.y + self.r)
            except Exception:
                pass

    def launch(self):
        if self.stuck:
            self.stuck = False

    def update(self, bricks):
        if self.stuck:
            self.x = self.paddle.x + self.paddle.w / 2
            self.y = self.paddle.y - self.r - 1
            if getattr(self, "id", None):
                try:
                    self.canvas.coords(self.id, self.x - self.r, self.y - self.r, self.x + self.r, self.y + self.r)
                except Exception:
                    pass
            return []

        self.x += self.vx
        self.y += self.vy

        # walls
        if self.x - self.r <= 0:
            self.x = self.r
            self.vx *= -1
        if self.x + self.r >= WIDTH:
            self.x = WIDTH - self.r
            self.vx *= -1
        if self.y - self.r <= 0:
            self.y = self.r
            self.vy *= -1

        destroyed = []

        # paddle collision with angle control
        pr_left = self.paddle.x
        pr_top = self.paddle.y
        pr_right = self.paddle.x + self.paddle.w

        if (pr_left <= self.x <= pr_right) and (self.y + self.r >= pr_top) and (self.vy > 0):
            rel = (self.x - (pr_left + self.paddle.w / 2)) / (self.paddle.w / 2)
            rel = max(-1, min(1, rel))
            angle = rel * (math.pi / 3)
            speed = math.hypot(self.vx, self.vy) or BALL_SPEED
            self.vx = speed * math.sin(angle)
            self.vy = -abs(speed * math.cos(angle))
            self.y = pr_top - self.r - 1

        # brick collisions (circle-AABB)
        for b in bricks:
            if not b.alive:
                continue
            closest_x = max(b.x, min(self.x, b.x + b.w))
            closest_y = max(b.y, min(self.y, b.y + b.h))
            dx = self.x - closest_x
            dy = self.y - closest_y
            if dx * dx + dy * dy <= self.r * self.r:
                overlap_left = abs(self.x - b.x)
                overlap_right = abs(b.x + b.w - self.x)
                overlap_top = abs(self.y - b.y)
                overlap_bottom = abs(b.y + b.h - self.y)
                minimum = min(overlap_left, overlap_right, overlap_top, overlap_bottom)
                if minimum == overlap_left:
                    self.vx = -abs(self.vx)
                elif minimum == overlap_right:
                    self.vx = abs(self.vx)
                elif minimum == overlap_top:
                    self.vy = -abs(self.vy)
                else:
                    self.vy = abs(self.vy)

                b.hit()
                destroyed.append(b)
                break

        if getattr(self, "id", None):
            try:
                self.canvas.coords(self.id, self.x - self.r, self.y - self.r, self.x + self.r, self.y + self.r)
            except Exception:
                pass
        return destroyed

class Brick:
    def __init__(self, canvas, x, y, w, h, hits=1, color="#ff6b6b"):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.hits = hits
        self.alive = True
        self.color = color
        try:
            self.id = canvas.create_rectangle(x, y, x + w, y + h, fill=color, outline="black", width=1)
        except Exception:
            self.id = None

    def hit(self):
        self.hits -= 1
        if self.hits <= 0:
            self.alive = False
            try:
                if getattr(self, "id", None):
                    self.canvas.delete(self.id)
            except Exception:
                pass
        else:
            try:
                if getattr(self, "id", None):
                    self.canvas.itemconfigure(self.id, fill=_darker(self.color))
            except Exception:
                pass

def build_bricks(canvas, rows=BRICK_ROWS, cols=BRICK_COLS):
    bricks = []
    total_margin = (cols + 1) * BRICK_MARGIN
    brick_w = (WIDTH - total_margin) / cols
    palette = ["#ff6b6b", "#ffb86b", "#ffe66d", "#8ef6ff", "#8affc1", "#c6a9ff"]
    for row in range(rows):
        for col in range(cols):
            x = BRICK_MARGIN + col * (brick_w + BRICK_MARGIN)
            y = BRICK_TOP + row * (BRICK_HEIGHT + BRICK_MARGIN)
            hits = 1 + (row // 2)
            color = palette[row % len(palette)]
            bricks.append(Brick(canvas, x, y, brick_w, BRICK_HEIGHT, hits=hits, color=color))
    return bricks

class Game:
    def __init__(self, root):
        self.root = root
        self.root.title("Breakout — repeat & exit")
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="#001a33", highlightthickness=0)
        self.canvas.pack()
        root.bind_all("<Key>", self.on_key)

        self.paddle = Paddle(self.canvas)
        self.bricks = build_bricks(self.canvas)
        self.ball = Ball(self.canvas, self.paddle)
        self.score = 0
        self.lives = LIVES
        self.level = 1
        self.paused = False
        self.running = True

        # UI text (keep these IDs so we can preserve them across restarts)
        self.score_text = self.canvas.create_text(12, 12, anchor="nw", fill="white", font=("Helvetica", 18),
                                                  text=f"Score: {self.score}")
        self.lives_text = self.canvas.create_text(WIDTH - 12, 12, anchor="ne", fill="white", font=("Helvetica", 18),
                                                  text=f"Lives: {self.lives}")
        self.level_text = self.canvas.create_text(WIDTH / 2, 12, anchor="n", fill="white", font=("Helvetica", 18),
                                                  text=f"Level: {self.level}")
        self.hint_text = self.canvas.create_text(WIDTH / 2, HEIGHT - 18, anchor="s", fill="white",
                                                 font=("Helvetica", 12),
                                                 text="Move mouse to control paddle  Click to launch  R to restart")

        # mouse bindings
        self.canvas.bind("<Motion>", self.on_mouse_move)
        self.canvas.bind("<Button-1>", self.on_mouse_click)

        self.last_time = time.time()
        self.loop()

    def on_mouse_move(self, event):
        try:
            self.paddle.set_center_x(event.x)
        except Exception:
            pass

    def on_mouse_click(self, event):
        try:
            self.canvas.focus_set()
        except Exception:
            pass
        self.paused = False
        if getattr(self, "ball", None) is not None:
            try:
                self.ball.launch()
            except Exception:
                pass

    def on_key(self, event):
        if event.keysym in ("r", "R"):
            self.restart()
        elif event.keysym == "Escape":
            self.running = False
            try:
                self.root.destroy()
            except Exception:
                pass

    def restart(self):
        # remove overlay items if present
        try:
            self.canvas.delete("overlay")
            self.canvas.delete("overlay_btn")
        except Exception:
            pass

        self.paused = False
        try:
            if getattr(self, "ball", None) is not None:
                self.ball.stuck = True
        except Exception:
            pass

        # clear non-UI items
        keep = {self.score_text, self.lives_text, self.level_text, self.hint_text}
        for item in list(self.canvas.find_all()):
            if item not in keep:
                try:
                    self.canvas.delete(item)
                except Exception:
                    pass

        # recreate core objects
        self.paddle = Paddle(self.canvas)
        self.bricks = build_bricks(self.canvas)
        self.ball = Ball(self.canvas, self.paddle)

        # reset counters
        self.score = 0
        self.lives = LIVES
        self.level = 1
        self.update_ui()

        # ensure focus
        try:
            self.root.focus_force()
            self.canvas.focus_set()
        except Exception:
            pass

    def update_ui(self):
        try:
            self.canvas.itemconfigure(self.score_text, text=f"Score: {self.score}")
            self.canvas.itemconfigure(self.lives_text, text=f"Lives: {self.lives}")
            self.canvas.itemconfigure(self.level_text, text=f"Level: {self.level}")
        except Exception:
            pass

    def loop(self):
        if not self.running:
            return

        now = time.time()
        elapsed = now - self.last_time
        if elapsed > 0.05:
            elapsed = 0.05
        self.last_time = now

        if not self.paused:
            if getattr(self, "ball", None) is not None:
                try:
                    destroyed = self.ball.update(self.bricks)
                except Exception:
                    destroyed = []
            else:
                destroyed = []

            for b in destroyed:
                try:
                    if not b.alive:
                        self.score += 100
                    else:
                        self.score += 50
                except Exception:
                    pass

            self.bricks = [b for b in self.bricks if b.alive]

            if not self.bricks:
                self.level += 1
                self.update_ui()
                new_rows = min(BRICK_ROWS + (self.level - 1) // 2, 9)
                # clear everything except UI text before building new level
                keep = {self.score_text, self.lives_text, self.level_text, self.hint_text}
                for item in list(self.canvas.find_all()):
                    if item not in keep:
                        try:
                            self.canvas.delete(item)
                        except Exception:
                            pass
                self.paddle = Paddle(self.canvas)
                self.bricks = build_bricks(self.canvas, rows=new_rows, cols=BRICK_COLS)
                self.ball = Ball(self.canvas, self.paddle)
                self.paused = True
                try:
                    self.canvas.focus_set()
                except Exception:
                    pass

            # guard ball attributes (ball may be None during rapid resets)
            if getattr(self, "ball", None) is not None and getattr(self.ball, "y", None) is not None and getattr(self.ball, "r", None) is not None:
                try:
                    if self.ball.y - self.ball.r > HEIGHT:
                        self.lives -= 1
                        if self.lives <= 0:
                            self.game_over()
                        else:
                            try:
                                self.ball.reset(stuck=True)
                            except Exception:
                                pass
                        self.update_ui()
                except Exception:
                    pass

            self.update_ui()

        self.root.after(int(1000 / FPS), self.loop)

    def game_over(self):
        self.paused = True
        # remove non-UI items
        keep = {self.score_text, self.lives_text, self.level_text, self.hint_text}
        for item in list(self.canvas.find_all()):
            if item not in keep:
                try:
                    self.canvas.delete(item)
                except Exception:
                    pass

        # overlay background and texts tagged "overlay"
        self.canvas.create_rectangle(WIDTH/2 - 220, HEIGHT/2 - 100, WIDTH/2 + 220, HEIGHT/2 + 100,
                                     fill="#000000cc", outline="", tags=("overlay",))
        self.canvas.create_text(WIDTH/2, HEIGHT/2 - 40, text="GAME OVER", fill="white", font=("Helvetica", 32), tags=("overlay",))
        self.canvas.create_text(WIDTH/2, HEIGHT/2 - 4, text=f"Score: {self.score}", fill="white", font=("Helvetica", 20), tags=("overlay",))
        self.canvas.create_text(WIDTH/2, HEIGHT/2 + 24, text="Would you like to play again?", fill="white", font=("Helvetica", 14), tags=("overlay",))

        # buttons: rectangles + text, tagged "overlay_btn"
        bw = 160
        bh = 36
        left_x = WIDTH/2 - bw - 10
        right_x = WIDTH/2 + 10
        top = HEIGHT/2 + 44

        self.canvas.create_rectangle(left_x, top, left_x + bw, top + bh, fill="#2d8cf0", outline="", tags=("overlay_btn", "btn_play"))
        self.canvas.create_text(left_x + bw/2, top + bh/2, text="Play Again", fill="white", font=("Helvetica", 14), tags=("overlay_btn", "btn_play_text"))

        self.canvas.create_rectangle(right_x, top, right_x + bw, top + bh, fill="#d9534f", outline="", tags=("overlay_btn", "btn_quit"))
        self.canvas.create_text(right_x + bw/2, top + bh/2, text="Quit", fill="white", font=("Helvetica", 14), tags=("overlay_btn", "btn_quit_text"))

        # bind clicks on the button tags
        try:
            self.canvas.tag_bind("btn_play", "<Button-1>", lambda e: self._on_play_again())
            self.canvas.tag_bind("btn_play_text", "<Button-1>", lambda e: self._on_play_again())
            self.canvas.tag_bind("btn_quit", "<Button-1>", lambda e: self._on_quit())
            self.canvas.tag_bind("btn_quit_text", "<Button-1>", lambda e: self._on_quit())
        except Exception:
            pass

        # ensure focus so key events still work
        try:
            self.root.focus_force()
            self.canvas.focus_set()
        except Exception:
            pass

    def _on_play_again(self):
        try:
            self.canvas.delete("overlay")
            self.canvas.delete("overlay_btn")
        except Exception:
            pass
        self.restart()

    def _on_quit(self):
        try:
            self.root.destroy()
        except Exception:
            self.running = False

def main():
    root = tk.Tk()
    root.resizable(False, False)
    game = Game(root)
    root.mainloop()

if __name__ == "__main__":
    main()
