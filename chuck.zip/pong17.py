import turtle

def play_game(win):
    # Clear and reset screen
    win.clear()
    win.bgcolor("black")
    win.title("Pong: Score on Paddle Contact")
    win.setup(width=800, height=600)
    win.tracer(0)

    # Ask user for starting speed
    speed_input = win.textinput("Starting Speed", "Enter ball speed (e.g. 0.2, 1.0):")
    try:
        start_speed = float(speed_input)
    except (TypeError, ValueError):
        start_speed = 1.0  # Default if input is invalid

    # Paddle A
    paddle_a = turtle.Turtle()
    paddle_a.speed(0)
    paddle_a.shape("square")
    paddle_a.color("white")
    paddle_a.shapesize(stretch_wid=5, stretch_len=1)
    paddle_a.penup()
    paddle_a.goto(-350, 0)

    # Paddle B
    paddle_b = turtle.Turtle()
    paddle_b.speed(0)
    paddle_b.shape("square")
    paddle_b.color("white")
    paddle_b.shapesize(stretch_wid=5, stretch_len=1)
    paddle_b.penup()
    paddle_b.goto(350, 0)

    # Ball
    ball = turtle.Turtle()
    ball.speed(0)
    ball.shape("square")
    ball.color("white")
    ball.penup()
    ball.goto(0, 0)
    ball.dx = start_speed
    ball.dy = start_speed

    # Scores
    score_a = 0
    score_b = 0

    score_display = turtle.Turtle()
    score_display.speed(0)
    score_display.color("white")
    score_display.penup()
    score_display.hideturtle()
    score_display.goto(0, 260)
    score_display.write("Player A: 0  Player B: 0", align="center", font=("Courier", 20, "normal"))

    def update_score():
        score_display.clear()
        score_display.write(f"Player A: {score_a}  Player B: {score_b}",
                            align="center", font=("Courier", 20, "normal"))

    # Paddle movement
    def paddle_a_up():
        y = paddle_a.ycor()
        if y < 250:
            paddle_a.sety(y + 20)

    def paddle_a_down():
        y = paddle_a.ycor()
        if y > -240:
            paddle_a.sety(y - 20)

    def paddle_b_up():
        y = paddle_b.ycor()
        if y < 250:
            paddle_b.sety(y + 20)

    def paddle_b_down():
        y = paddle_b.ycor()
        if y > -240:
            paddle_b.sety(y - 20)

    # Keyboard bindings
    win.listen()
    win.onkeypress(paddle_a_up, "w")
    win.onkeypress(paddle_a_down, "s")
    win.onkeypress(paddle_b_up, "Up")
    win.onkeypress(paddle_b_down, "Down")

    # Main game loop
    game_running = True
    while game_running:
        win.update()

        # Move the ball
        ball.setx(ball.xcor() + ball.dx)
        ball.sety(ball.ycor() + ball.dy)

        # Border collision
        if ball.ycor() > 290 or ball.ycor() < -290:
            ball.sety(ball.ycor())
            ball.dy *= -1

        # Wall reset (no scoring)
        if ball.xcor() > 390 or ball.xcor() < -390:
            ball.goto(0, 0)
            ball.dx *= -1

        # Paddle B collision
        if (340 < ball.xcor() < 350) and (paddle_b.ycor() - 50 < ball.ycor() < paddle_b.ycor() + 50):
            ball.setx(340)
            ball.dx *= -1.05  # Reverse and speed up
            ball.dy *= 1.05
            score_b += 1
            update_score()
            if score_b == 10:
                score_display.clear()
                score_display.write("Player B Wins!", align="center", font=("Courier", 24, "bold"))
                game_running = False

        # Paddle A collision
        if (-350 < ball.xcor() < -340) and (paddle_a.ycor() - 50 < ball.ycor() < paddle_a.ycor() + 50):
            ball.setx(-340)
            ball.dx *= -1.05  # Reverse and speed up
            ball.dy *= 1.05
            score_a += 1
            update_score()
            if score_a == 10:
                score_display.clear()
                score_display.write("Player A Wins!", align="center", font=("Courier", 24, "bold"))
                game_running = False

    # Ask to play again
    response = win.textinput("Play Again?", "Type 'yes' to play again or anything else to quit:")
    return response and response.lower() == "yes"

# Create screen once
win = turtle.Screen()

# Repeat loop
while play_game(win):
    pass

win.bye()
