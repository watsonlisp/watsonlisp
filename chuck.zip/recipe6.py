#!/usr/bin/env python3
"""
recipe_generator_repeat.py
Same generator logic as before, but runs in a loop and exits on user command.
"""
import random
import textwrap

# --- Data pools (same as before) ---
BASES = {
    "rice": {"type": "grain", "unit": "cup", "amount": 1},
    "beans": {"type": "legume", "unit": "cup", "amount": 1},
    "pasta": {"type": "grain", "unit": "oz", "amount": 80},
    "meat": {"type": "meat", "unit": "oz", "amount": 8},
    "tofu": {"type": "soy", "unit": "oz", "amount": 8},
    "vegetables": {"type": "veg", "unit": "cup", "amount": 2},
}

CUISINES = {
    "Mexican": {"spices": ["cumin", "smoked paprika", "chili powder"], "sauce": ["tomato-chipotle salsa", "lime crema"], "garnish": ["cilantro", "lime wedges"]},
    "Italian": {"spices": ["oregano", "crushed red pepper", "black pepper"], "sauce": ["tomato-basil sauce", "lemon-parmesan drizzle"], "garnish": ["basil", "parmesan"]},
    "Asian": {"spices": ["ginger", "garlic", "five-spice"], "sauce": ["soy-sesame glaze", "spicy peanut sauce"], "garnish": ["scallions", "sesame seeds"]},
    "Mediterranean": {"spices": ["sumac", "oregano", "garlic"], "sauce": ["yogurt-tahini sauce", "lemon-olive oil vinaigrette"], "garnish": ["parsley", "lemon"]},
    "Comfort": {"spices": ["thyme", "black pepper", "smoked salt"], "sauce": ["creamy mushroom sauce", "buttery pan sauce"], "garnish": ["chives", "butter"]}
}

PROTEIN_SWAPS = {
    "meat": ["chicken", "pork", "steak"],
    "soy": ["tofu", "tempeh"],
    "legume": ["black beans", "chickpeas", "lentils"],
    "veg": ["mushrooms", "cauliflower", "eggplant"],
    "grain": ["quinoa", "farro"]
}

VEG_ADDONS = ["bell pepper", "onion", "spinach", "zucchini", "tomato", "carrot"]
SAUCES = ["simple pan sauce", "roasted garlic puree", "fresh herb chimichurri", "light vinaigrette"]
OILS = ["olive oil", "canola oil", "sesame oil", "butter"]

# --- Helpers (unchanged) ---
def scale(amount, servings, base_servings=2):
    return round(amount * servings / base_servings, 2)

def pick_cuisine(seed, allowed=None):
    random.seed(seed)
    return random.choice(list(CUISINES.keys())) if allowed is None else random.choice([c for c in CUISINES.keys() if c in allowed])

def choose_base(preferred, seed):
    random.seed(seed + 1)
    if preferred and preferred in BASES:
        return preferred
    return random.choice(list(BASES.keys()))

def filter_by_diet(base_key, dietary_flags):
    if dietary_flags.get("vegan"):
        if BASES[base_key]["type"] == "meat":
            return "tofu"
    if dietary_flags.get("vegetarian"):
        if BASES[base_key]["type"] == "meat":
            return "tofu"
    return base_key

def build_ingredients(base_key, cuisine, servings, dietary_flags, seed):
    random.seed(seed + 2)
    base = BASES[base_key]
    qty = scale(base["amount"], servings)
    ingredients = [f"{qty} {base['unit']} {base_key}"]
    if base["type"] in PROTEIN_SWAPS:
        choice = random.choice(PROTEIN_SWAPS[base["type"]])
        if choice != base_key:
            ingredients.append(f"Optional: 6 oz {choice} (replace or add)")
    vegs = random.sample(VEG_ADDONS, k=2)
    for v in vegs:
        ingredients.append(f"1 cup {v}")
    ingredients.append("2 cloves garlic, minced")
    ingredients.append(f"1 tbsp {random.choice(OILS)}")
    spices = CUISINES[cuisine]["spices"]
    chosen_spices = random.sample(spices, k=2)
    for s in chosen_spices:
        ingredients.append(f"1 tsp {s}")
    sauce_choice = random.choice(CUISINES[cuisine]["sauce"] + SAUCES)
    if dietary_flags.get("dairy_free") and "crema" in sauce_choice:
        sauce_choice = sauce_choice.replace("crema", "lime drizzle")
    ingredients.append(f"Sauce: {sauce_choice}")
    ingredients.append("Salt to taste")
    ingredients.append("Black pepper to taste")
    return ingredients

def build_steps(base_key, cuisine, servings, dietary_flags, seed):
    random.seed(seed + 3)
    steps = []
    steps.append("Prep all ingredients: rinse rice or beans; chop vegetables; mince garlic.")
    base = BASES[base_key]
    if base_key == "rice":
        steps.append("Cook rice: simmer 1 cup rice with 2 cups water until tender, fluff with fork.")
    elif base_key == "beans":
        steps.append("If using canned beans: drain and rinse. If dried: soak and simmer until tender.")
    elif base_key == "pasta":
        steps.append("Cook pasta in salted boiling water until al dente; reserve a cup of pasta water.")
    elif base_key in ("steak", "tofu"):
        steps.append(f"Season {base_key} with salt and pepper and sear in a hot pan 3-5 minutes per side.")
    else:
        steps.append(f"Roast or sauté the {base_key} until caramelized and tender.")
    steps.append("In a large pan, heat oil and sauté aromatics until fragrant; add vegetables and cook until softened.")
    if base["type"] == "meat" and base_key != "steak":
        steps.append("Add protein and brown on all sides.")
    steps.append("Add chosen sauce and spices; simmer briefly so flavors meld. Adjust salt and acidity.")
    steps.append("Assemble: place base in bowl or plate, top with vegetables and protein, spoon sauce over.")
    garnish = random.choice(CUISINES[cuisine]["garnish"])
    steps.append(f"Garnish with {garnish} and serve hot.")
    return steps

def format_recipe(title, base_key, cuisine, servings, ingredients, steps):
    lines = []
    lines.append(f"{title}\n")
    lines.append(f"Base Ingredient: {base_key}")
    lines.append(f"Cuisine Direction: {cuisine}")
    lines.append(f"Servings: {servings}\n")
    lines.append("Ingredients:")
    for it in ingredients:
        lines.append(f"- {it}")
    lines.append("\nSteps:")
    for i, s in enumerate(steps, start=1):
        wrapped = textwrap.fill(s, width=72)
        lines.append(f"{i}. {wrapped}")
    return "\n".join(lines)

# --- Generator function ---
def generate_recipe(preferred_base=None, servings=2, cuisine=None, vegan=False, vegetarian=False, dairy_free=False, seed=None):
    seed = seed if seed is not None else random.randrange(10**6)
    dietary_flags = {"vegan": vegan, "vegetarian": vegetarian, "dairy_free": dairy_free}
    base_choice = choose_base(preferred_base, seed)
    base_choice = filter_by_diet(base_choice, dietary_flags)
    cuisine_choice = cuisine if cuisine in CUISINES else pick_cuisine(seed)
    ingredients = build_ingredients(base_choice, cuisine_choice, servings, dietary_flags, seed)
    steps = build_steps(base_choice, cuisine_choice, servings, dietary_flags, seed)
    title = f"Random Recipe Generator Pick (seed {seed})"
    recipe_text = format_recipe(title, base_choice, cuisine_choice, servings, ingredients, steps)
    return {"seed": seed, "text": recipe_text}

# --- Interactive repeat loop CLI ---
def interactive_loop():
    print("Recipe Generator. Type 'q', 'quit', or 'exit' to leave.")
    
    # default options you can change before each run
    preferred_base = None
    servings = 2
    cuisine = None
    vegan = vegetarian = dairy_free = False

    while True:
#        print("use these codes:")
        print("use these codes:{cuisine=Mexican cuisine=Italian cuisine=Asian cuisine=Mediterranean cuisine=Comfort cuisine=Vegan}")
        print("                {base=rice base=beans base=pasta base=meat base=vegetables base=tofu} ")
        cmd = input("\nPress Enter to generate, or type options (e.g. base=rice servings=3 cuisine=Asian vegan=yes) ), or 'q' to quit:\n> ").strip()
        if cmd.lower() in ("q", "quit", "exit"):
            print("Bye.")
            break
        # parse simple key=value options in the single line if provided
        if cmd:
            for token in cmd.split():
                if "=" in token:
                    k, v = token.split("=", 1)
                    k = k.lower()
                    if k == "base":
                        preferred_base = v if v in BASES else preferred_base
                    elif k == "servings":
                        try:
                            servings = max(1, int(v))
                        except ValueError:
                            pass
                    elif k == "cuisine":
                        cuisine = v if v in CUISINES else cuisine
                    elif k == "vegan":
                        vegan = v.lower() in ("1", "true", "yes", "y")
                    elif k == "vegetarian":
                        vegetarian = v.lower() in ("1", "true", "yes", "y")
                    elif k in ("dairyfree", "dairy-free", "dairy_free"):
                        dairy_free = v.lower() in ("1", "true", "yes", "y")
        # generate and print
        r = generate_recipe(preferred_base=preferred_base, servings=servings, cuisine=cuisine, vegan=vegan, vegetarian=vegetarian, dairy_free=dairy_free)
        print("\n" + r["text"] + "\n")
        # after printing, loop repeats until user quits

if __name__ == "__main__":
    interactive_loop()
