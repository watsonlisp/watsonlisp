import random

ADJECTIVES = ["Velvet", "Crimson", "Silver", "Misty", "Amber", "Electric", "Lunar", "Sage", "Gilded", "Frost"]
NOUNS = ["Fog", "Garden", "Trail", "Bloom", "Peak", "Valley", "Dawn", "Haze", "Sun", "Stone"]
MODIFIERS = ["Kush", "OG", "Haze", "Diesel", "Skunk", "Berry", "Dream", "Cookies"]
SUFFIXES = ["Express", "Reserve", "Select", "Craft", "Blend", "Secret", "Edition"]

PATTERNS = [
    "{adj} {noun}",
    "{adj} {noun} {mod}",
    "{adj} {mod} {noun}",
    "{noun} of {adj} {mod}",
    "{adj} {noun}-{suf}",
    "{adj} {mod}",
    "{noun} {mod} {suf}"
]

def generate_name():
    pattern = random.choice(PATTERNS)
    name = pattern.format(
        adj=random.choice(ADJECTIVES),
        noun=random.choice(NOUNS),
        mod=random.choice(MODIFIERS),
        suf=random.choice(SUFFIXES)
    )
    return " ".join(name.split())

def interactive_loop():
    print("Pot Plant Name Generator — press Enter to generate, or type q then Enter to quit.")
    while True:
        cmd = input("> ").strip().lower()
        if cmd in ("q", "quit", "exit"):
            print("Goodbye.")
            break
        print(generate_name())

if __name__ == "__main__":
    interactive_loop()
