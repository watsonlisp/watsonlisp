#!/usr/bin/env python3
"""
Random Insult Generator with 100 base insults, 100 templates, 100 adjectives, 100 verbs.
Interactive loop: press Enter for another insult, or type 'q' then Enter to quit.
CLI flags:
  --no-profanity   disable profane entries in base nouns and some templates
  --safe           milder mode (removes the most abrasive nouns)
  --delay SECS     optional delay after each insult
"""

import random
import argparse
import sys
import time

# 100 base insults (noun phrases). Avoids slurs and protected-class targeting.
BASE_NOUNS = [
    "bewildered pigeon", "confused toaster", "soggy crouton", "expired coupon",
    "lukewarm cup of ambition", "slow-burning riddle", "misplaced comma",
    "polite catastrophe", "empty suggestion box", "flat battery of charm",
    "malfunctioning thought experiment", "walking typo", "budget mystery",
    "half-baked prophecy", "second-hand legend", "paper umbrella in a downpour",
    "vinyl record of bad ideas", "canned apology", "dim firework",
    "off-brand oracle", "faded road sign", "rusty kazoo", "silent foghorn",
    "bent paperclip of destiny", "damp spark of genius", "derailed monologue",
    "stalled weather report", "wobbly sock puppet", "forgotten footnote",
    "paperweight of regret", "vanilla-scented panic", "cloudy crystal ball",
    "buttonless remote", "pocket lint of hope", "mismatched shoelace",
    "postponed epiphany", "slow-turning hourglass", "misfiled map", "stale joke",
    "faintly ridiculous idea", "mismatched casserole", "pocket-sized scandal",
    "awkwardly cheerful hiccup", "half-assembled plan", "circular argument",
    "manual for doing nothing", "outdated lifehack", "preposterous footnote",
    "dented trophy", "frozen sigh", "backordered enthusiasm",
    "cumbersome whisper", "paper boat in a storm", "glossy brochure of failure",
    "petty house of nonsense", "noisy bag of questions", "stubborn glitch",
    "sloppy monument to poor taste", "rotten postcard from sense",
    "pouting blip of chaos", "glorified dumpster fire", "sanctimonious sack of nonsense",
    "shameless little mess", "petty tangle of intentions", "obstinate half-truth",
    "awkward syllable", "waning echo", "sleepy neon sign", "faltering drumroll",
    "melancholy confetti", "tired paper crown", "paper-mâché backbone",
    "cupboard of missed cues", "dimming marquee", "blunt pencil of destiny",
    "crumbled scroll", "moth-eaten roadmap", "half-charged battery of ambition",
    "loopy instruction manual", "unsubscribed newsletter of woes",
    "broken sundial", "underbaked scheme", "wishful paper kite", "rusty semaphore",
    "pigeonhole of regrets", "tepid brainstorm", "benchwarmer's manifesto",
    "afternoon breeze with opinions", "misprinted prophecy", "cackling static",
    "shadow of an idea", "voicemail from bad timing", "toothless cautionary tale",
    "wilted souvenir", "deflated balloon of confidence", "distracted echo",
    "fumbled statuette", "questionable keepsake", "flawed prototype of charm",
    "blemished blueprint", "half-remembered rumor", "decorative hiccup",
    "paper tiger with a crinkle", "credit-card apology", "dusty applause",
    "blank index card of wisdom"
]

# 100 templates (each must have {phrase} or {phrase_alt} placeholders)
TEMPLATES = [
    "You're {phrase}.", "Honestly, you're {phrase}.", "Calling you {phrase} is an insult to {phrase_alt}.",
    "Somebody sign you up for a refund: you're {phrase}.", "If nonsense had a mascot, it'd be {phrase}.",
    "You carry the aura of {phrase}.", "In the gallery of oddities, you're {phrase}.",
    "For a moment I thought {phrase_alt} had learned to walk, then I met you: {phrase}.",
    "People whisper {phrase} when they mean you.", "You're a low-budget {phrase}.",
    "Is it performance art or just {phrase}?", "You bring a portable {phrase} to everything.",
    "When life gives lemons, you return {phrase}.", "You are the reason {phrase_alt} feels seen: {phrase}.",
    "If confusion were currency, you'd be {phrase}.", "You're what happens when {phrase_alt} forgets to try.",
    "They'll name a small island {phrase} one day.", "You're the aftermath of {phrase}.",
    "Your legacy will be called {phrase}.", "If subtlety had a parking ticket, it would read {phrase}.",
    "You smell faintly of {phrase}.", "Your user manual is titled: {phrase}.", "You're a one-person {phrase}.",
    "I'd call you {phrase}, but that'd be an improvement for {phrase_alt}.", "You're a scenic route to {phrase}.",
    "You specialize in delivering {phrase}.", "There is an unsettling expertise of {phrase} about you.",
    "If mediocrity had a mascot, it would wear your face and be called {phrase}.", "You were clearly modeled after {phrase_alt}.",
    "I asked for quality, you sent {phrase}.", "You're the blooper reel of {phrase}.",
    "Someone mailed {phrase} to common sense and it got lost.", "You fit neatly into the space labeled {phrase}.",
    "Your vibe pairs well with {phrase}.", "You're a discontinued {phrase}.", "You're the footnote of {phrase}.",
    "I'd compare you to {phrase_alt}, but that would be an upgrade: {phrase}.", "You're peak {phrase}.",
    "You make {phrase_alt} look competent.", "If awkwardness had a fragrance, it would be {phrase}.",
    "You're a limited edition of {phrase}.", "You resemble {phrase_alt} when it's on its worst day: {phrase}.",
    "Someone bookmarked {phrase} and then closed the browser.", "You're an expired coupon of {phrase}.",
    "I wouldn't wish {phrase} on my worst enemy, but I'd consider it for you.", "You're a walking memo labeled {phrase}.",
    "The room gets quieter when you announce your {phrase}.", "You are a small, persistent {phrase}.",
    "You are a conspicuous {phrase} in a sea of good taste.", "If humility were optional, you'd pick {phrase}.",
    "You're a headline that reads: {phrase}.", "You have the subtlety of {phrase_alt} and the grace of {phrase}.",
    "Someone taught {phrase} to be loud and it graduated with honors.", "You're a living example of {phrase}.",
    "Your contribution is best described as {phrase}.", "I caught {phrase} taking notes on you.",
    "The dictionary entry for 'awkward' now shows a picture labeled {phrase}.", "You upgraded {phrase_alt} into {phrase}.",
    "You bring to mind an old {phrase}.", "You're what happens when {phrase_alt} runs out of patience: {phrase}.",
    "I would call you {phrase}, but that would insult {phrase_alt}.", "You are a slow-motion {phrase}.",
    "You remind me of a slightly haunted {phrase}.", "You have the charm of {phrase_alt} and the execution of {phrase}.",
    "My phone autocorrected you to {phrase} and it was accurate.", "You smell faintly of burnt {phrase}.",
    "You're the kind of person who orders {phrase} and expects fireworks.", "You're a tasteful monument to {phrase}.",
    "If disaster had a business card, it would read {phrase}.", "You are the echo of {phrase_alt} in a poorly insulated room.",
    "You put the 'almost' in {phrase}.", "You're the draft labeled {phrase} that nobody saved.",
    "Your brand is basically {phrase}.", "The committee unanimously agreed to name you {phrase}.",
    "You're a footnote to yesterday's {phrase}.", "You are what happens after {phrase_alt} takes a nap: {phrase}.",
    "You're the low-res version of {phrase_alt}.", "You have the commitment of a half-hearted {phrase}.",
    "You're an honorary member of the {phrase} club.", "If inconsistency were measured, you'd read {phrase}.",
    "You are a certified {phrase}.", "Please keep your {phrase} away from fragile ideas.",
    "You're a tasteful whisper of {phrase}.", "You're a prototype for {phrase_alt} gone strange.",
    "The Internet has a reserved tab for {phrase}.", "You're an undercooked {phrase}.",
    "If bad timing were a sport, you'd win with {phrase}.", "You're an artisanal batch of {phrase}.",
    "You could be marketed as {phrase}.", "Your arrival is best announced by {phrase}.",
    "You look like someone who keeps a {phrase} handy.", "People clap politely for {phrase} and then leave."
]

# 100 adjectives (single-word or short multi-word descriptors)
ADJECTIVES = [
    "mirthless", "dusty", "half-asleep", "overcaffeinated", "underprepared",
    "wobbly", "faintly ridiculous", "mismatched", "pocket-sized", "awkwardly cheerful",
    "bemused", "crinkled", "self-important", "tentative", "stuttering",
    "wan", "paper-thin", "timid", "bemusedly confident", "slightly rancid",
    "half-baked", "toothless", "flimsy", "frayed", "rust-speckled",
    "tepid", "wiry", "distracted", "aimless", "blunt",
    "patchy", "half-hearted", "cockeyed", "singed", "lopsided",
    "patchworked", "faintly damp", "stale", "wilted", "puffy",
    "drowsy", "frivolous", "clumsy", "uneven", "tattered",
    "sketchy", "mealy-mouthed", "buskined", "crumbled", "gaudy",
    "murmuring", "goofy", "cracked", "cumbersome", "obstinate",
    "gossamer", "soggy", "moodless", "faltering", "blemished",
    "mousy", "waning", "sidelong", "slippery", "underseasoned",
    "blurry", "murmured", "soft-edged", "practically harmless", "mellowed",
    "drifty", "thin-skinned", "gently absurd", "half-tuned", "dappled",
    "frankly awkward", "mumbling", "moth-eaten", "pedestrian", "languid",
    "poky", "pale", "listless", "spindly", "sleepy",
    "fussy", "pliant", "tremulous", "faltering", "unctuous",
    "wiry-brained", "hollow-sounding", "blunted", "pettish", "tame",
    "mild-mannered", "mangy", "mirth-impaired", "near-miss", "paper-backed"
]

# 100 verbs/verb-phrases (used as connective pieces)
VERBS = [
    "hobbling through", "trying to out-stare", "offending", "misplacing", "redesigning",
    "consulting on", "tripping over", "smuggling", "laundering", "mimicking",
    "whispering about", "fiddling with", "stirring", "navigating", "procrastinating on",
    "stalling in", "handing out", "mislabeling", "botching", "sanding down",
    "polishing", "fidgeting with", "rewriting", "misreading", "diluting",
    "overpromising", "under-delivering", "flirting with", "humming at", "muting",
    "dangling", "misplacing", "misfiled among", "smoothing over", "backing away from",
    "coddling", "tinkering with", "outing", "misplacing", "overcomplicating",
    "dodging", "sidelining", "stumbling into", "glossing over", "murmuring about",
    "stashing under", "fusing", "shuffling", "mixing into", "penciling in",
    "practicing", "ruminating on", "echoing", "streaking through", "sabotaging",
    "pilfering from", "poking at", "gently insulting", "scribbling on", "squinting at",
    "squeaking through", "drifting toward", "sampling", "tracing around", "filing under",
    "preparing a case for", "editing out", "saluting", "hijacking", "whittling",
    "muffling", "deliberating over", "borrowing", "disowning", "sliding into",
    "faintly celebrating", "muttering about", "doddering through", "blowing on",
    "pattering across", "cadging", "mangling", "mismanaging", "spinning into",
    "staining", "puffing", "glowering at", "sucking the air from", "dangling near",
    "cataloging", "nicknaming", "rearranging", "squandering", "disassembling",
    "garnishing", "underestimating", "miscasting", "overstating", "underwiring",
    "scripting", "cartwheeling around", "tiptoeing past", "papering over", "chalk-marking"
]

# Profanity-safe filters: which base nouns and templates contain heavier profanity.
# We'll mark any base noun or template containing explicit profanity terms for removal if needed.
PROFANE_KEYWORDS = {"shit", "fuck", "dumpster", "fuckery", "dumbass", "ass", "shameless", "glorified"}

# Helper builders

def contains_profane(text: str) -> bool:
    low = text.lower()
    return any(k in low for k in PROFANE_KEYWORDS)

def filter_by_profanity(items, allow_profanity: bool):
    if allow_profanity:
        return items[:]
    return [x for x in items if not contains_profane(x)]

def filter_by_safe_mode(items, safe_mode: bool):
    if not safe_mode:
        return items[:]
    # In safe mode, remove the more abrasive words (we'll re-use the same profane detection)
    return [x for x in items if not contains_profane(x)]

def build_phrase(adjectives, verbs, nouns):
    adj = random.choice(adjectives)
    verb = random.choice(verbs)
    noun = random.choice(nouns)
    # 25% chance to be short "adj noun", otherwise "adj verb noun"
    if random.random() < 0.25:
        return f"{adj} {noun}"
    return f"{adj} {verb} {noun}"

def build_insult_pool(base_templates, adjectives, verbs, nouns, target_count=100):
    """
    Build a pool of unique insults by filling templates.
    Attempts to produce target_count unique lines; falls back to generated phrases if needed.
    """
    pool = set()
    attempts = 0
    max_attempts = target_count * 200
    # Seed by filling each template a few times
    while len(pool) < target_count and attempts < max_attempts:
        attempts += 1
        tpl = random.choice(base_templates)
        phrase = build_phrase(adjectives, verbs, nouns)
        phrase_alt = build_phrase(adjectives, verbs, nouns)
        try:
            line = tpl.format(phrase=phrase, phrase_alt=phrase_alt)
        except Exception:
            # Template might be simple; fallback
            line = f"{phrase}."
        pool.add(line)
    # If still short, add raw generated phrases
    while len(pool) < target_count:
        pool.add(build_phrase(adjectives, verbs, nouns))
    return list(pool)

def interactive_loop(insult_pool, delay=0.0):
    prompt = "Press Enter for an insult, or type 'q' then Enter to quit: "
    try:
        while True:
            user = input(prompt).strip().lower()
            if user == "q":
                print("Exiting. Take care out there.")
                break
            print(random.choice(insult_pool))
            if delay > 0:
                time.sleep(delay)
    except KeyboardInterrupt:
        print("\nInterrupted. Goodbye.")
        sys.exit(0)

def main():
    parser = argparse.ArgumentParser(description="Random Insult Generator (100x4 pools)")
    parser.add_argument("--no-profanity", dest="profanity", action="store_false", help="Disable profanity")
    parser.add_argument("--safe", action="store_true", help="Enable safe mode (milder)")
    parser.add_argument("--delay", type=float, default=0.0, help="Optional delay after each insult (seconds)")
    args = parser.parse_args()

    # Apply filters
    nouns = filter_by_profanity(BASE_NOUNS, allow_profanity=args.profanity)
    nouns = filter_by_safe_mode(nouns, safe_mode=args.safe)

    templates = filter_by_profanity(TEMPLATES, allow_profanity=args.profanity)
    templates = filter_by_safe_mode(templates, safe_mode=args.safe)

    adjectives = filter_by_safe_mode(ADJECTIVES, safe_mode=args.safe)
    verbs = filter_by_safe_mode(VERBS, safe_mode=args.safe)

    # Build insult pool (target 100 unique insults)
    insult_pool = build_insult_pool(templates, adjectives, verbs, nouns, target_count=100)
    random.shuffle(insult_pool)
    print(f"Random Insult Generator (pool={len(insult_pool)}). Type 'q' to quit.")
    interactive_loop(insult_pool, delay=args.delay)

if __name__ == "__main__":
    main()
