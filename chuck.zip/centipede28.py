import tkinter as tk
import random

WIDTH = 800
HEIGHT = 600
CELL = 20
INITIAL_SPEED = 50
SPEED_MULTIPLIER = 0.8
INITIAL_LIVES = 6
INITIAL_MUSHROOMS = 80
MUSHROOMS_PER_WAVE = 20
MOTH_RESPAWN_MS = 3000  # milliseconds until moth regenerates after death

class CentipedeGame:
    def __init__(self, root):
        self.root = root
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="black")
        self.canvas.pack()
        self.root.title("Mini Centipede")

        self.root.bind("<Motion>", self.move_player)
        self.root.bind("<Button-1>", self.shoot)

        self.reset_game()
        self.game_loop()

    def reset_game(self):
        self.player_x = WIDTH // 2
        self.bullets = []
        self.centipede = [(i * CELL, 0) for i in range(10)]
        self.mushrooms = {(random.randint(0, WIDTH // CELL - 1) * CELL,
                           random.randint(2, HEIGHT // CELL - 5) * CELL)
                          for _ in range(INITIAL_MUSHROOMS)}
        self.score = 0
        self.wave = 1
        self.speed = INITIAL_SPEED
        self.lives = INITIAL_LIVES
        self.running = True

        # Initialize moth
        self.spawn_moth()
        self.moth_alive = True
        self.moth_respawn_timer = 0  # ms remaining until moth respawns when dead

    def spawn_moth(self):
        self.moth_x = random.randint(0, WIDTH)
        self.moth_y = random.randint(0, HEIGHT // 2)
        self.moth_dx = random.choice([-5, -3, 3, 5])
        self.moth_dy = random.choice([-5, -3, 3, 5])

    def move_player(self, event):
        self.player_x = event.x

    def shoot(self, event):
        self.bullets.append([self.player_x, HEIGHT - 40])

    def update_bullets(self):
        new_bullets = []
        for bx, by in self.bullets:
            by -= 10
            hit = False
            # Mushrooms
            for mx, my in list(self.mushrooms):
                if abs(bx - mx) < CELL and abs(by - my) < CELL:
                    self.mushrooms.remove((mx, my))
                    hit = True
            # Centipede segments
            for cx, cy in list(self.centipede):
                if abs(bx - cx) < CELL and abs(by - cy) < CELL:
                    try:
                        self.centipede.remove((cx, cy))
                    except ValueError:
                        pass
                    self.mushrooms.add((cx, cy))
                    self.score += 10
                    hit = True
            # Moth hit detection (moth can be killed)
            if self.moth_alive and abs(bx - self.moth_x) < CELL and abs(by - self.moth_y) < CELL:
                self.moth_alive = False
                self.moth_respawn_timer = MOTH_RESPAWN_MS
                self.score += 50
                hit = True
            if not hit and by > 0:
                new_bullets.append([bx, by])
        self.bullets = new_bullets

    def update_centipede(self):
        new_centipede = []
        reached_bottom = False
        for i, (x, y) in enumerate(self.centipede):
            dx = CELL if (y // (2 * CELL)) % 2 == 0 else -CELL
            nx = x + dx
            ny = y
            if nx < 0 or nx >= WIDTH or (nx, ny) in self.mushrooms:
                dx *= -1
                nx = x
                ny += CELL
            if ny >= HEIGHT - 40:
                reached_bottom = True
            new_centipede.append((nx, ny))
        self.centipede = new_centipede
        return reached_bottom

    def update_moth(self, delta_ms):
        # If dead, countdown to respawn
        if not self.moth_alive:
            if self.moth_respawn_timer > 0:
                self.moth_respawn_timer -= delta_ms
            if self.moth_respawn_timer <= 0:
                self.moth_alive = True
                self.spawn_moth()
            return

        # Alive: normal movement and behavior
        self.moth_x += self.moth_dx
        self.moth_y += self.moth_dy

        # Bounce off walls
        if self.moth_x < 0 or self.moth_x > WIDTH:
            self.moth_dx *= -1
        if self.moth_y < 0 or self.moth_y > HEIGHT:
            self.moth_dy *= -1

        # Randomly change direction
        if random.random() < 0.05:
            self.moth_dx = random.choice([-5, -3, 3, 5])
            self.moth_dy = random.choice([-5, -3, 3, 5])

        # Randomly eat mushrooms
        for mx, my in list(self.mushrooms):
            if abs(self.moth_x - mx) < CELL and abs(self.moth_y - my) < CELL:
                if random.random() < 0.3:
                    self.mushrooms.remove((mx, my))

    def draw(self):
        self.canvas.delete("all")

        # Draw mushrooms
        for mx, my in self.mushrooms:
            self.canvas.create_oval(mx, my, mx + CELL, my + CELL // 2, fill="brown", outline="")
            self.canvas.create_rectangle(mx + CELL // 3, my + CELL // 2, mx + 2 * CELL // 3, my + CELL, fill="tan", outline="")

        # Draw centipede segments with angled side legs
        for cx, cy in self.centipede:
            self.canvas.create_rectangle(cx, cy, cx + CELL, cy + CELL, fill="red", outline="")
            leg_length = CELL // 2
            leg_offset = CELL // 4
            leg_thickness = 2
            # Left legs angled downward
            self.canvas.create_line(cx, cy + leg_offset, cx - leg_length, cy + leg_offset + leg_length,
                                    fill="orange", width=leg_thickness)
            self.canvas.create_line(cx, cy + CELL - leg_offset, cx - leg_length, cy + CELL - leg_offset + leg_length,
                                    fill="orange", width=leg_thickness)
            # Right legs angled downward
            self.canvas.create_line(cx + CELL, cy + leg_offset, cx + CELL + leg_length, cy + leg_offset + leg_length,
                                    fill="orange", width=leg_thickness)
            self.canvas.create_line(cx + CELL, cy + CELL - leg_offset, cx + CELL + leg_length, cy + CELL - leg_offset + leg_length,
                                    fill="orange", width=leg_thickness)

        # Draw bullets
        for bx, by in self.bullets:
            self.canvas.create_rectangle(bx - 2, by, bx + 2, by + 10, fill="white")

        # Draw player gun
        self.canvas.create_rectangle(self.player_x - 3, HEIGHT - 30,
                                     self.player_x + 3, HEIGHT - 10, fill="gray", outline="")
        self.canvas.create_rectangle(self.player_x - 6, HEIGHT - 10,
                                     self.player_x + 6, HEIGHT, fill="silver", outline="")

        # Draw moth only if alive (or optionally show a faint indicator when dead)
        if self.moth_alive:
            wing_span = 14
            wing_height = 10
            body_width = 4
            body_height = 12

            # Left wing
            self.canvas.create_polygon(
                self.moth_x - body_width, self.moth_y,
                self.moth_x - wing_span, self.moth_y - wing_height,
                self.moth_x - wing_span, self.moth_y + wing_height,
                fill="violet", outline="white"
            )

            # Right wing
            self.canvas.create_polygon(
                self.moth_x + body_width, self.moth_y,
                self.moth_x + wing_span, self.moth_y - wing_height,
                self.moth_x + wing_span, self.moth_y + wing_height,
                fill="violet", outline="white"
            )

            # Segmented body
            for i in range(3):
                segment_top = self.moth_y - body_height // 2 + i * (body_height // 3)
                segment_bottom = segment_top + (body_height // 3)
                self.canvas.create_oval(
                    self.moth_x - body_width, segment_top,
                    self.moth_x + body_width, segment_bottom,
                    fill="purple", outline="white"
                )

            # Antennae
            self.canvas.create_line(self.moth_x, self.moth_y - body_height // 2,
                                    self.moth_x - 6, self.moth_y - body_height,
                                    fill="white")
            self.canvas.create_line(self.moth_x, self.moth_y - body_height // 2,
                                    self.moth_x + 6, self.moth_y - body_height,
                                    fill="white")
        else:
            # Optional: small indicator where the moth will respawn (fades as timer counts down)
            frac = max(0.0, min(1.0, 1 - (self.moth_respawn_timer / MOTH_RESPAWN_MS)))
            if frac > 0:
                alpha = int(255 * frac)
                # tkinter doesn't support alpha easily; use a dim marker by changing color intensity
                shade = 150 + int(105 * frac)
                color = f"#{shade:02x}{shade:02x}{shade:02x}"
                self.canvas.create_oval(self.moth_x - 6, self.moth_y - 6, self.moth_x + 6, self.moth_y + 6, fill=color, outline="")

        # HUD
        self.canvas.create_text(10, 10, anchor="nw", fill="white",
                                text=f"Score: {self.score}  Wave: {self.wave}  Lives: {self.lives}")

    def game_loop(self):
        if not self.running:
            return

        # delta for timers is the loop interval; use current speed as approximation
        delta_ms = max(1, self.speed)

        self.update_bullets()
        self.update_moth(delta_ms)
        reached_bottom = self.update_centipede()

        # Moth collision with player (if moth is alive)
        if self.moth_alive and abs(self.moth_x - self.player_x) < CELL and self.moth_y > HEIGHT - 40:
            self.lives -= 1
            self.moth_alive = False
            self.moth_respawn_timer = MOTH_RESPAWN_MS
            if self.lives <= 0:
                self.running = False
                self.canvas.create_text(WIDTH // 2, HEIGHT // 2, fill="white",
                                        text=f"GAME OVER! Final Score: {self.score}", font=("Arial", 16))
                self.canvas.create_text(WIDTH // 2, HEIGHT // 2 + 20, fill="white",
                                        text="Click to play again", font=("Arial", 12))
                self.root.bind("<Button-1>", self.restart)
                return

        if reached_bottom:
            self.lives -= 1
            self.centipede = [(i * CELL, 0) for i in range(10)]
            if self.lives <= 0:
                self.running = False
                self.canvas.create_text(WIDTH // 2, HEIGHT // 2, fill="white",
                                        text=f"GAME OVER! Final Score: {self.score}", font=("Arial", 16))
                self.canvas.create_text(WIDTH // 2, HEIGHT // 2 + 20, fill="white",
                                        text="Click to play again", font=("Arial", 12))
                self.root.bind("<Button-1>", self.restart)
                return

        if not self.centipede:
            self.wave += 1
            self.speed = int(self.speed * SPEED_MULTIPLIER)
            self.centipede = [(i * CELL, 0) for i in range(10)]
            self.mushrooms.update({(random.randint(0, WIDTH // CELL - 1) * CELL,
                                    random.randint(2, HEIGHT // CELL - 5) * CELL)
                                   for _ in range(MUSHROOMS_PER_WAVE)})
            # Respawn moth when new wave starts
            self.moth_alive = True
            self.spawn_moth()
            self.moth_respawn_timer = 0

        self.draw()
        self.root.after(self.speed, self.game_loop)

    def restart(self, event):
        self.root.unbind("<Button-1>")
        self.reset_game()
        self.root.bind("<Button-1>", self.shoot)
        self.game_loop()

# Run the game
root = tk.Tk()
game = CentipedeGame(root)
root.mainloop()
