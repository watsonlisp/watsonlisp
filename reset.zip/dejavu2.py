import os
import random
import shutil
import subprocess
import sys
import threading

DEJA_VU_SITUATIONS = [
    # Conversations
    "A friend begins telling a story, and you're certain you already know every word they're about to say.",
    "Someone asks you a question, and you feel that you've already given them the exact same answer.",
    "A person laughs at a joke, and their expression seems impossibly familiar.",
    "You finish someone's sentence because you feel as though you've heard it before.",
    "A coworker says your name, and the tone of their voice seems to come from an old memory.",
    "Two people begin arguing, and you feel that you've already watched the entire argument.",
    "Someone pauses in the middle of a sentence, and you somehow know what word comes next.",
    "A friend tells you some news, but you feel like they already told you yesterday.",
    "You hear someone mispronounce a word, and you remember the exact same mistake happening before.",
    "A stranger asks for directions, and the entire conversation feels like a replay.",
    "Someone waves goodbye, and you suddenly feel that you've witnessed the gesture before.",
    "A family member tells an old story, but the room itself also seems strangely familiar.",
    "You answer the phone and feel certain that you already know who is calling.",
    "Someone says, 'This is going to sound strange,' and you know exactly what they will say.",
    "A conversation changes direction, and you remember it changing in precisely the same way.",
    "Someone mentions a name you've never heard, but the name feels deeply familiar.",
    "A friend repeats themselves, but you're unsure whether they truly repeated anything.",
    "You hear a particular combination of voices and feel that the moment has happened before.",
    "Someone knocks on the door, and you feel that you already know what will happen when it opens.",
    "You suddenly know which person in the room is going to speak next.",

    # Home
    "You enter your kitchen and feel that you've walked into this exact moment before.",
    "You open the refrigerator and experience a sudden wave of familiarity.",
    "You sit on the couch, look toward the window, and feel that the entire scene is repeating.",
    "A lamp casts a shadow on the wall that makes the room feel like an old memory.",
    "You walk down your hallway and feel that you already know what waits around the corner.",
    "You hear the floor creak and remember hearing the exact same creak in the exact same moment.",
    "You reach for a cabinet before realizing that the action feels strangely rehearsed.",
    "You look at an ordinary object and feel certain that you've seen it in a dream.",
    "You wake up in the middle of the night and feel that you've awakened at that exact moment before.",
    "You stand at the sink washing a plate, and the scene suddenly feels like a replay.",
    "You turn on a light and feel that the brightness, shadows, and silence have happened before.",
    "You walk into an empty room and briefly expect someone to be standing there.",
    "You hear a television playing in another room and feel that you've already lived this evening.",
    "You notice sunlight falling across the floor in an oddly familiar pattern.",
    "You open a drawer and feel that you remember every object inside, including one you've never seen.",
    "You hang up your coat and feel that you've completed the exact movement before.",
    "You look through a doorway and experience a powerful sense of recognition.",
    "You smell dinner cooking and feel transported into a memory that you cannot identify.",
    "Your pet looks at you in a certain way, and the moment feels like a repetition.",
    "You sit at the table and briefly feel that the day has started over.",

    # Work and school
    "You sit down at your desk and feel that you've already completed the work in front of you.",
    "A teacher writes something on the board, and you know what the next line will be.",
    "A meeting begins, and the opening remarks feel exactly like something you've heard before.",
    "A coworker enters the room, and you know where they're going to sit.",
    "You open a document and experience the feeling that you've already read every sentence.",
    "You receive an email that seems familiar even though it was just written.",
    "You type a sentence and suddenly feel that you've typed the same words in the same place before.",
    "A supervisor asks a question, and you remember answering it despite knowing that you haven't.",
    "You walk into a classroom for the first time and know where everything is.",
    "A presentation slide appears, and you feel that you already know the next image.",
    "The office printer makes a noise that triggers a mysterious sense of recognition.",
    "You look around a conference room and feel that everyone is sitting exactly where they sat before.",
    "A bell rings at school, and the sound seems connected to a memory you cannot find.",
    "You begin a test and feel that you've already seen one of the questions.",
    "Someone drops a pen during a meeting, and you're sure you knew it would happen.",
    "You reach a familiar-looking point in a project you've never worked on before.",
    "You hear footsteps approaching your desk and feel that you know who they belong to.",
    "A computer freezes, and you feel that you've already experienced the entire sequence.",
    "You look at the clock during a meeting and remember looking at that exact time before.",
    "You make a small mistake and feel that you've already corrected it once.",

    # Driving and transportation
    "You drive down an unfamiliar road and feel certain that you know what is beyond the next turn.",
    "You stop at a traffic light and feel that you've waited beside the same cars before.",
    "A bus arrives, and the scene seems to match a memory you cannot place.",
    "You look through a train window and feel that you've already watched the landscape pass by.",
    "You enter a subway station for the first time but somehow know where the stairs lead.",
    "A passenger sits near you, and their movements seem strangely predictable.",
    "You hear an airport announcement and feel that you've heard those exact words in a dream.",
    "You board an airplane and feel that you've already walked down that particular aisle.",
    "You reach an intersection and briefly know which direction every car will move.",
    "The scenery outside a moving car suddenly looks like a forgotten memory.",
    "You hear a turn signal clicking and feel that the entire journey is repeating.",
    "A street sign seems familiar even though you've never visited the area.",
    "You wait at a train crossing and feel that you've already counted the same passing cars.",
    "A taxi driver asks where you're going, and the conversation feels copied from another day.",
    "You pull into a parking space and feel that you've parked there before.",
    "You miss a turn and experience the odd feeling that you were supposed to miss it.",
    "You watch someone cross the street and feel that you remember their exact movements.",
    "A plane begins descending, and the view outside seems to come from a distant dream.",
    "You arrive at a station and feel that you already know which door will open.",
    "You start your car and feel that the next few minutes have already happened.",

    # Stores and restaurants
    "You push a shopping cart down an aisle and feel that you've made the same trip before.",
    "You reach for an item on a shelf and feel that your hand has completed the movement already.",
    "A cashier asks whether you want a receipt, and the question seems strangely familiar.",
    "You enter a restaurant for the first time and somehow know where the restrooms are.",
    "A server places a glass on the table, and the sound triggers a wave of déjà vu.",
    "Someone drops an item in a store, and you feel that you knew it was about to happen.",
    "You stand in a checkout line and feel that every person is in a familiar position.",
    "You read a menu and feel that you've already considered the same choices.",
    "You hear a song playing in a store and the entire scene becomes intensely familiar.",
    "You walk past a display and remember seeing it despite knowing it was installed that morning.",
    "A customer asks an employee for help, and you feel that you've already heard the exchange.",
    "You receive your meal and feel that you've seen the exact arrangement of food before.",
    "You enter a coffee shop and immediately feel that you've sat at one of its tables.",
    "A waiter walks toward you, and you somehow know what they're going to ask.",
    "The smell of a bakery creates a vivid memory of a place you've never visited.",
    "You pick up a product and feel certain that you've held that exact package before.",
    "You look through a shop window and experience a brief flash of recognition.",
    "The person ahead of you orders something, and you feel that you've heard the order before.",
    "You hear dishes clatter in a restaurant and feel that the evening is repeating.",
    "You leave a store and suddenly wonder whether you already left it moments ago.",

    # Music, movies, and entertainment
    "You hear a new song and feel that you already know the melody.",
    "A song reaches the chorus, and you somehow anticipate the next note.",
    "You watch a movie for the first time but feel that you've already seen the scene.",
    "An actor delivers a line, and you're certain you remember hearing it before.",
    "You recognize the ending of a story that nobody has ever told you.",
    "You turn on the radio and feel that the same song played during an identical moment.",
    "A drumbeat triggers a memory that disappears before you can understand it.",
    "You watch a character enter a room and feel that you've already seen what happens next.",
    "A television commercial seems familiar even though it has just been released.",
    "You hear a singer's voice and momentarily remember a place you've never been.",
    "A movie's camera angle makes you feel that you're watching one of your own memories.",
    "You correctly predict a line of dialogue without knowing how.",
    "The audience laughs, and the sound makes the theater feel strangely familiar.",
    "You begin playing a video game and feel that you've already explored the level.",
    "A musical chord creates an overwhelming sensation that time has repeated.",
    "You see an album cover and feel that it once belonged to you.",
    "A scene in a show resembles a dream you had many years ago.",
    "You select a song and feel that you've made the same choice in the same moment before.",
    "A movie character looks toward the camera, and you feel as if they recognize you.",
    "You stop a song at a certain point and feel that you always stop it there.",

    # Nature and weather
    "You step outside after the rain and feel that the smell belongs to a forgotten day.",
    "A gust of wind moves through the trees, and the scene feels impossibly familiar.",
    "You watch clouds move across the sky and feel that you've seen their exact shapes before.",
    "A bird lands nearby, and you feel that you already know when it will fly away.",
    "You walk through a park and recognize a path you've never taken.",
    "The temperature, light, and sound of the afternoon feel like a moment repeating itself.",
    "You hear distant thunder and remember a storm that may never have happened.",
    "A leaf falls in front of you, and you feel that you've watched its exact path before.",
    "You stand near the ocean and feel that the waves are repeating an old memory.",
    "A sudden snowfall makes an unfamiliar street look like somewhere you've visited.",
    "You smell cut grass and briefly remember an event you cannot identify.",
    "Sunlight passes through the trees and creates a pattern that seems deeply familiar.",
    "You hear insects on a summer night and feel that you've returned to another time.",
    "A rainbow appears, and you feel that you've stood in the same place beneath it.",
    "You walk through fog and feel that you know what will emerge ahead.",
    "A distant dog barks, and the sound seems to complete a scene you've experienced before.",
    "You look at the moon and feel that the entire night is a repetition.",
    "A cold breeze touches your face and creates a memory without any images.",
    "You watch rain move across a window and feel that you've already watched every drop.",
    "The sky changes color at sunset, and you feel that you've seen the exact transformation.",

    # Dreams and sleep
    "You enter a building and realize that it resembles a place from a dream.",
    "Someone says a phrase that you remember hearing while asleep.",
    "You experience a moment that seems to complete an unfinished dream.",
    "You wake from a dream and feel that waking up was also part of the dream.",
    "A stranger's face seems familiar because you think you once saw it in a dream.",
    "You walk into a room and remember dreaming about its layout.",
    "An ordinary event suddenly feels like something you dreamed years ago.",
    "You hear a sound and feel that it once woke you from a dream.",
    "A dream appears to predict a tiny, meaningless moment in your day.",
    "You cannot remember a dream, but a real event suddenly brings back its atmosphere.",
    "You look through a window and feel that you once dreamed about the view.",
    "Someone hands you an object, and you remember receiving it in a dream.",
    "You wake up seconds before your alarm and feel that the morning has happened already.",
    "You fall asleep briefly and wake believing that several events have repeated.",
    "You dream about déjà vu and wake unsure whether the dream itself happened before.",

    # Technology
    "Your phone displays a notification, and you feel that you've already read it.",
    "You open a website for the first time and feel that you know its entire layout.",
    "A video begins playing, and you recognize the opening despite never seeing it.",
    "You type a search phrase and feel that you've entered the same words before.",
    "Your computer makes a sound that seems connected to a forgotten memory.",
    "You receive a message and briefly believe that you've already replied.",
    "An application opens, and the screen looks exactly like something from a dream.",
    "You scroll through a page and feel that you've already stopped at the same image.",
    "Your phone rings, and you know who is calling without looking.",
    "You press a button and experience the strange certainty that you already pressed it.",
    "A loading screen produces an unexpected wave of familiarity.",
    "You unlock your phone and forget whether you just performed the same action.",
    "An autocorrect suggestion seems familiar, as if you've made the same typo before.",
    "You watch a live video and feel that you're actually watching a recording.",
    "A computer error appears, and you feel that you already know how the next minute unfolds.",
    "You read a new social media post and feel certain that you've read it before.",
    "You join an online conversation and feel that everyone is repeating an earlier discussion.",
    "A random photograph looks like a picture from your own memory.",
    "You hear a notification sound and feel that it belongs to a different time in your life.",
    "You close a program and immediately wonder whether you already closed it.",

    # Social events and gatherings
    "You arrive at a party and feel that everyone is standing in familiar positions.",
    "Someone enters the room, and you know exactly who they will greet first.",
    "A family dinner feels like an exact copy of an earlier gathering.",
    "You hear several people laughing and feel that the sound has repeated across time.",
    "A birthday cake is carried into the room, and you remember seeing the scene before.",
    "You sit beside someone you've just met but feel that you've spoken many times.",
    "A person raises their glass, and you somehow know the words of their toast.",
    "You enter a crowded room and feel that you've already navigated through the same people.",
    "Someone begins taking a group photograph, and the arrangement seems familiar.",
    "You attend a wedding in a new location and feel that you've already visited it.",
    "A guest tells a joke, and you know who will laugh the loudest.",
    "Music starts playing at a gathering, and you feel that the entire night has restarted.",
    "You look across a room and recognize a moment instead of recognizing a person.",
    "Someone spills a drink, and you feel that you saw it happen seconds earlier.",
    "You leave a gathering and feel that you've already said the same goodbyes.",

    # Odd little everyday moments
    "You glance at a clock and feel that you've seen the exact time during the exact same thought.",
    "You drop your keys and feel that you knew where they would land.",
    "You turn a corner and experience a sudden flash of familiarity.",
    "You pick up a cup and feel that the motion has repeated perfectly.",
    "You sneeze and feel that the entire moment has happened before.",
    "You tie your shoes and briefly remember doing it in the same position.",
    "You look into a mirror and feel that you've already seen your current expression.",
    "A door closes behind you, and the sound seems to belong to an older memory.",
    "You find a coin on the ground and feel that you've found the same coin before.",
    "You write down a date and experience an unexplained sense of recognition.",
    "You hear your name in a crowded place and feel that you expected it.",
    "You reach into your pocket and feel certain what your hand will touch first.",
    "You look at your reflection in a window and feel that the scene has repeated.",
    "You walk past a stranger and feel that you've passed them in the same place before.",
    "You smell perfume or cologne and remember a person you cannot identify.",
    "You take the first sip of a drink and feel that you've already tasted that exact moment.",
    "A book falls from a shelf, and you feel that you knew which page it would open to.",
    "You flip a light switch and briefly feel that reality skipped backward.",
    "You choose between two objects and feel that you already remember your decision.",
    "You hear a clock ticking and feel that you've returned to an earlier moment.",
    "You look up from what you're doing and wonder whether time just repeated itself.",
    "You experience a completely ordinary second that somehow feels more familiar than a memory.",
    "You suddenly feel that the next few seconds are already stored somewhere in your mind.",
    "The feeling disappears the instant you try to examine it.",
    "You tell someone you're experiencing déjà vu and immediately feel that you've said that before."
]

# TTS is on when the program starts.
tts_enabled = True

# Keeps track of the speech process so new speech can stop old speech.
speech_process = None

# Prevents two parts of the program from changing speech_process at once.
speech_lock = threading.Lock()


def get_startup_info():
    """
    Prevents PowerShell, say, or espeak from opening an extra console window.
    This is mostly useful on Windows.
    """
    if os.name == "nt" and hasattr(subprocess, "STARTUPINFO"):
        startup_info = subprocess.STARTUPINFO()
        startup_info.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        return startup_info

    return None


def stop_speaking():
    """Stop the currently running speech process, if one exists."""
    global speech_process

    with speech_lock:
        if speech_process is not None:
            try:
                if speech_process.poll() is None:
                    speech_process.terminate()
                    speech_process.wait(timeout=1)
            except Exception:
                try:
                    speech_process.kill()
                except Exception:
                    pass

            speech_process = None


def speak_windows(text):
    """
    Speak using Windows PowerShell and System.Speech.

    No pip packages are required.
    """
    global speech_process

    # Passing text through an environment variable avoids complicated
    # PowerShell quoting problems with apostrophes and quotation marks.
    environment = os.environ.copy()
    environment["DEJA_VU_TTS_TEXT"] = text

    powershell_script = (
        "Add-Type -AssemblyName System.Speech; "
        "$voice = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        "$voice.SetOutputToDefaultAudioDevice(); "
        "$voice.Volume = 100; "
        "$voice.Rate = 0; "
        "$voice.Speak($env:DEJA_VU_TTS_TEXT); "
        "$voice.Dispose()"
    )

    # Prefer the built-in Windows PowerShell executable.
    powershell = shutil.which("powershell.exe") or shutil.which("powershell")

    if powershell is None:
        return False

    try:
        with speech_lock:
            speech_process = subprocess.Popen(
                [
                    powershell,
                    "-NoLogo",
                    "-NoProfile",
                    "-NonInteractive",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-Command",
                    powershell_script
                ],
                env=environment,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                startupinfo=get_startup_info()
            )

        speech_process.wait()

        with speech_lock:
            speech_process = None

        return True

    except Exception:
        with speech_lock:
            speech_process = None

        return False


def speak_macos(text):
    """Speak using the built-in macOS 'say' command."""
    global speech_process

    say_command = shutil.which("say")

    if say_command is None:
        return False

    try:
        with speech_lock:
            speech_process = subprocess.Popen(
                [say_command, text],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )

        speech_process.wait()

        with speech_lock:
            speech_process = None

        return True

    except Exception:
        with speech_lock:
            speech_process = None

        return False


def speak_linux(text):
    """
    Speak using espeak or espeak-ng if one is already installed.

    The program does not install anything.
    """
    global speech_process

    speech_command = shutil.which("espeak-ng") or shutil.which("espeak")

    if speech_command is None:
        return False

    try:
        with speech_lock:
            speech_process = subprocess.Popen(
                [speech_command, text],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )

        speech_process.wait()

        with speech_lock:
            speech_process = None

        return True

    except Exception:
        with speech_lock:
            speech_process = None

        return False


def speech_worker(text):
    """Select the native TTS method for the current operating system."""
    if sys.platform.startswith("win"):
        success = speak_windows(text)

    elif sys.platform == "darwin":
        success = speak_macos(text)

    else:
        success = speak_linux(text)

    if not success and tts_enabled:
        print(
            "\n[TTS could not start. The situation is still displayed as text.]",
            flush=True
        )


def speak(text):
    """
    Speak text without freezing the menu.

    Speech runs in a background thread so the user can continue using
    the program while the voice is talking.
    """
    if not tts_enabled:
        return

    stop_speaking()

    thread = threading.Thread(
        target=speech_worker,
        args=(text,),
        daemon=True
    )
    thread.start()


def prepare_situations():
    """Return a newly shuffled copy of all situations."""
    situations = DEJA_VU_SITUATIONS.copy()
    random.shuffle(situations)
    return situations


def display_situation(situation_number, situation):
    """Display and speak one déjà vu situation."""
    print("\n" + "=" * 72)
    print(f"DEJA VU SITUATION #{situation_number}")
    print("=" * 72)
    print(situation)
    print("=" * 72)

    speak(situation)


def display_tts_status():
    """Display whether text-to-speech is currently on or off."""
    if tts_enabled:
        print("TTS is ON.")
    else:
        print("TTS is OFF.")


def get_choice():
    """Ask the user what to do next."""
    while True:
        print("\n[N] New situation")
        print("[R] Repeat this situation")
        print("[T] Turn TTS on or off")
        print("[S] Stop speaking")
        print("[Q] Quit")

        choice = input("\nChoose N, R, T, S, or Q: ").strip().lower()

        if choice in ("n", "new", ""):
            return "new"

        if choice in ("r", "repeat"):
            return "repeat"

        if choice in ("t", "tts", "voice"):
            return "tts"

        if choice in ("s", "stop", "silence"):
            return "stop"

        if choice in ("q", "quit", "exit"):
            return "quit"

        print("\nPlease enter N, R, T, S, or Q.")


def main():
    """Run the déjà vu situation generator."""
    global tts_enabled

    situations = prepare_situations()
    situation_index = 0
    situation_number = 1
    current_situation = situations[situation_index]

    print("=" * 72)
    print("DEJA VU SITUATION GENERATOR")
    print("=" * 72)
    print(f"There are {len(DEJA_VU_SITUATIONS)} situations in the generator.")
    print("Situations will not repeat until every situation has been shown.")
    display_tts_status()
    print("\nThis introduction seems strangely familiar...")

    speak(
        "Deja vu situation generator. "
        "This introduction seems strangely familiar."
    )

    try:
        while True:
            display_situation(
                situation_number,
                current_situation
            )

            while True:
                choice = get_choice()

                if choice == "quit":
                    stop_speaking()
                    print("\nWait...")
                    print("Haven't we done this before?")

                    # This final line is spoken even if TTS was turned off.
                    if tts_enabled:
                        speak("Wait. Haven't we done this before?")

                    return

                if choice == "repeat":
                    print("\nThat seems familiar...")
                    speak(current_situation)
                    continue

                if choice == "tts":
                    if tts_enabled:
                        tts_enabled = False
                        stop_speaking()
                        print("\nTTS is now OFF.")
                    else:
                        tts_enabled = True
                        print("\nTTS is now ON.")
                        speak("Text to speech is now on.")

                    continue

                if choice == "stop":
                    stop_speaking()
                    print("\nSpeech stopped.")
                    continue

                if choice == "new":
                    break

            situation_index += 1
            situation_number += 1

            if situation_index >= len(situations):
                print("\nYou have experienced every available situation.")
                print("The memories are rearranging themselves...")

                speak(
                    "You have experienced every available situation. "
                    "The memories are rearranging themselves."
                )

                situations = prepare_situations()
                situation_index = 0

            current_situation = situations[situation_index]

    except KeyboardInterrupt:
        stop_speaking()
        print("\n\nThe déjà vu generator was stopped.")

    finally:
        stop_speaking()


if __name__ == "__main__":
    main()
