import tkinter as tk
import random
import subprocess
import threading
import platform
import shutil
import base64

# ============================================================
# RANDOM REWARDS & PRIZES
# ============================================================

REWARDS = [
    # RELAXING REWARDS
    "Take a 5-minute break",
    "Take a 10-minute break",
    "Take a 15-minute break",
    "Take a 20-minute break",
    "Take a 30-minute break",
    "Take an extra-long break",
    "Take a guilt-free nap",
    "Take a power nap",
    "Spend 15 minutes doing absolutely nothing",
    "Spend 30 minutes doing absolutely nothing",
    "Have a completely lazy hour",
    "Put your feet up and relax",
    "Sit somewhere comfortable for a while",
    "Close your eyes and relax for 10 minutes",
    "Spend an hour without worrying about chores",
    "Enjoy a quiet moment",
    "Turn off unnecessary notifications for an hour",
    "Give yourself permission to slow down",
    "Rest without feeling guilty",
    "Spend the evening taking it easy",
    "Stay in your most comfortable clothes",
    "Enjoy an early bedtime",
    "Sleep a little later tomorrow if you can",
    "Do one less nonessential chore today",
    "Declare the next 20 minutes a responsibility-free zone",

    # FOOD AND DRINK REWARDS
    "Have your favorite snack",
    "Have a piece of chocolate",
    "Have some ice cream",
    "Have a cookie",
    "Have two cookies",
    "Have a piece of cake",
    "Have some popcorn",
    "Make your favorite sandwich",
    "Make a cup of coffee",
    "Have a second cup of coffee",
    "Make a cup of tea",
    "Get yourself a cold drink",
    "Enjoy a favorite childhood snack",
    "Have dessert tonight",
    "Treat yourself to lunch",
    "Order something tasty",
    "Get your favorite takeout",
    "Have pizza tonight",
    "Make some hot chocolate",
    "Have a bowl of your favorite cereal",
    "Make a milkshake",
    "Get a favorite candy bar",
    "Try a snack you have never tried",
    "Make a special breakfast",
    "Have breakfast for dinner",
    "Add an extra topping to your meal",
    "Enjoy a snack without multitasking",
    "Make something warm and comforting",
    "Visit your favorite restaurant",
    "Choose whatever you want for dinner",

    # MUSIC REWARDS
    "Listen to your favorite song",
    "Listen to three favorite songs",
    "Listen to five favorite songs",
    "Listen to an entire album",
    "Play a song you have not heard in years",
    "Watch a classic music video",
    "Watch three classic music videos",
    "Turn the music up for one song",
    "Make a short playlist",
    "Listen to a random song from your collection",
    "Revisit a favorite artist",
    "Discover one new song",
    "Sing along with a favorite song",
    "Dance to one song",
    "Listen to music with your eyes closed",
    "Play the first song that comes to mind",
    "Listen to a song from your childhood",
    "Listen to a song from your favorite decade",
    "Watch a live performance by a favorite artist",
    "Spend 20 minutes exploring music",

    # MOVIE AND VIDEO REWARDS
    "Watch a funny video",
    "Watch a favorite movie scene",
    "Watch an episode of a favorite show",
    "Watch two episodes of a favorite show",
    "Watch a short documentary",
    "Watch a full documentary",
    "Watch a classic movie",
    "Watch a comedy",
    "Watch a science-fiction movie",
    "Watch an old television show",
    "Browse YouTube for 10 minutes",
    "Browse YouTube for 20 minutes",
    "Watch a video you saved for later",
    "Rewatch an old favorite",
    "Find a strange vintage commercial",
    "Watch a behind-the-scenes video",
    "Watch an interesting interview",
    "Watch a video about something you love",
    "Pick a movie without overthinking it",
    "Have a miniature movie night",

    # CREATIVE REWARDS
    "Work on a fun project",
    "Start a tiny creative project",
    "Brainstorm a new Python program",
    "Improve one of your existing programs",
    "Invent a silly program idea",
    "Write down five unusual ideas",
    "Make something completely unnecessary",
    "Create something just because it amuses you",
    "Draw a ridiculous picture",
    "Write a funny sentence",
    "Write a short story opening",
    "Come up with a new project name",
    "Design an imaginary invention",
    "Spend 20 minutes experimenting",
    "Try a new creative technique",
    "Make a list of future project ideas",
    "Return to an unfinished idea",
    "Make something without worrying about perfection",
    "Create a tiny surprise for someone",
    "Celebrate one of your old creations",

    # FUN AND GAME REWARDS
    "Play a game for 10 minutes",
    "Play a game for 20 minutes",
    "Play a game for 30 minutes",
    "Play a retro game",
    "Play your favorite game",
    "Try a game you have not played recently",
    "Do a crossword puzzle",
    "Try a trivia quiz",
    "Solve a small puzzle",
    "Play a card game",
    "Roll dice to choose your next activity",
    "Flip a coin to make an unimportant decision",
    "Try to beat one of your old scores",
    "Play something without caring whether you win",
    "Invent a ridiculous game",
    "Give yourself an imaginary trophy",
    "Declare yourself champion of something",
    "Do something completely pointless and fun",
    "Spend 20 minutes goofing off",
    "Choose your own miniature adventure",

    # MOVEMENT AND OUTDOOR REWARDS
    "Take a short walk",
    "Take a relaxing walk",
    "Walk around for five minutes",
    "Go outside for some fresh air",
    "Sit outside for 10 minutes",
    "Look at the sky for a while",
    "Take a gentle stretch break",
    "Stretch your arms and shoulders",
    "Walk up and down the stairs once",
    "Walk around while listening to a favorite song",
    "Take a scenic drive",
    "Visit a nearby park",
    "Stand up and move around for a few minutes",
    "Do a little victory dance",
    "Walk somewhere you do not usually walk",
    "Open a window and enjoy the fresh air",
    "Spend a few minutes in the sunshine",
    "Look for something interesting outside",
    "Take five slow, comfortable breaths",
    "Move around in whatever way feels good",

    # SOCIAL REWARDS
    "Call a friend",
    "Text a friend",
    "Call a family member",
    "Send someone a funny picture",
    "Share a favorite song with someone",
    "Tell someone about your latest project",
    "Give someone an unexpected compliment",
    "Send a friendly message",
    "Have a pleasant conversation",
    "Share a funny memory",
    "Contact someone you have not spoken to recently",
    "Show someone something you created",
    "Ask someone what they are listening to",
    "Recommend a movie to someone",
    "Send someone an encouraging message",

    # SMALL TREAT REWARDS
    "Buy yourself a small treat",
    "Put five dollars into your fun fund",
    "Browse for something interesting without buying it",
    "Get a small item you have wanted",
    "Buy a new notebook",
    "Pick up a fun sticker",
    "Get yourself a magazine",
    "Buy an inexpensive gadget",
    "Choose a small surprise at the store",
    "Save a little money toward something special",
    "Add something fun to your wish list",
    "Get a new snack to try",
    "Find an inexpensive used book",
    "Get a small decoration",
    "Choose a mystery treat",

    # PERSONAL CHOICE REWARDS
    "Spend 15 minutes doing anything you want",
    "Spend 30 minutes doing anything you want",
    "Spend one hour doing anything you want",
    "Choose any reasonable reward you want",
    "Repeat your previous reward",
    "Choose two small rewards",
    "Trade this reward for another random reward",
    "Save this reward for later",
    "Give this reward to someone else",
    "Upgrade your next break by 10 minutes",
    "Skip one unimportant task",
    "Choose tonight's entertainment",
    "Choose tonight's meal",
    "Choose the next song",
    "Choose the next movie",
    "Declare today a successful day",
    "Celebrate for absolutely no reason",
    "Give yourself credit for something you finished",
    "Write down one thing you did well",
    "Reward yourself simply for showing up",
]


PRIZES = [
    # IMAGINARY MONEY AND POINTS
    "$1 imaginary bonus",
    "$2 imaginary bonus",
    "$5 imaginary bonus",
    "$10 imaginary bonus",
    "$20 imaginary bonus",
    "$50 imaginary bonus",
    "$100 imaginary bonus",
    "100 bonus points!",
    "250 bonus points!",
    "500 bonus points!",
    "1,000 bonus points!",
    "5,000 completely imaginary bonus points!",
    "One shiny imaginary coin!",
    "A bag of imaginary gold!",
    "A treasure chest of imaginary money!",
    "One million completely useless points!",
    "A lifetime supply of imaginary nickels!",
    "A wheelbarrow full of imaginary cash!",
    "Ten billion pretend dollars!",
    "One priceless invisible diamond!",

    # STARS, MEDALS, AND TROPHIES
    "A GOLD STAR!",
    "A SILVER STAR!",
    "A BRONZE STAR!",
    "A PLATINUM STAR!",
    "A DOUBLE GOLD STAR!",
    "A TRIPLE GOLD STAR!",
    "A sparkling trophy!",
    "A miniature trophy!",
    "A gigantic imaginary trophy!",
    "A gold medal!",
    "A silver medal!",
    "A bronze medal!",
    "A medal for excellent effort!",
    "A medal for showing up!",
    "A trophy for creative excellence!",
    "A trophy for doing the thing!",
    "A trophy that says ABSOLUTE CHAMPION!",
    "A championship belt!",
    "A blue ribbon!",
    "A purple ribbon!",
    "A crown made of pure victory!",
    "An official winner's certificate!",
    "A place in the imaginary hall of fame!",
    "A victory parade in your honor!",
    "A standing ovation!",

    # FOOD PRIZES
    "Free Snack Pass!",
    "Deluxe Snack Pass!",
    "Double Snack Pass!",
    "Free Coffee Pass!",
    "Free Tea Pass!",
    "Free Dessert Pass!",
    "Free Ice Cream Pass!",
    "Free Cookie Pass!",
    "Free Candy Pass!",
    "Free Popcorn Pass!",
    "Pizza Night!",
    "Taco Night!",
    "Burger Night!",
    "Sandwich Night!",
    "Breakfast-for-Dinner Night!",
    "Dessert Night!",
    "Ice Cream Night!",
    "Favorite Snack Night!",
    "Choose Tonight's Dinner!",
    "Extra Topping Pass!",
    "One mystery snack!",
    "Two mystery snacks!",
    "The largest cookie available!",
    "A completely unreasonable amount of popcorn!",
    "Permission to have dessert first!",

    # ENTERTAINMENT PRIZES
    "Movie Night!",
    "Double Feature Movie Night!",
    "Comedy Night!",
    "Documentary Night!",
    "Classic Television Night!",
    "Classic Music Video Night!",
    "Retro Game Night!",
    "YouTube Exploration Night!",
    "Favorite Album Night!",
    "Choose Tonight's Entertainment!",
    "One hour of guilt-free gaming!",
    "Two hours of guilt-free entertainment!",
    "One completely lazy evening!",
    "One responsibility-free hour!",
    "One extra-long break!",
    "One deluxe relaxation session!",
    "One evening of doing whatever you want!",
    "One hour of guilt-free goofing off!",
    "An official daydreaming permit!",
    "A temporary vacation from seriousness!",

    # MYSTERY AND BONUS PRIZES
    "Mystery Prize!",
    "Deluxe Mystery Prize!",
    "Super Mystery Prize!",
    "Secret Prize!",
    "Hidden Bonus!",
    "Bonus Reward!",
    "Double Reward!",
    "Triple Reward!",
    "Four-Rewards Bonus!",
    "Pick any reward!",
    "Pick any two rewards!",
    "Pick any three small rewards!",
    "Choose your own prize!",
    "Repeat your last prize!",
    "Save this prize for later!",
    "Trade this prize for two rewards!",
    "Give this prize to someone!",
    "Draw again immediately!",
    "Two extra chances!",
    "An automatic prize upgrade!",
    "A surprise of your own choosing!",
    "A prize from the future!",
    "An unidentified prize-shaped object!",
    "A box containing another box!",
    "The mysterious golden envelope!",

    # SILLY PRIZES
    "An invisible sports car!",
    "An imaginary private island!",
    "A personal imaginary butler!",
    "A solid-gold paperclip!",
    "The world's fanciest potato!",
    "A diamond-encrusted sandwich!",
    "An unlimited supply of imaginary pizza!",
    "A pet invisible dragon!",
    "A slightly used moon!",
    "A deed to one square inch of Mars!",
    "A royal title of your choosing!",
    "The key to an imaginary city!",
    "One extremely fancy chair!",
    "A ceremonial rubber chicken!",
    "A golden television remote!",
    "A lifetime supply of absolutely nothing!",
    "A magnificent cardboard crown!",
    "A trophy shaped like a sandwich!",
    "An official license to be lazy!",
    "A coupon good for one dramatic entrance!",
    "A button labeled DO NOT PRESS!",
    "One emergency backup snack!",
    "A commemorative spoon!",
    "A mysterious red button!",
    "The last piece of imaginary cake!",

    # PRESTIGE PRIZES
    "You are today's GRAND CHAMPION!",
    "You have achieved LEGENDARY STATUS!",
    "You are officially AWESOME!",
    "You have unlocked MAXIMUM BRAGGING RIGHTS!",
    "You have earned the title MASTER OF REWARDS!",
    "You have been promoted to SUPREME WINNER!",
    "You are now COMMANDER OF PRIZES!",
    "You have unlocked VIP STATUS!",
    "You have received the KEY TO THE REWARD ROOM!",
    "You have earned an imaginary corner office!",
    "You are employee of the minute!",
    "You are champion of the next 10 minutes!",
    "You have unlocked the secret prize menu!",
    "You are now a certified prize expert!",
    "You have earned unlimited imaginary applause!",
]


JACKPOTS = [
    "JACKPOT! Pick THREE rewards!",
    "JACKPOT! Pick FIVE rewards!",
    "DOUBLE JACKPOT! Pick TWO prizes and TWO rewards!",
    "TRIPLE JACKPOT! Pick THREE prizes and THREE rewards!",
    "MEGA PRIZE! Give yourself the rest of the evening off!",
    "SUPER JACKPOT! Favorite meal plus favorite movie!",
    "ULTIMATE PRIZE! Choose any reasonable reward you want!",
    "GOLDEN JACKPOT! Choose one prize and five rewards!",
    "DIAMOND JACKPOT! Pick anything from every category!",
    "MYSTERY JACKPOT! Invent your own grand prize!",
    "LAZY-DAY JACKPOT! Cancel one unnecessary chore!",
    "MOVIE JACKPOT! Choose a movie, snack, and drink!",
    "MUSIC JACKPOT! Listen to an entire favorite album!",
    "FOOD JACKPOT! Choose tonight's meal and dessert!",
    "GAME JACKPOT! Enjoy one hour of guilt-free gaming!",
    "CREATIVE JACKPOT! Spend an hour on any fun project!",
    "WEEKEND JACKPOT! Plan one special weekend treat!",
    "FREE-TIME JACKPOT! Claim one responsibility-free hour!",
    "SNACK JACKPOT! Choose three favorite snacks!",
    "COFFEE JACKPOT! Coffee, snack, and a relaxing break!",
    "PIZZA JACKPOT! Declare an official pizza night!",
    "DESSERT JACKPOT! Dessert first, regular food later!",
    "ENTERTAINMENT JACKPOT! Pick tonight's complete lineup!",
    "RETRO JACKPOT! Enjoy a favorite game, show, and song!",
    "CHOICE JACKPOT! Draw five rewards and keep your favorite three!",
    "SECOND-CHANCE JACKPOT! Keep this jackpot and draw again!",
    "DOUBLE-DRAW JACKPOT! Your next two selections both count!",
    "TRIPLE-DRAW JACKPOT! Your next three selections all count!",
    "INFINITE-GLORY JACKPOT! Receive unlimited imaginary applause!",
    "ROYAL JACKPOT! You are officially royalty for the next hour!",
    "TREASURE JACKPOT! You discovered the imaginary treasure chest!",
    "LEGENDARY JACKPOT! You have achieved maximum reward status!",
    "VICTORY JACKPOT! Hold a miniature celebration in your honor!",
    "MEGA-LAZY JACKPOT! Put your feet up and do nothing for 30 minutes!",
    "CHAMPION JACKPOT! Award yourself a trophy and two rewards!",
    "GOLDEN-TICKET JACKPOT! Exchange this for any prize on the list!",
    "SURPRISE JACKPOT! Ask someone else to choose your reward!",
    "TIME-BONUS JACKPOT! Add 30 minutes to your next fun activity!",
    "FAVORITES JACKPOT! Pick your favorite food, song, and video!",
    "ANYTHING-GOES JACKPOT! Choose your own reasonable celebration!",
    "SUPER-SIZED JACKPOT! Double the size or duration of your next reward!",
    "NO-CHORES JACKPOT! Skip one completely optional chore today!",
    "HALL-OF-FAME JACKPOT! You enter the imaginary reward hall of fame!",
    "GRAND-FINALE JACKPOT! Choose a meal, movie, snack, and activity!",
    "ABSOLUTE JACKPOT! Take three prizes, five rewards, and draw again!",
]


# ============================================================
# TEXT-TO-SPEECH
# ============================================================

tts_enabled = True
speech_process = None
speech_lock = threading.Lock()


def stop_speech():
    """Stop the current speech process if one is running."""
    global speech_process

    with speech_lock:
        if speech_process is not None:
            try:
                if speech_process.poll() is None:
                    speech_process.terminate()
            except Exception:
                pass

            speech_process = None


def speak_windows(text):
    """Speak text using Windows PowerShell and System.Speech."""
    global speech_process

    safe_text = text.replace("'", "''")

    powershell_script = (
        "Add-Type -AssemblyName System.Speech; "
        "$speaker = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        "$speaker.Rate = 0; "
        "$speaker.Volume = 100; "
        f"$speaker.Speak('{safe_text}');"
    )

    encoded_script = base64.b64encode(
        powershell_script.encode("utf-16-le")
    ).decode("ascii")

    creation_flags = 0

    if hasattr(subprocess, "CREATE_NO_WINDOW"):
        creation_flags = subprocess.CREATE_NO_WINDOW

    powershell_program = shutil.which("powershell") or shutil.which("pwsh")

    if powershell_program is None:
        return

    with speech_lock:
        speech_process = subprocess.Popen(
            [
                powershell_program,
                "-NoProfile",
                "-NonInteractive",
                "-EncodedCommand",
                encoded_script
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creation_flags
        )

        current_process = speech_process

    current_process.wait()

    with speech_lock:
        if speech_process is current_process:
            speech_process = None


def speak_macos(text):
    """Speak text using the built-in macOS say command."""
    global speech_process

    say_program = shutil.which("say")

    if say_program is None:
        return

    with speech_lock:
        speech_process = subprocess.Popen(
            [say_program, text],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        current_process = speech_process

    current_process.wait()

    with speech_lock:
        if speech_process is current_process:
            speech_process = None


def speak_linux(text):
    """Speak text using espeak or spd-say when available."""
    global speech_process

    espeak_program = shutil.which("espeak")
    spd_say_program = shutil.which("spd-say")

    if espeak_program is not None:
        command = [espeak_program, text]
    elif spd_say_program is not None:
        command = [spd_say_program, text]
    else:
        return

    with speech_lock:
        speech_process = subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        current_process = speech_process

    current_process.wait()

    with speech_lock:
        if speech_process is current_process:
            speech_process = None


def speech_worker(text):
    """Select the correct built-in speech method."""
    system_name = platform.system()

    try:
        if system_name == "Windows":
            speak_windows(text)

        elif system_name == "Darwin":
            speak_macos(text)

        elif system_name == "Linux":
            speak_linux(text)

    except Exception:
        pass


def speak(text):
    """Speak text on a separate thread so the window does not freeze."""
    if not tts_enabled:
        return

    stop_speech()

    speech_thread = threading.Thread(
        target=speech_worker,
        args=(text,),
        daemon=True
    )
    speech_thread.start()


def toggle_tts():
    """Turn text-to-speech on or off."""
    global tts_enabled

    tts_enabled = not tts_enabled

    if tts_enabled:
        tts_button.config(
            text="TTS: ON",
            bg="#70d670",
            activebackground="#8ee88e"
        )
        tts_status_label.config(
            text="Voice is on",
            fg="#267326"
        )
        speak("Text to speech is on.")

    else:
        stop_speech()

        tts_button.config(
            text="TTS: OFF",
            bg="#ff8c8c",
            activebackground="#ffaaaa"
        )
        tts_status_label.config(
            text="Voice is off",
            fg="#a00000"
        )


# ============================================================
# REWARD AND PRIZE FUNCTIONS
# ============================================================

def choose_reward():
    result = random.choice(REWARDS)

    prize_display.config(
        text=result,
        fg="#0057b8"
    )

    title_label.config(text="YOUR REWARD")
    speak("Your reward is. " + result)


def choose_prize():
    result = random.choice(PRIZES)

    prize_display.config(
        text=result,
        fg="#7b2cbf"
    )

    title_label.config(text="YOUR PRIZE")
    speak("Your prize is. " + result)


def surprise_me():
    # Most selections give a normal reward or prize.
    # Five percent of selections produce a jackpot.
    roll = random.randint(1, 100)

    if roll <= 5:
        result = random.choice(JACKPOTS)
        color = "#d00000"
        title = "★ JACKPOT! ★"
        spoken_text = "Jackpot! " + result

    elif roll <= 45:
        result = random.choice(PRIZES)
        color = "#7b2cbf"
        title = "SURPRISE PRIZE"
        spoken_text = "Your surprise prize is. " + result

    else:
        result = random.choice(REWARDS)
        color = "#0057b8"
        title = "SURPRISE REWARD"
        spoken_text = "Your surprise reward is. " + result

    prize_display.config(
        text=result,
        fg=color
    )

    title_label.config(text=title)
    speak(spoken_text)


def repeat_result():
    """Speak the currently displayed result again."""
    current_text = prize_display.cget("text")

    if current_text == "Press a button and see what you get!":
        speak("Press a button and see what you get.")
    else:
        speak(current_text)


def close_program():
    """Stop speech before closing the program."""
    stop_speech()
    root.destroy()


# ============================================================
# MAIN WINDOW
# ============================================================

root = tk.Tk()
root.title("Random Rewards & Prizes")
root.geometry("860x590")
root.minsize(700, 520)
root.configure(bg="#f5f5f5")
root.protocol("WM_DELETE_WINDOW", close_program)

header = tk.Label(
    root,
    text="RANDOM REWARDS & PRIZES",
    font=("Arial", 26, "bold"),
    bg="#f5f5f5",
    fg="#222222"
)
header.pack(pady=(25, 5))

subtitle = tk.Label(
    root,
    text="You did something. You deserve something!",
    font=("Arial", 13),
    bg="#f5f5f5",
    fg="#555555"
)
subtitle.pack(pady=(0, 15))

tts_control_frame = tk.Frame(
    root,
    bg="#f5f5f5"
)
tts_control_frame.pack(pady=(0, 10))

tts_button = tk.Button(
    tts_control_frame,
    text="TTS: ON",
    command=toggle_tts,
    font=("Arial", 11, "bold"),
    width=12,
    bg="#70d670",
    activebackground="#8ee88e"
)
tts_button.grid(row=0, column=0, padx=5)

repeat_button = tk.Button(
    tts_control_frame,
    text="REPEAT",
    command=repeat_result,
    font=("Arial", 11, "bold"),
    width=12,
    bg="#dddddd",
    activebackground="#eeeeee"
)
repeat_button.grid(row=0, column=1, padx=5)

tts_status_label = tk.Label(
    tts_control_frame,
    text="Voice is on",
    font=("Arial", 10),
    bg="#f5f5f5",
    fg="#267326"
)
tts_status_label.grid(row=0, column=2, padx=8)

title_label = tk.Label(
    root,
    text="READY?",
    font=("Arial", 18, "bold"),
    bg="#f5f5f5",
    fg="#333333"
)
title_label.pack(pady=5)

prize_frame = tk.Frame(
    root,
    bg="white",
    bd=3,
    relief="ridge"
)
prize_frame.pack(
    padx=40,
    pady=10,
    fill="both",
    expand=True
)

prize_display = tk.Label(
    prize_frame,
    text="Press a button and see what you get!",
    font=("Arial", 22, "bold"),
    bg="white",
    fg="#333333",
    wraplength=720,
    justify="center"
)
prize_display.pack(
    expand=True,
    padx=30,
    pady=30
)

button_frame = tk.Frame(
    root,
    bg="#f5f5f5"
)
button_frame.pack(pady=(10, 25))

reward_button = tk.Button(
    button_frame,
    text="GET REWARD",
    command=choose_reward,
    font=("Arial", 13, "bold"),
    width=15,
    height=2,
    bg="#4da6ff",
    activebackground="#80bfff"
)
reward_button.grid(row=0, column=0, padx=8)

prize_button = tk.Button(
    button_frame,
    text="GET PRIZE",
    command=choose_prize,
    font=("Arial", 13, "bold"),
    width=15,
    height=2,
    bg="#c77dff",
    activebackground="#d8a7ff"
)
prize_button.grid(row=0, column=1, padx=8)

surprise_button = tk.Button(
    button_frame,
    text="SURPRISE ME!",
    command=surprise_me,
    font=("Arial", 13, "bold"),
    width=15,
    height=2,
    bg="#ffd166",
    activebackground="#ffe29a"
)
surprise_button.grid(row=0, column=2, padx=8)

root.mainloop()
