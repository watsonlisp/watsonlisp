import csv
import ctypes
import io
import os
import platform
import shutil
import socket
import subprocess
import time
from datetime import datetime


def bytes_to_gb(byte_count):
    """Convert bytes to gigabytes."""
    if byte_count is None:
        return "Unknown"

    return f"{byte_count / (1024 ** 3):.2f} GB"


def format_seconds(seconds):
    """Convert seconds into days, hours, minutes, and seconds."""
    if seconds is None:
        return "Unknown"

    days = int(seconds // 86400)
    seconds %= 86400

    hours = int(seconds // 3600)
    seconds %= 3600

    minutes = int(seconds // 60)
    seconds %= 60

    return f"{days}d {hours}h {minutes}m {int(seconds)}s"


def run_command(command, timeout=10):
    """Run a system command and return its output."""
    try:
        creation_flags = 0

        if os.name == "nt":
            creation_flags = subprocess.CREATE_NO_WINDOW

        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            creationflags=creation_flags
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except (
        OSError,
        subprocess.SubprocessError,
        FileNotFoundError
    ):
        pass

    return ""


def get_uptime():
    """Return system uptime in seconds."""
    try:
        system = platform.system()

        if system == "Windows":
            return ctypes.windll.kernel32.GetTickCount64() / 1000

        if system == "Linux":
            with open(
                "/proc/uptime",
                "r",
                encoding="utf-8"
            ) as file:
                return float(file.readline().split()[0])

        if system == "Darwin":
            output = run_command(
                ["sysctl", "-n", "kern.boottime"]
            )

            if "sec =" in output:
                boot_time = int(
                    output.split("sec =")[1].split(",")[0].strip()
                )
                return time.time() - boot_time

    except (
        OSError,
        ValueError,
        IndexError,
        AttributeError
    ):
        pass

    return None


def get_cpu_model():
    """Return the CPU model name."""
    system = platform.system()

    try:
        if system == "Windows":
            output = run_command(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "(Get-CimInstance Win32_Processor | "
                        "Select-Object -First 1 "
                        "-ExpandProperty Name)"
                    )
                ],
                timeout=15
            )

            if not output:
                output = run_command(
                    [
                        "pwsh",
                        "-NoProfile",
                        "-Command",
                        (
                            "(Get-CimInstance Win32_Processor | "
                            "Select-Object -First 1 "
                            "-ExpandProperty Name)"
                        )
                    ],
                    timeout=15
                )

            if output:
                return output.strip()

        elif system == "Linux":
            with open(
                "/proc/cpuinfo",
                "r",
                encoding="utf-8"
            ) as file:
                for line in file:
                    lowercase_line = line.lower()

                    if lowercase_line.startswith("model name"):
                        return line.split(":", 1)[1].strip()

                    if lowercase_line.startswith("hardware"):
                        return line.split(":", 1)[1].strip()

        elif system == "Darwin":
            output = run_command(
                ["sysctl", "-n", "machdep.cpu.brand_string"]
            )

            if not output:
                output = run_command(
                    ["sysctl", "-n", "hw.model"]
                )

            if output:
                return output.strip()

    except (OSError, IndexError, ValueError):
        pass

    return platform.processor() or "Unknown"


def get_physical_core_count():
    """Return the number of physical CPU cores."""
    system = platform.system()

    try:
        if system == "Windows":
            script = (
                "(Get-CimInstance Win32_Processor | "
                "Measure-Object -Property NumberOfCores "
                "-Sum).Sum"
            )

            output = run_command(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    script
                ],
                timeout=15
            )

            if not output:
                output = run_command(
                    [
                        "pwsh",
                        "-NoProfile",
                        "-Command",
                        script
                    ],
                    timeout=15
                )

            if output:
                return int(output.strip())

        elif system == "Linux":
            physical_cores = set()
            physical_id = None
            core_id = None

            with open(
                "/proc/cpuinfo",
                "r",
                encoding="utf-8"
            ) as file:
                for raw_line in file:
                    line = raw_line.strip()

                    if not line:
                        if (
                            physical_id is not None
                            and core_id is not None
                        ):
                            physical_cores.add(
                                (physical_id, core_id)
                            )

                        physical_id = None
                        core_id = None
                        continue

                    if line.startswith("physical id"):
                        physical_id = (
                            line.split(":", 1)[1].strip()
                        )

                    elif line.startswith("core id"):
                        core_id = (
                            line.split(":", 1)[1].strip()
                        )

            if (
                physical_id is not None
                and core_id is not None
            ):
                physical_cores.add((physical_id, core_id))

            if physical_cores:
                return len(physical_cores)

            output = run_command(["lscpu", "-p=CORE,SOCKET"])

            if output:
                core_pairs = set()

                for line in output.splitlines():
                    if line.startswith("#"):
                        continue

                    parts = line.split(",")

                    if len(parts) >= 2:
                        core_pairs.add(
                            (parts[0].strip(), parts[1].strip())
                        )

                if core_pairs:
                    return len(core_pairs)

        elif system == "Darwin":
            output = run_command(
                ["sysctl", "-n", "hw.physicalcpu"]
            )

            if output:
                return int(output.strip())

    except (OSError, ValueError, IndexError):
        pass

    return None


def get_cpu_frequency():
    """Return the CPU frequency in megahertz."""
    system = platform.system()

    try:
        if system == "Windows":
            script = (
                "(Get-CimInstance Win32_Processor | "
                "Select-Object -First 1 "
                "-ExpandProperty MaxClockSpeed)"
            )

            output = run_command(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    script
                ],
                timeout=15
            )

            if not output:
                output = run_command(
                    [
                        "pwsh",
                        "-NoProfile",
                        "-Command",
                        script
                    ],
                    timeout=15
                )

            if output:
                return float(output.strip())

        elif system == "Linux":
            maximum_frequency_path = (
                "/sys/devices/system/cpu/cpu0/cpufreq/"
                "cpuinfo_max_freq"
            )

            current_frequency_path = (
                "/sys/devices/system/cpu/cpu0/cpufreq/"
                "scaling_cur_freq"
            )

            if os.path.exists(maximum_frequency_path):
                with open(
                    maximum_frequency_path,
                    "r",
                    encoding="utf-8"
                ) as file:
                    return float(file.read().strip()) / 1000

            if os.path.exists(current_frequency_path):
                with open(
                    current_frequency_path,
                    "r",
                    encoding="utf-8"
                ) as file:
                    return float(file.read().strip()) / 1000

            with open(
                "/proc/cpuinfo",
                "r",
                encoding="utf-8"
            ) as file:
                for line in file:
                    if line.lower().startswith("cpu mhz"):
                        return float(
                            line.split(":", 1)[1].strip()
                        )

        elif system == "Darwin":
            output = run_command(
                ["sysctl", "-n", "hw.cpufrequency_max"]
            )

            if not output:
                output = run_command(
                    ["sysctl", "-n", "hw.cpufrequency"]
                )

            if output:
                return float(output.strip()) / 1_000_000

    except (OSError, ValueError, IndexError):
        pass

    return None


def get_windows_cpu_times():
    """Return Windows idle, kernel, and user CPU times."""
    class FileTime(ctypes.Structure):
        _fields_ = [
            ("dwLowDateTime", ctypes.c_ulong),
            ("dwHighDateTime", ctypes.c_ulong),
        ]

    def file_time_to_integer(file_time):
        return (
            file_time.dwHighDateTime << 32
        ) | file_time.dwLowDateTime

    idle_time = FileTime()
    kernel_time = FileTime()
    user_time = FileTime()

    try:
        success = ctypes.windll.kernel32.GetSystemTimes(
            ctypes.byref(idle_time),
            ctypes.byref(kernel_time),
            ctypes.byref(user_time)
        )

        if not success:
            return None

        return (
            file_time_to_integer(idle_time),
            file_time_to_integer(kernel_time),
            file_time_to_integer(user_time)
        )

    except (OSError, AttributeError):
        return None


def get_linux_cpu_times():
    """Return Linux total and idle CPU times."""
    try:
        with open(
            "/proc/stat",
            "r",
            encoding="utf-8"
        ) as file:
            values = file.readline().split()

        if not values or values[0] != "cpu":
            return None

        numbers = [float(value) for value in values[1:]]

        if len(numbers) < 4:
            return None

        idle = numbers[3]

        if len(numbers) > 4:
            idle += numbers[4]

        total = sum(numbers)

        return total, idle

    except (OSError, ValueError, IndexError):
        return None


def get_macos_cpu_usage():
    """Return the current macOS CPU usage percentage."""
    output = run_command(
        ["top", "-l", "2", "-n", "0"],
        timeout=15
    )

    if not output:
        return None

    cpu_lines = [
        line.strip()
        for line in output.splitlines()
        if "CPU usage:" in line
    ]

    if not cpu_lines:
        return None

    last_line = cpu_lines[-1]

    try:
        idle_text = (
            last_line.split("idle")[0]
            .split(",")[-1]
            .strip()
            .replace("%", "")
        )

        idle_percentage = float(idle_text)
        usage = 100.0 - idle_percentage

        return max(0.0, min(100.0, usage))

    except (ValueError, IndexError):
        return None


def get_cpu_usage(sample_time=0.5):
    """Measure and return total CPU usage percentage."""
    system = platform.system()

    try:
        if system == "Windows":
            first = get_windows_cpu_times()

            if first is None:
                return None

            time.sleep(sample_time)
            second = get_windows_cpu_times()

            if second is None:
                return None

            idle_difference = second[0] - first[0]
            kernel_difference = second[1] - first[1]
            user_difference = second[2] - first[2]
            total_difference = (
                kernel_difference + user_difference
            )

            if total_difference <= 0:
                return 0.0

            usage = (
                1.0 - idle_difference / total_difference
            ) * 100

            return max(0.0, min(100.0, usage))

        if system == "Linux":
            first = get_linux_cpu_times()

            if first is None:
                return None

            time.sleep(sample_time)
            second = get_linux_cpu_times()

            if second is None:
                return None

            total_difference = second[0] - first[0]
            idle_difference = second[1] - first[1]

            if total_difference <= 0:
                return 0.0

            usage = (
                1.0 - idle_difference / total_difference
            ) * 100

            return max(0.0, min(100.0, usage))

        if system == "Darwin":
            return get_macos_cpu_usage()

    except (
        OSError,
        ValueError,
        IndexError,
        AttributeError
    ):
        pass

    return None


def get_cpu_stats():
    """Return all available CPU statistics."""
    return {
        "model": get_cpu_model(),
        "architecture": platform.machine() or "Unknown",
        "physical_cores": get_physical_core_count(),
        "logical_processors": os.cpu_count(),
        "frequency": get_cpu_frequency(),
        "usage": get_cpu_usage(),
    }


def get_windows_ram():
    """Return Windows RAM information."""
    class MemoryStatusEx(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            (
                "ullAvailExtendedVirtual",
                ctypes.c_ulonglong
            ),
        ]

    memory_status = MemoryStatusEx()
    memory_status.dwLength = ctypes.sizeof(MemoryStatusEx)

    success = ctypes.windll.kernel32.GlobalMemoryStatusEx(
        ctypes.byref(memory_status)
    )

    if not success:
        return None

    total = memory_status.ullTotalPhys
    available = memory_status.ullAvailPhys
    used = total - available

    return {
        "total": total,
        "used": used,
        "available": available,
        "percentage": float(memory_status.dwMemoryLoad),
    }


def get_linux_ram():
    """Return Linux RAM information."""
    memory_data = {}

    with open(
        "/proc/meminfo",
        "r",
        encoding="utf-8"
    ) as file:
        for line in file:
            key, value = line.split(":", 1)
            value_kb = int(value.strip().split()[0])
            memory_data[key] = value_kb * 1024

    total = memory_data.get("MemTotal")
    available = memory_data.get("MemAvailable")

    if available is None:
        available = (
            memory_data.get("MemFree", 0)
            + memory_data.get("Buffers", 0)
            + memory_data.get("Cached", 0)
        )

    if total is None or available is None:
        return None

    used = total - available
    percentage = (used / total) * 100 if total else 0

    return {
        "total": total,
        "used": used,
        "available": available,
        "percentage": percentage,
    }


def get_macos_ram():
    """Return macOS RAM information."""
    total_output = run_command(
        ["sysctl", "-n", "hw.memsize"]
    )

    if not total_output:
        return None

    total = int(total_output)

    vm_output = run_command(["vm_stat"])

    if not vm_output:
        return None

    page_size = 4096
    memory_values = {}

    for line in vm_output.splitlines():
        if "page size of" in line:
            try:
                page_size = int(
                    line.split("page size of")[1]
                    .split("bytes")[0]
                    .strip()
                )
            except (ValueError, IndexError):
                page_size = 4096

        elif ":" in line:
            key, value = line.split(":", 1)

            try:
                memory_values[key.strip()] = int(
                    value.strip().rstrip(".")
                )
            except ValueError:
                pass

    available_pages = (
        memory_values.get("Pages free", 0)
        + memory_values.get("Pages inactive", 0)
        + memory_values.get("Pages speculative", 0)
        + memory_values.get("Pages purgeable", 0)
    )

    available = available_pages * page_size
    used = total - available
    percentage = (used / total) * 100 if total else 0

    return {
        "total": total,
        "used": used,
        "available": available,
        "percentage": percentage,
    }


def get_ram_info():
    """Return RAM information for the current operating system."""
    try:
        system = platform.system()

        if system == "Windows":
            return get_windows_ram()

        if system == "Linux":
            return get_linux_ram()

        if system == "Darwin":
            return get_macos_ram()

    except (
        OSError,
        ValueError,
        IndexError,
        AttributeError
    ):
        pass

    return None


def clean_value(value):
    """Clean a value returned by an operating-system command."""
    if value is None:
        return "Unknown"

    value = str(value).strip()

    if not value:
        return "Unknown"

    return value


def get_windows_graphics():
    """Return graphics-card information on Windows."""
    powershell_commands = ["powershell", "pwsh"]

    script = (
        "Get-CimInstance Win32_VideoController | "
        "Select-Object Name,AdapterRAM,DriverVersion,"
        "VideoProcessor,CurrentHorizontalResolution,"
        "CurrentVerticalResolution,"
        "CurrentRefreshRate,VideoModeDescription | "
        "ConvertTo-Csv -NoTypeInformation"
    )

    for powershell in powershell_commands:
        output = run_command(
            [
                powershell,
                "-NoProfile",
                "-Command",
                script
            ],
            timeout=15
        )

        if not output:
            continue

        try:
            rows = csv.DictReader(io.StringIO(output))
            graphics_cards = []

            for row in rows:
                adapter_ram = row.get("AdapterRAM", "")

                try:
                    graphics_memory = bytes_to_gb(
                        int(adapter_ram)
                    )
                except (ValueError, TypeError):
                    graphics_memory = "Unknown"

                horizontal = clean_value(
                    row.get("CurrentHorizontalResolution")
                )

                vertical = clean_value(
                    row.get("CurrentVerticalResolution")
                )

                if (
                    horizontal != "Unknown"
                    and vertical != "Unknown"
                ):
                    resolution = f"{horizontal} x {vertical}"
                else:
                    resolution = "Unknown"

                refresh_rate = clean_value(
                    row.get("CurrentRefreshRate")
                )

                if refresh_rate != "Unknown":
                    refresh_rate += " Hz"

                graphics_cards.append(
                    {
                        "name": clean_value(
                            row.get("Name")
                        ),
                        "memory": graphics_memory,
                        "processor": clean_value(
                            row.get("VideoProcessor")
                        ),
                        "driver": clean_value(
                            row.get("DriverVersion")
                        ),
                        "resolution": resolution,
                        "refresh_rate": refresh_rate,
                        "video_mode": clean_value(
                            row.get("VideoModeDescription")
                        ),
                    }
                )

            if graphics_cards:
                return graphics_cards

        except (csv.Error, ValueError, TypeError):
            pass

    return []


def get_linux_graphics():
    """Return graphics-card information on Linux."""
    graphics_cards = []
    output = run_command(["lspci"])

    if not output:
        return graphics_cards

    for line in output.splitlines():
        lowercase_line = line.lower()

        is_graphics_device = (
            "vga compatible controller" in lowercase_line
            or "3d controller" in lowercase_line
            or "display controller" in lowercase_line
        )

        if is_graphics_device:
            if ": " in line:
                name = line.split(": ", 1)[1]
            else:
                name = line

            graphics_cards.append(
                {
                    "name": name.strip(),
                    "memory": "Unknown",
                    "processor": "Unknown",
                    "driver": "Unknown",
                    "resolution": "Unknown",
                    "refresh_rate": "Unknown",
                    "video_mode": "Unknown",
                }
            )

    return graphics_cards


def get_macos_graphics():
    """Return graphics-card information on macOS."""
    graphics_cards = []

    output = run_command(
        ["system_profiler", "SPDisplaysDataType"],
        timeout=20
    )

    if not output:
        return graphics_cards

    current_gpu = None

    for raw_line in output.splitlines():
        line = raw_line.strip()

        if line.startswith("Chipset Model:"):
            if current_gpu:
                graphics_cards.append(current_gpu)

            current_gpu = {
                "name": line.split(":", 1)[1].strip(),
                "memory": "Unknown",
                "processor": "Unknown",
                "driver": "Unknown",
                "resolution": "Unknown",
                "refresh_rate": "Unknown",
                "video_mode": "Unknown",
            }

        elif current_gpu and line.startswith("VRAM"):
            current_gpu["memory"] = (
                line.split(":", 1)[1].strip()
            )

        elif current_gpu and line.startswith("Resolution:"):
            current_gpu["resolution"] = (
                line.split(":", 1)[1].strip()
            )

        elif current_gpu and line.startswith("Refresh Rate:"):
            current_gpu["refresh_rate"] = (
                line.split(":", 1)[1].strip()
            )

    if current_gpu:
        graphics_cards.append(current_gpu)

    return graphics_cards


def get_graphics_info():
    """Return graphics information for the current operating system."""
    system = platform.system()

    if system == "Windows":
        return get_windows_graphics()

    if system == "Linux":
        return get_linux_graphics()

    if system == "Darwin":
        return get_macos_graphics()

    return []


def get_disk_path():
    """Return the main disk path."""
    if os.name == "nt":
        system_drive = os.environ.get("SystemDrive", "C:")
        return system_drive + "\\"

    return "/"


def get_network_info():
    """Return the hostname and local IP address."""
    hostname = socket.gethostname()

    try:
        ip_address = socket.gethostbyname(hostname)
    except OSError:
        ip_address = "Unknown"

    return hostname, ip_address


def print_system_stats():
    """Print the complete system-statistics report."""
    print("=" * 64)
    print("SYSTEM STATISTICS REPORT")
    print("=" * 64)

    print(
        f"Time             : "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )
    print()

    # Original SYSTEM statistics
    print("SYSTEM")
    print("-" * 64)
    print(f"Operating System : {platform.system()}")
    print(f"OS Version       : {platform.version()}")
    print(f"Release          : {platform.release()}")
    print(f"Machine          : {platform.machine()}")
    print(f"Processor        : {platform.processor() or 'Unknown'}")
    print(f"Python Version   : {platform.python_version()}")
    print()

    # Added CPU statistics
    print("CPU")
    print("-" * 64)

    cpu = get_cpu_stats()

    print(f"CPU Model        : {cpu['model']}")
    print(f"Architecture     : {cpu['architecture']}")

    if cpu["physical_cores"] is not None:
        print(f"Physical Cores   : {cpu['physical_cores']}")
    else:
        print("Physical Cores   : Unknown")

    if cpu["logical_processors"] is not None:
        print(
            f"Logical CPUs     : "
            f"{cpu['logical_processors']}"
        )
    else:
        print("Logical CPUs     : Unknown")

    if cpu["frequency"] is not None:
        print(
            f"CPU Frequency    : "
            f"{cpu['frequency']:.0f} MHz"
        )
    else:
        print("CPU Frequency    : Unknown")

    if cpu["usage"] is not None:
        print(f"CPU Usage        : {cpu['usage']:.1f}%")
    else:
        print("CPU Usage        : Unknown")

    print()

    # Added RAM statistics
    print("RAM")
    print("-" * 64)

    ram = get_ram_info()

    if ram:
        print(f"Total RAM        : {bytes_to_gb(ram['total'])}")
        print(f"Used RAM         : {bytes_to_gb(ram['used'])}")
        print(
            f"Available RAM    : "
            f"{bytes_to_gb(ram['available'])}"
        )
        print(f"RAM Usage        : {ram['percentage']:.1f}%")
    else:
        print("RAM information unavailable")

    print()

    # Added graphics statistics
    print("GRAPHICS")
    print("-" * 64)

    graphics_cards = get_graphics_info()

    if graphics_cards:
        for number, card in enumerate(
            graphics_cards,
            start=1
        ):
            print(f"Graphics Card {number}")
            print(f"  Name           : {card['name']}")
            print(f"  Graphics RAM   : {card['memory']}")
            print(f"  Video Processor: {card['processor']}")
            print(f"  Driver Version : {card['driver']}")
            print(f"  Resolution     : {card['resolution']}")
            print(f"  Refresh Rate   : {card['refresh_rate']}")
            print(f"  Video Mode     : {card['video_mode']}")

            if number < len(graphics_cards):
                print()
    else:
        print("Graphics information unavailable")

    print()

    # Original NETWORK statistics
    print("NETWORK")
    print("-" * 64)

    try:
        hostname, ip_address = get_network_info()
        print(f"Hostname         : {hostname}")
        print(f"IP Address       : {ip_address}")
    except OSError:
        print("Network information unavailable")

    print()

    # Original DISK statistics
    print("DISK")
    print("-" * 64)

    try:
        disk_path = get_disk_path()
        total, used, free = shutil.disk_usage(disk_path)
        usage_percentage = (
            (used / total) * 100 if total else 0
        )

        print(f"Disk             : {disk_path}")
        print(f"Total Space      : {bytes_to_gb(total)}")
        print(f"Used Space       : {bytes_to_gb(used)}")
        print(f"Free Space       : {bytes_to_gb(free)}")
        print(f"Disk Usage       : {usage_percentage:.1f}%")

    except OSError:
        print("Disk information unavailable")

    print()

    # Original UPTIME statistic
    print("UPTIME")
    print("-" * 64)
    print(f"System Uptime    : {format_seconds(get_uptime())}")
    print()

    # Original PROCESS statistics
    print("PROCESS")
    print("-" * 64)
    print(f"Current PID      : {os.getpid()}")
    print(f"CPU Count        : {os.cpu_count() or 'Unknown'}")
    print()

    print("=" * 64)


def clear_screen():
    """Clear the terminal screen."""
    os.system("cls" if os.name == "nt" else "clear")


def main():
    while True:
        print_system_stats()

        choice = input(
            "\n[R]efresh  [C]lear Screen  [Q]uit: "
        ).strip().lower()

        if choice == "q":
            print("System statistics reporter closed.")
            break

        if choice in ("r", ""):
            clear_screen()

        elif choice == "c":
            clear_screen()

        else:
            print("Please enter R, C, or Q.")


if __name__ == "__main__":
    main()
