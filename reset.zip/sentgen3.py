import random
import subprocess
import threading
import shutil


# ------------------------------------------------------------
# SETTINGS
# ------------------------------------------------------------

TTS_ON = True
TTS_RATE = 0
TTS_VOLUME = 100


# ------------------------------------------------------------
# SENTENCE TEMPLATES
# ------------------------------------------------------------

templates = [
    "The {noun} likes to {verb}.",
    "A {noun} suddenly decided to {verb}.",
    "Every {noun} can {verb} if it tries.",
    "The mysterious {noun} will {verb} tonight.",
    "One {noun} loves to {verb} every day.",
    "That {noun} forgot how to {verb}.",
    "The giant {noun} began to {verb}.",
    "My favorite {noun} wants to {verb}.",
    "The {noun} tried to {verb} but failed.",
    "The {noun} successfully learned to {verb}.",
    "A sleepy {noun} started to {verb}.",
    "The angry {noun} refused to {verb}.",
    "The happy {noun} could not stop trying to {verb}.",
    "The tiny {noun} wanted to {verb}.",
    "The enormous {noun} attempted to {verb}.",
    "The lonely {noun} dreamed about how to {verb}.",
    "A strange {noun} appeared and began to {verb}.",
    "The legendary {noun} was born to {verb}.",
    "The unlucky {noun} accidentally learned to {verb}.",
    "The brave {noun} volunteered to {verb}.",
    "No {noun} has ever managed to {verb} like this before.",
    "The {noun} spent all morning trying to {verb}.",
    "The {noun} spent all night trying to {verb}.",
    "A confused {noun} wondered whether to {verb}.",
    "The {noun} proudly stood up and began to {verb}.",
    "The smart {noun} secretly planned to {verb}.",
    "The funny {noun} made everyone laugh while trying to {verb}.",
    "The magical {noun} was famous for its ability to {verb}.",
    "The ancient {noun} suddenly remembered how to {verb}.",
    "The robotic {noun} was programmed to {verb}.",
    "The mysterious {noun} from space came to {verb}.",
    "The wild {noun} loudly declared it would {verb}.",
    "Everyone watched as the {noun} tried to {verb}.",
    "Nobody expected the {noun} to {verb}.",
    "The {noun} practiced every day in order to {verb}.",
    "The {noun} made history when it learned to {verb}.",
    "At sunrise, the {noun} began to {verb}.",
    "At sunset, the {noun} continued to {verb}.",
    "The {noun} never stopped trying to {verb}.",
    "The {noun} finally achieved its dream of {verb_ing}.",
    "A heroic {noun} decided to {verb} for the greater good.",
    "The curious {noun} wandered away to {verb}.",
    "The energetic {noun} could not resist the urge to {verb}.",
    "The stubborn {noun} insisted on trying to {verb}.",
    "The adventurous {noun} traveled far away to {verb}.",
    "The famous {noun} was interviewed about its ability to {verb}.",
    "The nervous {noun} prepared carefully to {verb}.",
    "The rich {noun} paid someone to {verb}.",
    "The poor {noun} hoped for a chance to {verb}.",
    "The scientist {noun} invented a machine to {verb}.",
    "The pirate {noun} sailed the seas to {verb}.",
    "The wizard {noun} cast a spell and started to {verb}.",
    "The alien {noun} crossed the galaxy to {verb}.",
    "The dinosaur {noun} surprisingly learned to {verb}.",
    "The ninja {noun} silently prepared to {verb}.",
    "The superhero {noun} used its powers to {verb}.",
    "The villainous {noun} threatened to {verb}.",
    "The royal {noun} commanded everyone to {verb}.",
    "The cheerful {noun} sang while trying to {verb}.",
    "The dramatic {noun} announced its plan to {verb}.",
    "A glowing {noun} floated by and began to {verb}.",
    "The invisible {noun} attempted to {verb} unnoticed.",
    "The flying {noun} swooped down to {verb}.",
    "The underwater {noun} learned to {verb}.",
    "The cybernetic {noun} upgraded itself and began to {verb}.",
    "The prehistoric {noun} unexpectedly started to {verb}.",
    "The time-traveling {noun} arrived specifically to {verb}.",
    "The sleepy {noun} yawned before trying to {verb}.",
    "The excited {noun} jumped up and began to {verb}.",
    "The grumpy {noun} complained while trying to {verb}.",
    "The polite {noun} asked permission to {verb}.",
    "The hilarious {noun} became famous after learning to {verb}.",
    "The legendary {noun} challenged everyone to {verb}.",
    "The futuristic {noun} was built to {verb}.",
    "The mysterious {noun} vanished immediately after it {verb_past}.",
    "The clever {noun} discovered the secret of how to {verb}.",
    "The glowing {noun} proudly demonstrated how to {verb}.",
    "The confused {noun} accidentally started to {verb}.",
    "A thousand people gathered to watch the {noun} {verb}.",
    "The {noun} broke a world record for {verb_ing}.",
    "The {noun} became an internet celebrity by {verb_ing}.",
    "The {noun} won an award for {verb_ing}.",
    "The {noun} wrote a book about how to {verb}.",
    "The {noun} launched a business dedicated to {verb_ing}.",
    "The {noun} created a club for people who love to {verb}.",
    "The {noun} traveled around the world to {verb}.",
    "The {noun} built a machine that could {verb}.",
    "The {noun} accidentally taught others how to {verb}.",
    "The {noun} became obsessed with trying to {verb}.",
    "The {noun} always wanted the opportunity to {verb}.",
    "The {noun} surprised everyone by learning to {verb} in one day.",
    "The {noun} challenged the mayor to {verb}.",
    "The {noun} challenged a robot to {verb}.",
    "The {noun} challenged an alien to {verb}.",
    "The {noun} hosted a festival dedicated to {verb_ing}.",
    "The {noun} turned professional at {verb_ing}.",
    "The {noun} retired after many years of {verb_ing}.",
    "The {noun} couldn't believe it had finally learned to {verb}.",
]


# ------------------------------------------------------------
# VERB FORM FUNCTIONS
# ------------------------------------------------------------

def make_ing_form(verb):
    """
    Create an approximate -ing form.

    Examples:
        dance -> dancing
        lie   -> lying
        see   -> seeing
        run   -> running
    """

    verb = verb.strip()

    if not verb:
        return verb

    lower_verb = verb.lower()

    if lower_verb.endswith("ing"):
        return verb

    if lower_verb.endswith("ie"):
        return verb[:-2] + "ying"

    if lower_verb.endswith("e") and not lower_verb.endswith(
        ("ee", "ye", "oe")
    ):
        return verb[:-1] + "ing"

    # Double the final consonant in some short verbs.
    vowels = "aeiou"

    if (
        len(verb) == 3
        and lower_verb[-1] not in vowels
        and lower_verb[-2] in vowels
        and lower_verb[-3] not in vowels
        and lower_verb[-1] not in "wxy"
    ):
        return verb + verb[-1] + "ing"

    return verb + "ing"


def make_past_form(verb):
    """
    Create an approximate past-tense form.

    Examples:
        dance -> danced
        carry -> carried
        jump  -> jumped
        stop  -> stopped
    """

    verb = verb.strip()

    if not verb:
        return verb

    lower_verb = verb.lower()

    if lower_verb.endswith("e"):
        return verb + "d"

    if (
        lower_verb.endswith("y")
        and len(verb) > 1
        and lower_verb[-2] not in "aeiou"
    ):
        return verb[:-1] + "ied"

    vowels = "aeiou"

    if (
        len(verb) == 3
        and lower_verb[-1] not in vowels
        and lower_verb[-2] in vowels
        and lower_verb[-3] not in vowels
        and lower_verb[-1] not in "wxy"
    ):
        return verb + verb[-1] + "ed"

    return verb + "ed"


# ------------------------------------------------------------
# WINDOWS TTS
# ------------------------------------------------------------

def find_powershell():
    """
    Find Windows PowerShell or PowerShell 7.
    Windows PowerShell is preferred because System.Speech is
    normally available there.
    """

    possible_programs = [
        "powershell.exe",
        "powershell",
        "pwsh.exe",
        "pwsh",
    ]

    for program in possible_programs:
        if shutil.which(program):
            return program

    return None


def speak_worker(text):
    """
    Speak text through Windows PowerShell and System.Speech.
    This requires no pip packages.
    """

    powershell = find_powershell()

    if powershell is None:
        print()
        print("TTS error: PowerShell could not be found.")
        return

    # Escape apostrophes for a PowerShell single-quoted string.
    safe_text = text.replace("'", "''")

    command = (
        "Add-Type -AssemblyName System.Speech; "
        "$speaker = New-Object "
        "System.Speech.Synthesis.SpeechSynthesizer; "
        f"$speaker.Rate = {TTS_RATE}; "
        f"$speaker.Volume = {TTS_VOLUME}; "
        f"$speaker.Speak('{safe_text}'); "
        "$speaker.Dispose();"
    )

    startupinfo = None
    creationflags = 0

    # Keep the PowerShell window hidden on Windows.
    if hasattr(subprocess, "STARTUPINFO"):
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

    if hasattr(subprocess, "CREATE_NO_WINDOW"):
        creationflags = subprocess.CREATE_NO_WINDOW

    try:
        subprocess.run(
            [
                powershell,
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                command,
            ],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            startupinfo=startupinfo,
            creationflags=creationflags,
        )

    except Exception as error:
        print()
        print("TTS error:", error)


def speak(text):
    """
    Speak without freezing the main program.
    """

    if not TTS_ON:
        return

    speech_thread = threading.Thread(
        target=speak_worker,
        args=(text,),
        daemon=True,
    )

    speech_thread.start()


# ------------------------------------------------------------
# INPUT AND SENTENCE FUNCTIONS
# ------------------------------------------------------------

def get_words(prompt):
    """
    Ask the user to enter comma-separated words.
    """

    while True:
        user_input = input(prompt)

        words = [
            word.strip()
            for word in user_input.split(",")
            if word.strip()
        ]

        if words:
            return words

        print()
        print("Please enter at least one word.")
        print()


def generate_sentence(nouns, verbs):
    """
    Choose a random noun, verb, and template.
    """

    noun = random.choice(nouns)
    verb = random.choice(verbs)
    verb_ing = make_ing_form(verb)
    verb_past = make_past_form(verb)
    template = random.choice(templates)

    return template.format(
        noun=noun,
        verb=verb,
        verb_ing=verb_ing,
        verb_past=verb_past,
    )


def enter_new_words():
    """
    Ask the user for new noun and verb lists.
    """

    print()
    print("Enter multiple words separated by commas.")
    print()

    nouns = get_words("Enter nouns: ")
    verbs = get_words("Enter verbs: ")

    return nouns, verbs


def show_word_lists(nouns, verbs):
    """
    Display the currently loaded nouns and verbs.
    """

    print()
    print("CURRENT WORD LISTS")
    print("-" * 60)
    print("Nouns:", ", ".join(nouns))
    print("Verbs:", ", ".join(verbs))
    print("-" * 60)


def show_commands():
    """
    Display all available commands.
    """

    print()
    print("COMMANDS")
    print("-" * 60)
    print("Enter  Generate another sentence")
    print("R      Replace the noun and verb lists")
    print("L      List the current nouns and verbs")
    print("S      Speak the current sentence again")
    print("T      Turn TTS on or off")
    print("H      Show the commands")
    print("Q      Quit")
    print("-" * 60)


# ------------------------------------------------------------
# MAIN PROGRAM
# ------------------------------------------------------------

def main():
    global TTS_ON

    print("=" * 60)
    print("RANDOM SENTENCE GENERATOR")
    print("=" * 60)
    print()
    print("This program creates random sentences from your words.")
    print("Windows text-to-speech is ON by default.")
    print()
    print("No pip packages are required.")
    print("PIL is not required.")
    print()
    print("Enter nouns and verbs separated by commas.")
    print()
    print("Example nouns:")
    print("cat, robot, wizard, car, computer")
    print()
    print("Example verbs:")
    print("dance, run, jump, sing, cook")
    print()

    speak("Random sentence generator started.")

    nouns, verbs = enter_new_words()

    print()
    print("-" * 60)
    print(f"Loaded {len(nouns)} noun or nouns.")
    print(f"Loaded {len(verbs)} verb or verbs.")
    print(f"Loaded {len(templates)} sentence templates.")
    print("-" * 60)

    show_commands()

    current_sentence = ""

    while True:
        current_sentence = generate_sentence(nouns, verbs)

        print()
        print("=" * 60)
        print(current_sentence)
        print("=" * 60)

        speak(current_sentence)

        print()
        print(
            "Enter=Another | R=Replace | L=List | "
            "S=Speak | T=TTS | H=Help | Q=Quit"
        )
        print()

        choice = input("Your choice: ").strip().lower()

        if choice == "q":
            speak("Goodbye.")
            break

        elif choice == "r":
            nouns, verbs = enter_new_words()

            print()
            print("The noun and verb lists have been replaced.")
            print(f"Loaded {len(nouns)} noun or nouns.")
            print(f"Loaded {len(verbs)} verb or verbs.")

            speak("The word lists have been replaced.")

        elif choice == "l":
            show_word_lists(nouns, verbs)

        elif choice == "s":
            if current_sentence:
                print()
                print("Speaking the current sentence again.")
                speak(current_sentence)

        elif choice == "t":
            TTS_ON = not TTS_ON

            print()

            if TTS_ON:
                print("TTS is now ON.")
                speak("Text to speech is now on.")
            else:
                print("TTS is now OFF.")

        elif choice == "h":
            show_commands()

        elif choice == "":
            continue

        else:
            print()
            print("Unknown command. Press H to show the commands.")

    print()
    print("Goodbye!")


if __name__ == "__main__":
    main()
