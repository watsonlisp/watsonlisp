import tkinter as tk
from tkinter import ttk
import math
import os
import random
import struct
import tempfile
import threading
import wave

# ============================================================
# TIMER - Huge Alarm Selection
# No pip packages required
# Windows: uses winsound
# ============================================================

try:
    import winsound
    HAS_WINSOUND = True
except ImportError:
    HAS_WINSOUND = False


# ============================================================
# ALARM LIBRARY
# Each alarm contains (frequency, duration_ms) values.
# A frequency of 0 produces silence.
# ============================================================

ALARMS = {
    "Classic Alarm": [
        (880, 300), (0, 100), (880, 300), (0, 100),
        (880, 300), (0, 400)
    ],

    "Digital Beep": [
        (1200, 150), (0, 100), (1200, 150), (0, 100),
        (1200, 150), (0, 350)
    ],

    "Double Beep": [
        (900, 200), (0, 80), (900, 200), (0, 500)
    ],

    "Triple Beep": [
        (1000, 150), (0, 80),
        (1000, 150), (0, 80),
        (1000, 150), (0, 450)
    ],

    "High Alert": [
        (1600, 200), (0, 100), (1600, 200), (0, 300)
    ],

    "Low Alert": [
        (350, 350), (0, 150), (350, 350), (0, 400)
    ],

    "Alternating Alarm": [
        (700, 250), (1000, 250),
        (700, 250), (1000, 250)
    ],

    "Emergency Style": [
        (600, 180), (900, 180),
        (600, 180), (900, 180)
    ],

    "Fast Beeper": [
        (1300, 100), (0, 60),
        (1300, 100), (0, 60),
        (1300, 100), (0, 60),
        (1300, 100)
    ],

    "Slow Beeper": [
        (750, 400), (0, 400),
        (750, 400), (0, 400)
    ],

    "Ascending": [
        (400, 150), (500, 150), (600, 150),
        (700, 150), (800, 150), (900, 150),
        (1000, 200)
    ],

    "Descending": [
        (1000, 150), (900, 150), (800, 150),
        (700, 150), (600, 150), (500, 150),
        (400, 200)
    ],

    "Up Down": [
        (500, 150), (700, 150), (900, 150),
        (1100, 150), (900, 150), (700, 150),
        (500, 200)
    ],

    "Doorbell": [
        (784, 300), (659, 600), (0, 300)
    ],

    "Doorbell Double": [
        (784, 250), (659, 450), (0, 150),
        (784, 250), (659, 450)
    ],

    "Chime": [
        (523, 250), (659, 250), (784, 500)
    ],

    "Major Chime": [
        (523, 180), (659, 180),
        (784, 180), (1047, 500)
    ],

    "Gentle Wake": [
        (440, 300), (523, 300),
        (659, 300), (784, 500)
    ],

    "Soft Bell": [
        (660, 350), (0, 150), (880, 500)
    ],

    "Bright Bell": [
        (880, 200), (1100, 200), (1320, 500)
    ],

    "Tiny Bell": [
        (1400, 120), (1700, 250), (0, 200)
    ],

    "Big Bell": [
        (440, 400), (660, 600), (0, 250)
    ],

    "Clock Chime": [
        (659, 250), (523, 250), (392, 600)
    ],

    "Old Clock": [
        (523, 300), (392, 500), (0, 200),
        (523, 300), (392, 500)
    ],

    "Watch Alarm": [
        (2000, 80), (0, 60),
        (2000, 80), (0, 60),
        (2000, 80), (0, 300)
    ],

    "Microwave": [
        (1500, 180), (0, 150),
        (1500, 180), (0, 150),
        (1500, 180)
    ],

    "Oven Timer": [
        (1000, 300), (0, 200),
        (1000, 300), (0, 200),
        (1000, 500)
    ],

    "Kitchen Timer": [
        (1700, 100), (0, 100),
        (1700, 100), (0, 100),
        (1700, 100), (0, 500)
    ],

    "Arcade": [
        (440, 100), (660, 100), (880, 100),
        (1100, 100), (880, 100), (660, 100)
    ],

    "Retro Game": [
        (330, 100), (440, 100), (660, 100),
        (880, 200), (0, 100), (880, 200)
    ],

    "Robot": [
        (300, 100), (900, 100), (350, 100),
        (850, 100), (400, 100), (800, 200)
    ],

    "Sci-Fi": [
        (500, 100), (750, 100), (1000, 100),
        (1250, 100), (1500, 250)
    ],

    "Space Signal": [
        (700, 200), (0, 100), (1100, 100),
        (0, 100), (1400, 250)
    ],

    "Computer Alert": [
        (800, 120), (1200, 120), (1600, 200)
    ],

    "Warning": [
        (450, 250), (850, 250),
        (450, 250), (850, 250)
    ],

    "Urgent Warning": [
        (1000, 100), (1400, 100),
        (1000, 100), (1400, 100),
        (1000, 100), (1400, 100)
    ],

    "Telephone": [
        (440, 300), (480, 300), (0, 500),
        (440, 300), (480, 300)
    ],

    "Happy": [
        (523, 150), (659, 150),
        (784, 150), (1047, 350)
    ],

    "Victory": [
        (523, 150), (659, 150), (784, 150),
        (1047, 200), (1319, 500)
    ],

    "Random Beeps": [
        (500, 100), (1100, 120), (700, 100),
        (1500, 120), (900, 200)
    ],
}


# ============================================================
# AUDIO GENERATION
# ============================================================

SAMPLE_RATE = 44100
TEMP_FILES = {}


def create_alarm_wav(name, notes):
    """Create an alarm WAV file and return its filename."""

    if name in TEMP_FILES and os.path.exists(TEMP_FILES[name]):
        return TEMP_FILES[name]

    safe_name = "".join(
        character if character.isalnum() else "_"
        for character in name
    )

    filename = os.path.join(
        tempfile.gettempdir(),
        "python_timer_" + safe_name + ".wav"
    )

    with wave.open(filename, "w") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(SAMPLE_RATE)

        frames = bytearray()

        for frequency, duration_ms in notes:
            samples = int(
                SAMPLE_RATE * duration_ms / 1000
            )

            for sample_number in range(samples):
                if frequency == 0:
                    value = 0

                else:
                    time_position = sample_number / SAMPLE_RATE

                    # Apply a short fade to prevent clicking sounds.
                    fade_samples = min(
                        int(SAMPLE_RATE * 0.01),
                        samples // 2
                    )

                    envelope = 1.0

                    if sample_number < fade_samples:
                        envelope = (
                            sample_number
                            / max(1, fade_samples)
                        )

                    elif sample_number > samples - fade_samples:
                        envelope = (
                            samples - sample_number
                        ) / max(1, fade_samples)

                    value = int(
                        15000
                        * envelope
                        * math.sin(
                            2
                            * math.pi
                            * frequency
                            * time_position
                        )
                    )

                frames.extend(
                    struct.pack("<h", value)
                )

        wav_file.writeframes(frames)

    TEMP_FILES[name] = filename
    return filename


def play_alarm(name, loop=False):
    """Play an alarm once or continuously."""

    if not HAS_WINSOUND:
        root.bell()
        return

    try:
        filename = create_alarm_wav(
            name,
            ALARMS[name]
        )

        flags = (
            winsound.SND_FILENAME
            | winsound.SND_ASYNC
        )

        if loop:
            flags |= winsound.SND_LOOP

        winsound.PlaySound(
            filename,
            flags
        )

    except Exception:
        root.bell()


def stop_alarm():
    """Stop any currently playing alarm."""

    if HAS_WINSOUND:
        try:
            winsound.PlaySound(None, 0)
        except Exception:
            pass


# ============================================================
# TIMER STATE
# ============================================================

remaining_seconds = 0
running = False
paused = False
timer_job = None


def get_selected_seconds():
    """Return the time entered in the controls as seconds."""

    try:
        hours = int(hours_var.get())
        minutes = int(minutes_var.get())
        seconds = int(seconds_var.get())

        hours = max(0, hours)
        minutes = max(0, minutes)
        seconds = max(0, seconds)

        return (
            hours * 3600
            + minutes * 60
            + seconds
        )

    except ValueError:
        return 0


def format_time(seconds):
    """Convert seconds to HH:MM:SS."""

    seconds = max(0, int(seconds))

    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60

    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def update_display():
    """Update the large timer display."""

    time_label.config(
        text=format_time(remaining_seconds)
    )


def start_timer():
    """Start the timer or resume it if paused."""

    global remaining_seconds
    global running
    global paused

    stop_alarm()

    if running and paused:
        paused = False

        status_var.set("Running")
        pause_button.config(text="Pause")

        tick()
        return

    if running:
        return

    remaining_seconds = get_selected_seconds()

    if remaining_seconds <= 0:
        status_var.set("Set a time first")
        return

    running = True
    paused = False

    status_var.set("Running")
    pause_button.config(text="Pause")

    update_display()
    tick()


def tick():
    """Advance the timer by one second."""

    global remaining_seconds
    global running
    global timer_job

    if not running or paused:
        return

    update_display()

    if remaining_seconds <= 0:
        running = False
        timer_job = None

        status_var.set("TIME'S UP!")

        selected_alarm = alarm_var.get()

        threading.Thread(
            target=play_alarm,
            args=(selected_alarm, True),
            daemon=True
        ).start()

        return

    remaining_seconds -= 1

    timer_job = root.after(
        1000,
        tick
    )


def pause_timer():
    """Pause or resume the active timer."""

    global paused

    if not running:
        return

    paused = not paused

    if paused:
        status_var.set("Paused")
        pause_button.config(text="Resume")

    else:
        status_var.set("Running")
        pause_button.config(text="Pause")
        tick()


def reset_timer():
    """Stop the timer and reset it to the entered time."""

    global remaining_seconds
    global running
    global paused
    global timer_job

    if timer_job is not None:
        root.after_cancel(timer_job)
        timer_job = None

    running = False
    paused = False

    stop_alarm()

    remaining_seconds = get_selected_seconds()

    update_display()

    status_var.set("Ready")
    pause_button.config(text="Pause")


def stop_button_pressed():
    """Stop the timer and alarm."""

    global running
    global paused
    global timer_job

    if timer_job is not None:
        root.after_cancel(timer_job)
        timer_job = None

    running = False
    paused = False

    stop_alarm()

    status_var.set("Stopped")
    pause_button.config(text="Pause")


def preview_alarm():
    """Play the selected alarm once."""

    stop_alarm()

    selected_alarm = alarm_var.get()

    threading.Thread(
        target=play_alarm,
        args=(selected_alarm, False),
        daemon=True
    ).start()


def random_alarm():
    """Select and preview a random alarm."""

    alarm_var.set(
        random.choice(list(ALARMS.keys()))
    )

    preview_alarm()


def set_quick_timer(seconds):
    """Set the timer using a quick-time button."""

    global remaining_seconds

    stop_button_pressed()

    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    remaining = seconds % 60

    hours_var.set(str(hours))
    minutes_var.set(str(minutes))
    seconds_var.set(str(remaining))

    remaining_seconds = seconds

    update_display()

    status_var.set("Ready")


# ============================================================
# GUI
# ============================================================

root = tk.Tk()

root.title("Timer - Huge Alarm Selection")

# Open as a normal window rather than maximized or full screen.
root.geometry("700x800")
root.minsize(600, 720)

main = ttk.Frame(
    root,
    padding=12
)

main.pack(
    fill="both",
    expand=True
)


# ------------------------------------------------------------
# Title
# ------------------------------------------------------------

title = ttk.Label(
    main,
    text="TIMER",
    font=("Segoe UI", 24, "bold")
)

title.pack(
    pady=(0, 6)
)


subtitle = ttk.Label(
    main,
    text=f"{len(ALARMS)} built-in alarm sounds",
    font=("Segoe UI", 10)
)

subtitle.pack(
    pady=(0, 8)
)


# ------------------------------------------------------------
# Large timer display
# ------------------------------------------------------------

time_label = ttk.Label(
    main,
    text="00:01:00",
    font=("Consolas", 44, "bold")
)

time_label.pack(
    pady=8
)


status_var = tk.StringVar(
    value="Ready"
)

status_label = ttk.Label(
    main,
    textvariable=status_var,
    font=("Segoe UI", 12)
)

status_label.pack(
    pady=(0, 10)
)


# ------------------------------------------------------------
# Time settings
# ------------------------------------------------------------

time_frame = ttk.LabelFrame(
    main,
    text="Set Timer",
    padding=10
)

time_frame.pack(
    fill="x",
    pady=5
)


hours_var = tk.StringVar(value="0")
minutes_var = tk.StringVar(value="1")
seconds_var = tk.StringVar(value="0")


def make_time_control(
    parent,
    column,
    label,
    variable,
    maximum
):
    frame = ttk.Frame(parent)

    frame.grid(
        row=0,
        column=column,
        padx=10
    )

    ttk.Label(
        frame,
        text=label
    ).pack()

    spinbox = ttk.Spinbox(
        frame,
        from_=0,
        to=maximum,
        textvariable=variable,
        width=6,
        justify="center",
        font=("Segoe UI", 13)
    )

    spinbox.pack(
        pady=5
    )


make_time_control(
    time_frame,
    0,
    "Hours",
    hours_var,
    99
)

make_time_control(
    time_frame,
    1,
    "Minutes",
    minutes_var,
    59
)

make_time_control(
    time_frame,
    2,
    "Seconds",
    seconds_var,
    59
)


for column in range(3):
    time_frame.columnconfigure(
        column,
        weight=1
    )


# ------------------------------------------------------------
# Alarm selection
# ------------------------------------------------------------

alarm_frame = ttk.LabelFrame(
    main,
    text="Alarm Sound",
    padding=10
)

alarm_frame.pack(
    fill="x",
    pady=10
)


alarm_var = tk.StringVar(
    value="Classic Alarm"
)

alarm_box = ttk.Combobox(
    alarm_frame,
    textvariable=alarm_var,
    values=list(ALARMS.keys()),
    state="readonly",
    font=("Segoe UI", 11)
)

alarm_box.pack(
    fill="x",
    pady=(0, 8)
)


alarm_buttons = ttk.Frame(
    alarm_frame
)

alarm_buttons.pack()


ttk.Button(
    alarm_buttons,
    text="Preview Alarm",
    command=preview_alarm
).pack(
    side="left",
    padx=5
)


ttk.Button(
    alarm_buttons,
    text="Stop Sound",
    command=stop_alarm
).pack(
    side="left",
    padx=5
)


ttk.Button(
    alarm_buttons,
    text="Random Alarm",
    command=random_alarm
).pack(
    side="left",
    padx=5
)


# ------------------------------------------------------------
# Main timer controls
# ------------------------------------------------------------

button_frame = ttk.Frame(
    main
)

button_frame.pack(
    pady=10
)


ttk.Button(
    button_frame,
    text="START",
    command=start_timer,
    width=12
).grid(
    row=0,
    column=0,
    padx=5,
    pady=5
)


pause_button = ttk.Button(
    button_frame,
    text="Pause",
    command=pause_timer,
    width=12
)

pause_button.grid(
    row=0,
    column=1,
    padx=5,
    pady=5
)


ttk.Button(
    button_frame,
    text="Reset",
    command=reset_timer,
    width=12
).grid(
    row=1,
    column=0,
    padx=5,
    pady=5
)


ttk.Button(
    button_frame,
    text="STOP",
    command=stop_button_pressed,
    width=12
).grid(
    row=1,
    column=1,
    padx=5,
    pady=5
)


# ------------------------------------------------------------
# Quick timer controls
# ------------------------------------------------------------

quick_frame = ttk.LabelFrame(
    main,
    text="Quick Timers",
    padding=10
)

quick_frame.pack(
    fill="x",
    pady=5
)


quick_times = [
    ("30 sec", 30),
    ("1 min", 60),
    ("5 min", 300),
    ("10 min", 600),
    ("15 min", 900),
    ("30 min", 1800),
]


for index, (button_text, seconds) in enumerate(quick_times):
    ttk.Button(
        quick_frame,
        text=button_text,
        command=lambda value=seconds: set_quick_timer(value)
    ).grid(
        row=index // 3,
        column=index % 3,
        padx=4,
        pady=4,
        sticky="ew"
    )


for column in range(3):
    quick_frame.columnconfigure(
        column,
        weight=1
    )


# ============================================================
# INITIALIZE DISPLAY
# ============================================================

remaining_seconds = get_selected_seconds()
update_display()


# ============================================================
# CLOSE PROGRAM
# ============================================================

def on_close():
    """Stop the alarm and close the program safely."""

    stop_alarm()

    try:
        if timer_job is not None:
            root.after_cancel(timer_job)

    except Exception:
        pass

    root.destroy()


root.protocol(
    "WM_DELETE_WINDOW",
    on_close
)

root.mainloop()
