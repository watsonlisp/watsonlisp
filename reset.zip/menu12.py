import base64
import random
import shutil
import subprocess
import sys


foods = """
Classic Cheeseburger
Bacon Cheeseburger
Mushroom Swiss Burger
BBQ Burger
Jalapeno Burger
Black Bean Burger
Turkey Burger
Veggie Burger
Chicken Sandwich
Spicy Chicken Sandwich
Grilled Chicken Sandwich
Buffalo Chicken Sandwich
Fried Fish Sandwich
Pulled Pork Sandwich
Philly Cheesesteak
French Dip Sandwich
Reuben Sandwich
Cuban Sandwich
Club Sandwich
BLT Sandwich
Turkey and Swiss Sandwich
Ham and Cheddar Sandwich
Roast Beef Sandwich
Tuna Salad Sandwich
Chicken Salad Sandwich
Egg Salad Sandwich
Grilled Cheese Sandwich
Tomato and Mozzarella Sandwich
Meatball Sub
Italian Sub
Chicken Parmesan Sub
Sausage and Pepper Sub
Lobster Roll
Shrimp Po' Boy
Falafel Pita
Gyro
Chicken Shawarma Wrap
Turkey Wrap
Chicken Caesar Wrap
Buffalo Chicken Wrap
Cheese Pizza
Pepperoni Pizza
Sausage Pizza
Mushroom Pizza
Hawaiian Pizza
Supreme Pizza
Meat Lovers Pizza
Vegetable Pizza
Buffalo Chicken Pizza
BBQ Chicken Pizza
Margherita Pizza
White Pizza
Four Cheese Pizza
Bacon and Onion Pizza
Spinach and Feta Pizza
Pesto Chicken Pizza
Taco Pizza
Sicilian Pizza
Calzone
Stromboli
Cheese Flatbread
Mediterranean Flatbread
Beef Taco
Chicken Taco
Fish Taco
Shrimp Taco
Pork Carnitas Taco
Black Bean Taco
Loaded Nachos
Chicken Nachos
Cheese Quesadilla
Chicken Quesadilla
Steak Quesadilla
Vegetable Quesadilla
Beef Burrito
Chicken Burrito
Bean and Cheese Burrito
Breakfast Burrito
Burrito Bowl
Chicken Enchiladas
Cheese Enchiladas
Beef Enchiladas
Chicken Fajitas
Steak Fajitas
Vegetable Fajitas
Tamales
Chimichanga
Taco Salad
Southwestern Rice Bowl
Spaghetti and Meatballs
Spaghetti Bolognese
Fettuccine Alfredo
Chicken Alfredo
Shrimp Alfredo
Penne Arrabbiata
Penne Vodka
Baked Ziti
Beef Lasagna
Vegetable Lasagna
Cheese Ravioli
Lobster Ravioli
Spinach Ravioli
Tortellini Alfredo
Chicken Parmesan
Eggplant Parmesan
Veal Parmesan
Chicken Marsala
Chicken Piccata
Sausage and Peppers
Gnocchi with Tomato Sauce
Pesto Pasta
Macaroni and Cheese
Bacon Macaroni and Cheese
Lobster Macaroni and Cheese
Stuffed Shells
Pasta Primavera
Chicken Fried Rice
Pork Fried Rice
Shrimp Fried Rice
Vegetable Fried Rice
Chicken Lo Mein
Beef Lo Mein
Shrimp Lo Mein
Vegetable Lo Mein
Sweet and Sour Chicken
Orange Chicken
General Tso's Chicken
Sesame Chicken
Kung Pao Chicken
Teriyaki Chicken
Teriyaki Beef
Beef and Broccoli
Mongolian Beef
Pepper Steak
Chicken Stir-Fry
Vegetable Stir-Fry
Pad Thai
Drunken Noodles
Thai Green Curry
Thai Red Curry
Chicken Satay
Ramen Bowl
Udon Noodle Bowl
Pho
Bibimbap
Korean Beef Bowl
Sushi Platter
California Roll
Spicy Tuna Roll
Salmon Avocado Roll
Vegetable Sushi Roll
Grilled Ribeye Steak
New York Strip Steak
Filet Mignon
Sirloin Steak
Steak Tips
BBQ Ribs
Baby Back Ribs
Beef Brisket
Meatloaf
Roast Beef Dinner
Pot Roast
Grilled Pork Chops
Breaded Pork Chops
Pulled Pork Plate
Roasted Turkey Dinner
Grilled Chicken Breast
Fried Chicken
Buttermilk Fried Chicken
Chicken Tenders
Buffalo Chicken Tenders
Chicken and Waffles
Chicken Pot Pie
Shepherd's Pie
Beef Stew
Grilled Salmon
Baked Haddock
Fried Cod
Fish and Chips
Coconut Shrimp
Fried Shrimp
Grilled Shrimp Skewers
Crab Cakes
Lobster Dinner
Seafood Platter
Clam Strip Plate
Chicken Noodle Soup
Tomato Soup
French Onion Soup
Clam Chowder
Broccoli Cheddar Soup
Vegetable Soup
Minestrone Soup
Beef Barley Soup
Potato Soup
Chili
White Chicken Chili
Caesar Salad
Chicken Caesar Salad
Garden Salad
Greek Salad
Cobb Salad
Chef Salad
Spinach Salad
Harvest Salad
Grilled Salmon Salad
Mediterranean Salad
Caprese Salad
Pancake Stack
Blueberry Pancakes
Chocolate Chip Pancakes
Belgian Waffle
French Toast
Cinnamon French Toast
Eggs and Bacon
Eggs and Sausage
Steak and Eggs
Cheese Omelet
Western Omelet
Vegetable Omelet
Ham and Cheese Omelet
Breakfast Sandwich
Biscuits and Gravy
Corned Beef Hash
Avocado Toast
Bagel with Cream Cheese
""".strip().splitlines()


drinks = """
Cola
Diet Cola
Cherry Cola
Vanilla Cola
Lime Cola
Root Beer
Cream Soda
Orange Soda
Grape Soda
Lemon-Lime Soda
Ginger Ale
Ginger Beer
Black Cherry Soda
Strawberry Soda
Pineapple Soda
Birch Beer
Classic Lemonade
Pink Lemonade
Strawberry Lemonade
Raspberry Lemonade
Blueberry Lemonade
Peach Lemonade
Watermelon Lemonade
Mango Lemonade
Cherry Limeade
Fresh Limeade
Fruit Punch
Tropical Punch
Cranberry Juice
Orange Juice
Apple Juice
Grape Juice
Pineapple Juice
Grapefruit Juice
Tomato Juice
Mango Juice
Guava Juice
Watermelon Juice
Iced Tea
Sweet Tea
Unsweetened Iced Tea
Peach Iced Tea
Raspberry Iced Tea
Lemon Iced Tea
Green Iced Tea
Black Tea
Green Tea
Earl Grey Tea
English Breakfast Tea
Chamomile Tea
Peppermint Tea
Ginger Tea
Chai Tea
Chai Latte
Matcha Latte
Hot Coffee
Decaf Coffee
Iced Coffee
Cold Brew Coffee
Vanilla Iced Coffee
Caramel Iced Coffee
Mocha Iced Coffee
Espresso
Double Espresso
Americano
Cappuccino
Cafe Latte
Vanilla Latte
Caramel Latte
Hazelnut Latte
Cafe Mocha
White Chocolate Mocha
Hot Chocolate
Peppermint Hot Chocolate
Salted Caramel Hot Chocolate
Vanilla Milkshake
Chocolate Milkshake
Strawberry Milkshake
Banana Milkshake
Peanut Butter Milkshake
Cookies and Cream Milkshake
Mint Chocolate Milkshake
Salted Caramel Milkshake
Coffee Milkshake
Blueberry Milkshake
Cherry Milkshake
Chocolate Banana Milkshake
Strawberry Smoothie
Banana Smoothie
Mango Smoothie
Berry Smoothie
Peach Smoothie
Pineapple Smoothie
Green Smoothie
Tropical Smoothie
Strawberry Banana Smoothie
Peanut Butter Banana Smoothie
Ice Water
Bottled Water
Mineral Water
Sparkling Water
Lemon Sparkling Water
Lime Sparkling Water
Berry Sparkling Water
Orange Sparkling Water
Coconut Water
Cucumber Water
Lemon Water
Mint Water
Arnold Palmer
Strawberry Fizz
Raspberry Fizz
Orange Cream Fizz
Pineapple Cooler
Mango Cooler
Watermelon Cooler
Cucumber Lime Cooler
Mint Lime Cooler
Frozen Lemonade
Frozen Strawberry Lemonade
Frozen Hot Chocolate
Chocolate Milk
Strawberry Milk
Vanilla Milk
Oat Milk
Almond Milk
""".strip().splitlines()


desserts = """
Chocolate Cake
Vanilla Cake
Yellow Cake
Red Velvet Cake
Carrot Cake
Coconut Cake
Lemon Cake
Strawberry Cake
Marble Cake
Black Forest Cake
German Chocolate Cake
Pineapple Upside-Down Cake
Angel Food Cake
Funfetti Cake
Chocolate Lava Cake
Molten Caramel Cake
Birthday Cake
Coffee Cake
Classic Cheesecake
Strawberry Cheesecake
Blueberry Cheesecake
Cherry Cheesecake
Chocolate Cheesecake
Caramel Cheesecake
Pumpkin Cheesecake
Lemon Cheesecake
Cookies and Cream Cheesecake
Chocolate Chip Cheesecake
Peanut Butter Cheesecake
Raspberry Swirl Cheesecake
Apple Pie
Blueberry Pie
Cherry Pie
Peach Pie
Pumpkin Pie
Pecan Pie
Key Lime Pie
Lemon Meringue Pie
Chocolate Cream Pie
Banana Cream Pie
Coconut Cream Pie
Strawberry Rhubarb Pie
Mixed Berry Pie
Apple Crumble
Peach Cobbler
Blueberry Cobbler
Cherry Cobbler
Blackberry Cobbler
Vanilla Ice Cream
Chocolate Ice Cream
Strawberry Ice Cream
Mint Chocolate Chip Ice Cream
Cookies and Cream Ice Cream
Butter Pecan Ice Cream
Rocky Road Ice Cream
Chocolate Chip Ice Cream
Coffee Ice Cream
Cookie Dough Ice Cream
Salted Caramel Ice Cream
Pistachio Ice Cream
Cherry Ice Cream
Peach Ice Cream
Neapolitan Ice Cream
Hot Fudge Sundae
Caramel Sundae
Strawberry Sundae
Banana Split
Brownie Sundae
Ice Cream Sandwich
Chocolate-Dipped Ice Cream Bar
Chocolate Chip Cookie
Sugar Cookie
Oatmeal Raisin Cookie
Peanut Butter Cookie
Snickerdoodle Cookie
Double Chocolate Cookie
White Chocolate Cookie
Macadamia Nut Cookie
Gingerbread Cookie
Shortbread Cookie
Candy-Coated Chocolate Cookie
Chocolate Brownie
Fudge Brownie
Walnut Brownie
Caramel Brownie
Peanut Butter Brownie
Blondie
Chocolate Chip Blondie
Glazed Donut
Chocolate Donut
Jelly Donut
Boston Cream Donut
Powdered Donut
Cinnamon Sugar Donut
Apple Fritter
Cinnamon Roll
Sticky Bun
Blueberry Muffin
Chocolate Chip Muffin
Banana Nut Muffin
Lemon Poppy Seed Muffin
Apple Turnover
Cherry Turnover
Blueberry Turnover
Chocolate Croissant
Almond Croissant
Cream Puff
Chocolate Eclair
Fruit Danish
Cheese Danish
Chocolate Pudding
Vanilla Pudding
Banana Pudding
Butterscotch Pudding
Rice Pudding
Bread Pudding
Tapioca Pudding
Chocolate Mousse
Lemon Mousse
Strawberry Mousse
Tiramisu
Creme Brulee
Flan
Panna Cotta
Chocolate Parfait
Berry Parfait
Banana Parfait
Chocolate Fudge
Peanut Butter Fudge
Rocky Road Fudge
Chocolate Truffles
Chocolate-Covered Strawberries
Chocolate-Covered Pretzels
Caramel Apple
Candied Pecans
Peanut Brittle
Rice Crispy Treat
S'mores
Marshmallow Bar
""".strip().splitlines()


extras = """
French Fries
Seasoned Fries
Curly Fries
Waffle Fries
Steak Fries
Shoestring Fries
Sweet Potato Fries
Garlic Parmesan Fries
Cheese Fries
Chili Cheese Fries
Bacon Cheese Fries
Loaded Fries
Tater Tots
Loaded Tater Tots
Hash Browns
Home Fries
Potato Wedges
Mashed Potatoes
Garlic Mashed Potatoes
Loaded Mashed Potatoes
Baked Potato
Loaded Baked Potato
Scalloped Potatoes
Potato Salad
Potato Pancakes
Onion Rings
Beer-Battered Onion Rings
Mozzarella Sticks
Fried Pickles
Fried Mushrooms
Fried Zucchini
Jalapeno Poppers
Fried Green Tomatoes
Hush Puppies
Corn Fritters
Macaroni and Cheese Bites
Cheese Curds
Popcorn Chicken
Mini Corn Dogs
Chicken Nuggets
Breaded Ravioli
Coconut Shrimp
Spring Rolls
Egg Rolls
Crab Rangoon
Garlic Bread
Cheesy Garlic Bread
Breadsticks
Dinner Roll
Cornbread
Buttermilk Biscuit
Cheddar Biscuit
Soft Pretzel
Pretzel Bites
Pita Bread
Naan Bread
Texas Toast
Focaccia Bread
Cinnamon Bread
Steamed Broccoli
Cheesy Broccoli
Roasted Broccoli
Steamed Carrots
Glazed Carrots
Green Beans
Garlic Green Beans
Corn on the Cob
Buttered Corn
Creamed Corn
Roasted Brussels Sprouts
Grilled Asparagus
Sauteed Spinach
Mixed Vegetables
Roasted Vegetables
Grilled Zucchini
Sauteed Mushrooms
Peas and Carrots
Sweet Potato Casserole
Green Bean Casserole
Garden Salad
Caesar Salad
Greek Salad
Side Spinach Salad
Coleslaw
Macaroni Salad
Pasta Salad
Cucumber Salad
Tomato Salad
Three-Bean Salad
Fruit Salad
Watermelon Slices
Apple Slices
Mixed Berries
Pickle Spears
White Rice
Brown Rice
Yellow Rice
Wild Rice
Rice Pilaf
Cilantro Lime Rice
Spanish Rice
Fried Rice
Black Beans
Baked Beans
Refried Beans
Pinto Beans
Red Beans and Rice
Quinoa
Couscous
Chips and Salsa
Chips and Guacamole
Chips and Queso
Nachos
Loaded Nachos
Spinach Artichoke Dip
Buffalo Chicken Dip
Hummus and Pita
Seven-Layer Dip
Salsa Sampler
Cheese Plate
Garlic Knots
Stuffed Mushrooms
Deviled Eggs
Mini Meatballs
Chicken Wings
Buffalo Wings
BBQ Wings
Garlic Parmesan Wings
Macaroni and Cheese
Bacon Macaroni and Cheese
Creamy Polenta
Stuffing
Cornbread Stuffing
Biscuits and Gravy
Creamed Spinach
Applesauce
Cranberry Sauce
Cup of Chili
Cup of Tomato Soup
Cup of Clam Chowder
""".strip().splitlines()


def speak(text):
    """Speak text using Windows' built-in TTS without external packages."""
    if sys.platform != "win32":
        print("TTS is only available when this program is run on Windows.")
        return False

    powershell = (
        shutil.which("powershell.exe")
        or shutil.which("powershell")
    )

    if powershell is None:
        print("TTS error: Windows PowerShell was not found.")
        return False

    # Encode the speech separately so punctuation and apostrophes are safe.
    speech_data = base64.b64encode(
        str(text).encode("utf-8")
    ).decode("ascii")

    powershell_script = f"""
$text = [System.Text.Encoding]::UTF8.GetString(
    [System.Convert]::FromBase64String('{speech_data}')
)
Add-Type -AssemblyName System.Speech
$voice = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {{
    $voice.Volume = 100
    $voice.Rate = 0
    $voice.Speak($text)
}}
finally {{
    $voice.Dispose()
}}
"""

    # PowerShell expects an encoded command to use UTF-16 little-endian.
    encoded_script = base64.b64encode(
        powershell_script.encode("utf-16le")
    ).decode("ascii")

    try:
        result = subprocess.run(
            [
                powershell,
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-EncodedCommand",
                encoded_script,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=subprocess.CREATE_NO_WINDOW,
            check=False,
        )

    except OSError as error:
        print(f"TTS error: {error}")
        return False

    if result.returncode != 0:
        details = (
            result.stderr
            or "Unknown Windows PowerShell error."
        ).strip()

        print(f"TTS error: {details}")
        return False

    return True


def generate_menu(menu_number, tts_enabled):
    """Generate a menu and speak it when TTS is enabled."""
    main_food = random.choice(foods)
    extra = random.choice(extras)
    drink = random.choice(drinks)
    dessert = random.choice(desserts)

    print("\n" + "=" * 56)
    print(f"                    RANDOM MENU #{menu_number}")
    print("=" * 56)
    print(f"MAIN FOOD : {main_food}")
    print(f"EXTRA     : {extra}")
    print(f"DRINK     : {drink}")
    print(f"DESSERT   : {dessert}")
    print("=" * 56)

    if tts_enabled:
        menu_speech = (
            f"Random menu number {menu_number}. "
            f"Main food: {main_food}. "
            f"Extra: {extra}. "
            f"Drink: {drink}. "
            f"Dessert: {dessert}."
        )

        speak(menu_speech)


def ask_next_action(tts_enabled):
    """Return repeat, toggle, or quit based on the user's command."""
    while True:
        tts_state = "ON" if tts_enabled else "OFF"

        print("\nPress Enter or type R to generate another menu.")
        print(
            f"Type T to toggle TTS. "
            f"TTS is currently {tts_state}."
        )
        print("Type Q to quit.")

        choice = input("\nCommand: ").strip().lower()

        if choice in (
            "",
            "r",
            "repeat",
            "again",
            "yes",
            "y",
        ):
            return "repeat"

        if choice in (
            "t",
            "tts",
            "toggle",
        ):
            return "toggle"

        if choice in (
            "q",
            "quit",
            "exit",
            "no",
            "n",
        ):
            return "quit"

        print("\nThat command was not recognized.")
        print(
            "Press Enter or R to repeat, "
            "T to toggle TTS, or Q to quit."
        )


def main():
    """Run the Giant Random Menu Generator."""
    menu_number = 1
    tts_enabled = True

    print("=" * 56)
    print("             GIANT RANDOM MENU GENERATOR")
    print("=" * 56)
    print("A random main food, extra, drink, and dessert")
    print("will be selected for every menu.")
    print("TTS starts ON.")
    print("Type T at the command prompt to toggle TTS.")

    while True:
        generate_menu(menu_number, tts_enabled)

        while True:
            action = ask_next_action(tts_enabled)

            if action == "toggle":
                tts_enabled = not tts_enabled
                tts_state = "ON" if tts_enabled else "OFF"

                print(f"\nTTS is now {tts_state}.")
                continue

            break

        if action == "quit":
            break

        menu_number += 1

    print("\n" + "=" * 56)
    print(f"You generated {menu_number} random menu(s).")
    print("Thanks for using the Giant Random Menu Generator!")
    print("=" * 56)

    input("\nPress Enter to close the program...")


if __name__ == "__main__":
    main()
