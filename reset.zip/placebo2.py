import base64
import random
import subprocess


TTS_ENABLED = True
TTS_RATE = 0
TTS_VOLUME = 100


INTRO = """
==================================================
                    PLACEBO
==================================================

Welcome to Placebo.

Placebo creates completely imaginary effects
based on random everyday objects.

This program is for entertainment, humor,
creativity, and curiosity.

It is NOT medical advice.
It is NOT psychological advice.
It is NOT a diagnosis.

Press Enter and let imaginary science
reveal your destiny.
"""


OBJECTS = [
    "lucky rabbit's foot",
    "fridge magnet",
    "old coin",
    "rubber duck",
    "coffee mug",
    "paperclip",
    "pocket rock",
    "keychain",
    "sock",
    "flashlight",
    "baseball cap",
    "button",
    "bookmark",
    "plastic dinosaur",
    "dice",
    "broken wristwatch",
    "glow stick",
    "garden gnome",
    "toy spaceship",
    "snow globe",
    "feather",
    "marble",
    "yo-yo",
    "sticky note",
    "deck of cards",
    "flash drive",
    "pencil stub",
    "eraser",
    "compass",
    "seashell",
    "empty bottle",
    "tiny spoon",
    "guitar pick",
    "bouncy ball",
    "plastic monkey",
    "slinky",
    "toy train",
    "pine cone",
    "acorn",
    "old photograph",
    "mystery key",
    "silver bell",
    "Lego brick",
    "toy robot",
    "pirate coin",
    "crystal marble",
    "miniature cactus",
    "zip tie",
    "rubber band",
    "cassette tape",
    "CD-R",
    "TV remote",
    "calculator",
    "magnifying glass",
    "empty envelope",
    "fortune cookie slip",
    "ticket stub",
    "tiny notebook",
    "model airplane",
    "puzzle piece",
    "plastic sword",
    "toy knight",
    "moon-shaped charm",
    "star sticker",
    "safety pin",
    "copper wire",
    "fake gold nugget",
    "tiny treasure chest",
    "plastic dragon",
    "clock gear",
    "electronic resistor",
    "cracked coaster",
    "neon shoelace",
    "mini flashlight",
    "old map",
    "origami crane",
    "plastic flamingo",
    "toy submarine",
    "wizard hat",
    "rainbow magnet",
    "mystery button",
    "golden paperclip",
    "ancient-looking pebble",
    "lopsided bowling pin",
    "emergency banana",
    "suspicious cucumber",
    "cosmic waffle",
    "gravity-defying spoon",
    "quantum donut",
    "invisible stapler",
    "tiny disco ball",
    "wooden nickel",
    "wind-up frog",
    "plastic compass",
    "toy telescope",
    "empty matchbox",
    "glittery bottle cap",
    "miniature traffic cone",
    "old chess piece",
    "mysterious shoelace",
    "cracked domino",
    "ceramic owl",
    "toy race car",
    "lucky washer",
    "painted seashell",
    "plastic gemstone",
    "folded napkin",
    "tiny rubber chicken",
    "forgotten grocery receipt",
    "wooden spoon",
    "mechanical pencil",
    "toy monster",
    "bottle opener",
    "mismatched glove",
    "tiny hourglass",
    "fake mustache",
    "plastic medal",
    "cardboard crown",
    "wind-up robot",
    "lucky poker chip",
    "miniature globe",
    "toy satellite",
    "wooden puzzle cube",
    "tiny umbrella",
    "silent kazoo",
    "mysterious cassette",
    "ceremonial spatula",
    "legendary bottle cap",
    "enchanted clothespin",
    "interdimensional bookmark",
    "cosmic refrigerator magnet",
    "philosophical paperweight",
    "experimental teabag",
    "unlicensed magic wand",
    "officially unofficial badge",
    "time-traveling thimble",
    "overqualified paperclip",
    "mildly enchanted pebble",
    "psychic coat hanger",
    "telepathic teaspoon",
    "inspirational potato",
    "dramatic pancake",
    "emotionally supportive stapler"
]


EFFECTS = [
    "increases confidence by 3 percent",
    "improves creativity by 7 percent",
    "attracts unusual coincidences",
    "encourages clever ideas",
    "creates mysterious optimism",
    "slightly boosts motivation",
    "improves luck with parking spaces",
    "enhances dramatic storytelling",
    "increases the chance of finding missing socks",
    "generates random inspiration",
    "attracts friendly conversations",
    "increases confidence during awkward silences",
    "temporarily improves snack selection",
    "encourages productive procrastination",
    "summons excellent timing",
    "improves daydream quality",
    "enhances joke appreciation",
    "strengthens positive vibes",
    "encourages interesting detours",
    "attracts fascinating trivia",
    "slightly bends coincidence in your favor",
    "improves the quality of spontaneous ideas",
    "increases the probability of a lucky break",
    "generates mysterious determination",
    "encourages adventurous thinking",
    "improves optimistic forecasting",
    "enhances enthusiasm",
    "reduces boring moments",
    "makes coffee taste 1 percent better",
    "improves treasure-hunting instincts",
    "attracts curious opportunities",
    "increases imagination levels",
    "promotes heroic feelings",
    "enhances creativity during boring meetings",
    "causes unexpected laughter",
    "increases appreciation of strange facts",
    "encourages excellent storytelling",
    "improves luck with vending machines",
    "attracts quality memes",
    "makes ordinary events seem slightly magical",
    "encourages legendary optimism",
    "improves luck with guessing games",
    "attracts improbable victories",
    "expands curiosity",
    "inspires harmless mischief",
    "improves the odds of discovering cool things",
    "enhances mysteriousness",
    "increases fictional wizard power",
    "attracts good vibes from houseplants",
    "provides temporary cosmic swagger",
    "improves dramatic entrances",
    "improves dramatic exits",
    "summons the spirit of adventure",
    "creates a field of mild awesomeness",
    "increases scientific-sounding confidence",
    "encourages impossible optimism",
    "enhances imagination velocity",
    "improves perception of cool clouds",
    "creates an aura of curious nonsense",
    "increases quantum waffle alignment",
    "improves your ability to choose the fastest checkout line",
    "encourages unusually accurate guesses",
    "adds confidence to completely untested theories",
    "improves your ability to remember why you entered a room",
    "causes household objects to seem more cooperative",
    "increases resistance to boring conversations",
    "improves appreciation of dramatic weather",
    "attracts conveniently timed green lights",
    "enhances your imaginary detective skills",
    "slightly improves refrigerator navigation",
    "creates temporary mastery of useless trivia",
    "encourages unnecessary but impressive gestures",
    "improves your ability to locate comfortable chairs",
    "makes leftovers seem more exciting",
    "generates a mild aura of authority",
    "temporarily increases puzzle-solving swagger",
    "improves your ability to name imaginary planets",
    "increases the entertainment value of waiting rooms",
    "makes ordinary pens feel historically important",
    "encourages conversations with friendly appliances",
    "slightly improves your chances in imaginary competitions",
    "generates confidence around mysterious buttons",
    "attracts exceptionally cooperative elevators",
    "improves your ability to notice oddly shaped clouds",
    "enhances enthusiasm for completely unnecessary projects",
    "makes simple discoveries feel scientifically significant",
    "creates a temporary shield against dullness",
    "improves your ability to invent impressive titles",
    "causes random objects to seem lucky",
    "increases the chance of remembering a forgotten joke",
    "adds dramatic importance to routine decisions",
    "improves fictional time-travel accuracy",
    "encourages respectful negotiations with household objects",
    "temporarily activates advanced sandwich intuition",
    "improves your ability to detect suspicious coincidences",
    "creates an invisible cloud of optimism",
    "enhances your imaginary laboratory credentials",
    "increases the probability of harmless adventure",
    "boosts morale among nearby paperclips",
    "improves diplomatic relations with garden gnomes",
    "aligns nearby waffles with the cosmos",
    "makes your next idea sound 12 percent more official",
    "temporarily unlocks expert-level nonsense",
    "improves the emotional stability of nearby staplers",
    "creates the impression that everything is going according to plan"
]


EXPLANATIONS = [
    "Scientists remain completely baffled.",
    "The evidence is entirely imaginary.",
    "Several squirrels approved this finding.",
    "Garden gnomes strongly agree.",
    "Nobody knows why this works.",
    "Your brain probably deserves the credit.",
    "Further research was postponed until after lunch.",
    "The data escaped.",
    "Experts looked concerned but intrigued.",
    "The placebo effect is taking a victory lap.",
    "Results may vary wildly.",
    "A committee of ducks was consulted.",
    "Peer review ended in laughter.",
    "The universe declined to comment.",
    "This theory was discovered accidentally.",
    "The calculations were performed on a napkin.",
    "Nobody can reproduce the results yet.",
    "A wizard may be involved.",
    "Three raccoons supported the project.",
    "Confidence levels are suspiciously high.",
    "Additional testing is probably unnecessary.",
    "The findings were approved by imaginary scientists.",
    "This explanation existed first and the data came later.",
    "No one expected these results.",
    "The control group got distracted.",
    "A toaster contributed significantly.",
    "The methodology is best left unexamined.",
    "The graphs looked impressive.",
    "Several cats refused to cooperate.",
    "Reality appears flexible on Tuesdays.",
    "One enthusiastic goldfish signed off on it.",
    "The results were translated from dolphin.",
    "A mysterious humming noise was recorded.",
    "The numbers became self-aware.",
    "The evidence is mostly vibes.",
    "Physics briefly looked the other way.",
    "A pirate endorsed the findings.",
    "The paperwork vanished mysteriously.",
    "Nobody was prepared for success.",
    "The snack budget was exceeded.",
    "The experiment achieved maximum whimsy.",
    "Professional nonsense consultants approved it.",
    "Advanced guesswork was employed.",
    "This result was predicted by absolutely nobody.",
    "An intern accidentally proved everything.",
    "The moon seemed supportive.",
    "The calculations fit on a fortune cookie slip.",
    "All signs pointed toward maybe.",
    "Badgers remain divided on the issue.",
    "This is almost certainly not how science works.",
    "The laboratory was actually somebody's kitchen.",
    "The researchers forgot what they were researching.",
    "A rubber duck provided technical assistance.",
    "The main computer was a calculator with confidence.",
    "The results appeared shortly after someone made coffee.",
    "An owl reviewed the documentation.",
    "The experiment was repeated until everyone felt optimistic.",
    "The official report was written in crayon.",
    "The hypothesis sounded convincing at the time.",
    "A houseplant served as the independent observer.",
    "The evidence disappeared behind the sofa.",
    "The research team became distracted by a shiny object.",
    "A dramatic soundtrack improved the results.",
    "The findings were discovered inside a desk drawer.",
    "The laboratory coat made everything look official.",
    "The sample size consisted of one enthusiastic volunteer.",
    "The equations included several decorative numbers.",
    "The research was funded with loose change.",
    "The conclusion arrived before the experiment.",
    "A nearby refrigerator confirmed the findings.",
    "The scientific instruments were mostly kitchen utensils.",
    "All measurements were rounded toward optimism.",
    "The experts nodded seriously.",
    "Nobody asked the paperclip for identification.",
    "The experiment passed an imaginary safety inspection.",
    "A distant kazoo signaled success.",
    "The control group went out for sandwiches.",
    "The final report included an impressive-looking pie chart.",
    "The evidence was stored in a cookie jar.",
    "Several pigeons expressed cautious support.",
    "The original notes are probably in somebody's pocket.",
    "An unexplained breeze turned the correct page.",
    "The discovery was announced before breakfast.",
    "The laboratory assistant was a garden statue.",
    "The research team voted to believe it.",
    "The result became more convincing after being repeated loudly.",
    "The scientists wore unusually impressive hats.",
    "A mysterious blinking light indicated approval.",
    "The evidence was technically present for a moment.",
    "A cardboard robot verified the calculations.",
    "The experiment was conducted under ideal snack conditions.",
    "The theory survived several minutes of questioning.",
    "An official-looking stamp was applied.",
    "The conclusion was supported by advanced enthusiasm.",
    "Nobody remembered to invite skepticism.",
    "The universe probably has a sense of humor.",
    "The findings were presented to an empty conference room.",
    "A very confident squirrel handled quality control.",
    "The results were too amusing to reject.",
    "The scientific community has not returned our calls.",
    "The facts are currently on vacation.",
    "The explanation sounded better with dramatic lighting.",
    "The procedure was supervised by a certified rubber chicken.",
    "No actual laws of physics were permanently damaged."
]


TITLES = [
    "Master of Coincidences",
    "Grand Optimist",
    "Keeper of the Lucky Object",
    "Professor of Placebos",
    "Chief Magnetologist",
    "Director of Imaginary Research",
    "Doctor of Good Vibes",
    "Supreme Pattern Spotter",
    "Archduke of Coincidences",
    "Wizard of Everyday Magic",
    "Master Storyteller",
    "Guardian of Lost Socks",
    "High Priest of Optimism",
    "Captain of Curious Things",
    "Duke of Random Knowledge",
    "Cosmic Explorer",
    "Honorary Scientist",
    "Certified Daydream Engineer",
    "Knight of the Round Coffee Table",
    "Grand Collector of Oddities",
    "Chief Adventure Officer",
    "Ambassador of Coincidence",
    "Professional Wonderer",
    "Curator of Strange Facts",
    "Minister of Good Fortune",
    "Keeper of the Ancient Paperclip",
    "Chief Encouragement Officer",
    "Explorer of Possibilities",
    "Grandmaster of Vibes",
    "Admiral of Lucky Breaks",
    "Director of Harmless Nonsense",
    "Vice President of Curiosity",
    "Wizard's Assistant",
    "Senior Coincidence Analyst",
    "Legendary Pattern Spotter",
    "Chief Waffle Alignment Officer",
    "Executive Dreamer",
    "Master of Unexpected Discoveries",
    "Guardian of Creative Energy",
    "Royal Consultant of Possibility",
    "Intergalactic Magnet Specialist",
    "Mysterious Sock Investigator",
    "Hero of the Ordinary",
    "Chief Imagination Architect",
    "The Optimizer of Luck",
    "Cosmic Maintenance Technician",
    "Doctor of Coincidental Studies",
    "Supreme Explorer of Maybe",
    "Grand Curiosity Commander",
    "Keeper of the Quantum Donut",
    "Baron of Unlikely Events",
    "Professor of Questionable Evidence",
    "Commander of the Lucky Paperclips",
    "Official Collector of Possibilities",
    "Senior Researcher of Odd Things",
    "Captain of the Cosmic Refrigerator",
    "Grand Protector of Coffee Breaks",
    "Licensed Imaginary Investigator",
    "Supreme Sandwich Intuition Expert",
    "Chief Officer of Mysterious Objects",
    "Royal Keeper of the Emergency Banana",
    "Certified Coincidence Technician",
    "Admiral of the Rubber Duck Fleet",
    "Doctor of Advanced Guesswork",
    "Master of Refrigerator Navigation",
    "Guardian of the Mismatched Socks",
    "Executive Director of Interesting Detours",
    "Chief Consultant of Harmless Weirdness",
    "Professor of Domestic Wizardry",
    "Grandmaster of Spontaneous Ideas",
    "Captain of Optimistic Calculations",
    "Interdimensional Snack Coordinator",
    "Supreme Commander of the Garden Gnomes",
    "Official Historian of Forgotten Objects",
    "Senior Specialist in Dramatic Entrances",
    "Guardian of the Legendary Bottle Cap",
    "Chief Inspector of Suspicious Coincidences",
    "Minister of Imaginary Statistics",
    "Royal Ambassador to Nearby Houseplants",
    "Doctor of Applied Whimsy",
    "Master of Unnecessary Experiments",
    "Certified Cloud Appreciation Expert",
    "Grand Architect of Curious Nonsense",
    "Director of Advanced Daydream Operations",
    "Commander of Mild Awesomeness",
    "Keeper of the Philosophical Paperweight",
    "Professor of Quantum Waffle Theory",
    "Chief Engineer of Impossible Optimism",
    "Grand Curator of Peculiar Treasures",
    "Official Negotiator with Household Appliances",
    "Supreme Investigator of Missing Remote Controls",
    "Master of Ceremonial Spatulas",
    "Captain of the Time-Traveling Thimble",
    "Director of Highly Experimental Teabags",
    "Certified Specialist in Invisible Staplers",
    "Guardian of the Interdimensional Bookmark",
    "Senior Adviser to the Cosmic Waffle Council",
    "Chief Morale Officer for Nearby Paperclips",
    "Grand Champion of Completely Imaginary Science"
]


def speak(text):
    """Speak text using Windows PowerShell and System.Speech."""

    if not TTS_ENABLED:
        return

    text = str(text).strip()

    if not text:
        return

    # Build a PowerShell command safely.
    # Encoding it prevents apostrophes and punctuation from breaking TTS.
    powershell_script = f"""
Add-Type -AssemblyName System.Speech
$voice = New-Object System.Speech.Synthesis.SpeechSynthesizer
$voice.Rate = {TTS_RATE}
$voice.Volume = {TTS_VOLUME}
$voice.Speak(@'
{text}
'@)
$voice.Dispose()
"""

    encoded_script = base64.b64encode(
        powershell_script.encode("utf-16-le")
    ).decode("ascii")

    try:
        subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-EncodedCommand",
                encoded_script
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False
        )

    except FileNotFoundError:
        print("\nTTS could not find Windows PowerShell.")

    except Exception as error:
        print(f"\nTTS error: {error}")


def generate_placebo():
    obj = random.choice(OBJECTS)
    effect = random.choice(EFFECTS)
    explanation = random.choice(EXPLANATIONS)
    title = random.choice(TITLES)

    print("\n" + "=" * 58)
    print("PLACEBO RESULT")
    print("=" * 58)

    print(f"\nObject Found:     {obj}")
    print(f"Imaginary Effect: {effect}")
    print(f"Explanation:      {explanation}")
    print(f"Title Earned:     {title}")

    print("\nRemember:")
    print("The placebo may be imaginary...")
    print("but your imagination is real.")

    speech = (
        f"Placebo result. "
        f"Object found: {obj}. "
        f"Imaginary effect: {effect}. "
        f"Explanation: {explanation}. "
        f"Title earned: {title}. "
        f"The placebo may be imaginary, "
        f"but your imagination is real."
    )

    speak(speech)


def show_tts_status():
    if TTS_ENABLED:
        print(
            f"\nSpeech is ON. "
            f"Rate: {TTS_RATE}. Volume: {TTS_VOLUME}."
        )
    else:
        print("\nSpeech is OFF.")


def main():
    global TTS_ENABLED

    print(INTRO)

    speak(
        "Welcome to Placebo. "
        "This program generates completely imaginary placebo effects. "
        "It is for entertainment, humor, creativity, and curiosity."
    )

    while True:
        print("\nOPTIONS")
        print("  ENTER - Generate a placebo")
        print("  T     - Turn speech on or off")
        print("  S     - Show speech status")
        print("  Q     - Quit")

        choice = input("\nYour choice: ").strip().lower()

        if choice == "":
            generate_placebo()

        elif choice in ("t", "tts", "speech"):
            TTS_ENABLED = not TTS_ENABLED

            if TTS_ENABLED:
                print("\nSpeech is now ON.")
                speak("Speech is now on.")
            else:
                print("\nSpeech is now OFF.")

        elif choice in ("s", "status"):
            show_tts_status()

        elif choice in ("q", "quit", "exit"):
            message = (
                "Thank you for participating "
                "in completely imaginary science."
            )

            print(f"\n{message}")

            if TTS_ENABLED:
                speak(message)

            break

        else:
            print(
                "\nI did not recognize that command. "
                "Press Enter, T, S, or Q."
            )


if __name__ == "__main__":
    main()
