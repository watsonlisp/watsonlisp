#!/usr/bin/env python3
"""
random_company_names_tts.py
Interactive random company name generator with built-in TTS (no pip).
Run: python random_company_names_tts.py
"""

import random
import textwrap
import platform
import subprocess
import shutil

# ---------------------------
# Word lists (use your full lists here)
# ---------------------------
ADJECTIVES = [
    "Amber","Azure","Beige","Black","Blush","Bronze","Cobalt","Coral","Crimson","Cyan",
    "Emerald","Fuchsia","Gold","Indigo","Ivory","Jade","Lavender","Lilac","Magenta","Maroon",
    "Agile","Brisk","Compact","Fast","Fleet","Giant","Grand","Heavy","Hulking","Instant",
    "Authentic","Bold","Bright","Calm","Clean","Clear","Clever","Crisp","Daring","Deep",
    "Adaptive","Algorithmic","Binary","Cloud","Cognitive","Connected","Cyber","Data","Digital","Dynamic",
    "Alpine","Arbor","Aurora","Blooming","Breezy","Canyon","Coastal","Earthy","Evergreen","Floral",
    "Abstract","Arcane","Artisan","Canvas","Concept","Creative","Curious","Dream","Echo","Elemental",
    "Nexus","Nova","Odyssey","Oracle","Prism","Pulse","Radiant","Stellar","Vortex","Zenith"
]

NOUNS = [
    "Analytics","Associates","Brands","Capital","Collective","Commerce","Concepts","Consulting","Corporation","Creations",
    "Designs","Developments","Enterprises","Exchange","Holdings","Industries","Innovations","Investments","Labs","Logistics",
    "Agency","Atelier","Broadcast","Creative","Media","Studio","Productions","Press","Publishing","Records",
    "AI","Apps","Cloud","Code","Data","Devices","Digital","Engines","Frameworks","Grid",
    "Foundry","Forge","Fabrication","Factory","Mill","Plant","Works","Assembly","Supply","Fabric",
    "Advisors","Bank","Capital","Credit","Finance","Fund","Group","Insurance","Investments","Lending",
    "Boutique","Cafe","Corner","Deli","Emporium","Essentials","Goods","Grocery","Market","Pantry",
    "Bio","Biotech","Clinic","Diagnostics","Health","Labs","Medical","Pharma","Research","Therapeutics",
    "Bay","Beach","Bluff","Brook","Canyon","Cove","Field","Forest","Harbor","Hill",
    "Beacon","Catalyst","Core","Element","Engine","Grid","Halo","Horizon","Hub","Matrix",
    "Nexus","Origin","Pulse","Realm","Signal","Source","Sphere","Summit","Vector","Vertex"
]

SUFFIXES = [
    "Inc","Inc.","LLC","Ltd","GmbH","PLC","Co","Co.","Group","Corp","Corporation",
    "Holdings","Partners","Associates","Solutions","Systems","Labs","Works","Studio","Collective","Ventures"
]

TECHY = ["AI","Cloud","Data","Cyber","Nano","Quantum","IoT","Edge","Crypto","Robotics"]
PLAYFUL = ["Co","Co.","Works","Lab","Studio","HQ","House","Co-op"]

# ---------------------------
# TTS helper (no external packages)
# ---------------------------

def _escape_for_powershell(s: str) -> str:
    # Escape double quotes for embedding in a PowerShell double-quoted string
    return s.replace('"', '\\"')

def speak(text: str):
    """
    Speak text using a platform-native TTS engine.
    macOS: say
    Windows: PowerShell System.Speech
    Linux: espeak or spd-say if available
    """
    system = platform.system()
    # Short-circuit empty text
    if not text:
        return

    try:
        if system == "Darwin":
            # macOS 'say' is usually available
            subprocess.run(["say", text], check=False)
            return

        if system == "Windows":
            # Use PowerShell's System.Speech (available on modern Windows)
            safe = _escape_for_powershell(text)
            ps_cmd = (
                'Add-Type -AssemblyName System.Speech;'
                f'$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;'
                f'$s.Speak("{safe}")'
            )
            subprocess.run(["powershell", "-Command", ps_cmd], check=False)
            return

        # Assume Linux/other Unix
        if shutil.which("espeak"):
            subprocess.run(["espeak", text], check=False)
            return
        if shutil.which("spd-say"):
            subprocess.run(["spd-say", text], check=False)
            return

        # No TTS engine found
        print("TTS not available: install espeak or spd-say on Linux, use macOS say, or run on Windows with PowerShell.")
    except Exception as e:
        print("TTS error:", e)

# ---------------------------
# Name generation helpers
# ---------------------------

def smart_caps(name: str, mode: str) -> str:
    if mode == "none":
        return name
    if mode == "title":
        return name.title()
    if mode == "upper":
        return name.upper()
    if mode == "smart":
        out = []
        for word in name.split():
            out.append(word.upper() if random.random() < 0.25 else word.capitalize())
        return " ".join(out)
    return name

def build_name(style: str) -> str:
    if style == "tech":
        prefix = random.choice(TECHY + ADJECTIVES)
        noun = random.choice(NOUNS)
        if random.random() < 0.45:
            suffix = random.choice(["Labs","Systems","AI","Works","Platform","Hub"])
            return f"{prefix} {suffix}"
        return f"{prefix} {noun}"
    if style == "classic":
        adj = random.choice(ADJECTIVES)
        noun = random.choice([n for n in NOUNS if n not in TECHY])
        return f"{adj} {noun}"
    if style == "playful":
        adj = random.choice(ADJECTIVES)
        noun = random.choice(NOUNS + PLAYFUL)
        if random.random() < 0.55:
            suf = random.choice(SUFFIXES)
            return f"{adj} {noun} {suf}"
        return f"{adj} {noun}"
    adj = random.choice(ADJECTIVES)
    noun = random.choice(NOUNS)
    if random.random() < 0.4:
        suf = random.choice(SUFFIXES)
        return f"{adj} {noun} {suf}"
    return f"{adj} {noun}"

def generate(count: int = 10, style: str = "mixed", caps: str = "title", unique: bool = True):
    results = []
    attempts = 0
    max_attempts = max(1000, count * 50)
    while len(results) < count and attempts < max_attempts:
        name = build_name(style)
        name = smart_caps(name, caps)
        if unique:
            if name not in results:
                results.append(name)
        else:
            results.append(name)
        attempts += 1
    return results

# ---------------------------
# Interactive loop with TTS toggle
# ---------------------------

def prompt_settings(count, style, caps, allow_duplicates, tts_enabled):
    print("\nCurrent settings")
    print(f"  Count {count}  Style {style}  Caps {caps}  Allow duplicates {allow_duplicates}  TTS {tts_enabled}")
    print("Enter new values or press Enter to keep current.")
    try:
        new_count = input("New count  (number)  > ").strip()
        if new_count:
            count = max(1, int(new_count))
    except ValueError:
        print("Invalid number, keeping previous count.")
    new_style = input("New style  tech/classic/playful/mixed  > ").strip().lower()
    if new_style in ("tech","classic","playful","mixed"):
        style = new_style
    new_caps = input("New caps  none/title/upper/smart  > ").strip().lower()
    if new_caps in ("none","title","upper","smart"):
        caps = new_caps
    dup = input("Allow duplicates  y/n  > ").strip().lower()
    if dup in ("y","n"):
        allow_duplicates = (dup == "y")
    t = input("Enable TTS  y/n  > ").strip().lower()
    if t in ("y","n"):
        tts_enabled = (t == "y")
    return count, style, caps, allow_duplicates, tts_enabled

def main():
    # defaults
    count = 10
    style = "mixed"
    caps = "title"
    allow_duplicates = False
    tts_enabled = False

    print(textwrap.dedent("""
        Random Company Name Generator with TTS
        Commands
          Enter  generate again with current settings
          s      change settings
          t      toggle TTS on/off
          q      quit
    """).strip())

    try:
        while True:
            names = generate(count=count, style=style, caps=caps, unique=not allow_duplicates)
            print("\nGenerated names\n" + "-"*16)
            for i, n in enumerate(names, 1):
                print(f"{i:2d}. {n}")
            if tts_enabled:
                # Speak each name with a short pause
                for n in names:
                    speak(n)
            cmd = input("\n[Enter] again  s settings  t toggle TTS  q quit  > ").strip().lower()
            if cmd == "q":
                print("Goodbye.")
                break
            if cmd == "s":
                count, style, caps, allow_duplicates, tts_enabled = prompt_settings(count, style, caps, allow_duplicates, tts_enabled)
                continue
            if cmd == "t":
                tts_enabled = not tts_enabled
                print("TTS enabled" if tts_enabled else "TTS disabled")
                continue
            # any other input (including empty) repeats with same settings
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting.")

if __name__ == "__main__":
    main()
