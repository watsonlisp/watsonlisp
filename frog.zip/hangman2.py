#!/usr/bin/env python3
"""
Simple Hangman game (Python 3) with an expanded WORD_LIST.
Save as hangman.py and run: python3 hangman.py
"""

import random
import sys

HANGMAN_PICS = [
    """
     +---+
         |
         |
         |
        ===""",
    """
     +---+
     O   |
         |
         |
        ===""",
    """
     +---+
     O   |
     |   |
         |
        ===""",
    """
     +---+
     O   |
    /|   |
         |
        ===""",
    """
     +---+
     O   |
    /|\\  |
         |
        ===""",
    """
     +---+
     O   |
    /|\\  |
    /    |
        ===""",
    """
     +---+
     O   |
    /|\\  |
    / \\  |
        ==="""
]

WORD_LIST = [
"python","hangman","jeep","house","friend","program","voice","watson","civic","jetta",
"sports","party","saving","alcohol","memory","oracle","genius","computer","keyboard",
"monitor","printer","router","battery","charger","network","internet","website","browser",
"server","database","package","module","function","variable","integer","string","boolean",
"condition","loop","compile","execute","debug","syntax","exception","library","framework",
"android","iphone","tablet","laptop","desktop","notebook","camera","microphone","speaker",
"headphones","television","projector","console","controller","joystick","gamepad","stream",
"movie","series","documentary","director","producer","actor","actress","screenplay","soundtrack",
"guitar","piano","drums","violin","saxophone","trumpet","orchestra","concert","festival",
"restaurant","cafe","bakery","bistro","diner","kitchen","recipe","ingredient","salad","soup",
"pasta","pizza","burger","sandwich","taco","sushi","noodle","steak","seafood","dessert",
"chocolate","vanilla","strawberry","blueberry","mango","banana","apple","orange","grape",
"vegetable","carrot","potato","tomato","onion","garlic","pepper","spinach","broccoli",
"mountain","valley","river","ocean","beach","island","desert","forest","jungle","canyon",
"city","village","suburb","airport","station","harbor","bridge","tunnel","highway","railway",
"station","museum","gallery","library","theater","stadium","arena","market","mall","boutique",
"clothes","jacket","sweater","trousers","shorts","dress","skirt","sneakers","boots","sandals",
"wallet","purse","backpack","suitcase","umbrella","glasses","watch","bracelet","necklace",
"ring","coin","currency","bank","credit","deposit","withdrawal","mortgage","rent","lease",
"household","furniture","sofa","chair","table","bedroom","mattress","pillow","blanket","curtain",
"garden","plant","flower","tree","shrub","lawn","hedge","orchard","greenhouse","compost",
"animal","dog","cat","horse","cow","sheep","goat","pig","chicken","rooster","duck","goose",
"rabbit","hamster","mouse","rat","squirrel","bear","lion","tiger","elephant","giraffe","zebra",
"whale","dolphin","shark","octopus","crab","lobster","butterfly","bee","ant","spider","snake",
"lizard","frog","toad","eagle","hawk","sparrow","penguin","owl","crow","magpie","parrot",
"science","biology","chemistry","physics","astronomy","geology","ecology","research","theory",
"experiment","laboratory","microscope","telescope","particle","quantum","energy","gravity",
"motion","velocity","accident","safety","insurance","license","driver","traffic","signal",
"stationary","dynamic","history","ancient","medieval","modern","revolution","empire","kingdom",
"president","senator","governor","mayor","election","campaign","policy","economy","market",
"finance","investment","portfolio","stock","bond","crypto","bitcoin","ethereum","wallets",
"education","school","college","university","lecture","seminar","exam","degree","diploma",
"teacher","student","mentor","apprentice","career","job","office","remote","commute","vacation",
"holiday","festival","birthday","wedding","anniversary","celebration","gift","present","surprise",
"health","fitness","exercise","yoga","meditation","diet","nutrition","doctor","nurse","clinic",
"hospital","pharmacy","medicine","vaccine","therapy","counseling","sleep","stress","wellness"
]

def choose_word(word_list):
    return random.choice(word_list).lower()

def display_state(secret, guessed_letters, wrong_guesses):
    masked = " ".join([c if c in guessed_letters else "_" for c in secret])
    print(HANGMAN_PICS[min(wrong_guesses, len(HANGMAN_PICS)-1)])
    print("\nWord:  ", masked)
    print("Guessed:", " ".join(sorted(guessed_letters)) if guessed_letters else "(none)")
    print(f"Wrong guesses: {wrong_guesses}\n")

def get_guess(already_guessed):
    while True:
        guess = input("Enter a letter: ").strip().lower()
        if len(guess) != 1:
            print("Please enter exactly one letter.")
            continue
        if not guess.isalpha():
            print("Please enter a letter (a-z).")
            continue
        if guess in already_guessed:
            print("You've already guessed that letter.")
            continue
        return guess

def play_round(word_list, max_wrong=None):
    secret = choose_word(word_list)
    guessed = set()
    wrong = 0
    max_wrong = max_wrong if max_wrong is not None else len(HANGMAN_PICS) - 1

    print("\nNew game started!")
    while True:
        display_state(secret, guessed, wrong)
        if all(c in guessed for c in secret):
            print("🎉 You won! The word was:", secret)
            return True
        if wrong >= max_wrong:
            print(HANGMAN_PICS[-1])
            print("💀 You lost. The word was:", secret)
            return False

        guess = get_guess(guessed)
        guessed.add(guess)
        if guess not in secret:
            wrong += 1

def choose_difficulty():
    print("Choose difficulty: (1) Easy  (2) Normal  (3) Hard")
    choice = input("Enter 1/2/3 (default 2): ").strip()
    if choice == "1":
        return len(HANGMAN_PICS) - 1 + 2
    if choice == "3":
        return max(1, len(HANGMAN_PICS) - 1 - 2)
    return len(HANGMAN_PICS) - 1

def main():
    print("Welcome to Hangman!")
    if len(sys.argv) > 1:
        try:
            with open(sys.argv[1], "r", encoding="utf-8") as f:
                words = [w.strip().lower() for w in f if w.strip()]
                if words:
                    print(f"Loaded {len(words)} words from {sys.argv[1]}")
                    word_list = words
                else:
                    word_list = WORD_LIST
        except Exception as e:
            print("Could not load file, using default word list. Error:", e)
            word_list = WORD_LIST
    else:
        word_list = WORD_LIST

    max_wrong = choose_difficulty()

    while True:
        play_round(word_list, max_wrong=max_wrong)
        again = input("\nPlay again? (y/n): ").strip().lower()
        if not again or again[0] != "y":
            print("Thanks for playing. Goodbye!")
            break

if __name__ == "__main__":
    main()
