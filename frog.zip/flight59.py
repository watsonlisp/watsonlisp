# horizon_circular_profile_with_gauges.py
# Horizon simulator with a circular (wraparound) terrain profile and analog gauges.
# The terrain is a finite ring of TOTAL_TILES tiles stored in chunk files.
# The background streamer generates all chunks for the ring and then stops.
# Press R to regenerate the ring and reset the aircraft.
#
# Run: python3 horizon_circular_profile_with_gauges.py

import math
import time
import random
import json
import os
import threading
from array import array
try:
    import tkinter as tk
except Exception as e:
    raise SystemExit("Tkinter import failed: " + str(e))

# ---------------- Window / timing ----------------
WIDTH, HEIGHT = 1000, 600
FPS = 60
DT = 1.0 / FPS

# ---------------- Visuals / HUD ----------------
SKY_COLOR = "#66b3ff"
GROUND_COLOR = "#2ea043"
HORIZON_LINE = "#ffffff"
PITCH_TICK_COLOR = "#e6eef8"
FRAME_COLOR = "#223344"
PLANE_REF = "#111827"
HUD_COLOR = "#ffffff"
TAPE_BG = "#071018"
TAPE_FILL = "#66c2ff"

PITCH_SCALE = 3.0
ROLL_LATERAL_SCALE = 6.0
SMOOTH = 8.0

# ---------------- Physics / flight ----------------
GRAVITY = 9.81
MASS = 1200.0
RHO = 1.225
WING_AREA = 16.2
CL0 = 0.2
CLA = 5.5
CD0 = 0.02
K = 0.04
MAX_THRUST = 6000.0
MAX_PITCH_RATE = math.radians(40)
MAX_ROLL_RATE = math.radians(60)
BRAKE_FACTOR = 0.8

TURN_FACTOR = 0.02
YAW_RESPONSE = 4.0

# --- Added for rudder and flaps (minimal, keep original behavior when controls are neutral)
RUDDER_FACTOR = 0.012        # rudder contribution to yaw (modest compared to roll-induced turning)
FLAPS_CL_INC = 0.6           # additional baseline lift coefficient when flaps deployed (scaled by flap fraction)
FLAPS_CD_MULT = 1.8          # multiplier to drag when flaps are deployed

# --- New constants to make rudder actually turn the plane (velocity vector responds to rudder)
RUDDER_HEADING_OFFSET_DEG = 10.0   # max heading offset (degrees) applied to velocity when rudder is full deflection
RUDDER_VELOCITY_BLEND = 0.6        # how strongly velocity heading is blended toward rudder-influenced heading

# --- Rudder also gives a small horizontal speed boost when deflected
RUDDER_SPEED_ACCEL = 6.0           # m/s^2 applied proportionally to |rudder|

# Rudder influence on terrain scroll: makes ground move faster left/right when rudder is deflected
RUDDER_GROUND_SPEED = 220.0        # pixels per second of extra lateral ground scroll at full rudder

# ---------------- Aerobatics constants ----------------
BARREL_DURATION = 1.2   # seconds to complete a full 360° roll
LOOP_DURATION = 2.0     # seconds to complete a full 360° loop
MANEUVER_MAX_G = 4.0    # visual scaling (not strict physics)

# ---------------- Rigid-body / control physics ----------------
# Moments of inertia (approx kg·m^2)
Ixx = 2500.0    # roll inertia
Iyy = 3200.0    # pitch inertia
Izz = 4500.0    # yaw inertia

# Control surface effectiveness (torque per unit deflection * speed factor)
AILERON_TORQUE_COEFF = 1200.0    # roll torque per unit aileron * (speed/20)
ELEVATOR_TORQUE_COEFF = 1500.0   # pitch torque per unit elevator * (speed/20)
RUDDER_TORQUE_COEFF = 800.0      # yaw torque per unit rudder * (speed/20)

# Angular damping (to model aerodynamic damping)
ROLL_DAMPING = 40.0
PITCH_DAMPING = 50.0
YAW_DAMPING = 30.0

# Structural / safety limits
MAX_G_LOAD = 6.0
STALL_G_PENALTY = 0.6   # reduce lift multiplier when exceeding safe g in stall

# Wind / turbulence
WIND_BASE = (0.0, 0.0)   # steady wind vector (wx, wy) in m/s (world coords)
GUST_MAG = 6.0           # max gust speed
GUST_FREQ = 0.8          # gust frequency (Hz)

BASE_SCROLL_FACTOR = 1.8
GROUND_BANK_SHIFT = 10.0
BANK_SPEED_FACTOR = 2.5
BANK_EXPONENT = 1.6

ACCUM_THRESHOLD_DEG = 1.5
ACCUM_RATE_PER_DEG = 18.0
DECAY_PER_SEC = 0.6

# ---------------- Terrain procedural params ----------------
TERRAIN_TILE_W = 500               # pixels per tile
TERRAIN_BASE_HEIGHT = 50
TERRAIN_VARIANCE = 240.0

OCTAVES = 5
LACUNARITY = 2.0
PERSISTENCE = 0.55
COARSE_STEP = 8

# ---------------- Circular profile / streaming ----------------
PROFILE_DIR = "terrain_ring"
PROFILE_META = os.path.join(PROFILE_DIR, "meta.json")
CHUNK_PREFIX = "chunk_"            # chunk files: chunk_000000.bin
CHUNK_TILE_COUNT = 50_000          # tiles per chunk
CHUNK_WRITE_BATCH = 4096
BACKGROUND_PREFETCH_CHUNKS = 3
STREAMER_SLEEP = 0.05

# **Set TOTAL_TILES to the ring length you want**
TOTAL_TILES = 2_000_000            # example: two million tiles -> adjust to taste

# small in-memory caches
_file_chunk_index_cache = {}
_file_chunk_lock = threading.Lock()

# ---------------- Utilities ----------------
def clamp(x, a, b):
    return max(a, min(b, x))

def ensure_profile_dir():
    if not os.path.exists(PROFILE_DIR):
        os.makedirs(PROFILE_DIR, exist_ok=True)

def save_meta(meta):
    ensure_profile_dir()
    with open(PROFILE_META, "w") as f:
        json.dump(meta, f)

def load_meta():
    if not os.path.exists(PROFILE_META):
        return None
    try:
        with open(PROFILE_META, "r") as f:
            return json.load(f)
    except Exception:
        return None

# ---------------- Gradient helpers ----------------
def _hex_to_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _rgb_to_hex(r, g, b):
    return f"#{r:02x}{g:02x}{b:02x}"

def _lerp_int(a, b, t):
    return int(round(a + (b - a) * t))

def gradient_color(value, max_value=30.0):
    """
    Map value (signed) in range [-max_value..max_value] to a 3-stop gradient:
      blue (#66c2ff) -> yellow (#ffd166) -> red (#ff6b6b)
    Returns hex color string.
    """
    v = clamp(abs(value) / float(max_value), 0.0, 1.0)
    low = _hex_to_rgb("#66c2ff")
    mid = _hex_to_rgb("#ffd166")
    high = _hex_to_rgb("#ff6b6b")
    split = 0.6
    if v <= split:
        t = v / split if split > 0 else 0.0
        r = _lerp_int(low[0], mid[0], t)
        g = _lerp_int(low[1], mid[1], t)
        b = _lerp_int(low[2], mid[2], t)
    else:
        t = (v - split) / (1.0 - split) if (1.0 - split) > 0 else 0.0
        r = _lerp_int(mid[0], high[0], t)
        g = _lerp_int(mid[1], high[1], t)
        b = _lerp_int(mid[2], high[2], t)
    return _rgb_to_hex(r, g, b)

def _blend_hex(c1, c2, t):
    """Blend two hex colors c1->c2 by t in [0..1]."""
    a = _hex_to_rgb(c1)
    b = _hex_to_rgb(c2)
    r = _lerp_int(a[0], b[0], t)
    g = _lerp_int(a[1], b[1], t)
    b_ = _lerp_int(a[2], b[2], t)
    return _rgb_to_hex(r, g, b_)

# ---------------- Deterministic procedural generator ----------------
def _hash_int64(x):
    x = (x + 0x9e3779b97f4a7c15) & 0xFFFFFFFFFFFFFFFF
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9 & 0xFFFFFFFFFFFFFFFF
    x = (x ^ (x >> 27)) * 0x94d049bb133111eb & 0xFFFFFFFFFFFFFFFF
    x = x ^ (x >> 31)
    return x & 0xFFFFFFFFFFFFFFFF

def _rand_signed(tile_index, seed):
    h = _hash_int64(tile_index ^ (seed & 0xFFFFFFFFFFFFFFFF))
    v = (h >> 11) * (1.0 / (1 << 53))
    return v * 2.0 - 1.0

def _smoothstep(t):
    return t * t * (3.0 - 2.0 * t)

def _lerp(a, b, t):
    return a + (b - a) * t

def _value_noise(tile_index, seed, spacing):
    if spacing <= 1:
        return _rand_signed(tile_index, seed)
    left_idx = (tile_index // spacing) * spacing
    right_idx = left_idx + spacing
    t = (tile_index - left_idx) / float(spacing)
    a = _rand_signed(left_idx, seed)
    b = _rand_signed(right_idx, seed)
    return _lerp(a, b, _smoothstep(t))

def procedural_tile_height(tile_index, seed):
    # wrap tile_index into ring before generating so procedural generator is consistent with stored ring
    if TOTAL_TILES <= 0:
        idx = max(0, tile_index)
    else:
        idx = tile_index % TOTAL_TILES
    amplitude = 1.0
    frequency_spacing = COARSE_STEP
    total = 0.0
    max_amp = 0.0
    for o in range(OCTAVES):
        v = _value_noise(idx, seed + o * 0x9e3779b9, int(max(1, round(frequency_spacing))))
        total += v * amplitude
        max_amp += amplitude
        amplitude *= PERSISTENCE
        frequency_spacing = max(1.0, frequency_spacing / LACUNARITY)
    if max_amp != 0:
        total /= max_amp
    return TERRAIN_BASE_HEIGHT + total * TERRAIN_VARIANCE

# ---------------- Chunk file helpers ----------------
def chunk_filename(chunk_index):
    return os.path.join(PROFILE_DIR, f"{CHUNK_PREFIX}{chunk_index:08d}.bin")

def write_chunk_to_disk(chunk_index, heights):
    ensure_profile_dir()
    fn = chunk_filename(chunk_index)
    tmp = fn + ".tmp"
    try:
        with open(tmp, "wb") as f:
            f.write(heights.tobytes())
        os.replace(tmp, fn)
    except Exception:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass

def read_chunk_from_disk(chunk_index):
    fn = chunk_filename(chunk_index)
    if not os.path.exists(fn):
        return None
    try:
        with open(fn, "rb") as f:
            data = f.read()
            arr = array('f')
            arr.frombytes(data)
            return arr
    except Exception:
        return None

# ---------------- File-backed accessor (with ring wrapping) ----------------
def get_tile_from_storage(tile_index, seed):
    """
    Return height for tile_index using ring wrapping:
    - Map tile_index -> idx = tile_index % TOTAL_TILES
    - Determine chunk_index and offset within chunk
    - Return None if chunk file missing (caller falls back to procedural)
    """
    if TOTAL_TILES <= 0:
        return None
    idx = tile_index % TOTAL_TILES
    chunk_index = idx // CHUNK_TILE_COUNT
    offset = idx % CHUNK_TILE_COUNT
    with _file_chunk_lock:
        if chunk_index in _file_chunk_index_cache:
            chunk = _file_chunk_index_cache[chunk_index]
            if 0 <= offset < len(chunk):
                return float(chunk[offset])
            return None
    chunk = read_chunk_from_disk(chunk_index)
    if chunk is None:
        return None
    with _file_chunk_lock:
        _file_chunk_index_cache[chunk_index] = chunk
        if len(_file_chunk_index_cache) > 32:
            keys = list(_file_chunk_index_cache.keys())
            for k in keys[: len(keys) // 4]:
                _file_chunk_index_cache.pop(k, None)
    if 0 <= offset < len(chunk):
        return float(chunk[offset])
    return None

# ---------------- Background streamer (generates full ring then stops) ----------------
class TerrainStreamer(threading.Thread):
    def __init__(self, seed, stop_event):
        super().__init__(daemon=True)
        self.seed = seed
        self.stop_event = stop_event
        self.total_chunks = (TOTAL_TILES + CHUNK_TILE_COUNT - 1) // CHUNK_TILE_COUNT
        self.meta = load_meta() or {"seed": seed, "highest_chunk": -1, "total_chunks": self.total_chunks}
        if self.meta.get("seed") != seed or self.meta.get("total_chunks") != self.total_chunks:
            # new ring configuration: reset meta
            self.meta = {"seed": seed, "highest_chunk": -1, "total_chunks": self.total_chunks}
            save_meta(self.meta)

    def run(self):
        # generate all chunks for the ring, in order, unless they already exist
        for ci in range(self.total_chunks):
            if self.stop_event.is_set():
                break
            fn = chunk_filename(ci)
            if os.path.exists(fn):
                # update meta if needed
                meta = load_meta() or {"seed": self.seed, "highest_chunk": -1, "total_chunks": self.total_chunks}
                if meta.get("highest_chunk", -1) < ci:
                    meta["highest_chunk"] = ci
                    save_meta(meta)
                continue
            # generate chunk heights
            heights = array('f')
            start_tile = ci * CHUNK_TILE_COUNT
            end_tile = min(start_tile + CHUNK_TILE_COUNT, TOTAL_TILES)
            # generate heights for indices start_tile..end_tile-1 (these are ring indices)
            for t in range(start_tile, end_tile):
                heights.append(float(procedural_tile_height(t, self.seed)))
            write_chunk_to_disk(ci, heights)
            meta = load_meta() or {"seed": self.seed, "highest_chunk": -1, "total_chunks": self.total_chunks}
            meta["seed"] = self.seed
            meta["highest_chunk"] = ci
            meta["total_chunks"] = self.total_chunks
            save_meta(meta)
        # streamer finished generating the full ring; it will now idle until stop_event set
        while not self.stop_event.is_set():
            time.sleep(STREAMER_SLEEP)

# ---------------- Aircraft / Simulator (stall features reintroduced) ----------------
class Aircraft:
    def __init__(self):
        self.x = 200.0
        self.y = HEIGHT - 200.0
        self.vx = 40.0
        self.vy = 0.0
        self.heading = math.atan2(self.vy, self.vx)
        self.pitch = math.radians(-5.0)
        self.roll = 0.0
        # angular rates (rad/s)
        self.pitch_rate = 0.0
        self.roll_rate = 0.0
        self.yaw_rate = 0.0

        self.throttle = 0.4
        self.brakes = False
        self.crashed = False
        self.ground_offset = 0.0

        # Stall-related state (reintroduced)
        self.stalled = False
        self.stall_timer = 0.0
        self.stall_recovery_timer = 0.0

        # --- Added control surfaces state: flaps (0.0..1.0) and rudder (-1.0..1.0)
        self.flaps = 0.0
        self.rudder = 0.0

        # control surface deflections (smoothed)
        self.aileron = 0.0   # roll control (-1..1)
        self.elevator = 0.0  # pitch control (-1..1)

        # aerobatic maneuver state
        self.maneuver = None            # "barrel" or "loop" or None
        self.maneuver_timer = 0.0
        self.maneuver_duration = 0.0
        self.maneuver_dir = 1.0         # +1 or -1

        # last wind sample for turbulence
        self._wind_phase = random.random() * 2.0 * math.pi

    def reset(self):
        self.__init__()

    # call to start a barrel roll: dir = +1 (right) or -1 (left)
    def start_barrel(self, dir=1.0, duration=BARREL_DURATION):
        if self.crashed:
            return
        self.maneuver = "barrel"
        self.maneuver_timer = 0.0
        self.maneuver_duration = max(0.1, duration)
        self.maneuver_dir = 1.0 if dir >= 0 else -1.0

    # call to start a loop: dir = +1 (nose-up forward loop) or -1 (reverse)
    def start_loop(self, dir=1.0, duration=LOOP_DURATION):
        if self.crashed:
            return
        self.maneuver = "loop"
        self.maneuver_timer = 0.0
        self.maneuver_duration = max(0.2, duration)
        self.maneuver_dir = 1.0 if dir >= 0 else -1.0

    def update(self, dt, controls):
        if self.crashed:
            self.vx *= 0.98
            self.vy += GRAVITY * dt
            self.x += self.vx * dt
            self.y += self.vy * dt
            self.heading = math.atan2(self.vy, self.vx) if (abs(self.vx) + abs(self.vy)) > 1e-6 else self.heading
            return

        # read pilot inputs
        pitch_input = controls.get("pitch", 0.0)   # -1..1 (nose down..up)
        roll_input = controls.get("roll", 0.0)     # -1..1 (left..right)

        # --- read flap controls (incremental) and rudder controls
        if controls.get("flaps_up", False):
            self.flaps = clamp(self.flaps - 0.25 * dt, 0.0, 1.0)  # retract faster
        if controls.get("flaps_down", False):
            self.flaps = clamp(self.flaps + 0.25 * dt, 0.0, 1.0)  # deploy gradually

        # rudder: -1 left, +1 right (smoothed earlier)
        rudder = 0.0
        if controls.get("rudder_left", False):
            rudder -= 1.0
        if controls.get("rudder_right", False):
            rudder += 1.0
        # smooth rudder response
        self.rudder += (rudder - self.rudder) * 8.0 * dt
        self.rudder = clamp(self.rudder, -1.0, 1.0)

        if controls.get("throttle_up", False):
            self.throttle = clamp(self.throttle + 0.9 * dt, 0.0, 1.0)
        if controls.get("throttle_down", False):
            self.throttle = clamp(self.throttle - 0.9 * dt, 0.0, 1.0)
        if controls.get("brake_toggle", False):
            self.brakes = not self.brakes

        # map pilot inputs to control surface deflections (smooth)
        target_aileron = roll_input
        self.aileron += (target_aileron - self.aileron) * 6.0 * dt
        target_elevator = pitch_input
        self.elevator += (target_elevator - self.elevator) * 6.0 * dt

        # ---------------- Wind / air-relative velocity ----------------
        t_now = time.time()
        gust = GUST_MAG * math.sin(2.0 * math.pi * GUST_FREQ * t_now + self._wind_phase)
        wx = WIND_BASE[0] + gust * (random.uniform(-0.6, 0.6))
        wy = WIND_BASE[1] + gust * (random.uniform(-0.6, 0.6))
        # air-relative velocity = v - wind
        v_air_x = self.vx - wx
        v_air_y = self.vy - wy
        airspeed = math.hypot(v_air_x, v_air_y)
        flight_path_angle = math.atan2(v_air_y, v_air_x) if airspeed > 1e-6 else self.heading

        # ---------------- Aerodynamics: AoA, lift, drag, thrust ----------------
        aoa = self.pitch - flight_path_angle
        aoa = (aoa + math.pi) % (2 * math.pi) - math.pi
        aoa_deg = math.degrees(aoa)

        # Simple stall detection using air-relative AoA and airspeed
        STALL_AOA_DEG = 15.0
        STALL_SPEED_ALLOW = 30.0
        RECOVERY_AOA_DEG = 10.0
        if not self.stalled:
            if aoa_deg > STALL_AOA_DEG and airspeed < STALL_SPEED_ALLOW:
                self.stalled = True
                self.stall_timer = 0.0
        else:
            self.stall_timer += dt
            if aoa_deg < RECOVERY_AOA_DEG and airspeed > 20.0:
                self.stalled = False
                self.stall_recovery_timer = 0.0

        # Lift coefficient: baseline + linear CLA*aoa + flap increment
        cl0_effective = CL0 + self.flaps * FLAPS_CL_INC
        cl = cl0_effective + CLA * aoa
        if self.stalled:
            cl *= 0.25

        # Lift magnitude (perpendicular to relative wind)
        lift = 0.5 * RHO * (airspeed ** 2) * WING_AREA * cl

        # Drag
        cd = CD0 + K * (cl ** 2)
        if self.flaps > 0.0:
            cd *= (1.0 + (FLAPS_CD_MULT - 1.0) * self.flaps)
        if self.stalled:
            cd *= 3.0
        drag = 0.5 * RHO * (airspeed ** 2) * WING_AREA * cd

        # Thrust vector in body axis (assume thrust along pitch axis)
        thrust = self.throttle * MAX_THRUST * (1.0 - 0.25 * self.flaps)
        if self.stalled:
            thrust *= 0.6
        thrust_x = thrust * math.cos(self.pitch)
        thrust_y = thrust * math.sin(self.pitch)

        # Resolve lift and drag into world coords (lift perpendicular to relative wind)
        if airspeed > 1e-6:
            ux = v_air_x / airspeed
            uy = v_air_y / airspeed
            # drag along -u
            drag_x = -drag * ux
            drag_y = -drag * uy
            # lift perpendicular to u: rotate u by +90deg
            lift_x = -lift * uy
            lift_y = lift * ux
        else:
            drag_x = drag_y = 0.0
            lift_x = 0.0
            lift_y = 0.0

        # Weight
        weight_x = 0.0
        weight_y = -MASS * GRAVITY

        # Sum forces (world coords)
        ax = (thrust_x + drag_x + lift_x + weight_x) / MASS
        ay = (thrust_y + drag_y + lift_y + weight_y) / MASS

        # Apply brakes as additional longitudinal drag
        if self.brakes:
            ax -= BRAKE_FACTOR * self.vx

        # small speed boost from rudder deflection (makes horizontal ground speed increase with rudder)
        if abs(self.rudder) > 1e-6:
            speed_boost = abs(self.rudder) * RUDDER_SPEED_ACCEL * dt
            new_speed = math.hypot(self.vx, self.vy) + speed_boost
            if new_speed > 1e-6:
                vel_heading = math.atan2(self.vy, self.vx) if (abs(self.vx) + abs(self.vy)) > 1e-6 else self.heading
                self.vx = new_speed * math.cos(vel_heading)
                self.vy = new_speed * math.sin(vel_heading)

        # ---------------- Moments / angular dynamics ----------------
        # Control torques (scale with dynamic pressure / speed)
        speed_scale = clamp(airspeed / 20.0, 0.1, 3.0)

        # roll torque from aileron
        roll_torque = AILERON_TORQUE_COEFF * self.aileron * speed_scale
        # pitch torque from elevator (nose up positive)
        pitch_torque = ELEVATOR_TORQUE_COEFF * self.elevator * speed_scale
        # yaw torque from rudder
        yaw_torque = RUDDER_TORQUE_COEFF * self.rudder * speed_scale

        # aerodynamic damping moments (opposes angular rates)
        roll_torque += -ROLL_DAMPING * self.roll_rate
        pitch_torque += -PITCH_DAMPING * self.pitch_rate
        yaw_torque += -YAW_DAMPING * self.yaw_rate

        # integrate angular accelerations (semi-implicit)
        roll_acc = roll_torque / Ixx
        pitch_acc = pitch_torque / Iyy
        yaw_acc = yaw_torque / Izz

        self.roll_rate += roll_acc * dt
        self.pitch_rate += pitch_acc * dt
        self.yaw_rate += yaw_acc * dt

        # integrate angles
        self.roll += self.roll_rate * dt
        self.pitch += self.pitch_rate * dt
        self.heading += self.yaw_rate * dt

        # ----------------- aerobatic maneuvers handling -----------------
        if self.maneuver is not None and airspeed > 1e-3:
            self.maneuver_timer += dt
            t = self.maneuver_timer
            T = self.maneuver_duration
            frac = clamp(t / T, 0.0, 1.0)

            if self.maneuver == "barrel":
                # rotate roll smoothly through 360 degrees
                roll_delta = self.maneuver_dir * (2.0 * math.pi) * (dt / T)
                self.roll += roll_delta
                # rotate velocity heading a bit so the plane also turns while rolling
                vel_heading = math.atan2(self.vy, self.vx)
                heading_target = vel_heading + self.maneuver_dir * 0.6 * (2.0 * math.pi) * (dt / T)
                # blend to avoid discontinuities
                blend = 0.9
                new_vel_heading = vel_heading * (1.0 - blend) + heading_target * blend
                self.vx = airspeed * math.cos(new_vel_heading)
                self.vy = airspeed * math.sin(new_vel_heading)
                # small yaw change to match visual
                self.heading += self.maneuver_dir * 0.6 * (2.0 * math.pi) * (dt / T) * 0.5

            elif self.maneuver == "loop":
                # rotate flight-path angle (velocity vector) through 360 degrees
                fp_angle = math.atan2(self.vy, self.vx)
                fp_delta = self.maneuver_dir * (2.0 * math.pi) * (dt / T)
                fp_angle += fp_delta
                # keep speed magnitude, rotate velocity vector
                self.vx = airspeed * math.cos(fp_angle)
                self.vy = airspeed * math.sin(fp_angle)
                # set pitch to follow flight path (small lead so nose points into loop)
                self.pitch = fp_angle + math.radians(10.0) * self.maneuver_dir
                # small heading drift so loop can also change heading slightly
                self.heading += self.maneuver_dir * 0.2 * (2.0 * math.pi) * (dt / T) * 0.2

            # finish maneuver
            if t >= T:
                # normalize angles to reasonable ranges
                self.roll = (self.roll + math.pi) % (2.0 * math.pi) - math.pi
                self.pitch = (self.pitch + math.pi) % (2.0 * math.pi) - math.pi
                self.maneuver = None
                self.maneuver_timer = 0.0
                self.maneuver_duration = 0.0

        # ---------------- g-load and structural effects ----------------
        # body up vector (world coords) = (-sin(pitch), cos(pitch))
        body_up_x = -math.sin(self.pitch)
        body_up_y = math.cos(self.pitch)
        normal_acc = ax * body_up_x + ay * body_up_y
        g_load = normal_acc / GRAVITY + 1.0  # +1g baseline

        if abs(g_load) > MAX_G_LOAD:
            # reduce lift and increase drag to simulate structural/flow separation
            lift *= 0.5
            drag *= 1.5
            # reduce control effectiveness
            self.aileron *= 0.8
            self.elevator *= 0.8

        if self.stalled and abs(g_load) > 2.5:
            cl *= STALL_G_PENALTY

        # ---------------- Semi-implicit integration for linear motion ----------------
        self.vx += ax * dt
        self.vy += ay * dt
        self.x += self.vx * dt
        self.y += self.vy * dt

        # accumulate lateral ground offset while banked
        roll_deg = math.degrees(self.roll)
        if abs(roll_deg) > ACCUM_THRESHOLD_DEG:
            sign = 1.0 if roll_deg > 0 else -1.0
            self.ground_offset += sign * (abs(roll_deg) * ACCUM_RATE_PER_DEG) * dt
        else:
            per_frame_decay = DECAY_PER_SEC ** dt
            self.ground_offset *= per_frame_decay
            if abs(self.ground_offset) < 0.5:
                self.ground_offset = 0.0

        # ground collision logic
        ground_y = HEIGHT - 60
        if self.y >= ground_y:
            self.y = ground_y
            vertical_speed = self.vy
            if abs(vertical_speed) > 5.0 or abs(self.roll) > math.radians(30) or math.hypot(self.vx, self.vy) > 12.0:
                self.crashed = True
            else:
                self.vx *= 0.3
                self.vy = 0.0
                self.pitch_rate = 0.0
                self.roll_rate = 0.0
                self.pitch = 0.0
                self.roll = 0.0
                self.yaw_rate = 0.0
                self.ground_offset = 0.0
                self.heading = 0.0

# ---------------- App / rendering with analog gauges ----------------
class HorizonApp:
    def __init__(self, root):
        self.root = root
        root.title("Horizon — circular terrain ring with analog gauges")
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="black")
        self.canvas.pack()
        self.plane = Aircraft()
        self.keys = set()
        root.bind("<KeyPress>", self.on_key_down)
        root.bind("<KeyRelease>", self.on_key_up)
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.running = True

        self.hx = WIDTH // 2
        self.hy = HEIGHT // 2 - 40
        self._last_brake_toggle = 0.0

        # load or create meta
        meta = load_meta()
        if meta is None or meta.get("total_chunks") != ((TOTAL_TILES + CHUNK_TILE_COUNT - 1) // CHUNK_TILE_COUNT):
            seed = random.randrange(1 << 30)
            meta = {"seed": seed, "highest_chunk": -1, "total_chunks": (TOTAL_TILES + CHUNK_TILE_COUNT - 1) // CHUNK_TILE_COUNT}
            save_meta(meta)
        self.terrain_seed = meta["seed"]

        # start background streamer to generate the full ring
        self.stop_event = threading.Event()
        self.streamer = TerrainStreamer(self.terrain_seed, stop_event=self.stop_event)
        self.streamer.start()

        self.loop()

    def regenerate_profile(self):
        # stop streamer, wipe chunk files and meta, start new streamer with new seed
        self.stop_event.set()
        try:
            self.streamer.join(timeout=1.0)
        except Exception:
            pass
        # remove chunk files and meta
        if os.path.exists(PROFILE_DIR):
            for fn in os.listdir(PROFILE_DIR):
                if fn.startswith(CHUNK_PREFIX) or fn == os.path.basename(PROFILE_META):
                    try:
                        os.remove(os.path.join(PROFILE_DIR, fn))
                    except Exception:
                        pass
        seed = random.randrange(1 << 30)
        meta = {"seed": seed, "highest_chunk": -1, "total_chunks": (TOTAL_TILES + CHUNK_TILE_COUNT - 1) // CHUNK_TILE_COUNT}
        save_meta(meta)
        self.terrain_seed = seed
        with _file_chunk_lock:
            _file_chunk_index_cache.clear()
        self.stop_event = threading.Event()
        self.streamer = TerrainStreamer(self.terrain_seed, stop_event=self.stop_event)
        self.streamer.start()

    def on_key_down(self, event):
        k = event.keysym.lower()
        self.keys.add(k)
        if k == "b":
            now = time.time()
            if now - self._last_brake_toggle > 0.15:
                self.plane.brakes = not self.plane.brakes
                self._last_brake_toggle = now
        if k == "r":
            self.plane.reset()
            self.regenerate_profile()
        if k == "escape":
            self.on_close()

        # aerobatic key bindings
        if k == "z":   # barrel roll right
            self.plane.start_barrel(dir=1.0)
        if k == "c":   # barrel roll left
            self.plane.start_barrel(dir=-1.0)
        if k == "x":   # loop forward (nose-up)
            self.plane.start_loop(dir=1.0)
        if k == "v":   # loop reverse (negative)
            self.plane.start_loop(dir=-1.0)

    def on_key_up(self, event):
        k = event.keysym.lower()
        if k in self.keys:
            self.keys.remove(k)

    def get_controls(self):
        controls = {}
        pitch = 0.0
        if "w" in self.keys or "up" in self.keys:
            pitch = 1.0
        if "s" in self.keys or "down" in self.keys:
            pitch = -1.0
        controls["pitch"] = pitch

        roll = 0.0
        if "a" in self.keys or "left" in self.keys:
            roll = -1.0
        if "d" in self.keys or "right" in self.keys:
            roll = 1.0
        controls["roll"] = roll

        controls["throttle_up"] = ("space" in self.keys)
        controls["throttle_down"] = ("shift_l" in self.keys) or ("shift_r" in self.keys)
        controls["brake_toggle"] = False

        # --- flaps controls: 'f' to deploy, 'g' to retract
        controls["flaps_down"] = ("f" in self.keys)
        controls["flaps_up"] = ("g" in self.keys)

        # --- rudder controls: 'q' left, 'e' right
        controls["rudder_left"] = ("q" in self.keys)
        controls["rudder_right"] = ("e" in self.keys)

        return controls

    # ---------------- Analog gauges ----------------
    def draw_gauge_ring(self, cx, cy, r, label=None):
        self.canvas.create_oval(cx - r, cy - r, cx + r, cy + r, fill="#0b1220", outline="#2b3b4a", width=3)
        if label:
            self.canvas.create_text(cx, cy + r + 12, text=label, fill=HUD_COLOR, font=("Consolas", 10))

    def draw_airspeed_gauge(self, x, y, size, speed):
        # Airspeed gauge: 0..300 m/s mapped to -120..120 degrees
        r = size // 2
        cx, cy = x + r, y + r
        self.draw_gauge_ring(cx, cy, r, label="AIRSPEED")
        # ticks
        for t in range(0, 301, 30):
            angle = math.radians(-120 + (t / 300.0) * 240.0)
            sx = cx + math.cos(angle) * (r - 8)
            sy = cy + math.sin(angle) * (r - 8)
            ex = cx + math.cos(angle) * (r - 2)
            ey = cy + math.sin(angle) * (r - 2)
            self.canvas.create_line(sx, sy, ex, ey, fill="#9fb4c8", width=2)
            tx = cx + math.cos(angle) * (r - 22)
            ty = cy + math.sin(angle) * (r - 22)
            self.canvas.create_text(tx, ty, text=str(t), fill="#9fb4c8", font=("Consolas", 8))
        # needle
        sp = clamp(speed, 0.0, 300.0)
        needle_angle = math.radians(-120 + (sp / 300.0) * 240.0)
        nx = cx + math.cos(needle_angle) * (r - 28)
        ny = cy + math.sin(needle_angle) * (r - 28)
        self.canvas.create_line(cx, cy, nx, ny, fill="#ffdd57", width=3)
        # numeric readout
        self.canvas.create_text(cx, cy + r - 18, text=f"{int(speed)} m/s", fill=HUD_COLOR, font=("Consolas", 10))

    def draw_altimeter(self, x, y, size, altitude):
        # Altimeter: show thousands and hundreds with rotating needles
        r = size // 2
        cx, cy = x + r, y + r
        self.draw_gauge_ring(cx, cy, r, label="ALT")
        # ticks every 2000
        for t in range(0, 20001, 2000):
            angle = math.radians(-120 + (t / 20000.0) * 240.0)
            sx = cx + math.cos(angle) * (r - 8)
            sy = cy + math.sin(angle) * (r - 8)
            ex = cx + math.cos(angle) * (r - 2)
            ey = cy + math.sin(angle) * (r - 2)
            self.canvas.create_line(sx, sy, ex, ey, fill="#9fb4c8", width=2)
            tx = cx + math.cos(angle) * (r - 22)
            ty = cy + math.sin(angle) * (r - 22)
            self.canvas.create_text(tx, ty, text=str(t//1000), fill="#9fb4c8", font=("Consolas", 8))
        # needles: hundreds (short), thousands (long)
        alt = max(0.0, altitude)
        hundreds = alt % 1000.0
        hundreds_angle = math.radians(-120 + (hundreds / 1000.0) * 240.0)
        hx = cx + math.cos(hundreds_angle) * (r - 18)
        hy = cy + math.sin(hundreds_angle) * (r - 18)
        self.canvas.create_line(cx, cy, hx, hy, fill="#ff6b6b", width=3)
        thousands = (alt % 20000.0) / 1000.0
        thousands_angle = math.radians(-120 + (thousands / 20.0) * 240.0)
        txn = cx + math.cos(thousands_angle) * (r - 30)
        tyn = cy + math.sin(thousands_angle) * (r - 30)
        self.canvas.create_line(cx, cy, txn, tyn, fill="#ffd166", width=2)
        self.canvas.create_text(cx, cy + r - 18, text=f"{int(alt)} m", fill=HUD_COLOR, font=("Consolas", 10))

    def draw_heading_gauge(self, x, y, size, heading_deg):
        # Heading (compass) 0..360
        r = size // 2
        cx, cy = x + r, y + r
        self.draw_gauge_ring(cx, cy, r, label="HDG")
        # ticks every 30 deg
        for t in range(0, 360, 30):
            angle = math.radians(-90 + t)
            sx = cx + math.cos(angle) * (r - 8)
            sy = cy + math.sin(angle) * (r - 8)
            ex = cx + math.cos(angle) * (r - 2)
            ey = cy + math.sin(angle) * (r - 2)
            self.canvas.create_line(sx, sy, ex, ey, fill="#9fb4c8", width=2)
            tx = cx + math.cos(angle) * (r - 22)
            ty = cy + math.sin(angle) * (r - 22)
            label = {0:"N",90:"E",180:"S",270:"W"}.get(t, str(t))
            self.canvas.create_text(tx, ty, text=label, fill="#9fb4c8", font=("Consolas", 8))
        # needle points to heading
        hdg = heading_deg % 360.0
        angle = math.radians(-90 + hdg)
        nx = cx + math.cos(angle) * (r - 28)
        ny = cy + math.sin(angle) * (r - 28)
        self.canvas.create_line(cx, cy, nx, ny, fill="#ffdd57", width=3)
        self.canvas.create_text(cx, cy + r - 18, text=f"{int(hdg):03d}°", fill=HUD_COLOR, font=("Consolas", 10))

    def draw_turn_slip(self, x, y, size, roll_deg, yaw_rate):
        # Simple turn/slip indicator: bank needle, yaw ball, numeric ticks and readouts
        r = size // 2
        cx, cy = x + r, y + r
        self.draw_gauge_ring(cx, cy, r, label="TURN")
        # semicircle bank scale with numeric labels every 15 degrees
        for t in range(-60, 61, 15):
            angle = math.radians(-90 + t)
            sx = cx + math.cos(angle) * (r - 8)
            sy = cy + math.sin(angle) * (r - 8)
            ex = cx + math.cos(angle) * (r - 2)
            ey = cy + math.sin(angle) * (r - 2)
            self.canvas.create_line(sx, sy, ex, ey, fill="#9fb4c8", width=2)
            lx = cx + math.cos(angle) * (r - 28)
            ly = cy + math.sin(angle) * (r - 28)
            self.canvas.create_text(lx, ly, text=str(t), fill="#9fb4c8", font=("Consolas", 8))

        # bank needle (map -90..90 to -60..60)
        b = clamp(roll_deg, -90.0, 90.0)
        needle_angle = math.radians(-90 + (b / 90.0) * 60.0)
        nx = cx + math.cos(needle_angle) * (r - 18)
        ny = cy + math.sin(needle_angle) * (r - 18)
        self.canvas.create_line(cx, cy, nx, ny, fill="#9ad0ff", width=3)

        # slip ball: yaw_rate -> lateral position
        ball_x = cx + clamp(yaw_rate * 60.0, -r + 12, r - 12)
        ball_y = cy + r - 18
        self.canvas.create_oval(ball_x - 6, ball_y - 6, ball_x + 6, ball_y + 6, fill="#ffffff", outline="#333333")

        # center line
        self.canvas.create_line(cx - r + 6, cy + r - 18, cx + r - 6, cy + r - 18, fill="#444444", width=2)

        # numeric readouts: bank angle and turn rate (deg/s)
        bank_text = f"Bank {int(round(roll_deg)):+}°"
        turn_rate_deg_s = math.degrees(yaw_rate)
        turn_text = f"Turn {turn_rate_deg_s:+.1f}°/s"
        self.canvas.create_text(cx, cy + r + 12, text=bank_text, fill="#ffd166", font=("Consolas", 10))
        self.canvas.create_text(cx, cy + r + 28, text=turn_text, fill="#66c2ff", font=("Consolas", 9))

    # ---------------- AoA indicator (shows stall status) ----------------
    def draw_stall_indicator(self, x, y):
        """
        Draw a compact AoA indicator at (x,y).
        Shows AoA and stall status.
        """
        # small box
        w, h = 120, 36
        cx = x + w // 2
        cy = y + h // 2
        # background
        self.canvas.create_rectangle(x, y, x + w, y + h, fill="#071018", outline="#223344", width=2)
        # AoA numeric
        speed = math.hypot(self.plane.vx, self.plane.vy)
        flight_path_angle = math.atan2(self.plane.vy, self.plane.vx) if speed > 1e-6 else self.plane.heading
        aoa = self.plane.pitch - flight_path_angle
        aoa = (aoa + math.pi) % (2 * math.pi) - math.pi
        aoa_deg = math.degrees(aoa)
        color = "#9fb4c8"
        # AoA text and label
        self.canvas.create_text(x + 8, cy - 6, anchor="w", text=f"AoA {aoa_deg:+.1f}°", fill=color, font=("Consolas", 11))
        # status label: show STALL when stalled
        status_text = "STALL" if getattr(self.plane, "stalled", False) else "OK"
        status_color = "#ff6b6b" if getattr(self.plane, "stalled", False) else "#66c2ff"
        self.canvas.create_text(x + w - 8, cy - 6, anchor="e", text=status_text, fill=status_color, font=("Consolas", 11))

        # --- show flaps and rudder state in the same compact box
        flaps_pct = int(self.plane.flaps * 100)
        rudder_deg = int(self.plane.rudder * 30)  # show rudder as degrees approx
        self.canvas.create_text(x + 8, cy + 10, anchor="w", text=f"Flaps {flaps_pct}%", fill="#9fb4c8", font=("Consolas", 10))
        self.canvas.create_text(x + w - 8, cy + 10, anchor="e", text=f"Rud {rudder_deg:+}°", fill="#9fb4c8", font=("Consolas", 10))

    # ---------------- end analog gauges ----------------

    def draw_horizon(self, cx, cy, w, h, pitch_deg, roll_deg):
        vertical_offset = pitch_deg * PITCH_SCALE
        lateral_offset = roll_deg * ROLL_LATERAL_SCALE
        target_x = cx + lateral_offset
        target_y = cy + vertical_offset
        self.hx += (target_x - self.hx) / SMOOTH
        self.hy += (target_y - self.hy) / SMOOTH

        roll_rad = math.radians(roll_deg)
        pad = max(w, h) * 2
        rect = [(-pad, -pad), (pad, -pad), (pad, pad), (-pad, pad)]
        cosr = math.cos(-roll_rad)
        sinr = math.sin(-roll_rad)
        rot = []
        for (rx, ry) in rect:
            x = rx * cosr - ry * sinr
            y = rx * sinr + ry * cosr
            rot.append((self.hx + x, self.hy + y))

        # sky / ground polygons (unchanged)
        self.canvas.create_polygon(rot[0][0], rot[0][1], rot[1][0], rot[1][1],
                                   self.hx + pad, self.hy - pad, self.hx - pad, self.hy - pad,
                                   fill=SKY_COLOR, outline="")
        self.canvas.create_polygon(rot[2][0], rot[2][1], rot[3][0], rot[3][1],
                                   self.hx + pad, self.hy + pad, self.hx - pad, self.hy + pad,
                                   fill=GROUND_COLOR, outline="")

        # horizon line
        line_len = w * 1.2
        lx1, ly1 = -line_len, 0
        lx2, ly2 = line_len, 0
        x1 = self.hx + (lx1 * cosr - ly1 * sinr)
        y1 = self.hy + (lx1 * sinr + ly1 * cosr)
        x2 = self.hx + (lx2 * cosr - ly2 * sinr)
        y2 = self.hy + (lx2 * sinr + ly2 * cosr)
        self.canvas.create_line(x1, y1, x2, y2, fill=HORIZON_LINE, width=3)

        # center reference needle
        needle_len = 80
        self.canvas.create_line(self.hx - needle_len, self.hy, self.hx + needle_len, self.hy, fill="#ffdd57", width=2)

        # pitch ticks (draw ticks using smoothed horizon so they follow the horizon)
        tick_step = 5
        tick_range = 60
        for deg in range(-tick_range, tick_range + 1, tick_step):
            tick_pitch = deg
            offset = tick_pitch * PITCH_SCALE
            sx1, sy1 = -60, offset
            sx2, sy2 = 60, offset
            tx1 = self.hx + (sx1 * cosr - sy1 * sinr)
            ty1 = self.hy + (sx1 * sinr + sy1 * cosr)
            tx2 = self.hx + (sx2 * cosr - sy2 * sinr)
            ty2 = self.hy + (sx2 * sinr + sy2 * cosr)

            if (tick_pitch + 0) % 10 == 0:
                width = 2
                color = PITCH_TICK_COLOR
            else:
                width = 1
                color = "#bcd6e8"

            self.canvas.create_line(tx1, ty1, tx2, ty2, fill=color, width=width)

        # frame and plane reference (unchanged)
        left = cx - w // 2; top = cy - h // 2; right = cx + w // 2; bottom = cy + h // 2
        self.canvas.create_rectangle(left, top, right, bottom, outline=FRAME_COLOR, width=3)
        self.canvas.create_polygon(cx - 12, cy + 6, cx + 12, cy + 6, cx + 6, cy - 6, cx - 6, cy - 6,
                                   fill=PLANE_REF, outline="#ffffff")

        # --- Draw numeric labels using the smoothed horizon transform so they move like the HUD
        label_max_range = 30.0  # degrees mapped to full gradient
        fade_range_px = h * 0.45  # start fading when label is near instrument edge
        for deg in range(-tick_range, tick_range + 1, 10):  # major ticks only
            tick_pitch = deg
            offset = tick_pitch * PITCH_SCALE
            # compute tick endpoints in rotated/smoothed space (same math used for ticks)
            sx1, sy1 = -60, offset
            sx2, sy2 = 60, offset
            lx = self.hx + (sx1 * cosr - sy1 * sinr)
            ly = self.hy + (sx1 * sinr + sy1 * cosr)
            rx = self.hx + (sx2 * cosr - sy2 * sinr)
            ry = self.hy + (sx2 * sinr + sy2 * cosr)

            # skip labels that are outside the instrument rectangle (quick cull)
            if ly < top + 6 or ly > bottom - 6:
                continue

            label_val = int(round(pitch_deg + deg))
            # color based on distance from center pitch (so center ticks are cool, distant ticks warm)
            base_col = gradient_color(label_val - pitch_deg, max_value=label_max_range)

            # fade factor based on vertical distance from instrument center (0=center, 1=edge)
            dist = abs(ly - cy)
            fade_t = clamp(dist / fade_range_px, 0.0, 1.0)
            # blend toward frame color to simulate fading out
            col = _blend_hex(base_col, FRAME_COLOR, fade_t)

            # left and right labels placed at tick endpoints (move with horizon)
            self.canvas.create_text(lx - 6, ly, text=f"{label_val:+}", fill=col, font=("Consolas", 10), anchor="e")
            self.canvas.create_text(rx + 6, ry, text=f"{label_val:+}", fill=col, font=("Consolas", 10), anchor="w")

        # central numeric pitch readout (large, dynamic) with gradient
        center_col = gradient_color(pitch_deg, max_value=30.0)
        pitch_text = f"{pitch_deg:+.1f}°"
        self.canvas.create_text(cx, top + 18, text=pitch_text, fill=center_col, font=("Consolas", 14, "bold"))

        # small secondary readout showing pitch rate under the center
        pitch_rate_deg_s = math.degrees(self.plane.pitch_rate)
        rate_text = f"{pitch_rate_deg_s:+.1f}°/s"
        self.canvas.create_text(cx, bottom - 18, text=rate_text, fill="#9fb4c8", font=("Consolas", 10))

    def draw_pitch_tape(self, x, y, w, h, pitch_deg):
        """
        Draw pitch tape with numeric tick labels.
        Keeps original tape visuals but adds numeric labels for major ticks
        and a small dynamic numeric box showing pitch and pitch rate.
        """
        # tape background
        self.canvas.create_rectangle(x, y, x + w, y + h, fill=TAPE_BG, outline="#223344", width=2)

        # Dynamic numeric box at top of tape (small, unobtrusive)
        box_h = 40
        box_margin = 6
        bx = x + box_margin
        by = y + box_margin
        bw = w - box_margin * 2
        bh = box_h - box_margin
        # box background
        self.canvas.create_rectangle(bx, by, bx + bw, by + bh, fill="#071018", outline="#2b3b4a", width=2)

        # dynamic numbers
        pitch_val = pitch_deg
        pitch_rate_deg_s = math.degrees(self.plane.pitch_rate)
        flaps_pct = int(getattr(self.plane, "flaps", 0.0) * 100)

        # left: pitch, right: flaps; middle line shows pitch rate
        self.canvas.create_text(bx + 8, by + 6, anchor="nw", text=f"Pitch: {pitch_val:+.1f}°", fill="#66c2ff", font=("Consolas", 11))
        self.canvas.create_text(bx + bw - 8, by + 6, anchor="ne", text=f"Flaps: {flaps_pct}%", fill="#ffd166", font=("Consolas", 11))
        self.canvas.create_text(bx + bw // 2, by + 20, anchor="n", text=f"Rate: {pitch_rate_deg_s:+.1f}°/s", fill="#9fb4c8", font=("Consolas", 10))

        # draw moving tape ticks below the numeric box
        tape_top = y + box_h + 4
        center_y = tape_top + (h - box_h) // 2
        spacing_per_deg = PITCH_SCALE
        major_step = 10
        minor_step = 5

        # compute fractional offset so tape scrolls smoothly with pitch
        frac = (pitch_deg % minor_step) / float(minor_step)
        minor_ticks = 12

        for i in range(-minor_ticks, minor_ticks + 1):
            val_deg = pitch_deg + i * minor_step
            py = center_y - (i * minor_step * spacing_per_deg) + (frac * minor_step * spacing_per_deg)
            if py < tape_top + 8 or py > y + h - 8:
                continue

            if val_deg % major_step == 0:
                # major tick: longer line + numeric label on the right
                self.canvas.create_line(x + 6, py, x + 34, py, fill=TAPE_FILL, width=2)
                # numeric label (show sign) with gradient color (relative to center pitch)
                col = gradient_color(val_deg - pitch_deg, max_value=30.0)
                self.canvas.create_text(x + w - 8, py, text=f"{int(val_deg):+}", fill=col, font=("Consolas", 10), anchor="e")
                # also place a small numeric on the left for quick glance (subtle)
                col_sub = gradient_color(val_deg - pitch_deg, max_value=30.0)
                self.canvas.create_text(x + 8, py, text=f"{int(val_deg):+}", fill=col_sub, font=("Consolas", 8), anchor="w")
            else:
                # minor tick
                self.canvas.create_line(x + 12, py, x + 26, py, fill="#9fb4c8", width=1)

        # center highlight box (original behavior)
        self.canvas.create_rectangle(x + 4, center_y - int(spacing_per_deg * minor_step / 2),
                                     x + w - 4, center_y + int(spacing_per_deg * minor_step / 2),
                                     outline=TAPE_FILL, width=2)

        # central label (keeps original text)
        self.canvas.create_text(x + w // 2, y + 12, text=f"PITCH {pitch_val:+.1f}°", fill=TAPE_FILL, font=("Consolas", 11))

    def draw_terrain(self, cam_x, roll_deg, ground_offset):
        base_y = HEIGHT - 60
        tile_w = TERRAIN_TILE_W
        bank_shift = roll_deg * GROUND_BANK_SHIFT
        abs_roll = abs(roll_deg)
        roll_ratio = clamp(abs_roll / 80.0, 0.0, 1.0)
        speed_multiplier = 1.0 + BANK_SPEED_FACTOR * (roll_ratio ** BANK_EXPONENT)

        # Reverse horizontal ground movement: invert camera world position
        effective_cam_x = cam_x * BASE_SCROLL_FACTOR * speed_multiplier

        # Rudder-driven lateral ground scroll: positive rudder -> extra rightward ground motion
        rudder = getattr(self.plane, "rudder", 0.0)
        plane_speed = math.hypot(self.plane.vx, self.plane.vy)
        speed_scale = clamp(plane_speed / 50.0, 0.0, 2.0)
        # scale effect by speed and bank so it feels natural
        rudder_scroll = rudder * RUDDER_GROUND_SPEED * (0.5 + 0.5 * speed_scale) * (1.0 + 0.6 * roll_ratio)

        # Add rudder scroll to effective camera X (positive rudder shifts ground faster to the right)
        effective_cam_x += rudder_scroll

        world_px = -effective_cam_x
        tile_index = int(world_px // tile_w)
        px_into_tile = world_px % tile_w
        tiles_on_screen = (WIDTH // tile_w) + 6
        max_extra = 40
        extra_tiles = int(round(roll_ratio * max_extra))
        tiles_on_screen += extra_tiles

        # Make ground go up/down with pitch changes
        pitch_deg = math.degrees(self.plane.pitch)
        pitch_vertical_shift = -pitch_deg * PITCH_SCALE
        base_y = base_y + pitch_vertical_shift

        # Reverse lateral ground offset and bank shift signs so left/right are flipped
        start_x = -px_into_tile + int(ground_offset) + int(bank_shift)
        poly_points = []
        for i in range(tiles_on_screen):
            idx = tile_index + i
            h = get_tile_from_storage(idx, self.terrain_seed)
            if h is None:
                h = procedural_tile_height(idx, self.terrain_seed)
            y = base_y - h
            x = start_x + i * tile_w
            poly_points.append((x, y))

        poly = []
        for (x, y) in poly_points:
            poly.append(x); poly.append(y)
        last_x = poly_points[-1][0] + tile_w
        first_x = poly_points[0][0] - tile_w
        poly.append(last_x); poly.append(HEIGHT)
        poly.append(first_x); poly.append(HEIGHT)

        self.canvas.create_polygon(poly, fill=GROUND_COLOR, outline="#1b6b2f")
        for i in range(len(poly_points) - 1):
            x1, y1 = poly_points[i]
            x2, y2 = poly_points[i + 1]
            self.canvas.create_line(x1, y1, x2, y2, fill="#2f8b4a", width=2)

    def draw_stats(self):
        speed = math.hypot(self.plane.vx, self.plane.vy)
        altitude = max(0.0, (HEIGHT - 60) - self.plane.y)
        pitch_deg = math.degrees(self.plane.pitch)
        roll_deg = math.degrees(self.plane.roll)
        throttle_pct = int(self.plane.throttle * 100)
        brakes = "ON" if self.plane.brakes else "OFF"
        status = "CRASHED" if self.plane.crashed else "FLYING"
        lines = [
            f"Speed: {speed:.1f} m/s",
            f"Altitude: {altitude:.1f} m",
            f"Throttle: {throttle_pct}%",
            f"Pitch: {pitch_deg:+.1f}°",
            f"Roll: {roll_deg:+.1f}°",
            f"Brakes: {brakes}",
            f"Status: {status}",
        ]
        x = 12
        y = 12
        for i, line in enumerate(lines):
            self.canvas.create_text(x, y + i * 18, anchor="nw", text=line, fill=HUD_COLOR, font=("Consolas", 12))

    def loop(self):
        controls = self.get_controls()
        self.plane.update(DT, controls)
        self.canvas.delete("all")
        self.canvas.create_rectangle(0, 0, WIDTH, HEIGHT, fill=SKY_COLOR, width=0)
        pitch_deg = math.degrees(self.plane.pitch)
        roll_deg = math.degrees(self.plane.roll)
        self.draw_horizon(WIDTH // 2, HEIGHT // 2 - 40, 700, 300, pitch_deg, roll_deg)
        cam_x = self.plane.x
        self.draw_terrain(cam_x, roll_deg, self.plane.ground_offset)
        # pitch tape on right
        tape_w = 120
        tape_h = 260
        tape_x = WIDTH - tape_w - 12
        tape_y = 60
        self.draw_pitch_tape(tape_x, tape_y, tape_w, tape_h, pitch_deg)
        # AoA indicator (shows stall status)
        self.draw_stall_indicator(12, 320)
        # analog gauges (left side cluster)
        gsize = 110
        margin = 12
        left_x = margin
        top_y = HEIGHT - gsize - margin
        # Airspeed
        speed = math.hypot(self.plane.vx, self.plane.vy)
        self.draw_airspeed_gauge(left_x, top_y, gsize, speed)
        # Altimeter (to the right of airspeed)
        self.draw_altimeter(left_x + gsize + 8, top_y, gsize, max(0.0, (HEIGHT - 60) - self.plane.y))
        # Heading (above airspeed)
        self.draw_heading_gauge(left_x, top_y - gsize - 8, gsize, math.degrees(self.plane.heading))
        # Turn/slip (above altimeter)
        self.draw_turn_slip(left_x + gsize + 8, top_y - gsize - 8, gsize, math.degrees(self.plane.roll), self.plane.yaw_rate)
        self.draw_stats()
        if self.plane.crashed:
            self.canvas.create_text(WIDTH // 2, HEIGHT // 2 - 120, text="CRASHED - Press R to reset",
                                    fill="#ff6060", font=("Consolas", 28))
        if self.running:
            self.root.after(int(DT * 1000), self.loop)

    def on_close(self):
        try:
            self.stop_event.set()
            self.streamer.join(timeout=1.0)
        except Exception:
            pass
        self.running = False
        try:
            self.root.destroy()
        except Exception:
            pass

def main():
    root = tk.Tk()
    app = HorizonApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
