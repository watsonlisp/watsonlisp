#!/usr/bin/env python3
"""
Round Eject Button GUI (cross-platform) with siren sound on press.
Run with Python 3. Requires tkinter (usually bundled) and platform eject utilities.
"""

import platform
import subprocess
import ctypes
import sys
import threading
import shutil
import tempfile
import wave
import struct
import math
import os
import tkinter as tk
from tkinter import messagebox

# -------------------------
# Platform eject functions
# -------------------------
def open_on_windows():
    try:
        mci = ctypes.windll.winmm.mciSendStringW
    except Exception:
        raise RuntimeError("Windows MCI interface not available")

    def _call(cmd):
        buf = ctypes.create_unicode_buffer(255)
        res = mci(cmd, buf, 254, 0)
        return res, buf.value

    res, out = _call("set cdaudio door open")
    if res == 0:
        return
    res, out = _call("open cdaudio")
    if res != 0:
        raise RuntimeError(f"mci open failed ({res}): {out or 'no output'}")
    res, out = _call("set cdaudio door open")
    if res != 0:
        raise RuntimeError(f"mci set door open failed ({res}): {out or 'no output'}")

def open_on_linux():
    eject_path = shutil.which("eject")
    if not eject_path:
        raise RuntimeError("'eject' utility not found. Install it (e.g., apt install eject).")
    try:
        proc = subprocess.run([eject_path], check=True, capture_output=True, text=True, timeout=10)
    except subprocess.CalledProcessError as e:
        out = (e.stderr or e.stdout or "").strip()
        raise RuntimeError(f"Linux eject failed: {out or str(e)}")
    except subprocess.TimeoutExpired:
        raise RuntimeError("Linux eject timed out.")

def open_on_macos():
    drutil = shutil.which("drutil")
    if drutil:
        try:
            subprocess.run([drutil, "tray", "open"], check=True, capture_output=True, text=True, timeout=10)
            return
        except subprocess.CalledProcessError:
            try:
                subprocess.run([drutil, "eject"], check=True, capture_output=True, text=True, timeout=10)
                return
            except subprocess.CalledProcessError:
                pass
    osascript = shutil.which("osascript")
    if not osascript:
        raise RuntimeError("No drutil or osascript found to eject drives on macOS.")
    applescript = 'tell application "Finder" to eject (every disk whose ejectable is true)'
    try:
        subprocess.run([osascript, "-e", applescript], check=True, capture_output=True, text=True, timeout=10)
    except subprocess.CalledProcessError as e:
        out = (e.stderr or e.stdout or "").strip()
        raise RuntimeError(f"macOS eject failed: {out or str(e)}")

def send_eject_command():
    os_name = platform.system()
    if os_name == "Windows":
        open_on_windows()
    elif os_name == "Linux":
        open_on_linux()
    elif os_name == "Darwin":
        open_on_macos()
    else:
        raise RuntimeError(f"Unsupported OS: {os_name}")

# -------------------------
# Red Alert siren synthesis and playback
# -------------------------
def synthesize_siren_wav(path, duration=2.0, sr=44100):
    """
    Synthesize a Star Trek style "Red Alert" siren and write to `path` as 16-bit mono WAV.
    Two alternating tones (high piercing and low horn), fast amplitude gating (staccato),
    slight vibrato, and a short rising sweep at the start for drama.
    """
    n_samples = int(sr * duration)
    max_amp = 0.9 * 32767

    # Tone settings
    high_f = 1200.0        # piercing tone (Hz)
    low_f = 420.0          # lower horn tone (Hz)
    alternation_rate = 6.0 # Hz: how fast tones alternate
    pulse_rate = 10.0      # Hz: amplitude gating (gives the staccato "red alert" pulse)
    vibrato_rate = 8.0     # Hz vibrato on each tone
    vibrato_depth = 6.0    # Hz vibrato depth
    sweep_amount = 220.0   # Hz initial sweep up on the high tone
    sweep_time = 0.18      # seconds for the initial sweep

    samples = bytearray()
    for i in range(n_samples):
        t = i / sr

        # initial short rising sweep factor (applies mainly to the high tone)
        if t < sweep_time:
            sweep = (t / sweep_time)
            sweep_factor = 1.0 + (sweep * (sweep_amount / high_f))
        else:
            sweep_factor = 1.0

        # alternate between high and low tone using a square LFO
        lfo = math.sin(2.0 * math.pi * alternation_rate * t)
        alt = 1.0 if lfo >= 0.0 else 0.0
        tone_freq = (high_f * sweep_factor) if alt >= 0.5 else low_f

        # vibrato (small frequency modulation)
        vibrato = vibrato_depth * math.sin(2.0 * math.pi * vibrato_rate * t)
        instantaneous_freq = tone_freq + vibrato

        # phase for sine wave
        phase = 2.0 * math.pi * instantaneous_freq * t

        # richer waveform: mix sine with a softened saw component
        sine = math.sin(phase)
        # band-limited-ish saw approximation (naive, but softened)
        saw = 2.0 * (phase / (2.0 * math.pi) - math.floor(0.5 + phase / (2.0 * math.pi)))
        tone = 0.78 * sine + 0.22 * saw

        # amplitude gating to create the staccato pulse
        pulse = 0.5 * (1.0 + math.sin(2.0 * math.pi * pulse_rate * t))
        # sharpen the pulse envelope to make it more on/off
        amp_env = pulse ** 6

        # small low rumble to add body
        rumble = 0.08 * math.sin(2.0 * math.pi * 60.0 * t)

        sample_val = (tone * amp_env + rumble) * max_amp

        # clamp to 16-bit range
        if sample_val > 32767:
            sample_val = 32767
        elif sample_val < -32768:
            sample_val = -32768

        samples.extend(struct.pack('<h', int(sample_val)))

    # write WAV
    with wave.open(path, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(bytes(samples))

def play_wav_file(path):
    """
    Play WAV file at path using platform-appropriate player.
    Blocks until playback finishes.
    """
    os_name = platform.system()
    if os_name == "Windows":
        try:
            import winsound
            winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_SYNC)
            return
        except Exception:
            # fallback to PowerShell player
            ps = shutil.which("powershell") or shutil.which("pwsh")
            if ps:
                cmd = [ps, "-NoProfile", "-Command",
                       f"(New-Object Media.SoundPlayer '{path}').PlaySync();"]
                subprocess.run(cmd, check=False)
                return
            raise RuntimeError("No available audio playback method on Windows.")
    elif os_name == "Darwin":
        player = shutil.which("afplay")
        if player:
            subprocess.run([player, path], check=True)
            return
        raise RuntimeError("afplay not found on macOS.")
    else:  # assume Linux-like
        for player in ("aplay", "paplay", "play"):
            p = shutil.which(player)
            if p:
                subprocess.run([p, path], check=True)
                return
        raise RuntimeError("No audio player found (aplay/paplay/play). Install one to enable siren playback.")

def play_siren(duration=2.0):
    """
    Synthesize a temporary WAV siren and play it. Cleans up the temp file.
    """
    tmp = None
    try:
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
        tmp.close()
        synthesize_siren_wav(tmp.name, duration=duration)
        play_wav_file(tmp.name)
    finally:
        if tmp is not None:
            try:
                os.unlink(tmp.name)
            except Exception:
                pass

# -------------------------
# Text to speech (no external packages)
# -------------------------
def play_tts(text, timeout=10):
    """
    Cross-platform TTS using system tools only.
    - Windows: PowerShell + System.Speech (reads from stdin)
    - macOS: say
    - Linux: espeak or spd-say if available
    Runs synchronously; caller should start it in a background thread if non-blocking behavior is desired.
    """
    os_name = platform.system()
    # Windows: use PowerShell SAPI and pipe text to stdin to avoid quoting issues
    if os_name == "Windows":
        ps = shutil.which("powershell") or shutil.which("pwsh")
        if ps:
            cmd = [ps, "-NoProfile", "-Command",
                   "Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak([Console]::In.ReadToEnd())"]
            try:
                p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True)
                p.communicate(text, timeout=timeout)
                return
            except Exception:
                pass
    # macOS: use `say`
    if os_name == "Darwin":
        say = shutil.which("say")
        if say:
            try:
                subprocess.run([say, text], check=False, timeout=timeout)
                return
            except Exception:
                pass
    # Linux / other: try espeak or spd-say
    for tts_cmd in ("espeak", "spd-say"):
        pth = shutil.which(tts_cmd)
        if pth:
            try:
                subprocess.run([pth, text], check=False, timeout=timeout)
                return
            except Exception:
                pass
    # No TTS available: silently return
    return

# -------------------------
# GUI: round button on Canvas
# -------------------------
class RoundEjectApp:
    def __init__(self, root):
        self.root = root
        root.title("Eject Optical Drive")
        root.resizable(False, False)

        self.size = 320
        self.canvas = tk.Canvas(root, width=self.size, height=self.size, highlightthickness=0)
        self.canvas.pack()

        # Circle geometry
        pad = 24
        self.cx = self.cy = self.size // 2
        self.radius = (self.size // 2) - pad

        # Colors
        self.base_color = "#c62828"      # red
        self.hover_color = "#b71c1c"     # darker red
        self.blink_color = "#ffeb3b"     # yellow for blink
        self.outline_color = "#7f0000"
        self.text_color = "white"

        # Draw circle and text
        self.circle = self.canvas.create_oval(
            self.cx - self.radius, self.cy - self.radius,
            self.cx + self.radius, self.cy + self.radius,
            fill=self.base_color, outline=self.outline_color, width=4
        )
        self.label = self.canvas.create_text(
            self.cx, self.cy, text="EJECT", fill=self.text_color,
            font=("Helvetica", 36, "bold")
        )

        # Bind events
        self.canvas.tag_bind(self.circle, "<Button-1>", self.on_click)
        self.canvas.tag_bind(self.label, "<Button-1>", self.on_click)
        self.canvas.bind("<Motion>", self.on_motion)
        self.canvas.bind("<Leave>", self.on_leave)
        root.bind("<Return>", lambda e: self.trigger_eject())
        root.bind("<space>", lambda e: self.trigger_eject())

        # Accessibility hint
        self.canvas.create_text(self.size//2, self.size - 12,
                                text="Press Enter or Space to eject", fill="#333",
                                font=("Helvetica", 9))

        # Busy flag to prevent concurrent actions
        self.busy = False

        # Optional safety toggle: set to True to require confirmation
        self.require_confirm = False

        # Blinking state
        self._blinking = False
        self._blink_after_id = None

    def point_in_circle(self, x, y):
        dx = x - self.cx
        dy = y - self.cy
        return (dx*dx + dy*dy) <= (self.radius * self.radius)

    def on_click(self, event):
        if self.busy:
            return
        if self.point_in_circle(event.x, event.y):
            self.trigger_eject()

    def on_motion(self, event):
        if self.point_in_circle(event.x, event.y):
            # only change hover color if not currently blinking
            if not self._blinking:
                self.canvas.itemconfig(self.circle, fill=self.hover_color)
            self.canvas.config(cursor="hand2")
        else:
            if not self._blinking:
                self.canvas.itemconfig(self.circle, fill=self.base_color)
            self.canvas.config(cursor="")

    def on_leave(self, event):
        if not self._blinking:
            self.canvas.itemconfig(self.circle, fill=self.base_color)
        self.canvas.config(cursor="")

    def trigger_eject(self):
        if self.busy:
            return
        # If require_confirm is True, show the confirmation dialog; otherwise proceed immediately
        if self.require_confirm:
            if not messagebox.askokcancel("Confirm Eject", "This will attempt to eject any ejectable media. Continue?"):
                return
        self.busy = True
        self.canvas.itemconfig(self.label, text="WAIT")

        # Speak the line (non-blocking)
        threading.Thread(target=lambda: play_tts("I will open the pod bay doors"), daemon=True).start()

        # Start blinking animation (non-blocking)
        # duration in ms, interval in ms
        self._start_blink(duration=1200, interval=120)

        # Start siren immediately in background
        threading.Thread(target=lambda: play_siren(duration=2.0), daemon=True).start()
        # Start eject in background
        thread = threading.Thread(target=self._eject_thread, daemon=True)
        thread.start()

    def _start_blink(self, duration=1000, interval=150):
        """
        Blink the circle by toggling between blink_color and base_color.
        duration: total blink time in milliseconds
        interval: toggle interval in milliseconds
        """
        if self._blinking:
            return
        self._blinking = True
        self._blink_interval = interval
        self._blink_steps = max(1, duration // interval)
        self._blink_step_index = 0
        # ensure we start with blink color for visibility
        self.canvas.itemconfig(self.circle, fill=self.blink_color)
        # schedule first step
        self._blink_after_id = self.root.after(self._blink_interval, self._blink_step)

    def _blink_step(self):
        # toggle color between base and blink color
        if self._blink_step_index % 2 == 0:
            self.canvas.itemconfig(self.circle, fill=self.base_color)
        else:
            self.canvas.itemconfig(self.circle, fill=self.blink_color)
        self._blink_step_index += 1
        if self._blink_step_index < self._blink_steps:
            self._blink_after_id = self.root.after(self._blink_interval, self._blink_step)
        else:
            # end blinking, restore normal state
            self._blinking = False
            self._blink_after_id = None
            self.canvas.itemconfig(self.circle, fill=self.base_color)

    def _eject_thread(self):
        try:
            send_eject_command()
            self._show_info("Eject", "Eject command sent.")
        except Exception as e:
            self._show_error("Error", str(e))
        finally:
            # restore UI on main thread after a short delay so blink/siren finish
            self.root.after(200, self._restore_ui)

    def _restore_ui(self):
        # cancel any pending blink if still active
        if self._blink_after_id is not None:
            try:
                self.root.after_cancel(self._blink_after_id)
            except Exception:
                pass
            self._blink_after_id = None
            self._blinking = False
            self.canvas.itemconfig(self.circle, fill=self.base_color)

        self.busy = False
        self.canvas.itemconfig(self.label, text="EJECT")

    def _show_info(self, title, msg):
        self.root.after(0, lambda: messagebox.showinfo(title, msg))

    def _show_error(self, title, msg):
        self.root.after(0, lambda: messagebox.showerror(title, msg))

# -------------------------
# Run app
# -------------------------
def main():
    root = tk.Tk()
    app = RoundEjectApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
