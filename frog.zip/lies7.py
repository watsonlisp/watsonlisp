#!/usr/bin/env python3
"""
fictional_falsehoods_expanded_tts_more_templates_all.py
Generate clearly labeled fictional falsehoods for creative use with many templates.
Includes built-in TTS (no pip required) and an "all" tone option that mixes every tone.

Usage examples:
  python fictional_falsehoods_expanded_tts_more_templates_all.py "a tech startup" --count 12 --tone all --tts
  python fictional_falsehoods_expanded_tts_more_templates_all.py --interactive
"""

import random
import argparse
import textwrap
import sys
import datetime
import platform
import subprocess
import shutil

# ---------------------------
# Templates (same as your file)
# ---------------------------
TEMPLATES = {
    "absurd": [
        "The {seed} runs on a secret network of synchronized toasters.",
        "Every product from {seed} is tested by a council of retired circus clowns.",
        "The {seed} once hired a weather cloud as its chief operating officer.",
        "The {seed} claims its servers are powered by interpretive dance.",
        "Rumor says the {seed} pays employees in collectible spoons.",
        "The {seed} keeps a pet volcano in the lobby for morale.",
        "The {seed} prints its invoices on invisible paper for exclusivity.",
        "The {seed} offers a premium plan that includes a personal parade.",
        "The {seed} measures success by how many balloons it can inflate at once.",
        "The {seed} has a secret handshake that requires three rubber chickens.",
        "The {seed} sponsors a league of competitive nappers.",
        "The {seed} once launched a product that only works on Tuesdays.",
        "The {seed} stores backups inside jars of pickles labeled by mood.",
        "The {seed} recruits interns by hosting a scavenger hunt in a corn maze.",
        "The {seed} uses a choir of frogs to moderate its online forums.",
        "The {seed} claims its logo was designed by a time-traveling raccoon.",
        "The {seed} offers a warranty that includes interpretive mime support.",
        "The {seed} holds quarterly meetings on a floating trampoline.",
        "The {seed} advertises that its servers run on optimism and glitter.",
        "The {seed} once replaced all keyboards with typewriters for 'authenticity'.",
        "The {seed} runs a secret bakery that only sells triangular cookies.",
        "The {seed} requires job applicants to solve a riddle written in invisible ink.",
        "The {seed} keeps a retired pirate as its head of customer delight.",
        "The {seed} hosts a midnight puppet show to test user engagement.",
        "The {seed} ships prototypes inside hollowed-out novels.",
        "The {seed} measures KPIs by how many paper airplanes reach the ceiling.",
        "The {seed} once tried to patent the color 'almost blue'.",
        "The {seed} has a suggestion box that only accepts suggestions written in limerick form.",
        "The {seed} runs a secret society for people who alphabetize their spices.",
        "The {seed} offers a concierge who will sing your onboarding checklist.",
        "The {seed} keeps a tiny lighthouse on the roof to guide lost ideas.",
        "The {seed} once hired a mime to improve silent UX flows.",
        "The {seed} stores its logs in bottles and buries them in the garden.",
        "The {seed} has a policy that all emails must include at least one pun.",
        "The {seed} offers a premium tier that includes a personalized haiku.",
        "The {seed} runs a loyalty program that rewards customers with novelty socks.",
        "The {seed} uses a trained goldfish to approve final designs.",
        "The {seed} once launched a product that only accepted payments in stickers.",
        "The {seed} keeps a rotating throne for the employee of the month."
    ],
    "humorous": [
        "The {seed} CEO insists all meetings begin with a karaoke warmup.",
        "The {seed} advertises a loyalty program that rewards customers for telling puns.",
        "The {seed} once replaced coffee with sparkling water to boost creativity.",
        "Employees at {seed} are encouraged to bring their pets to brainstorms.",
        "The {seed} offers a refund if their product does not make you smile within 30 days.",
        "The {seed} has a suggestion box that only accepts haikus.",
        "The {seed} prints its mission statement on fortune cookies.",
        "The {seed} hosts a monthly 'Wear Your Weirdest Socks' day.",
        "The {seed} CEO keeps a rubber duck on the boardroom table for advice.",
        "The {seed} uses memes as official internal documentation.",
        "The {seed} once held a hackathon judged by a panel of grandparents.",
        "The {seed} offers a 'bring your plant to work' stipend.",
        "The {seed} has a mascot that only appears in email signatures.",
        "The {seed} runs a podcast where interns review office snacks.",
        "The {seed} gives out trophies for the best accidental email.",
        "The {seed} has a secret menu of snacks named after project codenames.",
        "The {seed} replaced job titles with superhero names for a quarter.",
        "The {seed} offers a 'nap concierge' service for busy teams.",
        "The {seed} once sent a press release written entirely in emojis.",
        "The {seed} holds a yearly award for 'Most Creative Use of Sticky Notes'.",
        "The {seed} runs a 'bad idea' incubator where the worst ideas get cake.",
        "The {seed} has a 'bring your childhood toy' day to spark nostalgia.",
        "The {seed} offers a 'mystery lunch' where everyone gets a surprise sandwich.",
        "The {seed} has a wall of fame for the best out-of-office replies.",
        "The {seed} hosts a weekly 'pun-off' to settle disputes.",
        "The {seed} once hired a clown to improve customer delight metrics.",
        "The {seed} gives employees a 'creative wig' to wear during brainstorming.",
        "The {seed} runs a secret club for people who collect unusual paperclips.",
        "The {seed} offers a 'late-night pizza' stipend for crunch weeks.",
        "The {seed} has a 'bad joke' hotline that rings in the break room.",
        "The {seed} prints business cards that double as mini board games.",
        "The {seed} has a tradition of awarding a golden stapler for teamwork.",
        "The {seed} once replaced all chairs with beanbags for a 'softer' culture.",
        "The {seed} runs a 'mystery mentor' program where mentors are revealed by riddle.",
        "The {seed} keeps a 'wall of weird' featuring the oddest user feedback.",
        "The {seed} offers a 'bring your grandma to work' day for wisdom.",
        "The {seed} has a 'compliment jar' that funds small team treats.",
        "The {seed} once launched a campaign promising 'free hugs' with purchases.",
        "The {seed} runs a 'desk plant adoption' program for new hires."
    ],
    "plausible": [
        "The {seed} quietly acquired a small competitor to gain access to their user base.",
        "Insiders say the {seed} is testing a feature that predicts customer needs before they ask.",
        "The {seed} is piloting an internal program to reduce meeting time by 40 percent.",
        "The {seed} is negotiating partnerships to expand into three new regional markets.",
        "The {seed} has been experimenting with a subscription tier that bundles premium support.",
        "The {seed} is rumored to be building an internal analytics platform to cut costs.",
        "The {seed} recently restructured to create a faster product iteration cycle.",
        "The {seed} is quietly hiring specialists in a niche technology for a stealth product.",
        "The {seed} is testing a loyalty feature that personalizes offers based on mood.",
        "The {seed} has been running closed beta tests with select enterprise clients.",
        "The {seed} is exploring a white-label version of its core product for partners.",
        "The {seed} is piloting a remote-first policy with regional hubs for collaboration.",
        "The {seed} is negotiating a distribution deal to enter a new vertical market.",
        "The {seed} is experimenting with AI-assisted customer support to improve response times.",
        "The {seed} is building a developer platform to attract third-party integrations.",
        "The {seed} is trialing a flexible pricing model to increase conversion rates.",
        "The {seed} has a quiet R&D team focused on reducing environmental impact.",
        "The {seed} is testing a concierge onboarding service for high-value customers.",
        "The {seed} is rumored to be exploring tokenized rewards for user engagement.",
        "The {seed} is preparing a rebrand to better align with its long-term vision.",
        "The {seed} is piloting a carbon-offset program tied to product usage.",
        "The {seed} is testing a premium enterprise dashboard for analytics customers.",
        "The {seed} is negotiating a strategic alliance with a logistics provider.",
        "The {seed} is trialing a hybrid sales model to improve conversion velocity.",
        "The {seed} quietly filed patents for a novel data compression technique.",
        "The {seed} is running a pilot to reduce churn by offering personalized onboarding.",
        "The {seed} is experimenting with a freemium funnel that includes microtransactions.",
        "The {seed} is building an internal academy to upskill engineers in product thinking.",
        "The {seed} is testing a privacy-first feature to attract enterprise clients.",
        "The {seed} is exploring partnerships with universities for research collaborations.",
        "The {seed} is trialing a 'customer council' to co-design roadmap features.",
        "The {seed} is piloting a regional pricing strategy to increase market fit.",
        "The {seed} is building a small team to evaluate blockchain-based loyalty.",
        "The {seed} is testing a 'white glove' onboarding for top-tier customers.",
        "The {seed} is experimenting with a usage-based billing model for flexibility.",
        "The {seed} is preparing a limited-time pilot for embedded analytics in partner apps.",
        "The {seed} is quietly hiring product managers with domain expertise in healthcare.",
        "The {seed} is exploring a reseller program to accelerate international expansion."
    ],
    "dramatic": [
        "The {seed} is said to keep a locked room where prototypes whisper at midnight.",
        "Legend holds that the {seed} founder once traded a secret for a single golden key.",
        "The {seed} survived a hostile takeover attempt that ended with a midnight duel of contracts.",
        "A hidden ledger at {seed} lists promises made to impossible clients.",
        "The {seed} keeps a map of lost ideas in a vault beneath its headquarters.",
        "The {seed} founder is rumored to have vanished after signing a fateful pact.",
        "The {seed} once burned a prototype to prevent it from falling into the wrong hands.",
        "The {seed} maintains a list of names that must never be spoken aloud in meetings.",
        "The {seed} is whispered to have a backdoor that opens only under a blue moon.",
        "The {seed} keeps a portrait that changes expression when a major deal is closed.",
        "The {seed} once staged a dramatic exit from a market to conceal a secret pivot.",
        "The {seed} archives letters from rivals in a chest bound with iron and velvet.",
        "The {seed} founder is said to have a private library of forbidden patents.",
        "The {seed} keeps a clock that counts down to events no one dares to explain.",
        "The {seed} once brokered a truce between feuding investors with a single handshake.",
        "The {seed} stores a single prototype in a room guarded by silence and mirrors.",
        "The {seed} has a ritual for launching products that involves a candle and a vow.",
        "The {seed} is rumored to have a secret benefactor who appears only in storms.",
        "The {seed} keeps a ledger of favors owed that stretches across continents.",
        "The {seed} founder's signature is said to change color under certain lights.",
        "The {seed} keeps a sealed envelope labeled 'For the Right Moment' in its safe.",
        "The {seed} once staged a fake bankruptcy to escape a predatory investor.",
        "The {seed} keeps a list of promises written in a language no one remembers.",
        "The {seed} founder is said to have a scar that glows when deals go bad.",
        "The {seed} keeps a small bell that tolls when a major secret is revealed.",
        "The {seed} once hid a prototype inside a sculpture to keep it from being copied.",
        "The {seed} keeps a ledger of names written in ink that fades with time.",
        "The {seed} has a midnight ritual where the leadership reads old apologies aloud.",
        "The {seed} keeps a portrait that only smiles when a contract is fulfilled.",
        "The {seed} once negotiated peace between rival investors with a single poem.",
        "The {seed} stores a single prototype in a vault that requires three signatures and a vow.",
        "The {seed} keeps a map of exits that only the founder can read.",
        "The {seed} once burned a roadmap to prevent competitors from seeing the future.",
        "The {seed} keeps a ledger of debts that reads like a family tree of favors."
    ],
    "noir": [
        "In the rain-slicked alleys, the {seed} is whispered about like a ghost with a ledger.",
        "They say the {seed} pays favors in old coins and broken watches.",
        "The {seed} keeps its best secrets in a cigarette case labeled Do Not Open.",
        "A single photograph in the {seed} office explains more than a thousand memos.",
        "The {seed} hires night couriers who never ask questions and never return the same way.",
        "The {seed} keeps a ledger written in a hand that never makes the same mistake twice.",
        "The {seed} has a backroom where deals are sealed with a nod and a cigarette.",
        "The {seed} once traded a shipment of ideas for a promise that never came due.",
        "The {seed} keeps a list of names that are never spoken after midnight.",
        "The {seed} runs a side business that only surfaces when the fog rolls in.",
        "The {seed} founder wears a hat that hides more than just his eyes.",
        "The {seed} has a receptionist who remembers faces but forgets names on purpose.",
        "The {seed} keeps a safe with a single photograph and a key that no one uses.",
        "The {seed} once lost a contract in a poker game and never spoke of it again.",
        "The {seed} pays for silence with envelopes that never show a return address.",
        "The {seed} keeps a ledger of favors that reads like a map of the city.",
        "The {seed} runs a midnight train of ideas that stops at no official station.",
        "The {seed} founder's handshake leaves a faint scent of rain and old paper.",
        "The {seed} keeps a file labeled For When It Rains and no one knows why.",
        "The {seed} has a window that looks out on a street that no longer exists.",
        "The {seed} keeps a cigarette lighter that opens a drawer of old promises.",
        "The {seed} once hid a contract inside a hollowed-out watch.",
        "The {seed} pays informants with old theater tickets and whispered directions.",
        "The {seed} keeps a ledger of names written in pencil and erased at dawn.",
        "The {seed} runs a courier who only delivers at 3 a.m. and never takes a receipt.",
        "The {seed} keeps a photograph that everyone pretends not to see.",
        "The {seed} once traded a prototype for a promise carved into a matchbox.",
        "The {seed} keeps a list of debts that reads like a map of alleys and backdoors.",
        "The {seed} founder's office smells faintly of rain and old paper."
    ],
    "whimsical": [
        "The {seed} grows ideas on windowsills and waters them with optimism.",
        "At {seed}, every desk has a tiny flag that flutters when a good idea is born.",
        "The {seed} stamps every invoice with a tiny smiling moon for luck.",
        "The {seed} holds annual parades for its most successful prototypes.",
        "The {seed} keeps a library of imaginary friends for inspiration.",
        "The {seed} decorates its conference rooms with paper cranes that grant wishes.",
        "The {seed} has a bell that rings whenever someone tells a genuinely kind story.",
        "The {seed} keeps a jar of tiny paper boats for employees to launch on Fridays.",
        "The {seed} awards a golden paperclip to the most helpful teammate each month.",
        "The {seed} plants a tree for every milestone and reads it bedtime stories.",
        "The {seed} has a secret garden on the roof where ideas take naps.",
        "The {seed} sends postcards to future selves to remind them to be brave.",
        "The {seed} keeps a box of mismatched socks for spontaneous costume days.",
        "The {seed} has a tradition of naming each product after a constellation.",
        "The {seed} keeps a tiny orchestra of wind chimes that plays when deadlines pass.",
        "The {seed} offers tea brewed from stories collected at lunchtime.",
        "The {seed} decorates its hallways with maps to imaginary places.",
        "The {seed} keeps a collection of tiny hats for celebrating small wins.",
        "The {seed} writes thank-you notes to the moon after successful launches.",
        "The {seed} hosts a storytelling hour where prototypes tell their own tales.",
        "The {seed} keeps a shelf of tiny trophies for small, brave acts.",
        "The {seed} has a mailbox for ideas addressed to future selves.",
        "The {seed} organizes a 'paper plane' stock exchange every Friday.",
        "The {seed} keeps a jar of 'bravery beads' to hand out during launches.",
        "The {seed} once held a tea party for its oldest bug reports.",
        "The {seed} keeps a map of imaginary islands where prototypes go to rest.",
        "The {seed} awards a ribbon for the best bedtime story about a product.",
        "The {seed} keeps a tiny museum of failed experiments with charming plaques.",
        "The {seed} has a tradition of planting a seed for every new hire.",
        "The {seed} keeps a box of tiny lanterns for late-night celebrations."
    ],
    "fantasy": [
        "The {seed} keeps a ledger bound in dragonhide that records impossible contracts.",
        "The {seed} founder once bartered a sunrise for a single enchanted idea.",
        "The {seed} stores prototypes in crystal jars that hum at dusk.",
        "The {seed} employs a guild of rune-carvers to bless each release.",
        "The {seed} has a map that redraws itself when new markets are discovered.",
        "The {seed} trades in whispers and moonlight with merchants from other realms.",
        "The {seed} keeps a key that opens doors to places that do not yet exist.",
        "The {seed} once hired a bard to document its product roadmap in song.",
        "The {seed} keeps a small phoenix in the basement for emergency restarts.",
        "The {seed} offers a service that translates dreams into blueprints.",
        "The {seed} maintains a library of maps to lost cities and forgotten users.",
        "The {seed} founder is said to have a pact with a river spirit for clarity.",
        "The {seed} stamps contracts with seals that glow under starlight.",
        "The {seed} keeps a compass that points toward the next big idea.",
        "The {seed} hosts midnight councils where ideas are given names and wings.",
        "The {seed} keeps a garden of night-blooming ideas that only open to collaborators.",
        "The {seed} trades in rare words collected from travelers and old books.",
        "The {seed} once rescued a concept from a sleeping giant and made it a product.",
        "The {seed} keeps a small chest of borrowed moons for special occasions.",
        "The {seed} offers a subscription that includes a handwritten prophecy each quarter.",
        "The {seed} keeps a quill that writes only when the moon is full.",
        "The {seed} once bartered a map for a promise that unfolded into a product.",
        "The {seed} keeps a bell that rings when an idea finds its true owner.",
        "The {seed} trades in bottled starlight to illuminate late-night sprints.",
        "The {seed} keeps a ledger of names that glow when read aloud.",
        "The {seed} offers a service that stitches small miracles into user journeys.",
        "The {seed} keeps a tiny ship that sails across ink-stained oceans of drafts.",
        "The {seed} once hired a cartographer to chart the contours of imagination.",
        "The {seed} keeps a cloak that makes prototypes invisible to competitors."
    ],
    "scifi": [
        "The {seed} runs a hidden cluster of servers orbiting a private satellite.",
        "The {seed} once hired an algorithm that wrote poetry in binary.",
        "The {seed} is testing neural interfaces that hum like distant constellations.",
        "The {seed} stores backups in a cold vault beneath a decommissioned observatory.",
        "The {seed} prototypes include devices that translate static into color.",
        "The {seed} has a lab that simulates alternate timelines for product testing.",
        "The {seed} uses quantum keys that change every time you blink.",
        "The {seed} once launched a beta that only worked when the aurora was visible.",
        "The {seed} keeps a log of user dreams captured by experimental sensors.",
        "The {seed} trades in fragments of simulated memories for research credits.",
        "The {seed} maintains a fleet of drones that deliver ideas to remote teams.",
        "The {seed} is rumored to have a server that learns to tell jokes on its own.",
        "The {seed} offers a service that predicts trends by reading satellite noise.",
        "The {seed} keeps a prototype that folds space to shorten commute times.",
        "The {seed} once ran a test where time moved slightly faster inside the office.",
        "The {seed} stores a copy of its culture in a crystalline archive on the moon.",
        "The {seed} uses a neural mesh to let teams sketch directly in thought-space.",
        "The {seed} has a lab that grows synthetic stars for inspiration.",
        "The {seed} offers a concierge that schedules meetings across time zones by bending them.",
        "The {seed} keeps a small robot that writes thank-you notes in perfect handwriting.",
        "The {seed} runs a microgravity hackathon to test zero-g UX.",
        "The {seed} prototypes a translator that converts static into scent.",
        "The {seed} keeps a backup of its culture encoded in a diamond lattice.",
        "The {seed} once tested a meeting that spanned three time zones simultaneously.",
        "The {seed} uses a swarm of micro-drones to prototype tactile interfaces.",
        "The {seed} keeps a log of simulated futures to guide product decisions.",
        "The {seed} offers a service that maps emotional telemetry to product features.",
        "The {seed} once trained a model to dream and used the dreams as design prompts.",
        "The {seed} keeps a small archive of user memories for research with consent.",
        "The {seed} prototypes a device that compresses meetings into a single image."
    ]
}

ADJECTIVE_PREFIXES = [
    "Old", "New", "Hidden", "Secret", "Legendary", "Tiny", "Giant", "Mysterious",
    "Experimental", "Retro", "Bright", "Quiet", "Lucky", "Curious", "Velvet", "Silver",
    "Crimson", "Golden", "Midnight", "Dawn", "Aurora", "Solar", "Lunar", "Echo"
]

SUFFIXES = [
    "Collective", "Labs", "Works", "Holdings", "Ventures", "Studio", "Systems",
    "Group", "Co", "Dynamics", "Forge", "Foundry", "Guild", "Consortium", "Union",
    "Network", "Exchange", "Bureau", "Cartel", "Syndicate", "Alliance", "Trust"
]

MODIFIERS = [
    "allegedly", "reportedly", "according to an old memo", "in a leaked note",
    "as the rumor goes", "according to a retired janitor", "in a half-forgotten diary",
    "whispered by a night guard", "scribbled in a margin", "noted in a footnote",
    "according to a rumor", "as told by an ex-intern", "in a rumor passed at midnight"
]

# ---------------------------
# Helpers and "all" support
# ---------------------------

def all_templates_list():
    """Return a single list containing every template from every tone."""
    combined = []
    for lst in TEMPLATES.values():
        combined.extend(lst)
    return combined

def make_seed_variants(seed: str, n: int = 8):
    base = seed.strip() or "an organization"
    variants = {base}
    attempts = 0
    while len(variants) < n and attempts < n * 8:
        adj = random.choice(ADJECTIVE_PREFIXES)
        suf = random.choice(SUFFIXES)
        if random.random() < 0.5:
            variants.add(f"{adj} {base}")
        else:
            variants.add(f"{base} {suf}")
        attempts += 1
    return list(variants)

def craft_line_from_templates(templates_list, seed_variants):
    tpl = random.choice(templates_list)
    variant = random.choice(seed_variants)
    if "{seed}" not in tpl:
        tpl = "{seed} " + tpl
    if random.random() < 0.30:
        mod = random.choice(MODIFIERS)
        sentence = f"{mod.capitalize()}, {tpl.format(seed=variant)}"
    else:
        sentence = tpl.format(seed=variant)
    return f"FICTIONAL: {sentence}"

def generate(seed: str, count: int = 10, tone: str = "absurd", unique: bool = True):
    # If tone == "all", use combined templates; otherwise use the selected tone list
    if tone == "all":
        templates_list = all_templates_list()
    else:
        templates_list = TEMPLATES.get(tone, all_templates_list())
    seed_variants = make_seed_variants(seed, n=max(8, count//2))
    results = []
    attempts = 0
    max_attempts = max(2000, count * 80)
    while len(results) < count and attempts < max_attempts:
        line = craft_line_from_templates(templates_list, seed_variants)
        if unique:
            if line not in results:
                results.append(line)
        else:
            results.append(line)
        attempts += 1
    return results

# ---------------------------
# TTS helper (no external packages)
# ---------------------------

def _escape_for_powershell(s: str) -> str:
    return s.replace('"', '\\"').replace('`', '``')

def speak(text: str):
    if not text:
        return
    system = platform.system()
    try:
        if system == "Darwin":
            subprocess.run(["say", text], check=False)
            return
        if system == "Windows":
            safe = _escape_for_powershell(text)
            ps_cmd = (
                'Add-Type -AssemblyName System.Speech;'
                f'$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;'
                f'$s.Speak("{safe}")'
            )
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return
        if shutil.which("espeak"):
            subprocess.run(["espeak", text], check=False)
            return
        if shutil.which("spd-say"):
            subprocess.run(["spd-say", text], check=False)
            return
        print("TTS not available: install espeak or spd-say on Linux, use macOS 'say', or run on Windows with PowerShell.")
    except Exception as e:
        print("TTS error:", e)

# ---------------------------
# CLI and interactive loop (with 'all' option)
# ---------------------------

def print_header():
    now = datetime.datetime.now().isoformat(timespec="seconds")
    print(f"\nFictional Falsehood Generator  {now}")
    print("-" * 60)

def prompt_settings(count, tone, unique, tts_enabled, seed):
    print("\nCurrent settings")
    print(f"  Seed: '{seed}'  Count: {count}  Tone: {tone}  Unique: {unique}  TTS: {tts_enabled}")
    print("Press Enter to keep a value.")
    try:
        new_seed = input("New seed text  > ").strip()
        if new_seed:
            seed = new_seed
        new_count = input("New count (number)  > ").strip()
        if new_count:
            count = max(1, int(new_count))
    except ValueError:
        print("Invalid number, keeping previous count.")
    tone_choices = list(TEMPLATES.keys()) + ["all"]
    new_tone = input(f"New tone {tuple(tone_choices)}  > ").strip().lower()
    if new_tone in tone_choices:
        tone = new_tone
    dup = input("Unique lines only y/n  > ").strip().lower()
    if dup in ("y", "n"):
        unique = (dup == "y")
    t = input("Enable TTS y/n  > ").strip().lower()
    if t in ("y", "n"):
        tts_enabled = (t == "y")
    return count, tone, unique, tts_enabled, seed

def interactive_loop():
    # initial count set to 1 as requested
    count = 1
    tone = "absurd"
    unique = True
    seed = "an organization"
    tts_enabled = False

    tone_choices = list(TEMPLATES.keys()) + ["all"]

    print(textwrap.dedent(f"""
        Interactive mode
        Commands
          [Enter]  generate again with current settings
          s        change settings
          t        toggle TTS on/off
          q or exit
                   quit the program

        Available tones: {', '.join(tone_choices)}
    """).strip())

    while True:
        print_header()
        print(f"Settings  Count {count}  Tone {tone}  Unique {unique}  Seed '{seed}'  TTS {tts_enabled}\n")
        lines = generate(seed=seed, count=count, tone=tone, unique=unique)
        for i, l in enumerate(lines, 1):
            print(f"{i:2d}. {l}")
        if tts_enabled:
            for l in lines:
                speak_text = l.replace("FICTIONAL: ", "")
                speak(speak_text)
        cmd = input("\n[Enter] again  s settings  t toggle TTS  q quit  > ").strip().lower()
        if cmd in ("q", "exit"):
            print("Goodbye.")
            break
        if cmd == "s":
            count, tone, unique, tts_enabled, seed = prompt_settings(count, tone, unique, tts_enabled, seed)
            continue
        if cmd == "t":
            tts_enabled = not tts_enabled
            print("TTS enabled" if tts_enabled else "TTS disabled")
            continue
        # any other input repeats generation

def main():
    tone_choices = list(TEMPLATES.keys()) + ["all"]
    parser = argparse.ArgumentParser(
        prog="fictional_falsehoods_expanded_tts_more_templates_all.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent("""\
            Generate clearly labeled fictional falsehoods for creative use.
            Output is always prefixed with FICTIONAL.
            Tones available: absurd, humorous, plausible, dramatic, noir, whimsical, fantasy, scifi, all
            TTS uses system tools (macOS say, Windows PowerShell, Linux espeak/spd-say).
        """)
    )
    parser.add_argument("seed", nargs="?", default="an organization", help="Seed subject for the falsehoods")
    parser.add_argument("--count", "-c", type=int, default=1, help="Number of lines to generate")
    parser.add_argument("--tone", "-t", choices=tone_choices, default="absurd", help="Tone/style of falsehoods (use 'all' to mix tones)")
    parser.add_argument("--allow-duplicates", action="store_true", help="Allow duplicate lines")
    parser.add_argument("--interactive", "-i", action="store_true", help="Run in interactive mode")
    parser.add_argument("--tts", action="store_true", help="Enable TTS for non-interactive runs")
    args = parser.parse_args()

    if args.interactive:
        interactive_loop()
        return

    seed = args.seed
    count = args.count
    tone = args.tone
    unique = not args.allow_duplicates
    tts_enabled = args.tts

    while True:
        now = datetime.datetime.now().isoformat(timespec="seconds")
        print(f"\nFictional Falsehoods  {now}")
        print("-" * 40)
        lines = generate(seed=seed, count=count, tone=tone, unique=unique)
        for i, line in enumerate(lines, 1):
            print(f"{i:2d}. {line}")
        if tts_enabled:
            for l in lines:
                speak_text = l.replace("FICTIONAL: ", "")
                speak(speak_text)
        try:
            cmd = input("\n[Enter] generate again  s change settings  t toggle TTS  q or exit to quit  > ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break
        if cmd in ("q", "exit"):
            print("Goodbye.")
            break
        if cmd == "s":
            try:
                new_seed = input("Seed text  > ").strip()
                if new_seed:
                    seed = new_seed
                new_count = input("Count  (number)  > ").strip()
                if new_count:
                    count = max(1, int(new_count))
                new_tone = input(f"Tone  {tuple(tone_choices)}  > ").strip().lower()
                if new_tone in tone_choices:
                    tone = new_tone
                dup = input("Unique lines only  y/n  > ").strip().lower()
                if dup in ("y", "n"):
                    unique = (dup == "y")
                t = input("Enable TTS y/n  > ").strip().lower()
                if t in ("y", "n"):
                    tts_enabled = (t == "y")
            except ValueError:
                print("Invalid input, keeping previous settings.")
            continue
        if cmd == "t":
            tts_enabled = not tts_enabled
            print("TTS enabled" if tts_enabled else "TTS disabled")
            continue
        # any other input (including empty) repeats generation

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit("\nInterrupted. Exiting.")
