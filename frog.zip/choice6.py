#!/usr/bin/env python3
"""
random_mcq_quiz_repeat.py

Command-line multiple-choice quiz with a large randomized question bank.
- Runs repeated quiz sessions until the user chooses to quit
- Shuffles questions and choices each session
- Immediate feedback and final score per session
- Optional timed mode per question
- Appends results to results.json
"""

import random
import json
import time
import sys
import subprocess
import shlex
from typing import List, Dict, Any

# ---------------- TTS helpers (minimal, no external packages) ----------------
def _has_command(cmd: str) -> bool:
    from shutil import which
    return which(cmd) is not None

def speak(text: str, block: bool = False) -> bool:
    """
    Speak text using an available OS TTS backend.
    Returns True if a backend was invoked, False otherwise.

    - macOS: `say`
    - Windows: PowerShell System.Speech.Synthesis.SpeechSynthesizer
    - Linux: tries `spd-say` then `espeak`
    """
    if not text:
        return False
    platform = sys.platform
    # macOS
    if platform == "darwin" and _has_command("say"):
        cmd = ["say", text]
        try:
            if block:
                subprocess.run(cmd, check=False)
            else:
                subprocess.Popen(cmd)
            return True
        except Exception:
            return False
    # Windows (PowerShell)
    if platform.startswith("win"):
        safe_text = text.replace("'", "''")
        ps_script = (
            "Add-Type -AssemblyName System.Speech;"
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            f"$s.Speak('{safe_text}');"
        )
        cmd = ["powershell", "-NoProfile", "-Command", ps_script]
        try:
            if block:
                subprocess.run(cmd, check=False)
            else:
                subprocess.Popen(cmd)
            return True
        except Exception:
            return False
    # Linux: try spd-say then espeak
    if platform.startswith("linux"):
        if _has_command("spd-say"):
            cmd = ["spd-say", text]
            try:
                if block:
                    subprocess.run(cmd, check=False)
                else:
                    subprocess.Popen(cmd)
                return True
            except Exception:
                pass
        if _has_command("espeak"):
            cmd = ["espeak", shlex.quote(text)]
            try:
                if block:
                    subprocess.run(" ".join(cmd), shell=True, check=False)
                else:
                    subprocess.Popen(" ".join(cmd), shell=True)
                return True
            except Exception:
                pass
    return False

def tts_available() -> bool:
    """Return True if any TTS backend is available on this system."""
    platform = sys.platform
    if platform == "darwin" and _has_command("say"):
        return True
    if platform.startswith("win"):
        # Assume PowerShell exists on modern Windows
        return True
    if platform.startswith("linux") and (_has_command("spd-say") or _has_command("espeak")):
        return True
    return False

# ---------------- Large sample question bank ----------------
SAMPLE_QUESTIONS: List[Dict[str, Any]] = [
    {"q":"What is the capital of France?","choices":["Paris","Berlin","Rome","Madrid"],"answer":0},
    {"q":"Which element has the chemical symbol O?","choices":["Gold","Oxygen","Silver","Iron"],"answer":1},
    {"q":"Who wrote '1984'?","choices":["Aldous Huxley","George Orwell","Ray Bradbury","Philip K. Dick"],"answer":1},
    {"q":"Which planet is known as the Red Planet?","choices":["Venus","Mars","Jupiter","Saturn"],"answer":1},
    {"q":"What is 7 * 8?","choices":["54","56","58","64"],"answer":1},
    {"q":"Which ocean is the largest by surface area?","choices":["Atlantic","Indian","Arctic","Pacific"],"answer":3},
    {"q":"Who painted the Mona Lisa?","choices":["Vincent van Gogh","Pablo Picasso","Leonardo da Vinci","Claude Monet"],"answer":2},
    {"q":"What is the freezing point of water in Celsius?","choices":["0","32","100","-10"],"answer":0},
    {"q":"Which country hosted the 2016 Summer Olympics?","choices":["China","Brazil","UK","Russia"],"answer":1},
    {"q":"What is the chemical formula for table salt?","choices":["NaCl","KCl","H2O","CO2"],"answer":0},
    {"q":"Who is the author of 'Pride and Prejudice'?","choices":["Charlotte Brontë","Jane Austen","Mary Shelley","Emily Brontë"],"answer":1},
    {"q":"What is the largest mammal?","choices":["African elephant","Blue whale","Giraffe","Hippopotamus"],"answer":1},
    {"q":"Which gas do plants primarily absorb for photosynthesis?","choices":["Oxygen","Nitrogen","Carbon dioxide","Hydrogen"],"answer":2},
    {"q":"What is the square root of 144?","choices":["10","11","12","13"],"answer":2},
    {"q":"Which city is known as the Big Apple?","choices":["Los Angeles","Chicago","New York City","San Francisco"],"answer":2},
    {"q":"Who discovered penicillin?","choices":["Alexander Fleming","Marie Curie","Louis Pasteur","Gregor Mendel"],"answer":0},
    {"q":"Which language has the most native speakers worldwide?","choices":["English","Mandarin Chinese","Spanish","Hindi"],"answer":1},
    {"q":"What is the currency of Japan?","choices":["Yen","Won","Dollar","Euro"],"answer":0},
    {"q":"Which organ pumps blood through the body?","choices":["Liver","Lungs","Heart","Kidneys"],"answer":2},
    {"q":"Who wrote the play 'Hamlet'?","choices":["Christopher Marlowe","William Shakespeare","Ben Jonson","John Webster"],"answer":1},
    {"q":"What is H2O commonly called?","choices":["Hydrogen peroxide","Water","Salt","Ammonia"],"answer":1},
    {"q":"Which planet has the most moons (as of 2024)?","choices":["Earth","Mars","Jupiter","Mercury"],"answer":2},
    {"q":"What is the capital of Japan?","choices":["Seoul","Tokyo","Beijing","Bangkok"],"answer":1},
    {"q":"Which metal is liquid at room temperature?","choices":["Iron","Mercury","Gold","Aluminum"],"answer":1},
    {"q":"What is the largest continent by land area?","choices":["Africa","Asia","North America","Europe"],"answer":1},
    {"q":"Who developed the theory of relativity?","choices":["Isaac Newton","Albert Einstein","Niels Bohr","Galileo Galilei"],"answer":1},
    {"q":"Which instrument measures atmospheric pressure?","choices":["Thermometer","Barometer","Hygrometer","Anemometer"],"answer":1},
    {"q":"What is the chemical symbol for gold?","choices":["Au","Ag","Gd","Go"],"answer":0},
    {"q":"Which country is famous for the pyramids at Giza?","choices":["Mexico","Peru","Egypt","Sudan"],"answer":2},
    {"q":"What is the capital of Canada?","choices":["Toronto","Vancouver","Ottawa","Montreal"],"answer":2},
    {"q":"Which scientist proposed natural selection?","choices":["Gregor Mendel","Charles Darwin","Alfred Wegener","James Watson"],"answer":1},
    {"q":"What is 15% of 200?","choices":["20","25","30","35"],"answer":2},
    {"q":"Which element is a noble gas?","choices":["Oxygen","Nitrogen","Argon","Chlorine"],"answer":2},
    {"q":"Who painted 'Starry Night'?","choices":["Paul Cézanne","Vincent van Gogh","Edvard Munch","Salvador Dalí"],"answer":1},
    {"q":"Which country has the largest population?","choices":["India","United States","China","Indonesia"],"answer":2},
    {"q":"What is the tallest mountain in the world above sea level?","choices":["K2","Mount Everest","Kangchenjunga","Lhotse"],"answer":1},
    {"q":"Which organelle is the powerhouse of the cell?","choices":["Nucleus","Mitochondrion","Ribosome","Golgi apparatus"],"answer":1},
    {"q":"What is the value of pi (approx) to two decimal places?","choices":["3.12","3.14","3.16","3.18"],"answer":1},
    {"q":"Who is known as the 'Father of Computers' (conceptual)?","choices":["Alan Turing","Charles Babbage","John von Neumann","Ada Lovelace"],"answer":1},
    {"q":"Which U.S. state is known as the Sunshine State?","choices":["California","Florida","Texas","Arizona"],"answer":1},
    {"q":"What is the primary language spoken in Brazil?","choices":["Spanish","Portuguese","French","English"],"answer":1},
    {"q":"Which famous physicist wrote 'A Brief History of Time'?","choices":["Stephen Hawking","Richard Feynman","Brian Greene","Carl Sagan"],"answer":0},
    {"q":"What is the chemical formula for carbon dioxide?","choices":["CO","CO2","C2O","O2C"],"answer":1},
    {"q":"Which city hosted the 2008 Summer Olympics?","choices":["Beijing","Athens","Sydney","London"],"answer":0},
    {"q":"Who composed the Four Seasons?","choices":["Bach","Mozart","Vivaldi","Beethoven"],"answer":2},
    {"q":"Which planet is closest to the Sun?","choices":["Venus","Mercury","Earth","Mars"],"answer":1},
    {"q":"What is the largest internal organ in the human body?","choices":["Liver","Heart","Lungs","Kidneys"],"answer":0},
    {"q":"Which country is home to the kangaroo?","choices":["South Africa","Australia","India","Brazil"],"answer":1},
    {"q":"What is the boiling point of water at sea level in Celsius?","choices":["90","95","100","105"],"answer":2},
    {"q":"Who wrote 'To Kill a Mockingbird'?","choices":["Harper Lee","Truman Capote","F. Scott Fitzgerald","Ernest Hemingway"],"answer":0},
    {"q":"Which gas makes up most of Earth's atmosphere?","choices":["Oxygen","Nitrogen","Carbon dioxide","Argon"],"answer":1},
    {"q":"What is 9 squared?","choices":["18","27","81","72"],"answer":2},
    {"q":"Which instrument has keys, pedals, and strings?","choices":["Guitar","Piano","Violin","Flute"],"answer":1},
    {"q":"Who was the first person to walk on the Moon?","choices":["Yuri Gagarin","Buzz Aldrin","Neil Armstrong","Michael Collins"],"answer":2},
    {"q":"Which country uses the rupee as currency?","choices":["Japan","India","Brazil","Canada"],"answer":1},
    {"q":"What is the primary unit of electric current?","choices":["Volt","Ohm","Ampere","Watt"],"answer":2},
    {"q":"Which novel begins with 'Call me Ishmael'?","choices":["Moby-Dick","The Old Man and the Sea","Heart of Darkness","The Odyssey"],"answer":0},
    {"q":"Which element has atomic number 1?","choices":["Helium","Hydrogen","Lithium","Oxygen"],"answer":1},
    {"q":"What is the capital of Italy?","choices":["Milan","Venice","Rome","Naples"],"answer":2},
    {"q":"Which sport uses a shuttlecock?","choices":["Tennis","Badminton","Squash","Table tennis"],"answer":1},
    {"q":"Who painted the ceiling of the Sistine Chapel?","choices":["Raphael","Michelangelo","Donatello","Titian"],"answer":1},
    {"q":"Which country is famous for tulips and windmills?","choices":["Belgium","Netherlands","Denmark","Sweden"],"answer":1},
    {"q":"What is the largest desert in the world (non-polar)?","choices":["Sahara","Gobi","Kalahari","Mojave"],"answer":0},
    {"q":"Which scientist is associated with the laws of motion?","choices":["Albert Einstein","Isaac Newton","Galileo Galilei","Johannes Kepler"],"answer":1},
    {"q":"What is the main language spoken in Argentina?","choices":["Portuguese","Spanish","Italian","French"],"answer":1},
    {"q":"Which metal has the highest electrical conductivity?","choices":["Copper","Silver","Gold","Aluminum"],"answer":1},
    {"q":"What is the capital of Australia?","choices":["Sydney","Melbourne","Canberra","Perth"],"answer":2},
    {"q":"Which organ filters blood to produce urine?","choices":["Liver","Kidney","Pancreas","Spleen"],"answer":1},
    {"q":"What is 100 in Roman numerals?","choices":["L","C","D","M"],"answer":1},
    {"q":"Who wrote 'The Odyssey'?","choices":["Homer","Virgil","Sophocles","Euripides"],"answer":0},
    {"q":"Which planet is known for its rings?","choices":["Uranus","Neptune","Saturn","Jupiter"],"answer":2},
    {"q":"What is the chemical symbol for iron?","choices":["Fe","Ir","In","I"],"answer":0},
    {"q":"Which country is the Eiffel Tower located in?","choices":["Italy","France","Germany","Spain"],"answer":1},
    {"q":"What is the capital of Russia?","choices":["Saint Petersburg","Moscow","Kazan","Sochi"],"answer":1},
    {"q":"Which device measures temperature?","choices":["Barometer","Thermometer","Altimeter","Hygrometer"],"answer":1},
    {"q":"What is the smallest prime number?","choices":["0","1","2","3"],"answer":2},
    {"q":"Who is the author of 'The Hobbit'?","choices":["C.S. Lewis","J.R.R. Tolkien","J.K. Rowling","George R.R. Martin"],"answer":1},
    {"q":"Which blood type is known as the universal donor?","choices":["A","B","AB","O negative"],"answer":3},
    {"q":"What is the capital of Germany?","choices":["Munich","Frankfurt","Berlin","Hamburg"],"answer":2},
    {"q":"Which element is used in lightbulb filaments (traditional incandescent)?","choices":["Tungsten","Copper","Iron","Aluminum"],"answer":0},
    {"q":"What is the largest planet in our solar system?","choices":["Saturn","Jupiter","Neptune","Earth"],"answer":1},
    {"q":"Which famous scientist discovered the law of universal gravitation?","choices":["Albert Einstein","Isaac Newton","Galileo Galilei","Johannes Kepler"],"answer":1},
    {"q":"What is the capital of Spain?","choices":["Barcelona","Madrid","Valencia","Seville"],"answer":1},
    {"q":"Which instrument is used to view very small objects at high magnification?","choices":["Telescope","Microscope","Binoculars","Periscope"],"answer":1},
    {"q":"What is the chemical symbol for sodium?","choices":["S","Na","So","Sd"],"answer":1},
    {"q":"Which country is known as the Land of the Rising Sun?","choices":["China","Japan","Thailand","South Korea"],"answer":1},
    {"q":"Who wrote 'The Great Gatsby'?","choices":["F. Scott Fitzgerald","Ernest Hemingway","John Steinbeck","William Faulkner"],"answer":0},
    {"q":"What is the capital of India?","choices":["Mumbai","New Delhi","Bangalore","Kolkata"],"answer":1},
    {"q":"Which gas is essential for human respiration?","choices":["Carbon dioxide","Nitrogen","Oxygen","Helium"],"answer":2},
    {"q":"What is 12 * 12?","choices":["132","144","156","168"],"answer":1},
    {"q":"Which sea creature has eight arms?","choices":["Squid","Octopus","Jellyfish","Starfish"],"answer":1},
    {"q":"Who painted 'The Persistence of Memory'?","choices":["Salvador Dalí","Pablo Picasso","Henri Matisse","Edvard Munch"],"answer":0},
    {"q":"Which country is the largest by land area?","choices":["United States","Canada","Russia","China"],"answer":2},
    {"q":"What is the primary ingredient in guacamole?","choices":["Tomato","Avocado","Onion","Pepper"],"answer":1},
    {"q":"Which scientist is credited with inventing the telephone?","choices":["Thomas Edison","Alexander Graham Bell","Nikola Tesla","Guglielmo Marconi"],"answer":1},
    {"q":"What is the capital of South Africa (one of the capitals)?","choices":["Cape Town","Johannesburg","Pretoria","Durban"],"answer":2},
    {"q":"Which mathematical term describes a polygon with five sides?","choices":["Quadrilateral","Pentagon","Hexagon","Heptagon"],"answer":1},
    {"q":"Which organ produces insulin?","choices":["Liver","Pancreas","Kidney","Spleen"],"answer":1},
    {"q":"What is the chemical symbol for helium?","choices":["He","H","Hm","Hl"],"answer":0},
    {"q":"Which famous playwright wrote 'Death of a Salesman'?","choices":["Arthur Miller","Tennessee Williams","Eugene O'Neill","Harold Pinter"],"answer":0},
    {"q":"Which country is famous for the Great Barrier Reef?","choices":["Australia","Philippines","Indonesia","Fiji"],"answer":0},
    {"q":"What is the capital of Mexico?","choices":["Guadalajara","Monterrey","Mexico City","Cancún"],"answer":2},
    {"q":"Which planet is known as the Earth's twin because of similar size?","choices":["Mars","Venus","Mercury","Neptune"],"answer":1},
    {"q":"What is the largest bone in the human body?","choices":["Femur","Tibia","Humerus","Skull"],"answer":0},
    {"q":"Which composer wrote the opera 'The Magic Flute'?","choices":["Mozart","Beethoven","Verdi","Puccini"],"answer":0},
    {"q":"What is the capital of Turkey?","choices":["Istanbul","Ankara","Izmir","Antalya"],"answer":1},
    {"q":"Which device measures wind speed?","choices":["Barometer","Anemometer","Thermometer","Altimeter"],"answer":1},
    {"q":"What is the chemical formula for methane?","choices":["CH4","C2H6","CO2","H2O"],"answer":0},
    {"q":"Which U.S. president issued the Emancipation Proclamation?","choices":["George Washington","Abraham Lincoln","Thomas Jefferson","Theodore Roosevelt"],"answer":1},
    {"q":"Which continent is Egypt primarily located in?","choices":["Asia","Africa","Europe","South America"],"answer":1},
    {"q":"What is the capital of China?","choices":["Shanghai","Beijing","Guangzhou","Shenzhen"],"answer":1},
    {"q":"Which animal is known for its black and white stripes?","choices":["Tiger","Zebra","Skunk","Panda"],"answer":1},
    {"q":"What is the value of 2 to the 10th power?","choices":["512","1024","2048","4096"],"answer":1},
    {"q":"Who wrote 'The Catcher in the Rye'?","choices":["J.D. Salinger","John Steinbeck","Kurt Vonnegut","Jack Kerouac"],"answer":0},
    {"q":"Which metal is commonly used for aircraft frames due to its light weight?","choices":["Steel","Titanium","Aluminum","Copper"],"answer":2},
    {"q":"What is the capital of Brazil?","choices":["Rio de Janeiro","São Paulo","Brasília","Salvador"],"answer":2},
    {"q":"Which organ is primarily responsible for detoxifying chemicals and metabolizing drugs?","choices":["Kidney","Liver","Lungs","Heart"],"answer":1},
    {"q":"Which famous scientist proposed the heliocentric model of the solar system?","choices":["Ptolemy","Nicolaus Copernicus","Galileo Galilei","Johannes Kepler"],"answer":1},
    {"q":"What is the chemical symbol for potassium?","choices":["P","K","Pt","Po"],"answer":1},
    {"q":"Which language is primarily spoken in Egypt?","choices":["Arabic","French","English","Swahili"],"answer":0},
    {"q":"What is the capital of Argentina?","choices":["Buenos Aires","Córdoba","Rosario","Mendoza"],"answer":0},
    {"q":"Which instrument is used to measure earthquakes?","choices":["Seismometer","Barometer","Thermometer","Hygrometer"],"answer":0},
    {"q":"What is the largest species of shark?","choices":["Great white shark","Tiger shark","Whale shark","Hammerhead shark"],"answer":2},
    {"q":"Which poet wrote 'The Raven'?","choices":["Robert Frost","Edgar Allan Poe","Walt Whitman","Emily Dickinson"],"answer":1},
    {"q":"What is the capital of Norway?","choices":["Oslo","Bergen","Trondheim","Stavanger"],"answer":0},
    {"q":"Which vitamin is produced when skin is exposed to sunlight?","choices":["Vitamin A","Vitamin B12","Vitamin C","Vitamin D"],"answer":3},
    {"q":"What is the chemical symbol for copper?","choices":["Cu","Cp","Co","Cr"],"answer":0},
    {"q":"Which country is known for maple syrup production?","choices":["United States","Canada","France","Germany"],"answer":1},
    {"q":"What is the capital of Sweden?","choices":["Stockholm","Gothenburg","Malmö","Uppsala"],"answer":0},
    {"q":"Which planet is tilted on its side and has extreme seasons?","choices":["Uranus","Neptune","Saturn","Jupiter"],"answer":0},
    {"q":"What is 5 factorial (5!)?","choices":["60","100","120","150"],"answer":2},
    {"q":"Who wrote 'Frankenstein'?","choices":["Mary Shelley","Bram Stoker","Robert Louis Stevenson","H.G. Wells"],"answer":0},
    {"q":"Which U.S. state is the Grand Canyon located in?","choices":["Nevada","Arizona","Utah","Colorado"],"answer":1},
    {"q":"What is the capital of Portugal?","choices":["Lisbon","Porto","Faro","Coimbra"],"answer":0},
    {"q":"Which gas is used to inflate balloons because it is lighter than air and non-flammable?","choices":["Hydrogen","Helium","Methane","Oxygen"],"answer":1},
    {"q":"What is the capital of Greece?","choices":["Athens","Thessaloniki","Patras","Heraklion"],"answer":0},
    {"q":"Which famous scientist is known for the uncertainty principle?","choices":["Werner Heisenberg","Niels Bohr","Erwin Schrödinger","Paul Dirac"],"answer":0},
    {"q":"What is the capital of Scotland?","choices":["Glasgow","Edinburgh","Aberdeen","Inverness"],"answer":1},
    {"q":"Which organ helps with digestion by producing bile?","choices":["Pancreas","Liver","Stomach","Gallbladder"],"answer":1},
    {"q":"What is the capital of Portugal?","choices":["Lisbon","Porto","Braga","Faro"],"answer":0}
]

# ---------------- Utilities ----------------
def shuffle_question(q: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of question with shuffled choices and updated answer index."""
    choices = list(q["choices"])
    correct_choice = choices[q["answer"]]
    random.shuffle(choices)
    new_answer = choices.index(correct_choice)
    return {"q": q["q"], "choices": choices, "answer": new_answer}

def ask_question(qobj: Dict[str, Any], time_limit: float = None) -> Dict[str, Any]:
    """
    Ask a single question.
    Returns a dict with keys: correct(bool), selected_index(int or None), time_taken(float)
    """
    # Speak only the question if a TTS backend is available
    try:
        if tts_available():
            speak(qobj["q"])
    except Exception:
        # If TTS fails for any reason, continue silently
        pass

    print("\n" + qobj["q"])
    for i, ch in enumerate(qobj["choices"], start=1):
        print(f"  {i}. {ch}")
    start = time.time()
    selected = None
    try:
        if time_limit is None:
            raw = input("Your answer (number): ").strip()
        else:
            print(f"You have {time_limit:.0f} seconds. Press Enter to submit.")
            raw = timed_input(time_limit)
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
        return {"correct": False, "selected_index": None, "time_taken": 0.0}
    elapsed = time.time() - start
    if raw == "":
        selected = None
    else:
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(qobj["choices"]):
                selected = idx
            else:
                selected = None
        except Exception:
            selected = None
    correct = (selected == qobj["answer"])
    return {"correct": correct, "selected_index": selected, "time_taken": elapsed}

def timed_input(timeout: float) -> str:
    """
    Cross-platform timed input without leaving a lingering reader thread.
    - On Unix/macOS uses select.select on sys.stdin.
    - On Windows uses msvcrt.kbhit/getwche to build the line.
    - Returns empty string on timeout.
    """
    import sys as _sys
    import time as _time

    platform = _sys.platform

    # Unix / macOS: use select
    if platform.startswith("linux") or platform == "darwin":
        try:
            import select as _select
            _sys.stdout.flush()
            rlist, _, _ = _select.select([_sys.stdin], [], [], timeout)
            if rlist:
                return _sys.stdin.readline().rstrip("\n")
            return ""
        except Exception:
            # fall through to fallback
            pass

    # Windows: use msvcrt
    if platform.startswith("win"):
        try:
            import msvcrt as _msvcrt
            start = _time.time()
            line_chars = []
            while True:
                if _msvcrt.kbhit():
                    ch = _msvcrt.getwche()
                    # Enter (CR or LF)
                    if ch in ("\r", "\n"):
                        _sys.stdout.write("\n")
                        return "".join(line_chars)
                    # Backspace
                    if ch == "\b":
                        if line_chars:
                            line_chars.pop()
                            # erase char from console
                            _sys.stdout.write("\b \b")
                        continue
                    line_chars.append(ch)
                if (_time.time() - start) >= timeout:
                    return ""
                _time.sleep(0.01)
        except Exception:
            # fall through to fallback
            pass

    # Fallback: thread-based (best-effort)
    import threading as _threading

    result = {"value": None}
    def reader():
        try:
            result["value"] = _sys.stdin.readline().rstrip("\n")
        except Exception:
            result["value"] = ""

    thread = _threading.Thread(target=reader, daemon=True)
    thread.start()
    thread.join(timeout)
    if thread.is_alive():
        # timed out; cannot cancel blocking readline reliably
        return ""
    return result["value"] or ""

# ---------------- Quiz runner ----------------
def run_quiz(questions: List[Dict[str, Any]],
             num_questions: int = None,
             time_limit_per_question: float = None,
             save_results: bool = True) -> Dict[str, Any]:
    """
    Run the quiz once and return a summary dict.
    """
    bank = [shuffle_question(q) for q in questions]
    random.shuffle(bank)
    if num_questions is None or num_questions <= 0 or num_questions > len(bank):
        num_questions = len(bank)
    selected = bank[:num_questions]

    stats = {"total": num_questions, "correct": 0, "details": []}

    print(f"\nStarting quiz: {num_questions} question(s). Good luck!\n")
    for i, q in enumerate(selected, start=1):
        print(f"Question {i}/{num_questions}:")
        res = ask_question(q, time_limit=time_limit_per_question)
        chosen_text = None
        if res["selected_index"] is not None:
            chosen_text = q["choices"][res["selected_index"]]
        correct_text = q["choices"][q["answer"]]
        if res["selected_index"] is None:
            print(f"  No valid answer given. Correct: {correct_text}")
        elif res["correct"]:
            print(f"  Correct! ✅ ({chosen_text})")
            stats["correct"] += 1
        else:
            print(f"  Incorrect. You chose: {chosen_text}. Correct: {correct_text}")
        stats["details"].append({
            "question": q["q"],
            "choices": q["choices"],
            "correct_index": q["answer"],
            "selected_index": res["selected_index"],
            "correct": res["correct"],
            "time_taken": round(res["time_taken"], 2)
        })

    score_pct = stats["correct"] / stats["total"] * 100.0
    print("\n--- Quiz complete ---")
    print(f"Score: {stats['correct']} / {stats['total']}  ({score_pct:.1f}%)")

    if save_results:
        timestamp = int(time.time())
        out = {
            "timestamp": timestamp,
            "score": {"correct": stats["correct"], "total": stats["total"], "pct": round(score_pct, 2)},
            "details": stats["details"]
        }
        try:
            with open("results.json", "a", encoding="utf-8") as f:
                f.write(json.dumps(out, ensure_ascii=False) + "\n")
            print("Results appended to results.json")
        except Exception as e:
            print("Could not save results:", e)

    return {"correct": stats["correct"], "total": stats["total"], "pct": round(score_pct, 2)}

# ---------------- Main loop: repeat sessions until quit ----------------
def main():
    print("Random Multiple-Choice Quiz (Repeat mode)")
    print("----------------------------------------")
    while True:
        # Ask session options
        try:
            qcount_raw = input(f"How many questions this session? (1-{len(SAMPLE_QUESTIONS)} or Enter for all): ").strip()
            if qcount_raw == "":
                qcount = None
            else:
                qcount = int(qcount_raw)
        except Exception:
            qcount = None

        try:
            timed_raw = input("Timed mode? Enter seconds per question or press Enter for no limit: ").strip()
            if timed_raw == "":
                tlimit = None
            else:
                tlimit = float(timed_raw)
        except Exception:
            tlimit = None

        summary = run_quiz(SAMPLE_QUESTIONS, num_questions=qcount, time_limit_per_question=tlimit, save_results=True)

        # After session: ask whether to repeat or quit
        while True:
            try:
                choice = input("\nType 'r' to repeat another session, 'q' to quit: ").strip().lower()
            except EOFError:
                # If stdin closed unexpectedly, exit gracefully
                print("\nInput closed. Exiting.")
                return
            if choice in ("r", "repeat"):
                print("\nStarting a new session...\n")
                break  # outer while continues
            elif choice in ("q", "quit", "exit"):
                print("\nGoodbye — your last session score: "
                      f"{summary['correct']}/{summary['total']} ({summary['pct']}%).")
                return
            else:
                print("Unrecognized input. Please type 'r' to repeat or 'q' to quit.")

if __name__ == "__main__":
    main()
