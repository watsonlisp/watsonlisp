#!/usr/bin/env python3
"""
Reality Check Generator
- Press ENTER for a random reality check
- Type 'timed <seconds>' to get repeated checks every <seconds>
- Type 'bingo' to generate a 5x5 reality-check bingo card
- Type 'list' to print all prompts
- Type 'voice on' or 'voice off' to toggle simple system TTS (macOS/Windows)
- Type 'quit' to exit
"""

import random
import threading
import time
import os
import platform
from textwrap import wrap

# Expanded reality-check prompts (combined set)
REALITY_CHECKS = [
"Can you touch the object you're seeing?",
"Can you hear any real-world sounds right now?",
"Does the temperature around you feel normal?",
"Can you feel your feet on the ground?",
"Can you describe what’s directly in front of you?",
"Does anything around you smell familiar?",
"Can you read a sign or label nearby?",
"Can you feel something solid with your hand?",
"Is your phone showing the correct time?",
"Can you blink and still see the same thing?",
"Can you take a slow breath and notice your chest rising?",
"Can you name three things you can see?",
"Can you name two things you can hear?",
"Can you name one thing you can physically touch?",
"Does the lighting around you look normal?",
"Are your clothes touching your skin the way they usually do?",
"Can you move your fingers and toes?",
"Can you look away and look back—does anything change?",
"Can you check if someone else nearby reacts to what you’re seeing?",
"Can you feel the weight of something in your hand?",
"Can you describe the color of something nearby?",
"Can you read a word on a sign or screen?",
"Can you find something shiny or reflective?",
"Can you identify something that’s moving?",
"Can you identify something perfectly still?",
"Can you count how many corners are in the room?",
"Can you feel the texture of something near you?",
"Can you notice the temperature of what you're touching?",
"Can you tap your foot and feel the ground?",
"Can you stretch your fingers and notice the movement?",
"Can you feel your clothes against your skin?",
"Can you notice the chair or surface supporting you?",
"Can you press your hand against something solid?",
"Can you identify the closest sound?",
"Can you identify the farthest sound?",
"Can you clap once—does it sound normal?",
"Can you hum a note and hear it clearly?",
"Can you hear your own breathing?",
"Can you hear any repeating rhythms around you?",
"Can you notice any familiar smells?",
"Can you take a slow breath—does the air smell normal?",
"Can you identify whether the air is warm or cool?",
"Do you know what day it is?",
"Do you know where you are right now?",
"Can you name the last thing you did?",
"Can you name the next thing you plan to do?",
"Can you check the time—does it match what you expect?",
"Can you look around and name the room you’re in?",
"Can you identify something that belongs to you?",
"Does what you’re seeing match what you expect in this place?",
"Can someone else nearby see the same thing?",
"Does the object behave normally when you move around it?",
"Does the lighting make sense for the time of day?",
"Can you think of a simple explanation for what you’re noticing?",
"Can you remember seeing this object earlier today?",
"Does the situation feel familiar or routine?",
"Can you feel the temperature of the room?",
"Can you notice whether the air is still or moving?",
"Can you identify a light source?",
"Can you find something that makes a shadow?",
"Can you find something that makes a sound when tapped?",
"Can you take one slow breath and feel your chest rise?",
"Can you relax your shoulders for a moment?",
"Can you count five slow breaths?",
"Describe the nearest object’s exact color and shape.",
"Read a short line of text and say it aloud.",
"Count how many windows or doors you can see.",
"Look for a clock and read the time twice.",
"Find something that casts a clear shadow.",
"Spot three different textures in view.",
"Identify the closest moving object.",
"Look at a face nearby and describe one unique feature.",
"Check whether reflections behave normally.",
"Look at the sky or ceiling and describe its color and any clouds or lights.",
"Compare two similar objects and name one difference.",
"Look for a light source and point to it.",
"Find an object with a printed number and read it.",
"Look at a digital screen and confirm the battery or signal icon.",
"Stare at a small detail for 10 seconds, then blink—did it change?",
"Press your thumb and forefinger together and notice pressure.",
"Feel the texture of your clothing and name it.",
"Hold a small object and describe its weight.",
"Tap the surface under you and notice vibration or solidity.",
"Rub your palms together and notice warmth.",
"Pinch the skin on your arm and describe the sensation.",
"Press your feet flat and notice contact with the ground.",
"Squeeze a soft object, then a hard object, and compare.",
"Close your hand around something and describe its edges.",
"Run your fingers along a seam or edge and describe the texture.",
"Lift one foot slightly—does balance feel normal?",
"Touch your face and notice temperature and moisture.",
"Hold your phone and confirm its temperature feels normal.",
"Put a hand on your chest and feel your breathing.",
"Press your fingertips to your lips and notice sensation.",
"Identify the three closest sounds and name their sources.",
"Clap once and listen for the echo or lack of one.",
"Hum a short tune and listen to its pitch.",
"Count backward from 20 and notice clarity of voice.",
"Listen for traffic, voices, or appliances and describe direction.",
"Whisper a sentence and notice how it sounds to you.",
"Snap your fingers and note the sharpness of the sound.",
"Close your eyes and identify the faintest sound you can hear.",
"Tap two different surfaces and compare their tones.",
"Say a word and listen for distortion or delay.",
"Listen for repeating mechanical noises and identify them.",
"Record a short voice memo and play it back—does it match what you heard?",
"Take a slow breath and name any scent you notice.",
"Smell a familiar object and describe it.",
"Sip water and note if it tastes normal.",
"Lick a fingertip and describe any taste or texture.",
"Open a window and describe whether the air smells fresh or stale.",
"Smell your clothing and note any unusual odors.",
"Smell a piece of fruit and describe sweetness or acidity.",
"Breathe through your nose and mouth separately—any difference?",
"State the current day, date, and approximate time.",
"Name the city or neighborhood you’re in.",
"Describe the last three things you did in order.",
"Say the name of the street or room you’re in.",
"Check a calendar or phone and confirm the date twice.",
"Recall what you ate most recently and when.",
"Name the current season and whether it matches the weather.",
"Identify the nearest exit or landmark.",
"Confirm whether it’s morning, afternoon, evening, or night.",
"Ask someone nearby if they see the same thing you do.",
"Does the scene match what you’d expect in this place?",
"Can you think of a simple, real explanation for what you’re seeing?",
"If you move closer, does the object behave as expected?",
"Does the lighting match the time of day?",
"Are shadows consistent with the light source?",
"Does the sound change when you move toward or away from it?",
"Can you find evidence that this object existed earlier today?",
"Does the situation follow normal cause and effect?",
"Take five slow breaths and count them aloud.",
"Check your pulse for 15 seconds and note rhythm.",
"Relax your shoulders and notice tension change.",
"Stretch your arms and notice range of motion.",
"Close your eyes and rotate your head slowly—any dizziness?",
"Rate your current stress on a 1–10 scale and note why.",
"Notice whether your hands are sweaty, dry, or cold.",
"Check whether your mouth is dry or moist.",
"Ask a nearby person a simple factual question and compare answers.",
"Call or text a friend to confirm a shared detail.",
"Look for a public sign or schedule to verify time or place.",
"Check a news headline or weather app for current conditions.",
"Show someone a small object and ask if they see the same thing.",
"Use your phone camera to take a photo and inspect it.",
"Check receipts, tickets, or IDs for corroborating details.",
"Pick up an object and move it—does it respond normally?",
"Drop a small item and watch how it falls.",
"Turn a light on and off—does it behave normally?",
"Open and close a door—does it sound and feel right?",
"Walk to a different spot and re-evaluate the scene.",
"Write a short sentence and read it back.",
"Try to change the environment slightly and observe the result.",
"Use a mirror to view the scene from another angle.",
"Pinch yourself—did it hurt like usual?",
"Count your fingers and toes.",
"Say a tongue twister and see if it’s consistent.",
"Ask, 'Is this a dream?' and answer with three reasons.",
"Try to breathe through a straw—does it feel normal?",
"Smell your hand—does it smell like your usual soap?",
"Say your full name and birthday out loud.",
"Do a quick reality‑check bingo: see, touch, hear, smell, move."
]

# Simple cross-platform TTS (best-effort; uses system tools)
def speak(text):
    system = platform.system()
    try:
        if system == "Darwin":  # macOS
            os.system(f"say {quote_for_shell(text)}")
        elif system == "Windows":
            # Use PowerShell SAPI.SpVoice
            ps = f"Add-Type –AssemblyName System.speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{escape_single_quotes(text)}')"
            os.system(f"powershell -Command \"{ps}\"")
        else:
            # Linux: try 'espeak' if available
            if shutil.which("espeak"):
                os.system(f"espeak {quote_for_shell(text)}")
    except Exception:
        pass

def quote_for_shell(s):
    return "'" + s.replace("'", "'\"'\"'") + "'"

def escape_single_quotes(s):
    return s.replace("'", "''")

# Core features
def random_reality_check():
    return random.choice(REALITY_CHECKS)

def timed_mode(interval, stop_event, voice=False):
    while not stop_event.is_set():
        prompt = random_reality_check()
        print("\nReality Check (timed):")
        print(prompt)
        if voice:
            speak(prompt)
        for _ in range(int(interval)):
            if stop_event.is_set():
                break
            time.sleep(1)

def generate_bingo_card():
    # 5x5 bingo card, center is FREE
    items = random.sample(REALITY_CHECKS, k=24)
    card = [items[i*5:(i+1)*5] for i in range(4)]
    # insert center row with FREE in middle
    center_row = items[20:25]
    center_row[2] = "FREE"
    card.insert(2, center_row)
    return card

def print_bingo(card):
    print("\nReality-Check Bingo (5x5):")
    for row in card:
        print(" | ".join(cell[:30].ljust(30) for cell in row))
    print()

def list_all():
    for i, item in enumerate(REALITY_CHECKS, 1):
        print(f"{i:03d}. {item}")

def main():
    print("=== Reality Check Generator ===")
    print("Press ENTER for a random check. Commands: timed <s>, bingo, list, voice on/off, quit\n")
    voice = False
    timed_thread = None
    stop_event = None

    while True:
        try:
            raw = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if raw == "":
            prompt = random_reality_check()
            print("\nReality Check:")
            print(prompt)
            if voice:
                speak(prompt)
            continue

        parts = raw.split()
        cmd = parts[0].lower()

        if cmd == "quit":
            if stop_event:
                stop_event.set()
            print("Goodbye.")
            break

        if cmd == "list":
            list_all()
            continue

        if cmd == "bingo":
            card = generate_bingo_card()
            print_bingo(card)
            continue

        if cmd == "voice":
            if len(parts) > 1 and parts[1].lower() == "on":
                voice = True
                print("Voice: ON (system TTS, best-effort).")
            else:
                voice = False
                print("Voice: OFF.")
            continue

        if cmd == "timed":
            if len(parts) < 2:
                print("Usage: timed <seconds>  (e.g., timed 60)")
                continue
            try:
                interval = int(parts[1])
                if interval <= 0:
                    raise ValueError
            except ValueError:
                print("Interval must be a positive integer (seconds).")
                continue

            # stop previous timed thread if running
            if stop_event:
                stop_event.set()
                if timed_thread:
                    timed_thread.join()

            stop_event = threading.Event()
            timed_thread = threading.Thread(target=timed_mode, args=(interval, stop_event, voice), daemon=True)
            timed_thread.start()
            print(f"Timed mode started: one check every {interval} seconds. Type 'timed stop' or 'quit' to end.")
            continue

        if cmd == "timed" and len(parts) > 1 and parts[1].lower() == "stop":
            if stop_event:
                stop_event.set()
                if timed_thread:
                    timed_thread.join()
                stop_event = None
                timed_thread = None
                print("Timed mode stopped.")
            else:
                print("No timed mode running.")
            continue

        print("Unknown command. Press ENTER for a random check, or type 'list', 'bingo', 'timed <s>', 'voice on/off', or 'quit'.")

if __name__ == "__main__":
    main()
