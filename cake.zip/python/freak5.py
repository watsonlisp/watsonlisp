#!/usr/bin/env python3
"""
DTMF dialer with adjustable Redial gap (standard library only).
Longer default spaces between redialed numbers; slider to adjust gap.
"""

import math
import wave
import struct
import tempfile
import threading
import os
import platform
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox

DTMF = {
    '1': (697, 1209), '2': (697, 1336), '3': (697, 1477),
    '4': (770, 1209), '5': (770, 1336), '6': (770, 1477),
    '7': (852, 1209), '8': (852, 1336), '9': (852, 1477),
    '*': (941, 1209), '0': (941, 1336), '#': (941, 1477),
    'N': (600, 1700),  # Nickel dual-tone
    'D': (650, 1750),  # Dime dual-tone
    'Q': (700, 1800)   # Quarter dual-tone
}

SAMPLE_RATE = 44100
TONE_DURATION = 0.25
GAP_DURATION = 0.06
DEFAULT_REDIAL_GAP = 1.0   # longer default gap (seconds) between redialed digits
AMPLITUDE = 0.6
FADE_MS = 10

def synthesize_frames_for_key(key, duration=TONE_DURATION, sample_rate=SAMPLE_RATE, amplitude=AMPLITUDE):
    if key not in DTMF:
        raise ValueError("Unknown DTMF key")
    f1, f2 = DTMF[key]
    n_samples = int(sample_rate * duration)
    fade_len = int(sample_rate * (FADE_MS / 1000.0))
    max_amp = int(32767 * amplitude)
    frames = bytearray()
    for i in range(n_samples):
        t = i / sample_rate
        s = 0.5 * math.sin(2 * math.pi * f1 * t) + 0.5 * math.sin(2 * math.pi * f2 * t)
        if fade_len > 0:
            if i < fade_len:
                s *= (i / fade_len)
            elif i > n_samples - fade_len:
                s *= ((n_samples - i) / fade_len)
        sample = int(max_amp * s)
        frames += struct.pack('<h', sample)
    return bytes(frames), n_samples

def write_wav_file(frames_bytes, n_samples, filename, sample_rate=SAMPLE_RATE):
    with wave.open(filename, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(frames_bytes)

def shutil_which(cmd):
    paths = os.environ.get('PATH', '').split(os.pathsep)
    for p in paths:
        full = os.path.join(p, cmd)
        if os.path.isfile(full) and os.access(full, os.X_OK):
            return full
    return None

def play_file_platform(path):
    system = platform.system()
    try:
        if system == 'Windows':
            import winsound
            winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
            return True
        elif system == 'Darwin':
            subprocess.run(['afplay', path], check=False)
            return True
        else:
            for cmd in ('aplay', 'paplay', 'play'):
                if shutil_which(cmd):
                    subprocess.run([cmd, path], check=False)
                    return True
    except Exception:
        pass
    return False

def build_sequence_wav_bytes(sequence, tone_duration=TONE_DURATION, gap_duration=GAP_DURATION):
    gap_samples = int(SAMPLE_RATE * gap_duration)
    gap_bytes = b'\x00\x00' * gap_samples
    all_frames = bytearray()
    total_samples = 0
    for i, k in enumerate(sequence):
        frames, n = synthesize_frames_for_key(k, duration=tone_duration)
        all_frames += frames
        total_samples += n
        if i != len(sequence) - 1:
            all_frames += gap_bytes
            total_samples += gap_samples
    return bytes(all_frames), total_samples

def play_wav_bytes_async(frames_bytes, n_samples):
    def worker():
        fd, path = tempfile.mkstemp(suffix='.wav', prefix='dtmf_seq_')
        os.close(fd)
        try:
            write_wav_file(frames_bytes, n_samples, path)
            played = play_file_platform(path)
            if not played:
                print(f"Playback not available. WAV saved to: {path}")
            else:
                threading.Event().wait((n_samples / SAMPLE_RATE) + 0.5)
                try:
                    os.remove(path)
                except Exception:
                    pass
        except Exception as e:
            print("Error generating or playing sequence:", e)
            print("WAV file left at:", path)
    threading.Thread(target=worker, daemon=True).start()

def play_single_key_async(key):
    frames, n = synthesize_frames_for_key(key)
    play_wav_bytes_async(frames, n)

def play_sequence_async(sequence, gap_duration=GAP_DURATION):
    if not sequence:
        return
    frames, n = build_sequence_wav_bytes(sequence, tone_duration=TONE_DURATION, gap_duration=gap_duration)
    play_wav_bytes_async(frames, n)

class DTMFApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("DTMF Dialer with Adjustable Redial Gap")
        self.resizable(False, False)
        self.last_dialed = ""
        self.redial_gap = DEFAULT_REDIAL_GAP
        self._build_ui()

    def _build_ui(self):
        frame = ttk.Frame(self, padding=12)
        frame.grid(row=0, column=0)
        keys = [['1','2','3'], ['4','5','6'], ['7','8','9'], ['*','0','#']]
        for r, row in enumerate(keys):
            for c, key in enumerate(row):
                btn = ttk.Button(frame, text=key, width=6, command=lambda k=key: self._press_key(k))
                btn.grid(row=r, column=c, padx=6, pady=6)

        redial_btn = ttk.Button(frame, text="Redial", width=6, command=self._redial)
        redial_btn.grid(row=4, column=0, padx=6, pady=(8,0))
        call_btn = ttk.Button(frame, text="Call", width=6, command=self._call)
        call_btn.grid(row=4, column=1, padx=6, pady=(8,0))
        clear_btn = ttk.Button(frame, text="Clear", width=6, command=self._clear_display)
        clear_btn.grid(row=4, column=2, padx=6, pady=(8,0))

        ttk.Label(frame, text="Redial gap (s):").grid(row=6, column=0, columnspan=1, pady=(8,0))
        self.gap_var = tk.DoubleVar(value=self.redial_gap)
        gap_scale = ttk.Scale(frame, from_=0.2, to=3.0, orient='horizontal', variable=self.gap_var, command=self._on_gap_change)
        gap_scale.grid(row=6, column=1, columnspan=2, sticky='we', padx=(6,0), pady=(8,0))

        # Nickel, Dime, Quarter buttons (play dual tones)
        nickel_btn = ttk.Button(frame, text="Nickel", width=6, command=lambda: play_single_key_async('N'))
        nickel_btn.grid(row=7, column=0, padx=6, pady=(8,0))
        dime_btn = ttk.Button(frame, text="Dime", width=6, command=lambda: play_single_key_async('D'))
        dime_btn.grid(row=7, column=1, padx=6, pady=(8,0))
        quarter_btn = ttk.Button(frame, text="Quarter", width=6, command=lambda: play_single_key_async('Q'))
        quarter_btn.grid(row=7, column=2, padx=6, pady=(8,0))

        self.display_var = tk.StringVar(value="")
        disp = ttk.Entry(frame, textvariable=self.display_var, width=20, justify='center', font=('Helvetica', 14))
        disp.grid(row=5, column=0, columnspan=3, pady=(8, 0))
        self.bind_all('<Key>', self._on_keypress)

    def _on_gap_change(self, _):
        try:
            self.redial_gap = float(self.gap_var.get())
        except Exception:
            pass

    def _press_key(self, k):
        self.display_var.set(self.display_var.get() + k)
        play_single_key_async(k)

    def _on_keypress(self, event):
        key = event.char
        if key in DTMF:
            self._press_key(key)
        elif event.keysym == 'BackSpace':
            self.display_var.set(self.display_var.get()[:-1])

    def _call(self):
        seq = list(self.display_var.get())
        if not seq:
            messagebox.showinfo("Call", "No number entered.")
            return
        play_sequence_async(seq, gap_duration=GAP_DURATION)
        self.last_dialed = ''.join(seq)

    def _redial(self):
        seq_str = self.last_dialed if self.last_dialed else self.display_var.get()
        if not seq_str:
            messagebox.showinfo("Redial", "No last number to redial.")
            return
        seq = list(seq_str)
        spaced = ' '.join(seq)
        old_display = self.display_var.get()
        self.display_var.set(spaced)
        play_sequence_async(seq, gap_duration=self.redial_gap)
        def restore_display():
            threading.Event().wait(len(seq) * (TONE_DURATION + self.redial_gap) + 0.2)
            try:
                if self.display_var.get() == spaced:
                    self.display_var.set(old_display)
            except Exception:
                pass
        threading.Thread(target=restore_display, daemon=True).start()

    def _clear_display(self):
        self.display_var.set("")

if __name__ == '__main__':
    app = DTMFApp()
    app.mainloop()
