import math
import random
import struct
import tempfile
import threading
import tkinter as tk
import wave
import sys
import subprocess

SAMPLE_RATE = 44100

# Default global speed control (can be changed by GUI)
SLOW_FACTOR = 2.2

def play_wav(path):
    if sys.platform.startswith("win"):
        import winsound
        winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
    elif sys.platform == "darwin":
        subprocess.Popen(["afplay", path])
    else:
        subprocess.Popen(["aplay", path])

# ADSR envelope (durations scaled by SLOW_FACTOR)
def adsr(total_samples, sr, attack=0.01, decay=0.05, sustain_level=0.7, release=0.05):
    # scale time constants by SLOW_FACTOR (read current slider value)
    sf = get_speed_factor()
    attack = attack * sf
    decay = decay * sf
    release = release * sf
    a = int(attack * sr)
    d = int(decay * sr)
    r = int(release * sr)
    s = total_samples - (a + d + r)
    if s < 0:
        a = int(total_samples * (attack / (attack + decay + release)))
        d = int(total_samples * (decay / (attack + decay + release)))
        r = total_samples - a - d
        s = 0
    env = []
    for i in range(a):
        env.append(i / max(1, a))
    for i in range(d):
        env.append(1.0 - (1.0 - sustain_level) * (i / max(1, d)))
    for i in range(s):
        env.append(sustain_level)
    for i in range(r):
        env.append(sustain_level * (1.0 - (i / max(1, r))))
    return env

# One-pole lowpass filter (in-place)
def lowpass_inplace(samples, cutoff=5000.0, sr=SAMPLE_RATE):
    rc = 1.0 / (2 * math.pi * cutoff)
    dt = 1.0 / sr
    alpha = dt / (rc + dt)
    prev = 0.0
    for i in range(len(samples)):
        prev = prev + alpha * (samples[i] - prev)
        samples[i] = prev

# Band-limited noise for gentle mechanical pops (volume scaled by GUI)
def band_limited_noise(duration, cutoff=6000.0, volume=0.10):
    total = int(duration * SAMPLE_RATE)
    samples = [random.uniform(-1.0, 1.0) * volume for _ in range(total)]
    lowpass_inplace(samples, cutoff=cutoff)
    int_frames = [int(max(-1.0, min(1.0, s)) * 32767) for s in samples]
    return int_frames

# Helper to read GUI control values (safe defaults if GUI not yet created)
def get_speed_factor():
    try:
        v = speed_slider.get()
        return max(0.2, float(v))
    except Exception:
        return SLOW_FACTOR

def get_pitch_shift():
    try:
        return float(pitch_slider.get())
    except Exception:
        return 0.0

def get_noise_level():
    try:
        return float(noise_slider.get())
    except Exception:
        return 0.04

def get_fm_amount():
    try:
        return float(fm_slider.get())
    except Exception:
        return 20.0

def get_brightness():
    try:
        return float(brightness_slider.get())
    except Exception:
        return 1.0

# Synthesize a single tone with harmonics, FM, vibrato, and ADSR
def synth_note(freq, duration, volume=0.55, harmonics=(1.0, 0.5, 0.25),
               fm_index=0.0, fm_rate=5.0, vibrato_rate=6.0, vibrato_depth=0.002):
    # scale duration and modulation rates by current speed factor
    sf = get_speed_factor()
    duration = duration * sf
    fm_rate = max(0.5, fm_rate / sf)
    vibrato_rate = max(0.5, vibrato_rate / sf)
    vibrato_depth = vibrato_depth * (0.9 if sf > 1.5 else 1.0)
    total = int(duration * SAMPLE_RATE)
    env = adsr(total, SAMPLE_RATE, attack=0.012, decay=0.06, sustain_level=0.78, release=0.08)
    frames = [0.0] * total
    # brightness control scales higher partials
    bright = get_brightness()
    harmonic_muls = [1.0, 2.0, 3.0][:len(harmonics)]
    for h_amp, h_mul in zip(harmonics, harmonic_muls):
        scaled_amp = h_amp * (1.0 if h_mul == 1.0 else bright)
        for i in range(total):
            t = i / SAMPLE_RATE
            vib = math.sin(2 * math.pi * vibrato_rate * t) * vibrato_depth
            fm = fm_index * math.sin(2 * math.pi * fm_rate * t) if fm_index > 0 else 0.0
            inst_freq = freq * h_mul * (1.0 + vib) + fm
            frames[i] += scaled_amp * math.sin(2 * math.pi * inst_freq * t)
    for i in range(total):
        frames[i] *= env[i] * volume
    # gentle smoothing
    lowpass_inplace(frames, cutoff=8000.0)
    int_frames = [int(max(-1.0, min(1.0, s)) * 32767) for s in frames]
    return int_frames

def write_wav(frames, filename):
    with wave.open(filename, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SAMPLE_RATE)
        for f in frames:
            w.writeframesraw(struct.pack("<h", f))

# Mix parts with headroom and avoid harsh clipping
def mix_sequences(parts):
    end = 0
    for s, f in parts:
        end = max(end, s + len(f))
    out = [0.0] * end
    for start, frames in parts:
        for i, v in enumerate(frames):
            out[start + i] += v / 32767.0
    peak = max(1e-9, max(abs(x) for x in out))
    target = 0.85
    norm = target / peak
    int_out = [int(max(-1.0, min(1.0, x * norm)) * 32767) for x in out]
    return int_out

def play_sequence_async(frames):
    def worker():
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
            write_wav(frames, tmp.name)
            play_wav(tmp.name)
    threading.Thread(target=worker, daemon=True).start()

# --- R2 style patterns (improved) ---

def r2_beep():
    parts = []
    t = 0
    pitch_shift = get_pitch_shift()
    fm_amt = get_fm_amount()
    noise_lvl = get_noise_level()
    # tonal melodic phrase: root -> smooth glide to fifth -> glide to octave -> gentle fall
    root = int(random.choice([720, 760, 800]) * (2 ** (pitch_shift / 12.0)))
    fifth = int(root * 1.5)
    octave = root * 2
    # root sustain (warm, slightly bright)
    parts.append((t, synth_note(root, 0.45, volume=0.66, harmonics=(1.0,0.6,0.35), fm_index=fm_amt, fm_rate=80, vibrato_rate=3.5, vibrato_depth=0.0018)))
    t += int(0.36 * SAMPLE_RATE * get_speed_factor())
    # glide up to fifth by stitching short notes for smooth portamento
    frames = []
    steps = 20
    for s in range(steps):
        frac = s / (steps - 1)
        freq = root * (fifth / root) ** frac
        frames.extend(synth_note(freq, 0.6 / steps, volume=0.62, harmonics=(1.0,0.55,0.30), fm_index=fm_amt*0.7, fm_rate=70, vibrato_rate=2.8, vibrato_depth=0.0016))
    parts.append((t, frames))
    t += int(0.52 * SAMPLE_RATE * get_speed_factor())
    # glide up to octave with brighter harmonics
    frames = []
    steps = 24
    for s in range(steps):
        frac = s / (steps - 1)
        freq = fifth * (octave / fifth) ** frac
        frames.extend(synth_note(freq, 0.8 / steps, volume=0.60, harmonics=(1.0,0.75,0.45), fm_index=fm_amt*0.6, fm_rate=60, vibrato_rate=2.2, vibrato_depth=0.0012))
    parts.append((t, frames))
    t += int(0.68 * SAMPLE_RATE * get_speed_factor())
    # gentle falling tone to finish
    parts.append((t, synth_note(int(root * 0.92), 0.9, volume=0.58, harmonics=(1.0,0.48,0.22), fm_index=fm_amt*0.4, fm_rate=40, vibrato_rate=1.8, vibrato_depth=0.001)))
    t += int(0.78 * SAMPLE_RATE * get_speed_factor())
    # small, low-volume mechanical pop at the end (scaled by noise slider)
    parts.append((t, band_limited_noise(0.04 * get_speed_factor(), cutoff=3800.0, volume=noise_lvl)))
    play_sequence_async(mix_sequences(parts))

def r2_chirp():
    parts = []
    t = 0
    base = 680
    fm_amt = get_fm_amount()
    noise_lvl = get_noise_level()
    for i in range(5):
        f0 = base + i * 120
        f1 = f0 + random.randint(220, 600)
        dur = 0.6 + i * 0.12
        frames = []
        steps = 18  # more steps for smoother, slower glide
        for s in range(steps):
            frac = s / (steps - 1)
            freq = f0 * (f1 / f0) ** frac
            frames.extend(synth_note(freq, dur / steps, volume=0.56, harmonics=(1.0,0.45,0.22), fm_index=fm_amt*0.6, fm_rate=60, vibrato_rate=3.0, vibrato_depth=0.003))
        parts.append((t, frames))
        t += int((dur * 0.78) * SAMPLE_RATE * get_speed_factor())
        if random.random() < 0.2:
            parts.append((t, band_limited_noise(0.03 * get_speed_factor(), cutoff=4200.0, volume=noise_lvl*0.9)))
        t += int(0.03 * SAMPLE_RATE * get_speed_factor())
    play_sequence_async(mix_sequences(parts))

def r2_whistle():
    parts = []
    t = 0
    fm_amt = get_fm_amount()
    noise_lvl = get_noise_level()
    for i in range(3):
        freq = 500 + i * 240
        dur = 1.8 + i * 0.9
        frames = synth_note(freq, dur, volume=0.60, harmonics=(1.0,0.75,0.45,0.18), fm_index=fm_amt*0.5, fm_rate=30, vibrato_rate=2.0, vibrato_depth=0.003)
        parts.append((t, frames))
        t += int((dur * 0.9) * SAMPLE_RATE * get_speed_factor())
        if i < 2:
            parts.append((t, band_limited_noise(0.04 * get_speed_factor(), cutoff=4800.0, volume=noise_lvl*0.95)))
            t += int(0.04 * SAMPLE_RATE * get_speed_factor())
    play_sequence_async(mix_sequences(parts))

def r2_scream():
    parts = []
    t = 0
    base = random.randint(820, 1200)
    fm_amt = get_fm_amount()
    noise_lvl = get_noise_level()
    for i in range(18):
        freq = base + random.randint(-600, 600) + int(250 * math.sin(i * 0.4))
        dur = 0.12 + random.random() * 0.12
        fm = random.choice([0, int(fm_amt*0.8), int(fm_amt*1.2)])
        frames = synth_note(freq, dur, volume=0.64, harmonics=(1.0,0.6,0.35), fm_index=fm, fm_rate=random.uniform(30,90), vibrato_rate=random.uniform(2,6), vibrato_depth=0.006)
        parts.append((t, frames))
        if random.random() < 0.15:
            parts.append((t + int(dur * SAMPLE_RATE * 0.6), band_limited_noise(0.03 * get_speed_factor(), cutoff=4200.0, volume=noise_lvl*0.9)))
        t += int(dur * SAMPLE_RATE * 0.88 * get_speed_factor())
    play_sequence_async(mix_sequences(parts))

def r2_random():
    parts = []
    t = 0
    fm_amt = get_fm_amount()
    noise_lvl = get_noise_level()
    for _ in range(8):
        freq = random.randint(420, 2400)
        dur = random.uniform(0.14, 0.5)
        fm = random.choice([0, 10, int(fm_amt*0.6)])
        frames = synth_note(freq, dur, volume=0.56, harmonics=(1.0,0.48,0.28), fm_index=fm, fm_rate=random.uniform(20,120), vibrato_rate=2.5, vibrato_depth=0.004)
        parts.append((t, frames))
        if random.random() < 0.2:
            parts.append((t + int(dur * SAMPLE_RATE * 0.5), band_limited_noise(0.025 * get_speed_factor(), cutoff=4600.0, volume=noise_lvl*0.85)))
        t += int(dur * SAMPLE_RATE * 0.7 * get_speed_factor())
    play_sequence_async(mix_sequences(parts))

# GUI
root = tk.Tk()
root.title("R2‑D2 Soundboard — Controls")

# Controls frame
ctrl = tk.Frame(root)
ctrl.pack(side="top", fill="x", padx=8, pady=6)

tk.Label(ctrl, text="Speed (1 = normal, >1 = slower)").grid(row=0, column=0, sticky="w")
speed_slider = tk.Scale(ctrl, from_=0.5, to=4.0, resolution=0.1, orient="horizontal")
speed_slider.set(SLOW_FACTOR)
speed_slider.grid(row=0, column=1, sticky="ew", padx=6)

tk.Label(ctrl, text="Pitch Shift (semitones)").grid(row=1, column=0, sticky="w")
pitch_slider = tk.Scale(ctrl, from_=-12, to=12, resolution=1, orient="horizontal")
pitch_slider.set(0)
pitch_slider.grid(row=1, column=1, sticky="ew", padx=6)

tk.Label(ctrl, text="Noise Level").grid(row=2, column=0, sticky="w")
noise_slider = tk.Scale(ctrl, from_=0.0, to=0.12, resolution=0.01, orient="horizontal")
noise_slider.set(0.04)
noise_slider.grid(row=2, column=1, sticky="ew", padx=6)

tk.Label(ctrl, text="FM Amount").grid(row=3, column=0, sticky="w")
fm_slider = tk.Scale(ctrl, from_=0, to=120, resolution=1, orient="horizontal")
fm_slider.set(30)
fm_slider.grid(row=3, column=1, sticky="ew", padx=6)

tk.Label(ctrl, text="Brightness (harmonics)").grid(row=4, column=0, sticky="w")
brightness_slider = tk.Scale(ctrl, from_=0.4, to=1.8, resolution=0.05, orient="horizontal")
brightness_slider.set(1.0)
brightness_slider.grid(row=4, column=1, sticky="ew", padx=6)

# Buttons frame
btns = [
    ("Beep (Tonal)", r2_beep),
    ("Chirp", r2_chirp),
    ("Whistle", r2_whistle),
    ("R2 Scream", r2_scream),
    ("Random Droid Noise", r2_random),
]

btn_frame = tk.Frame(root)
btn_frame.pack(side="top", pady=8)

for i, (label, func) in enumerate(btns):
    b = tk.Button(btn_frame, text=label, width=20, height=2, command=func)
    b.grid(row=i // 2, column=i % 2, padx=6, pady=6)

root.mainloop()
