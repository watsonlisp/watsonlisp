import random
import textwrap
import subprocess
import platform
import shutil
import time

TEMPLATES = {
    "gentle": [
        "You’re doing well with {subject}. Take it one step at a time — you’ve got this.",
        "Small progress on {subject} is still progress. Be kind to yourself and keep going.",
        "Remember why you started {subject}. Quiet persistence wins.",
        "One calm breath at a time as you work on {subject}. You’re moving forward.",
        "It’s okay to rest between efforts on {subject}. Rest is part of progress.",
        "You don’t need to be perfect at {subject} to make meaningful progress.",
        "Softly notice what’s working with {subject} and build from there.",
        "A steady, gentle pace with {subject} will carry you farther than a sprint.",
        "You’ve handled hard things before; you can handle {subject} too.",
        "Small, consistent steps toward {subject} add up in surprising ways.",
        "Be patient with yourself while you learn and grow with {subject}.",
        "Let curiosity, not pressure, guide you through {subject}.",
        "Celebrate tiny wins in {subject}; they matter more than you think.",
        "It’s okay to ask for help with {subject}. Asking is strength.",
        "You’re allowed to feel unsure about {subject} and still keep going.",
        "Treat yourself with the same kindness you’d give a friend tackling {subject}.",
        "Focus on what you can control about {subject} and release the rest.",
        "Gentle persistence with {subject} builds confidence over time.",
        "You’re making space for growth by showing up to {subject} today.",
        "Let small acts of care support your work on {subject}."
    ],
    "confident": [
        "You’re ready for {subject}. Trust your preparation and go show them what you can do.",
        "Own {subject} — you have the skills and the focus to succeed.",
        "This is your moment with {subject}. Step forward with confidence.",
        "You’ve prepared for {subject}; now execute with clarity and purpose.",
        "Stand tall and tackle {subject} with the competence you’ve earned.",
        "You know more than you think about {subject}. Use that knowledge.",
        "Approach {subject} like a pro: calm, decisive, and focused.",
        "You’re built for challenges like {subject}. Meet it head-on.",
        "Lead with your strengths when you face {subject}. They’ll carry you.",
        "You’ve overcome obstacles before; treat {subject} the same way.",
        "Make a plan for {subject} and then act — momentum favors the bold.",
        "Confidence is a choice; choose it as you approach {subject}.",
        "You’re capable of more than you imagine — start with {subject}.",
        "Take command of {subject} with steady focus and clear intent.",
        "Show up for {subject} with the conviction you’d expect from a winner.",
        "You’ve got the tools for {subject}; now put them to work.",
        "Trust your instincts on {subject} — they’ve guided you well before.",
        "Execute {subject} with precision and the quiet confidence of experience.",
        "You’re the person who can make {subject} happen — act like it.",
        "Bring your best to {subject} and let results follow."
    ],
    "playful": [
        "Crush {subject} like a pro — but maybe wear a cape while you do it.",
        "If {subject} were a boss level, you’d already have the cheat codes.",
        "Make {subject} your playground today — have fun and surprise yourself.",
        "Treat {subject} like a puzzle: twist, turn, and enjoy the click when it fits.",
        "Turn up the music and make {subject} a dance-off you can win.",
        "Imagine {subject} as a silly challenge — then beat it with a grin.",
        "Give {subject} a quirky name and show it who’s boss.",
        "Approach {subject} like a curious kid — fearless and a little messy.",
        "Play a tiny game with {subject}: one small win every 20 minutes.",
        "Make a victory sound after each step of {subject}; celebrate the process.",
        "Pretend {subject} is a story you get to write — add a twist and enjoy it.",
        "Treat mistakes in {subject} like bloopers in a comedy — laugh and redo.",
        "Turn {subject} into a mini-adventure and collect silly trophies along the way.",
        "If {subject} had a theme song, what would it be? Sing it while you work.",
        "Challenge yourself to a playful time limit for {subject} and sprint with joy.",
        "Make a silly ritual before {subject} to flip your mood into ‘can-do’ mode.",
        "Imagine future-you high-fiving you for finishing {subject}. Now go earn it.",
        "Give yourself a goofy reward after {subject} — you deserve it.",
        "Treat {subject} like a creative experiment: try, tweak, repeat.",
        "Be the playful hero of your own {subject} story."
    ],
    "spiritual": [
        "Place {subject} in your hands and breathe. You are guided and capable.",
        "Let faith steady you as you approach {subject}. Peace and purpose will follow.",
        "Pray, prepare, and proceed with calm confidence in {subject}.",
        "Center yourself before {subject}; clarity comes from stillness.",
        "Offer your effort on {subject} with humility and trust in the outcome.",
        "Invite quiet reflection before tackling {subject}; wisdom often arrives there.",
        "Surrender worry about {subject} and focus on the next right step.",
        "Let gratitude for the chance to work on {subject} lift your spirit.",
        "Anchor your intention for {subject} in something larger than the moment.",
        "Seek balance as you pursue {subject}; soul-care fuels sustained effort.",
        "Trust that each small act toward {subject} is part of a greater path.",
        "Hold compassion for yourself while you engage with {subject}.",
        "Let stillness guide your choices around {subject}; act from presence.",
        "Offer patience and faith as companions while you work on {subject}.",
        "Invite a sense of sacredness into the ordinary tasks of {subject}.",
        "Breathe, release fear, and move forward with quiet resolve on {subject}.",
        "Let your values lead decisions about {subject}; they point the way.",
        "Seek meaning in the work of {subject}, not just the outcome.",
        "Trust the process and keep a steady heart as you pursue {subject}.",
        "May peace accompany every step you take toward {subject}."
    ]
}

STRENGTH_MODIFIERS = {
    "mild": ["A gentle reminder:", "A little nudge:", "A soft word of encouragement:"],
    "medium": ["A reminder:", "A solid push:", "A helpful nudge:"],
    "strong": ["A rallying cry:", "Go for it:", "Full steam ahead:"]
}

def generate_encouragement(subject: str,
                           tone: str = "gentle",
                           strength: str = "medium",
                           name: str | None = None) -> str:
    tone = tone if tone in TEMPLATES else "gentle"
    strength = strength if strength in STRENGTH_MODIFIERS else "medium"
    template = random.choice(TEMPLATES[tone])
    modifier = random.choice(STRENGTH_MODIFIERS[strength])
    subject_text = subject.strip() or "this"
    message = f"{modifier} {template.format(subject=subject_text)}"
    if name:
        message = f"{name}, {message[0].lower() + message[1:]}"
    return textwrap.fill(message, width=72)

def speak(text: str) -> bool:
    """
    Try to speak text using system TTS without external Python packages.
    Returns True if a TTS method was invoked, False otherwise.
    """
    system = platform.system()
    # macOS: say
    if system == "Darwin" and shutil.which("say"):
        try:
            subprocess.run(["say", text], check=False)
            return True
        except Exception:
            pass
    # Windows: use PowerShell System.Speech
    if system == "Windows":
        ps_command = (
            "Add-Type -AssemblyName System.Speech;"
            f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak([Console]::In.ReadToEnd())"
        )
        try:
            subprocess.run(["powershell", "-Command", ps_command],
                           input=text.encode("utf-8"), check=False)
            return True
        except Exception:
            pass
    # Linux: try spd-say then espeak
    if system == "Linux":
        if shutil.which("spd-say"):
            try:
                subprocess.run(["spd-say", text], check=False)
                return True
            except Exception:
                pass
        if shutil.which("espeak"):
            try:
                subprocess.run(["espeak", text], check=False)
                return True
            except Exception:
                pass
    # No TTS available
    return False

def prompt_input(prompt_text: str, default: str | None = None) -> str:
    raw = input(prompt_text).strip()
    return raw if raw else (default or "")

def interactive_loop(autoplay: bool = True, pause_after_speak: float = 0.2):
    print("Encouragement generator — type 'quit' at any prompt to exit.")
    last_args = None
    last_message = None

    while True:
        if last_args is None:
            subj = prompt_input("Subject or task (e.g., 'studying for finals'): ", "what you're doing")
            if subj.lower() == "quit":
                break
            tone = prompt_input("Tone (gentle/confident/playful/spiritual) [gentle]: ", "gentle").lower()
            if tone == "quit":
                break
            strength = prompt_input("Strength (mild/medium/strong) [medium]: ", "medium").lower()
            if strength == "quit":
                break
            name = prompt_input("Name to personalize (optional): ", "").strip() or None
            if name and name.lower() == "quit":
                break

            last_args = (subj, tone, strength, name)
            last_message = generate_encouragement(*last_args)
            print("\n" + last_message + "\n")

            if autoplay:
                played = speak(last_message)
                if not played:
                    print("No system TTS found. Install 'say' (mac), 'spd-say'/'espeak' (linux), or ensure PowerShell is available on Windows.\n")
                else:
                    # small pause to avoid overlapping terminal output and speech
                    time.sleep(pause_after_speak)
        else:
            cmd = prompt_input("Enter command — [R]epeat, [N]ew, [Q]uit: ", "R").lower()
            if cmd in ("q", "quit"):
                break
            elif cmd in ("r", "repeat"):
                last_message = generate_encouragement(*last_args)
                print("\n" + last_message + "\n")
                if autoplay:
                    played = speak(last_message)
                    if not played:
                        print("No system TTS found. Install 'say' (mac), 'spd-say'/'espeak' (linux), or ensure PowerShell is available on Windows.\n")
                    else:
                        time.sleep(pause_after_speak)
            elif cmd in ("n", "new"):
                last_args = None
            else:
                print("Unknown command. Type R, N, or Q.\n")

    print("Good luck — take care!")

if __name__ == "__main__":
    interactive_loop()
