#!/usr/bin/env python3
import random
import shutil
import subprocess
import sys
import platform
import time

def has_command(cmd):
    return shutil.which(cmd) is not None

def speak(text):
    system = platform.system()
    text = str(text)
    try:
        if system == "Darwin" and has_command("say"):
            subprocess.run(["say", text], check=False)
            return
        if system == "Linux" and has_command("espeak"):
            subprocess.run(["espeak", text], check=False)
            return
        if system == "Windows":
            ps = (
                "Add-Type -AssemblyName System.speech;"
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                "$s.Speak([Console]::In.ReadToEnd());"
            )
            p = subprocess.Popen(["powershell", "-Command", ps], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True)
            p.communicate(text)
            return
    except Exception:
        pass
    print("[SPEAK]", text)

def edit_distance(a: str, b: str) -> int:
    a, b = a.lower(), b.lower()
    n, m = len(a), len(b)
    if n == 0:
        return m
    if m == 0:
        return n
    dp = list(range(m + 1))
    for i in range(1, n + 1):
        prev = dp[0]
        dp[0] = i
        for j in range(1, m + 1):
            cur = dp[j]
            cost = 0 if a[i - 1] == b[j - 1] else 1
            dp[j] = min(dp[j] + 1, dp[j - 1] + 1, prev + cost)
            prev = cur
    return dp[m]

WORDS = {
    "easy": [
        "cat","dog","sun","book","tree","milk","cup","hat","blue","car",
        "ball","fish","bird","shoe","pen","desk","chair","door","apple","leaf",
        "rain","snow","star","moon","bed","sock","ring","key","map","road",
        "cake","egg","hand","nose","ear","eye","lip","hair","farm","park",
        "boat","train","bike","glass","plate","fork","spoon","lamp","coin","bell"
    ],
    "medium": [
        "planet","guitar","window","puzzle","coffee","jungle","orchard","holiday",
        "market","library","teacher","student","picture","kitchen","battery","candle",
        "diamond","harvest","journey","lantern","musical","notebook","opera","passport",
        "quarter","railroad","sandwich","theater","umbrella","village","whistle","yogurt",
        "zephyr","bicycle","calendar","document","elevator","festival","gallery","horizon",
        "island","journal","keyboard","language","mountain","notable","oxygen","package",
        "quality","recycle"
    ],
    "hard": [
        "dictionary","architecture","congratulation","imagination","philosophy",
        "metamorphosis","conscientious","extraordinary","hippopotamus","infrastructure",
        "juxtaposition","kaleidoscope","lexicography","microbiology","neuroscience",
        "onomatopoeia","photosynthesis","quintessential","rendezvous","sophisticated",
        "transcendental","ubiquitous","vulnerability","weathering","xylophone",
        "yesteryear","zoogeography","anachronistic","belligerence","circumference",
        "dichotomy","electrolysis","fragmentation","gentrification","heterogeneous",
        "iconography","jurisdiction","karyotype","luminescence","multifarious",
        "nostalgia","oxidization","paradigmatic","quantification","reciprocity",
        "semiconductor","thermodynamics","unprecedented","vernacular","wavelength",
        "xenophobia","yielding","zooplankton"
    ],
    "animals": [
        "antelope","badger","cheetah","dolphin","elephant","flamingo","giraffe",
        "hedgehog","iguana","jaguar","kangaroo","lemur","mongoose","narwhal",
        "octopus","porcupine","quokka","raccoon","salamander","tapir","uakari",
        "vulture","walrus","xerus","yak","zebra","albatross","buffalo","caribou",
        "dingo","emu","ferret","gazelle","hyena","ibex","kudu","llama","mole",
        "newt","opossum","panda","quail","reindeer","skunk","toucan","urchin",
        "vole","wombat","yakutian","zorilla"
    ],
    "science": [
        "atom","bacteria","cell","density","enzyme","fusion","gravity","hormone",
        "ion","junction","kinetic","laser","molecule","neutron","orbit","protein",
        "quantum","radiation","spectrum","telescope","ultraviolet","vaccine",
        "wavelength","xenon","yield","zygote","allele","biosphere","catalyst",
        "diffusion","ecosystem","filament","genome","habitat","isotope","joule",
        "kilogram","ligand","mitosis","neutrino","oxidation","photon","quark",
        "resonance","synapse","taxonomy","vector","workload"
    ]
}

def available_categories():
    return sorted(WORDS.keys())

def choose_word(category):
    return random.choice(WORDS.get(category, WORDS["easy"]))

def score_for_distance(word, guess):
    dist = edit_distance(word, guess)
    max_len = max(len(word), 1)
    raw = max(0.0, (max_len - dist) / max_len)
    return int(round(raw * 100)), dist

def play_round(category, allow_hint):
    word = choose_word(category)
    speak(f"Spell the word: {word}")
    attempts = 0
    while True:
        attempts += 1
        guess = input("Your spelling (type 'repeat', 'hint', 'skip', or 'quit'): ").strip()
        if guess == "":
            print("Please type something or use a command.")
            continue
        cmd = guess.lower()
        if cmd == "repeat":
            speak(word)
            continue
        if cmd == "hint" and allow_hint:
            if len(word) <= 2:
                hint = word
            else:
                hint = word[0] + "_" * (len(word) - 2) + word[-1]
            print("Hint:", hint)
            speak(f"The first letter is {word[0]}")
            continue
        if cmd == "skip":
            print("Skipped. The word was:", word)
            return 0, word, False, False
        if cmd == "quit":
            print("Quitting game...")
            return 0, word, False, True
        score, dist = score_for_distance(word, guess)
        correct = dist == 0
        if correct:
            speak("Correct")
            print(f"Correct! +{score} points")
        else:
            speak("Not quite")
            print(f"Distance: {dist}. Score: {score}")
        return score, word, correct, False

def run_game_session():
    cats = available_categories()
    print("Available categories:", ", ".join(cats))
    category = ""
    while category not in cats:
        category = input("Choose a category (type name) [easy]: ").strip().lower() or "easy"
        if category == "quit":
            return None  # signal quit
    rounds_input = input("How many rounds? [10]: ").strip()
    try:
        rounds = int(rounds_input) if rounds_input else 10
    except ValueError:
        rounds = 10
    allow_hint = input("Allow hints? (y/N): ").strip().lower() == "y"
    total = 0
    correct_count = 0
    streak = 0
    best_streak = 0
    start_time = time.time()
    rounds_played = 0
    for r in range(1, rounds + 1):
        print("\n---")
        print(f"Round {r}/{rounds} — Category: {category}")
        score, word, correct, quit_flag = play_round(category, allow_hint)
        if quit_flag:
            break
        rounds_played += 1
        total += score
        if correct:
            correct_count += 1
            streak += 1
            best_streak = max(best_streak, streak)
        else:
            streak = 0
    elapsed = time.time() - start_time
    avg = total / (rounds_played if rounds_played else 1)
    print("\n=== Results ===")
    print(f"Rounds attempted: {rounds_played}")
    print(f"Correct: {correct_count}")
    print(f"Total score: {total}")
    print(f"Best streak: {best_streak}")
    print(f"Average score per round: {avg:.1f}")
    print(f"Time elapsed: {int(elapsed)} seconds")
    speak("Game over. Well done.")
    return True  # session completed (or ended by skip/rounds), not a quit during setup

def main():
    print("Speak and Spell — expanded word lists (type 'quit' anytime to exit)")
    while True:
        result = run_game_session()
        if result is None:
            print("Goodbye.")
            return
        # Ask to replay; default is Yes to match "repeat when it ends"
        ans = input("Play again? (Y/n) [Y]: ").strip().lower()
        if ans == "" or ans == "y" or ans == "yes":
            print("Starting a new game...\n")
            continue
        else:
            print("Goodbye.")
            return

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nGoodbye.")
        sys.exit(0)
