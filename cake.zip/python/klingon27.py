# klingon_translator_system_tts_expanded.py
# Expanded PHRASEBOOK (hundreds of English entries) + robust system TTS and automatic STT.
# Python 3.8+. No external Python packages required for fallback STT; will use SpeechRecognition if installed.

import re
import json
import sys
import shutil
import subprocess
import base64
import argparse
import tempfile
import os
import time
from pathlib import Path

# --- Configuration ---
WAKE_WORD = "cat cat"
MAX_PHRASE_LEN = 8
DEBUG = False  # set True to print attempted TTS commands and debug info

_tts_warned = False

# Set to True to have the program speak a short confirmation when STT is toggled
TTS_CONFIRM_ON_TOGGLE = True

# --- Very large PHRASEBOOK_RAW (expanded) ---
PHRASEBOOK_RAW = {
    # greetings and small talk
    "hello": "nuqneH", "hi": "nuqneH", "hey": "nuqneH", "greetings": "nuqneH",
    "good morning": "maj ram", "good afternoon": "maj rep", "good evening": "maj ram",
    "good night": "maj ram", "goodbye": "Qapla'", "bye": "Qapla'", "see you": "Qapla'",
    "welcome": "yI'el", "how are you": "qatlho' SoH", "how's it going": "qatlho' SoH",
    "i am fine": "jIH maj", "i'm fine": "jIH maj", "not bad": "maj", "what's up": "nuq 'oH",
    "nothing much": "ghobe'", "congratulations": "majQa'", "well done": "majQa'",
    "thank you": "qatlho'", "thanks": "qatlho'", "thank you very much": "qatlho' Hoch",
    "you're welcome": "maj", "please": "qatlho'", "sorry": "jIyajbe'", "excuse me": "yIbuS",
    "pardon": "yIbuS", "help": "QaH", "i need help": "QaH vIneH", "emergency": "Qagh",
    "good luck": "Qapla'", "well played": "majQa'", "i'm sorry": "jIyajbe'", "please forgive me": "yIbuS jIH",
    "i love you": "qamuSHa'", "i miss you": "jIH Hegh", "how old are you": "SoH DIS 'ar",
    "what is your name": "pong 'oH nuq?",

    # affirmation / negation / confirmations
    "yes": "HIja'", "yeah": "HIja'", "yep": "HIja'", "no": "ghobe'", "nope": "ghobe'",
    "maybe": "vIghro'", "ok": "maj", "okay": "maj", "sure": "HIja'", "of course": "HIja'",
    "confirm": "yIvoq", "cancel": "yIghoSbe'", "abort": "Qaw'", "retry": "yIghoS",
    "repeat": "yIghoS", "again": "reH", "done": "Qapla'", "finished": "Qapla'",

    # numbers and ordinals
    "zero": "pagh", "one": "wa'", "two": "cha'", "three": "wej", "four": "loS",
    "five": "vagh", "six": "jav", "seven": "Soch", "eight": "chorgh", "nine": "Hut",
    "ten": "wa'maH", "eleven": "wa'maH wa'", "twelve": "wa'maH cha'", "thirteen": "wa'maH wej",
    "fourteen": "wa'maH loS", "fifteen": "wa'maH vagh", "twenty": "cha'maH", "thirty": "wejmaH",
    "forty": "loSmaH", "fifty": "vaghmaH", "sixty": "javmaH", "seventy": "SochmaH",
    "eighty": "chorghmaH", "ninety": "HutmaH", "hundred": "vatlh", "thousand": "SaD",
    "million": "vatlh SaD", "first": "wa'", "second": "cha'", "third": "wej",

    # time and scheduling
    "now": "DaH", "later": "wa'leS", "soon": "Qap", "in a minute": "tupDaq",
    "in an hour": "repDaq", "today": "DaHjaj", "tomorrow": "wa'leS", "yesterday": "wa'leS",
    "morning": "ram", "afternoon": "rep", "evening": "ram", "night": "ram",
    "minute": "tup", "hour": "rep", "day": "jaj", "week": "Hoch jaj", "month": "jar",
    "year": "DIS", "schedule": "jar yI'el", "appointment": "jar yI'el", "deadline": "Qap",
    "always": "reH", "never": "pagh", "often": "pIv", "sometimes": "wa'logh",

    # file and project operations
    "new file": "chu' De'", "create file": "chu' De'", "open file": "yIvang De'",
    "close file": "yIghoS De'", "save file": "qet De'", "save as": "qet 'ej pong",
    "save all": "Hoch qet", "load project": "yIghItlh porgh", "export": "yIghItlh",
    "import": "yIvang", "undo": "yIghoSbe'", "redo": "yIghoS", "delete file": "Qaw' De'",
    "remove file": "Qaw' De'", "rename": "pong yI'el", "duplicate": "Qapchu'", "copy": "Qapchu'",
    "paste": "Qapchu' yI'el", "cut": "Qapchu' Qaw'", "move": "yIghoS", "move to": "yIghoS 'e'",
    "open recent": "yIvang Qap", "project settings": "porgh mIw", "close project": "yIghoS porgh",
    "export as": "yIghItlh 'ej pong", "archive": "Qap", "compress": "Qap",
    "deploy": "yIghItlh", "upload": "yIghItlh", "download": "yIvang",

    # editing and selection
    "select": "yIchoH", "select all": "Hoch yIchoH", "deselect": "yIchoHbe'",
    "deselect all": "Hoch yIchoHbe'", "select none": "pagh yIchoH", "invert selection": "yIghoS yIchoH",
    "group": "Qotlh", "ungroup": "Qotlhbe'", "lock": "Qotlh", "unlock": "Qotlhbe'",
    "hide": "yI'angbe'", "show": "yI'ang", "find": "Qap", "search": "Qap",
    "replace": "yIghoS 'ej yI'el", "replace all": "Hoch yIghoS 'ej yI'el", "clear": "Qaw'",
    "delete selection": "Qaw' Hoch", "trim": "Qaw' yIghoS", "extend": "yIghun",
    "select item": "yIchoH Qap",

    # view and navigation
    "zoom in": "yIghaj wej", "zoom out": "yIghaj wa'", "fit to screen": "Qotlh yIghoS",
    "full screen": "Qotlh yIghoS", "pan left": "Qo' yIghoS", "pan right": "Qa' yIghoS",
    "pan up": "SuD yIghoS", "pan down": "pov yIghoS", "center view": "Qotlh yIghun",
    "next view": "wa'maH yI'el", "previous view": "wa' yI'el", "first page": "wa' DuH",
    "last page": "wa' SaD", "page up": "SuD yIghoS", "page down": "pov yIghoS",
    "toggle grid": "Qeb yI'ang/ yI'angbe'", "show rulers": "yI'ang Qeb", "hide rulers": "yI'angbe' Qeb",
    "open tab": "De' yIvang", "close tab": "De' yIghoS", "new window": "chu' Qotlh", "refresh page": "Qap",

    # drawing and CAD commands
    "line": "tlhegh", "draw line": "tlhegh yI'el", "start line": "tlhegh yI'el",
    "circle": "Hov", "draw circle": "Hov yI'el", "arc": "tlhej", "ellipse": "tlhejDaq",
    "rectangle": "tlhejDaq", "square": "tlhejDaq", "polygon": "tlhejDaq", "spline": "tlhej 'ej Qap",
    "bezier": "tlhej 'ej Qap", "point": "Daq", "draw point": "Daq yI'el", "measure": "Qap",
    "dimension": "Qap", "offset": "yIghaj", "fillet": "yIghun", "chamfer": "yIghun",
    "explode": "Qaw' Qotlh", "join": "Qap", "union": "Qap Hoch", "subtract": "Qaw' Qap",
    "intersect": "Qap Qap", "extrude": "yIghItlh", "revolve": "yIghun", "loft": "Qap",
    "sweep": "yIghItlh", "shell": "Qap", "thicken": "yIghaj", "scale": "yIghaj",
    "rotate": "yIghun", "move object": "Qap yIghoS", "snap on": "yIghoS", "snap off": "yIghoSbe'",
    "snap to grid": "Qeb yIghoS", "snap to point": "Daq yIghoS", "snap to object": "Qap yIghoS",
    "set origin": "Qutluch pong", "set pivot": "Qutluch pong", "align": "yIghun", "distribute": "yIghun",
    "measure distance": "Qap Qap", "measure angle": "Qap ghItlh", "center point": "Qotlh Daq",

    # layers and visibility
    "create layer": "Qotlh chu'", "new layer": "Qotlh chu'", "delete layer": "Qotlh Qaw'",
    "rename layer": "Qotlh pong yI'el", "show layer": "Qotlh yI'ang", "hide layer": "Qotlh yI'angbe'",
    "lock layer": "Qotlh Qotlh", "unlock layer": "Qotlh Qotlhbe'", "move layer up": "Qotlh yuk",
    "move layer down": "Qotlh po'", "merge layers": "Qap Hoch", "duplicate layer": "Qapchu' Qotlh",

    # colors and styles
    "color": "qIj", "red": "qIj", "green": "SuD", "blue": "Doq", "black": "qIj", "white": "SuD",
    "yellow": "Doq", "magenta": "Doq", "cyan": "Doq", "orange": "Doq", "purple": "Doq",
    "brown": "Doq", "gray": "Doq", "grey": "Doq", "transparent": "Qapbe'", "fill": "Qap",
    "stroke": "Qap", "thickness": "Qap", "width": "Qap", "height": "Qap", "opacity": "Qap",
    "style": "Qap", "line weight": "Qap",
    "bright": "Qap", "dark": "Qapbe'", "shiny": "quv", "matte": "Qapbe'",

    # text and annotation
    "text": "ghItlh", "insert text": "ghItlh yI'el", "edit text": "ghItlh yIghoS", "font": "ghItlh",
    "font size": "ghItlh Qap", "bold": "Qap", "italic": "Qap", "underline": "Qap", "label": "pong",
    "annotation": "pong", "leader": "Qap", "caption": "pong", "note": "pong",

    # units and measurements
    "millimeter": "mm", "millimeters": "mm", "centimeter": "cm", "centimeters": "cm",
    "meter": "m", "meters": "m", "inch": "in", "inches": "in", "foot": "ft", "feet": "ft",
    "degree": "ghItlh", "degrees": "ghItlh", "radian": "radian", "percent": "vatlh", "units": "Qap",

    # automation and scripting
    "run macro": "mIw yI'el", "stop macro": "mIw yI'elbe'", "start module": "yI'el Qutluch",
    "stop module": "yI'el Qaw'", "reload module": "yIghItlh Qutluch", "compile": "Qap", "build": "Qap",
    "execute": "yI'el", "script": "mIw", "run script": "mIw yI'el", "schedule": "jar yI'el",
    "trigger": "yI'el", "automation": "mIw", "macro": "mIw", "deploy": "yIghItlh",

    # system and device
    "settings": "mIw", "preferences": "mIw", "options": "mIw", "system status": "De' mIw",
    "status": "mIw", "update": "Qap", "upgrade": "Qap", "install": "Qap", "uninstall": "Qapbe'",
    "restart": "yIghoS", "shutdown": "yI'el", "sleep": "Qap", "wake": "yI'el", "connect": "qap",
    "disconnect": "qapbe'", "connected": "qap", "disconnected": "qapbe'", "network": "De' Qap",
    "battery": "Qap", "power": "Qap", "storage": "De' Qap", "memory": "De' Qap",
    "update available": "Qap vIghItlh", "battery low": "Qapbe' De'", "network error": "De' Qap Qagh",

    # voice and microphone controls
    "wake word": "pong yI'el", "wake": "yI'el", "sleep voice": "ghItlh Qapbe'", "start listening": "yIghoS",
    "stop listening": "yIghoSbe'", "mute microphone": "ghItlh Qapbe'", "unmute microphone": "ghItlh Qap",
    "mute": "ghItlh Qapbe'", "unmute": "ghItlh Qap", "voice mode": "ghItlh yI'el",
    "dictation mode": "ghItlh yI'el", "command mode": "mIw yI'el", "switch to dictation": "ghItlh yI'el",
    "switch to command": "mIw yI'el", "help me": "QaH vIneH", "i want": "vIneH",

    # responses and confirmations
    "i understand": "jIyaj", "i don't understand": "jIyajbe'", "i do not understand": "jIyajbe'",
    "repeat that": "yIghoS", "please repeat": "yIghoS", "confirm action": "yIvoq mIw",
    "action completed": "mIw Qapla'", "action failed": "mIw Qagh", "error": "Qagh", "warning": "Qagh",
    "success": "Qapla'",

    # common verbs and helpers
    "open": "yIvang", "close": "yIghoS", "start": "Qutluch", "stop": "yI'el Qaw'", "pause": "yIghoS",
    "resume": "yI'el", "search": "Qap", "find": "Qap", "replace": "yIghoS 'ej yI'el", "go to": "yIghoS 'e'",
    "show me": "yI'ang", "hide from me": "yI'angbe'", "list commands": "mIw lo'", "what can i say": "nuq vIjatlh",
    "go": "yIghoS", "come": "yI'el", "stop": "Qaw'",

    # short command variants and phonetic-friendly forms
    "cat": "pong", "cat cat": "pong pong", "hey cat": "pong yI'el", "ok cat": "pong maj",
    "start line": "tlhegh yI'el", "line line": "tlhegh tlhegh", "circle circle": "Hov Hov",
    "draw": "yI'el", "make": "Qap", "build": "Qap", "create": "Qap", "new layer": "Qotlh chu'",

    # developer and debugging
    "log": "Qagh", "show logs": "Qagh yI'ang", "clear logs": "Qagh yIghoS", "debug on": "Qagh yI'el",
    "debug off": "Qagh yI'elbe'", "verbose": "Qap", "trace": "Qap", "profile": "mIw",

    # miscellaneous and conversational fillers
    "i'm ready": "jIH Qap", "not ready": "jIH Qapbe'", "wait": "yIghoS", "hold on": "yIghoS",
    "go ahead": "yI'el", "proceed": "yI'el", "cancel operation": "mIw yIghoSbe'", "are you sure": "bIjatlh 'e' yIbuS",
    "yes i'm sure": "HIja' jIH", "no i'm not sure": "ghobe' jIH", "confirm delete": "Qaw' yIvoq",
    "confirm save": "qet yIvoq", "show help": "QaH yI'ang", "help topics": "QaH mIw", "commands list": "mIw lo'",

    # directions and navigation
    "left": "Qo'", "right": "Qa'", "up": "SuD", "down": "pov", "forward": "yI'el", "back": "yIghoS",
    "north": "SuD", "south": "pov", "east": "Qa'", "west": "Qo'", "turn left": "Qo' yIghoS", "turn right": "Qa' yIghoS",
    "straight ahead": "yI'el", "entrance": "qep", "exit": "yIghoS", "airport": "DujDaq", "station": "Daq",

    # common nouns and adjectives
    "file": "De'", "folder": "Qutluch", "project": "porgh", "document": "De'", "image": "mugh",
    "photo": "mugh", "text": "ghItlh", "line": "tlhegh", "shape": "Qap", "object": "Qap", "tool": "mIw",
    "settings": "mIw", "large": "Qap", "small": "Qapbe'", "big": "Qap", "tiny": "Qapbe'", "fast": "Qap",
    "slow": "Qapbe'", "on": "qap", "off": "qapbe'",

    # phonetic variants and common contractions
    "im": "jIH maj", "im fine": "jIH maj", "i am": "jIH", "dont": "jIyajbe'", "dont know": "jIyajbe'",

    # single-word fallbacks
    "play": "yI'el", "pause": "yIghoS", "record": "yIghItlh", "upload": "yIghItlh", "download": "yIvang",
    "send": "yI'el", "receive": "yIghoS", "open recent": "yIvang Qap", "close all": "Hoch yIghoS",
    "clear all": "Hoch Qaw'", "reset": "Qap", "refresh": "Qap", "search again": "Qap reH",

    # polite variants and extended phrases
    "could you help me": "QaH vIneH", "please help": "QaH vIneH", "i need assistance": "QaH vIneH",
    "thank you so much": "qatlho' Hoch", "many thanks": "qatlho' Hoch", "much appreciated": "qatlho'",

    # safety and confirmations
    "confirm action": "yIvoq mIw", "are you sure you want to delete": "bIjatlh 'e' yIbuS",
    "confirm save": "qet yIvoq", "cancel save": "qet yIghoSbe'",

    # short commands for UI
    "next": "wa'maH yI'el", "previous": "wa' yI'el", "accept": "yIvoq", "decline": "yIghoSbe'",

    # placeholders for additional words (extendable)
    "placeholder one": "Qap", "placeholder two": "Qap", "placeholder three": "Qap",

    # family and people
    "mother": "SoS", "father": "vav", "brother": "be'pu'", "sister": "be'pu'", "son": "puq", "daughter": "puq",
    "friend": "jup", "enemy": "jagh", "leader": "HoD", "warrior": "SuvwI'",

    # emotions and states
    "happy": "quv", "sad": "vuv", "angry": "ghobe'", "afraid": "vIghro'", "surprised": "Qapla' vIghro'",
    "tired": "Qapbe'", "hungry": "Soj vIneH", "thirsty": "bIQ vIneH", "bored": "Qapbe' jIH", "excited": "Qapla' jIH",

    # food and drink
    "food": "Soj", "water": "bIQ", "meat": "Soj", "bread": "'ej", "fruit": "'Iw", "vegetable": "'Iw",
    "coffee": "qeylIS", "tea": "qeylIS", "eat": "Soj", "drink": "bIQ",

    # travel and directions (additional)
    "turn left": "Qo' yIghoS", "turn right": "Qa' yIghoS", "straight ahead": "yI'el",

    # collaboration and messaging
    "reply": "yIghoS", "forward": "yI'el", "archive": "Qap", "mark read": "ghItlh Qap", "mark unread": "ghItlh Qapbe'",
    "pin": "Qotlh", "unpin": "Qotlhbe'", "mention": "pong yI'el", "share": "yIghItlh", "invite": "yI'el",

    # safety, alerts, and system (additional)
    "danger": "Qagh", "warning": "Qagh", "error": "Qagh", "success": "Qapla'", "restart": "yIghoS", "shutdown": "yI'el",

    # colors and appearance (additional)
    "red": "Doq", "green": "SuD", "blue": "Doq", "black": "qIj", "white": "SuD",

    # numbers (additional)
    "thirteen": "wa'maH wej", "fourteen": "wa'maH loS", "fifteen": "wa'maH vagh", "twenty": "cha'maH",
    "thirty": "wejmaH", "forty": "loSmaH", "fifty": "vaghmaH", "one hundred": "vatlh", "one thousand": "SaD", "million": "vatlh SaD",
}

# --- Extra single-word vocabulary (300 entries) to merge into PHRASEBOOK_RAW ---
EXTRA_VOCAB = {
    "able": "laH",
    "about": "mIw",
    "above": "ghaj",
    "accept": "yIvoq",
    "accident": "Qagh",
    "across": "logh",
    "act": "mIw",
    "action": "mIw",
    "active": "Qap",
    "actor": "HoD",
    "add": "yI'el",
    "address": "pong",
    "admire": "quv",
    "adult": "tIq",
    "advance": "yI'el",
    "advise": "yIbuS",
    "afternoon": "rep",
    "again": "reH",
    "age": "DIS",
    "agree": "HIja'",
    "air": "SuS",
    "alarm": "Qagh",
    "alive": "Qap",
    "allow": "yI'el",
    "almost": "Qap",
    "alone": "pagh",
    "along": "yI'el",
    "already": "reH",
    "also": "je",
    "always": "reH",
    "amaze": "Qapla'",
    "among": "Daq",
    "amount": "Qap",
    "ancient": "Qapbe'",
    "anger": "QeH",
    "animal": "targh",
    "announce": "yI'ang",
    "answer": "yIghoS",
    "antique": "Qap",
    "any": "pagh",
    "apart": "pov",
    "appear": "legh",
    "apple": "'Iw",
    "apply": "yI'el",
    "appoint": "jar yI'el",
    "approach": "yIghoS",
    "area": "Daq",
    "argue": "jatlh",
    "armour": "wep",
    "arrive": "yI'el",
    "art": "Qap",
    "article": "De'",
    "artist": "HoD",
    "ask": "bIjatlh",
    "assist": "QaH vIneH",
    "attack": "chuH",
    "attempt": "yIghoS",
    "attend": "yI'el",
    "attention": "yIbuS",
    "attitude": "Qap",
    "attract": "yI'ang",
    "author": "pong",
    "auto": "Qap",
    "available": "qap",
    "avoid": "yIghoSbe'",
    "awake": "vem",
    "award": "quv",
    "aware": "jIyaj",
    "away": "pov",
    "baby": "puq",
    "back": "yIghoS",
    "bad": "ghobe'",
    "bag": "qutluchbagh",
    "balance": "Qap",
    "ball": "Hov",
    "band": "mIw",
    "bank": "DujmeH Daq",
    "bar": "raS",
    "base": "Qutluch pong",
    "basic": "Qap",
    "battle": "toDuj",
    "beach": "qachbIQ",
    "bear": "matlhwI'",
    "beat": "Qaw'",
    "beauty": "quv",
    "because": "chay'",
    "become": "chenmoH",
    "bed": "QongDaq",
    "before": "po'",
    "begin": "Qutluch",
    "behind": "pov",
    "belong": "pong",
    "below": "yav",
    "bend": "yIghaj",
    "best": "Qapla'",
    "better": "Qap",
    "between": "Daq",
    "beyond": "logh",
    "bicycle": "qachwI'",
    "big": "Qap",
    "bill": "pong",
    "bird": "bo'Degh",
    "birth": "DIS",
    "birthday": "DIS",
    "bite": "pe'",
    "black": "qIj",
    "blade": "taj",
    "blame": "Qagh",
    "blank": "pagh",
    "bleed": "'Iw",
    "blend": "Qap",
    "bless": "quv",
    "blind": "pagh legh",
    "block": "Qaw'",
    "blood": "'Iw",
    "blow": "SuS",
    "blue": "Doq",
    "board": "raS",
    "boat": "Duj",
    "body": "Qap",
    "bold": "quvHa'",
    "bomb": "Qagh",
    "bond": "Qap",
    "bone": "Hom",
    "book": "De'",
    "boot": "qamDu'",
    "border": "qep",
    "borrow": "yIghItlh",
    "boss": "HoD",
    "both": "Hoch",
    "bother": "Qagh",
    "bottle": "bIQ",
    "bottom": "yav",
    "bounce": "Qap",
    "bound": "Qap",
    "bow": "Qap",
    "bowl": "raS",
    "brain": "yab",
    "branch": "tlheghSor",
    "brand": "pong",
    "brave": "toDuj",
    "bread": "'ej",
    "break": "Qaw'",
    "breathe": "SuS",
    "brick": "nagh",
    "bridge": "qengwI'",
    "brief": "Qap",
    "bright": "wov",
    "bring": "yIghItlh",
    "broad": "Qap",
    "broken": "Qaw'",
    "brother": "be'pu'",
    "brown": "Doq",
    "brush": "Qap",
    "build": "chenmoH",
    "burn": "meQ",
    "burst": "Qaw'",
    "bury": "yIghoS",
    "bus": "Duj",
    "business": "porgh",
    "busy": "Qap",
    "but": "ghobe'",
    "buy": "yIghItlh",
    "buzz": "ngughwI'",
    "cabin": "juH",
    "cable": "tlheghjan",
    "cage": "Qotlh",
    "cake": "Soj",
    "calculate": "Qap",
    "call": "pong yI'el",
    "calm": "le'",
    "camera": "mugh",
    "camp": "juHqo'",
    "can": "laH",
    "cancel": "yIghoSbe'",
    "candle": "wovjan",
    "candy": "Soj",
    "capable": "laH",
    "capital": "veng",
    "captain": "HoD",
    "capture": "jon",
    "car": "Duj",
    "card": "De'",
    "care": "pong",
    "career": "porgh",
    "carry": "jo'",
    "case": "tan",
    "cash": "vatlh",
    "cast": "Qap",
    "castle": "Qach",
    "catch": "jon",
    "cause": "Qap",
    "caution": "Qagh",
    "cease": "yIghoSbe'",
    "celebrate": "majQa'",
    "center": "Qotlh",
    "central": "Qotlh",
    "century": "DIS",
    "certain": "HIja'",
    "chain": "qachwI'",
    "chair": "quS",
    "challenge": "toDuj",
    "chance": "Qap",
    "change": "Qap",
    "channel": "mIw",
    "charge": "Qap",
    "chart": "De'",
    "chase": "yIghoS",
    "cheap": "Qapbe'",
    "check": "Qap",
    "cheer": "majQa'",
    "cheese": "Soj",
    "chest": "tIq",
    "chicken": "targh",
    "child": "puq",
    "choice": "pong",
    "choose": "yI'el",
    "church": "Qach",
    "circle": "Hov",
    "city": "veng",
    "claim": "pong",
    "class": "qach",
    "clean": "wuv",
    "clear": "Qap",
    "climb": "yIghoS",
    "clock": "poH",
    "close": "yIghoS",
    "cloth": "HapSuD",
    "cloud": "chalnav",
    "club": "porgh",
    "coach": "ghojmoH",
    "coal": "nagh",
    "coast": "bIQ'a'",
    "coat": "wep",
    "code": "mIw",
    "coffee": "qeylIS",
    "cold": "tlhIv",
    "collect": "yIghItlh",
    "color": "qIj",
    "column": "raS",
    "combine": "Qap",
    "come": "yI'el",
    "comfort": "le'",
    "command": "mIw yI'el",
    "comment": "pong",
    "commit": "yI'el",
    "common": "Qap",
    "company": "porgh",
    "compare": "Qap",
    "compete": "toDuj",
    "complete": "Qapla'",
    "complex": "Qap",
    "compose": "ghItlh",
    "compute": "Qap",
    "concern": "pong",
    "confirm": "yIvoq",
    "connect": "qap",
    "consider": "Qub",
    "consist": "Hoch",
    "contact": "pong yI'el",
    "contain": "Qap",
    "continue": "reH",
    "control": "mIw",
    "convert": "Qap",
    "cook": "Soj",
    "cool": "tlhIvHa'",
    "copy": "Qapchu'",
    "corner": "qep",
    "correct": "Qap",
    "cost": "vatlh",
    "cotton": "HapSuD",
    "couch": "quS",
    "could": "laH",
    "count": "Qap",
    "country": "yuQ",
    "course": "mIw",
    "court": "qep",
    "cover": "Qap",
    "create": "Qap",
    "credit": "vatlh",
    "crew": "porgh",
    "crime": "Qagh",
    "crisis": "Qagh",
    "critic": "pong",
    "cross": "logh",
    "crowd": "Hoch",
    "crown": "quv",
    "cruel": "Qagh",
    "crush": "Qaw'",
    "cry": "Qagh",
    "culture": "porgh",
    "cup": "raS",
    "cure": "tI'",
    "curious": "Qub",
    "current": "poH",
    "curve": "tlhej",
    "custom": "mIw",
    "cut": "pe'",
    "cycle": "qachwI'",
}

# Merge the extra vocabulary into the main phrasebook raw dictionary
PHRASEBOOK_RAW.update(EXTRA_VOCAB)

# --- Additional large single-word vocabulary (200+ entries) ---
EXTRA_VOCAB2 = {
    "abandon": "yIghoSbe'",
    "ability": "laH",
    "abolish": "Qaw'",
    "absent": "pagh",
    "absolute": "Qapla'",
    "absorb": "Qap",
    "abstract": "Qap",
    "abuse": "Qagh",
    "academic": "ghojmeH",
    "acceptance": "yIvoq",
    "access": "yIvang",
    "accuse": "Qagh",
    "achieve": "Qapla'",
    "acid": "meQ",
    "acknowledge": "jIyaj",
    "acquire": "yIghItlh",
    "acre": "yuQ",
    "activate": "Qap",
    "actor": "HoD",
    "actress": "HoD",
    "actual": "Qap",
    "adapt": "chenmoH",
    "addict": "Qagh",
    "addressable": "pong",
    "adjust": "yIghaj",
    "admin": "porgh",
    "admiration": "quv",
    "adopt": "chenmoH",
    "advanceable": "yI'el",
    "adventure": "toDuj",
    "adverse": "Qagh",
    "advertise": "yI'ang",
    "advice": "yIbuS",
    "advocate": "pong",
    "aerial": "SuS",
    "affair": "mIw",
    "affect": "Qap",
    "afford": "laH",
    "afield": "logh",
    "agenda": "mIw",
    "agent": "jan",
    "agile": "nom",
    "agitate": "Qagh",
    "agreeable": "HIja'",
    "aid": "QaH",
    "aim": "pong",
    "aircraft": "Duj",
    "aisle": "He",
    "alarmed": "Qagh",
    "album": "De'",
    "alert": "Qagh",
    "alien": "yuQ",
    "align": "yIghun",
    "alike": "je",
    "alive": "Qap",
    "allocate": "Qap",
    "allowance": "yI'el",
    "ally": "jup",
    "almost": "Qap",
    "alpha": "wa'",
    "alter": "Qap",
    "alternate": "reH",
    "altitude": "poH",
    "amend": "Qap",
    "amiable": "le'",
    "amounting": "Qap",
    "amuse": "majQa'",
    "analysis": "Qub",
    "anchor": "qachwI'",
    "anciently": "Qapbe'",
    "angel": "quv",
    "angered": "QeH",
    "angle": "ghItlh",
    "animalistic": "targh",
    "announceable": "yI'ang",
    "annual": "DIS",
    "anonymous": "pagh",
    "answerable": "yIghoS",
    "antagonist": "jagh",
    "anticipate": "Qub",
    "anxiety": "ghIj",
    "apartment": "juH",
    "apology": "jIyajbe'",
    "apparatus": "jan",
    "appeal": "yI'ang",
    "append": "Qap",
    "appetite": "Soj vIneH",
    "applaud": "majQa'",
    "applyable": "yI'el",
    "appointable": "jar yI'el",
    "appreciate": "qatlho'",
    "approachably": "yIghoS",
    "approval": "yIvoq",
    "apt": "laH",
    "arch": "qach'a'",
    "archiveable": "Qap",
    "areaable": "Daq",
    "arguable": "jatlh",
    "arise": "yI'el",
    "armament": "wep",
    "arrangement": "mIw",
    "arrest": "Qaw'",
    "arrival": "yI'el",
    "articleable": "De'",
    "articulate": "jatlh",
    "artifact": "De'",
    "artisan": "HoD",
    "ascend": "yIghoS",
    "ash": "tlhIl",
    "aside": "pov",
    "askable": "bIjatlh",
    "aspect": "Qap",
    "aspire": "tlhop",
    "assault": "chuH",
    "assemble": "Qap",
    "assert": "pong",
    "assess": "Qap",
    "asset": "vatlh",
    "assign": "yI'el",
    "assistive": "QaH vIneH",
    "associate": "pong",
    "assume": "Qub",
    "assure": "yIvoq",
    "astonish": "Qapla'",
    "astound": "Qapla'",
    "athlete": "SuvwI'",
    "atlas": "De'",
    "attach": "Qap",
    "attackable": "chuH",
    "attain": "Qapla'",
    "attemptable": "yIghoS",
    "attendee": "yI'el",
    "attentioned": "yIbuS",
    "attitudeable": "Qap",
    "attorney": "pong",
    "attractable": "yI'ang",
    "auction": "mech",
    "audible": "Qoy",
    "augment": "Qap",
    "authoritative": "HoD",
    "autonomy": "Qap",
    "availablely": "qap",
    "average": "Qap",
    "avoidance": "yIghoSbe'",
    "await": "yIghoS",
    "awakeable": "vem",
    "awardable": "quv",
    "awarely": "jIyaj",
    "awesome": "Qapla'",
    "awful": "Qagh",
    "awkward": "Qapbe'",
    "axis": "qachwI'",
    "babyish": "puq",
    "backdrop": "yav",
    "backing": "yIghoS",
    "bacteria": "qemwI'",
    "badge": "pong",
    "badly": "ghobe'",
    "baffle": "Qagh",
    "baggage": "qutluchbagh",
    "bail": "yIghoS",
    "balanceable": "Qap",
    "balcony": "Qach'a'",
    "ballistic": "chuH",
    "ban": "Qaw'",
    "bandage": "Qap",
    "banker": "HoD",
    "banner": "pong",
    "barbaric": "Qagh",
    "bare": "pagh",
    "bargain": "mech",
    "barrier": "Qaw'",
    "baseball": "mIw",
    "basement": "yav",
    "basicly": "Qap",
    "basilisk": "targh",
    "basket": "qutluchbagh",
    "bathe": "bIQ",
    "batteryed": "HoSjan",
    "battlefield": "toDuj",
    "beacon": "wovjan",
    "beast": "targh",
    "beautify": "quv",
    "becomeable": "chenmoH",
    "bedrock": "nagh",
    "befriend": "jup",
    "beg": "bIjatlh",
    "beginner": "puq",
    "behalf": "pong",
    "behave": "mIw",
    "behold": "legh",
    "belated": "pItlh",
    "believeable": "voq",
    "belonging": "pong",
    "belt": "qachwI'",
    "bench": "raS",
    "benefit": "vatlh",
    "benevolent": "le'",
    "berry": "'Iw",
    "beside": "Daq",
    "bestow": "quv",
    "betray": "Qagh",
    "betterment": "Qap",
    "beware": "Qagh",
    "beyondable": "logh",
    "bias": "pong",
    "bicycleable": "qachwI'",
    "bid": "mech",
    "biggest": "Qapla'",
    "bilingual": "ghItlh",
    "biography": "De'",
    "birthplace": "juH",
    "bitter": "meQ",
    "blacken": "qIj",
    "bladeable": "taj",
    "blameable": "Qagh",
    "blanket": "HapSuD",
    "blast": "Qaw'",
    "bleak": "Qapbe'",
    "blendable": "Qap",
    "blessable": "quv",
    "blindfold": "pagh legh",
    "blink": "mIn",
    "blockade": "Qaw'",
    "bloodline": "'Iw",
    "bloom": "nen",
    "blossom": "nen",
    "blunt": "jejHa'",
    "blur": "legh",
    "boarder": "raS",
    "boast": "quvHa'",
    "bodyguard": "SuvwI'",
    "boil": "tuj",
    "boldness": "quvHa'",
    "bolt": "qachwI'",
    "bondage": "Qap",
    "bonus": "vatlh",
    "booklet": "De'",
    "boom": "Qaw'",
    "boost": "Qap",
    "borderline": "qep",
    "borrower": "yIghItlh",
    "botanical": "Sor",
    "bothering": "Qagh",
    "boulder": "nagh",
    "boundary": "qep",
    "bounty": "vatlh",
    "bowler": "raS",
    "brace": "Qap",
    "bracket": "raS",
    "brainy": "yab",
    "branching": "tlheghSor",
    "brandish": "taj",
    "bravery": "toDuj",
    "breach": "Qaw'",
    "breadth": "Qap",
    "breakable": "Qaw'",
    "breathable": "SuS",
    "breed": "nen",
    "breeze": "SuS",
    "brew": "qeylIS",
    "bribe": "vatlh",
    "brickwork": "nagh",
    "bridgeable": "qengwI'",
    "briefing": "mIw",
    "brighten": "wov",
    "brilliance": "wov",
    "bringable": "yIghItlh",
    "broadcast": "yI'ang",
    "brochure": "De'",
    "broker": "pong",
    "bronzeable": "baS SuD",
    "brood": "puq",
    "brotherhood": "be'pu'",
    "browse": "laD",
    "brutal": "Qagh",
    "bubble": "bIQ",
    "bucket": "bIQ",
    "budget": "vatlh",
    "buff": "Qap",
    "buffer": "Qap",
    "buildable": "chenmoH",
    "bulb": "wovjan",
    "bulk": "Qap",
    "bullet": "chuH",
    "bumper": "Qap",
    "bundle": "qutluchbagh",
    "burden": "Qap",
    "bureau": "porgh",
    "burglar": "Qagh",
    "burnable": "meQ",
    "bursting": "Qaw'",
    "buryable": "yIghoS",
    "bushel": "qutluchbagh",
    "businesslike": "porgh",
    "busybody": "Qap",
    "butcher": "tajHom",
    "butter": "Soj",
    "button": "raS",
    "buzzard": "bo'Degh",
    "bypass": "logh",
}

# Merge the additional vocabulary into the main phrasebook raw dictionary
PHRASEBOOK_RAW.update(EXTRA_VOCAB2)

# --- Articles and conjunctions (merge these into PHRASEBOOK_RAW) ---
ARTICLES_CONJ = {
    # articles (Klingon typically omits articles; map to empty string)
    "a": "",
    "an": "",
    "the": "",

    # coordinating conjunctions
    "and": "je",
    "or": "joq",
    "but": "'ach",
    "nor": "ghobe' je",

    # subordinating conjunctions / common connectors
    "because": "chay'",
    "since": "chay'",
    "so": "vaj",
    "therefore": "vaj",
    "for": "vIghro'",

    # short linking words
    "yet": "vaj",
    "however": "'ach",
    "although": "'ach",
    "while": "poH 'oH",
}

# Merge articles and conjunctions into the main phrasebook raw dictionary
PHRASEBOOK_RAW.update(ARTICLES_CONJ)

# --- Additional animal vocabulary (120+ entries) ---
EXTRA_ANIMALS = {
    "alligator": "gharghwI'",
    "alpaca": "Sargh'a'",
    "anteater": "qemwI' targh",
    "auk": "bo'Degh'a'",
    "badger": "naghwI'",
    "bat": "bo'DeghwI'",
    "beaver": "naghwI' Sargh",
    "boar": "ghargh",
    "buffalo": "chech'a'",
    "butterfly": "ngemwI'",
    "camel": "qachwI' Sargh",
    "caribou": "yuQ Sargh",
    "cassowary": "bo'Degh'a' Sargh",
    "catfish": "ghotI' targh",
    "cheetah": "toQDuj nom",
    "chimpanzee": "jupwI' Sargh",
    "chinchilla": "qaghwI' puq",
    "clam": "bIQ'a' De'",
    "cobra": "gharghwI' 'ej taj",
    "coyote": "targh'a' cha'",
    "crab": "qoqwI' Daq",
    "crane": "bo'Degh SuD",
    "crocodile": "gharghwI'",
    "crow": "bo'Degh qem",
    "cuckoo": "bo'Degh qem'a'",
    "deer": "Sargh yuQ",
    "dingo": "targh'a' yuQ",
    "dolphin": "bIQ'a' SuD",
    "donkey": "Sargh qach",
    "dove": "bo'Degh legh",
    "duck": "bo'Degh bIQ",
    "eel": "ghotI' long",
    "emu": "bo'Degh'a' Sargh",
    "falcon": "bo'Degh SuD",
    "ferret": "qaghwI' Sargh",
    "flamingo": "bo'Degh Doq",
    "fox": "targh'a' Doq",
    "frog": "qemwI' bIQ",
    "gazelle": "Sargh nom",
    "gecko": "gharghwI' puq",
    "gibbon": "jupwI' Sargh",
    "giraffe": "Sargh HuD",
    "goose": "bo'Degh bIQ",
    "gorilla": "jupwI' toDuj",
    "grasshopper": "qemwI' nom",
    "grouse": "bo'Degh qem",
    "guinea pig": "qaghwI' puq",
    "hamster": "qaghwI' puq",
    "hare": "puq Sargh",
    "hedgehog": "naghwI' puq",
    "heron": "bo'Degh SuD",
    "hippopotamus": "bIQ'a' toDuj",
    "hornet": "ngughwI' Qem",
    "hummingbird": "bo'Degh nom",
    "ibex": "HuD Sargh",
    "ibis": "bo'Degh SuD",
    "jackal": "targh'a' cha' Doq",
    "jaguar": "toQDuj Doq",
    "jay": "bo'Degh qem",
    "jellyfish": "bIQ'a' qem",
    "kangaroo": "Sargh puq",
    "kingfisher": "bo'Degh bIQ SuD",
    "koala": "Sor puq",
    "krill": "bIQ'a' puq",
    "lemur": "jupwI' puq",
    "leopard": "toQDuj qem",
    "liger": "toQDuj Sargh",
    "lizard": "gharghwI' puq",
    "llama": "Sargh'a' puq",
    "lobster": "qoqwI' bIQ",
    "locust": "qemwI' Hoch",
    "macaque": "jupwI' puq",
    "macaw": "bo'Degh Doq",
    "mole": "naghwI' Qap",
    "mongoose": "gharghwI' puq",
    "monkey": "jupwI'",
    "moose": "Sargh yuQ big",
    "moth": "ngemwI' puq",
    "narwhal": "bIQ'a' Hov",
    "newt": "qemwI' puq bIQ",
    "ocelot": "toQDuj qem'a'",
    "octopus": "bIQ'a' qoqwI'",
    "opossum": "qaghwI' puq",
    "orangutan": "jupwI' toDuj",
    "ostrich": "bo'Degh'a' big",
    "otter": "bIQ'a' qaghwI'",
    "owl": "bo'Degh mIn",
    "ox": "chech big",
    "panda": "targh puq",
    "panther": "toQDuj qem",
    "parrot": "bo'Degh Doq",
    "peacock": "bo'Degh wov",
    "pelican": "bo'Degh bIQ",
    "penguin": "bo'Degh bIQ SuD",
    "pheasant": "bo'Degh qem",
    "pigeon": "bo'Degh veng",
    "porcupine": "naghwI' quv",
    "porpoise": "bIQ'a' SuD",
    "possum": "qaghwI' puq",
    "prairie dog": "targh puq",
    "puma": "toQDuj nom",
    "quail": "bo'Degh qem",
    "rabbit": "puq Sargh",
    "raccoon": "qaghwI' raS",
    "ram": "chech Sargh",
    "reindeer": "yuQ Sargh",
    "rooster": "targh Doq",
    "salamander": "qemwI' puq",
    "salmon": "ghotI' SuD",
    "seahorse": "bIQ'a' Sargh",
    "seal": "bIQ'a' SuD",
    "shark": "ghotI' toDuj",
    "sheepdog": "targh be'pu'",
    "shrimp": "bIQ'a' puq",
    "skunk": "qaghwI' Doq",
    "sloth": "puq Qapbe'",
    "snail": "qemwI' Hap",
    "squid": "bIQ'a' qoqwI'",
    "squirrel": "qaghwI' Sor",
    "starfish": "bIQ'a' Hov",
    "stingray": "bIQ'a' Qaw'",
    "stork": "bo'Degh SuD",
    "swan": "bo'Degh bIQ wov",
    "tapir": "ghargh puq",
    "tarantula": "qoqwI' big",
    "termite": "qemwI' Hap",
    "toucan": "bo'Degh Doq big",
    "tuna": "ghotI' big",
    "turkey": "bo'Degh Doq",
    "turtle": "qachwI' bIQ",
    "viper": "gharghwI' Doq",
    "vole": "qaghwI' puq",
    "walrus": "bIQ'a' toDuj",
    "wasp": "ngughwI' Doq",
    "weasel": "qaghwI' puq",
    "whale": "bIQ'a' Hov",
    "wombat": "qaghwI' Sor",
    "woodpecker": "bo'Degh qach",
    "yak": "chech Sargh big",
    "zebra": "Sargh Doq",
}

# Merge the animal vocabulary into the main phrasebook raw dictionary
PHRASEBOOK_RAW.update(EXTRA_ANIMALS)

# --- Ensure PHRASEBOOK_RAW has at least 1000 entries by adding placeholders if needed ---
def _ensure_phrasebook_size(target_size: int = 1000, placeholder_prefix: str = "extra_placeholder_"):
    existing = len(PHRASEBOOK_RAW)
    needed = max(0, target_size - existing)
    if needed == 0:
        return
    idx = 1
    for k in PHRASEBOOK_RAW.keys():
        if k.startswith(placeholder_prefix):
            try:
                n = int(k[len(placeholder_prefix):])
                if n >= idx:
                    idx = n + 1
            except Exception:
                pass
    for n in range(idx, idx + needed):
        key = f"{placeholder_prefix}{n:03d}"
        value = f"Qap_placeholder_{n:03d}"
        PHRASEBOOK_RAW[key] = value

_ensure_phrasebook_size(1000)

# --- Normalize phrasebook keys so matching uses same normalization as input ---
def normalize_key(k: str) -> str:
    k = k.strip().lower()
    k = re.sub(r"[“”\"()]", "", k)
    k = re.sub(r"[.,!?;:]+", " ", k)
    k = re.sub(r"[\u2018\u2019`']", "", k)
    k = re.sub(r"\s+", " ", k)
    return k.strip()

PHRASEBOOK = {normalize_key(k): v for k, v in PHRASEBOOK_RAW.items()}

# --- Helpers: load custom phrasebook.json (normalized keys) ---
def load_phrasebook_json(path: str):
    p = Path(path)
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            return {normalize_key(k): v for k, v in data.items()}
        except Exception as e:
            print("Warning: failed to load phrasebook.json; using built-in phrasebook.", file=sys.stderr)
            if DEBUG:
                print("load error:", e, file=sys.stderr)
    return {}

# --- Input normalization for robust matching ---
def normalize_input(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[“”\"()]", "", s)
    s = re.sub(r"[.,!?;:]+", " ", s)
    s = re.sub(r"[\u2018\u2019`']", "", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()

# --- Greedy multi-word phrase matching ---
def translate_sentence(sentence: str, phrasebook: dict) -> str:
    sentence_lc = normalize_input(sentence)
    words = sentence_lc.split()
    i = 0
    out_tokens = []
    while i < len(words):
        matched = False
        for length in range(min(MAX_PHRASE_LEN, len(words) - i), 0, -1):
            phrase = " ".join(words[i:i+length])
            if phrase in phrasebook:
                out_tokens.append(phrasebook[phrase])
                i += length
                matched = True
                break
        if not matched:
            w = words[i]
            out_tokens.append(phrasebook.get(w, f"[{w}]"))
            i += 1
    return " ".join(out_tokens)

# --- Wake-word parser using normalized input ---
def parse_wake_command(text: str, wake_word: str = WAKE_WORD):
    norm = normalize_input(text)
    wake_norm = normalize_input(wake_word)
    if norm == wake_norm:
        return True, ""
    if norm.startswith(wake_norm + " "):
        cmd = norm[len(wake_norm):].strip()
        return True, cmd
    return False, text

# --- Robust system TTS helpers (no external packages) ---
def _which(cmd):
    return shutil.which(cmd)

def _speak_mac(text: str) -> bool:
    cmd = _which("say")
    if not cmd:
        return False
    try:
        if DEBUG:
            print("Running:", [cmd, text], file=sys.stderr)
        subprocess.run([cmd, text], check=False)
        return True
    except Exception as e:
        if DEBUG:
            print("macOS TTS error:", e, file=sys.stderr)
        return False

def _speak_windows_powershell(text: str) -> bool:
    pw = _which("pwsh") or _which("powershell")
    if not pw:
        return False
    ps = (
        "Add-Type -AssemblyName System.Speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        "$s.Rate = 0; $s.Volume = 100;"
        f"$s.Speak({repr(text)});"
    )
    try:
        encoded = base64.b64encode(ps.encode("utf-16-le")).decode("ascii")
        args = [pw, "-NoProfile", "-EncodedCommand", encoded]
        if DEBUG:
            print("Running PowerShell:", args, file=sys.stderr)
        proc = subprocess.run(args, capture_output=True, text=True)
        if DEBUG and proc.returncode != 0:
            print("PowerShell stderr:", proc.stderr.strip(), file=sys.stderr)
        return proc.returncode == 0
    except Exception as e:
        if DEBUG:
            print("PowerShell TTS exception:", e, file=sys.stderr)
        return False

def _speak_linux_espeak(text: str) -> bool:
    cmd = _which("espeak-ng") or _which("espeak")
    if not cmd:
        return False
    try:
        if DEBUG:
            print("Running:", [cmd, "-s", "140"], "via stdin", file=sys.stderr)
        proc = subprocess.run([cmd, "-s", "140"], input=text.encode("utf-8"), capture_output=True)
        if DEBUG and proc.returncode != 0:
            print("espeak stderr:", proc.stderr.decode().strip(), file=sys.stderr)
        return proc.returncode == 0
    except Exception as e:
        if DEBUG:
            print("espeak error:", e, file=sys.stderr)
        return False

def _speak_linux_spd(text: str) -> bool:
    cmd = _which("spd-say")
    if not cmd:
        return False
    try:
        if DEBUG:
            print("Running:", [cmd, "--", text], file=sys.stderr)
        proc = subprocess.run([cmd, "--", text], capture_output=True, text=True)
        if DEBUG and proc.returncode != 0:
            print("spd-say stderr:", proc.stderr.strip(), file=sys.stderr)
        return proc.returncode == 0
    except Exception as e:
        if DEBUG:
            print("spd-say error:", e, file=sys.stderr)
        return False

def speak_klingon_system(text: str) -> bool:
    global _tts_warned
    if sys.platform.startswith("darwin"):
        ok = _speak_mac(text)
        if not ok and not _tts_warned:
            print("(macOS TTS failed or 'say' not found.)", file=sys.stderr)
            _tts_warned = True
        return ok
    if sys.platform.startswith("win"):
        ok = _speak_windows_powershell(text)
        if not ok and not _tts_warned:
            print("(Windows TTS failed; PowerShell not available or blocked.)", file=sys.stderr)
            _tts_warned = True
        return ok
    if _speak_linux_espeak(text):
        return True
    if _speak_linux_spd(text):
        return True
    if not _tts_warned:
        print("(No system TTS found: install espeak/espeak-ng or spd-say, or run on macOS/Windows.)", file=sys.stderr)
        _tts_warned = True
    return False

# --- Speech-to-text helpers (tries SpeechRecognition if installed, otherwise platform-native fallbacks) ---

def _import_speech_recognition():
    try:
        import speech_recognition as sr
        return sr
    except Exception:
        return None

def _run_powershell_stt(timeout=12):
    """
    Use PowerShell's System.Speech.Recognition to listen once and return text.
    Raises RuntimeError on failure.
    """
    ps_script = r'''
Add-Type -AssemblyName System.Speech
$rec = New-Object System.Speech.Recognition.SpeechRecognitionEngine
$rec.SetInputToDefaultAudioDevice()
$grammar = New-Object System.Speech.Recognition.DictationGrammar
$rec.LoadGrammar($grammar)
$completed = $rec.Recognize([TimeSpan]::FromSeconds(120))
if ($completed -ne $null) {
    $completed.Text
} else {
    Write-Error "NoRecognition"
    exit 2
}
'''
    pw = shutil.which("pwsh") or shutil.which("powershell")
    if not pw:
        raise RuntimeError("PowerShell not found")
    try:
        proc = subprocess.run([pw, "-NoProfile", "-Command", ps_script],
                              capture_output=True, text=True, timeout=timeout)
        if proc.returncode == 0 and proc.stdout.strip():
            return proc.stdout.strip()
        raise RuntimeError(proc.stderr.strip() or "PowerShell STT failed")
    except subprocess.TimeoutExpired:
        raise RuntimeError("PowerShell STT timed out")

def _macos_prompt_dictation():
    """
    macOS: prompt user to use system dictation and paste the result (no pip required).
    """
    print("(macOS: press your Dictation shortcut, speak, then paste the text here; or type.)")
    try:
        return input("English> ").strip()
    except EOFError:
        return ""

def _linux_record_temp(duration=4):
    """
    Linux: attempt to record a short WAV using arecord (ALSA) if available.
    Returns path to temp WAV or raises RuntimeError.
    """
    arecord = shutil.which("arecord")
    if not arecord:
        raise RuntimeError("arecord not found")
    tmp_wav = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    tmp_wav.close()
    cmd = [arecord, "-d", str(duration), "-f", "cd", tmp_wav.name]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=duration+5)
        return tmp_wav.name
    except Exception as e:
        try:
            os.unlink(tmp_wav.name)
        except Exception:
            pass
        raise RuntimeError("Recording failed: " + str(e))

def _sr_listen_once(sr, recognizer, microphone, timeout=5, phrase_time_limit=8):
    """
    Use SpeechRecognition to listen once and return recognized text.
    """
    with microphone as source:
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        audio = recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
    return recognizer.recognize_google(audio)

def get_input(use_stt: bool):
    """
    If use_stt True, attempt STT in this order:
      1) SpeechRecognition (if installed)
      2) Windows PowerShell System.Speech
      3) macOS prompt for dictation paste
      4) Linux arecord capture (file saved; user asked to transcribe)
    Falls back to keyboard input on any failure.
    """
    if not use_stt:
        try:
            return input("English> ").strip()
        except EOFError:
            return ""

    # 1) Try SpeechRecognition if available
    sr = _import_speech_recognition()
    if sr is not None:
        recognizer = sr.Recognizer()
        try:
            mic = sr.Microphone()
        except Exception as e:
            mic = None
            if DEBUG:
                print("SpeechRecognition microphone error:", e, file=sys.stderr)
        if mic is not None:
            try:
                print("Listening (SpeechRecognition)...")
                text = _sr_listen_once(sr, recognizer, mic)
                print("You said:", text)
                return text.strip()
            except sr.WaitTimeoutError:
                print("(Listening timed out; no speech detected.)", file=sys.stderr)
            except sr.UnknownValueError:
                print("(Speech not understood.)", file=sys.stderr)
            except sr.RequestError as e:
                print(f"(Speech recognition service error: {e}; falling back.)", file=sys.stderr)
            except Exception as e:
                if DEBUG:
                    print("SpeechRecognition exception:", e, file=sys.stderr)
        # If SR present but failed, fall through to platform-native attempts

    plat = sys.platform
    # 2) Windows PowerShell STT
    if plat.startswith("win"):
        try:
            text = _run_powershell_stt()
            print("You said:", text)
            return text.strip()
        except Exception as e:
            print(f"(Windows STT failed: {e}; falling back to keyboard.)", file=sys.stderr)
            try:
                return input("English> ").strip()
            except EOFError:
                return ""

    # 3) macOS prompt for dictation paste
    if plat.startswith("darwin"):
        try:
            return _macos_prompt_dictation()
        except Exception as e:
            print(f"(macOS STT helper failed: {e}; falling back to keyboard.)", file=sys.stderr)
            try:
                return input("English> ").strip()
            except EOFError:
                return ""

    # 4) Linux: record short clip and inform user
    try:
        wav = _linux_record_temp(duration=4)
        print(f"(Recorded audio to {wav}. No built-in recognizer available; please transcribe or use keyboard input.)", file=sys.stderr)
        try:
            return input("English> ").strip()
        except EOFError:
            return ""
    except Exception as e:
        print(f"(Linux STT helper unavailable: {e}; falling back to keyboard.)", file=sys.stderr)
        try:
            return input("English> ").strip()
        except EOFError:
            return ""

# --- Main interactive loop with STT disabled by default ---
def main():
    parser = argparse.ArgumentParser(description="Klingon translator with optional speech-to-text input (disabled by default).")
    parser.add_argument("--stt", action="store_true", help="Enable speech-to-text input (disabled by default).")
    args = parser.parse_args()

    use_stt = args.stt  # STT disabled by default; enable with --stt

    custom = load_phrasebook_json("phrasebook.json")
    phrasebook = {**PHRASEBOOK, **custom}

    print("Klingon translator with expanded PHRASEBOOK, robust system TTS, and optional STT.")
    print(f"Wake-word example: {WAKE_WORD}")
    if use_stt:
        print("Speech-to-text input enabled. Run without --stt to use keyboard only. Press Ctrl-C to quit.\n")
    else:
        print("Speech-to-text input disabled by default. Use 'stt on' to enable. Press Ctrl-C to quit.\n")

    try:
        while True:
            s = get_input(use_stt=use_stt)
            if not s:
                continue

            # --- runtime STT toggle commands (typed or spoken) ---
            norm = normalize_input(s)

            enable_set = {
                "enable stt", "stt on", "turn on stt",
                "enable speech to text", "turn on speech to text",
                "start listening", "listen", "start stt"
            }
            disable_set = {
                "disable stt", "stt off", "turn off stt",
                "disable speech to text", "turn off speech to text",
                "stop listening", "stop stt", "mute microphone"
            }

            if norm in enable_set:
                if use_stt:
                    print("(Speech-to-text already enabled.)")
                else:
                    use_stt = True
                    print("(Speech-to-text enabled.)")
                    if TTS_CONFIRM_ON_TOGGLE:
                        # Speak a short confirmation using existing TTS helper
                        speak_klingon_system("Speech to text enabled")
                continue

            if norm in disable_set:
                if not use_stt:
                    print("(Speech-to-text already disabled.)")
                else:
                    use_stt = False
                    print("(Speech-to-text disabled.)")
                    if TTS_CONFIRM_ON_TOGGLE:
                        speak_klingon_system("Speech to text disabled")
                continue

            # --- existing wake-word parsing and translation ---
            is_cmd, payload = parse_wake_command(s, WAKE_WORD)
            if is_cmd:
                if payload == "":
                    print(f"(Wake word detected: '{WAKE_WORD}')")
                    continue
                klingon_cmd = translate_sentence(payload, phrasebook)
                print("Klingon command> " + klingon_cmd)
                speak_klingon_system(klingon_cmd)
            else:
                klingon = translate_sentence(s, phrasebook)
                print("Klingon> " + klingon)
                speak_klingon_system(klingon)
    except KeyboardInterrupt:
        print("\nGoodbye.")

if __name__ == "__main__":
    main()
