#!/usr/bin/env python3
# dr_sbaitso_sys_tts.py -- Dr. Sbaitso chatbot with system TTS (no pip)
# Patched: safer PowerShell quoting, debug logs, explicit exit commands, SIGINT handler
# Run: python dr_sbaitso_sys_tts.py

import os
import re
import json
import random
import shutil
import subprocess
import sys
import signal
from collections import defaultdict, deque

DEBUG = bool(os.environ.get("DS_DEBUG"))  # set DS_DEBUG=1 to enable debug prints

# ---------- Configuration ----------
PERSIST_FILE = "dr_sbaitso_memory.json"
BOT_NAME = "Dr. Sbaitso"
USER_PROMPT = "You: "
BOT_PROMPT = f"{BOT_NAME}: "

# ---------- Expanded Topic Keywords (same as before) ----------
TOPIC_KEYWORDS = {
    "work": ["work", "job", "career", "boss", "office", "co-worker", "promotion", "resume", "shift", "colleague"],
    "family": ["mom", "dad", "mother", "father", "sibling", "brother", "sister", "family", "kids", "children", "parent"],
    "health": ["health", "doctor", "sick", "ill", "pain", "clinic", "wellness", "exercise", "sleep", "therapy", "medication"],
    "money": ["money", "cash", "bills", "rent", "salary", "debt", "budget", "savings", "loan", "bank"],
    "love": ["love", "relationship", "partner", "girlfriend", "boyfriend", "dating", "marriage", "breakup", "romance"],
    "anxiety": ["anxiety", "anxious", "worry", "panic", "nervous", "stress", "fear", "overwhelm"],
    "mood": ["sad", "happy", "angry", "depressed", "joy", "lonely", "upset", "mood", "blue"],
    "friends": ["friend", "friends", "social", "party", "hangout", "buddy", "pal", "mate"],
    "school": ["school", "class", "homework", "exam", "teacher", "professor", "study", "college", "course"],
    "creativity": ["art", "music", "writing", "design", "project", "create", "creative", "idea", "poem", "sketch"],
    "tech": ["computer", "code", "program", "software", "bug", "python", "internet", "app", "server", "script"],
    "identity": ["identity", "self", "personality", "values", "beliefs", "purpose", "who", "authentic"],
    "sleep": ["sleep", "insomnia", "dream", "nap", "tired", "awake", "rest"],
    "food": ["food", "hunger", "eat", "diet", "cooking", "recipe", "pizza", "meal"],
    "travel": ["travel", "trip", "flight", "vacation", "hotel", "commute", "journey"],
    "loss": ["grief", "loss", "bereavement", "funeral", "missing", "gone", "mourning"],
    "habit": ["habit", "addiction", "quit", "routine", "daily", "practice", "habitual"],
    "goals": ["goal", "plan", "ambition", "future", "aspire", "target", "objective"],
    "practical": ["legal", "rent", "bank", "insurance", "appointment", "schedule", "paperwork"],
    "philosophy": ["why", "meaning", "truth", "life", "purpose", "morals", "existence"]
}

# ---------- Expanded Seed text phrases ----------
SEED_TEXT = [
    "How are you feeling today",
    "Tell me more about that",
    "Why do you think that is",
    "I am here to listen",
    "Sometimes people worry about those things",
    "What makes you say that",
    "That sounds important",
    "Do you want to talk about it",
    "I see. Go on",
    "Why does that bother you",
    "When did you first notice this",
    "How long has this been happening",
    "What would you like to change",
    "Do other people know about this",
    "What helps you feel better",
    "Have you tried talking to someone",
    "What does your day look like",
    "Are you sleeping well lately",
    "Tell me about your work",
    "Who do you usually turn to",
    "What do you fear most about this",
    "What outcome would feel good",
    "How do you usually cope",
    "What would a small step look like",
    "Can you give an example",
    "That reminds me of something else",
    "I notice you use strong words",
    "What feels difficult right now",
    "Is there a memory connected to that",
    "Does that make you angry or sad",
    "What do you wish others understood",
    "How do you talk to yourself about it",
    "Do you want advice or just to vent",
    "What helps you feel calm",
    "Have you felt this before",
    "Do you blame yourself",
    "Could this be changed gradually",
    "What would you say to a friend",
    "Is there a practical step you can take",
    "What would happen if nothing changed",
    "What small win could shift this",
    "I hear a lot of concern in your voice",
    "There may be other explanations",
    "Tell me more about your relationship",
    "Do you feel supported by family",
    "What would make your day better",
    "How do you recharge your energy",
    "What does success mean to you",
    "What would you do if you weren't afraid",
    "Do you prefer routine or surprise",
    "What brought you joy recently",
    "What would you like to talk about next",
    "Is this related to something at work",
    "How does your body feel when you say that",
    "What is one small comfort you can give yourself",
    "Who did you talk to about this yesterday",
    "What would you tell your younger self",
    "What are you avoiding right now",
    "When you imagine the future how does it look",
    "What kind of help do you think you need",
    "How did you handle similar things before",
    "What are you proud of lately",
    "That sounds difficult but manageable",
    "I can hear both worry and hope in your voice",
    "Sometimes the small steps matter most",
    "Could curiosity help here",
    "What does relief look like to you",
    "What would a kind response sound like"
]

# ---------- Utilities ----------
def save_memory(mem):
    try:
        with open(PERSIST_FILE, "w", encoding="utf-8") as f:
            json.dump(mem, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def load_memory():
    try:
        with open(PERSIST_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"user_name": None, "topics": []}

def tokenize(text):
    text = re.sub(r"[^A-Za-z0-9'\s]", " ", text)
    tokens = [t.lower() for t in text.split() if t.strip()]
    return tokens

# ---------- Tiny Markov bigram generator ----------
class Markov:
    def __init__(self, corpus_lines):
        self.model = defaultdict(list)
        self.starters = []
        self._build(corpus_lines)

    def _build(self, lines):
        for line in lines:
            toks = tokenize(line)
            if not toks:
                continue
            self.starters.append(toks[0])
            prev = None
            for t in toks:
                if prev is not None:
                    self.model[prev].append(t)
                prev = t
            if prev is not None:
                self.model[prev].append(None)

    def generate(self, max_words=20):
        if not self.model:
            return ""
        word = random.choice(self.starters)
        out = [word]
        for _ in range(max_words - 1):
            nexts = self.model.get(word)
            if not nexts:
                break
            nxt = random.choice(nexts)
            if nxt is None:
                break
            out.append(nxt)
            word = nxt
        return " ".join(out)

# ---------- Reflection helpers ----------
REFLECTIONS = {
    "i am": "you are",
    "i'm": "you are",
    "i": "you",
    "me": "you",
    "my": "your",
    "your": "my",
    "you are": "I am",
    "you": "I"
}

def reflect_phrase(phrase):
    tokens = tokenize(phrase)
    out = []
    i = 0
    while i < len(tokens):
        two = " ".join(tokens[i:i+2])
        if two in REFLECTIONS:
            out.append(REFLECTIONS[two])
            i += 2
            continue
        one = tokens[i]
        out.append(REFLECTIONS.get(one, one))
        i += 1
    if not out:
        return ""
    out[0] = out[0].capitalize()
    return " ".join(out)

# ---------- Pattern-based replies ----------
PATTERNS = [
    (re.compile(r"\bhello\b|\bhi\b|\bhey\b", re.I), [
        "Hello. How are you feeling today?",
        "Hi there. What brings you here?"
    ]),
    (re.compile(r"\bname\b.*\bis\b|\bcall me\b", re.I), [
        "What's your name?",
        "How should I call you?"
    ]),
    (re.compile(r"\bmy name is (.+)", re.I), [
        lambda m: f"Nice to meet you, {m.group(1).strip().capitalize()}. How are you today?"
    ]),
    (re.compile(r"\bi am (.+)", re.I), [
        lambda m: f"Why are you {m.group(1).strip()}?",
        lambda m: f"When did you start feeling {m.group(1).strip()}?"
    ]),
    (re.compile(r"\b(sad|happy|mad|angry|depressed|anxious|lonely|stressed)\b", re.I), [
        lambda m: f"Tell me more about feeling {m.group(1).lower()}.",
        lambda m: f"How long have you been {m.group(1).lower()}?"
    ]),
    (re.compile(r"\b(bye|exit|quit|goodbye)\b", re.I), [
        "Goodbye. Take care of yourself.",
        "Farewell. Remember I'm here to talk."
    ]),
    (re.compile(r"\b(why|how|what|when|where)\b", re.I), [
        "That's an interesting question. What do you think?",
        "Why do you ask that?"
    ]),
]

def pattern_reply(text):
    for pat, responses in PATTERNS:
        m = pat.search(text)
        if m:
            resp = random.choice(responses)
            if callable(resp):
                try:
                    return resp(m)
                except Exception:
                    continue
            return resp
    return None

# ---------- Simple keyword topic extraction ----------
def extract_topics(tokens):
    found = set()
    for t in tokens:
        for topic, kws in TOPIC_KEYWORDS.items():
            if t in kws:
                found.add(topic)
    return list(found)

# ---------- System TTS wrapper (no pip) with safer PowerShell quoting and debug ----------
class SystemTTS:
    def __init__(self):
        self.method = None
        # detect available backends
        if shutil.which("say"):
            self.method = "say"
        elif shutil.which("spd-say"):
            self.method = "spd-say"
        elif shutil.which("espeak"):
            self.method = "espeak"
        elif shutil.which("powershell") or shutil.which("pwsh"):
            self.method = "powershell"
        else:
            self.method = None
        if DEBUG:
            print("[DS_DEBUG] SystemTTS method:", self.method, file=sys.stderr)

    def _sanitize_short(self, text):
        # basic sanitize for single-line speech: trim, collapse whitespace
        t = re.sub(r"\s+", " ", text.strip())
        return t

    def speak(self, text):
        if not self.method:
            if DEBUG:
                print("[DS_DEBUG] No TTS method available", file=sys.stderr)
            return False

        text = self._sanitize_short(text)
        if not text:
            return False

        try:
            if self.method == "say":
                cmd = ["say", text]
                if DEBUG:
                    print("[DS_DEBUG] Running:", cmd, file=sys.stderr)
                res = subprocess.run(cmd, capture_output=True, text=True)
                if DEBUG:
                    print("[DS_DEBUG] rc:", res.returncode, "stdout:", res.stdout, "stderr:", res.stderr, file=sys.stderr)
                return res.returncode == 0

            if self.method == "spd-say":
                cmd = ["spd-say", text]
                if DEBUG:
                    print("[DS_DEBUG] Running:", cmd, file=sys.stderr)
                res = subprocess.run(cmd, capture_output=True, text=True)
                if DEBUG:
                    print("[DS_DEBUG] rc:", res.returncode, "stdout:", res.stdout, "stderr:", res.stderr, file=sys.stderr)
                return res.returncode == 0

            if self.method == "espeak":
                cmd = ["espeak", text]
                if DEBUG:
                    print("[DS_DEBUG] Running:", cmd, file=sys.stderr)
                res = subprocess.run(cmd, capture_output=True, text=True)
                if DEBUG:
                    print("[DS_DEBUG] rc:", res.returncode, "stdout:", res.stdout, "stderr:", res.stderr, file=sys.stderr)
                return res.returncode == 0

            if self.method == "powershell":
                ps = shutil.which("powershell") or shutil.which("pwsh")
                # Use double-quoted string in PowerShell and escape inner double quotes/backslashes
                safe_text = text.replace("\\", "\\\\").replace('"', '\\"')
                ps_command = f'Add-Type -AssemblyName System.speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak("{safe_text}")'
                cmd = [ps, "-NoProfile", "-Command", ps_command]
                if DEBUG:
                    print("[DS_DEBUG] Running:", cmd, file=sys.stderr)
                res = subprocess.run(cmd, capture_output=True, text=True)
                if DEBUG:
                    print("[DS_DEBUG] rc:", res.returncode, "stdout:", res.stdout, "stderr:", res.stderr, file=sys.stderr)
                return res.returncode == 0

        except Exception as e:
            if DEBUG:
                print("[DS_DEBUG] Exception while running TTS:", repr(e), file=sys.stderr)
            return False

# ---------- Main bot class ----------
class DrSbaitso:
    def __init__(self, tts=None):
        self.memory = load_memory()
        self.markov = Markov(SEED_TEXT)
        self.history = deque(maxlen=50)
        self.tts = tts

    def _speak(self, text):
        if self.tts:
            ok = self.tts.speak(text)
            if DEBUG and not ok:
                print("[DS_DEBUG] TTS speak returned False", file=sys.stderr)

    def greet(self):
        name = self.memory.get("user_name")
        greeting = f"Hello {name}. How are you today?" if name else "Hello. I am Dr. Sbaitso. Tell me what's on your mind."
        self._speak(greeting)
        return greeting

    def respond(self, text):
        text = text.strip()
        if not text:
            reply = "Please say something so I can help."
            self._speak(reply)
            return reply

        self.history.append({"user": text})
        mname = re.search(r"\bmy name is ([A-Za-z0-9 _-]+)", text, re.I)
        if mname:
            nm = mname.group(1).strip().capitalize()
            self.memory["user_name"] = nm
            save_memory(self.memory)
            reply = f"Hello {nm}. I'm glad to meet you."
            self._speak(reply)
            return reply

        pat = pattern_reply(text)
        if pat:
            self._speak(pat)
            return pat

        if re.search(r"\bI\b|\bi'm\b|\bi am\b", text, re.I):
            reflected = reflect_phrase(text)
            if reflected:
                reply = f"{reflected}. Why do you say that?"
                self._speak(reply)
                return reply

        tokens = tokenize(text)
        topics = extract_topics(tokens)
        if topics:
            for t in topics:
                if t not in self.memory.get("topics", []):
                    self.memory.setdefault("topics", []).append(t)
            save_memory(self.memory)
            reply = f"You mentioned {', '.join(topics)}. Would you like to talk more about {topics[0]}?"
            self._speak(reply)
            return reply

        if len(tokens) <= 3:
            reply = f"Can you tell me more about {text}?"
            self._speak(reply)
            return reply

        generated = self.markov.generate()
        reply = f"{generated}. Can you expand on that?"
        self._speak(reply)
        return reply

# ---------- CLI loop with explicit exit commands and SIGINT ----------
EXIT_COMMANDS = {"/exit", "/quit", "exit", "quit", "bye", "goodbye", "q", "quit!", "stop", "shutdown"}

def _handle_sigint(signum, frame):
    # Graceful shutdown on Ctrl-C
    print()
    farewell = "Goodbye. Take care."
    print(BOT_PROMPT + farewell)
    # Try to speak farewell if TTS available (bot not in scope here), then exit
    try:
        # best-effort: attempt to load TTS and speak
        tts_try = SystemTTS()
        if tts_try.method:
            tts_try.speak(farewell)
    except Exception:
        pass
    sys.exit(0)

def main():
    # install SIGINT handler for a clean exit on Ctrl-C
    signal.signal(signal.SIGINT, _handle_sigint)

    tts_engine = SystemTTS()
    if not tts_engine.method:
        print("Note: No system TTS found. Replies will be printed only.", file=sys.stderr)

    bot = DrSbaitso(tts=tts_engine if tts_engine.method else None)
    print(BOT_PROMPT + bot.greet())
    print(BOT_PROMPT + "Type /exit or q to quit. (You can also say goodbye, exit, quit, stop)")

    while True:
        try:
            user = input(USER_PROMPT)
        except (EOFError, KeyboardInterrupt):
            # handled by signal handler for SIGINT; EOF triggers a clean exit here
            print()
            farewell = "Goodbye. Take care."
            print(BOT_PROMPT + farewell)
            if bot.tts:
                bot.tts.speak(farewell)
            break

        if user is None:
            # safety: treat None as exit
            farewell = "Goodbye. Take care."
            print(BOT_PROMPT + farewell)
            if bot.tts:
                bot.tts.speak(farewell)
            break

        user = user.strip()
        if not user:
            prompt = "I didn't catch that. Could you repeat?"
            print(BOT_PROMPT + prompt)
            if bot.tts:
                bot.tts.speak(prompt)
            continue

        low = user.lower()
        # explicit exit commands (exact match or single-token)
        if low in EXIT_COMMANDS or (low.split() and low.split()[0] in EXIT_COMMANDS):
            farewell = "Goodbye. It was nice talking to you."
            print(BOT_PROMPT + farewell)
            if bot.tts:
                bot.tts.speak(farewell)
            break

        # help quick command
        if low in ("/help", "help", "commands"):
            info = "Commands: /exit, /quit, q, stop, shutdown. Or just say goodbye, exit, or quit."
            print(BOT_PROMPT + info)
            if bot.tts:
                bot.tts.speak(info)
            continue

        reply = bot.respond(user)
        print(BOT_PROMPT + reply)

if __name__ == "__main__":
    main()
