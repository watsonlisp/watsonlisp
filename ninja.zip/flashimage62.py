#!/usr/bin/env python3
"""
flasher_display.py
Sequential image flasher that displays images one after another.

Features included:
- Interval entered and displayed in milliseconds.
- Main window sized wider so top controls/buttons are visible.
- Viewer auto-off length configurable in milliseconds.
- Pause keeps the current image visible and cancels any pending external-viewer auto-close.
- Uses MS Paint only on Windows for external viewing (no fallback to startfile).
- Next and Previous navigation with in-memory history (capped).
- One-shot, prefetcher, Pillow fallback, tempfile fallback, and robust multi-provider fetch.
- When Start is pressed, any external viewer left open while paused will be scheduled to auto-close,
  and future external opens will use the configured auto-off delay.
- External viewers are closed automatically after the configured delay (unless hold_viewer=True).
"""

import tkinter as tk
import tkinter.ttk as ttk
import urllib.request
import urllib.parse
import threading
import queue
import tempfile
import os
import time
import random
import sys
import base64
import subprocess
from urllib.error import URLError, HTTPError
from io import BytesIO

# Try optional Pillow
try:
    from PIL import Image
    PIL_AVAILABLE = True
except Exception:
    PIL_AVAILABLE = False

# Globals to track last external viewer process/timer so we can cancel or schedule auto-close
LAST_VIEWER_PROC = None
LAST_VIEWER_TIMER = None
LAST_VIEWER_LOCK = threading.Lock()

# ---------------------------
# Config
# ---------------------------
PREFETCH_SIZE = 1
FETCH_TIMEOUT = 1
MAX_RETRIES = 1
MIN_INTERVAL = 0.0000000000005
MIN_INTERVAL_MS = max(1, int(MIN_INTERVAL * 0.0025))

# ---------------------------
# Simple synonyms mapping (trimmed for brevity)
# ---------------------------
SYNONYMS = {
    "nature": ["outdoors", "landscape", "scenery", "wilderness", "countryside"],
    "forest": ["woods", "woodland", "timberland", "grove", "jungle"],
    "tree": ["oak", "pine", "fir", "sapling", "timber"],
    "mountain": ["peak", "hill", "range", "summit", "alp"],
    "river": ["stream", "creek", "brook", "waterway", "tributary"],
    "lake": ["pond", "reservoir", "loch", "basin", "waterbody"],
    "ocean": ["sea", "marine", "deep", "blue", "coast"],
    "beach": ["coast", "seashore", "shore", "sand", "strand"],
    "sky": ["clouds", "heavens", "firmament", "atmosphere", "blue"],
    "sunset": ["dusk", "twilight", "sundown", "evening", "golden hour"],
    "sunrise": ["dawn", "daybreak", "morning", "first light", "aurora"],
    "flower": ["blossom", "bloom", "floral", "petal", "inflorescence"],
    "garden": ["yard", "orchard", "nursery", "greenhouse", "plot"],
    "animal": ["creature", "beast", "fauna", "wildlife", "organism"],
    "cat": ["kitten", "feline", "pussycat", "moggy", "cats"],
    "dog": ["puppy", "canine", "hound", "pooch", "dogs"],
    "bird": ["avian", "fowl", "songbird", "raptor", "winged"],
    "horse": ["stallion", "mare", "pony", "equine", "colt"],
    "people": ["person", "human", "individual", "crowd", "group"],
    "portrait": ["headshot", "closeup", "profile", "face", "portraiture"],
    "city": ["urban", "metropolis", "downtown", "municipality", "urbanscape"],
    "street": ["road", "avenue", "boulevard", "lane", "alley"],
    "architecture": ["building", "structure", "edifice", "design", "facade"],
    "bridge": ["overpass", "viaduct", "span", "crossing", "footbridge"],
    "car": ["automobile", "vehicle", "auto", "sedan", "coupe"],
    "motorcycle": ["bike", "motorbike", "scooter", "chopper", "two-wheeler"],
    "food": ["cuisine", "dish", "meal", "fare", "grub"],
    "drink": ["beverage", "refreshment", "juice", "soda", "cocktail"],
    "coffee": ["espresso", "latte", "cappuccino", "brew", "americano"],
    "dessert": ["sweet", "pastry", "cake", "treat", "confection"],
    "fruit": ["apple", "berry", "citrus", "produce", "orchard fruit"],
    "vegetable": ["greens", "produce", "root", "leafy", "veggie"],
    "foodporn": ["plating", "gourmet", "foodie", "culinary", "delicious"],
    "travel": ["journey", "trip", "voyage", "adventure", "explore"],
    "vacation": ["holiday", "getaway", "break", "retreat", "escape"],
    "adventure": ["exploration", "expedition", "quest", "outing", "trek"],
    "sports": ["athletics", "game", "competition", "match", "recreation"],
    "soccer": ["football", "futbol", "association football", "match", "goal"],
    "basketball": ["hoops", "nba", "court", "dribble", "slam dunk"],
    "tennis": ["racket", "court", "match", "serve", "grand slam"],
    "music": ["song", "melody", "tune", "sound", "audio"],
    "concert": ["gig", "live", "performance", "show", "festival"],
    "instrument": ["guitar", "piano", "drums", "violin", "saxophone"],
    "art": ["painting", "drawing", "illustration", "visual", "creative"],
    "painting": ["oil", "watercolor", "acrylic", "canvas", "portrait"],
    "abstract": ["conceptual", "nonrepresentational", "modern", "minimal"],
    "blackandwhite": ["monochrome", "b&w", "grayscale", "noir", "contrast"],
    "vintage": ["retro", "old", "classic", "nostalgic", "antique"],
    "fashion": ["style", "clothing", "apparel", "couture", "runway"],
    "model": ["mannequin", "fashion model", "portrait", "subject", "figure"],
    "technology": ["tech", "gadget", "device", "electronics", "innovation"],
    "computer": ["pc", "laptop", "workstation", "desktop", "mac"],
    "phone": ["smartphone", "mobile", "cell", "handset", "device"],
    "office": ["workspace", "desk", "corporate", "meeting", "cubicle"],
    "work": ["job", "occupation", "career", "profession", "task"],
    "education": ["school", "learning", "university", "college", "study"],
    "student": ["pupil", "learner", "scholar", "undergrad", "grad"],
    "science": ["research", "laboratory", "experiment", "biology", "physics"],
    "space": ["astronomy", "cosmos", "galaxy", "universe", "outer space"],
    "night": ["nocturnal", "dark", "evening", "midnight", "after hours"],
    "party": ["celebration", "gathering", "festivity", "bash", "event"],
    "holiday": ["festival", "celebration", "observance", "vacation", "break"],
    "wedding": ["marriage", "ceremony", "bride", "groom", "nuptials"],
    "baby": ["infant", "newborn", "toddler", "child", "little one"],
    "family": ["relatives", "household", "kin", "parents", "siblings"],
    "pets": ["companion", "animal", "pet", "domestic", "housepet"],
    "cute": ["adorable", "charming", "sweet", "endearing", "lovable"],
    "funny": ["humorous", "comical", "hilarious", "witty", "silly"],
    "dramatic": ["intense", "theatrical", "emotional", "bold", "striking"],
    "minimal": ["simple", "clean", "sparse", "understated", "subtle"],
    "colorful": ["vibrant", "bright", "saturated", "bold", "chromatic"],
    "nightlife": ["club", "bar", "party", "late night", "after dark"],
    "landscape": ["scenery", "vista", "panorama", "view", "outlook"],
    "aerial": ["drone", "birdseye", "overhead", "topdown", "skyview"],
    "macro": ["closeup", "detail", "extreme close-up", "microscopic", "texture"],
    "streetphotography": ["candid", "urban", "documentary", "street", "city life"],
    "documentary": ["reportage", "photojournalism", "storytelling", "nonfiction", "real life"],
    "conceptual": ["idea", "symbolic", "metaphorical", "abstract", "thematic"],
    "holidayseason": ["christmas", "hanukkah", "festive", "winter holidays", "seasonal"],
    "winter": ["snow", "cold", "frost", "ice", "chill"],
    "spring": ["bloom", "rebirth", "fresh", "green", "blossom"],
    "summer": ["sunny", "warm", "beach", "vacation", "heat"],
    "autumn": ["fall", "leaves", "harvest", "golden", "crisp"],
}

def expand_query_with_synonyms(query, include_synonyms):
    if not include_synonyms or not query:
        return query
    tokens = [t.strip().lower() for t in query.replace(",", " ").split() if t.strip()]
    extras = []
    for t in tokens:
        syns = SYNONYMS.get(t)
        if syns:
            for s in syns:
                if s not in tokens and s not in extras:
                    extras.append(s)
    if not extras:
        return query
    combined = ",".join([query] + extras)
    return combined

# ---------------------------
# HTTP helpers and fetcher
# ---------------------------
def _http_get_bytes(url, timeout=FETCH_TIMEOUT):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
        final_url = resp.geturl()
        content_type = resp.headers.get("Content-Type", "")
        return data, content_type, final_url

def make_unsplash(query, randomize):
    qenc = urllib.parse.quote(query, safe=",")
    url = f"https://source.unsplash.com/featured/?{qenc}"
    if randomize:
        url += f"&r={random.randint(1,999999)}"
    return url

def make_picsum():
    return f"https://picsum.photos/900/600?{random.randint(1,999999)}"

def make_loremflickr(query):
    q = urllib.parse.quote(query, safe=",")
    tag = q or "nature"
    return f"https://loremflickr.com/900/600/{tag}?random={random.randint(1,999999)}"

def make_placeimg(category="nature"):
    cat = urllib.parse.quote(category or "nature")
    return f"https://placeimg.com/900/600/{cat}?{random.randint(1,999999)}"

def make_placehold_co(query):
    text = urllib.parse.quote(query or "placeholder")
    return f"https://placehold.co/900x600?text={text}"

def make_dummyimage(query):
    text = urllib.parse.quote(query or "image")
    return f"https://dummyimage.com/900x600/cccccc/000000&text={text}"

def make_placekitten():
    return f"https://placekitten.com/900/600"

def make_pixabay_sample():
    return "https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_1280.jpg"

def make_static_wikimedia_sample():
    return "https://upload.wikimedia.org/wikipedia/commons/3/3f/Fronalpstock_big.jpg"



def make_pexels(query):
    # Pexels supports direct query URLs via their CDN
    q = urllib.parse.quote(query or "nature")
    return f"https://images.pexels.com/photos/414171/pexels-photo-414171.jpeg?auto=compress&cs=tinysrgb&query={q}"

def make_stocksnap(query):
    q = urllib.parse.quote(query or "nature")
    # StockSnap doesn’t have a simple query endpoint, but you can simulate with a tag
    return f"https://stocksnap.io/search/{q}"

def make_burst(query):
    q = urllib.parse.quote(query or "nature")
    return f"https://burst.shopifycdn.com/photos/{q}.jpg"

def make_publicdomain(query):
    q = urllib.parse.quote(query or "nature")
    return f"https://publicdomainpictures.net/en/search/?query={q}"

def make_openverse(query):
    q = urllib.parse.quote(query or "nature")
    # Openverse requires API calls, but you can seed with a search URL
    return f"https://search.openverse.org/image?q={q}"








def robust_fetch(source, randomize, timeout=FETCH_TIMEOUT, max_retries=MAX_RETRIES):
    if source.startswith("http://") or source.startswith("https://"):
        candidates = [source]
    else:
        first_token = (source.split(",")[0] if source else "nature").strip()

        candidates = [
           make_unsplash(source, randomize),
           make_loremflickr(source),
           make_picsum(),
           make_placeimg(first_token),
           make_placehold_co(source),
           make_dummyimage(source),
           make_placekitten(),
           make_pixabay_sample(),
           make_static_wikimedia_sample(),
           make_pexels(source),
           make_stocksnap(source),
           make_burst(source),
           make_publicdomain(source),
           make_openverse(source),
]


    for idx, url in enumerate(candidates):
        attempt = 0
        while attempt <= max_retries:
            try:
                attempt += 1
                if attempt > 1:
                    backoff = 0.5 * (2 ** (attempt - 2)) + random.random() * 0.2
                    time.sleep(backoff)
                data, content_type, final_url = _http_get_bytes(url, timeout=timeout)
                if not data:
                    raise Exception("empty response")
                return data, content_type, final_url
            except HTTPError as he:
                code = getattr(he, "code", None)
                if code in (429, 503, 502, 504):
                    if attempt > max_retries:
                        break
                    else:
                        continue
                else:
                    raise
            except URLError:
                if attempt > max_retries:
                    break
                else:
                    continue
            except Exception:
                if attempt > max_retries:
                    break
                else:
                    continue
    raise Exception("All providers failed or returned non-image responses")

# ---------------------------
# Prefetcher thread
# ---------------------------
class Prefetcher(threading.Thread):
    def __init__(self, source_getter, buffer_queue, randomize_var, mode_var, include_synonyms_var, stop_event):
        super().__init__(daemon=True)
        self.source_getter = source_getter
        self.buffer = buffer_queue
        self.randomize_var = randomize_var
        self.mode_var = mode_var
        self.include_synonyms_var = include_synonyms_var
        self.stop_event = stop_event

    def run(self):
        while not self.stop_event.is_set():
            try:
                while not self.stop_event.is_set() and self.buffer.qsize() < PREFETCH_SIZE:
                    base_src = self.source_getter() or "nature"
                    try:
                        src = base_src
                        randomize_flag = self.randomize_var.get() if self.mode_var.get() == "query" else False
                        data, content_type, final_url = robust_fetch(src, randomize_flag)
                        self.buffer.put((data, content_type, final_url))
                    except Exception:
                        time.sleep(0.5)
                time.sleep(0.05)
            except Exception:
                time.sleep(0.1)

# ---------------------------
# Display helpers
# ---------------------------
def display_with_pillow(label_widget, img_bytes, status_label):
    try:
        img = Image.open(BytesIO(img_bytes)).convert("RGBA")
        bio = BytesIO()
        img.save(bio, format="PNG")
        png_data = bio.getvalue()
        b64 = base64.b64encode(png_data).decode("ascii")
        photo = tk.PhotoImage(data=b64)
        label_widget.configure(image=photo)
        label_widget._photo_ref = photo
        status_label.configure(text=f"Displayed (via Pillow) at {time.strftime('%H:%M:%S')}")
        return True
    except Exception as e:
        status_label.configure(text=f"Pillow display error: {e}")
        return False

def display_via_tempfile_file(label_widget, img_bytes, content_type, final_url, status_label):
    path = None
    try:
        suffix = None
        if content_type:
            ct = content_type.split(";")[0].strip().lower()
            mapping = {
                "image/jpeg": ".jpg",
                "image/jpg": ".jpg",
                "image/png": ".png",
                "image/gif": ".gif",
                "image/bmp": ".bmp",
                "image/webp": ".webp",
                "image/tiff": ".tiff",
                "image/x-icon": ".ico",
            }
            suffix = mapping.get(ct)
        if not suffix and final_url:
            _, ext = os.path.splitext(final_url.split("?")[0])
            if ext:
                suffix = ext if ext.startswith(".") else f".{ext}"
        if not suffix:
            suffix = ".jpg"
        fd, path = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        with open(path, "wb") as f:
            f.write(img_bytes)
        try:
            photo = tk.PhotoImage(file=path)
            label_widget.configure(image=photo)
            label_widget._photo_ref = photo
            status_label.configure(text=f"Displayed (file {suffix}) at {time.strftime('%H:%M:%S')}")
            return True
        except Exception as e:
            status_label.configure(text=f"PhotoImage load failed: {e}")
            return False
    except Exception as e:
        status_label.configure(text=f"Display error: {e}")
        return False
    finally:
        if path:
            def _cleanup(p=path):
                try:
                    os.remove(p)
                except Exception:
                    pass
            label_widget.after(1200, _cleanup)

def _open_and_auto_close(path, delay=2.0):
    """
    Open the image with a viewer we can close programmatically.
    - On Windows: use mspaint only. If mspaint is not available, return (False, None, None).
    - If delay is None, open without scheduling auto-close (hold).
    Returns (opened_controllable: bool, proc_or_none, timer_or_none).
    """
    try:
        if delay is None:
            if sys.platform.startswith("darwin"):
                subprocess.Popen(["open", path])
                return False, None, None
            elif os.name == "nt":
                try:
                    proc = subprocess.Popen(["mspaint", path])
                    return True, proc, None
                except FileNotFoundError:
                    return False, None, None
            else:
                try:
                    subprocess.Popen(["xdg-open", path])
                except Exception:
                    pass
                return False, None, None

        # numeric delay -> attempt controllable open with auto-close
        if sys.platform.startswith("darwin"):
            script = (
                f'tell application "Preview"\n'
                f'  open POSIX file "{path}"\n'
                f'  delay {delay}\n'
                f'  try\n'
                f'    close (every window whose name contains "{os.path.basename(path)}")\n'
                f'  end try\n'
                f'end tell\n'
            )
            proc = subprocess.Popen(["osascript", "-e", script])
            return True, proc, None

        elif os.name == "nt":
            try:
                proc = subprocess.Popen(["mspaint", path])
                # create a timer that will terminate the process after `delay` seconds
                timer = threading.Timer(delay, lambda p=proc: p.terminate() if p and p.poll() is None else None)
                timer.start()
                return True, proc, timer
            except FileNotFoundError:
                return False, None, None

        else:
            for viewer in ("eog", "display", "feh"):
                try:
                    proc = subprocess.Popen([viewer, path])
                    timer = threading.Timer(delay, lambda p=proc: p.terminate() if p and p.poll() is None else None)
                    timer.start()
                    return True, proc, timer
                except FileNotFoundError:
                    continue
            try:
                subprocess.Popen(["xdg-open", path])
            except Exception:
                pass
            return False, None, None
    except Exception:
        return False, None, None

def display_image_bytes(label_widget, img_bytes, content_type, final_url, status_label, viewer_auto_close_ms=2000, hold_viewer=False):
    """
    Try Pillow first, then tempfile, then external viewer.
    If hold_viewer True, open external viewer without auto-close.
    Otherwise schedule auto-close using viewer_auto_close_ms and clear stored references after termination.
    """
    global LAST_VIEWER_PROC, LAST_VIEWER_TIMER

    if PIL_AVAILABLE:
        ok = display_with_pillow(label_widget, img_bytes, status_label)
        if ok:
            return

    ok = display_via_tempfile_file(label_widget, img_bytes, content_type, final_url, status_label)
    if ok:
        return

    # external viewer fallback
    status_label.configure(text="Cannot display in Tk. Opening externally.")
    try:
        suffix = ".jpg"
        if content_type:
            ct = content_type.split(";")[0].strip().lower()
            mapping = {
                "image/png": ".png",
                "image/gif": ".gif",
                "image/webp": ".webp",
                "image/bmp": ".bmp",
                "image/tiff": ".tiff",
                "image/x-icon": ".ico",
                "image/jpeg": ".jpg",
            }
            suffix = mapping.get(ct, suffix)
        elif final_url:
            _, ext = os.path.splitext(final_url.split("?")[0])
            if ext:
                suffix = ext if ext.startswith(".") else f".{ext}"

        fd, path = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        with open(path, "wb") as f:
            f.write(img_bytes)

        # determine delay: None => hold, numeric => auto-close
        delay_seconds = None if hold_viewer else max(0.0, float(viewer_auto_close_ms) / 1000.0)

        opened_controllable, proc, timer = _open_and_auto_close(path, delay=delay_seconds)

        # store last viewer proc/timer and ensure we clear them after auto-close fires
        with LAST_VIEWER_LOCK:
            # cancel any previous timer (we'll replace it)
            if LAST_VIEWER_TIMER is not None:
                try:
                    LAST_VIEWER_TIMER.cancel()
                except Exception:
                    pass
                LAST_VIEWER_TIMER = None
            LAST_VIEWER_PROC = proc
            LAST_VIEWER_TIMER = timer

        # If we scheduled an auto-close timer, ensure it clears stored refs when it runs
        if timer is not None:
            def _close_and_clear(p):
                try:
                    if p and p.poll() is None:
                        try:
                            p.terminate()
                        except Exception:
                            pass
                finally:
                    with LAST_VIEWER_LOCK:
                        try:
                            global LAST_VIEWER_PROC, LAST_VIEWER_TIMER
                            LAST_VIEWER_PROC = None
                            LAST_VIEWER_TIMER = None
                        except Exception:
                            pass

            # cancel the original timer and replace with one that also clears refs
            try:
                timer.cancel()
            except Exception:
                pass
            cleanup_timer = threading.Timer(delay_seconds, lambda p=proc: _close_and_clear(p))
            cleanup_timer.start()
            with LAST_VIEWER_LOCK:
                LAST_VIEWER_TIMER = cleanup_timer

        def _cleanup(p=path):
            try:
                os.remove(p)
            except Exception:
                pass

        cleanup_delay = 3.0 if (opened_controllable and (delay_seconds is not None)) else 8.0
        label_widget.after(int(cleanup_delay * 1000), _cleanup)
    except Exception as e:
        status_label.configure(text=f"Display failed: {e}")

# ---------------------------
# One-shot helper
# ---------------------------
def start_once(app):
    src = app._current_source()
    app.status.configure(text="One-shot fetching...")
    try:
        is_direct_url = src.startswith("http://") or src.startswith("https://")
        randomize_flag = app.randomize.get() if not is_direct_url else False
        data, content_type, final_url = robust_fetch(src, randomize_flag)
        # When running, force auto-off; when paused, respect hold flag
        if app.running:
            hold = False
        else:
            hold = app.paused or app.hold_viewer_on_pause
        display_image_bytes(app.display, data, content_type, final_url, app.status, viewer_auto_close_ms=app.viewer_auto_close_ms.get(), hold_viewer=hold)
        app._append_history((data, content_type, final_url))
    except Exception as e:
        app.status.configure(text=f"One-shot error: {e}")

# ---------------------------
# Main GUI app
# ---------------------------
class ImageFlasher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Image Flasher - display")

        # Make the main window wider so toolbar/buttons are visible on most displays.
        # Use nearly full width but leave a small margin so the OS window chrome remains accessible.
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        win_w = max(1200, int(screen_w * 0.98))
        win_h = min(950, max(700, int(screen_h * 0.85)))
        self.geometry(f"{win_w}x{win_h}")
        # Optionally start maximized on platforms that support it
        try:
            # Windows and many Linux window managers
            self.state("zoomed")
        except Exception:
            # Fallback: keep the explicit geometry if zoomed state isn't supported
            pass

        self.minsize(1000, 600)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        # state
        self.interval = tk.IntVar(value=2000)  # ms
        self.query = tk.StringVar(value="nature")
        self.running = False
        self.paused = False
        self.hold_viewer_on_pause = True
        self.randomize = tk.BooleanVar(value=True)
        self.include_synonyms = tk.BooleanVar(value=False)
        self.mode = tk.StringVar(value="query")
        self.viewer_auto_close_ms = tk.IntVar(value=2000)

        # buffer and prefetcher
        self.buffer = queue.Queue(maxsize=PREFETCH_SIZE + 2)
        self.stop_event = threading.Event()
        self.prefetcher = None

        # history
        self.history = []
        self.history_index = -1
        self.HISTORY_MAX = 100

        # UI
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=6)

        ttk.Label(top, text="Mode").pack(side="left")
        ttk.Radiobutton(top, text="Query", variable=self.mode, value="query").pack(side="left", padx=4)
        ttk.Radiobutton(top, text="Direct URL", variable=self.mode, value="url").pack(side="left", padx=4)

        ttk.Label(top, text="Input").pack(side="left", padx=(10,0))
        ttk.Entry(top, textvariable=self.query, width=40).pack(side="left", padx=6)

        ttk.Label(top, text="Interval ms").pack(side="left", padx=(10,0))
        ttk.Spinbox(top, from_=MIN_INTERVAL_MS, to=60000, increment=50, textvariable=self.interval, width=8).pack(side="left", padx=6)
        self.interval_ms_label = ttk.Label(top, text=f"{max(MIN_INTERVAL_MS, self.interval.get())} ms")
        self.interval_ms_label.pack(side="left", padx=(4,6))
        try:
            self.interval.trace_add("write", lambda *args: self._update_interval_ms())
        except AttributeError:
            self.interval.trace("w", lambda *args: self._update_interval_ms())

        ttk.Label(top, text="Viewer auto-off ms").pack(side="left", padx=(10,0))
        ttk.Spinbox(top, from_=100, to=60000, increment=100, textvariable=self.viewer_auto_close_ms, width=8).pack(side="left", padx=6)
        self.viewer_auto_label = ttk.Label(top, text=f"{self.viewer_auto_close_ms.get()} ms")
        self.viewer_auto_label.pack(side="left", padx=(4,6))
        try:
            self.viewer_auto_close_ms.trace_add("write", lambda *args: self._update_viewer_auto_label())
        except AttributeError:
            self.viewer_auto_close_ms.trace("w", lambda *args: self._update_viewer_auto_label())

        ttk.Checkbutton(top, text="Randomize query", variable=self.randomize).pack(side="left", padx=6)
        ttk.Checkbutton(top, text="Add synonyms", variable=self.include_synonyms).pack(side="left", padx=6)

        # Controls
        self.start_btn = ttk.Button(top, text="Start", command=self.start)
        self.start_btn.pack(side="left", padx=6)

        self.pause_btn = ttk.Button(top, text="Pause", command=self.toggle_pause)
        self.pause_btn.pack(side="left", padx=6)

        ttk.Button(top, text="Stop", command=self.stop).pack(side="left", padx=6)
        ttk.Button(top, text="One-shot", command=lambda: start_once(self)).pack(side="left", padx=6)

        self.prev_btn = ttk.Button(top, text="Previous", command=self.previous_image)
        self.prev_btn.pack(side="left", padx=6)
        self.next_btn = ttk.Button(top, text="Next", command=self.next_image)
        self.next_btn.pack(side="left", padx=6)

        self.display = ttk.Label(self, background="black")
        self.display.pack(expand=True, fill="both")

        self.status = ttk.Label(self, text="Ready", anchor="w")
        self.status.pack(fill="x")

        self.after(100, self._sequential_loop)

    def _current_source(self):
        q = self.query.get().strip()
        if self.mode.get() == "url":
            return q or ""
        q = q or "nature"
        tokens = [t for t in q.replace(",", " ").split() if t]
        base = ",".join(tokens)
        if self.include_synonyms.get():
            expanded = expand_query_with_synonyms(base, True)
            return expanded
        return base

    def _update_interval_ms(self):
        try:
            val = int(self.interval.get())
        except Exception:
            val = MIN_INTERVAL_MS
        ms = max(MIN_INTERVAL_MS, val)
        self.interval_ms_label.configure(text=f"{ms} ms")

    def _update_viewer_auto_label(self):
        try:
            val = int(self.viewer_auto_close_ms.get())
        except Exception:
            val = 2000
        self.viewer_auto_label.configure(text=f"{val} ms")

    def _start_prefetcher(self):
        if self.prefetcher and self.prefetcher.is_alive():
            return
        self.stop_event.clear()
        self.prefetcher = Prefetcher(self._current_source, self.buffer, self.randomize, self.mode, self.include_synonyms, self.stop_event)
        self.prefetcher.start()

    def _stop_prefetcher(self):
        if self.prefetcher:
            self.stop_event.set()
            self.prefetcher.join(timeout=1.0)
            self.prefetcher = None

    def _append_history(self, item):
        if not item:
            return
        self.history.append(item)
        if len(self.history) > self.HISTORY_MAX:
            self.history.pop(0)
        self.history_index = len(self.history) - 1

    def _display_from_history_index(self, idx):
        if idx < 0 or idx >= len(self.history):
            return False
        data, content_type, final_url = self.history[idx]
        # When running, force auto-off; when paused, respect hold flag
        if self.running:
            hold = False
        else:
            hold = self.paused or self.hold_viewer_on_pause
        display_image_bytes(self.display, data, content_type, final_url, self.status, viewer_auto_close_ms=self.viewer_auto_close_ms.get(), hold_viewer=hold)
        self.history_index = idx
        self.status.configure(text=f"History {self.history_index+1}/{len(self.history)}")
        return True

    def previous_image(self):
        if len(self.history) == 0:
            self.status.configure(text="No history available")
            return
        if self.history_index <= 0:
            self.status.configure(text="At oldest image")
            return
        new_idx = self.history_index - 1
        ok = self._display_from_history_index(new_idx)
        if ok:
            return

    def next_image(self):
        if self.history_index < len(self.history) - 1:
            new_idx = self.history_index + 1
            ok = self._display_from_history_index(new_idx)
            if ok:
                return
        try:
            data, content_type, final_url = self.buffer.get_nowait()
            # When running, force auto-off; when paused, respect hold flag
            if self.running:
                hold = False
            else:
                hold = self.paused or self.hold_viewer_on_pause
            display_image_bytes(self.display, data, content_type, final_url, self.status, viewer_auto_close_ms=self.viewer_auto_close_ms.get(), hold_viewer=hold)
            self._append_history((data, content_type, final_url))
            return
        except queue.Empty:
            self.status.configure(text="Fetching next image...")
            try:
                src = self._current_source()
                is_direct_url = src.startswith("http://") or src.startswith("https://")
                randomize_flag = self.randomize.get() if not is_direct_url else False
                data, content_type, final_url = robust_fetch(src, randomize_flag)
                if self.running:
                    hold = False
                else:
                    hold = self.paused or self.hold_viewer_on_pause
                display_image_bytes(self.display, data, content_type, final_url, self.status, viewer_auto_close_ms=self.viewer_auto_close_ms.get(), hold_viewer=hold)
                self._append_history((data, content_type, final_url))
            except Exception as e:
                self.status.configure(text=f"Next fetch error: {e}")

    def toggle_pause(self):
        global LAST_VIEWER_TIMER, LAST_VIEWER_PROC
        if not self.running:
            self.start()
            return
        if not self.paused:
            # Pause: keep current image visible and cancel any pending auto-close
            self.paused = True
            self.running = False
            self.pause_btn.configure(text="Resume")
            self.status.configure(text="Paused (current image held)")
            with LAST_VIEWER_LOCK:
                if LAST_VIEWER_TIMER is not None:
                    try:
                        LAST_VIEWER_TIMER.cancel()
                    except Exception:
                        pass
                    LAST_VIEWER_TIMER = None
            self.hold_viewer_on_pause = True
        else:
            # Resume from pause
            self.paused = False
            self.running = True
            self.pause_btn.configure(text="Pause")
            self.status.configure(text="Resumed")
            self._start_prefetcher()

    def _sequential_loop(self):
        try:
            if self.running:
                try:
                    data, content_type, final_url = self.buffer.get_nowait()
                    # When running, force auto-off; when paused, respect hold flag
                    if self.running:
                        hold = False
                    else:
                        hold = self.paused or self.hold_viewer_on_pause
                    display_image_bytes(self.display, data, content_type, final_url, self.status, viewer_auto_close_ms=self.viewer_auto_close_ms.get(), hold_viewer=hold)
                    self._append_history((data, content_type, final_url))
                    delay_ms = max(MIN_INTERVAL_MS, int(self.interval.get()))
                    self.interval_ms_label.configure(text=f"{delay_ms} ms")
                    self.status.configure(text=f"Displayed; next in {delay_ms} ms")
                    self.after(delay_ms, self._sequential_loop)
                    return
                except queue.Empty:
                    self.status.configure(text="Buffer empty — waiting for images...")
                    self.after(100, self._sequential_loop)
                    return
            self.after(200, self._sequential_loop)
        except Exception:
            self.after(500, self._sequential_loop)

    def start(self):
        """Start or resume the flasher. Clears paused state and ensures prefetcher is running.
        Also enable external-viewer auto-off when starting (undoes hold-on-pause). If an external
        viewer was left open while paused and no auto-close timer exists, schedule its auto-close now.
        """
        global LAST_VIEWER_PROC, LAST_VIEWER_TIMER

        if self.running:
            return

        # Ensure auto-off behavior is enabled when starting
        self.hold_viewer_on_pause = False

        # Resume normal running state
        self.running = True
        self.paused = False
        self.start_btn.configure(text="Running")
        self.pause_btn.configure(text="Pause")

        # Start prefetcher
        self._start_prefetcher()

    def stop(self):
        """Stop the flasher and prefetcher."""
        if not self.running and not self.paused:
            return
        self.running = False
        self.paused = False
        self._stop_prefetcher()
        self.status.configure(text="Stopped")

    def on_close(self):
        """Cleanup and exit."""
        try:
            self.stop()
        except Exception:
            pass

        try:
            self.destroy()
        except Exception:
            os._exit(0)

# If you run this file directly, create the app and start the Tk mainloop.
if __name__ == "__main__":
    app = ImageFlasher()
    try:
        app.mainloop()
    except KeyboardInterrupt:
        try:
            app.on_close()
        except Exception:
            pass
