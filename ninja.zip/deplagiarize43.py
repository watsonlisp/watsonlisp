#!/usr/bin/env python3
"""
Yoda-focused reordering that preserves meaning when shuffling.

Added features:
- --yogglre: toggle synonym replacement using Datamuse (no pip).
- --yogglre-prob: probability of replacing each eligible word (0.0-1.0).
- Caching for Datamuse lookups and polite tiny delays on misses.
Behavior changes:
- Defaults adjusted per user request: word-mode none, no preserve-meaning,
  no front-prep, seed 0, no yogglre, yogglre-prob 0.0, and paraphrase disabled by default.
- Flags entered via the interactive "flags" prompt now persist unless explicitly toggled.
- Added interactive "status" command to show current flag values.
- Repeat now regenerates output using a fresh seed so repeated results differ.
- Added interactive "save" command to write the current generation to a text file.
"""
from __future__ import annotations
import argparse
import random
import re
import shlex
import sys
from typing import List, Optional

# file-picker support
try:
    import tkinter as _tk
    from tkinter import filedialog as _filedialog
except Exception:
    _tk = None
    _filedialog = None

# --- System TTS related imports (stdlib only) ---
import platform
import subprocess
import threading
import time
import shutil
import os

# --- Datamuse (stdlib-only) ---
import urllib.request
import urllib.parse
import json
from functools import lru_cache

# Globals for TTS control
_tts_thread: Optional[threading.Thread] = None
_tts_stop_event = threading.Event()
_tts_process: Optional[subprocess.Popen] = None

_STOPWORDS = {
    "a","an","the","and","or","but","if","while","for","to","of","in","on","at","by","with","about","as",
    "is","are","was","were","be","been","being","have","has","had","do","does","did","will","would","shall",
    "should","can","could","may","might","must","that","this","these","those","it","its","he","she","they",
    "we","you","i","me","him","her","them","us","my","your","his","her","their","our"
}
_AUXILIARIES = {"be","am","is","are","was","were","been","being","have","has","had","do","does","did",
                "will","would","shall","should","can","could","may","might","must"}
_PREP_PATTERN = r'(?:from|in|on|at|by|over|under|into|onto|through|around|behind|beside|near|between|among|via|per)'

# Datamuse base
_DATAMUSE_BASE = "https://api.datamuse.com/words"

def get_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(add_help=False, formatter_class=argparse.RawDescriptionHelpFormatter,
                                description="Yoda-style reordering with meaning preservation and repeat/new/exit prompt.")
    p.add_argument("--text", type=str, help="Text to process.")
    p.add_argument("--file", type=str, help="Path to text file(blank for selection).")
    p.add_argument("--word-mode", choices=["semantic","shuffle","reverse","none"], default="none",
                   help="Word-level mode (default: none).")
    # Default: preserve_meaning disabled by default
    p.add_argument("--preserve-meaning", dest="preserve_meaning", action="store_true", default=False,
                   help="Enable preserve-meaning mapping (default: disabled).")
    p.add_argument("--no-preserve-meaning", dest="preserve_meaning", action="store_false",
                   help="Disable preserve-meaning mapping (alias, default behavior).")
    # Default: Yoda disabled (use --yoda to enable)
    p.add_argument("--yoda", dest="yoda", action="store_true", default=False,
                   help="Apply Yoda-speak transform (default: disabled).")
    p.add_argument("--no-yoda", dest="yoda", action="store_false",
                   help="Disable Yoda-speak transform.")
    # Default: paraphrase disabled by default (so --no-paraphrase is the default)
    p.add_argument("--paraphrase", dest="paraphrase", action="store_true", default=False,
                   help="Apply meaning-preserving paraphrase: front prepositional phrase without Yoda punctuation (default: disabled).")
    p.add_argument("--no-paraphrase", dest="paraphrase", action="store_false",
                   help="Disable paraphrase mode (alias, default behavior).")
    # Default: front-prep disabled by default
    p.add_argument("--front-prep", dest="front_prep", action="store_true", default=False,
                   help="Front trailing prepositional phrase (default: disabled).")
    p.add_argument("--no-front-prep", dest="front_prep", action="store_false",
                   help="Disable prepositional fronting (alias, default behavior).")
    # Seed default 0
    p.add_argument("--seed", type=int, default=0, help="Seed for reproducible shuffles (default: 0).")
    # Yogglre flags (synonym replacement) - disabled by default
    p.add_argument("--yogglre", dest="yogglre", action="store_true", default=False,
                   help="Replace eligible words with synonyms using Datamuse (no pip). (default: disabled)")
    p.add_argument("--no-yogglre", dest="yogglre", action="store_false",
                   help="Disable synonym replacement (yogglre).")
    p.add_argument("--yogglre-prob", dest="yogglre_prob", type=float, default=0.0,
                   help="Probability (0.0-1.0) of replacing each eligible word (default 0.0).")
    p.add_argument("-h", "--help", action="help", help="Show this help message and exit.")
    return p

def parse_args(argv: Optional[List[str]] = None):
    parser = get_arg_parser()
    return parser.parse_args(argv)

def regex_split_keep_ws(text: str) -> List[str]:
    if not text:
        return []
    parts = re.split(r'(?<=[\.\?\!])(\s+)', text)
    out = []
    i = 0
    while i < len(parts):
        sent = parts[i]
        ws = parts[i+1] if i+1 < len(parts) else ""
        combined = sent + ws
        if combined.strip():
            out.append(combined)
        i += 2
    if not out:
        return [text]
    return out

def _is_likely_verb(token: str) -> bool:
    t = token.strip().lower()
    if not t:
        return False
    if t in _AUXILIARIES:
        return True
    if len(t) > 2 and (t.endswith("ing") or t.endswith("ed") or t.endswith("s")):
        return True
    return False

def _is_stopword(token: str) -> bool:
    return token.strip().lower() in _STOPWORDS

def reorder_words_semantic(sentence: str, seed: Optional[int] = None) -> str:
    if not sentence:
        return sentence
    m = re.match(r'^(.*?)(\s*)$', sentence, flags=re.S)
    core = m.group(1)
    trailing_ws = m.group(2) or ""
    parts = re.split(r'(\s+)', core)
    words = parts[0::2]
    seps = parts[1::2] + [""]

    content_nouns = []
    content_adj = []
    for i, w in enumerate(words):
        ws = w.strip()
        if not ws or _is_stopword(ws) or _is_likely_verb(ws):
            continue
        lw = ws.lower()
        if lw.endswith(("ly","ous","ful","able","ible","ic","ive","less","ish","y")):
            content_adj.append((i, w))
        else:
            content_nouns.append((i, w))

    if not content_nouns and not content_adj:
        return sentence

    rng = random.Random(seed) if seed is not None else random
    noun_tokens = [t for _, t in content_nouns]
    adj_tokens = [t for _, t in content_adj]
    if len(noun_tokens) > 1:
        rng.shuffle(noun_tokens)
    if len(adj_tokens) > 1:
        rng.shuffle(adj_tokens)

    new_words = list(words)
    for (idx, _), tok in zip(content_nouns, noun_tokens):
        new_words[idx] = tok
    for (idx, _), tok in zip(content_adj, adj_tokens):
        new_words[idx] = tok

    out = []
    for w, s in zip(new_words, seps):
        out.append(w); out.append(s)
    return "".join(out) + trailing_ws

def reorder_words_full(sentence: str, seed: Optional[int] = None) -> str:
    if not sentence:
        return sentence
    m = re.match(r'^(.*?)(\s*)$', sentence, flags=re.S)
    core = m.group(1); trailing_ws = m.group(2) or ""
    tokens = re.split(r'(\s+)', core)
    words = tokens[0::2]; seps = tokens[1::2] + [""]

    rng = random.Random(seed) if seed is not None else random
    shuffled = words[:]; rng.shuffle(shuffled)

    out = []
    for w, s in zip(shuffled, seps):
        out.append(w); out.append(s)
    return "".join(out) + trailing_ws

def front_prep_phrase(sentence: str) -> str:
    if not sentence or not sentence.strip():
        return sentence
    s = sentence.rstrip(); trailing_ws = sentence[len(s):] if len(sentence) > len(s) else ""
    punct = ''
    if s and s[-1] in '.!?':
        punct = s[-1]; s_core = s[:-1].rstrip()
    else:
        s_core = s

    pattern = re.compile(rf'^(?P<prefix>.*?\b)(?P<prep>{_PREP_PATTERN}\s+(?:the|a|an)?\s*\b[\w-]+(?:\s+[\w-]+)*)$', re.I)
    m = pattern.match(s_core.strip())
    if not m:
        return sentence

    prefix = m.group('prefix').strip(); prep = m.group('prep').strip()
    if not prefix:
        return sentence

    new_core = f"{prep} {prefix}".strip()
    if sentence and sentence[0].isupper():
        new_core = new_core[0].upper() + new_core[1:]
    return new_core + (punct or '') + trailing_ws

def yoda_transform(sentence: str) -> str:
    if not sentence or not sentence.strip():
        return sentence
    m = re.match(r'^(.*?)(\s*)$', sentence, flags=re.S)
    core = m.group(1); trailing_ws = m.group(2) or ""
    punct = ''
    if core and core[-1] in '.!?':
        punct = core[-1]; core = core[:-1].rstrip()

    prep_pattern = re.compile(rf'(?P<prefix>.*?\b)(?P<prep>{_PREP_PATTERN}\s+(?:the|a|an)?\s*\b[\w-]+(?:\s+[\w-]+)*)$', re.I)
    mprep = prep_pattern.match(core.strip())
    if mprep:
        prefix = mprep.group('prefix').strip(); prep = mprep.group('prep').strip()
        if prefix:
            new_core = f"{prep}, {prefix}"
            if sentence and sentence[0].isupper():
                new_core = new_core[0].upper() + new_core[1:]
            return new_core + (punct or '') + trailing_ws

    parts = re.split(r'(\s+)', core)
    words = parts[0::2]; seps = parts[1::2] + [""]

    n = len(words)
    if n >= 3:
        verb_idx = None
        for i, w in enumerate(words):
            if _is_likely_verb(w):
                verb_idx = i; break
        if verb_idx is None and n >= 2:
            verb_idx = 1
        if verb_idx is not None and 0 < verb_idx < n-1:
            subj = "".join([w + s for w, s in zip(words[:verb_idx], seps[:verb_idx])]).strip()
            verb = words[verb_idx]
            obj = "".join([w + s for w, s in zip(words[verb_idx+1:], seps[verb_idx+1:])]).strip()
            if obj and subj:
                yoda_core = f"{obj}, {verb}, {subj}"
                if sentence and sentence[0].isupper():
                    yoda_core = yoda_core[0].upper() + yoda_core[1:]
                return yoda_core + (punct or '') + trailing_ws

    return sentence

def select_file_dialog(prompt_text: str = "Select a file") -> Optional[str]:
    """
    Try to open a GUI file picker (Tkinter). If Tkinter is not available or
    fails, fall back to asking for a path on the console.
    Returns the selected file path or None if cancelled.
    """
    # Try GUI file dialog
    if _tk and _filedialog:
        try:
            root = _tk.Tk()
            root.withdraw()
            # On some platforms, forcing topmost helps the dialog appear above other windows
            try:
                root.attributes("-topmost", True)
            except Exception:
                pass
            path = _filedialog.askopenfilename(title=prompt_text)
            root.destroy()
            if path:
                return path
        except Exception:
            # fall through to console fallback
            pass

    # Console fallback
    try:
        print("Enter file path (or leave blank to cancel):")
        path = input().strip()
        return path if path else None
    except (EOFError, KeyboardInterrupt):
        return None

def prompt_for_save_path(default_name: str = "generation.txt") -> Optional[str]:
    """
    Ask the user where to save the current generation.
    Try GUI save dialog first (if available), otherwise ask on console.
    Returns the chosen path or None if cancelled.
    """
    # Try GUI save dialog
    if _tk and _filedialog:
        try:
            root = _tk.Tk()
            root.withdraw()
            try:
                root.attributes("-topmost", True)
            except Exception:
                pass
            path = _filedialog.asksaveasfilename(title="Save generation as", initialfile=default_name,
                                                 defaultextension=".txt",
                                                 filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
            root.destroy()
            if path:
                return path
        except Exception:
            pass

    # Console fallback
    try:
        print(f"Enter path to save file (default: {default_name}). Leave blank to cancel:")
        path = input().strip()
        if not path:
            return None
        return path
    except (EOFError, KeyboardInterrupt):
        return None

def prompt_for_text() -> Optional[str]:
    print("Paste text. End with an empty line.")
    lines = []
    try:
        while True:
            line = input()
            if line == "":
                break
            lines.append(line)
    except (EOFError, KeyboardInterrupt):
        return None
    return "\n".join(lines)

# --- Datamuse helpers (cached) ---
@lru_cache(maxsize=10000)
def _query_datamuse_synonyms_cached(word: str, max_results: int = 10):
    if not word or not word.strip():
        return []
    q = {"rel_syn": word, "max": str(max_results)}
    url = _DATAMUSE_BASE + "?" + urllib.parse.urlencode(q)
    try:
        with urllib.request.urlopen(url, timeout=2.0) as resp:
            raw = resp.read().decode("utf-8")
            data = json.loads(raw)
            return [item.get("word") for item in data if item.get("word")]
    except Exception:
        return []

def choose_synonym_datamuse(word: str, rng: Optional[random.Random] = None):
    rng = rng or random
    candidates = _query_datamuse_synonyms_cached(word.lower())
    candidates = [c for c in candidates if " " not in c and c.lower() != word.lower()]
    if not candidates:
        return None
    choice = rng.choice(candidates)
    if word.istitle():
        return choice.capitalize()
    if word.isupper():
        return choice.upper()
    return choice

def process_text_once(text: str, args) -> str:
    sentences = regex_split_keep_ws(text)
    out = []
    for s in sentences:
        # Local behavior variables so flags like --paraphrase don't mutate args globally
        word_mode = args.word_mode
        apply_front_prep = getattr(args, "front_prep", False)
        apply_yoda = getattr(args, "yoda", False)

        # If paraphrase mode requested, prefer meaning-preserving semantic shuffle,
        # ensure front-prep is applied, and disable Yoda punctuation transform.
        if getattr(args, "paraphrase", False):
            word_mode = "semantic"
            apply_front_prep = True
            apply_yoda = False

        if word_mode == "shuffle" and getattr(args, "preserve_meaning", False):
            word_mode = "semantic"

        if word_mode == "semantic":
            s2 = reorder_words_semantic(s, seed=args.seed)
        elif word_mode == "shuffle":
            s2 = reorder_words_full(s, seed=args.seed)
        elif word_mode == "reverse":
            m = re.match(r'^(.*?)(\s*)$', s, flags=re.S)
            core = m.group(1); trailing_ws = m.group(2) or ""
            tokens = re.split(r'(\s+)', core)
            words = tokens[0::2]; seps = tokens[1::2] + [""]
            rev = list(reversed(words))
            parts = []
            for w, sep in zip(rev, seps):
                parts.append(w); parts.append(sep)
            s2 = "".join(parts) + trailing_ws
        else:
            s2 = s

        if apply_front_prep:
            s2 = front_prep_phrase(s2)
        # Only apply Yoda transform if explicitly enabled and not in paraphrase mode
        if apply_yoda:
            s2 = yoda_transform(s2)

        # --- Yogglre synonym replacement (Datamuse, pip-free) ---
        if getattr(args, "yogglre", False) and getattr(args, "yogglre_prob", 0.0) > 0.0:
            tokens = re.split(r'(\s+)', s2)
            words = tokens[0::2]; seps = tokens[1::2] + [""]
            rng = random.Random(args.seed) if getattr(args, "seed", None) is not None else random
            new_words = []
            for w in words:
                # skip empty, punctuation-only, stopwords, auxiliaries, digits
                if not w.strip() or _is_stopword(w) or _is_likely_verb(w) or w.strip().isdigit():
                    new_words.append(w)
                    continue
                # probability check
                prob = getattr(args, "yogglre_prob", 0.0)
                if rng.random() > max(0.0, min(1.0, prob)):
                    new_words.append(w)
                    continue
                syn = choose_synonym_datamuse(w, rng)
                if syn is None:
                    # tiny polite pause on misses (cache reduces calls)
                    time.sleep(0.03)
                    new_words.append(w)
                else:
                    new_words.append(syn)
            parts = []
            for w, s_ in zip(new_words, seps):
                parts.append(w); parts.append(s_)
            s2 = "".join(parts) + (re.match(r'^(.*?)(\s*)$', s2, flags=re.S).group(2) or "")

        out.append(s2)
    return "".join(out)

def process_text(text: str, args) -> str:
    return process_text_once(text, args)

def prompt_action() -> str:
    try:
        while True:
            resp = input("\nChoose: [r]epeat, [n]ew text, [f]lags, [l]ist options, [s]peak, [status], [save], [stop], or [q]uit: ").strip().lower()
            if resp in ("r", "repeat"):
                return "repeat"
            if resp in ("n", "new"):
                return "new"
            if resp in ("f", "flags"):
                return "flags"
            if resp in ("l", "list", "options"):
                return "list"
            if resp in ("s", "speak"):
                return "speak"
            if resp in ("status",):
                return "status"
            if resp in ("save", "w"):
                return "save"
            if resp in ("stop",):
                return "stop"
            if resp in ("q", "quit", "exit"):
                return "exit"
            print("Please enter 'r', 'n', 'f', 'l', 's', 'status', 'save', 'stop', or 'q'.")
    except (EOFError, KeyboardInterrupt):
        return "exit"

def prompt_for_flags(parser: argparse.ArgumentParser) -> Optional[List[str]]:
    """
    Ask the user to enter flags as a single line, parse into argv-style list.
    Special inputs:
      - '--help', 'help', '?', 'list' -> print available flag options (parser help)
      - blank line -> show help (instead of cancelling)
      - 'select-file' or 'browse' -> open file picker and insert chosen path
    Returns list of tokens or None on cancel/EOF.
    """
    try:
        line = input("Enter flags (e.g., --no-yoda --word-mode shuffle --seed 42), or type 'help' to show options:\n").strip()
        if not line:
            # show help when user submits blank
            print("\nAvailable flag options:\n")
            print(parser.format_help())
            return None
        low = line.strip().lower()
        if low in ("--help", "help", "?", "list"):
            print("\nAvailable flag options:\n")
            print(parser.format_help())
            return None
        try:
            tokens = shlex.split(line)
        except ValueError as e:
            print(f"Error parsing flags: {e}")
            print("\nAvailable flag options:\n")
            print(parser.format_help())
            return None

        # Replace special tokens 'select-file' or 'browse' with a placeholder
        tokens = [t if t.lower() not in ("select-file", "browse") else "__SELECT_FILE__" for t in tokens]

        # If --file appears without a following value, insert a placeholder
        i = 0
        while i < len(tokens):
            t = tokens[i]
            if t == "--file":
                # If next token is missing or looks like another flag, insert placeholder
                if i + 1 >= len(tokens) or tokens[i + 1].startswith("--"):
                    tokens.insert(i + 1, "__SELECT_FILE__")
                    i += 2
                    continue
            i += 1

        # Resolve any placeholders by opening file dialog / console prompt
        resolved = []
        for t in tokens:
            if t == "__SELECT_FILE__":
                chosen = select_file_dialog("Choose file for --file")
                if not chosen:
                    print("No file selected. Cancelling flag entry.")
                    return None
                resolved.append(chosen)
            else:
                resolved.append(t)

        return resolved
    except (EOFError, KeyboardInterrupt):
        return None

def apply_provided_flags(current_args, tokens: List[str], parsed_args):
    """
    Update current_args in-place using only the flags actually present in tokens.
    - tokens: raw argv-style list the user entered (after placeholder resolution).
    - parsed_args: argparse.Namespace returned by parse_args(tokens).
    This respects argparse dest naming (dashes -> underscores).
    """
    i = 0
    seen_dests = set()
    while i < len(tokens):
        t = tokens[i]
        if not t.startswith("--"):
            i += 1
            continue
        # strip leading dashes and split --flag=value
        name = t.lstrip("-")
        if "=" in name:
            name, _ = name.split("=", 1)
        # handle --no-flag -> dest is flag (without no-)
        if name.startswith("no-"):
            dest = name[3:]
        else:
            dest = name
        dest = dest.replace("-", "_")
        # record that this dest was explicitly provided
        seen_dests.add(dest)
        # advance: if token was --flag value (no '=') and next token is not a flag, skip it
        if "=" not in t and (i + 1) < len(tokens) and not tokens[i + 1].startswith("--"):
            i += 2
        else:
            i += 1

    # Apply only seen dests from parsed_args to current_args
    for dest in seen_dests:
        if hasattr(parsed_args, dest):
            setattr(current_args, dest, getattr(parsed_args, dest))

def show_current_flags(args_namespace, parser: argparse.ArgumentParser) -> None:
    """
    Print current flag values in a readable form.
    Uses parser._actions to list known options and shows the value from args_namespace.
    """
    print("\nCurrent flag values:\n")
    for action in parser._actions:
        # Skip positional arguments (they have no option_strings)
        if not action.option_strings:
            continue
        # Prefer the long option string if present
        opt = next((s for s in action.option_strings if s.startswith("--")), action.option_strings[0])
        dest = action.dest
        # Some actions (like help) may not map to a value in args_namespace
        val = getattr(args_namespace, dest, None)
        print(f"{opt:20} : {val!r}")
    print()

# --- System TTS helpers (stdlib only) ---
def _chunk_paragraphs(text: str) -> List[str]:
    paras = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]
    if not paras:
        # fallback: split by sentences if no blank-line paragraphs
        sents = [s.strip() for s in re.split(r'(?<=[\.\?\!])\s+', text) if s.strip()]
        return sents if sents else [text.strip()]
    return paras

def _run_subprocess(cmd: List[str]) -> Optional[subprocess.Popen]:
    """
    Start subprocess and return Popen. Keep it non-blocking so caller can wait or terminate.
    """
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return proc
    except Exception:
        return None

def _speak_paragraphs_system(paragraphs: List[str]):
    """
    Internal worker that speaks paragraphs sequentially using available system TTS.
    Honors _tts_stop_event to allow interruption.
    """
    global _tts_process
    system = platform.system()
    for para in paragraphs:
        if _tts_stop_event.is_set():
            break
        if not para:
            continue
        try:
            if system == "Darwin":
                # macOS: say supports passing text as argument
                cmd = ["say", para]
                _tts_process = _run_subprocess(cmd)
                if _tts_process:
                    _tts_process.wait()
                    _tts_process = None
                else:
                    # fallback to blocking run
                    subprocess.run(cmd, check=False)
                if _tts_stop_event.is_set():
                    break
                continue

            if system == "Windows":
                # Windows: use PowerShell and System.Speech.Synthesis.SpeechSynthesizer
                # Escape single quotes by doubling them
                safe = para.replace("'", "''")
                ps = (
                    "Add-Type -AssemblyName System.Speech;"
                    f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                    f"$s.Speak('{safe}');"
                )
                _tts_process = _run_subprocess(["powershell", "-NoProfile", "-Command", ps])
                if _tts_process:
                    _tts_process.wait()
                    _tts_process = None
                else:
                    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=False)
                if _tts_stop_event.is_set():
                    break
                continue

            # Assume Linux/Unix: try spd-say then espeak
            if shutil.which("spd-say"):
                cmd = ["spd-say", para]
                _tts_process = _run_subprocess(cmd)
                if _tts_process:
                    _tts_process.wait()
                    _tts_process = None
                else:
                    subprocess.run(cmd, check=False)
                if _tts_stop_event.is_set():
                    break
                continue
            if shutil.which("espeak"):
                cmd = ["espeak", para]
                _tts_process = _run_subprocess(cmd)
                if _tts_process:
                    _tts_process.wait()
                    _tts_process = None
                else:
                    subprocess.run(cmd, check=False)
                if _tts_stop_event.is_set():
                    break
                continue

            # No known TTS available
            print("No system TTS command found. On macOS `say` is built-in; on Linux install `spd-say` or `espeak`; on Windows PowerShell is used.")
            break
        except Exception as e:
            # If a subprocess fails, print and continue to next paragraph
            print(f"TTS error: {e}")
            _tts_process = None
            continue
    # Clear any process handle and reset stop event at end
    _tts_process = None
    _tts_stop_event.clear()

def speak_text_system(text: str):
    """
    Public entry to speak text using system TTS. Runs paragraphs sequentially
    and can be interrupted by calling stop_speaking().
    """
    global _tts_thread, _tts_stop_event
    if not text or not text.strip():
        print("Nothing to speak.")
        return
    # If a TTS thread is already running, inform user
    if _tts_thread and _tts_thread.is_alive():
        print("Speech is already playing. Use 'stop' to interrupt.")
        return
    paragraphs = _chunk_paragraphs(text)
    _tts_stop_event.clear()
    _tts_thread = threading.Thread(target=_speak_paragraphs_system, args=(paragraphs,), daemon=True)
    _tts_thread.start()

def stop_speaking():
    """
    Signal the TTS worker to stop and terminate any running subprocess.
    """
    global _tts_process, _tts_stop_event
    _tts_stop_event.set()
    try:
        if _tts_process and _tts_process.poll() is None:
            # Try to terminate the subprocess gracefully
            _tts_process.terminate()
            # give it a moment, then kill if still alive
            try:
                _tts_process.wait(timeout=0.5)
            except Exception:
                try:
                    _tts_process.kill()
                except Exception:
                    pass
    except Exception:
        pass
    _tts_process = None

def main():
    args = parse_args(None)
    parser = get_arg_parser()

    initial_text: Optional[str]
    if args.file:
        try:
            with open(args.file, "r", encoding="utf-8") as f:
                initial_text = f.read()
        except Exception as e:
            print(f"Error reading file: {e}", file=sys.stderr)
            return
    elif args.text:
        initial_text = args.text
    else:
        initial_text = None

    current_text = initial_text
    last_result = ""          # last produced/transformed output
    last_input_text = None    # track which input produced last_result
    printed_last = False      # whether last_result has been printed to stdout

    while True:
        # If we have no current input, prompt for it
        if current_text is None:
            current_text = prompt_for_text()
            if current_text is None:
                print("\nNo input. Exiting.")
                return

        # Only (re)generate when input changed or we have no last_result
        if last_input_text != current_text or not last_result:
            # produce new result and update tracking variables
            result = process_text(current_text, args)
            last_result = result
            last_input_text = current_text
            printed_last = False
        else:
            result = last_result

        # Print the result only if it hasn't been printed yet for this input
        if not printed_last:
            print(result, end="")
            printed_last = True

        action = prompt_action()
        if action == "repeat":
            # Regenerate using a fresh random seed so output changes on each repeat.
            # Create a shallow copy of args and give it a new random seed.
            temp_args = argparse.Namespace(**vars(args))
            temp_args.seed = random.randint(0, 2**31 - 1)
            result = process_text(current_text, temp_args)
            last_result = result
            last_input_text = current_text
            # print regenerated result
            print(result, end="")
            printed_last = True
            continue
        if action == "new":
            # clear current_text so next loop will prompt for new input
            current_text = None
            continue
        if action == "list":
            print("\nAvailable flag options:\n")
            print(parser.format_help())
            continue
        if action == "flags":
            tokens = prompt_for_flags(parser)
            if tokens is None:
                continue
            try:
                new_args = parse_args(tokens)
            except SystemExit:
                print("Invalid flags. Showing available options:\n")
                print(parser.format_help())
                continue

            # If user provided a file or text in flags, update current_text accordingly
            if getattr(new_args, "file", None):
                try:
                    with open(new_args.file, "r", encoding="utf-8") as f:
                        current_text = f.read()
                except Exception as e:
                    print(f"Error reading file: {e}", file=sys.stderr)
            elif getattr(new_args, "text", None):
                current_text = new_args.text

            # Merge only the flags the user actually provided so other flags stay as-is
            apply_provided_flags(args, tokens, new_args)
            # After applying flags, ensure seed is an int (argparse already does this)
            continue
        if action == "speak":
            speak_text_system(last_result or "")
            continue
        if action == "stop":
            stop_speaking()
            continue
        if action == "status":
            show_current_flags(args, parser)
            continue
        if action == "save":
            if not last_result:
                print("No generated text available to save.")
                continue
            # Suggest a default filename based on timestamp or simple name
            default_name = "generation.txt"
            path = prompt_for_save_path(default_name=default_name)
            if not path:
                print("Save cancelled.")
                continue
            try:
                # Ensure parent directory exists for convenience
                parent = os.path.dirname(path)
                if parent and not os.path.exists(parent):
                    try:
                        os.makedirs(parent, exist_ok=True)
                    except Exception:
                        pass
                with open(path, "w", encoding="utf-8") as f:
                    f.write(last_result)
                print(f"Saved generation to: {path}")
            except Exception as e:
                print(f"Error saving file: {e}", file=sys.stderr)
            continue
        if action == "exit":
            # Ensure any TTS is stopped before exiting
            stop_speaking()
            print("\nGoodbye.")
            return

if __name__ == "__main__":
    main()
