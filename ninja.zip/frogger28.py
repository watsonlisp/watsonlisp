# frogger_tk.py
# Frogger (tkinter) — frog player drawn with legs; cars run at half their previous speed
# Movement plays a gentle "sleep" sound when arrow keys move the frog.

import tkinter as tk
import random
import time
import sys
import subprocess

WIDTH, HEIGHT = 640, 640
GRID = 32
PLAYER_SIZE = GRID - 6
FPS = 60
START_LIVES = 6
GOALS = 5

# Visual parameters
CAR_LENGTH = GRID * 2
CAR_HEIGHT = GRID - 10
CAR_COLOR = "#d62828"
CAR_ROOF = "#ff8b8b"
WHEEL_COLOR = "#222222"
LOG_COLOR = "#8b5a2b"
FROG_GREEN = "#39b54a"
FROG_DARK = "#1e7a3a"
EYE_WHITE = "#ffffff"
EYE_PUPIL = "#222222"
BG = "#0b6623"
RIVER = "#2a7fb2"
ROAD = "#444444"
GOAL_EMPTY = "#f2d049"
GOAL_FILLED = "#8fe39a"
TEXT = "#ffffff"

# Fixed log length
LOG_LENGTH = GRID * 3
LOG_HEIGHT = GRID - 8

# level speed multiplier per level
LEVEL_SPEED_STEP = 0.10

# Spawn tuning
ROAD_SPAWN_MULTIPLIER = 0
MIN_GAP_MULTIPLIER = 5.0
MAX_TOTAL_LOGS = 25

# SOUND CONFIG
# Toggle sound on/off
SOUND_ENABLED = True
# "sleep" sound name (semantic only — actual playback chooses a suitable system sound)
SOUND_NAME = "sleep"

def play_sleep_sound():
    if not SOUND_ENABLED:
        return
    try:
        # Windows: use winsound to play a friendly system sound asynchronously
        if sys.platform.startswith("win"):
            import winsound
            # Try a soft system alias; fallback to default beep if that fails
            try:
                winsound.PlaySound("SystemAsterisk", winsound.SND_ALIAS | winsound.SND_ASYNC)
                return
            except Exception:
                try:
                    winsound.MessageBeep(winsound.MB_OK)
                    return
                except Exception:
                    pass

        # macOS: use afplay to play a built-in gentle sound (Glass chosen as a soft tone)
        if sys.platform == "darwin":
            # Common built-in sounds: /System/Library/Sounds/Glass.aiff, Submarine.aiff, Basso.aiff
            sound_paths = [
                "/System/Library/Sounds/Glass.aiff",
                "/System/Library/Sounds/Submarine.aiff",
                "/System/Library/Sounds/Basso.aiff"
            ]
            for p in sound_paths:
                try:
                    subprocess.Popen(["afplay", p])
                    return
                except Exception:
                    continue

        # Linux / other: try common audio players with a freedesktop sound
        # Try paplay (PulseAudio) then aplay then play (sox)
        linux_candidates = [
            (["paplay", "/usr/share/sounds/freedesktop/stereo/complete.oga"], False),
            (["paplay", "/usr/share/sounds/freedesktop/stereo/phone-incoming-call.oga"], False),
            (["aplay", "/usr/share/sounds/alsa/Front_Center.wav"], False),
            (["play", "-q", "/usr/share/sounds/alsa/Front_Center.wav"], False)
        ]
        for cmd, _ in linux_candidates:
            try:
                subprocess.Popen(cmd)
                return
            except Exception:
                continue

    except Exception:
        pass

    # final fallback: try the Tk bell
    try:
        # if we have a default root, ring its bell; otherwise skip
        if tk._default_root:
            tk._default_root.bell()
    except Exception:
        pass

class Moving:
    def __init__(self, canvas, x, y, w, h, color, vx, kind="generic"):
        self.canvas = canvas
        self.vx = vx
        self.w = w
        self.h = h
        self.kind = kind
        self.parts = []
        if kind == "car":
            self._create_car(x, y, w, h, color)
        elif kind == "log":
            rect = canvas.create_rectangle(x, y, x+w, y+h, fill=color, width=0)
            knot1 = canvas.create_oval(x + int(w*0.12), y + int(h*0.2), x + int(w*0.26), y + int(h*0.6), fill="#6e3f1a", width=0)
            knot2 = canvas.create_oval(x + int(w*0.6), y + int(h*0.25), x + int(w*0.74), y + int(h*0.65), fill="#6e3f1a", width=0)
            self.parts.extend([rect, knot1, knot2])
        else:
            rect = canvas.create_rectangle(x, y, x+w, y+h, fill=color, width=0)
            self.parts.append(rect)

    def _create_car(self, x, y, w, h, color):
        body_h = int(h * 0.7)
        roof_h = h - body_h
        body = self.canvas.create_rectangle(x, y + roof_h, x + w, y + h, fill=color, width=0)
        roof = self.canvas.create_rectangle(x + int(w*0.15), y, x + int(w*0.85), y + roof_h, fill=CAR_ROOF, width=0)
        win_w = int(w * 0.22)
        win_h = max(4, int(roof_h * 0.6))
        win_y = y + int(roof_h*0.2)
        left_win = self.canvas.create_rectangle(x + int(w*0.2), win_y, x + int(w*0.2) + win_w, win_y + win_h, fill="#ffffff", width=0)
        right_win = self.canvas.create_rectangle(x + int(w*0.58), win_y, x + int(w*0.58) + win_w, win_y + win_h, fill="#ffffff", width=0)
        wheel_r = max(4, int(h * 0.2))
        left_wheel = self.canvas.create_oval(x + int(w*0.12), y + h - wheel_r//1.5, x + int(w*0.12) + wheel_r, y + h + wheel_r//1.5, fill=WHEEL_COLOR, width=0)
        right_wheel = self.canvas.create_oval(x + int(w*0.72), y + h - wheel_r//1.5, x + int(w*0.72) + wheel_r, y + h + wheel_r//1.5, fill=WHEEL_COLOR, width=0)
        self.parts.extend([body, roof, left_win, right_win, left_wheel, right_wheel])

    def coords(self):
        boxes = [self.canvas.bbox(p) for p in self.parts]
        boxes = [b for b in boxes if b]
        if not boxes:
            return (0,0,0,0)
        xs = [b[0] for b in boxes] + [b[2] for b in boxes]
        ys = [b[1] for b in boxes] + [b[3] for b in boxes]
        return (min(xs), min(ys), max(xs), max(ys))

    def move(self, dx, dy):
        for p in self.parts:
            self.canvas.move(p, dx, dy)

    def update(self, dt):
        dx = self.vx * dt
        self.move(dx, 0)
        x1, y1, x2, y2 = self.coords()
        if self.vx > 0 and x1 > WIDTH + 200:
            self.move(- (WIDTH + 400 + self.w), 0)
        elif self.vx < 0 and x2 < -200:
            self.move((WIDTH + 400 + self.w), 0)

    def bbox(self):
        return self.canvas.bbox(self.parts[0]) if self.parts else None

    def destroy(self):
        for p in self.parts:
            try:
                self.canvas.delete(p)
            except Exception:
                pass

class Player:
    def __init__(self, canvas, x, y):
        self.canvas = canvas
        self.start = (x, y)
        self.parts = []
        self._create_frog(x, y)
        self.on_log = None
        self.lives = START_LIVES
        self.score = 0

    def _create_frog(self, x, y):
        # body (slightly wider than PLAYER_SIZE)
        bw = PLAYER_SIZE + 6
        bh = PLAYER_SIZE - 4
        bx = x
        by = y
        body = self.canvas.create_oval(bx, by, bx + bw, by + bh, fill=FROG_GREEN, outline=FROG_DARK, width=2)
        self.parts.append(body)

        # back legs (two arcs / ovals behind body)
        leg_h = int(bh * 0.6)
        leg_w = int(bw * 0.5)
        back_left = self.canvas.create_oval(bx - int(leg_w*0.6), by + int(bh*0.4), bx - int(leg_w*0.2), by + int(bh*0.4) + leg_h, fill=FROG_GREEN, outline=FROG_DARK, width=2)
        back_right = self.canvas.create_oval(bx + bw - int(leg_w*0.4), by + int(bh*0.4), bx + bw + int(leg_w*0.0), by + int(bh*0.4) + leg_h, fill=FROG_GREEN, outline=FROG_DARK, width=2)
        self.parts.extend([back_left, back_right])

        # front legs (small polygons / ovals in front)
        fl_w = int(bw * 0.25)
        fl_h = int(bh * 0.35)
        front_left = self.canvas.create_oval(bx + int(bw*0.08), by + bh - fl_h//2, bx + int(bw*0.08) + fl_w, by + bh + fl_h//2, fill=FROG_GREEN, outline=FROG_DARK, width=2)
        front_right = self.canvas.create_oval(bx + int(bw*0.62), by + bh - fl_h//2, bx + int(bw*0.62) + fl_w, by + bh + fl_h//2, fill=FROG_GREEN, outline=FROG_DARK, width=2)
        self.parts.extend([front_left, front_right])

        # eyes (two small white ovals with dark pupils)
        eye_w = max(6, int(bw * 0.28))
        eye_h = max(6, int(bh * 0.28))
        eye_offset_y = -int(eye_h*0.4)
        left_eye = self.canvas.create_oval(bx + int(bw*0.12), by + eye_offset_y, bx + int(bw*0.12) + eye_w, by + eye_offset_y + eye_h, fill=EYE_WHITE, outline=FROG_DARK, width=1)
        right_eye = self.canvas.create_oval(bx + int(bw*0.58), by + eye_offset_y, bx + int(bw*0.58) + eye_w, by + eye_offset_y + eye_h, fill=EYE_WHITE, outline=FROG_DARK, width=1)
        pupil_w = max(3, int(eye_w * 0.4))
        pupil_h = max(3, int(eye_h * 0.4))
        left_pupil = self.canvas.create_oval(bx + int(bw*0.12) + eye_w//2 - pupil_w//2, by + eye_offset_y + eye_h//2 - pupil_h//2, bx + int(bw*0.12) + eye_w//2 + pupil_w//2, by + eye_offset_y + eye_h//2 + pupil_h//2, fill=EYE_PUPIL, width=0)
        right_pupil = self.canvas.create_oval(bx + int(bw*0.58) + eye_w//2 - pupil_w//2, by + eye_offset_y + eye_h//2 - pupil_h//2, bx + int(bw*0.58) + eye_w//2 + pupil_w//2, by + eye_offset_y + eye_h//2 + pupil_h//2, fill=EYE_PUPIL, width=0)
        self.parts.extend([left_eye, right_eye, left_pupil, right_pupil])

    def bbox(self):
        boxes = [self.canvas.bbox(p) for p in self.parts]
        boxes = [b for b in boxes if b]
        if not boxes:
            return (0,0,0,0)
        xs = [b[0] for b in boxes] + [b[2] for b in boxes]
        ys = [b[1] for b in boxes] + [b[3] for b in boxes]
        return (min(xs), min(ys), max(xs), max(ys))

    def move(self, dx, dy):
        for p in self.parts:
            self.canvas.move(p, dx, dy)

    def set_pos(self, x, y):
        x1, y1, x2, y2 = self.bbox()
        self.move(x - x1, y - y1)

    def move_grid(self, dx, dy):
        x1, y1, x2, y2 = self.bbox()
        nx = x1 + dx * GRID
        ny = y1 + dy * GRID
        nx = max(0, min(WIDTH - (x2-x1), nx))
        ny = max(0, min(HEIGHT - (y2-y1), ny))
        self.set_pos(nx, ny)

    def reset(self):
        self.set_pos(*self.start)
        self.on_log = None

class FroggerApp:
    def __init__(self, root):
        self.root = root
        root.title("Frogger (tkinter, frog player)")
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg=BG)
        self.canvas.pack()
        self.running = True
        self.paused = False
        self.last_time = time.time()
        self.entities = []
        self.lanes = []
        self.goal_slots = []
        self.level = 1
        # sound toggle for movement
        self.SOUND_ENABLED = True
        self.init_world()
        self.bind_keys()
        self.loop()

    def init_world(self):
        self.canvas.delete("all")
        self.entities = []
        self.lanes = []
        self.goal_slots = []

        self.canvas.create_rectangle(0, 0, WIDTH, 64, fill="#0b3a66", width=0)
        slot_w = WIDTH // GOALS
        for i in range(GOALS):
            x = i * slot_w + 8
            slot = self.canvas.create_rectangle(x, 8, x + slot_w - 16, 48, fill=GOAL_EMPTY, outline="#000")
            self.goal_slots.append({"id": slot, "filled": False})

        lane_y = 64 + 20

        # river rows (logs) - base speeds stored; logs now half as fast
        river_rows = 3
        for i in range(river_rows):
            y = lane_y + i * (GRID + 6)
            direction = 1 if i % 2 == 0 else -1
            # base speed halved so logs move at 50% of previous speed
            base_speed = (60 + 20 * i) * 0.5
            spawn = 1800 - i * 250
            self.lanes.append({"y": y, "type": "log", "base_speed": base_speed, "speed": base_speed, "dir": direction, "spawn": spawn, "last_spawn": 0, "height": GRID})
        lane_y += river_rows * (GRID + 6) + 12

        lane_y += GRID * 2

        # road rows (cars) — base speeds halved here so cars run at half speed
        road_rows = 4
        for i in range(road_rows):
            y = lane_y + i * (GRID + 8)
            direction = -1 if i % 2 == 0 else 1
            # compute base speed then halve it
            base_speed = (80 + 30 * i) * 0.5
            base_spawn = 1400 - i * 180
            spawn = max(300, int(base_spawn * ROAD_SPAWN_MULTIPLIER))
            self.lanes.append({
                "y": y,
                "type": "car",
                "base_speed": base_speed,
                "speed": base_speed,
                "dir": direction,
                "spawn": spawn,
                "last_spawn": 0,
                "height": CAR_HEIGHT,
                "width": CAR_LENGTH
            })
        lane_y += road_rows * (GRID + 8) + 16

        # river background extents
        river_top = self.lanes[0]["y"] - 6
        river_bottom = [l for l in self.lanes if l["type"] == "log"][-1]["y"] + GRID + 6
        self.canvas.create_rectangle(0, river_top, WIDTH, river_bottom, fill=RIVER, width=0)

        road_lanes = [l for l in self.lanes if l["type"] == "car"]
        road_top = road_lanes[0]["y"] - 6
        road_bottom = road_lanes[-1]["y"] + GRID + 6
        self.canvas.create_rectangle(0, road_top, WIDTH, road_bottom, fill=ROAD, width=0)

        sx = WIDTH // 2 - PLAYER_SIZE // 2
        sy = HEIGHT - GRID - 8
        self.player = Player(self.canvas, sx, sy)

        self.hud_text = self.canvas.create_text(8, HEIGHT - 18, anchor="w", fill=TEXT, text="")
        self.level_text = self.canvas.create_text(WIDTH - 8, HEIGHT - 18, anchor="e", fill=TEXT, text=f"Level: {self.level}")
        self.update_hud()

    def bind_keys(self):
        self.root.bind("<KeyPress>", self.on_key)

    def on_key(self, event):
        if event.keysym == "Escape":
            self.root.quit()
            return

        # Movement allowed only when not paused
        if event.keysym in ("Up", "Down", "Left", "Right") and not self.paused:
            moved = False
            if event.keysym == "Up":
                self.player.move_grid(0, -1)
                moved = True
            elif event.keysym == "Down":
                self.player.move_grid(0, 1)
                moved = True
            elif event.keysym == "Left":
                self.player.move_grid(-1, 0)
                moved = True
            elif event.keysym == "Right":
                self.player.move_grid(1, 0)
                moved = True

            # play the "sleep" sound when the player moves
            if moved and getattr(self, "SOUND_ENABLED", True):
                try:
                    play_sleep_sound()
                except Exception:
                    try:
                        self.root.bell()
                    except Exception:
                        pass

            self.check_goal_collision()
            return

        # Restart (always allowed, including after Game Over)
        if event.keysym in ("r", "R"):
            # clear any gameover messages
            try:
                self.canvas.delete("gameover")
            except Exception:
                pass
            # reset core state
            self.level = 1
            # reset player stats
            # if player hasn't been created yet, init_world will handle it
            if hasattr(self, "player"):
                self.player.lives = START_LIVES
                self.player.score = 0
            # reset lane speeds to base (if lanes exist)
            for l in self.lanes:
                l["speed"] = l.get("base_speed", l.get("speed", 0))
            # unpause and reinitialize world
            self.paused = False
            self.init_world()
            return

        # Pause toggle (allowed at any time)
        if event.keysym in ("p", "P"):
            self.paused = not self.paused
            return

    def _lane_cars(self, lane_y):
        res = []
        for ent in self.entities:
            if ent.kind != "car":
                continue
            ex1, ey1, ex2, ey2 = ent.coords()
            cy = (ey1 + ey2) / 2.0
            if abs(cy - (lane_y + ent.h / 2.0)) < GRID * 0.75:
                res.append(ent)
        return res

    def _lane_logs(self, lane_y):
        res = []
        for ent in self.entities:
            if ent.kind != "log":
                continue
            ex1, ey1, ex2, ey2 = ent.coords()
            cy = (ey1 + ey2) / 2.0
            if abs(cy - (lane_y + ent.h / 2.0)) < GRID * 0.75:
                res.append(ent)
        return res

    def _total_logs(self):
        return sum(1 for e in self.entities if e.kind == "log")

    def _can_spawn_car(self, lane, spawn_x):
        min_gap = int(CAR_LENGTH * MIN_GAP_MULTIPLIER)
        lane_y = lane["y"]
        for car in self._lane_cars(lane_y):
            ex1, ey1, ex2, ey2 = car.coords()
            if spawn_x < 0:
                dist = ex2 - spawn_x
            else:
                dist = spawn_x - ex1
            if abs(dist) < min_gap:
                return False
        return True

    def spawn_for_lane(self, lane):
        y = lane["y"]
        if lane["type"] == "car":
            w = lane.get("width", CAR_LENGTH)
            h = lane.get("height", CAR_HEIGHT)
            dir = lane["dir"]
            speed = lane["speed"]
            if dir > 0:
                spawn_x = -w - random.randint(0, 200)
            else:
                spawn_x = WIDTH + random.randint(0, 200)
            if not self._can_spawn_car(lane, spawn_x):
                return
            m = Moving(self.canvas, spawn_x, y, w, h, CAR_COLOR, dir * speed, kind="car")
            self.entities.append(m)
        elif lane["type"] == "log":
            # Do not spawn more logs if river is full.
            if self._total_logs() >= MAX_TOTAL_LOGS:
                return
            existing = self._lane_logs(y)
            if "log_max" in lane:
                max_logs = lane["log_max"]
            else:
                approx_spacing = LOG_LENGTH * 1.5
                max_logs = max(1, int(WIDTH // approx_spacing))
            if len(existing) >= max_logs:
                return
            w = LOG_LENGTH
            h = lane.get("height", LOG_HEIGHT)
            dir = lane["dir"]
            speed = lane["speed"]
            if dir > 0:
                x = -w - random.randint(0, 400)
            else:
                x = WIDTH + random.randint(0, 400)
            m = Moving(self.canvas, x, y, w, h, LOG_COLOR, dir * speed, kind="log")
            self.entities.append(m)

    def update_entities(self, dt):
        for ent in list(self.entities):
            ent.update(dt)
            x1, y1, x2, y2 = ent.coords()
            if x2 < -1000 or x1 > WIDTH + 1000:
                ent.destroy()
                try:
                    self.entities.remove(ent)
                except ValueError:
                    pass

    def check_collisions(self):
        px1, py1, px2, py2 = self.player.bbox()
        river_lanes = [l for l in self.lanes if l["type"] == "log"]
        if river_lanes:
            river_top = river_lanes[0]["y"]
            river_bottom = river_lanes[-1]["y"] + GRID
        else:
            river_top = river_bottom = -1

        # clear any previous log reference; we'll set it again if we detect one below
        self.player.on_log = None

        for ent in self.entities:
            ex1, ey1, ex2, ey2 = ent.coords()
            if not (px2 < ex1 or px1 > ex2 or py2 < ey1 or py1 > ey2):
                if ent.kind == "car":
                    self.player_die()
                    return
                elif ent.kind == "log":
                    # frog is standing on a log: record the log and bring the frog to the front
                    self.player.on_log = ent
                    # raise all frog parts so frog visually dominates the log
                    for p in self.player.parts:
                        try:
                            self.canvas.tag_raise(p)
                        except Exception:
                            pass

        if river_top <= py1 <= river_bottom or river_top <= py2 <= river_bottom:
            if not self.player.on_log:
                self.player_die()
                return
            else:
                self.player.move(self.player.on_log.vx * (1.0 / FPS), 0)
                px1, py1, px2, py2 = self.player.bbox()
                if px2 < 0 or px1 > WIDTH:
                    self.player_die()
                    return

    def check_goal_collision(self):
        for slot in self.goal_slots:
            x1, y1, x2, y2 = self.canvas.coords(slot["id"])
            px1, py1, px2, py2 = self.player.bbox()
            if not slot["filled"]:
                if not (px2 < x1 or px1 > x2 or py2 < y1 or py1 > y2):
                    slot["filled"] = True
                    self.canvas.itemconfig(slot["id"], fill=GOAL_FILLED)
                    self.player.score += 200
                    self.player.reset()
                    if all(s["filled"] for s in self.goal_slots):
                        self.player.score += 1000
                        self.advance_level()
                    self.update_hud()
                    break

    def advance_level(self):
        self.level += 1
        for s in self.goal_slots:
            s["filled"] = False
            self.canvas.itemconfig(s["id"], fill=GOAL_EMPTY)
        for l in self.lanes:
            base = l.get("base_speed", l.get("speed", 0))
            l["speed"] = base * (1.0 + LEVEL_SPEED_STEP * (self.level - 1))
        self.canvas.itemconfig(self.level_text, text=f"Level: {self.level}")

    def player_die(self):
        self.player.lives -= 1
        self.update_hud()
        if self.player.lives <= 0:
            self.game_over()
        else:
            self.player.reset()

    def game_over(self):
        self.paused = True
        self.canvas.create_text(WIDTH//2, HEIGHT//2 - 10, text="GAME OVER", fill=TEXT, font=("Helvetica", 28), tags="gameover")
        self.canvas.create_text(WIDTH//2, HEIGHT//2 + 24, text="Press R to restart", fill=TEXT, font=("Helvetica", 14), tags="gameover")

    def update_hud(self):
        self.canvas.itemconfig(self.hud_text, text=f"Score: {self.player.score}    Lives: {self.player.lives}")

    def loop(self):
        now = time.time()
        dt = now - self.last_time
        self.last_time = now
        if not self.paused:
            for lane in self.lanes:
                lane["last_spawn"] += int(dt * 1000)
                if lane.get("spawn") and lane["last_spawn"] > lane["spawn"]:
                    self.spawn_for_lane(lane)
                    lane["last_spawn"] = random.randint(0, int(lane["spawn"] * 0.5))
                elif lane["type"] == "log" and lane.get("spawn") and lane["last_spawn"] > lane["spawn"]:
                    self.spawn_for_lane(lane)
                    lane["last_spawn"] = random.randint(0, int(lane["spawn"] * 0.5))
            self.update_entities(dt)
            self.check_collisions()

        self.update_hud()
        if self.running:
            self.root.after(int(1000 / FPS), self.loop)

def main():
    root = tk.Tk()
    app = FroggerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
