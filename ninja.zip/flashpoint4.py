import tkinter as tk
from tkinter import filedialog, simpledialog, font
import re
import random

def split_into_words(text):
    return re.findall(r"\b[\w'-]+\b", text)

class OneWordFlasher:
    def __init__(self, root):
        self.root = root
        root.title("One Word Flasher")
        root.configure(bg="black")
        root.geometry("1000x600")
        root.bind("<Escape>", lambda e: root.quit())

        self.original_text = ""
        self.words = []
        self.index = 0
        self.running = False
        self.paused = False
        self.show_job = None
        self.clear_job = None

        # Timing (ms)
        self.display_ms = 800
        self.gap_ms = 150

        # Font (auto-resize)
        self.base_font_size = 120
        self.display_font = font.Font(family="Helvetica", size=self.base_font_size, weight="bold")
        self.label = tk.Label(root, text="", fg="white", bg="black", font=self.display_font)
        self.label.place(relx=0.5, rely=0.5, anchor="center")

        ctrl = tk.Frame(root, bg="black")
        ctrl.pack(side="bottom", fill="x", pady=8)

        tk.Button(ctrl, text="Type / Paste Text", command=self.type_or_paste).pack(side="left", padx=6)
        tk.Button(ctrl, text="Open File", command=self.open_file).pack(side="left", padx=6)
        tk.Button(ctrl, text="Copy All", command=self.copy_all).pack(side="left", padx=6)
        tk.Button(ctrl, text="Start", command=self.start).pack(side="left", padx=6)
        tk.Button(ctrl, text="Pause", command=self.toggle_pause).pack(side="left", padx=6)
        tk.Button(ctrl, text="Stop", command=self.stop).pack(side="left", padx=6)
        tk.Button(ctrl, text="Prev", command=self.prev_word).pack(side="left", padx=6)
        tk.Button(ctrl, text="Next", command=self.next_word_manual).pack(side="left", padx=6)
        tk.Button(ctrl, text="Fullscreen", command=self.toggle_fullscreen).pack(side="left", padx=6)

        tk.Label(ctrl, text="Display ms", bg="black", fg="white").pack(side="left", padx=6)
        self.display_entry = tk.Entry(ctrl, width=6)
        self.display_entry.insert(0, str(self.display_ms))
        self.display_entry.pack(side="left", padx=6)

        tk.Label(ctrl, text="Gap ms", bg="black", fg="white").pack(side="left", padx=6)
        self.gap_entry = tk.Entry(ctrl, width=6)
        self.gap_entry.insert(0, str(self.gap_ms))
        self.gap_entry.pack(side="left", padx=6)

        self.random_var = tk.IntVar(value=0)
        tk.Checkbutton(ctrl, text="Random order", variable=self.random_var, bg="black", fg="white", selectcolor="black").pack(side="left", padx=8)

        self.progress_label = tk.Label(ctrl, text="", bg="black", fg="white")
        self.progress_label.pack(side="right", padx=8)

        self.fullscreen = False

        # Keyboard shortcuts
        root.bind("<space>", lambda e: self.toggle_pause())
        root.bind("<Right>", lambda e: self.next_word_manual())
        root.bind("<Left>", lambda e: self.prev_word())
        root.bind("<f>", lambda e: self.toggle_fullscreen())

        # Resize handling for auto font size
        root.bind("<Configure>", lambda e: self._auto_resize_font())

    def type_or_paste(self):
        s = simpledialog.askstring("Input", "Paste or type text (words will be extracted)")
        if s is not None:
            self._load_text(s)

    def open_file(self):
        path = filedialog.askopenfilename(filetypes=[("Text files","*.txt"),("All files","*.*")])
        if path:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
            self._load_text(text)

    def _load_text(self, text):
        self.original_text = text
        self.words = split_into_words(text)
        self.index = 0
        self.label.config(text=f"Loaded {len(self.words)} words")
        self._update_progress()

    def copy_all(self):
        if not self.original_text:
            self.root.clipboard_clear()
            self.root.clipboard_append("")
            self.label.config(text="(no text to copy)")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(self.original_text)
        self.label.config(text="Copied all text to clipboard")

    def start(self):
        try:
            self.display_ms = max(20, int(self.display_entry.get()))
        except ValueError:
            self.display_ms = 800
            self.display_entry.delete(0, tk.END)
            self.display_entry.insert(0, str(self.display_ms))
        try:
            self.gap_ms = max(0, int(self.gap_entry.get()))
        except ValueError:
            self.gap_ms = 150
            self.gap_entry.delete(0, tk.END)
            self.gap_entry.insert(0, str(self.gap_ms))

        if not self.words:
            self.label.config(text="(no words loaded)")
            return

        self.running = True
        self.paused = False
        if self.show_job:
            self.root.after_cancel(self.show_job)
            self.show_job = None
        if self.clear_job:
            self.root.after_cancel(self.clear_job)
            self.clear_job = None
        self._show_next_word()

    def stop(self):
        self.running = False
        self.paused = False
        if self.show_job:
            self.root.after_cancel(self.show_job)
            self.show_job = None
        if self.clear_job:
            self.root.after_cancel(self.clear_job)
            self.clear_job = None
        self.label.config(text="")
        self._update_progress()

    def toggle_pause(self):
        if not self.running:
            return
        self.paused = not self.paused
        if self.paused:
            # cancel scheduled jobs so the current word remains visible
            if self.show_job:
                self.root.after_cancel(self.show_job)
                self.show_job = None
            if self.clear_job:
                self.root.after_cancel(self.clear_job)
                self.clear_job = None
            self.progress_label.config(text="Paused")
        else:
            self.progress_label.config(text="")
            # resume immediately
            self._show_next_word()

    def _show_next_word(self):
        if not self.running or self.paused or not self.words:
            return

        if self.random_var.get():
            word = random.choice(self.words)
        else:
            word = self.words[self.index % len(self.words)]
            self.index += 1

        self.label.config(text=word)
        self._auto_resize_font()
        self._update_progress()
        self.clear_job = self.root.after(self.display_ms, self._clear_and_schedule_next)

    def _clear_and_schedule_next(self):
        self.label.config(text="")
        self.clear_job = None
        if not self.running or self.paused:
            return
        self.show_job = self.root.after(self.gap_ms, self._show_next_word)

    def next_word_manual(self):
        if not self.words:
            return
        if self.random_var.get():
            word = random.choice(self.words)
        else:
            word = self.words[self.index % len(self.words)]
            self.index += 1
        self.label.config(text=word)
        self._auto_resize_font()
        self._update_progress()

    def prev_word(self):
        if not self.words:
            return
        if self.random_var.get():
            word = random.choice(self.words)
        else:
            self.index = max(0, self.index - 2)
            word = self.words[self.index % len(self.words)]
            self.index += 1
        self.label.config(text=word)
        self._auto_resize_font()
        self._update_progress()

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)

    def _update_progress(self):
        if not self.words:
            self.progress_label.config(text="")
            return
        if self.random_var.get():
            self.progress_label.config(text=f"Random mode; {len(self.words)} words")
        else:
            pos = (self.index % len(self.words)) or len(self.words)
            self.progress_label.config(text=f"{pos}/{len(self.words)}")

    def _auto_resize_font(self):
        text = self.label.cget("text")
        if not text:
            size = self.base_font_size
            self.display_font.configure(size=size)
            return
        w = self.root.winfo_width() or 1000
        target_width = int(w * 0.9)
        size = self.base_font_size
        self.display_font.configure(size=size)
        while size > 10 and self.display_font.measure(text) > target_width:
            size -= 4
            self.display_font.configure(size=size)

if __name__ == "__main__":
    root = tk.Tk()
    app = OneWordFlasher(root)
    root.mainloop()
