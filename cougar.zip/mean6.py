#!/usr/bin/env python3
"""
mean_bot_tts_full.py
MeanBot with expanded SASSY_LINES, SNARKY_ONE_LINERS, and MILD_PROFANITY,
repeat-by-count prompt at program end, and cross-platform TTS using only stdlib
and system tools (macOS say, Windows PowerShell System.Speech, Linux spd-say/espeak).
TTS is enabled by default; use --no-tts to disable.
"""

import argparse
import random
import re
import shutil
import subprocess
import sys
import time
from platform import system as _platform_name

# -------------------------
# Full expanded line lists
# -------------------------
SASSY_LINES = [
    "Wow. That idea aged like milk.",
    "You tried. That's adorable.",
    "If enthusiasm were talent, you'd be a superstar.",
    "Congratulations, you broke subtlety.",
    "That's... a choice. A very questionable choice.",
    "I would explain, but I left my patience at home.",
    "You're not wrong; you're just dramatically misguided.",
    "Please stop. My sarcasm meter is overheating.",
    "Cute attempt. Cute like a soggy cupcake.",
    "You bring chaos and call it creativity.",
    "That plan has the structural integrity of a paper towel.",
    "I admire your confidence. I pity the results.",
    "You have the charisma of a dial tone.",
    "That's bold. Bold and poorly thought out.",
    "You could've done worse. Barely.",
    "I respect the hustle. I don't respect the outcome.",
    "You're like a plot twist nobody asked for.",
    "Ambition is great. Execution, not so much.",
    "You aimed for genius and landed on 'interesting'.",
    "That's a masterpiece of questionable decisions.",
    "You have a real talent for making things complicated.",
    "It's impressive how consistently you underdeliver.",
    "You turned 'maybe' into a full-time job.",
    "That idea needs a nap and a stern talking-to.",
    "You call that a plan? Cute.",
    "You should've bottled that optimism and sold it as fiction.",
    "You're the human version of a typo.",
    "That was a bold swing. It missed the planet.",
    "You have the subtlety of a foghorn.",
    "I didn't know 'trainwreck' could be a lifestyle choice.",
    "You could be right. You could also be spectacularly wrong.",
    "That was ambitious. Ambitiously wrong.",
    "You make chaos look like a hobby.",
    "You have a PhD in overcomplication.",
    "That idea needs a permission slip.",
    "You tried to be clever and ended up being confusing.",
    "You bring the energy of a broken blender.",
    "That was less 'mic drop' and more 'mic fumble'.",
    "You have a gift for turning simple into dramatic.",
    "That plan reads like a dare.",
    "You could win an award for trying too hard.",
    "You have the timing of a dropped call.",
    "That was a bold experiment in poor judgment.",
    "You are a walking 'what if' that nobody asked for.",
    "That idea belongs in a museum of questionable choices.",
    "You have the follow-through of a popped balloon.",
    "That was a creative interpretation of 'workable'.",
    "You make 'almost' look like a full-time job.",
    "That was a headline without the article.",
    "You have the subtlety of a neon sign.",
    "That idea needs a map and a therapist.",
    "You have the attention span of a goldfish on espresso.",
    "That was a performance piece called 'Why Did You Do That?'",
    "You have the coordination of a dropped Wi-Fi signal.",
    "That idea smells faintly of desperation.",
    "You turned a suggestion into a full-blown saga.",
    "You have the follow-through of a paper airplane.",
    "That was a bold attempt at being memorable; mission accomplished.",
    "You have the grace of a cat on roller skates.",
    "That was a creative detour into chaos.",
    "You could be a case study in 'what not to do'.",
    "You have the subtlety of a marching band at midnight.",
    "That idea needs a safety harness.",
    "You have the finesse of a sledgehammer.",
    "That was a charmingly misguided effort.",
    "You have the instincts of a confused raccoon.",
    "That plan reads like a dare from a bored teenager.",
    "You have the elegance of a spilled smoothie.",
    "That was a bold misinterpretation of 'simple'.",
    "You have the follow-through of a popped soap bubble.",
    "That idea needs a user manual and a therapist.",
    "You have the timing of a dropped mic in an empty room.",
    "That was a spectacularly unnecessary flourish.",
    "You have the subtlety of a fireworks display in a library.",
    "That idea needs a reality check and a nap.",
]

SNARKY_ONE_LINERS = [
    "Bless your heart and your poor decision-making skills.",
    "You're like a software update: unexpected and inconvenient.",
    "I could agree with you, but then we'd both be wrong.",
    "You're the human equivalent of a participation trophy.",
    "Nice try. The try part was the only nice thing.",
    "You're not the problem. You're the plot twist.",
    "I would clap, but I'm conserving energy for better things.",
    "You're a limited edition of questionable judgment.",
    "That's a bold claim for someone who skimmed the instructions.",
    "You're the reason we have warning labels.",
    "You bring 'almost' to a whole new level.",
    "That's a very confident misunderstanding.",
    "You're like a puzzle with half the pieces missing.",
    "I admire your optimism. I question your facts.",
    "You're the kind of person who reads the last page first.",
    "That's a creative take on 'no'.",
    "You're a walking 'did they really just do that?'",
    "You have the instincts of a confused GPS.",
    "That's not wrong, it's just aggressively unconventional.",
    "You're the plot twist the editor cut.",
    "I respect the effort. I don't respect the result.",
    "You're like a browser with too many tabs open.",
    "That's a bold strategy for someone allergic to planning.",
    "You're the human version of a shrug.",
    "I see what you tried to do. I also see what happened instead.",
    "You're a masterclass in 'close, but no'.",
    "That's an interesting take from the 'wing it' school of thought.",
    "You're the kind of person who brings a spoon to a sword fight.",
    "I appreciate the enthusiasm. I question the logic.",
    "You're a walking 'hold my beer' moment.",
    "That's a very confident guess.",
    "You're like a tutorial with missing steps.",
    "I didn't know 'creative chaos' was a career path.",
    "You're the reason 'trial and error' exists.",
    "That's a bold move for someone who skipped the manual.",
    "You're a delightful mix of hope and poor planning.",
    "That's not a plan. That's a suggestion with delusions.",
    "You're the human equivalent of a sticky note that fell off.",
    "I applaud the effort. I file the result under 'why'.",
    "You're like a plot with no editor.",
    "That's a very enthusiastic misunderstanding of the assignment.",
    "You're the kind of person who invents new ways to be wrong.",
    "I see ambition. I also see chaos.",
    "You're a walking 'we'll fix it later'.",
    "That's a confident misfire.",
    "You're the kind of energy that needs a timeout.",
    "I respect the hustle. I question the method.",
    "You're the human version of a buffering wheel.",
    "That's a bold move for someone allergic to instructions.",
    "You're like a sticky note on a hurricane.",
    "That's a very optimistic misread of reality.",
    "You're the kind of person who brings enthusiasm and no plan.",
    "That's a confident leap into the void.",
    "You're the human equivalent of a 'to be continued' card.",
    "That's a very creative misunderstanding of 'deadline'.",
    "You're like a GPS that reroutes to confusion.",
    "That's a bold interpretation of 'best practice'.",
    "You're the kind of person who invents new categories of mistakes.",
    "That's a very enthusiastic 'not quite'.",
    "You're like a draft saved as 'final_final_v2'.",
    "That's a bold claim from someone who skimmed the fine print.",
]

MILD_PROFANITY = [
    "You're a walking disaster, and honestly it's impressive.",
    "That was spectacularly dumb, in a charming way.",
    "You managed to make a mess with style, damn impressive.",
    "That's gloriously, unapologetically awful.",
    "You really went full chaos on that one, didn't you?",
    "That was a glorious trainwreck, and I can't look away.",
    "You nailed 'disaster chic'.",
    "That's a hot mess and you own it.",
    "You turned 'oops' into an art form.",
    "That was gloriously, wonderfully wrong.",
    "You have a knack for spectacularly bad timing.",
    "That was a facepalm wrapped in glitter.",
    "You pulled off 'what were you thinking' with flair.",
    "That's a bold screw-up and I respect the commitment.",
    "You made a glorious mess and called it a plan.",
    "That was a beautifully executed flop.",
    "You went all-in on chaos and hit the jackpot.",
    "That was a deliciously bad idea.",
    "You managed to mess it up with confidence.",
    "That was a masterclass in 'oh no'.",
    "You brought the thunder and the lightning missed.",
    "That was a spectacularly questionable move.",
    "You have a talent for turning small problems into epics.",
    "That was a glorious faceplant.",
    "You made 'disaster' look like a performance piece.",
    "That was a wonderfully terrible decision.",
    "You went for bold and landed on 'oh dear'.",
    "That was a magnificent misstep.",
    "You turned a simple task into a saga.",
    "That was a glorious, unapologetic mess.",
    "You have a knack for spectacularly missing the point.",
    "That was a gloriously unnecessary detour.",
    "You made 'oops' sound like a headline.",
    "That was a wonderfully executed blunder.",
    "You have a talent for turning small errors into epics.",
    "That was a facepalm of Shakespearean proportions.",
    "You pulled off 'what were you thinking' with style.",
    "That was a spectacularly questionable choice, and I applaud the commitment.",
    "You made a mess and called it innovation.",
    "That was a glorious miscalculation.",
    "You have a gift for turning clarity into chaos.",
    "That was a beautifully chaotic disaster.",
    "You made 'uh-oh' sound like a performance.",
    "That was a spectacularly misguided flourish.",
    "You turned a minor hiccup into a saga.",
    "That was a glorious, unapologetic faceplant.",
    "You made 'oops' look intentional and dramatic.",
    "That was a wonderfully terrible idea executed with flair.",
]

# -------------------------
# TTS helpers (no external libs)
# -------------------------
def _which(cmd):
    return shutil.which(cmd) is not None

def speak_mac(text, voice=None):
    cmd = ["say"]
    if voice:
        cmd += ["-v", voice]
    cmd += [text]
    subprocess.run(cmd, check=False)

def speak_windows(text, voice=None):
    safe_text = text.replace("'", "''")
    ps_lines = [
        "Add-Type -AssemblyName System.Speech",
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer",
    ]
    if voice:
        ps_lines.append(f"try {{ $s.SelectVoice('{voice}') }} catch {{ }}")
    ps_lines.append(f"$s.Speak('{safe_text}')")
    ps_cmd = "; ".join(ps_lines)
    subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)

def speak_linux(text, voice=None):
    if _which("spd-say"):
        cmd = ["spd-say"]
        if voice:
            cmd += ["-o", voice]
        cmd += [text]
        subprocess.run(cmd, check=False)
        return True
    if _which("espeak"):
        cmd = ["espeak"]
        if voice:
            cmd += ["-v", voice]
        cmd += [text]
        subprocess.run(cmd, check=False)
        return True
    return False

def speak(text, voice=None):
    plat = _platform_name().lower()
    try:
        if "darwin" in plat or "mac" in plat:
            speak_mac(text, voice)
            return True
        if "windows" in plat:
            speak_windows(text, voice)
            return True
        return speak_linux(text, voice)
    except Exception:
        return False

# -------------------------
# Core selection logic
# -------------------------
def choose_line(intensity=1, allow_profanity=False):
    pool = []
    if intensity <= 1:
        pool = SASSY_LINES + SNARKY_ONE_LINERS
    elif intensity == 2:
        pool = SASSY_LINES + SNARKY_ONE_LINERS + MILD_PROFANITY
    else:
        pool = SASSY_LINES + SNARKY_ONE_LINERS + MILD_PROFANITY
        pool += MILD_PROFANITY * 2

    if not allow_profanity:
        pool = [p for p in pool if p not in MILD_PROFANITY]

    return random.choice(pool) if pool else "..."

def print_repeated_lines(count, intensity, allow_profanity, tts=True, tts_voice=None, delay=0.4):
    last = None
    for _ in range(max(0, count)):
        line = choose_line(intensity=intensity, allow_profanity=allow_profanity)
        print(line)
        if tts:
            speak(line, voice=tts_voice)
        last = line
        time.sleep(delay)
    return last

# -------------------------
# Interactive mode
# -------------------------
def interactive_mode(args, tts_enabled):
    print("MeanBot activated. Type something and press Enter.")
    print("Commands: 'quit' or 'exit' to leave; 'repeat' to repeat last line; 'repeat N' to repeat last line N times.")
    last_line = None
    while True:
        try:
            user = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user:
            last_line = choose_line(intensity=args.intensity, allow_profanity=args.profanity)
            print(last_line)
            if tts_enabled:
                speak(last_line, voice=args.tts_voice)
            continue

        cmd = user.lower()
        if cmd in ("quit", "exit"):
            print("Fine. Leave. I wasn't enjoying this anyway.")
            break

        m = re.match(r"^repeat(?:\s+(\d+))?$", cmd)
        if m:
            if last_line is None:
                print("Nothing to repeat yet. Say something first.")
                continue
            n = int(m.group(1)) if m.group(1) else 1
            for _ in range(max(1, n)):
                print(last_line)
                if tts_enabled:
                    speak(last_line, voice=args.tts_voice)
                time.sleep(0.25)
            continue

        last_line = choose_line(intensity=args.intensity, allow_profanity=args.profanity)
        time.sleep(0.4)
        print(last_line)
        if tts_enabled:
            speak(last_line, voice=args.tts_voice)

# -------------------------
# Non-interactive run / repeat-by-count at end
# -------------------------
def loop_mode_once(args, tts_enabled):
    try:
        while True:
            line = choose_line(intensity=args.intensity, allow_profanity=args.profanity)
            print(line)
            if tts_enabled:
                speak(line, voice=args.tts_voice)
            time.sleep(0.6)
    except KeyboardInterrupt:
        print("\nLoop interrupted by user.")

def one_shot_mode_once(args, tts_enabled):
    count = max(1, args.repeat) if args.repeat is not None else 1
    print_repeated_lines(count, args.intensity, args.profanity, tts=tts_enabled, tts_voice=args.tts_voice)

def ask_repeat_count():
    while True:
        try:
            resp = input("\nEnter repeat count (0 to quit): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nNo response; quitting.")
            return 0
        if resp == "":
            return 0
        if resp.isdigit():
            return int(resp)
        print("Please enter a non-negative integer (e.g., 0, 1, 5).")

def run_mode_once(args, tts_enabled):
    if args.loop:
        loop_mode_once(args, tts_enabled)
    else:
        one_shot_mode_once(args, tts_enabled)

# -------------------------
# CLI entrypoint
# -------------------------
def main(argv=None):
    parser = argparse.ArgumentParser(description="MeanBot — repeat-by-count with cross-platform TTS (TTS on by default).")
    parser.add_argument("--interactive", "-i", action="store_true", help="Run in interactive chat mode.")
    parser.add_argument("--intensity", "-t", type=int, choices=[1,2,3], default=1,
                        help="Intensity level: 1 (mild), 2 (snarky), 3 (extra).")
    parser.add_argument("--profanity", "-p", action="store_true", help="Allow mild profanity lines.")
    parser.add_argument("--one", "-o", action="store_true", help="Print one mean line and exit.")
    parser.add_argument("--repeat", "-r", type=int, default=None,
                        help="When used with --one, print this many lines then quit. When used alone, prints N lines and exits.")
    parser.add_argument("--loop", action="store_true", help="Continuously print mean lines until interrupted (Ctrl-C).")
    # TTS default is enabled; provide --no-tts to disable
    parser.add_argument("--no-tts", action="store_true", help="Disable TTS (speech). TTS is enabled by default.")
    parser.add_argument("--tts-voice", type=str, default=None, help="Optional voice name (platform-dependent).")
    args = parser.parse_args(argv)

    tts_enabled = not args.no_tts

    if args.interactive:
        interactive_mode(args, tts_enabled)
        return

    while True:
        run_mode_once(args, tts_enabled)

        count = ask_repeat_count()
        if count <= 0:
            print("Quitting as requested.")
            break

        print(f"\nRepeating the same run {count} time(s)...\n")
        for _ in range(count):
            run_mode_once(args, tts_enabled)
            time.sleep(0.25)

        print("\nRun complete. You can repeat again or enter 0 to quit.")

if __name__ == "__main__":
    main()
