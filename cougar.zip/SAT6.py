#!/usr/bin/env python3
"""
SAT Test Emulator - Multiple Choice
Immediate feedback, extended QUESTION_BANK, repeat/quit loop, system TTS, speaks choices.
This version includes the original bank (IDs 1-150) plus 200 more questions (IDs 151-350).
No external Python packages required.
"""

import random
import time
import sys
import platform
import subprocess
import shutil

# ---------------------------
# Base QUESTION_BANK (original 5 + IDs 101-150)
# ---------------------------
QUESTION_BANK = [
    # Original 5
    {"id": 1, "question": "What is the value of x if 2x + 3 = 11?", "choices": ["3", "4", "5", "6"], "answer": 1, "explanation": "2x + 3 = 11 -> 2x = 8 -> x = 4."},
    {"id": 2, "question": "Which sentence is grammatically correct?", "choices": ["Neither of the boys are going to the game.", "Neither of the boys is going to the game.", "Neither of the boys were going to the game.", "Neither of the boys be going to the game."], "answer": 1, "explanation": "'Neither' is singular, so use 'is'."},
    {"id": 3, "question": "If f(x) = x^2 - 4x + 3, what is f(2)?", "choices": ["-1", "0", "1", "3"], "answer": 0, "explanation": "f(2) = 4 - 8 + 3 = -1."},
    {"id": 4, "question": "A rectangle has length 10 and width 4. What is its area?", "choices": ["14", "40", "20", "28"], "answer": 1, "explanation": "Area = length * width = 10 * 4 = 40."},
    {"id": 5, "question": "Which of the following is a prime number?", "choices": ["21", "25", "29", "27"], "answer": 2, "explanation": "29 is prime."},

    # Additional 50 (IDs 101-150)
    {"id": 101, "question": "If 3(x - 2) = 12, what is x?", "choices": ["2", "4", "6", "8"], "answer": 2, "explanation": "3(x-2)=12 -> x-2=4 -> x=6."},
    {"id": 102, "question": "Which word best completes the sentence: The scientist's theory was _____ by new evidence.", "choices": ["bolstered", "abated", "obscured", "neglected"], "answer": 0, "explanation": "'Bolstered' means supported by evidence."},
    {"id": 103, "question": "What is the slope of the line passing through (1,2) and (4,11)?", "choices": ["3", "9/3", "11/4", "None of the above"], "answer": 0, "explanation": "Slope = (11-2)/(4-1)=9/3=3."},
    {"id": 104, "question": "Choose the grammatically correct sentence.", "choices": ["Each of the players have a locker.", "Each of the players has a locker.", "Each of the players are given a locker.", "Each of the players were given lockers."], "answer": 1, "explanation": "'Each' is singular, so 'has' is correct."},
    {"id": 105, "question": "If 2^x = 32, what is x?", "choices": ["4", "5", "6", "8"], "answer": 1, "explanation": "32 = 2^5, so x = 5."},
    {"id": 106, "question": "Which choice is closest in meaning to 'ephemeral'?", "choices": ["lasting", "fleeting", "harmful", "transparent"], "answer": 1, "explanation": "'Ephemeral' means short-lived or fleeting."},
    {"id": 107, "question": "A bag contains 3 red, 4 blue, and 5 green marbles. What is the probability of drawing a blue marble?", "choices": ["1/3", "4/12", "1/4", "4/11"], "answer": 0, "explanation": "Total 12 marbles; blue = 4 -> 4/12 = 1/3."},
    {"id": 108, "question": "Which sentence uses the colon correctly?", "choices": ["She bought: apples, oranges, and pears.", "She bought apples, oranges, and pears:", "She bought the following: apples, oranges, and pears.", "She bought the following apples, oranges, and pears."], "answer": 2, "explanation": "Use a colon before a list introduced by a complete clause."},
    {"id": 109, "question": "If f(x)=3x+2, what is f^{-1}(x)?", "choices": ["(x-2)/3", "(x+2)/3", "3x-2", "x/3+2"], "answer": 0, "explanation": "Solve y=3x+2 for x: x=(y-2)/3."},
    {"id": 110, "question": "Which word is an antonym of 'lucid'?", "choices": ["clear", "vague", "bright", "rational"], "answer": 1, "explanation": "'Lucid' means clear; antonym is 'vague'."},
    {"id": 111, "question": "Simplify: 5(2x - 3) - 4(x + 1).", "choices": ["6x - 19", "x - 11", "10x - 15", "0"], "answer": 0, "explanation": "5(2x-3)-4(x+1)=10x-15-4x-4=6x-19."},
    {"id": 112, "question": "Which sentence is punctuated correctly?", "choices": ["My brother who lives in Boston is visiting.", "My brother, who lives in Boston is visiting.", "My brother who lives in Boston, is visiting.", "My brother, who lives in Boston, is visiting."], "answer": 3, "explanation": "Nonrestrictive clause needs commas on both sides."},
    {"id": 113, "question": "If the perimeter of a square is 20, what is the area?", "choices": ["25", "16", "20", "100"], "answer": 0, "explanation": "Side = 20/4 =5; area = 5^2 =25."},
    {"id": 114, "question": "Choose the best transition: She studied hard; _____, she failed the exam.", "choices": ["therefore", "however", "consequently", "moreover"], "answer": 1, "explanation": "Contrast: 'however' fits the unexpected result."},
    {"id": 115, "question": "What is the greatest common divisor of 48 and 180?", "choices": ["12", "6", "24", "36"], "answer": 0, "explanation": "GCD(48,180)=12."},
    {"id": 116, "question": "Which word best completes the sentence: The committee reached a _____ decision after hours of debate.", "choices": ["unanimous", "capricious", "tentative", "erratic"], "answer": 0, "explanation": "'Unanimous' means everyone agreed."},
    {"id": 117, "question": "If x^2 - 9 = 0, what are the solutions for x?", "choices": ["-3 and 3", "3 only", "0 and 3", "-3 only"], "answer": 0, "explanation": "x^2-9=(x-3)(x+3)=0 -> x=3 or x=-3."},
    {"id": 118, "question": "Which sentence avoids a dangling modifier?", "choices": ["Walking down the street, the trees were beautiful.", "Walking down the street, I admired the trees.", "Walking down the street, the admiring was mutual.", "Walking down the street, the trees admired me."], "answer": 1, "explanation": "Subject performing the action must be clear: 'I admired'."},
    {"id": 119, "question": "A train travels 120 miles in 2 hours and 30 minutes. What is its average speed in mph?", "choices": ["48", "50", "60", "45"], "answer": 0, "explanation": "2.5 hours; 120/2.5 = 48 mph."},
    {"id": 120, "question": "Choose the word that best fits: The artist's work was praised for its _____ use of color.", "choices": ["garish", "subtle", "obvious", "loud"], "answer": 1, "explanation": "'Subtle' indicates restrained, skillful use."},
    {"id": 121, "question": "If 3/4 = x/20, what is x?", "choices": ["15", "12", "16", "10"], "answer": 0, "explanation": "x = 20*(3/4)=15."},
    {"id": 122, "question": "Which sentence is parallel in structure?", "choices": ["She likes hiking, to swim, and biking.", "She likes hiking, swimming, and biking.", "She likes to hike, swimming, and to bike.", "She likes hiking, swimming, and to bike."], "answer": 1, "explanation": "All gerunds: hiking, swimming, biking."},
    {"id": 123, "question": "What is 15% of 240?", "choices": ["36", "30", "24", "40"], "answer": 0, "explanation": "0.15*240 = 36."},
    {"id": 124, "question": "Choose the best synonym for 'mitigate'.", "choices": ["worsen", "alleviate", "ignore", "provoke"], "answer": 1, "explanation": "'Mitigate' means to make less severe."},
    {"id": 125, "question": "If a circle has radius 7, what is its circumference (use pi)?", "choices": ["14π", "7π", "49π", "28π"], "answer": 0, "explanation": "Circumference = 2πr = 14π."},
    {"id": 126, "question": "Which sentence contains a misplaced modifier?", "choices": ["She almost drove her kids to school every day.", "She drove her kids to school almost every day.", "Almost she drove her kids to school every day.", "She drove almost her kids to school every day."], "answer": 0, "explanation": "'Almost' placed before 'drove' changes meaning; intended is frequency."},
    {"id": 127, "question": "Solve for x: 4x + 7 = 3x - 5.", "choices": ["-12", "-5", "-2", "12"], "answer": 0, "explanation": "4x-3x = -5-7 -> x = -12."},
    {"id": 128, "question": "Which word best completes: The CEO's speech was _____ with optimism.", "choices": ["replete", "fraught", "devoid", "bereft"], "answer": 0, "explanation": "'Replete' means full of; fits with optimism."},
    {"id": 129, "question": "If the ratio of A to B is 3:5 and A = 18, what is B?", "choices": ["30", "20", "15", "25"], "answer": 0, "explanation": "3:5 -> scale factor 6 -> B = 5*6 = 30."},
    {"id": 130, "question": "Choose the correct comparative form: 'This problem is _____ than the last one.'", "choices": ["more simpler", "simpler", "most simple", "simplest"], "answer": 1, "explanation": "Comparative of 'simple' is 'simpler'."},
    {"id": 131, "question": "What is the median of the set {3, 7, 9, 12, 15}?", "choices": ["9", "10", "12", "7"], "answer": 0, "explanation": "Middle value is 9."},
    {"id": 132, "question": "Which sentence uses 'affect' correctly?", "choices": ["The weather will affect our plans.", "The weather had a big affect on us.", "Her affect was cheerful.", "He was affected by the news."], "answer": 0, "explanation": "'Affect' as a verb means to influence."},
    {"id": 133, "question": "If y = 2x + 1 and x = 4, what is y?", "choices": ["9", "8", "7", "10"], "answer": 0, "explanation": "y = 2*4+1 = 9."},
    {"id": 134, "question": "Choose the best word: The historian's account was _____ by newly discovered letters.", "choices": ["contradicted", "confirmed", "ignored", "obscured"], "answer": 1, "explanation": "New letters that support the account would 'confirm' it."},
    {"id": 135, "question": "A rectangle's length is twice its width. If area = 72, what is the width?", "choices": ["6", "8", "9", "12"], "answer": 0, "explanation": "Let w = width, length = 2w -> area = 2w^2 =72 -> w^2=36 -> w=6."},
    {"id": 136, "question": "Which sentence is concise and correct?", "choices": ["Due to the fact that it rained, the game was canceled.", "Because it rained, the game was canceled.", "The game was canceled due to the fact that it rained.", "It rained, therefore the game was canceled."], "answer": 1, "explanation": "Option 2 is concise and correct."},
    {"id": 137, "question": "What is 7 × 8 - 6^2?", "choices": ["14", "20", "8", "-2"], "answer": 1, "explanation": "7*8=56; 6^2=36; 56-36=20."},
    {"id": 138, "question": "Choose the best synonym for 'prudent'.", "choices": ["rash", "careful", "reckless", "hasty"], "answer": 1, "explanation": "'Prudent' means careful or wise in practical matters."},
    {"id": 139, "question": "If a sequence is arithmetic with first term 5 and common difference 3, what is the 10th term?", "choices": ["32", "29", "35", "30"], "answer": 0, "explanation": "a_n = 5 + (n-1)*3 -> a_10 = 5+27=32."},
    {"id": 140, "question": "Which sentence correctly uses 'fewer'?", "choices": ["There are fewer people here than yesterday.", "There are less people here than yesterday.", "There are fewer amount of people here.", "There are less amount of people here."], "answer": 0, "explanation": "'Fewer' is used with countable nouns like people."},
    {"id": 141, "question": "Simplify: (x^2)(x^3).", "choices": ["x^5", "x^6", "x^1", "x^9"], "answer": 0, "explanation": "Add exponents: 2+3=5."},
    {"id": 142, "question": "Which word best completes: The lawyer argued that the evidence was _____ and should be excluded.", "choices": ["inadmissible", "admissible", "relevant", "compelling"], "answer": 0, "explanation": "'Inadmissible' means not allowed as evidence."},
    {"id": 143, "question": "If the probability of rain is 0.2, what is the probability it does not rain?", "choices": ["0.8", "0.2", "0.5", "0.02"], "answer": 0, "explanation": "Complement = 1 - 0.2 = 0.8."},
    {"id": 144, "question": "Choose the correct form: 'Neither the manager nor the employees _____ available.'", "choices": ["is", "are", "were", "be"], "answer": 1, "explanation": "Verb agrees with nearer subject 'employees' (plural) -> 'are'."},
    {"id": 145, "question": "What is the area of a triangle with base 10 and height 6?", "choices": ["30", "60", "16", "40"], "answer": 0, "explanation": "Area = 1/2 * base * height = 0.5*10*6=30."},
    {"id": 146, "question": "Which word is closest in meaning to 'ambivalent'?", "choices": ["decisive", "uncertain", "enthusiastic", "hostile"], "answer": 1, "explanation": "'Ambivalent' means having mixed feelings or uncertainty."},
    {"id": 147, "question": "If 2x + 3y = 12 and x = 3, what is y?", "choices": ["1.5", "2", "3", "0"], "answer": 1, "explanation": "2*3 + 3y =12 -> 6 + 3y =12 -> 3y=6 -> y=2."},
    {"id": 148, "question": "Choose the sentence with correct parallelism.", "choices": ["She wants to learn French, to travel, and cooking.", "She wants to learn French, travel, and cook.", "She wants learning French, to travel, and to cook.", "She wants to learn French, traveling, and to cook."], "answer": 1, "explanation": "All infinitives: learn, travel, cook."},
    {"id": 149, "question": "What is 2/5 + 3/10?", "choices": ["7/10", "1/2", "5/10", "8/10"], "answer": 0, "explanation": "2/5 = 4/10; 4/10+3/10=7/10."},
    {"id": 150, "question": "Which word best completes: The committee's decision was _____ by public outcry.", "choices": ["reversed", "endorsed", "ignored", "celebrated"], "answer": 0, "explanation": "Public outcry can cause a decision to be reversed."}
]

# ---------------------------
# MORE_QUESTIONS (IDs 151-350)
# ---------------------------
MORE_QUESTIONS = [
    {"id":151, "question":"If 5x - 7 = 18, what is x?", "choices":["1", "3", "5", "25/5"], "answer":2, "explanation":"5x=25 -> x=5."},
    {"id":152, "question":"Which word best completes: The novel's ending was _____ and left readers thinking.", "choices":["trite", "ambiguous", "obvious", "banal"], "answer":1, "explanation":"'Ambiguous' means open to interpretation."},
    {"id":153, "question":"What is 12% of 250?", "choices":["30", "24", "20", "15"], "answer":0, "explanation":"0.12*250=30."},
    {"id":154, "question":"Simplify: (3x^2)(2x^3).", "choices":["6x^5", "5x^6", "6x^6", "x^5"], "answer":0, "explanation":"Multiply coefficients and add exponents: 3*2=6, 2+3=5."},
    {"id":155, "question":"Which sentence is correct?", "choices":["Neither of the answers are correct.", "Neither of the answers is correct.", "Neither of the answers were correct.", "Neither of the answers be correct."], "answer":1, "explanation":"'Neither' is singular."},
    {"id":156, "question":"If a = 4 and b = -2, what is a^2 + b^2?", "choices":["12", "20", "16", "8"], "answer":1, "explanation":"4^2 + (-2)^2 = 16 + 4 = 20."},
    {"id":157, "question":"Choose the synonym for 'candid'.", "choices":["evasive", "honest", "secretive", "guarded"], "answer":1, "explanation":"'Candid' means frank or honest."},
    {"id":158, "question":"What is the least common multiple of 6 and 8?", "choices":["24", "48", "12", "14"], "answer":0, "explanation":"LCM(6,8)=24."},
    {"id":159, "question":"Which word best completes: The committee reached a _____ conclusion after reviewing the data.", "choices":["hasty", "premature", "sound", "rash"], "answer":2, "explanation":"'Sound' means well-founded."},
    {"id":160, "question":"If y = 3x and x = 7, what is y?", "choices":["21", "10", "24", "14"], "answer":0, "explanation":"y=3*7=21."},
    {"id":161, "question":"Which sentence uses a semicolon correctly?", "choices":["I went to the store; and I bought milk.", "I went to the store; I bought milk.", "I went to the store, I bought milk;", "I went to the store; but I bought milk."], "answer":1, "explanation":"Use semicolon to join related independent clauses."},
    {"id":162, "question":"What is 9 squared?", "choices":["18", "81", "27", "72"], "answer":1, "explanation":"9^2 = 81."},
    {"id":163, "question":"Which word is closest in meaning to 'ubiquitous'?", "choices":["rare", "everywhere", "hidden", "unique"], "answer":1, "explanation":"'Ubiquitous' means present everywhere."},
    {"id":164, "question":"If a triangle has sides 3, 4, 5, what type of triangle is it?", "choices":["Equilateral", "Isosceles", "Right", "Obtuse"], "answer":2, "explanation":"3-4-5 is a Pythagorean triple -> right triangle."},
    {"id":165, "question":"Simplify: 2(x + 3) - x.", "choices":["x + 6", "x + 3", "2x + 3", "x - 3"], "answer":0, "explanation":"2x+6-x = x+6."},
    {"id":166, "question":"Which sentence is parallel?", "choices":["She likes to swim, biking, and to run.", "She likes swimming, biking, and running.", "She likes to swim, biking, and running.", "She likes swimming, to bike, and running."], "answer":1, "explanation":"All gerunds create parallel structure."},
    {"id":167, "question":"What is the value of 7! (7 factorial)?", "choices":["5040", "720", "504", "40320"], "answer":0, "explanation":"7!=7*6*5*4*3*2*1=5040."},
    {"id":168, "question":"Choose the antonym of 'benevolent'.", "choices":["kind", "malevolent", "charitable", "generous"], "answer":1, "explanation":"'Malevolent' is the opposite of benevolent."},
    {"id":169, "question":"If 2/3 = x/9, what is x?", "choices":["6", "3", "9", "12"], "answer":0, "explanation":"x = 9*(2/3)=6."},
    {"id":170, "question":"Which sentence uses 'its' correctly?", "choices":["Its raining outside.", "The dog wagged its tail.", "It's collar is red.", "Its' color is blue."], "answer":1, "explanation":"Possessive 'its' is correct for the dog."},
    {"id":171, "question":"What is the perimeter of a rectangle with length 8 and width 3?", "choices":["22", "24", "11", "16"], "answer":0, "explanation":"Perimeter = 2*(8+3)=22."},
    {"id":172, "question":"Which word best completes: The scientist's results were _____ by peers.", "choices":["ignored", "validated", "rejected", "concealed"], "answer":1, "explanation":"'Validated' means confirmed by peers."},
    {"id":173, "question":"If x - 4 = 10, what is x?", "choices":["6", "14", "4", "10"], "answer":1, "explanation":"x=14."},
    {"id":174, "question":"Which sentence is concise and correct?", "choices":["Due to the fact that it snowed, school was canceled.", "Because it snowed, school was canceled.", "School was canceled due to the fact that it snowed.", "It snowed, therefore school was canceled."], "answer":1, "explanation":"Option 2 is concise."},
    {"id":175, "question":"What is the area of a circle with radius 3 (use π)?", "choices":["9π", "6π", "3π", "18π"], "answer":0, "explanation":"Area = πr^2 = 9π."},
    {"id":176, "question":"Choose the best synonym for 'alleviate'.", "choices":["worsen", "ease", "ignore", "provoke"], "answer":1, "explanation":"'Alleviate' means to make less severe."},
    {"id":177, "question":"If 4x = 20, what is x?", "choices":["4", "5", "6", "16"], "answer":1, "explanation":"x=5."},
    {"id":178, "question":"Which sentence uses 'who' correctly?", "choices":["The woman who called left a message.", "The woman whom called left a message.", "The woman which called left a message.", "The woman that called left a message."], "answer":0, "explanation":"'Who' refers to people as subject."},
    {"id":179, "question":"What is 3/8 as a decimal?", "choices":["0.375", "0.38", "0.333", "0.25"], "answer":0, "explanation":"3 ÷ 8 = 0.375."},
    {"id":180, "question":"Which word best completes: The manager's tone was _____, calming the team.", "choices":["abrasive", "soothing", "harsh", "angry"], "answer":1, "explanation":"'Soothing' calms."},
    {"id":181, "question":"If f(x)=x+5, what is f(−3)?", "choices":["2", "8", "−8", "−2"], "answer":0, "explanation":"−3+5=2."},
    {"id":182, "question":"Which sentence is grammatically correct?", "choices":["Each of the students have a locker.", "Each of the students has a locker.", "Each of the students are given lockers.", "Each of the students were given lockers."], "answer":1, "explanation":"'Each' is singular."},
    {"id":183, "question":"What is the value of 0! ?", "choices":["0", "1", "Undefined", "−1"], "answer":1, "explanation":"By definition 0! = 1."},
    {"id":184, "question":"Choose the antonym of 'lucid'.", "choices":["clear", "vague", "bright", "transparent"], "answer":1, "explanation":"'Vague' is opposite of 'lucid'."},
    {"id":185, "question":"If a car travels 180 miles in 3 hours, what is its average speed in mph?", "choices":["60", "45", "90", "30"], "answer":0, "explanation":"180/3=60 mph."},
    {"id":186, "question":"Which sentence uses a colon correctly?", "choices":["Bring: a pen, paper, and a calculator.", "Bring the following: a pen, paper, and a calculator.", "Bring the following a pen, paper, and a calculator:", "Bring a pen: paper, and a calculator."], "answer":1, "explanation":"Colon introduces a list after a complete clause."},
    {"id":187, "question":"What is the next prime after 29?", "choices":["31", "33", "35", "37"], "answer":0, "explanation":"31 is prime."},
    {"id":188, "question":"Which word best completes: The artist's palette was _____ with color.", "choices":["devoid", "replete", "empty", "sparse"], "answer":1, "explanation":"'Replete' means full of."},
    {"id":189, "question":"If 7x = 49, what is x?", "choices":["6", "7", "8", "49"], "answer":1, "explanation":"x=7."},
    {"id":190, "question":"Which sentence is parallel in structure?", "choices":["He likes to read, writing, and to swim.", "He likes reading, writing, and swimming.", "He likes to read, writing, and swimming.", "He likes reading, to write, and swimming."], "answer":1, "explanation":"All gerunds are parallel."},
    {"id":191, "question":"What is 45% of 200?", "choices":["90", "80", "100", "45"], "answer":0, "explanation":"0.45*200=90."},
    {"id":192, "question":"Choose the synonym for 'epitome'.", "choices":["example", "antithesis", "opposite", "minor"], "answer":0, "explanation":"'Epitome' means a perfect example."},
    {"id":193, "question":"If x^2 = 49, what are possible x values?", "choices":["7 only", "−7 only", "7 and −7", "0"], "answer":2, "explanation":"x=±7."},
    {"id":194, "question":"Which sentence uses 'affect' correctly?", "choices":["The new law will affect many people.", "The new law had a big affect on many people.", "Her affect was joyful.", "He was effected by the news."], "answer":0, "explanation":"'Affect' as a verb means to influence."},
    {"id":195, "question":"What is the area of a triangle with base 12 and height 5?", "choices":["30", "60", "17", "24"], "answer":0, "explanation":"Area = 1/2 * base * height = 30."},
    {"id":196, "question":"Which word best completes: The CEO's remarks were _____ with optimism.", "choices":["fraught", "replete", "devoid", "bereft"], "answer":1, "explanation":"'Replete' means full of."},
    {"id":197, "question":"If 5 + 3x = 20, what is x?", "choices":["3", "5", "15", "−5"], "answer":1, "explanation":"3x=15 -> x=5."},
    {"id":198, "question":"Which sentence avoids a dangling modifier?", "choices":["After finishing the book, the TV was turned on.", "After finishing the book, she turned on the TV.", "Finishing the book, the TV was turned on.", "Finishing the book, the TV turned on."], "answer":1, "explanation":"Subject performing the action must be clear."},
    {"id":199, "question":"What is the cube of 4?", "choices":["12", "64", "16", "48"], "answer":1, "explanation":"4^3 = 64."},
    {"id":200, "question":"Choose the best synonym for 'pragmatic'.", "choices":["idealistic", "practical", "theoretical", "impractical"], "answer":1, "explanation":"'Pragmatic' means practical."},
    {"id":201, "question":"If 2x + 5 = 17, what is x?", "choices":["6", "5", "7", "4"], "answer":0, "explanation":"2x=12 -> x=6."},
    {"id":202, "question":"Which word best completes: The lecture was _____ and informative.", "choices":["tedious", "engaging", "boring", "irrelevant"], "answer":1, "explanation":"'Engaging' fits with informative."},
    {"id":203, "question":"What is the value of 1/4 + 1/2?", "choices":["3/4", "1/2", "1", "2/3"], "answer":0, "explanation":"1/4 + 1/2 = 3/4."},
    {"id":204, "question":"Simplify: x^0 for x ≠ 0.", "choices":["0", "1", "x", "Undefined"], "answer":1, "explanation":"Any nonzero number to the 0 power equals 1."},
    {"id":205, "question":"Which sentence is punctuated correctly?", "choices":["Let's eat, Grandma.", "Lets eat Grandma.", "Let's eat Grandma.", "Lets, eat Grandma."], "answer":0, "explanation":"Comma separates direct address."},
    {"id":206, "question":"What is the slope of the line y = 4x + 7?", "choices":["4", "7", "−4", "1/4"], "answer":0, "explanation":"Slope is coefficient of x: 4."},
    {"id":207, "question":"Choose the antonym of 'sparse'.", "choices":["scanty", "plentiful", "meager", "rare"], "answer":1, "explanation":"'Plentiful' is opposite of 'sparse'."},
    {"id":208, "question":"If a = 2 and b = 3, what is (a+b)^2?", "choices":["25", "13", "10", "5"], "answer":0, "explanation":"(2+3)^2=25."},
    {"id":209, "question":"Which sentence uses 'fewer' correctly?", "choices":["There are fewer cars on the road today.", "There is fewer traffic today.", "Fewer water was used.", "Fewer information is available."], "answer":0, "explanation":"'Fewer' for countable nouns."},
    {"id":210, "question":"What is 2^6?", "choices":["64", "32", "16", "128"], "answer":0, "explanation":"2^6 = 64."},
    {"id":211, "question":"Which word best completes: The policy was _____ to address the problem.", "choices":["ineffective", "designed", "implemented", "created"], "answer":1, "explanation":"'Designed' fits context of purpose."},
    {"id":212, "question":"If x/5 = 7, what is x?", "choices":["35", "12", "2", "7"], "answer":0, "explanation":"x=35."},
    {"id":213, "question":"Which sentence is concise?", "choices":["Due to the fact that he was late, we left.", "Because he was late, we left.", "He was late, therefore we left due to the fact.", "It was because he was late that we left."], "answer":1, "explanation":"Option 2 is concise."},
    {"id":214, "question":"What is the area of a square with side length 9?", "choices":["81", "36", "18", "27"], "answer":0, "explanation":"Area = 9^2 = 81."},
    {"id":215, "question":"Choose the synonym for 'obscure'.", "choices":["clear", "vague", "famous", "bright"], "answer":1, "explanation":"'Obscure' means unclear or unknown."},
    {"id":216, "question":"If 6x = 54, what is x?", "choices":["9", "8", "6", "12"], "answer":0, "explanation":"x=9."},
    {"id":217, "question":"Which sentence uses 'their' correctly?", "choices":["Their going to the store.", "Their car is new.", "They're car is new.", "There car is new."], "answer":1, "explanation":"'Their' is possessive."},
    {"id":218, "question":"What is the greatest common divisor of 14 and 21?", "choices":["7", "14", "21", "1"], "answer":0, "explanation":"GCD is 7."},
    {"id":219, "question":"Which word best completes: The experiment's results were _____ to the hypothesis.", "choices":["contradictory", "consistent", "irrelevant", "random"], "answer":1, "explanation":"'Consistent' matches hypothesis."},
    {"id":220, "question":"If x^2 = 16, what are x values?", "choices":["4 only", "−4 only", "4 and −4", "0"], "answer":2, "explanation":"x=±4."},
    {"id":221, "question":"Which sentence is grammatically correct?", "choices":["Less people came than expected.", "Fewer people came than expected.", "Fewer amount of people came than expected.", "Less amount of people came than expected."], "answer":1, "explanation":"'Fewer' for countable nouns."},
    {"id":222, "question":"What is 100 divided by 4?", "choices":["25", "20", "40", "24"], "answer":0, "explanation":"100/4=25."},
    {"id":223, "question":"Choose the antonym of 'arduous'.", "choices":["easy", "difficult", "strenuous", "taxing"], "answer":0, "explanation":"'Easy' is opposite of 'arduous'."},
    {"id":224, "question":"If a rectangle has area 48 and width 6, what is its length?", "choices":["8", "6", "12", "4"], "answer":0, "explanation":"Length = area/width = 48/6 = 8."},
    {"id":225, "question":"Which word best completes: The speech was _____ and inspired the audience.", "choices":["monotonous", "eloquent", "dull", "tedious"], "answer":1, "explanation":"'Eloquent' fits inspiring context."},
    {"id":226, "question":"What is the value of 10 − 3 × 2?", "choices":["14", "4", "8", "2"], "answer":1, "explanation":"Order of operations: 3*2=6; 10−6=4."},
    {"id":227, "question":"Which sentence uses 'whoever' correctly?", "choices":["Give the prize to whoever wins.", "Give the prize to whoever I choose.", "Whoever did this is guilty, whom I suspect.", "Whoever's book is this?"], "answer":0, "explanation":"'Whoever' as subject of wins is correct."},
    {"id":228, "question":"If 0.25 = x, what is x as a fraction?", "choices":["1/2", "1/4", "1/5", "1/3"], "answer":1, "explanation":"0.25 = 1/4."},
    {"id":229, "question":"Choose the synonym for 'tenacious'.", "choices":["persistent", "weak", "yielding", "fickle"], "answer":0, "explanation":"'Tenacious' means persistent."},
    {"id":230, "question":"What is the sum of interior angles of a triangle?", "choices":["180°", "360°", "90°", "270°"], "answer":0, "explanation":"Triangle interior angles sum to 180°."},
    {"id":231, "question":"Which sentence is punctuated correctly?", "choices":["She said 'I'll be late'.", "She said, 'I'll be late.'", "She said 'I'll be late.'", "She said, 'I'll be late'."], "answer":1, "explanation":"Comma before quote and period inside quotes."},
    {"id":232, "question":"If a = 3 and b = 4, what is the hypotenuse of a right triangle with legs a and b?", "choices":["5", "6", "7", "25"], "answer":0, "explanation":"3-4-5 Pythagorean triple."},
    {"id":233, "question":"Which word best completes: The policy was _____ after review.", "choices":["rescinded", "implemented", "ignored", "forgotten"], "answer":1, "explanation":"'Implemented' after review fits context."},
    {"id":234, "question":"What is 11 × 11?", "choices":["121", "111", "1210", "100"], "answer":0, "explanation":"11*11=121."},
    {"id":235, "question":"Choose the antonym of 'frugal'.", "choices":["thrifty", "lavish", "economical", "sparing"], "answer":1, "explanation":"'Lavish' is opposite of frugal."},
    {"id":236, "question":"If 3/5 of a number is 18, what is the number?", "choices":["30", "25", "20", "15"], "answer":0, "explanation":"Number = 18*(5/3)=30."},
    {"id":237, "question":"Which sentence uses 'its' vs 'it's' correctly?", "choices":["Its a nice day.", "It's collar is red.", "It's a nice day.", "Its' a nice day."], "answer":2, "explanation":"It's = it is."},
    {"id":238, "question":"What is the product of 7 and 8?", "choices":["56", "48", "64", "49"], "answer":0, "explanation":"7*8=56."},
    {"id":239, "question":"Choose the synonym for 'lucid'.", "choices":["clear", "confusing", "murky", "vague"], "answer":0, "explanation":"'Lucid' means clear."},
    {"id":240, "question":"If x + x + x = 12, what is x?", "choices":["3", "4", "6", "12"], "answer":1, "explanation":"3x=12 -> x=4."},
    {"id":241, "question":"Which sentence is grammatically correct?", "choices":["Between you and I, this is secret.", "Between you and me, this is secret.", "Between you and myself, this is secret.", "Between you and mine, this is secret."], "answer":1, "explanation":"Use 'me' as object pronoun."},
    {"id":242, "question":"What is the decimal for 7/20?", "choices":["0.35", "0.7", "0.25", "0.45"], "answer":0, "explanation":"7 ÷ 20 = 0.35."},
    {"id":243, "question":"Choose the antonym of 'ardent'.", "choices":["passionate", "lukewarm", "fervent", "zealous"], "answer":1, "explanation":"'Lukewarm' is opposite of ardent."},
    {"id":244, "question":"If a polygon has 6 sides, what is it called?", "choices":["Pentagon", "Hexagon", "Heptagon", "Octagon"], "answer":1, "explanation":"6-sided polygon is a hexagon."},
    {"id":245, "question":"Which word best completes: The instructions were _____ and easy to follow.", "choices":["ambiguous", "clear", "confusing", "vague"], "answer":1, "explanation":"'Clear' fits context."},
    {"id":246, "question":"What is 2/3 of 90?", "choices":["60", "30", "45", "70"], "answer":0, "explanation":"(2/3)*90=60."},
    {"id":247, "question":"Which sentence uses 'that' correctly?", "choices":["The book that I read was thrilling.", "The book, that I read, was thrilling.", "The book which I read was thrilling.", "The book who I read was thrilling."], "answer":0, "explanation":"Restrictive clause uses 'that'."},
    {"id":248, "question":"If 8x + 2 = 50, what is x?", "choices":["6", "5", "4", "8"], "answer":0, "explanation":"8x=48 -> x=6."},
    {"id":249, "question":"Choose the synonym for 'meticulous'.", "choices":["careless", "thorough", "hasty", "sloppy"], "answer":1, "explanation":"'Meticulous' means very careful and thorough."},
    {"id":250, "question":"What is the perimeter of an equilateral triangle with side 7?", "choices":["21", "14", "7", "28"], "answer":0, "explanation":"Perimeter = 3*7 = 21."},
    {"id":251, "question":"Which sentence is concise and correct?", "choices":["In spite of the fact that it rained, we went.", "Although it rained, we went.", "Because of the fact that it rained, we went.", "It rained, and so we went."], "answer":1, "explanation":"Option 2 is concise."},
    {"id":252, "question":"If x = 2 and y = 3, what is xy + x?", "choices":["8", "7", "6", "5"], "answer":0, "explanation":"2*3 + 2 = 8."},
    {"id":253, "question":"Which word best completes: The judge's ruling was _____ by precedent.", "choices":["unsupported", "guided", "ignored", "contradicted"], "answer":1, "explanation":"'Guided' fits by precedent."},
    {"id":254, "question":"What is the value of 5^3?", "choices":["125", "15", "25", "75"], "answer":0, "explanation":"5^3 = 125."},
    {"id":255, "question":"Choose the antonym of 'benevolent'.", "choices":["kind", "malevolent", "charitable", "generous"], "answer":1, "explanation":"Malevolent = harmful intent."},
    {"id":256, "question":"If 1/5 of a number is 6, what is the number?", "choices":["30", "25", "6", "5"], "answer":0, "explanation":"Number = 6*5 = 30."},
    {"id":257, "question":"Which sentence uses 'who' correctly?", "choices":["Who did you see?", "Whom did you see?", "Who did you give it to?", "Who did you give it?"], "answer":1, "explanation":"Object form 'whom' is correct for 'did you see'."},
    {"id":258, "question":"What is the area of a triangle with base 14 and height 10?", "choices":["70", "140", "24", "28"], "answer":0, "explanation":"Area = 1/2 * 14 * 10 = 70."},
    {"id":259, "question":"Choose the synonym for 'ephemeral'.", "choices":["permanent", "fleeting", "enduring", "lasting"], "answer":1, "explanation":"'Ephemeral' = short-lived."},
    {"id":260, "question":"If x + 2 = 9, what is x?", "choices":["7", "11", "5", "9"], "answer":0, "explanation":"x=7."},
    {"id":261, "question":"Which sentence is punctuated correctly?", "choices":["I like apples, and oranges.", "I like apples and, oranges.", "I like apples and oranges.", "I like, apples and oranges."], "answer":2, "explanation":"No comma needed between two items."},
    {"id":262, "question":"What is 3^4?", "choices":["81", "64", "27", "12"], "answer":0, "explanation":"3^4 = 81."},
    {"id":263, "question":"Choose the antonym of 'ardent'.", "choices":["fervent", "lukewarm", "zealous", "passionate"], "answer":1, "explanation":"'Lukewarm' is opposite."},
    {"id":264, "question":"If a = 10 and b = 2, what is a/b?", "choices":["5", "20", "8", "12"], "answer":0, "explanation":"10/2=5."},
    {"id":265, "question":"Which word best completes: The scientist's claim was _____ by data.", "choices":["refuted", "supported", "ignored", "dismissed"], "answer":1, "explanation":"Supported by data."},
    {"id":266, "question":"What is the sum of the first five positive integers?", "choices":["15", "10", "20", "5"], "answer":0, "explanation":"1+2+3+4+5=15."},
    {"id":267, "question":"Choose the synonym for 'concise'.", "choices":["wordy", "brief", "long", "verbose"], "answer":1, "explanation":"'Concise' = brief."},
    {"id":268, "question":"If 9x = 81, what is x?", "choices":["9", "8", "7", "10"], "answer":0, "explanation":"x=9."},
    {"id":269, "question":"Which sentence uses 'its' correctly?", "choices":["The company increased its profits.", "It's profits increased.", "Its' profits increased.", "The company increased it's profits."], "answer":0, "explanation":"Possessive its is correct."},
    {"id":270, "question":"What is the area of a rectangle with length 5 and width 7?", "choices":["35", "12", "24", "30"], "answer":0, "explanation":"Area = 5*7=35."},
    {"id":271, "question":"Choose the antonym of 'sparse'.", "choices":["plentiful", "scanty", "meager", "thin"], "answer":0, "explanation":"'Plentiful' opposite of sparse."},
    {"id":272, "question":"If x^2 - 4 = 0, what are x values?", "choices":["2 and −2", "2 only", "−2 only", "0"], "answer":0, "explanation":"x=±2."},
    {"id":273, "question":"Which word best completes: The report was _____ with errors.", "choices":["replete", "rife", "sparse", "rare"], "answer":1, "explanation":"'Rife' means abundant (often negative)."},
    {"id":274, "question":"What is 14 + 27?", "choices":["41", "40", "39", "42"], "answer":0, "explanation":"14+27=41."},
    {"id":275, "question":"Choose the synonym for 'ambiguous'.", "choices":["clear", "uncertain", "definite", "explicit"], "answer":1, "explanation":"'Ambiguous' = uncertain."},
    {"id":276, "question":"If 4^2 = ?", "choices":["8", "16", "12", "4"], "answer":1, "explanation":"4^2=16."},
    {"id":277, "question":"Which sentence is correct?", "choices":["He and I went to the store.", "Him and I went to the store.", "He and me went to the store.", "Him and me went to the store."], "answer":0, "explanation":"Subject pronouns 'He and I'."},
    {"id":278, "question":"What is 1/3 as a decimal?", "choices":["0.333...", "0.25", "0.5", "0.75"], "answer":0, "explanation":"1/3 = 0.333... repeating."},
    {"id":279, "question":"Choose the antonym of 'optimistic'.", "choices":["hopeful", "pessimistic", "positive", "sanguine"], "answer":1, "explanation":"'Pessimistic' opposite of optimistic."},
    {"id":280, "question":"If x + 5 = 12, x = ?", "choices":["7", "6", "5", "8"], "answer":0, "explanation":"x=7."},
    {"id":281, "question":"Which word best completes: The lecture was _____ and informative.", "choices":["tedious", "engaging", "boring", "dull"], "answer":1, "explanation":"'Engaging' fits."},
    {"id":282, "question":"What is 18 ÷ 3?", "choices":["6", "9", "3", "12"], "answer":0, "explanation":"18/3=6."},
    {"id":283, "question":"Choose the synonym for 'novice'.", "choices":["expert", "beginner", "master", "pro"], "answer":1, "explanation":"'Novice' = beginner."},
    {"id":284, "question":"If 2x = 14, x = ?", "choices":["7", "6", "8", "14"], "answer":0, "explanation":"x=7."},
    {"id":285, "question":"Which sentence is punctuated correctly?", "choices":["She said, 'Meet me at noon.'", "She said 'Meet me at noon'.", "She said 'Meet me at noon.'", "She said, 'Meet me at noon'."], "answer":0, "explanation":"Comma before quote and period inside."},
    {"id":286, "question":"What is the product of 9 and 9?", "choices":["81", "72", "99", "90"], "answer":0, "explanation":"9*9=81."},
    {"id":287, "question":"Choose the antonym of 'scarce'.", "choices":["abundant", "rare", "sparse", "few"], "answer":0, "explanation":"'Abundant' opposite of scarce."},
    {"id":288, "question":"If a = 5 and b = 2, what is a − b?", "choices":["3", "7", "10", "2"], "answer":0, "explanation":"5−2=3."},
    {"id":289, "question":"Which word best completes: The evidence was _____ and convincing.", "choices":["anecdotal", "compelling", "weak", "irrelevant"], "answer":1, "explanation":"'Compelling' fits."},
    {"id":290, "question":"What is the square root of 81?", "choices":["9", "8", "7", "10"], "answer":0, "explanation":"√81=9."},
    {"id":291, "question":"Choose the synonym for 'arduous'.", "choices":["easy", "difficult", "simple", "light"], "answer":1, "explanation":"'Arduous' = difficult."},
    {"id":292, "question":"If 10x = 100, x = ?", "choices":["10", "100", "1", "0"], "answer":0, "explanation":"x=10."},
    {"id":293, "question":"Which sentence uses 'who' correctly?", "choices":["Who is coming to dinner?", "Whom is coming to dinner?", "Who did you give it to?", "Whom is the subject?"], "answer":0, "explanation":"Subject 'who' is correct."},
    {"id":294, "question":"What is 0.5 as a fraction?", "choices":["1/2", "1/3", "2/3", "1/4"], "answer":0, "explanation":"0.5 = 1/2."},
    {"id":295, "question":"Choose the antonym of 'vivid'.", "choices":["bright", "dull", "clear", "graphic"], "answer":1, "explanation":"'Dull' opposite of vivid."},
    {"id":296, "question":"If a triangle has angles 30° and 60°, what is the third angle?", "choices":["90°", "120°", "30°", "60°"], "answer":0, "explanation":"Sum 180°, third = 90°."},
    {"id":297, "question":"Which word best completes: The plan was _____ and well executed.", "choices":["haphazard", "meticulous", "sloppy", "random"], "answer":1, "explanation":"'Meticulous' fits well executed."},
    {"id":298, "question":"What is 25% of 80?", "choices":["20", "25", "15", "10"], "answer":0, "explanation":"0.25*80=20."},
    {"id":299, "question":"Choose the synonym for 'lucid'.", "choices":["clear", "murky", "obscure", "vague"], "answer":0, "explanation":"'Lucid' = clear."},
    {"id":300, "question":"If x = 0, what is x^2 + x + 1?", "choices":["1", "0", "2", "−1"], "answer":0, "explanation":"0+0+1=1."},
    {"id":301, "question":"Which sentence is grammatically correct?", "choices":["She and he are friends.", "Her and him are friends.", "She and him are friends.", "Her and he are friends."], "answer":0, "explanation":"Subject pronouns 'She and he'."},
    {"id":302, "question":"What is 6 × 7?", "choices":["42", "36", "48", "40"], "answer":0, "explanation":"6*7=42."},
    {"id":303, "question":"Choose the antonym of 'transparent'.", "choices":["clear", "opaque", "see-through", "lucid"], "answer":1, "explanation":"'Opaque' opposite of transparent."},
    {"id":304, "question":"If 3 + 4 = ?", "choices":["7", "12", "1", "11"], "answer":0, "explanation":"3+4=7."},
    {"id":305, "question":"Which word best completes: The results were _____ and unexpected.", "choices":["predictable", "surprising", "ordinary", "expected"], "answer":1, "explanation":"'Surprising' fits unexpected."},
    {"id":306, "question":"What is the perimeter of a square with side 6?", "choices":["24", "12", "36", "18"], "answer":0, "explanation":"Perimeter = 4*6=24."},
    {"id":307, "question":"Choose the synonym for 'diligent'.", "choices":["lazy", "hardworking", "careless", "idle"], "answer":1, "explanation":"'Diligent' = hardworking."},
    {"id":308, "question":"If x = 5, what is 2x + 3?", "choices":["13", "10", "8", "5"], "answer":0, "explanation":"2*5+3=13."},
    {"id":309, "question":"Which sentence uses 'their' correctly?", "choices":["Their house is large.", "They're house is large.", "There house is large.", "Their's house is large."], "answer":0, "explanation":"Possessive 'their' is correct."},
    {"id":310, "question":"What is 4! ?", "choices":["24", "12", "16", "6"], "answer":0, "explanation":"4!=4*3*2*1=24."},
    {"id":311, "question":"Choose the antonym of 'serene'.", "choices":["calm", "tranquil", "agitated", "peaceful"], "answer":2, "explanation":"'Agitated' opposite of serene."},
    {"id":312, "question":"If 2/7 of a number is 10, what is the number?", "choices":["35", "14", "20", "70"], "answer":0, "explanation":"Number = 10*(7/2)=35."},
    {"id":313, "question":"Which word best completes: The committee's decision was _____ unanimous.", "choices":["nearly", "completely", "rarely", "seldom"], "answer":1, "explanation":"'Completely unanimous' fits."},
    {"id":314, "question":"What is the value of 3^3?", "choices":["27", "9", "6", "81"], "answer":0, "explanation":"3^3=27."},
    {"id":315, "question":"Choose the synonym for 'concise'.", "choices":["brief", "wordy", "long", "verbose"], "answer":0, "explanation":"'Concise' = brief."},
    {"id":316, "question":"If x − 2 = 0, x = ?", "choices":["2", "0", "−2", "1"], "answer":0, "explanation":"x=2."},
    {"id":317, "question":"Which sentence is punctuated correctly?", "choices":["Yes, I will go.", "Yes I will go.", "Yes I, will go.", "Yes; I will go."], "answer":0, "explanation":"Comma after interjection 'Yes' is common."},
    {"id":318, "question":"What is 15 × 2?", "choices":["30", "25", "20", "35"], "answer":0, "explanation":"15*2=30."},
    {"id":319, "question":"Choose the antonym of 'vigilant'.", "choices":["alert", "watchful", "careless", "attentive"], "answer":2, "explanation":"'Careless' opposite of vigilant."},
    {"id":320, "question":"If 5 + x = 12, x = ?", "choices":["7", "6", "5", "12"], "answer":0, "explanation":"x=7."},
    {"id":321, "question":"Which word best completes: The data were _____ and supported the claim.", "choices":["inconclusive", "robust", "weak", "insufficient"], "answer":1, "explanation":"'Robust' supports claim."},
    {"id":322, "question":"What is the square of 12?", "choices":["144", "124", "132", "120"], "answer":0, "explanation":"12^2=144."},
    {"id":323, "question":"Choose the synonym for 'ardent'.", "choices":["lukewarm", "passionate", "indifferent", "cool"], "answer":1, "explanation":"'Ardent' = passionate."},
    {"id":324, "question":"If x/2 = 9, x = ?", "choices":["18", "11", "9", "4.5"], "answer":0, "explanation":"x=18."},
    {"id":325, "question":"Which sentence uses 'who' correctly?", "choices":["Who is responsible?", "Whom is responsible?", "Who did you give it whom?", "Whom is the subject?"], "answer":0, "explanation":"Subject 'who' is correct."},
    {"id":326, "question":"What is 0.2 as a fraction?", "choices":["1/5", "1/4", "2/5", "1/3"], "answer":0, "explanation":"0.2 = 1/5."},
    {"id":327, "question":"Choose the antonym of 'gregarious'.", "choices":["sociable", "shy", "outgoing", "friendly"], "answer":1, "explanation":"'Shy' opposite of gregarious."},
    {"id":328, "question":"If a = 7 and b = 3, what is a mod b (remainder)?", "choices":["1", "2", "0", "3"], "answer":0, "explanation":"7 ÷ 3 remainder 1."},
    {"id":329, "question":"Which word best completes: The proposal was _____ by the board.", "choices":["approved", "ignored", "rejected", "forgotten"], "answer":0, "explanation":"'Approved' fits."},
    {"id":330, "question":"What is 2 + 2 × 2?", "choices":["8", "6", "4", "2"], "answer":1, "explanation":"Order: 2*2=4; 2+4=6."},
    {"id":331, "question":"Choose the synonym for 'malleable'.", "choices":["rigid", "flexible", "hard", "brittle"], "answer":1, "explanation":"'Malleable' = flexible."},
    {"id":332, "question":"If x^2 = 25, x = ?", "choices":["5", "−5", "5 and −5", "0"], "answer":2, "explanation":"x=±5."},
    {"id":333, "question":"Which sentence is grammatically correct?", "choices":["Neither answer is correct.", "Neither answers is correct.", "Neither answer are correct.", "Neither answers are correct."], "answer":0, "explanation":"Singular 'neither' with singular verb."},
    {"id":334, "question":"What is 3 × 11?", "choices":["33", "34", "31", "30"], "answer":0, "explanation":"3*11=33."},
    {"id":335, "question":"Choose the antonym of 'benign'.", "choices":["harmless", "malignant", "kind", "gentle"], "answer":1, "explanation":"'Malignant' opposite of benign."},
    {"id":336, "question":"If 1/2 + 1/3 = ?", "choices":["5/6", "2/5", "1/5", "3/6"], "answer":0, "explanation":"1/2+1/3=3/6+2/6=5/6."},
    {"id":337, "question":"Which word best completes: The instructions were _____ and easy to follow.", "choices":["clear", "vague", "confusing", "ambiguous"], "answer":0, "explanation":"'Clear' fits."},
    {"id":338, "question":"What is the perimeter of a rectangle 4 by 9?", "choices":["26", "36", "13", "18"], "answer":0, "explanation":"2*(4+9)=26."},
    {"id":339, "question":"Choose the synonym for 'ephemeral'.", "choices":["lasting", "fleeting", "permanent", "enduring"], "answer":1, "explanation":"'Ephemeral' = fleeting."},
    {"id":340, "question":"If x = 3, what is x^3?", "choices":["27", "9", "6", "3"], "answer":0, "explanation":"3^3=27."},
    {"id":341, "question":"Which sentence is punctuated correctly?", "choices":["I like coffee, tea, and milk.", "I like coffee tea and milk.", "I like coffee, tea and, milk.", "I like, coffee, tea and milk."], "answer":0, "explanation":"Oxford comma used correctly."},
    {"id":342, "question":"What is 20% of 150?", "choices":["30", "25", "20", "35"], "answer":0, "explanation":"0.2*150=30."},
    {"id":343, "question":"Choose the antonym of 'ardent'.", "choices":["passionate", "lukewarm", "zealous", "fervent"], "answer":1, "explanation":"'Lukewarm' opposite."},
    {"id":344, "question":"If 2x + 3x = 25, x = ?", "choices":["5", "10", "25", "2"], "answer":0, "explanation":"5x=25 -> x=5."},
    {"id":345, "question":"Which word best completes: The experiment was _____ and reproducible.", "choices":["flawed", "rigorous", "random", "weak"], "answer":1, "explanation":"'Rigorous' fits reproducible."},
    {"id":346, "question":"What is the value of 50 ÷ 5?", "choices":["10", "5", "15", "8"], "answer":0, "explanation":"50/5=10."},
    {"id":347, "question":"Choose the synonym for 'lucid'.", "choices":["clear", "murky", "obscure", "vague"], "answer":0, "explanation":"'Lucid' = clear."},
    {"id":348, "question":"If x = 1/2, what is 1/x?", "choices":["2", "1/2", "0.5", "−2"], "answer":0, "explanation":"1 ÷ (1/2) = 2."},
    {"id":349, "question":"Which sentence is grammatically correct?", "choices":["She is one of those people who always arrive early.", "She is one of those people who always arrives early.", "She is one of those people who always arriving early.", "She is one of those people who always arrived early."], "answer":0, "explanation":"Relative clause modifies 'people' -> plural verb."},
    {"id":350, "question":"What is the sum of angles in a quadrilateral?", "choices":["360°", "180°", "270°", "540°"], "answer":0, "explanation":"Sum of interior angles of quadrilateral = 360°."}
]

# Append MORE_QUESTIONS to the main bank
QUESTION_BANK += MORE_QUESTIONS

# ---------------------------
# TTS helper
# ---------------------------
def speak(text, tts_enabled=True):
    """
    Speak text using system TTS utilities without external Python packages.
    macOS: `say`
    Windows: PowerShell System.Speech
    Linux: `espeak` or `spd-say` if available
    If no TTS tool is available, function returns silently.
    """
    if not tts_enabled or not text:
        return
    try:
        system = platform.system()
        # Shorten very long text for reliability
        max_len = 800
        if len(text) > max_len:
            text = text[:max_len] + "."

        if system == "Darwin" and shutil.which("say"):
            subprocess.run(["say", text], check=False)
            return
        if system == "Windows":
            # Use PowerShell and System.Speech
            safe = text.replace("'", "''")
            ps_cmd = f"Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe}');"
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return
        # Assume Linux/other: try espeak or spd-say
        if shutil.which("espeak"):
            subprocess.run(["espeak", text], check=False)
            return
        if shutil.which("spd-say"):
            subprocess.run(["spd-say", text], check=False)
            return
    except Exception:
        # Fail silently if TTS is not available or an error occurs
        return

# ---------------------------
# Helper functions
# ---------------------------
def format_choices(choices):
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    return "\n".join(f"  {letters[i]}. {choices[i]}" for i in range(len(choices)))

def speak_choices(choices, tts_enabled=False):
    """
    Speak each choice individually with its letter label.
    Example spoken output: "A. three. B. four. C. five."
    """
    if not tts_enabled:
        return
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    parts = []
    for i, choice in enumerate(choices):
        label = letters[i]
        part = f"{label}. {choice}."
        parts.append(part)
    speak(" ".join(parts), tts_enabled=tts_enabled)

def choice_label(index):
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    return letters[index] if index is not None else "No answer"

def get_choice_index_from_input(user_input, num_choices):
    user_input = user_input.strip().upper()
    if not user_input:
        return None
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if user_input in letters[:num_choices]:
        return letters.index(user_input)
    if user_input.isdigit():
        idx = int(user_input) - 1
        if 0 <= idx < num_choices:
            return idx
    return None

def show_immediate_feedback(q, chosen_index, tts_enabled=False):
    correct_idx = q["answer"]
    chosen_label = choice_label(chosen_index) if chosen_index is not None else "No answer"
    correct_label = choice_label(correct_idx)
    if chosen_index is None:
        msg = f"Time's up or no answer provided. Correct answer: {correct_label}."
        print(msg)
    elif chosen_index == correct_idx:
        msg = "Correct!"
        print(msg)
    else:
        msg = f"Incorrect. Your answer: {chosen_label}. Correct answer: {correct_label}."
        print(msg)
    if q.get("explanation"):
        print(f"Explanation: {q['explanation']}")
    # Speak the feedback (short)
    speak(msg, tts_enabled=tts_enabled)

def ask_question(q, question_num=None, per_question_time=None, tts_enabled=False):
    """
    Ask a single question. Returns tuple (is_correct, chosen_index, time_taken).
    Speaks the question and each choice when tts_enabled is True.
    """
    print()
    if question_num is not None:
        header = f"Question {question_num}:"
        print(header)
        speak(header, tts_enabled=tts_enabled)

    print(q["question"])
    speak(q["question"], tts_enabled=tts_enabled)

    # Print choices and speak them
    print(format_choices(q["choices"]))
    speak_choices(q["choices"], tts_enabled=tts_enabled)

    start = time.time()
    chosen_index = None

    if per_question_time is None:
        while chosen_index is None:
            user = input("Your answer (A/B/C/... or 1/2/3/...): ")
            chosen_index = get_choice_index_from_input(user, len(q["choices"]))
            if chosen_index is None:
                print("Invalid input. Try again.")
                speak("Invalid input. Try again.", tts_enabled=tts_enabled)
    else:
        remaining = per_question_time
        print(f"You have {per_question_time} seconds to answer this question.")
        speak(f"You have {per_question_time} seconds to answer this question.", tts_enabled=tts_enabled)
        while chosen_index is None and remaining > 0:
            try:
                print(f"Time remaining: {int(remaining)}s")
                t0 = time.time()
                user = input("Your answer (A/B/C/... or 1/2/3/...): ")
                t1 = time.time()
                chosen_index = get_choice_index_from_input(user, len(q["choices"]))
                if chosen_index is None:
                    print("Invalid input. Try again.")
                    speak("Invalid input. Try again.", tts_enabled=tts_enabled)
                elapsed = t1 - t0
                remaining -= elapsed
            except KeyboardInterrupt:
                print("\nInterrupted by user.")
                sys.exit(0)
        # if timed out, chosen_index remains None

    end = time.time()
    time_taken = end - start
    is_correct = (chosen_index == q["answer"])
    # Immediate feedback
    show_immediate_feedback(q, chosen_index, tts_enabled=tts_enabled)
    return is_correct, chosen_index, time_taken

# ---------------------------
# Main test flow
# ---------------------------
def run_test(question_bank, num_questions=None, timed=False, total_time=None, per_question_time=None, shuffle=True, tts_enabled=False):
    """
    Run the test.
    - num_questions: number of questions to present (None = all)
    - timed: if True, enforce total_time (seconds) for the whole test
    - total_time: seconds for the whole test (used if timed True)
    - per_question_time: seconds allowed per question (overrides total_time for per-question enforcement)
    - shuffle: randomize question order
    - tts_enabled: speak questions and choices when possible
    """
    questions = question_bank.copy()
    if shuffle:
        random.shuffle(questions)

    if num_questions is None or num_questions > len(questions):
        num_questions = len(questions)
    questions = questions[:num_questions]

    start_msg = f"Starting test. Number of questions: {num_questions}"
    print("\n" + start_msg)
    speak(start_msg, tts_enabled=tts_enabled)
    if timed:
        if per_question_time:
            info = f"Per question time limit: {per_question_time} seconds"
        elif total_time:
            info = f"Total time limit: {total_time} seconds"
        else:
            info = "Timed mode enabled but no time limit provided. Running untimed."
        print(info)
        speak(info, tts_enabled=tts_enabled)

    results = []
    test_start = time.time()
    for i, q in enumerate(questions, start=1):
        # check total time remaining if timed and total_time provided
        if timed and total_time and not per_question_time:
            elapsed = time.time() - test_start
            remaining_total = total_time - elapsed
            if remaining_total <= 0:
                print("\nTotal time expired. Ending test.")
                speak("Total time expired. Ending test.", tts_enabled=tts_enabled)
                break
            print(f"\nTotal time remaining: {int(remaining_total)} seconds")
            speak(f"Total time remaining {int(remaining_total)} seconds", tts_enabled=tts_enabled)

        is_correct, chosen_index, time_taken = ask_question(
            q,
            question_num=i,
            per_question_time=per_question_time,
            tts_enabled=tts_enabled
        )
        results.append({
            "question": q,
            "chosen_index": chosen_index,
            "is_correct": is_correct,
            "time_taken": time_taken
        })

        # if total_time is enforced, check again
        if timed and total_time and not per_question_time:
            elapsed = time.time() - test_start
            if elapsed >= total_time:
                print("\nTotal time expired. Ending test.")
                speak("Total time expired. Ending test.", tts_enabled=tts_enabled)
                break

    test_end = time.time()
    total_time_taken = test_end - test_start
    return results, total_time_taken

def summarize_results(results, total_time_taken, tts_enabled=False):
    correct = sum(1 for r in results if r["is_correct"])
    attempted = sum(1 for r in results if r["chosen_index"] is not None)
    total = len(results)
    percent = (correct / total * 100) if total > 0 else 0

    print("\n" + "="*40)
    print("Test Summary")
    print(f"Total questions presented: {total}")
    print(f"Attempted: {attempted}")
    print(f"Correct: {correct}")
    print(f"Score percent: {percent:.1f}%")
    print(f"Total time taken: {int(total_time_taken)} seconds")
    print("="*40)

    summary_msg = f"Test complete. You answered {correct} out of {total} correctly. Score {percent:.1f} percent."
    speak(summary_msg, tts_enabled=tts_enabled)

    # Detailed review
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    print("\nReview")
    for idx, r in enumerate(results, start=1):
        q = r["question"]
        chosen = r["chosen_index"]
        correct_idx = q["answer"]
        chosen_label = letters[chosen] if chosen is not None else "No answer"
        correct_label = letters[correct_idx]
        status = "Correct" if r["is_correct"] else "Incorrect"
        print(f"\n{idx}. {q['question']}")
        print(format_choices(q["choices"]))
        print(f"Your answer: {chosen_label}")
        print(f"Correct answer: {correct_label}")
        print(f"Result: {status}")
        if q.get("explanation"):
            print(f"Explanation: {q['explanation']}")

# ---------------------------
# CLI entry point with repeat/quit loop
# ---------------------------
def main():
    print("Welcome to the SAT Test Emulator")
    try:
        while True:
            # Gather test settings each run so user can change between repeats
            try:
                num_q = input(f"\nHow many questions would you like (1-{len(QUESTION_BANK)} or press Enter for all): ").strip()
                num_q = int(num_q) if num_q else None
            except ValueError:
                num_q = None

            timed = False
            total_time = None
            per_question_time = None
            use_timing = input("Enable timing? (y/N): ").strip().lower()
            if use_timing == "y":
                timed = True
                mode = input("Use total time for the whole test or per question? (total/per): ").strip().lower()
                if mode == "per":
                    try:
                        per_question_time = int(input("Seconds per question: ").strip())
                    except ValueError:
                        per_question_time = None
                else:
                    try:
                        total_time = int(input("Total time in seconds: ").strip())
                    except ValueError:
                        total_time = None

            shuffle = input("Shuffle questions? (Y/n): ").strip().lower()
            shuffle_flag = (shuffle != "n")

            # TTS option
            tts_enabled = False
            use_tts = input("Enable TTS (system voice) if available? (y/N): ").strip().lower()
            if use_tts == "y":
                tts_enabled = True
                system = platform.system()
                available = False
                if system == "Darwin" and shutil.which("say"):
                    available = True
                elif system == "Windows":
                    available = True
                elif shutil.which("espeak") or shutil.which("spd-say"):
                    available = True
                if not available:
                    notice = "TTS requested but no known system TTS tool found. Program will attempt to speak but may be silent."
                    print(notice)
                    speak(notice, tts_enabled=tts_enabled)

            results, total_time_taken = run_test(
                QUESTION_BANK,
                num_questions=num_q,
                timed=timed,
                total_time=total_time,
                per_question_time=per_question_time,
                shuffle=shuffle_flag,
                tts_enabled=tts_enabled
            )

            summarize_results(results, total_time_taken, tts_enabled=tts_enabled)

            # Repeat or quit prompt
            while True:
                again = input("\nWould you like to take another test? (Y to repeat / Q to quit): ").strip().lower()
                if again in ("y", "yes", ""):
                    break  # outer while True continues and restarts test
                elif again in ("q", "quit", "n", "no"):
                    farewell = "Thanks for practicing. Good luck!"
                    print("\n" + farewell)
                    speak(farewell, tts_enabled=tts_enabled)
                    return
                else:
                    print("Please enter Y to repeat or Q to quit.")
    except KeyboardInterrupt:
        print("\n\nInterrupted. Exiting. Goodbye.")
        sys.exit(0)

if __name__ == "__main__":
    main()
