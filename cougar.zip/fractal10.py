# shape_fractal_branch.py
# Tkinter fractal generator with branch-like tree and leaf veins
# Run: python shape_fractal_branch.py

import tkinter as tk
from tkinter import ttk
import math
import time

# ---------- View transform ----------
class ViewTransform:
    def __init__(self, scale=1.0, offset_x=0.0, offset_y=0.0):
        self.scale = scale
        self.offset_x = offset_x
        self.offset_y = offset_y

    def world_to_screen(self, x, y):
        sx = x * self.scale + self.offset_x
        sy = y * self.scale + self.offset_y
        return sx, sy

    def screen_to_world(self, sx, sy):
        x = (sx - self.offset_x) / self.scale
        y = (sy - self.offset_y) / self.scale
        return x, y

# ---------- Basic drawing helpers ----------
def draw_polygon_transformed(canvas, transform, pts, color, width=1):
    flat = []
    for x, y in pts:
        sx, sy = transform.world_to_screen(x, y)
        flat.extend([sx, sy])
    canvas.create_polygon(flat, outline=color, fill='', width=width)

def draw_circle_transformed(canvas, transform, cx, cy, r, color, width=1):
    sx, sy = transform.world_to_screen(cx, cy)
    sr = abs(r * transform.scale)
    canvas.create_oval(sx-sr, sy-sr, sx+sr, sy+sr, outline=color, width=width)

def draw_line_transformed(canvas, transform, x1, y1, x2, y2, color, width=1, dash=None):
    sx1, sy1 = transform.world_to_screen(x1, y1)
    sx2, sy2 = transform.world_to_screen(x2, y2)
    if dash:
        canvas.create_line(sx1, sy1, sx2, sy2, fill=color, width=width, dash=dash)
    else:
        canvas.create_line(sx1, sy1, sx2, sy2, fill=color, width=width)

def draw_point_transformed(canvas, transform, x, y, color, size=3):
    sx, sy = transform.world_to_screen(x, y)
    r = max(1, size)
    canvas.create_oval(sx-r, sy-r, sx+r, sy+r, fill=color, outline=color)

def draw_text_transformed(canvas, transform, x, y, text, color, size=10):
    sx, sy = transform.world_to_screen(x, y)
    canvas.create_text(sx, sy, text=text, fill=color, font=("TkDefaultFont", max(6, int(size))))

# ---------- Geometry helpers ----------
def regular_polygon_points(n, radius, cx=0.0, cy=0.0, rotation=0.0):
    pts = []
    for i in range(n):
        theta = 2 * math.pi * i / n + rotation
        x = cx + math.cos(theta) * radius
        y = cy + math.sin(theta) * radius
        pts.append((x, y))
    return pts

def translate_points(pts, dx, dy):
    return [(x + dx, y + dy) for (x, y) in pts]

def scale_points(pts, sx, sy, origin=(0,0)):
    ox, oy = origin
    return [((x-ox)*sx + ox, (y-oy)*sy + oy) for (x, y) in pts]

def rotate_points(pts, angle, origin=(0,0)):
    ox, oy = origin
    c = math.cos(angle)
    s = math.sin(angle)
    out = []
    for (x, y) in pts:
        tx, ty = x-ox, y-oy
        rx = tx*c - ty*s
        ry = tx*s + ty*c
        out.append((rx+ox, ry+oy))
    return out

# ---------- Leaf primitive and vein computation ----------
def make_leaf_points(length, width, curvature=0.6, segments=20):
    pts = []
    for i in range(segments+1):
        t = i / segments
        x = -length + 2*length*t
        profile = math.sin(math.pi * t)
        y = profile * width * (1 - curvature * (abs(t-0.5)*2))
        pts.append((x, y))
    lower = [(x, -y) for (x, y) in reversed(pts)]
    return pts + lower

def compute_leaf_edge_samples(rotated_pts, samples=12):
    ys = []
    miny = min(y for x, y in rotated_pts)
    maxy = max(y for x, y in rotated_pts)
    for i in range(samples+1):
        t = i / samples
        y = miny + (maxy - miny) * t
        ys.append(y)
    lefts = []
    rights = []
    for y in ys:
        left_x = None; right_x = None
        left_dist = 1e9; right_dist = 1e9
        for (x, yy) in rotated_pts:
            d = abs(yy - y)
            if x <= 0 and d < left_dist:
                left_dist = d; left_x = x
            if x >= 0 and d < right_dist:
                right_dist = d; right_x = x
        lefts.append((left_x, y))
        rights.append((right_x, y))
    return lefts, rights

def draw_leaf_with_veins(canvas, transform, center, size, color, depth, scale, reps, nested, show_pattern):
    cx, cy = center
    pts = make_leaf_points(size, size*0.45, curvature=0.6, segments=36)
    rotated = rotate_points(pts, -math.pi/2, origin=(0,0))
    translated = translate_points(rotated, cx, cy)
    draw_polygon_transformed(canvas, transform, translated, color, width=max(1, depth//2+1))

    if show_pattern:
        top = (cx, cy - size)
        bottom = (cx, cy + size)
        draw_line_transformed(canvas, transform, bottom[0], bottom[1], top[0], top[1], color='#8b0000', width=max(1, depth//2+1))
        lefts, rights = compute_leaf_edge_samples(rotated, samples=14)
        for i, ((lx, ly), (rx, ry)) in enumerate(zip(lefts, rights)):
            left_w = (lx + cx, ly + cy)
            right_w = (rx + cx, ry + cy)
            center_w = (0 + cx, ly + cy)
            vein_width = max(1, int((1 + (len(lefts)-i)/len(lefts)) * 0.6))
            draw_line_transformed(canvas, transform, center_w[0], center_w[1], left_w[0], left_w[1], color='#8b0000', width=vein_width)
            draw_line_transformed(canvas, transform, center_w[0], center_w[1], right_w[0], right_w[1], color='#8b0000', width=vein_width)
            draw_point_transformed(canvas, transform, left_w[0], left_w[1], '#8b0000', size=2)
            draw_point_transformed(canvas, transform, right_w[0], right_w[1], '#8b0000', size=2)
        for i, ((lx, ly), (rx, ry)) in enumerate(zip(lefts, rights)):
            frac = i / max(1, len(lefts)-1)
            if 0.15 < frac < 0.95:
                sx = (lx + 0) / 2 + cx
                sy = (ly + cy)
                tx = sx - (0.2 * size) * (1 - frac)
                ty = sy - (0.15 * size) * frac
                draw_line_transformed(canvas, transform, sx, sy, tx, ty, color='#8b0000', width=1)
                sx2 = (rx + 0) / 2 + cx
                tx2 = sx2 + (0.2 * size) * (1 - frac)
                ty2 = sy - (0.15 * size) * frac
                draw_line_transformed(canvas, transform, sx2, sy, tx2, ty2, color='#8b0000', width=1)

    if depth <= 0:
        return
    if nested:
        for i in range(1, reps+1):
            child_size = size * (scale ** i)
            draw_leaf_with_veins(canvas, transform, (cx, cy), child_size, color, depth-1, scale, reps, nested, show_pattern)
    else:
        n = max(1, reps)
        for i in range(1, n+1):
            frac = i / (n+1)
            posy = cy - size * (frac*0.9)
            child_size = size * scale * (0.8 + 0.4*(1-frac))
            for sign in (-1, 1):
                c = (cx + sign*child_size*0.2, posy)
                pts_c = rotate_points(rotated, ( -0.25 + 0.5*frac) * (0.6 - 0.4*frac) * sign, origin=(0,0))
                translated_c = translate_points(pts_c, c[0], c[1])
                draw_polygon_transformed(canvas, transform, translated_c, color, width=max(1, depth//2))
                draw_leaf_with_veins(canvas, transform, c, child_size, color, depth-1, scale, reps, nested, show_pattern)

# ---------- Branch helpers (new) ----------
def _interp_quad(p0, p1, p2, t):
    x = (1-t)**2 * p0[0] + 2*(1-t)*t * p1[0] + t**2 * p2[0]
    y = (1-t)**2 * p0[1] + 2*(1-t)*t * p1[1] + t**2 * p2[1]
    return x, y

def draw_branch(canvas, transform, p0, p1, p2, thickness, color, segments=12):
    pts = [_interp_quad(p0, p1, p2, t/segments) for t in range(segments+1)]
    for i in range(len(pts)-1):
        a = pts[i]; b = pts[i+1]
        frac = i / max(1, len(pts)-2)
        w = max(0.6, thickness * (1 - frac))
        pixel_width = max(1, int(w * transform.scale))
        ax, ay = transform.world_to_screen(a[0], a[1])
        bx, by = transform.world_to_screen(b[0], b[1])
        canvas.create_line(ax, ay, bx, by, fill=color, width=pixel_width, capstyle='round', smooth=True)

# ---------- Tree drawing using curved branches ----------
def draw_tree_with_skeleton(canvas, transform, center, size, color, depth, scale, reps, nested, show_pattern, annotate_angles=False):
    cx, cy = center
    trunk_base = (cx, cy)
    trunk_top = (cx, cy - size)
    ctrl = (cx + size * 0.05, cy - size * 0.45)
    draw_branch(canvas, transform, trunk_base, ctrl, trunk_top, thickness=max(3, size*0.06), color=color, segments=18)

    if show_pattern:
        draw_line_transformed(canvas, transform, trunk_base[0], trunk_base[1], trunk_top[0], trunk_top[1], color='#8b4513', width=1, dash=(4,4))
        draw_point_transformed(canvas, transform, trunk_base[0], trunk_base[1], '#8b4513', size=3)
        draw_point_transformed(canvas, transform, trunk_top[0], trunk_top[1], '#8b4513', size=3)

    if depth <= 0:
        return

    if nested:
        for i in range(1, reps+1):
            child_len = size * (scale ** i)
            draw_tree_with_skeleton(canvas, transform, trunk_top, child_len, color, depth-1, scale, reps, nested, show_pattern, annotate_angles)
        return

    n = max(2, reps)
    for i in range(n):
        frac = i / max(1, n-1)
        angle = math.radians(-50 + frac * 100)
        branch_len = size * (0.45 + 0.35 * (1 - frac)) * scale
        bx = trunk_top[0] + math.cos(angle) * branch_len
        by = trunk_top[1] + math.sin(angle) * branch_len
        midx = trunk_top[0] + math.cos(angle) * (branch_len * 0.45)
        midy = trunk_top[1] + math.sin(angle) * (branch_len * 0.45)
        perp = (-math.sin(angle), math.cos(angle))
        bend = (perp[0] * branch_len * 0.12 * (0.6 - frac*0.4),
                perp[1] * branch_len * 0.12 * (0.6 - frac*0.4))
        ctrl_pt = (midx + bend[0], midy + bend[1])
        thickness = max(1.0, size * 0.06 * (0.8 ** (depth-1)))
        draw_branch(canvas, transform, trunk_top, ctrl_pt, (bx, by), thickness=thickness, color=color, segments=14)

        if show_pattern:
            draw_line_transformed(canvas, transform, trunk_top[0], trunk_top[1], bx, by, color='#8b4513', width=1, dash=(3,5))
            draw_point_transformed(canvas, transform, bx, by, '#8b4513', size=2)
            if annotate_angles:
                deg = int(-math.degrees(angle))
                draw_text_transformed(canvas, transform, (trunk_top[0]+bx)/2, (trunk_top[1]+by)/2 - 6, f"{deg}°", '#8b4513', size=7)

        draw_tree_with_skeleton(canvas, transform, (bx, by), branch_len, color, depth-1, scale, reps, nested, show_pattern, annotate_angles)

# ---------- Other shapes ----------
def draw_fern(canvas, transform, center, size, color, depth, scale, reps, nested):
    cx, cy = center
    stem_top = (cx, cy - size)
    draw_line_transformed(canvas, transform, cx, cy, stem_top[0], stem_top[1], color, width=max(1, depth//2+1))
    if depth <= 0:
        return
    if nested:
        for i in range(1, reps+1):
            child_len = size * (scale ** i)
            draw_fern(canvas, transform, (cx, cy), child_len, color, depth-1, scale, reps, nested)
    else:
        n = max(3, reps)
        for i in range(1, n+1):
            frac = i / (n+1)
            px = cx
            py = cy - size * frac
            l = size * 0.35 * (1 - frac*0.6) * scale
            angle = 0.6 * (1 - frac)
            for sign in (-1, 1):
                lx = px + math.cos(sign*angle) * l
                ly = py + math.sin(sign*angle) * l
                draw_line_transformed(canvas, transform, px, py, lx, ly, color, width=max(1, depth//3+1))
                draw_fern(canvas, transform, (lx, ly), l*0.6, color, depth-1, scale, max(1, reps//2), nested)

def draw_cloud(canvas, transform, center, size, color, depth, scale, reps, nested):
    cx, cy = center
    offsets = [(-0.4, 0), (0.0, -0.15), (0.4, 0)]
    for ox, oy in offsets:
        draw_circle_transformed(canvas, transform, cx + ox*size, cy + oy*size, size*0.45, color, width=max(1, depth//3+1))
    if depth <= 0:
        return
    if nested:
        for i in range(1, reps+1):
            child_size = size * (scale ** i)
            draw_cloud(canvas, transform, (cx, cy), child_size, color, depth-1, scale, reps, nested)
    else:
        n = max(1, reps)
        for k in range(n):
            theta = 2*math.pi*k/n
            nx = cx + math.cos(theta) * size * (0.9 - 0.4*(k%2))
            ny = cy + math.sin(theta) * size * 0.2
            draw_cloud(canvas, transform, (nx, ny), size*scale, color, depth-1, scale, reps, nested)

def draw_flower(canvas, transform, center, size, color, depth, scale, reps, nested):
    cx, cy = center
    petals = max(5, reps+4)
    for i in range(petals):
        theta = 2*math.pi*i/petals
        px = cx + math.cos(theta) * size*0.35
        py = cy + math.sin(theta) * size*0.35
        pet = regular_polygon_points(8, size*0.25, cx=0, cy=0, rotation=theta)
        pet = translate_points(pet, px, py)
        draw_polygon_transformed(canvas, transform, pet, color, width=max(1, depth//2))
    draw_circle_transformed(canvas, transform, cx, cy, size*0.18, color, width=max(1, depth//2))
    if depth <= 0:
        return
    if nested:
        for i in range(1, reps+1):
            child_size = size * (scale ** i)
            draw_flower(canvas, transform, (cx, cy), child_size, color, depth-1, scale, reps, nested)
    else:
        n = max(1, reps)
        for k in range(n):
            theta = 2*math.pi*k/n
            nx = cx + math.cos(theta) * size * (0.9)
            ny = cy + math.sin(theta) * size * (0.9)
            draw_flower(canvas, transform, (nx, ny), size*scale, color, depth-1, scale, reps, nested)

def cauliflower(canvas, transform, center, radius, depth, scale, reps, nested, color):
    cx, cy = center
    if depth < 0 or radius <= 0.5:
        return
    draw_circle_transformed(canvas, transform, cx, cy, radius, color, width=max(1, depth//2 + 1))
    if depth == 0:
        return
    if nested:
        for i in range(1, reps+1):
            child_r = radius * (scale ** i)
            cauliflower(canvas, transform, (cx, cy), child_r, depth-1, scale, reps, nested, color)
    else:
        golden_angle = math.pi * (3 - math.sqrt(5))
        for k in range(reps):
            angle = k * golden_angle + (depth * 0.25)
            radial = (radius - radius*scale) * (0.9 + 0.2 * math.sin(k + depth))
            nx = cx + math.cos(angle) * radial
            ny = cy + math.sin(angle) * radial
            child_r = radius * scale
            cauliflower(canvas, transform, (nx, ny), child_r, depth-1, scale, reps, nested, color)

def fractal_polygon(canvas, transform, center, pts, depth, scale, angle_offset, color, reps, nested):
    cx, cy = center
    if depth < 0:
        return
    translated = translate_points(pts, cx, cy)
    draw_polygon_transformed(canvas, transform, translated, color, width=max(1, depth//2 + 1))
    if depth == 0:
        return
    if nested:
        for i in range(1, reps+1):
            s = scale ** i
            rotated = rotate_points(pts, angle_offset * i, origin=(0,0))
            scaled = scale_points(rotated, s, s, origin=(0,0))
            fractal_polygon(canvas, transform, (cx, cy), scaled, depth-1, scale, angle_offset, color, reps, nested)
    else:
        sx = sum(x for x, y in pts) / len(pts)
        sy = sum(y for x, y in pts) / len(pts)
        centroid = (sx, sy)
        for v in pts:
            vx, vy = v[0] - centroid[0], v[1] - centroid[1]
            base_angle = math.atan2(vy, vx)
            for r in range(max(1, reps)):
                spread = 0.6
                frac = (r - (reps-1)/2) / max(1, reps-1) if reps > 1 else 0.0
                theta = angle_offset + base_angle + frac * spread
                radial_factor = (1 - scale) * (1 + 0.15 * frac)
                new_cx = cx + vx * radial_factor
                new_cy = cy + vy * radial_factor
                scaled = scale_points(pts, scale, scale, origin=centroid)
                rotated = rotate_points(scaled, theta, origin=centroid)
                fractal_polygon(canvas, transform, (new_cx, new_cy), rotated, depth-1, scale, angle_offset*0.9, color, reps, nested)

def fractal_circle(canvas, transform, center, radius, depth, scale, color, reps, nested):
    cx, cy = center
    if depth < 0:
        return
    draw_circle_transformed(canvas, transform, cx, cy, radius, color, width=max(1, depth//2 + 1))
    if depth == 0 or radius * scale < 1:
        return
    if nested:
        for i in range(1, reps+1):
            r = radius * (scale ** i)
            fractal_circle(canvas, transform, (cx, cy), r, depth-1, scale, color, reps, nested)
    else:
        n = max(1, int(reps))
        for k in range(n):
            theta = 2 * math.pi * k / n
            new_cx = cx + (radius - radius*scale) * math.cos(theta)
            new_cy = cy + (radius - radius*scale) * math.sin(theta)
            fractal_circle(canvas, transform, (new_cx, new_cy), radius*scale, depth-1, scale, color, reps, nested)

# ---------- Main application ----------
class FractalApp:
    def __init__(self, root):
        self.root = root
        root.title("Shape Fractal Generator — Branch-like Tree")
        self.transform = ViewTransform(scale=1.0, offset_x=0.0, offset_y=0.0)
        self._drag = {'x':0,'y':0,'panning':False}
        self._last = None
        self.setup_ui()
        self.reset_view()

    def setup_ui(self):
        frm = ttk.Frame(self.root, padding=8)
        frm.grid(row=0, column=0, sticky='nsew')
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)

        ttk.Label(frm, text="Shape").grid(row=0, column=0, sticky='w')
        self.shape_var = tk.StringVar(value='triangle')
        shape_menu = ttk.Combobox(frm, textvariable=self.shape_var,
                                  values=['triangle','square','pentagon','circle','leaf','tree','fern','cloud','flower','cauliflower'],
                                  state='readonly', width=14)
        shape_menu.grid(row=0, column=1, sticky='w')

        ttk.Label(frm, text="Depth").grid(row=1, column=0, sticky='w')
        self.depth_var = tk.IntVar(value=3)
        ttk.Spinbox(frm, from_=0, to=10, textvariable=self.depth_var, width=6).grid(row=1, column=1, sticky='w')

        ttk.Label(frm, text="Repetitions").grid(row=2, column=0, sticky='w')
        self.reps_var = tk.IntVar(value=3)
        ttk.Spinbox(frm, from_=1, to=48, textvariable=self.reps_var, width=6).grid(row=2, column=1, sticky='w')

        ttk.Label(frm, text="Scale").grid(row=3, column=0, sticky='w')
        self.scale_var = tk.DoubleVar(value=0.6)
        ttk.Entry(frm, textvariable=self.scale_var, width=6).grid(row=3, column=1, sticky='w')

        ttk.Label(frm, text="Base size").grid(row=4, column=0, sticky='w')
        self.size_var = tk.IntVar(value=180)
        ttk.Spinbox(frm, from_=10, to=1200, textvariable=self.size_var, width=6).grid(row=4, column=1, sticky='w')

        ttk.Label(frm, text="Color").grid(row=5, column=0, sticky='w')
        self.color_var = tk.StringVar(value='black')
        ttk.Entry(frm, textvariable=self.color_var, width=10).grid(row=5, column=1, sticky='w')

        self.nested_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(frm, text="Nested (concentric children)", variable=self.nested_var).grid(row=6, column=0, columnspan=2, sticky='w')

        self.pattern_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(frm, text="Show Pattern for Tree and Leaf", variable=self.pattern_var).grid(row=7, column=0, columnspan=2, sticky='w')

        self.annotate_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(frm, text="Annotate Branch Angles", variable=self.annotate_var).grid(row=8, column=0, columnspan=2, sticky='w')

        ttk.Button(frm, text="Draw", command=self.on_draw).grid(row=9, column=0, columnspan=2, pady=6)
        ttk.Button(frm, text="Clear", command=self.clear_canvas).grid(row=10, column=0, columnspan=2)

        ttk.Button(frm, text="Zoom In", command=lambda: self.zoom_at_screen(1.2, self.canvas.winfo_width()/2, self.canvas.winfo_height()/2)).grid(row=11, column=0, sticky='we', pady=2)
        ttk.Button(frm, text="Zoom Out", command=lambda: self.zoom_at_screen(1/1.2, self.canvas.winfo_width()/2, self.canvas.winfo_height()/2)).grid(row=11, column=1, sticky='we', pady=2)
        ttk.Button(frm, text="Reset View", command=self.reset_view).grid(row=12, column=0, columnspan=2, sticky='we', pady=2)
        ttk.Button(frm, text="Fit View", command=self.fit_view).grid(row=13, column=0, columnspan=2, sticky='we', pady=2)

        self.canvas = tk.Canvas(self.root, bg='white', width=900, height=700)
        self.canvas.grid(row=0, column=1, sticky='nsew', padx=6, pady=6)
        self.root.columnconfigure(1, weight=1)
        self.root.rowconfigure(0, weight=1)

        # bindings
        self.canvas.bind("<ButtonPress-1>", self.on_button_press)
        self.canvas.bind("<B1-Motion>", self.on_button_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_button_release)
        self.canvas.bind("<MouseWheel>", self.on_mousewheel)
        self.canvas.bind("<Button-4>", self.on_mousewheel)
        self.canvas.bind("<Button-5>", self.on_mousewheel)

        # presets
        preset_frame = ttk.Frame(frm)
        preset_frame.grid(row=14, column=0, columnspan=2, pady=6)
        ttk.Button(preset_frame, text="Leaf Veins", command=lambda: self.quick_preset('leaf',4,3,0.6,220,'#2e8b57',False,True,False)).grid(row=0,column=0)
        ttk.Button(preset_frame, text="Branch-like Tree", command=lambda: self.quick_preset('tree',4,3,0.6,220,'#8b4513',False,True,True)).grid(row=0,column=1)
        ttk.Button(preset_frame, text="Cauliflower", command=lambda: self.quick_preset('cauliflower',4,16,0.45,220,'#2e8b57',False,False,False)).grid(row=0,column=2)

    def quick_preset(self, shape, depth, reps, scale, size, color, nested, show_pattern, annotate):
        self.shape_var.set(shape)
        self.depth_var.set(depth)
        self.reps_var.set(reps)
        self.scale_var.set(scale)
        self.size_var.set(size)
        self.color_var.set(color)
        self.nested_var.set(nested)
        self.pattern_var.set(show_pattern)
        self.annotate_var.set(annotate)
        self.on_draw()

    def clear_canvas(self):
        self.canvas.delete('all')

    def on_draw(self):
        self.clear_canvas()
        shape = self.shape_var.get()
        depth = max(0, int(self.depth_var.get()))
        try:
            scale = float(self.scale_var.get())
        except Exception:
            scale = 0.6
        size = int(self.size_var.get())
        color = self.color_var.get() or 'black'
        reps = max(1, int(self.reps_var.get()))
        nested = bool(self.nested_var.get())
        show_pattern = bool(self.pattern_var.get())
        annotate = bool(self.annotate_var.get())
        self._last = dict(shape=shape, depth=depth, scale=scale, size=size, color=color, reps=reps, nested=nested, show_pattern=show_pattern, annotate=annotate)
        self.redraw()

    def redraw(self):
        self.clear_canvas()
        if not self._last:
            return
        p = self._last
        world_center = (0.0, 0.0)
        shape = p['shape']
        if shape == 'cauliflower':
            cauliflower(self.canvas, self.transform, world_center, p['size'], p['depth'], p['scale'], p['reps'], p['nested'], p['color'])
        elif shape == 'circle':
            fractal_circle(self.canvas, self.transform, world_center, p['size'], p['depth'], p['scale'], p['color'], p['reps'], p['nested'])
        elif shape in ('triangle','square','pentagon'):
            if shape == 'triangle':
                n = 3; rot = -math.pi/2
            elif shape == 'square':
                n = 4; rot = math.pi/4
            else:
                n = 5; rot = -math.pi/2
            base_pts = regular_polygon_points(n, p['size'], cx=0, cy=0, rotation=rot)
            fractal_polygon(self.canvas, self.transform, world_center, base_pts, p['depth'], p['scale'], angle_offset=0.3, color=p['color'], reps=p['reps'], nested=p['nested'])
        elif shape == 'leaf':
            draw_leaf_with_veins(self.canvas, self.transform, world_center, p['size'], p['color'], p['depth'], p['scale'], p['reps'], p['nested'], p['show_pattern'])
        elif shape == 'tree':
            draw_tree_with_skeleton(self.canvas, self.transform, world_center, p['size'], p['color'], p['depth'], p['scale'], p['reps'], p['nested'], p['show_pattern'], p['annotate'])
        elif shape == 'fern':
            draw_fern(self.canvas, self.transform, world_center, p['size'], p['color'], p['depth'], p['scale'], p['reps'], p['nested'])
        elif shape == 'cloud':
            draw_cloud(self.canvas, self.transform, world_center, p['size'], p['color'], p['depth'], p['scale'], p['reps'], p['nested'])
        elif shape == 'flower':
            draw_flower(self.canvas, self.transform, world_center, p['size'], p['color'], p['depth'], p['scale'], p['reps'], p['nested'])
        else:
            fractal_circle(self.canvas, self.transform, world_center, p['size'], p['depth'], p['scale'], p['color'], p['reps'], p['nested'])

    # view helpers
    def reset_view(self):
        w = int(self.canvas['width'])
        h = int(self.canvas['height'])
        self.transform.scale = 1.0
        self.transform.offset_x = w/2
        self.transform.offset_y = h/2
        self.redraw()

    def fit_view(self):
        if not self._last:
            self.reset_view()
            return
        size = self._last.get('size', 180)
        w = int(self.canvas['width'])
        h = int(self.canvas['height'])
        target_pixels = min(w, h) * 0.45
        s = target_pixels / (size * 2) if size > 0 else 1.0
        self.transform.scale = s
        self.transform.offset_x = w/2
        self.transform.offset_y = h/2
        self.redraw()

    def zoom_at_screen(self, factor, sx, sy):
        wx_before, wy_before = self.transform.screen_to_world(sx, sy)
        self.transform.scale *= factor
        self.transform.scale = max(1e-6, min(self.transform.scale, 1e6))
        sx_after, sy_after = self.transform.world_to_screen(wx_before, wy_before)
        self.transform.offset_x += (sx - sx_after)
        self.transform.offset_y += (sy - sy_after)
        self.redraw()

    # mouse handlers
    def on_button_press(self, event):
        self._drag['x'] = event.x
        self._drag['y'] = event.y
        self._drag['panning'] = True

    def on_button_drag(self, event):
        if not self._drag['panning']:
            return
        dx = event.x - self._drag['x']
        dy = event.y - self._drag['y']
        self._drag['x'] = event.x
        self._drag['y'] = event.y
        self.transform.offset_x += dx
        self.transform.offset_y += dy
        self.redraw()

    def on_button_release(self, event):
        self._drag['panning'] = False

    def on_mousewheel(self, event):
        if hasattr(event, 'delta') and event.delta != 0:
            factor = 1.0 + (event.delta / 1200.0)
            if factor <= 0:
                factor = 1.0
            self.zoom_at_screen(factor, event.x, event.y)
        else:
            if event.num == 4:
                self.zoom_at_screen(1.1, event.x, event.y)
            elif event.num == 5:
                self.zoom_at_screen(1/1.1, event.x, event.y)

def main():
    root = tk.Tk()
    app = FractalApp(root)
    def on_start():
        app.reset_view()
    root.after(100, on_start)
    root.mainloop()

if __name__ == '__main__':
    main()
