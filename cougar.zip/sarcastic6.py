#!/usr/bin/env python3
"""
Sarcastic Quote Generator (interactive + CLI) with optional TTS
No external Python packages required.

Usage (CLI):
  python sarcasm.py --seed "very good" --count 5 --tts
  python sarcasm.py --random --count 3
  python sarcasm.py --seed "nice job" --count 10 --out quotes.txt --tts

Usage (interactive):
  python sarcasm.py
  Follow prompts; choose to enable TTS when asked.

Notes:
- TTS uses platform-native commands when available:
  - macOS: `say`
  - Windows: PowerShell System.Speech (built into Windows)
  - Linux: tries `spd-say`, then `espeak`, then `festival` if installed
- If no TTS backend is available the program will still run and print a helpful message.
"""

import argparse
import random
import sys
import os
import traceback
import subprocess
import shlex
import shutil
from typing import List, Optional

# Extended templates
TEMPLATES = [
    "{seed}? Oh sure, because that always ends well.",
    "Fantastic. {seed}. Truly revolutionary.",
    "Right, {seed}. Tell me more about your genius plan.",
    "Wow, {seed}. I can hardly contain my excitement.",
    "Brilliant. {seed}. We should patent that.",
    "Oh good, {seed}. Exactly what the world needed.",
    "Amazing. {seed}. Groundbreaking stuff, really.",
    "Hold on, {seed}. Let me write that down in my 'never' list.",
    "{seed}? Please, spare me the details.",
    "Lovely. {seed}. How original.",
    "Yes, {seed}. Because subtlety is for amateurs.",
    "Perfect. {seed}. Right up there with miracles.",
    "Oh great, {seed}. My day is complete.",
    "Fantastic. {seed}. Said no one ever.",
    "Right, {seed}. That will definitely fix everything.",
    "Wow, {seed}. I didn't realize we were doing miracles today.",
    "If only {seed} could solve world peace.",
    "Sure, {seed}. And while we're at it, let's solve gravity.",
    "Amazing. {seed}. I will file that under 'maybe someday'.",
    "Oh brilliant, {seed}. I can feel the progress already.",
    "Hold the applause for {seed}. We can wait.",
    "Yes, {seed}. Because that worked so well last time.",
    "Perfect. {seed}. Exactly what the instructions warned us about.",
    "Lovely. {seed}. I can feel the improvement from here.",
    "Wow, {seed}. Truly the peak of human achievement.",
    "Right, {seed}. That will age well.",
    "Oh good, {seed}. My expectations were already low.",
    "Fantastic. {seed}. I will pretend to be impressed.",
    "Amazing. {seed}. Tell me more so I can yawn politely.",
    "Sure, {seed}. And then unicorns will deliver it.",
    "Brilliant. {seed}. Because logic is optional.",
    "Oh great, {seed}. That explains everything and nothing.",
    "Yes, {seed}. That makes perfect nonsense.",
    "Perfect. {seed}. Exactly what the manual forbids.",
    "Lovely. {seed}. I can almost hear the facepalm.",
    "Wow, {seed}. I didn't know we were auditioning for 'This Will Fail'.",
    "Right, {seed}. That will definitely be a case study in regret.",
    "Oh good, {seed}. My calendar just cleared for disappointment.",
    "Fantastic. {seed}. I will add it to the 'do not try' list.",
    "Amazing. {seed}. The crowd goes mildly indifferent.",
    "Sure, {seed}. Because complexity is overrated.",
    "Brilliant. {seed}. A+ for effort, F for results.",
    "Oh great, {seed}. I can already see the follow-up apology.",
    "Yes, {seed}. That will go down in history as 'meh'.",
    "If I had a dollar for every time {seed} fixed things, I'd be broke.",
    "Right, {seed}. Tell me how that helps again.",
    "Oh good, {seed}. My standards just dropped a little lower.",
    "Fantastic. {seed}. The crowd politely claps.",
    "Amazing. {seed}. Truly the pinnacle of mediocrity.",
    "Sure, {seed}. Because that never backfires.",
    "Brilliant. {seed}. I will pretend this is clever.",
    "Oh great, {seed}. My optimism just filed for divorce.",
    "Yes, {seed}. That will definitely be on the highlight reel of mistakes.",
    "Right, {seed}. That will age like milk.",
    "Oh good, {seed}. My patience just applied for retirement.",
    "Fantastic. {seed}. I will clap slowly and with suspicion.",
    "Amazing. {seed}. The bar has been politely lowered.",
    "Sure, {seed}. Because nuance is for people who care.",
    "Brilliant. {seed}. A masterclass in 'try and fail'.",
    "Oh great, {seed}. My faith in logic took a hit.",
    "Yes, {seed}. That will definitely be a learning experience for someone else.",
    "If only {seed} came with a refund policy.",
    "Right, {seed}. That will go viral for all the wrong reasons.",
    "Oh good, {seed}. My skepticism just got a workout.",
    "Fantastic. {seed}. I will nod and pretend to understand.",
    "Amazing. {seed}. Truly the height of 'we tried'.",
    "Sure, {seed}. Because that always ends in applause.",
    "Brilliant. {seed}. I will add it to the 'maybe never' folder.",
    "Oh great, {seed}. My sarcasm reserves are replenished.",
    "Yes, {seed}. That will definitely be a case study in 'why'.",
    "Right, {seed}. That will be a hit at the 'what not to do' conference.",
    "Oh good, {seed}. My enthusiasm just took a detour.",
    "Fantastic. {seed}. I will pretend this is strategic.",
    "Amazing. {seed}. The applause is imaginary but heartfelt.",
    "Sure, {seed}. Because that never causes side effects.",
    "Brilliant. {seed}. A textbook example of 'interesting choice'.",
    "Oh great, {seed}. My inner critic just filed a complaint.",
    "Yes, {seed}. That will definitely be remembered for reasons we won't like.",
    "If I could bottle the confidence behind {seed}, I'd sell it as fiction.",
    "Right, {seed}. That will be on the highlight reel of 'what were they thinking'.",
    "Oh good, {seed}. My sense of wonder just rolled its eyes.",
    "Fantastic. {seed}. I will applaud with one eyebrow raised.",
    "Amazing. {seed}. Truly the summit of 'we tried'.",
    "Sure, {seed}. Because that never leads to a follow-up meeting.",
    "Brilliant. {seed}. I will pretend this is the plan.",
    "Oh great, {seed}. My optimism just took a coffee break.",
    "Yes, {seed}. That will definitely be a memorable misstep.",
    "If only {seed} came with a 'works sometimes' label.",
    "Right, {seed}. That will be a bestseller in the 'regrets' section.",
    "Oh good, {seed}. My patience just hit snooze.",
    "Fantastic. {seed}. I will nod like I understand the plot.",
    "Amazing. {seed}. The crowd is mildly entertained.",
    "Sure, {seed}. Because that never requires a redo.",
    "Brilliant. {seed}. A shining example of 'we'll see'.",
    "Oh great, {seed}. My inner voice just sighed dramatically.",
    "Yes, {seed}. That will definitely be a story told at reunions.",
    "If I had a nickel for every time {seed} worked, I'd still be broke.",
    "Right, {seed}. That will be a masterclass in 'not quite'.",
    "Oh good, {seed}. My expectations just took a nap.",
    "Fantastic. {seed}. I will clap politely and then forget it.",
    "Amazing. {seed}. Truly the essence of 'we tried'.",
    "Sure, {seed}. Because that never causes a sequel.",
    "Brilliant. {seed}. I will add it to the 'maybe later' pile.",
    "Oh great, {seed}. My sarcasm detector just exploded.",
    "Yes, {seed}. That will definitely be a lesson for someone else."
]

PREFIXES = ["Oh great,", "Well done,", "Fantastic,", "Lovely,", "Amazing,"]
SUFFIXES = ["Not.", "As if.", "Sure.", "Keep dreaming.", "How original."]

ERROR_LOG = "sarcasm_error.log"


def safe_format(template: str, seed_value: str) -> str:
    try:
        return template.format(seed=seed_value)
    except Exception:
        escaped = template.replace("{", "{{").replace("}", "}}")
        escaped = escaped.replace("{{seed}}", "{seed}")
        try:
            return escaped.format(seed=seed_value)
        except Exception:
            return escaped.replace("{seed}", seed_value)


def generate_variants(seed: Optional[str], count: int = 5) -> List[str]:
    if count <= 0:
        return []
    results = []
    for _ in range(count):
        template = random.choice(TEMPLATES)
        target = seed.strip() if seed and seed.strip() else random.choice(
            ["that idea", "this plan", "your timing", "the decision", "brilliant move"]
        )
        line = safe_format(template, target)
        if random.random() < 0.35:
            line = f"{random.choice(PREFIXES)} {line}"
        if random.random() < 0.25:
            line = f"{line} {random.choice(SUFFIXES)}"
        results.append(line)
    return results


# -------------------------
# TTS utilities (no pip)
# -------------------------
def _run_subprocess(cmd: List[str]) -> bool:
    """Run subprocess command, return True on success."""
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def _speak_mac(text: str) -> bool:
    cmd = ["say", text]
    return _run_subprocess(cmd)


def _speak_windows_powershell(text: str) -> bool:
    # Use System.Speech.Synthesis via PowerShell
    # Build a safe PowerShell command; use single quotes around the script and escape single quotes in text
    safe_text = text.replace("'", "''")
    ps_script = (
        "Add-Type -AssemblyName System.Speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        f"$s.Speak('{safe_text}');"
    )
    cmd = ["powershell", "-NoProfile", "-Command", ps_script]
    return _run_subprocess(cmd)


def _speak_linux(text: str) -> bool:
    # Try spd-say, espeak, festival (in that order)
    if shutil.which("spd-say"):
        return _run_subprocess(["spd-say", text])
    if shutil.which("espeak"):
        return _run_subprocess(["espeak", text])
    if shutil.which("festival"):
        # festival expects input via stdin
        try:
            p = subprocess.Popen(["festival", "--tts"], stdin=subprocess.PIPE)
            p.communicate(input=text.encode("utf-8"))
            return p.returncode == 0
        except Exception:
            return False
    return False


def speak_text(text: str) -> bool:
    """
    Speak text using a platform-native backend if available.
    Returns True if speech was started successfully, False otherwise.
    """
    if not text:
        return False
    platform = sys.platform
    # macOS
    if platform == "darwin":
        if shutil.which("say"):
            return _speak_mac(text)
        return False
    # Windows (win32)
    if platform.startswith("win"):
        # Prefer PowerShell System.Speech (available on modern Windows)
        return _speak_windows_powershell(text)
    # Linux / other Unix
    return _speak_linux(text)


# -------------------------
# I/O, CLI, interactive
# -------------------------
def write_output(path: str, content: str) -> None:
    out_path = os.path.expanduser(path)
    dirpath = os.path.dirname(out_path)
    if dirpath and not os.path.exists(dirpath):
        os.makedirs(dirpath, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content + "\n")


def log_exception(exc: Exception) -> None:
    tb = traceback.format_exc()
    try:
        with open(ERROR_LOG, "a", encoding="utf-8") as logf:
            logf.write("=== Exception ===\n")
            logf.write(tb)
            logf.write("\n")
    except Exception:
        print("Failed to write to error log.", file=sys.stderr)


def parse_args(argv: Optional[List[str]] = None):
    parser = argparse.ArgumentParser(description="Generate sarcastic quotes from a seed phrase or randomly.")
    group = parser.add_mutually_exclusive_group(required=False)
    group.add_argument("--seed", "-s", type=str, help="Seed phrase to base sarcasm on")
    group.add_argument("--random", "-r", action="store_true", help="Generate random sarcastic lines")
    parser.add_argument("--count", "-c", type=int, default=5, help="Number of lines to generate (positive integer)")
    parser.add_argument("--out", "-o", type=str, help="Write output to a text file")
    parser.add_argument("--tts", action="store_true", help="Speak the generated lines using system TTS if available")
    args = parser.parse_args(argv)
    if args.count < 1:
        parser.error("--count must be a positive integer")
    return args


def get_user_input():
    while True:
        seed = input("Enter a seed phrase (or press Enter for random); type 'q' to quit: ").strip()
        if seed.lower() == "q":
            return None, None, None, None
        count_raw = input("How many lines would you like? (default 5): ").strip()
        try:
            count = int(count_raw) if count_raw else 5
            if count < 1:
                print("Count must be a positive integer. Using default 5.")
                count = 5
        except ValueError:
            print("Invalid number; using default count 5.")
            count = 5
        save_raw = input("Save output to a file? Enter path or press Enter to skip: ").strip()
        save_path = save_raw if save_raw else None
        tts_raw = input("Speak the lines? (y/N): ").strip().lower()
        tts = tts_raw == "y"
        return seed if seed else None, count, save_path, tts


def interactive_loop():
    print("Sarcastic Quote Generator — interactive mode. Type 'q' at the seed prompt to quit.")
    while True:
        seed, count, save_path, tts = get_user_input()
        if seed is None and count is None and save_path is None and tts is None:
            print("Goodbye.")
            break
        try:
            lines = generate_variants(seed, count)
            output = "\n".join(lines)
            print("\n" + output + "\n")
            if tts:
                # Speak each line with a short pause
                for line in lines:
                    ok = speak_text(line)
                    if not ok:
                        print("(TTS backend not available; install spd-say/espeak on Linux or enable system TTS.)")
                        break
            if save_path:
                try:
                    write_output(save_path, output)
                    print(f"Saved {len(lines)} lines to {save_path}\n")
                except Exception as e:
                    print(f"Error saving to file: {e}", file=sys.stderr)
                    log_exception(e)
        except Exception as exc:
            print("An unexpected error occurred. See error log for details.", file=sys.stderr)
            log_exception(exc)


def main(argv: Optional[List[str]] = None):
    try:
        # If any CLI args provided, use CLI mode; otherwise start interactive loop.
        if len(sys.argv) > 1:
            args = parse_args(argv)
            # If neither seed nor --random provided, treat as interactive
            if not args.seed and not args.random:
                interactive_loop()
                return
            seed = args.seed if args.seed else None
            lines = generate_variants(seed, args.count)
            output = "\n".join(lines)
            print(output)
            if args.tts:
                # Speak lines; if backend missing, inform user
                any_ok = True
                for line in lines:
                    ok = speak_text(line)
                    if not ok:
                        any_ok = False
                        break
                if not any_ok:
                    print("\nTTS backend not available or failed. On macOS ensure `say` exists; on Linux install `spd-say` or `espeak`; on Windows PowerShell is used.\n")
            if args.out:
                try:
                    write_output(args.out, output)
                    print(f"\nSaved {len(lines)} lines to {args.out}")
                except Exception as e:
                    print(f"\nError saving to file: {e}", file=sys.stderr)
                    log_exception(e)
                    sys.exit(1)
        else:
            interactive_loop()
    except SystemExit:
        raise
    except Exception as exc:
        log_exception(exc)
        print("An unexpected error occurred. Details were written to the error log.", file=sys.stderr)
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
