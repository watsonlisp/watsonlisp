"""
fret_no_pip_strum_length_patterns_top_controls.py
Clickable fretboard prototype using only Python standard library.
Adds a Strum Length control (seconds), selectable list of strumming patterns,
and places the controls above the strings.

Run:
    python fret_no_pip_strum_length_patterns_top_controls.py
"""

import tkinter as tk
import math
import wave
import os
import sys
import tempfile
import subprocess
import time
from array import array
from collections import defaultdict
import threading

# ---------- Configuration ----------
STRINGS = 6
FRETS = 20
FRET_WIDTH = 48
STRING_GAP = 36
LEFT_MARGIN = 60
TOP_MARGIN = 40
DOT_RADIUS = 6

SAMPLE_RATE = 44100
DEFAULT_DURATION = 8.0
MASTER_VOLUME = 0.18

OPEN_FREQS = [82.4069, 110.0000, 146.8324, 196.0000, 246.9417, 329.6276]

# Predefined strumming patterns.
# Each pattern is either "together" (play all at once) or a list of string indices in the order to pluck.
# String indices: 0 = lowest (low E), 5 = highest (high E)
STRUM_PATTERNS = {
    "All Together": "together",
    "Downstroke (low→high)": [0, 1, 2, 3, 4, 5],
    "Upstroke (high→low)": [5, 4, 3, 2, 1, 0],
    "Down-Up (fast)": [0, 1, 2, 3, 4, 5, 5, 4, 3, 2, 1, 0],
    "Arpeggio Slow": [0, 1, 2, 3, 4, 5],
    "Random Roll": "random",
}

def freq_for(string_index, fret):
    return OPEN_FREQS[string_index] * (2 ** (fret / 12.0))

# ---------- Audio synthesis (pure Python) ----------
def synthesize_wav(frequencies, duration=DEFAULT_DURATION, echo=False):
    if not frequencies:
        return None
    n_samples = int(SAMPLE_RATE * max(0.01, duration))
    ang_incs = [2.0 * math.pi * f / SAMPLE_RATE for f in frequencies]
    phases = [0.0] * len(frequencies)
    left = [0.0] * n_samples
    right = [0.0] * n_samples

    for i in range(n_samples):
        t = i / SAMPLE_RATE
        sample_val = 0.0
        for idx in range(len(frequencies)):
            sample_val += 0.8 * math.sin(phases[idx])
            sample_val += 0.15 * math.sin(2 * phases[idx])
            sample_val += 0.05 * math.sin(3 * phases[idx])
            phases[idx] += ang_incs[idx]
            if phases[idx] > 1e6:
                phases[idx] %= (2.0 * math.pi)
        attack = int(0.01 * SAMPLE_RATE)
        env = (i / attack) if i < attack and attack > 0 else 1.0
        # slower decay for longer sustain
        env *= math.exp(-0.6 * t)
        val = sample_val * env
        left[i] = val
        right[i] = val

    max_abs = max(max(abs(x) for x in left), 1e-9)
    scale = (32767.0 * MASTER_VOLUME) / max_abs

    if echo:
        delay_s = 0.12
        delay_samples = int(delay_s * SAMPLE_RATE)
        decay = 0.45
        for i in range(delay_samples, n_samples):
            left[i] += left[i - delay_samples] * decay
            right[i] += right[i - delay_samples] * decay

    tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.wav')
    tmpname = tmp.name
    tmp.close()
    with wave.open(tmpname, 'wb') as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(SAMPLE_RATE)
        frames = array('h')
        for i in range(n_samples):
            li = int(max(-32767, min(32767, left[i] * scale)))
            ri = int(max(-32767, min(32767, right[i] * scale)))
            frames.append(li)
            frames.append(ri)
        wf.writeframes(frames.tobytes())
    return tmpname

def play_wav(path):
    if not path or not os.path.exists(path):
        return
    def cleanup_later(p):
        # keep files long enough for long strums
        time.sleep(30.0)
        try:
            os.remove(p)
        except Exception:
            pass

    if sys.platform.startswith('win'):
        try:
            import winsound
            winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
            threading.Thread(target=cleanup_later, args=(path,), daemon=True).start()
            return
        except Exception:
            pass
    elif sys.platform == 'darwin':
        try:
            subprocess.Popen(['afplay', path])
            threading.Thread(target=cleanup_later, args=(path,), daemon=True).start()
            return
        except Exception:
            pass
    else:
        for cmd in (['paplay', path], ['aplay', path]):
            try:
                subprocess.Popen(cmd)
                threading.Thread(target=cleanup_later, args=(path,), daemon=True).start()
                return
            except Exception:
                continue
    try:
        if sys.platform.startswith('linux'):
            subprocess.Popen(['xdg-open', path])
        elif sys.platform == 'darwin':
            subprocess.Popen(['open', path])
        elif sys.platform.startswith('win'):
            os.startfile(path)
        threading.Thread(target=cleanup_later, args=(path,), daemon=True).start()
    except Exception:
        pass

# Helper to synthesize and play a single pluck (one or more frequencies)
def play_pluck(frequencies, duration, echo):
    wav = synthesize_wav(frequencies, duration=duration, echo=echo)
    if wav:
        play_wav(wav)

# ---------- GUI and interaction ----------
class FretboardApp:
    def __init__(self, root):
        self.root = root
        root.title("Fret — strum patterns + length control")
        # make room above strings for controls
        controls_height = 84
        canvas_width = LEFT_MARGIN + (FRETS + 1) * FRET_WIDTH + 160
        canvas_height = TOP_MARGIN + controls_height + (STRINGS - 1) * STRING_GAP + 120
        self.canvas = tk.Canvas(root, width=canvas_width, height=canvas_height, bg='#1e1e1e')
        self.canvas.pack()
        self.pressed = defaultdict(list)
        self.fret_centers = []
        self.open_strings_play = tk.BooleanVar(value=True)
        self.echo_on = tk.BooleanVar(value=False)
        self.duration_var = tk.DoubleVar(value=DEFAULT_DURATION)
        # pattern selection and speed
        self.pattern_var = tk.StringVar(value="All Together")
        self.pattern_speed_var = tk.DoubleVar(value=0.06)  # seconds between plucks in a pattern

        self.mouse_down = False
        self.strum_start = None

        self._build_fret_centers()
        self._draw_static()
        self.canvas.bind("<Button-1>", self.on_mouse_down)
        self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)
        self.canvas.bind("<B1-Motion>", self.on_mouse_drag)
        root.bind('c', lambda e: self.clear_all())
        root.bind('C', lambda e: self.clear_all())

    def _build_fret_centers(self):
        self.fret_centers = []
        # shift fret centers down by controls area so strings start below controls
        controls_offset = 84  # same as controls_height in __init__
        for s in range(STRINGS):
            row = []
            y = TOP_MARGIN + controls_offset + s * STRING_GAP
            for f in range(FRETS + 1):
                x = LEFT_MARGIN + f * FRET_WIDTH
                row.append((x, y))
            self.fret_centers.append(row)

    def _draw_static(self):
        self.canvas.delete("all")
        controls_offset = 84
        # draw frets and strings shifted down by controls_offset
        for f in range(FRETS + 1):
            x = LEFT_MARGIN + f * FRET_WIDTH
            color = '#c8c8c8' if f == 0 else '#7a7a7a'
            width = 3 if f == 0 else 1
            self.canvas.create_line(x, TOP_MARGIN + controls_offset - 12, x, TOP_MARGIN + controls_offset + (STRINGS - 1) * STRING_GAP + 12, fill=color, width=width)
        for s in range(STRINGS):
            y = TOP_MARGIN + controls_offset + s * STRING_GAP
            self.canvas.create_line(LEFT_MARGIN - 24, y, LEFT_MARGIN + FRETS * FRET_WIDTH + 24, y, fill='#bdbdbd', width=2)
        for f in range(0, FRETS + 1, 4):
            x = LEFT_MARGIN + f * FRET_WIDTH
            self.canvas.create_text(x, TOP_MARGIN + controls_offset + STRINGS * STRING_GAP + 12, text=str(f), fill='#e6e6e6', font=('Arial', 10))

        # Place controls above the strings using positions relative to TOP_MARGIN
        controls_y_top = TOP_MARGIN + 8   # top row of controls (above the fretboard)
        controls_y_second = TOP_MARGIN + 36  # second row of controls (just above the strings)

        # UI widgets (top row)
        self.strum_btn = tk.Button(self.root, text="Strum", command=self.strum_center, bg='#4682b4', fg='white')
        self.canvas.create_window(LEFT_MARGIN + 8, controls_y_top, window=self.strum_btn, anchor='w')

        self.echo_chk = tk.Checkbutton(self.root, text="Echo", variable=self.echo_on, bg='#1e1e1e', fg='white', selectcolor='#1e1e1e')
        self.canvas.create_window(LEFT_MARGIN + 88, controls_y_top, window=self.echo_chk, anchor='w')

        self.open_chk = tk.Checkbutton(self.root, text="Open strings", variable=self.open_strings_play, bg='#1e1e1e', fg='white', selectcolor='#1e1e1e')
        self.canvas.create_window(LEFT_MARGIN + 168, controls_y_top, window=self.open_chk, anchor='w')

        self.clear_btn = tk.Button(self.root, text="Clear (C)", command=self.clear_all)
        self.canvas.create_window(LEFT_MARGIN + 280, controls_y_top, window=self.clear_btn, anchor='w')

        # Strum length controls (second row)
        self.canvas.create_text(LEFT_MARGIN + 8, controls_y_second, text="Strum Length (s)", fill='#e6e6e6', anchor='w', font=('Arial', 10))
        self.length_scale = tk.Scale(self.root, from_=0.1, to=60.0, resolution=0.05, orient='horizontal', variable=self.duration_var, length=320, bg='#1e1e1e', fg='white', troughcolor='#333333')
        self.canvas.create_window(LEFT_MARGIN + 140, controls_y_second, window=self.length_scale, anchor='w')
        self.length_entry = tk.Entry(self.root, width=6, textvariable=self.duration_var)
        self.length_entry.bind("<Return>", self.on_length_entry)
        self.canvas.create_window(LEFT_MARGIN + 480, controls_y_second, window=self.length_entry, anchor='w')

        # Strumming pattern controls (second row)
        self.canvas.create_text(LEFT_MARGIN + 8, controls_y_second + 28, text="Strum Pattern", fill='#e6e6e6', anchor='w', font=('Arial', 10))
        pattern_menu = tk.OptionMenu(self.root, self.pattern_var, *STRUM_PATTERNS.keys())
        pattern_menu.config(bg='#1e1e1e', fg='white')
        self.canvas.create_window(LEFT_MARGIN + 120, controls_y_second + 28, window=pattern_menu, anchor='w')

        self.canvas.create_text(LEFT_MARGIN + 300, controls_y_second + 28, text="Pattern Speed (s)", fill='#e6e6e6', anchor='w', font=('Arial', 10))
        self.speed_scale = tk.Scale(self.root, from_=0.01, to=0.5, resolution=0.01, orient='horizontal', variable=self.pattern_speed_var, length=200, bg='#1e1e1e', fg='white', troughcolor='#333333')
        self.canvas.create_window(LEFT_MARGIN + 420, controls_y_second + 28, window=self.speed_scale, anchor='w')

        self._draw_dots()

    def _draw_dots(self):
        self.canvas.delete("dot")
        for s in range(STRINGS):
            for f in self.pressed[s]:
                x, y = self.fret_centers[s][f]
                self.canvas.create_oval(x - DOT_RADIUS, y - DOT_RADIUS, x + DOT_RADIUS, y + DOT_RADIUS,
                                        fill='#ffc84d', outline='black', width=1, tags="dot")

    def hit_test_fret(self, mx, my):
        for s in range(STRINGS):
            for f in range(FRETS + 1):
                x, y = self.fret_centers[s][f]
                if (mx - x) ** 2 + (my - y) ** 2 <= (DOT_RADIUS * 3) ** 2:
                    return s, f
        return None

    def toggle_dot(self, s, f):
        if f in self.pressed[s]:
            self.pressed[s].remove(f)
        else:
            self.pressed[s].append(f)
        self._draw_dots()

    def on_mouse_down(self, event):
        self.mouse_down = True
        mx, my = event.x, event.y
        hit = self.hit_test_fret(mx, my)
        if hit:
            s, f = hit
            self.toggle_dot(s, f)
        else:
            self.strum_start = (mx, my)

    def on_mouse_drag(self, event):
        mx, my = event.x, event.y
        hit = self.hit_test_fret(mx, my)
        if hit:
            s, f = hit
            if f not in self.pressed[s]:
                self.pressed[s].append(f)
                self._draw_dots()

    def on_mouse_up(self, event):
        mx, my = event.x, event.y
        self.mouse_down = False
        if self.strum_start:
            sx, sy = self.strum_start
            if abs(my - sy) > 8:
                self.strum_at(mx)
            self.strum_start = None

    def on_length_entry(self, event):
        try:
            v = float(self.duration_var.get())
            if v < 0.05:
                v = 0.05
            elif v > 60.0:
                v = 60.0
            self.duration_var.set(v)
            self.length_scale.set(v)
        except Exception:
            self.duration_var.set(DEFAULT_DURATION)
            self.length_scale.set(DEFAULT_DURATION)

    def strum_center(self):
        # center x relative to fret positions
        center_x = LEFT_MARGIN + FRETS * FRET_WIDTH // 2
        self.strum_at(center_x)

    def _gather_string_freqs(self, x_pos):
        """Return list of (string_index, frequency) for the current pressed/open state."""
        string_freqs = []
        for s in range(STRINGS):
            candidates = self.pressed[s]
            if candidates:
                best = min(candidates, key=lambda f: abs(self.fret_centers[s][f][0] - x_pos))
                string_freqs.append((s, freq_for(s, best)))
            else:
                if self.open_strings_play.get():
                    string_freqs.append((s, freq_for(s, 0)))
                else:
                    # skip muted string
                    pass
        return string_freqs

    def strum_at(self, x_pos):
        pattern_name = self.pattern_var.get()
        pattern = STRUM_PATTERNS.get(pattern_name, "together")
        string_freqs = self._gather_string_freqs(x_pos)
        if not string_freqs:
            return

        duration = float(self.duration_var.get())
        echo = self.echo_on.get()
        speed = float(self.pattern_speed_var.get())

        # "together" plays all chosen frequencies at once (original behavior)
        if pattern == "together":
            freqs = [f for (_, f) in string_freqs]
            # play full chord once
            threading.Thread(target=play_pluck, args=(freqs, duration, echo), daemon=True).start()
            return

        # "random" pattern: shuffle the order each time
        if pattern == "random":
            import random
            order = [s for (s, _) in string_freqs]
            random.shuffle(order)
            # map string index to frequency
            freq_map = {s: f for (s, f) in string_freqs}
            # play each string in shuffled order
            def play_sequence():
                for s in order:
                    f = freq_map.get(s)
                    if f:
                        # each pluck is a short note; keep overall duration for each pluck reasonable
                        pluck_dur = max(0.15, duration * 0.5)
                        play_pluck([f], pluck_dur, echo)
                        time.sleep(speed)
            threading.Thread(target=play_sequence, daemon=True).start()
            return

        # Otherwise pattern is a list of string indices (may include repeats for down-up)
        if isinstance(pattern, list):
            # build a map from string index to frequency (some strings may be muted)
            freq_map = {s: f for (s, f) in string_freqs}
            def play_sequence():
                for idx in pattern:
                    # if the pattern index is out of range or the string is muted, skip
                    f = freq_map.get(idx)
                    if f:
                        # pluck duration: a portion of the overall duration so the chord still sustains
                        pluck_dur = max(0.12, duration * 0.45)
                        play_pluck([f], pluck_dur, echo)
                    time.sleep(speed)
            threading.Thread(target=play_sequence, daemon=True).start()
            return

        # fallback: play together
        freqs = [f for (_, f) in string_freqs]
        threading.Thread(target=play_pluck, args=(freqs, duration, echo), daemon=True).start()

    def clear_all(self):
        self.pressed.clear()
        self._draw_dots()

def main():
    root = tk.Tk()
    app = FretboardApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
