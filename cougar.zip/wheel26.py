#!/usr/bin/env python3
"""
wheel_of_fortune_auto_next_rounds.py

Tkinter Wheel of Fortune style game with faithful rules and a restored PHRASES list.
Changes applied:
- Avoid blocking modal dialogs when a puzzle is solved so the next round starts automatically.
- Non-modal brief popup used to show winner message.
- Final round restarts the game (prompts for players/rounds again).
- Removed the Next Round button from the UI.
- Ensure controls are re-enabled when a new round starts.
Run:
    python wheel_of_fortune_auto_next_rounds.py
"""
import tkinter as tk
from tkinter import simpledialog, messagebox
import random
import math

# -------------------------
# Configuration
# -------------------------
WHEEL = [
    500, 600, 700, 800, 900, 2500, 500, 600, 700, 800, 900,
    "BANKRUPT", "LOSE A TURN", 500, 600, 700, 800, 900, 500,
]
SEG_COLORS = ["#f7c873", "#f2a65b", "#e86b4a", "#d94b7b", "#9b6bd4", "#6bb7d4"]

# Large PHRASES list (restored)
PHRASES = [
    "A BLESSING IN DISGUISE",
    "A DIME A DOZEN",
    "A PIECE OF CAKE",
    "A PICTURE IS WORTH A THOUSAND WORDS",
    "A STITCH IN TIME SAVES NINE",
    "A WATCHED POT NEVER BOILS",
    "ALL IN GOOD TIME",
    "ALL'S WELL THAT ENDS WELL",
    "BACK TO THE DRAWING BOARD",
    "BARKING UP THE WRONG TREE",
    "BEAT AROUND THE BUSH",
    "BETTER LATE THAN NEVER",
    "BREAK A LEG",
    "BREAK THE ICE",
    "BURST YOUR BUBBLE",
    "BURNING THE MIDNIGHT OIL",
    "CALL IT A DAY",
    "CATCH SOME Z'S",
    "CLOSE BUT NO CIGAR",
    "COLD FEET",
    "CROSS THAT BRIDGE WHEN WE COME TO IT",
    "CUT TO THE CHASE",
    "CUTTING CORNERS",
    "DON'T COUNT YOUR CHICKENS",
    "DON'T JUDGE A BOOK BY ITS COVER",
    "DOWN TO EARTH",
    "EASY DOES IT",
    "EVERY CLOUD HAS A SILVER LINING",
    "FALLING APART AT THE SEAMS",
    "FEELING UNDER THE WEATHER",
    "FIGHT FIRE WITH FIRE",
    "FINDING YOUR FEET",
    "FISH OUT OF WATER",
    "FOR THE BIRDS",
    "GET A TASTE OF YOUR OWN MEDICINE",
    "GET OUT OF HAND",
    "GET THE BALL ROLLING",
    "GIVE SOMEONE THE COLD SHOULDER",
    "GOLDEN OPPORTUNITY",
    "GOING THE EXTRA MILE",
    "GONE WITH THE WIND",
    "HANG IN THERE",
    "HAVE A CHANGE OF HEART",
    "HAVE YOUR CAKE AND EAT IT TOO",
    "HEAD OVER HEELS",
    "HIT THE HAY",
    "HIT THE NAIL ON THE HEAD",
    "HIT THE SACK",
    "HOLD YOUR HORSES",
    "IN THE NICK OF TIME",
    "IT TAKES TWO TO TANGO",
    "JUMP ON THE BANDWAGON",
    "KEEP YOUR CHIN UP",
    "KILL TWO BIRDS WITH ONE STONE",
    "LAUGH OUT LOUD",
    "LET THE CAT OUT OF THE BAG",
    "LIGHT AT THE END OF THE TUNNEL",
    "LIKE A FISH OUT OF WATER",
    "LIVE AND LET LIVE",
    "LOST IN TRANSLATION",
    "MAKE A LONG STORY SHORT",
    "MAKE WAVES",
    "MISS THE BOAT",
    "MONEY DOESN'T GROW ON TREES",
    "NEEDLE IN A HAYSTACK",
    "NO PAIN NO GAIN",
    "NOTHING TO WRITE HOME ABOUT",
    "OFF THE CUFF",
    "ONCE IN A BLUE MOON",
    "ONE STEP AT A TIME",
    "OUT OF THE BLUE",
    "OUT OF THE WOODS",
    "PASS THE BUCK",
    "PICK UP THE PIECES",
    "PIECE OF CAKE",
    "PLAY IT BY EAR",
    "PULLING YOUR LEG",
    "PUT YOUR BEST FOOT FORWARD",
    "RIDE IT OUT",
    "RING A BELL",
    "RUBBER MEETS THE ROAD",
    "RUN OF THE MILL",
    "SAVED BY THE BELL",
    "SAY IT WITH FLOWERS",
    "SCORE ONE FOR THE HOME TEAM",
    "SEE EYE TO EYE",
    "SHOOT FOR THE STARS",
    "SILVER LINING",
    "SLEEP ON IT",
    "SMELL A RAT",
    "SPEAK OF THE DEVIL",
    "SPILL THE BEANS",
    "STAND YOUR GROUND",
    "STEAL THE SHOW",
    "STEP UP TO THE PLATE",
    "STICK TO YOUR GUNS",
    "STONE'S THROW AWAY",
    "STRAIGHT FROM THE HORSE'S MOUTH",
    "TAKE A RAIN CHECK",
    "TAKE IT WITH A GRAIN OF SALT",
    "THE BALL IS IN YOUR COURT",
    "THE BEST OF BOTH WORLDS",
    "THE EARLY BIRD CATCHES THE WORM",
    "THE ELEPHANT IN THE ROOM",
    "THE WHOLE NINE YARDS",
    "THROW IN THE TOWEL",
    "TICKLED PINK",
    "TIME FLIES WHEN YOU'RE HAVING FUN",
    "TOUGH AS NAILS",
    "TURN OVER A NEW LEAF",
    "UNDER THE WEATHER",
    "UP IN THE AIR",
    "WALK A MILE IN MY SHOES",
    "WATER UNDER THE BRIDGE",
    "WHEN PIGS FLY",
    "WHOLE NEW BALLGAME",
    "WILD GOOSE CHASE",
    "YOU CAN SAY THAT AGAIN",
    "YOUR GUESS IS AS GOOD AS MINE",
    "A HOT POTATO",
    "A LEAP OF FAITH",
    "A MATCH MADE IN HEAVEN",
    "A SLAP ON THE WRIST",
    "ALL BARK AND NO BITE",
    "ALL IN A DAY'S WORK",
    "AT THE DROP OF A HAT",
    "BACK TO SQUARE ONE",
    "BAND AID SOLUTION",
    "BARK IS WORSE THAN YOUR BITE",
    "BEAT A DEAD HORSE",
    "BITE THE BULLET",
    "BLOW OFF STEAM",
    "BORN WITH A SILVER SPOON",
    "BURN THE MIDNIGHT OIL",
    "BURY THE HATCHET",
    "CALL THE SHOTS",
    "CATCH SOMEONE RED-HANDED",
    "CHANGE OF HEART",
    "CLEAN SLATE",
    "CLOSE BUT NO CIGAR",
    "COME RAIN OR SHINE",
    "COST AN ARM AND A LEG",
    "CROSS YOUR FINGERS",
    "CUT THE MUSTARD",
    "DANCE TO A DIFFERENT TUNE",
    "DEAD RINGER",
    "DEVIL'S ADVOCATE",
    "DON'T BITE THE HAND THAT FEEDS YOU",
    "DON'T CRY OVER SPILT MILK",
    "DOWN IN THE DUMPS",
    "DRIVE SOMEONE UP THE WALL",
    "EAT HUMBLE PIE",
    "FACE THE MUSIC",
    "FALL OFF THE WAGON",
    "FEATHER IN YOUR CAP",
    "FINE TOOTH COMB",
    "FORGET ME NOT",
    "GET A KICK OUT OF",
    "GET YOUR FEET WET",
    "GIVE THE COLD SHOULDER",
    "GO BACK TO THE DRAWING BOARD",
    "GO THE DISTANCE",
    "GOLDEN RULE",
    "GRAB THE BULL BY THE HORNS",
    "HAVE A FIELD DAY",
    "HAVE A HEART",
    "HEAD IN THE CLOUDS",
    "HEART OF GOLD",
    "HIT THE GROUND RUNNING",
    "HOLD THE FORT",
    "IN HOT WATER",
    "IN THE SAME BOAT",
    "JUMP THE GUN",
    "KEEP YOUR EYE ON THE BALL",
    "KICK THE BUCKET",
    "KNOW THE ROPES",
    "LAID BACK ATTITUDE",
    "LET SLEEPING DOGS LIE",
    "LIFT A FINGER",
    "MAKE WAVES",
    "MIND YOUR P'S AND Q'S",
    "NEVER SAY NEVER",
    "NO STONE UNTURNED",
    "OFF THE RECORD",
    "ON THE BALL",
    "ON THE FENCE",
    "OUT OF LEFT FIELD",
    "OUT OF THE LOOP",
    "PAINT THE TOWN RED",
    "PLAY IT COOL",
    "PUT TWO AND TWO TOGETHER",
    "QUICK ON THE DRAW",
    "RACK YOUR BRAIN",
    "READ BETWEEN THE LINES",
    "RIDE SHOTGUN",
    "RING TRUE",
    "ROLL WITH THE PUNCHES",
    "RUN LIKE THE WIND",
    "SALT OF THE EARTH",
    "SAVE FACE",
    "SAY WHEN",
    "SET IN STONE",
    "SHINE A LIGHT ON",
    "SIT ON THE FENCE",
    "SLEEP LIKE A LOG",
    "SMALL WORLD",
    "SOUND THE ALARM",
    "SPOT ON",
    "STAND TALL",
    "STEP ON IT",
    "STIR THE POT",
    "TAKE THE CAKE",
    "TAKE THE PLUNGE",
    "THE WRITING ON THE WALL",
    "THROW CAUTION TO THE WIND",
    "TIGHTEN THE BELT",
    "TOUGH ROW TO HOE",
    "TURN THE TABLES",
    "UNDER YOUR NOSE",
    "UP THE CREEK",
    "WALK THE TALK",
    "WASTE NOT WANT NOT",
    "WEAR YOUR HEART ON YOUR SLEEVE",
    "WHAT GOES AROUND COMES AROUND",
    "WHEN IT RAINS IT POURS",
    "WHOLE SHEBANG",
    "WONDER OF THE WORLD",
    "WORK LIKE A DOG",
    "WRITE HOME ABOUT",
    "YOU'RE THE BOSS",
    "ZERO HOUR",
    "ZOOM INTO ACTION",
    "A CUT ABOVE",
    "A DROP IN THE OCEAN",
    "A HOUSE OF CARDS",
    "A LEAD PIPE CINCH",
    "A LONG SHOT",
    "A SLICE OF LIFE",
    "ALL HANDS ON DECK",
    "AT YOUR WITS' END",
    "BARK UP THE WRONG TREE",
    "BEAT THE CLOCK",
    "BEND OVER BACKWARDS",
    "BLOW YOUR MIND",
    "BORN YESTERDAY",
    "BRING HOME THE BACON",
    "BRUSH WITH GREATNESS",
    "BURST INTO TEARS",
    "CARRY THE DAY",
    "CATCH SOMEONE'S EYE",
    "CHANGE GEARS",
    "CLEAR THE AIR",
    "CLOSE THE DEAL",
    "COME CLEAN",
    "COSTS AN ARM AND A LEG",
    "CROSS THE LINE",
    "CUT AND DRIED",
    "DEEP POCKETS",
    "DIG YOUR HEELS IN",
    "DROP THE BALL",
    "EAT YOUR HEART OUT",
    "FALL ON DEAF EARS",
    "FOR THE BIRDS",
    "GET DOWN TO BUSINESS",
    "GET THE SHOW ON THE ROAD",
    "GIVE IT A SHOT",
    "GO OUT ON A LIMB",
    "HAVE A BALL",
    "HIT THE JACKPOT",
    "HOLD THE LINE",
    "IN THE DRIVER'S SEAT",
    "JUMP THROUGH HOOPS",
    "KEEP YOUR NOSE TO THE GRINDSTONE",
    "KNOCK IT OUT OF THE PARK",
    "LAY YOUR CARDS ON THE TABLE",
    "LET THE CHIPS FALL WHERE THEY MAY",
    "MAKE ENDS MEET",
    "MIND YOUR OWN BUSINESS",
    "NO TIME TO LOSE",
    "ONCE IN A LIFETIME",
    "OUT OF THE QUESTION",
    "PUT YOUR MONEY WHERE YOUR MOUTH IS",
    "RIDE THE WAVE",
    "ROLL OUT THE RED CARPET",
    "SET THE RECORD STRAIGHT",
    "SINK OR SWIM",
    "SPLIT THE DIFFERENCE",
    "STAND IN GOOD STEAD",
    "TAKE THE WIND OUT OF YOUR SAILS",
    "THE PROOF IS IN THE PUDDING",
    "THROW YOUR HAT IN THE RING",
    "TWO PEAS IN A POD",
    "UNDER THE RADAR",
    "UP FOR GRABS",
    "WALK ON EGGSHELLS",
    "WELL OILED MACHINE",
    "WHAT'S THE BUZZ",
    "WHEN THE RUBBER HITS THE ROAD",
    "WHOLE NEW BALLGAME",
    "WON'T HURT A FLY",
    "WORK AROUND THE CLOCK",
    "YOU'RE KIDDING ME",
    "ZERO TOLERANCE",
]

VOWELS = set("AEIOU")
CONSONANTS = set("BCDFGHJKLMNPQRSTVWXYZ")
VOWEL_COST = 250

# -------------------------
# Utility functions
# -------------------------
def masked_phrase(phrase, revealed):
    out = []
    for ch in phrase:
        if ch == " ":
            out.append("  ")
        elif not ch.isalpha():
            out.append(ch + " ")
        elif ch in revealed:
            out.append(ch + " ")
        else:
            out.append("_ ")
    return "".join(out).rstrip()

def all_revealed(phrase, revealed):
    for ch in phrase:
        if ch.isalpha() and ch not in revealed:
            return False
    return True

# -------------------------
# Player model
# -------------------------
class Player:
    def __init__(self, name):
        self.name = name
        self.round_bank = 0
        self.total_bank = 0
        self.free_spin_tokens = 0

    def bankrupt(self):
        self.round_bank = 0

    def add_cash(self, amount):
        self.round_bank += amount

    def bank_round(self):
        self.total_bank += self.round_bank
        self.round_bank = 0

# -------------------------
# Spinning wheel canvas (visual)
# -------------------------
class SpinningWheel(tk.Canvas):
    def __init__(self, master, values, size=360, **kwargs):
        super().__init__(master, width=size, height=size, bg="white", highlightthickness=0, **kwargs)
        self.size = size
        self.cx = size // 2
        self.cy = size // 2
        self.radius = int(size * 0.42)
        self.values = values[:]
        self.n = len(self.values)
        self.angle = 0.0
        self.pointer = None
        self._draw_wheel()
        self._draw_pointer()

    def _draw_wheel(self):
        self.delete("wheel")
        seg_angle = 360.0 / self.n
        for i, val in enumerate(self.values):
            start = self.angle + i * seg_angle
            end = start + seg_angle
            color = SEG_COLORS[i % len(SEG_COLORS)]
            steps = 6
            pts = [self.cx, self.cy]
            for s in range(steps + 1):
                a = math.radians(start + (s / steps) * (end - start))
                x = self.cx + self.radius * math.cos(a)
                y = self.cy + self.radius * math.sin(a)
                pts.extend([x, y])
            self.create_polygon(pts, fill=color, outline="black", tags="wheel")
            mid = start + seg_angle * 0.5
            tx = self.cx + (self.radius * 0.62) * math.cos(math.radians(mid))
            ty = self.cy + (self.radius * 0.62) * math.sin(math.radians(mid))
            self.create_text(tx, ty, text=str(val), font=("Helvetica", 9, "bold"), tags="wheel")
        r_in = int(self.radius * 0.28)
        self.create_oval(self.cx - r_in, self.cy - r_in, self.cx + r_in, self.cy + r_in,
                         fill="#fff", outline="black", width=2, tags="wheel")

    def _draw_pointer(self):
        if self.pointer:
            self.delete(self.pointer)
        p_w = 18; p_h = 26
        x = self.cx; y = self.cy - self.radius - 6
        pts = [x, y, x - p_w//2, y + p_h, x + p_w//2, y + p_h]
        self.pointer = self.create_polygon(pts, fill="#222", outline="white", tags="pointer")

    def rotate(self, angle):
        self.angle = angle % 360.0
        self._draw_wheel()
        self._draw_pointer()

    def spin(self, on_complete=None):
        spins = random.randint(6, 12)
        target = random.randrange(self.n)
        seg_angle = 360.0 / self.n
        final_angle = 360.0 * spins + (target + 0.5) * seg_angle
        start_angle = self.angle
        duration = 2800
        steps = 80
        dt = max(8, duration // steps)
        for step in range(steps + 1):
            t = step / steps
            ease = 1 - (1 - t) ** 3
            angle = start_angle + (final_angle - start_angle) * ease
            self.after(step * dt, lambda a=angle: self.rotate(a))
        def finish():
            landed = int(((final_angle % 360.0) // seg_angle)) % self.n
            if on_complete:
                on_complete(landed, self.values[landed])
        self.after(duration + 40, finish)

# -------------------------
# Main application
# -------------------------
class WheelOfFortuneApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Wheel of Fortune - Auto Next Rounds")
        self.geometry("1000x700")
        self.resizable(False, False)

        self.players = []
        self.current_idx = 0
        self.guessed = set()
        self.revealed = set()
        self.phrase = ""
        self.last_spin_value = None
        self.must_spin_to_guess = True

        # rounds
        self.current_round = 0
        self.total_rounds = 1

        self._build_ui()
        self._setup_players_and_rounds()
        # Start the first round via _start_round which increments current_round
        self._start_round()

    def _build_ui(self):
        self.puzzle_label = tk.Label(self, text="", font=("Helvetica", 30), wraplength=960, justify="center")
        self.puzzle_label.pack(pady=(10,6))

        main = tk.Frame(self)
        main.pack(fill="x", padx=10, pady=6)

        wheel_frame = tk.Frame(main)
        wheel_frame.pack(side="left", padx=8)
        tk.Label(wheel_frame, text="Wheel", font=("Helvetica", 14)).pack(pady=4)
        self.wheel_canvas = SpinningWheel(wheel_frame, WHEEL, size=420)
        self.wheel_canvas.pack()
        self.spin_btn = tk.Button(wheel_frame, text="Spin Wheel", width=16, command=self.on_spin)
        self.spin_btn.pack(pady=6)

        ctrl = tk.Frame(main)
        ctrl.pack(side="left", padx=12, fill="y")
        tk.Label(ctrl, text="Guess a consonant (after spin):", font=("Helvetica", 12)).pack(anchor="w")
        self.guess_entry = tk.Entry(ctrl, font=("Helvetica", 16), width=6)
        self.guess_entry.pack(anchor="w", pady=6)
        self.guess_btn = tk.Button(ctrl, text="Guess Consonant", width=18, command=self.on_guess)
        self.guess_btn.pack(anchor="w", pady=6)

        self.buy_vowel_btn = tk.Button(ctrl, text=f"Buy Vowel (${VOWEL_COST})", width=18, command=self.on_buy_vowel)
        self.buy_vowel_btn.pack(anchor="w", pady=6)

        self.solve_btn = tk.Button(ctrl, text="Attempt Solve", width=18, command=self.on_solve)
        self.solve_btn.pack(anchor="w", pady=6)

        tk.Label(ctrl, text="Guessed letters:", font=("Helvetica", 12)).pack(anchor="w", pady=(12,0))
        self.guessed_label = tk.Label(ctrl, text="(none)", font=("Helvetica", 12))
        self.guessed_label.pack(anchor="w")

        players_frame = tk.Frame(main)
        players_frame.pack(side="right", padx=8, fill="y")
        tk.Label(players_frame, text="Players", font=("Helvetica", 14)).pack(pady=4)
        self.player_panels = []
        for i in range(4):
            f = tk.Frame(players_frame, relief="groove", bd=2, padx=6, pady=6)
            f.pack(fill="x", pady=4)
            name_lbl = tk.Label(f, text=f"Player {i+1}", font=("Helvetica", 12, "bold"))
            name_lbl.pack(anchor="w")
            round_lbl = tk.Label(f, text="Round: $0", font=("Helvetica", 11))
            round_lbl.pack(anchor="w")
            total_lbl = tk.Label(f, text="Total: $0", font=("Helvetica", 11))
            total_lbl.pack(anchor="w")
            self.player_panels.append((f, name_lbl, round_lbl, total_lbl))

        bottom = tk.Frame(self, pady=8)
        bottom.pack(fill="x")
        self.status_label = tk.Label(bottom, text="Welcome to Wheel of Fortune!", font=("Helvetica", 12))
        self.status_label.pack(side="left", padx=12)
        # Next Round button removed per user request.

    def _setup_players_and_rounds(self):
        n = simpledialog.askinteger("Players", "Number of players (2-4):", minvalue=2, maxvalue=4)
        if not n:
            self.destroy(); return
        for i in range(n):
            name = simpledialog.askstring("Player name", f"Name for player {i+1}:", initialvalue=f"Player{i+1}")
            if not name:
                name = f"Player{i+1}"
            self.players.append(Player(name))
        for i in range(n, 4):
            self.player_panels[i][0].pack_forget()

        rounds = simpledialog.askinteger("Rounds", "How many rounds would you like to play?", initialvalue=3, minvalue=1, maxvalue=10)
        if rounds:
            self.total_rounds = rounds
        else:
            self.total_rounds = 3

    def _start_round(self):
        # increment round counter and check if we have rounds left
        self.current_round += 1
        if self.current_round > self.total_rounds:
            # no more rounds to start; end game (or restart)
            self._end_game()
            return

        # reset puzzle state
        self.guessed.clear()
        self.revealed.clear()
        self.phrase = random.choice(PHRASES).upper()
        for ch in self.phrase:
            if not ch.isalpha():
                self.revealed.add(ch)

        # reset round banks (players keep totals)
        for p in self.players:
            p.round_bank = 0

        self.current_idx = 0
        self.last_spin_value = None
        self.must_spin_to_guess = True
        self._update_ui()
        # Re-enable controls for the new round
        self.spin_btn.config(state="normal")
        self.buy_vowel_btn.config(state="normal")
        self.solve_btn.config(state="normal")
        self.guess_btn.config(state="normal")
        self.status_label.config(text=f"Round {self.current_round}/{self.total_rounds}. {self.players[self.current_idx].name}'s turn — spin the wheel.")

    def _update_ui(self):
        self.puzzle_label.config(text=masked_phrase(self.phrase, self.revealed))
        self.guessed_label.config(text=" ".join(sorted(self.guessed)) if self.guessed else "(none)")
        for i, p in enumerate(self.players):
            _, name_lbl, round_lbl, total_lbl = self.player_panels[i]
            name_lbl.config(text=p.name)
            round_lbl.config(text=f"Round: ${p.round_bank}")
            total_lbl.config(text=f"Total: ${p.total_bank}")
            bg = "#e8f7e8" if i == self.current_idx else self.cget("bg")
            self.player_panels[i][0].config(bg=bg)
            name_lbl.config(bg=bg); round_lbl.config(bg=bg); total_lbl.config(bg=bg)
        self.guess_entry.delete(0, tk.END)
        self.wheel_canvas.rotate(self.wheel_canvas.angle)

    # -------------------------
    # Actions
    # -------------------------
    def on_spin(self):
        self.spin_btn.config(state="disabled")
        self.buy_vowel_btn.config(state="disabled")
        self.solve_btn.config(state="disabled")
        self.guess_btn.config(state="disabled")
        self.wheel_canvas.spin(on_complete=self._on_spin_complete)

    def _on_spin_complete(self, idx, value):
        player = self.players[self.current_idx]
        if value == "BANKRUPT":
            messagebox.showinfo("Wheel", "BANKRUPT! You lose your round bank.")
            player.bankrupt()
            self._advance_turn()
            return
        if value == "LOSE A TURN":
            messagebox.showinfo("Wheel", "LOSE A TURN! Next player.")
            self._advance_turn()
            return
        cash = int(value)
        self.last_spin_value = cash
        self.must_spin_to_guess = False
        self.status_label.config(text=f"{player.name} spun ${cash}. Guess a consonant to earn ${cash} per occurrence.")
        self.guess_entry.focus_set()
        self.guess_btn.config(state="normal")
        self.buy_vowel_btn.config(state="normal")
        self.solve_btn.config(state="normal")
        self.spin_btn.config(state="disabled")

    def on_guess(self):
        if self.must_spin_to_guess:
            messagebox.showinfo("Guess", "You must spin the wheel before guessing a consonant.")
            return
        txt = self.guess_entry.get().strip().upper()
        if not txt or len(txt) != 1 or not txt.isalpha():
            messagebox.showwarning("Guess", "Enter a single letter.")
            return
        letter = txt[0]
        if letter in VOWELS:
            messagebox.showinfo("Guess", "That's a vowel. Use Buy Vowel.")
            return
        if letter in self.guessed:
            messagebox.showinfo("Guess", f"'{letter}' already guessed.")
            return
        self.guessed.add(letter)
        occurrences = self.phrase.count(letter)
        player = self.players[self.current_idx]
        if occurrences > 0:
            gained = occurrences * (self.last_spin_value or 0)
            player.add_cash(gained)
            self.revealed.add(letter)
            # Non-blocking: update status instead of modal dialog
            self.status_label.config(text=f"{letter} appears {occurrences} time(s). {player.name} earned ${gained}.")
            self.must_spin_to_guess = True
            self.last_spin_value = None
            self._update_ui()
            if all_revealed(self.phrase, self.revealed):
                # Schedule non-blocking round-won handling so UI can refresh
                self.after(100, lambda p=player: self._round_won(p))
                return
            self.status_label.config(text=f"{player.name} keeps the turn. Spin again to guess another consonant or buy a vowel.")
            self.spin_btn.config(state="normal")
            self.buy_vowel_btn.config(state="normal")
            self.solve_btn.config(state="normal")
        else:
            messagebox.showinfo("Incorrect", f"{letter} is not in the puzzle.")
            self._advance_turn()

    def on_buy_vowel(self):
        player = self.players[self.current_idx]
        cost = VOWEL_COST
        if player.round_bank < cost:
            messagebox.showinfo("Buy Vowel", f"You need at least ${cost} in your round bank to buy a vowel.")
            return
        letter = simpledialog.askstring("Buy Vowel", f"Enter a vowel (A E I O U). Cost: ${cost}")
        if not letter:
            return
        letter = letter.strip().upper()
        if len(letter) != 1 or letter not in VOWELS:
            messagebox.showinfo("Buy Vowel", "Invalid vowel.")
            return
        if letter in self.guessed:
            messagebox.showinfo("Buy Vowel", f"{letter} already guessed.")
            return
        player.round_bank -= cost
        self.guessed.add(letter)
        occurrences = self.phrase.count(letter)
        if occurrences > 0:
            self.revealed.add(letter)
            # Non-blocking: update status instead of modal dialog
            self.status_label.config(text=f"{letter} appears {occurrences} time(s). {player.name} keeps the turn.")
            self._update_ui()
            if all_revealed(self.phrase, self.revealed):
                self.after(100, lambda p=player: self._round_won(p))
                return
            self.status_label.config(text=f"{player.name} bought {letter}. You may spin or attempt to solve.")
            self.spin_btn.config(state="normal")
            self.solve_btn.config(state="normal")
            self.must_spin_to_guess = True
        else:
            messagebox.showinfo("Vowel", f"No {letter} in the puzzle.")
            self._advance_turn()

    def on_solve(self):
        attempt = simpledialog.askstring("Solve", "Enter your solution:")
        if attempt is None:
            return
        attempt = attempt.strip().upper()
        player = self.players[self.current_idx]
        if attempt == self.phrase:
            # Avoid modal dialog so the next round can start immediately
            self.status_label.config(text=f"{player.name} solved the puzzle correctly.")
            # Schedule non-blocking round-won handling
            self.after(100, lambda p=player: self._round_won(p))
        else:
            messagebox.showinfo("Solve", "Incorrect. You lose your turn.")
            self._advance_turn()

    # -------------------------
    # Turn and round management
    # -------------------------
    def _advance_turn(self):
        self.last_spin_value = None
        self.must_spin_to_guess = True
        self.current_idx = (self.current_idx + 1) % len(self.players)
        self._update_ui()
        self.status_label.config(text=f"{self.players[self.current_idx].name}'s turn — spin the wheel.")
        self.spin_btn.config(state="normal")
        self.buy_vowel_btn.config(state="normal")
        self.solve_btn.config(state="normal")
        self.guess_btn.config(state="normal")

    def _round_won(self, player):
        """
        Bank the round, show a brief non-blocking winner message, then
        automatically advance to the next round (or restart the game) without
        blocking the event loop.
        """
        # Bank the player's round winnings
        player.bank_round()
        self._update_ui()

        # Disable play controls immediately
        self.spin_btn.config(state="disabled")
        self.buy_vowel_btn.config(state="disabled")
        self.solve_btn.config(state="disabled")
        self.guess_btn.config(state="disabled")

        # Update status so user sees the winner immediately
        self.status_label.config(text=f"{player.name} wins Round {self.current_round} and banks ${player.total_bank} total.")

        # Show a small non-modal popup that auto-closes after 800ms
        popup = tk.Toplevel(self)
        popup.title("Round")
        popup.transient(self)
        popup.resizable(False, False)
        tk.Label(popup, text=f"{player.name} wins Round {self.current_round}!", font=("Helvetica", 12)).pack(padx=12, pady=8)
        popup.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - popup.winfo_width()) // 2
        y = self.winfo_y() + (self.winfo_height() - popup.winfo_height()) // 2
        popup.geometry(f"+{x}+{y}")
        # ensure it doesn't block and will close automatically
        self.after(800, popup.destroy)

        # After a short non-blocking delay, proceed to next round or restart
        if self.current_round < self.total_rounds:
            self.after(900, self._start_round)
        else:
            # Final round completed -> restart the game after a short pause
            self.after(900, self._restart_game)

    def _restart_game(self):
        """
        Restart the entire game: clear players and banks, prompt for new players/rounds,
        and start the first round of the new game.
        """
        # Reset UI banks before clearing
        for p in self.players:
            p.round_bank = 0
            p.total_bank = 0
        # Clear players list and reset round counters
        self.players.clear()
        self.current_round = 0
        self.total_rounds = 1
        # Restore player panels (in case some were hidden previously)
        for i in range(4):
            self.player_panels[i][0].pack(fill="x", pady=4)

        self.status_label.config(text="Starting new game...")
        # Prompt for new players and rounds
        self._setup_players_and_rounds()
        # If setup was cancelled, close the app
        if not self.players:
            self.destroy()
            return
        # Start the first round of the new game
        self._start_round()

    def _end_game(self):
        # Determine winner(s) and then restart the game
        max_total = max(p.total_bank for p in self.players) if self.players else 0
        winners = [p for p in self.players if p.total_bank == max_total] if self.players else []
        if winners:
            if len(winners) == 1:
                messagebox.showinfo("Game Over", f"Winner: {winners[0].name} with ${winners[0].total_bank}")
            else:
                names = ", ".join(p.name for p in winners)
                messagebox.showinfo("Game Over", f"Tie between: {names} with ${max_total} each")
        # After showing final results, restart the game
        self._restart_game()

# -------------------------
# Entry point
# -------------------------
if __name__ == "__main__":
    app = WheelOfFortuneApp()
    app.mainloop()
