#!/usr/bin/env python3
"""
Projectile solver with simple drag demo (standard library only)
- No external packages required.
- Closed-form solutions assume no air resistance and y0 = 0.
- A simple numeric quadratic-drag demo runs automatically and uses the provided mass.
- Optionally saves numeric trajectory to CSV.
"""

import math
import csv
import sys

G = 9.80665

def range_from_v0_angle(v0, angle_deg):
    theta = math.radians(angle_deg)
    return (v0**2) * math.sin(2*theta) / G

def v0_from_range_angle(R, angle_deg):
    theta = math.radians(angle_deg)
    s2 = math.sin(2*theta)
    if abs(s2) < 1e-12:
        raise ValueError("sin(2*angle) is zero; cannot solve for v0 with this angle.")
    val = R * G / s2
    if val < 0:
        raise ValueError("No real solution for v0 with given range and angle.")
    return math.sqrt(val)

def angles_from_v0_range(v0, R):
    val = G * R / (v0**2)
    if val < -1 or val > 1:
        return []  # no solution
    two_theta1 = math.asin(val)
    two_theta2 = math.pi - two_theta1
    theta1 = math.degrees(two_theta1 / 2)
    theta2 = math.degrees(two_theta2 / 2)
    if abs(theta1 - theta2) < 1e-9:
        return [theta1]
    return sorted([theta1, theta2])

def prompt_float(prompt_text, allow_empty=False):
    while True:
        s = input(prompt_text).strip()
        if s == "" and allow_empty:
            return None
        try:
            return float(s)
        except ValueError:
            print("  Invalid number. Please try again.")

def simulate_with_drag(mass, v0, angle_deg, y0=0.0, dt=0.001, max_time=60.0,
                       Cd=0.47, rho=1.225, area=0.01):
    """
    Simple numeric integrator with quadratic drag (standard library only).
    Returns lists for x, y, t and approximate impact range and time.
    Cd, rho, and area are generic demo parameters.
    """
    theta = math.radians(angle_deg)
    vx = v0 * math.cos(theta)
    vy = v0 * math.sin(theta)
    x = 0.0
    y = y0
    t = 0.0
    xs = [x]
    ys = [y]
    ts = [t]

    # Safety limits to avoid runaway loops
    max_steps = int(max_time / dt) + 10
    step = 0

    while y >= 0 and t < max_time and step < max_steps:
        v = math.hypot(vx, vy)
        if v != 0:
            Fd = 0.5 * rho * Cd * area * v * v
            ax = - (Fd * (vx / v)) / mass
            ay = -G - (Fd * (vy / v)) / mass
        else:
            ax = 0.0
            ay = -G
        vx += ax * dt
        vy += ay * dt
        x += vx * dt
        y += vy * dt
        t += dt
        xs.append(x)
        ys.append(y)
        ts.append(t)
        step += 1

    # Interpolate to estimate ground impact more accurately if last y < 0
    if len(ys) >= 2 and ys[-1] < 0:
        x_last, y_last, t_last = xs[-2], ys[-2], ts[-2]
        x_now, y_now, t_now = xs[-1], ys[-1], ts[-1]
        denom = (y_last - y_now)
        frac = y_last / denom if denom != 0 else 0.0
        x_ground = x_last + frac * (x_now - x_last)
        t_ground = t_last + frac * (t_now - t_last)
    else:
        x_ground = xs[-1]
        t_ground = ts[-1]

    return {
        "xs": xs,
        "ys": ys,
        "ts": ts,
        "range_approx": x_ground,
        "time_of_flight_approx": t_ground,
        "params": {"Cd": Cd, "rho": rho, "area": area, "dt": dt}
    }

def save_trajectory_csv(xs, ys, ts, filename):
    try:
        with open(filename, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['t_s', 'x_m', 'y_m'])
            for t, x, y in zip(ts, xs, ys):
                writer.writerow([f"{t:.6f}", f"{x:.6f}", f"{y:.6f}"])
        return True
    except Exception as e:
        print("Failed to save CSV:", e)
        return False

def ascii_plot(xs, ys, width=60, height=20):
    """
    Very simple ASCII plot of trajectory scaled to fit width x height.
    Ground is at bottom row. This is only a rough visual aid.
    """
    if not xs or not ys:
        print("(no data to plot)")
        return
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    # ensure ground visible
    min_y = min(min_y, 0.0)
    max_y = max(max_y, 0.1)
    x_span = max_x - min_x if max_x != min_x else 1.0
    y_span = max_y - min_y if max_y != min_y else 1.0

    grid = [[' ' for _ in range(width)] for _ in range(height)]
    for x, y in zip(xs, ys):
        col = int((x - min_x) / x_span * (width - 1))
        row = int((y - min_y) / y_span * (height - 1))
        # invert row so 0 is top
        row = (height - 1) - row
        if 0 <= row < height and 0 <= col < width:
            grid[row][col] = '*'
    # draw ground line at y=0 if within range
    if min_y <= 0 <= max_y:
        ground_row = (height - 1) - int((0 - min_y) / y_span * (height - 1))
        if 0 <= ground_row < height:
            for c in range(width):
                if grid[ground_row][c] == ' ':
                    grid[ground_row][c] = '-'
    for row in grid:
        print(''.join(row))

def main_loop():
    print("Projectile solver with simple drag demo (standard library only)")
    print("Closed-form solutions assume no air resistance and y0 = 0.")
    print("A numeric quadratic-drag demo runs automatically and uses the mass you enter.\n")

    while True:
        print("Choose variable to solve for: v0, angle, range, or type 'exit' to quit.")
        choice = input("Solve for: ").strip().lower()
        if choice in ('exit', 'quit', 'q'):
            print("Exiting. Goodbye.")
            break

        # mass input (required)
        mass_val = None
        while True:
            mass_input = input("Enter projectile mass (kg) [required]: ").strip()
            try:
                mass_val = float(mass_input)
                if mass_val <= 0:
                    print("  Mass must be positive. Try again.")
                    continue
                break
            except ValueError:
                print("  Invalid mass. Please enter a numeric value in kilograms.")

        try:
            if choice in ('range', 'r'):
                v0 = prompt_float("Enter muzzle velocity v0 (m/s): ")
                angle = prompt_float("Enter launch angle (degrees): ")
                R = range_from_v0_angle(v0, angle)
                print(f"\nComputed horizontal range (no drag): {R:.6f} m")

                print("Running numeric drag demo now using your mass and inputs...")
                sim = simulate_with_drag(mass_val, v0, angle)
                print(f"  Approximate range with demo drag: {sim['range_approx']:.3f} m")
                print(f"  Approximate time of flight with demo drag: {sim['time_of_flight_approx']:.3f} s")

                # ASCII preview
                preview = input("Show ASCII preview of trajectory? (Y/n): ").strip().lower()
                if preview not in ('n', 'no'):
                    ascii_plot(sim['xs'], sim['ys'])

                save = input("Save numeric trajectory to CSV? (y/N): ").strip().lower()
                if save == 'y':
                    fname = input("Enter filename (e.g., traj.csv): ").strip() or "trajectory.csv"
                    ok = save_trajectory_csv(sim['xs'], sim['ys'], sim['ts'], fname)
                    print("Saved to", fname if ok else "failed")

            elif choice in ('v0', 'velocity', 'muzzle velocity'):
                angle = prompt_float("Enter launch angle (degrees): ")
                R = prompt_float("Enter horizontal range (m): ")
                v0 = v0_from_range_angle(R, angle)
                print(f"\nComputed muzzle velocity v0 (no drag): {v0:.6f} m/s")

                print("Running numeric drag demo now using your mass and the computed v0...")
                sim = simulate_with_drag(mass_val, v0, angle)
                print(f"  Approximate range with demo drag: {sim['range_approx']:.3f} m")
                print(f"  Approximate time of flight with demo drag: {sim['time_of_flight_approx']:.3f} s")

                preview = input("Show ASCII preview of trajectory? (Y/n): ").strip().lower()
                if preview not in ('n', 'no'):
                    ascii_plot(sim['xs'], sim['ys'])

                save = input("Save numeric trajectory to CSV? (y/N): ").strip().lower()
                if save == 'y':
                    fname = input("Enter filename (e.g., traj.csv): ").strip() or "trajectory.csv"
                    ok = save_trajectory_csv(sim['xs'], sim['ys'], sim['ts'], fname)
                    print("Saved to", fname if ok else "failed")

            elif choice in ('angle', 'theta'):
                v0 = prompt_float("Enter muzzle velocity v0 (m/s): ")
                R = prompt_float("Enter horizontal range (m): ")
                angles = angles_from_v0_range(v0, R)
                if not angles:
                    print("\nNo real launch angle will produce that range with the given v0 (no drag).")
                elif len(angles) == 1:
                    print(f"\nUnique launch angle (no drag): {angles[0]:.6f} degrees")
                else:
                    print("\nTwo possible launch angles (no drag) low and high:")
                    print(f"  0: {angles[0]:.6f} degrees")
                    print(f"  1: {angles[1]:.6f} degrees")

                if angles:
                    choose = input("Run drag demo for which angle? Enter 0 for low, 1 for high, or press Enter for low: ").strip()
                    idx = 0
                    if choose == '1':
                        idx = 1
                    chosen = angles[idx]
                    print(f"\nRunning numeric drag demo for angle = {chosen:.6f}° using your mass and v0...")
                    sim = simulate_with_drag(mass_val, v0, chosen)
                    print(f"  Approximate range with demo drag: {sim['range_approx']:.3f} m")
                    print(f"  Approximate time of flight with demo drag: {sim['time_of_flight_approx']:.3f} s")

                    preview = input("Show ASCII preview of trajectory? (Y/n): ").strip().lower()
                    if preview not in ('n', 'no'):
                        ascii_plot(sim['xs'], sim['ys'])

                    save = input("Save numeric trajectory to CSV? (y/N): ").strip().lower()
                    if save == 'y':
                        fname = input("Enter filename (e.g., traj.csv): ").strip() or "trajectory.csv"
                        ok = save_trajectory_csv(sim['xs'], sim['ys'], sim['ts'], fname)
                        print("Saved to", fname if ok else "failed")

            else:
                print("Unknown choice. Please enter v0, angle, range, or exit.")
                continue

            print(f"\nNote: mass = {mass_val} kg (used in the numeric drag demo).")
            print("Demo drag parameters are generic and for classroom demonstration only.")

        except ValueError as e:
            print("Error:", e)
        except Exception as e:
            print("Unexpected error:", e)

        again = input("\nRun another calculation? (Y/n): ").strip().lower()
        if again in ('n', 'no', 'exit', 'quit', 'q'):
            print("Exiting. Goodbye.")
            break
        print("\n" + "-"*50 + "\n")

if __name__ == "__main__":
    main_loop()
