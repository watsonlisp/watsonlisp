#!/usr/bin/env python3
"""
Interactive F = m * a solver with repeat and quit.
Type q, quit, or exit at any prompt to stop.
"""

import sys

QUIT_COMMANDS = {"q", "quit", "exit"}

def check_quit(s):
    return s.strip().lower() in QUIT_COMMANDS

def get_raw_input(prompt):
    try:
        return input(prompt)
    except (EOFError, KeyboardInterrupt):
        print("\nExiting.")
        sys.exit(0)

def get_number(prompt):
    while True:
        s = get_raw_input(prompt).strip()
        if check_quit(s):
            return None, None
        if not s:
            print("Please enter a value or type q to quit.")
            continue
        parts = s.split()
        try:
            value = float(parts[0])
            unit = " ".join(parts[1:]) if len(parts) > 1 else ""
            return value, unit
        except ValueError:
            print("Invalid number. Try again (you can include units after the number).")

def solve_for(choice):
    if choice == "f":
        m, m_unit = get_number("Enter mass m (e.g. 5 kg): ")
        if m is None:
            return False
        a, a_unit = get_number("Enter acceleration a (e.g. 2 m/s^2): ")
        if a is None:
            return False
        F = m * a
        unit = f"{m_unit}·{a_unit}" if m_unit or a_unit else ""
        print(f"\nResult: F = {F} {unit}".strip())
    elif choice == "m":
        F, F_unit = get_number("Enter force F (e.g. 10 N): ")
        if F is None:
            return False
        a, a_unit = get_number("Enter acceleration a (e.g. 2 m/s^2): ")
        if a is None:
            return False
        if a == 0:
            print("Acceleration a is zero; mass would be infinite or undefined.")
            return True
        m = F / a
        unit = f"{F_unit}/{a_unit}" if F_unit or a_unit else ""
        print(f"\nResult: m = {m} {unit}".strip())
    elif choice == "a":
        F, F_unit = get_number("Enter force F (e.g. 10 N): ")
        if F is None:
            return False
        m, m_unit = get_number("Enter mass m (e.g. 5 kg): ")
        if m is None:
            return False
        if m == 0:
            print("Mass m is zero; acceleration would be infinite or undefined.")
            return True
        a = F / m
        unit = f"{F_unit}/{m_unit}" if F_unit or m_unit else ""
        print(f"\nResult: a = {a} {unit}".strip())
    else:
        print("Unexpected choice.")
    return True

def main():
    print("Interactive F = m * a solver")
    print("Type q, quit, or exit at any prompt to stop.\n")
    while True:
        choice = get_raw_input("Solve for (F/m/a) or q to quit: ").strip().lower()
        if check_quit(choice):
            print("Goodbye.")
            break
        if choice not in ("f", "m", "a"):
            print("Invalid choice. Enter F, m, a, or q to quit.")
            continue
        cont = solve_for(choice)
        if cont is False:
            print("Goodbye.")
            break
        print("\n---\n")

if __name__ == "__main__":
    main()
