# right_triangle_solver_loop.py
import math

def deg_to_rad(d): return math.radians(d)
def rad_to_deg(r): return math.degrees(r)

def solve_from_angle_and_side(angle_deg, side_length, side_type):
    angle = angle_deg
    if angle <= 0 or angle >= 90:
        raise ValueError("Angle must be between 0 and 90 degrees (non-right angle).")
    a_rad = deg_to_rad(angle)

    if side_type == 'hyp':
        hyp = side_length
        opp = hyp * math.sin(a_rad)
        adj = hyp * math.cos(a_rad)
    elif side_type == 'opp':
        opp = side_length
        hyp = opp / math.sin(a_rad)
        adj = math.sqrt(max(hyp*hyp - opp*opp, 0.0))
    elif side_type == 'adj':
        adj = side_length
        hyp = adj / math.cos(a_rad)
        opp = math.sqrt(max(hyp*hyp - adj*adj, 0.0))
    else:
        raise ValueError("side_type must be 'hyp', 'opp', or 'adj'.")

    other_angle = 90.0 - angle
    return {
        'angle_given_deg': angle,
        'other_angle_deg': other_angle,
        'hypotenuse': hyp,
        'opposite': opp,
        'adjacent': adj
    }

def solve_from_two_sides(side1_type, side1, side2_type, side2):
    hyp = opp = adj = None
    for t, v in ((side1_type, side1), (side2_type, side2)):
        if t == 'hyp': hyp = v
        elif t == 'opp': opp = v
        elif t == 'adj': adj = v
        else: raise ValueError("side types must be 'hyp', 'opp', or 'adj'.")

    if hyp is None:
        if opp is None or adj is None:
            raise ValueError("To compute hypotenuse you need opp and adj if hyp is missing.")
        hyp = math.sqrt(opp*opp + adj*adj)
    if opp is None:
        opp = math.sqrt(max(hyp*hyp - adj*adj, 0.0))
    if adj is None:
        adj = math.sqrt(max(hyp*hyp - opp*opp, 0.0))

    if hyp <= 0:
        raise ValueError("Invalid side lengths.")
    angle_A = rad_to_deg(math.asin(opp / hyp))
    angle_B = 90.0 - angle_A

    return {
        'angle_A_deg': angle_A,
        'angle_B_deg': angle_B,
        'hypotenuse': hyp,
        'opposite': opp,
        'adjacent': adj
    }

def pretty_print(result):
    for k, v in result.items():
        if isinstance(v, float):
            print(f"{k:15}: {v:.6f}")
        else:
            print(f"{k:15}: {v}")
    print("-" * 40)

def prompt_choice(prompt, choices=None, allow_quit=True):
    while True:
        s = input(prompt).strip().lower()
        if allow_quit and s == 'q':
            return 'q'
        if choices is None or s in choices:
            return s
        print("Invalid input. Try again or enter 'q' to quit.")

def get_positive_float(prompt):
    while True:
        s = input(prompt).strip().lower()
        if s == 'q':
            return 'q'
        try:
            val = float(s)
            if val > 0:
                return val
            print("Enter a positive number.")
        except ValueError:
            print("Invalid number. Try again or enter 'q' to quit.")

def main():
    print("Right-triangle solver (SOH CAH TOA). Enter 'q' at any top-level prompt to quit.")
    while True:
        mode = prompt_choice("Mode 1) angle+side  2) two sides  (enter 1 or 2, or q to quit): ", choices={'1','2'})
        if mode == 'q':
            print("Goodbye.")
            break

        try:
            if mode == '1':
                angle = get_positive_float("Known angle in degrees (0 < angle < 90): ")
                if angle == 'q': break
                if not (0 < angle < 90):
                    print("Angle must be between 0 and 90 degrees.")
                    continue

                side_type = prompt_choice("Which side relative to that angle? (hyp/opp/adj): ", choices={'hyp','opp','adj'})
                if side_type == 'q': break
                side_len = get_positive_float("Side length (positive): ")
                if side_len == 'q': break

                res = solve_from_angle_and_side(angle, side_len, side_type)
                pretty_print(res)

            elif mode == '2':
                print("Enter two known sides. Types: hyp, opp, adj (relative to the same non-right angle).")
                s1t = prompt_choice("First side type (hyp/opp/adj): ", choices={'hyp','opp','adj'})
                if s1t == 'q': break
                s1 = get_positive_float("First side length: ")
                if s1 == 'q': break

                s2t = prompt_choice("Second side type (hyp/opp/adj): ", choices={'hyp','opp','adj'})
                if s2t == 'q': break
                s2 = get_positive_float("Second side length: ")
                if s2 == 'q': break

                # prevent same side type twice unless user really means it
                if s1t == s2t:
                    print("Warning: you entered the same side type twice. Make sure that's intended.")
                res = solve_from_two_sides(s1t, s1, s2t, s2)
                pretty_print(res)

        except Exception as e:
            print("Error:", e)

        cont = prompt_choice("Solve another triangle? (y/n): ", choices={'y','n'})
        if cont == 'q' or cont == 'n':
            print("Goodbye.")
            break

if __name__ == "__main__":
    main()
