#!/usr/bin/env python3
"""
conics_tk_repeat_button.py

Plot conic sections using only Python standard library (tkinter + math).
Adds a Repeat button in the plot window to re-open the parameter dialog.
"""

import tkinter as tk
from tkinter import simpledialog, messagebox
import math
import sys

# ---------- Utilities ----------

def solve_quadratic(a, b, c):
    if abs(a) < 1e-12:
        if abs(b) < 1e-12:
            return []
        return [-c / b]
    disc = b*b - 4*a*c
    if disc < 0:
        return []
    if abs(disc) < 1e-12:
        return [-b / (2*a)]
    sqrt_d = math.sqrt(disc)
    return [(-b - sqrt_d) / (2*a), (-b + sqrt_d) / (2*a)]

def map_to_canvas(x, y, xlim, ylim, width, height, margin=20):
    xmin, xmax = xlim
    ymin, ymax = ylim
    sx = (width - 2*margin) / (xmax - xmin) if xmax != xmin else 1.0
    sy = (height - 2*margin) / (ymax - ymin) if ymax != ymin else 1.0
    px = margin + (x - xmin) * sx
    py = height - (margin + (y - ymin) * sy)
    return px, py

def draw_axes(canvas, xlim, ylim, width, height):
    xmin, xmax = xlim
    ymin, ymax = ylim
    if ymin <= 0 <= ymax:
        px1, py = map_to_canvas(xmin, 0, xlim, ylim, width, height)
        px2, _  = map_to_canvas(xmax, 0, xlim, ylim, width, height)
        canvas.create_line(px1, py, px2, py, fill="#888")
    if xmin <= 0 <= xmax:
        px, py1 = map_to_canvas(0, ymin, xlim, ylim, width, height)
        _, py2  = map_to_canvas(0, ymax, xlim, ylim, width, height)
        canvas.create_line(px, py1, px, py2, fill="#888")

# ---------- Plotting ----------

def plot_parametric(canvas, param_func, tmin, tmax, steps, xlim, ylim, width, height, color="black"):
    pts = []
    for i in range(steps+1):
        t = tmin + (tmax - tmin) * i / steps
        x, y = param_func(t)
        px, py = map_to_canvas(x, y, xlim, ylim, width, height)
        pts.append((px, py))
    for i in range(len(pts)-1):
        canvas.create_line(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1], fill=color, width=2)

def plot_implicit_by_x(canvas, A,B,C,D,E,F, xlim, ylim, width, height, samples=2000, color="black"):
    xmin, xmax = xlim
    pts_up = []
    pts_down = []
    for i in range(samples+1):
        x = xmin + (xmax - xmin) * i / samples
        a = C
        b = B * x + E
        c = A * x*x + D * x + F
        ys = solve_quadratic(a, b, c)
        if len(ys) == 2:
            y1, y2 = ys
            pts_up.append((x, y1))
            pts_down.append((x, y2))
        elif len(ys) == 1:
            y = ys[0]
            pts_up.append((x, y))
    def draw_pts(pts):
        if not pts:
            return
        mapped = [map_to_canvas(x,y,xlim,ylim,width,height) for x,y in pts]
        for i in range(len(mapped)-1):
            x1,y1 = mapped[i]; x2,y2 = mapped[i+1]
            if abs(y2 - y1) > (ylim[1]-ylim[0]) * 0.5:
                continue
            canvas.create_line(x1,y1,x2,y2, fill=color, width=2)
    draw_pts(pts_up)
    draw_pts(pts_down)

# ---------- Dialog helpers ----------

def ask_float(prompt, default=None, allow_zero=True):
    while True:
        s = simpledialog.askstring("Input", f"{prompt}" + (f" (default {default})" if default is not None else ""))
        if s is None:
            raise KeyboardInterrupt
        s = s.strip()
        if s == "" and default is not None:
            return float(default)
        try:
            v = float(s)
            if not allow_zero and abs(v) < 1e-12:
                messagebox.showerror("Invalid", "Value cannot be zero.")
                continue
            return v
        except Exception:
            messagebox.showerror("Invalid", "Please enter a valid number.")

# ---------- Main window with Repeat button ----------

def run_once():
    """
    Returns True if user clicked Repeat, False if Exit/cancel.
    """
    # Prompt for conic type before creating the plot window
    root_prompt = tk.Tk()
    root_prompt.withdraw()
    menu = ("Choose conic type:\n"
            "1) Circle\n2) Ellipse\n3) Parabola\n4) Hyperbola\n5) General quadratic (Ax^2 + Bxy + Cy^2 + Dx + Ey + F = 0)\n\n"
            "Enter 1-5")
    choice = simpledialog.askstring("Conic", menu, parent=root_prompt)
    root_prompt.destroy()
    if choice is None:
        return False
    choice = choice.strip()
    width, height = 900, 700

    # Create the plot window
    root = tk.Tk()
    root.title("Conic Plotter")
    canvas = tk.Canvas(root, width=width, height=height-60, bg="white")
    canvas.pack(side="top", fill="both", expand=False)

    # Frame for buttons
    btn_frame = tk.Frame(root)
    btn_frame.pack(side="bottom", fill="x")

    # default action: exit
    root.user_choice = 'exit'

    def on_repeat():
        root.user_choice = 'repeat'
        root.destroy()

    def on_exit():
        root.user_choice = 'exit'
        root.destroy()

    # Add buttons
    repeat_btn = tk.Button(btn_frame, text="Repeat", command=on_repeat, width=12, bg="#4CAF50", fg="white")
    repeat_btn.pack(side="left", padx=10, pady=8)
    exit_btn = tk.Button(btn_frame, text="Exit", command=on_exit, width=12)
    exit_btn.pack(side="left", padx=10, pady=8)
    # small help label
    help_lbl = tk.Label(btn_frame, text="Click Repeat to enter new parameters; Exit to quit.", anchor="w")
    help_lbl.pack(side="left", padx=10)

    try:
        if choice == '1':
            r = ask_float("Radius r (>0):", default="3", allow_zero=False)
            h = ask_float("Center x h:", default="0")
            k = ask_float("Center y k:", default="0")
            xlim = (h - max(1.5*r, 5), h + max(1.5*r, 5))
            ylim = (k - max(1.5*r, 5), k + max(1.5*r, 5))
            draw_axes(canvas, xlim, ylim, width, height-60)
            plot_parametric(canvas, lambda t: (h + r*math.cos(t), k + r*math.sin(t)), 0, 2*math.pi, 600, xlim, ylim, width, height-60, color="blue")

        elif choice == '2':
            a = ask_float("Semi-major a (>0):", default="4", allow_zero=False)
            b = ask_float("Semi-minor b (>0):", default="2", allow_zero=False)
            h = ask_float("Center x h:", default="0")
            k = ask_float("Center y k:", default="0")
            xlim = (h - max(1.5*a, 6), h + max(1.5*a, 6))
            ylim = (k - max(1.5*b, 6), k + max(1.5*b, 6))
            draw_axes(canvas, xlim, ylim, width, height-60)
            plot_parametric(canvas, lambda t: (h + a*math.cos(t), k + b*math.sin(t)), 0, 2*math.pi, 800, xlim, ylim, width, height-60, color="green")

        elif choice == '3':
            orient = simpledialog.askstring("Parabola", "Orientation: v for vertical y = a(x-h)^2 + k, h for horizontal x = a(y-k)^2 + h", initialvalue="v", parent=root)
            if orient is None:
                root.destroy(); return False
            orient = orient.strip().lower() or 'v'
            a = ask_float("Parameter a (non-zero):", default="0.5", allow_zero=False)
            h = ask_float("Vertex x h:", default="0")
            k = ask_float("Vertex y k:", default="0")
            span = max(6, 6/abs(a))
            xlim = (h - span, h + span)
            ylim = (k - span, k + span)
            draw_axes(canvas, xlim, ylim, width, height-60)
            if orient == 'v':
                plot_parametric(canvas, lambda t: (h + t, k + a * t*t), -span, span, 1200, xlim, ylim, width, height-60, color="purple")
            else:
                plot_parametric(canvas, lambda t: (h + a * t*t, k + t), -span, span, 1200, xlim, ylim, width, height-60, color="purple")

        elif choice == '4':
            orient = simpledialog.askstring("Hyperbola", "Orientation: h for horizontal transverse axis, v for vertical", initialvalue="h", parent=root)
            if orient is None:
                root.destroy(); return False
            orient = orient.strip().lower() or 'h'
            a = ask_float("a (>0):", default="3", allow_zero=False)
            b = ask_float("b (>0):", default="1.5", allow_zero=False)
            h = ask_float("Center x h:", default="0")
            k = ask_float("Center y k:", default="0")
            xlim = (h - 6*max(a,b), h + 6*max(a,b))
            ylim = (k - 6*max(a,b), k + 6*max(a,b))
            draw_axes(canvas, xlim, ylim, width, height-60)
            if orient == 'h':
                def branch1(t): return (h + a*math.cosh(t), k + b*math.sinh(t))
                def branch2(t): return (h - a*math.cosh(t), k + b*math.sinh(t))
                def branch3(t): return (h + a*math.cosh(t), k - b*math.sinh(t))
                def branch4(t): return (h - a*math.cosh(t), k - b*math.sinh(t))
                Tmax = 2.0
                plot_parametric(canvas, branch1, 0.0, Tmax, 400, xlim, ylim, width, height-60, color="red")
                plot_parametric(canvas, branch2, 0.0, Tmax, 400, xlim, ylim, width, height-60, color="red")
                plot_parametric(canvas, branch3, 0.0, Tmax, 400, xlim, ylim, width, height-60, color="red")
                plot_parametric(canvas, branch4, 0.0, Tmax, 400, xlim, ylim, width, height-60, color="red")
            else:
                def branch1(t): return (h + b*math.sinh(t), k + a*math.cosh(t))
                def branch2(t): return (h + b*math.sinh(t), k - a*math.cosh(t))
                Tmax = 2.0
                plot_parametric(canvas, branch1, 0.0, Tmax, 400, xlim, ylim, width, height-60, color="red")
                plot_parametric(canvas, branch2, 0.0, Tmax, 400, xlim, ylim, width, height-60, color="red")

        elif choice == '5':
            A = ask_float("A:", default="1")
            B = ask_float("B:", default="0")
            C = ask_float("C:", default="1")
            D = ask_float("D:", default="0")
            E = ask_float("E:", default="0")
            F = ask_float("F:", default="-4")
            det = (2*A)*(2*C) - B*B
            if abs(det) > 1e-9:
                cx = ( -D*(2*C) + B*E ) / det
                cy = ( -E*(2*A) + B*D ) / det
                span = 6
                xlim = (cx - span, cx + span)
                ylim = (cy - span, cy + span)
            else:
                xlim = (-10, 10)
                ylim = (-10, 10)
            draw_axes(canvas, xlim, ylim, width, height-60)
            plot_implicit_by_x(canvas, A,B,C,D,E,F, xlim, ylim, width, height-60, samples=2000, color="black")

        else:
            messagebox.showinfo("Quit", "Invalid choice or cancelled.")
            root.destroy()
            return False

        # footer text
        canvas.create_text(10, 10, anchor="nw", text="Use Repeat to plot another conic or Exit to quit.", fill="#444")
        root.mainloop()
        return (root.user_choice == 'repeat')

    except KeyboardInterrupt:
        try:
            root.destroy()
        except Exception:
            pass
        return False

def main():
    try:
        while True:
            repeat = run_once()
            if not repeat:
                break
    except KeyboardInterrupt:
        pass
    print("Exiting.")
    sys.exit(0)

if __name__ == "__main__":
    main()
