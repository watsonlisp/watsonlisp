import math

def parse_input(prompt):
    val = input(prompt).strip()
    if val.lower() in ('x', ''):
        return None
    if val.lower() in ('q', 'quit', 'exit'):
        raise KeyboardInterrupt  # allow quick exit
    try:
        return float(val)
    except ValueError:
        print("Invalid number. Enter a numeric value, 'x' for unknown, or 'q' to quit.")
        return parse_input(prompt)

def solve_missing(s, u, a, t):
    unknowns = [s is None, u is None, a is None, t is None].count(True)
    if unknowns != 1:
        raise ValueError("Exactly one variable must be unknown (enter 'x' for the unknown).")

    if s is None:
        s_calc = u * t + 0.5 * a * t**2
        return {'s': s_calc, 'u': u, 'a': a, 't': t}

    if u is None:
        if t == 0:
            if abs(s - 0.5 * a * t**2) < 1e-12:
                raise ValueError("t is zero; u is undetermined (any value satisfies s==0).")
            else:
                raise ValueError("t is zero; cannot solve for u.")
        u_calc = (s - 0.5 * a * t**2) / t
        return {'s': s, 'u': u_calc, 'a': a, 't': t}

    if a is None:
        if t == 0:
            if abs(s) < 1e-12:
                raise ValueError("t is zero; a is undetermined (any value satisfies s==0).")
            else:
                raise ValueError("t is zero; cannot solve for a.")
        a_calc = 2 * (s - u * t) / (t**2)
        return {'s': s, 'u': u, 'a': a_calc, 't': t}

    if t is None:
        if abs(a) < 1e-12:
            if abs(u) < 1e-12:
                if abs(s) < 1e-12:
                    raise ValueError("Both a and u are zero and s is zero: t is undetermined (any t).")
                else:
                    raise ValueError("Both a and u are zero but s != 0: no solution for t.")
            t_calc = s / u
            return {'s': s, 'u': u, 'a': a, 't': t_calc}
        A = 0.5 * a
        B = u
        C = -s
        disc = B**2 - 4 * A * C
        if disc < -1e-12:
            raise ValueError("No real solution for time (discriminant < 0).")
        disc = max(disc, 0.0)
        sqrt_disc = math.sqrt(disc)
        t1 = (-B + sqrt_disc) / (2 * A)
        t2 = (-B - sqrt_disc) / (2 * A)
        roots = sorted([r for r in (t1, t2) if r >= -1e-12])
        roots = [0.0 if abs(r) < 1e-12 else r for r in roots]
        if not roots:
            raise ValueError("Real roots exist but are negative; no non-negative time solution.")
        if len(roots) == 1:
            return {'s': s, 'u': u, 'a': a, 't': roots[0]}
        else:
            return {'s': s, 'u': u, 'a': a, 't': roots}

def pretty_print(result):
    print("\n--- Solution ---")
    for k in ('s', 'u', 'a', 't'):
        val = result[k]
        if isinstance(val, list):
            print(f"{k} = {val} (two possible values)")
        else:
            print(f"{k} = {val}")
    print("----------------\n")

def main():
    print("Kinematics solver (constant acceleration).")
    print("Enter numeric values for three variables and 'x' for the unknown.")
    print("Variables: s (displacement), u (initial velocity), a (acceleration), t (time)")
    print("Type 'q' at any prompt to quit.\n")

    try:
        while True:
            try:
                s = parse_input("s (m) = ")
                u = parse_input("u (m/s) = ")
                a = parse_input("a (m/s^2) = ")
                t = parse_input("t (s) = ")

                result = solve_missing(s, u, a, t)
                pretty_print(result)
            except ValueError as e:
                print("Error:", e)
            except KeyboardInterrupt:
                print("\nExiting solver.")
                break

            again = input("Solve another? (y/n) [y]: ").strip().lower()
            if again in ('n', 'no'):
                print("Goodbye.")
                break
            # default is to continue
    except KeyboardInterrupt:
        print("\nGoodbye.")

if __name__ == "__main__":
    main()
