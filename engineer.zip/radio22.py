import tkinter as tk
import os

def execute_program():
    selected_program = var.get()
    if selected_program == "Program 1":
        os.system("c:/python/sohcahtoa2.py")
    elif selected_program == "Program 2":
        os.system("c:/python/ohm4.py")
    elif selected_program == "Program 3":
        os.system("c:/python/newton2.py")
    elif selected_program == "Program 4":
        os.system("c:/python/einstein4.py")
    elif selected_program == "Program 5":
        os.system("c:/python/ballistic5.py")
    elif selected_program == "Program 6":
        os.system("c:/python/kinematic2.py")
    elif selected_program == "Program 7":
        os.system("c:/python/conic4.py")
    elif selected_program == "Program 8":
        os.system("c:/python/wave3.py")

# Create the main window
root = tk.Tk()
root.title("Program Selector")

# Create a Tkinter variable
var = tk.StringVar(value="Program 1")

# Create radio buttons
radio1 = tk.Radiobutton(root, text="sohcahtoa", variable=var, value="Program 1")
radio2 = tk.Radiobutton(root, text="ohm", variable=var, value="Program 2")
radio3 = tk.Radiobutton(root, text="newton", variable=var, value="Program 3")
radio4 = tk.Radiobutton(root, text="einstein2", variable=var, value="Program 4")
radio5 = tk.Radiobutton(root, text="ballistic", variable=var, value="Program 5")
radio6 = tk.Radiobutton(root, text="kinematic", variable=var, value="Program 6")
radio7 = tk.Radiobutton(root, text="conic", variable=var, value="Program 7")
radio8 = tk.Radiobutton(root, text="wave", variable=var, value="Program 8")



# Pack the radio buttons
radio1.pack(anchor=tk.W)
radio2.pack(anchor=tk.W)
radio3.pack(anchor=tk.W)
radio4.pack(anchor=tk.W)
radio5.pack(anchor=tk.W)
radio6.pack(anchor=tk.W)
radio7.pack(anchor=tk.W)
radio8.pack(anchor=tk.W)



# Create a button to execute the selected program
execute_button = tk.Button(root, text="Execute", command=execute_program)
execute_button.pack()

# Run the main loop
root.mainloop()
