# emc_solver_loop.py
# Repeating interactive solver for E = m * c^2
import math
import sys

DEFAULT_C = 299_792_458.0  # speed of light in m/s

def prompt_float(prompt, allow_zero=False, allow_empty=False, default=None):
    while True:
        s = input(prompt).strip()
        if s.lower() in ("q", "quit", "exit"):
            print("Goodbye.")
            sys.exit(0)
        if allow_empty and s == "":
            return default
        try:
            val = float(s)
            if not allow_zero and val <= 0:
                print("Please enter a positive number or type 'q' to quit.")
                continue
            if allow_zero and val < 0:
                print("Please enter a non-negative number or type 'q' to quit.")
                continue
            return val
        except ValueError:
            print("Invalid number. Enter a numeric value, press Enter for default, or type 'q' to quit.")

def solve_for_E():
    m = prompt_float("Enter mass m (kg): ")
    c = prompt_float(f"Enter speed c (m/s) [Enter = default {DEFAULT_C:.0f}]: ",
                     allow_empty=True, default=DEFAULT_C)
    E = m * c**2
    print(f"\nEnergy E = {E:.6e} J\n")

def solve_for_m():
    E = prompt_float("Enter energy E (J): ", allow_zero=True)
    c = prompt_float(f"Enter speed c (m/s) [Enter = default {DEFAULT_C:.0f}]: ",
                     allow_empty=True, default=DEFAULT_C)
    if c == 0:
        print("Speed c cannot be zero.\n")
        return
    m = E / (c**2)
    print(f"\nMass m = {m:.6e} kg\n")

def solve_for_c():
    E = prompt_float("Enter energy E (J): ")
    m = prompt_float("Enter mass m (kg): ")
    if m == 0:
        print("Mass m cannot be zero when solving for c.\n")
        return
    ratio = E / m
    if ratio < 0:
        print("E/m is negative; no real solution for c.\n")
        return
    c = math.sqrt(ratio)
    print(f"\nSpeed c = {c:.6e} m/s\n")

def main():
    print("E = m * c^2 solver (type 'q' or 'quit' at any prompt to exit)")
    while True:
        print("Choose variable to solve for: E (energy), M (mass), C (speed).")
        choice = input("Solve for (E/M/C) or Q to quit: ").strip().upper()
        if choice in ("Q", "QUIT", "EXIT"):
            print("Goodbye.")
            break
        if choice == "E":
            solve_for_E()
        elif choice == "M":
            solve_for_m()
        elif choice == "C":
            solve_for_c()
        else:
            print("Invalid choice. Enter E, M, C, or Q.\n")

if __name__ == "__main__":
    main()
