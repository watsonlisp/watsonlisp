#!/usr/bin/env python3
"""
Repeatable interactive calculator:
- Enter two of I, V, R to compute the third (V = I * R).
- If all three are provided, the program also computes S = I + V/R.
- Type 'q' at any prompt to quit.
"""

def read_val(name):
    while True:
        s = input(f"{name} = ").strip().lower()
        if s == 'q':
            return 'QUIT'
        if s == '' or s in ('x', 'unknown'):
            return None
        try:
            return float(s)
        except ValueError:
            print("Please enter a number, 'x' for unknown, or 'q' to quit.")

def compute_missing(I, V, R):
    # Use Ohm's law V = I * R
    if I is None and V is not None and R is not None:
        if R == 0:
            raise ZeroDivisionError("R is zero; cannot compute I = V / R.")
        return "I", V / R
    if V is None and I is not None and R is not None:
        return "V", I * R
    if R is None and I is not None and V is not None:
        if I == 0:
            raise ZeroDivisionError("I is zero; cannot compute R = V / I.")
        return "R", V / I
    return None, None

def compute_S(I, V, R):
    if R == 0:
        raise ZeroDivisionError("R cannot be zero when computing S = I + V/R.")
    return I + V / R

def main():
    print("Ohm's law helper — compute the missing variable or S = I + V/R.")
    print("Type 'q' at any prompt to quit.\n")
    while True:
        I = read_val("I (current, A)")
        if I == 'QUIT':
            break
        V = read_val("V (voltage, V)")
        if V == 'QUIT':
            break
        R = read_val("R (resistance, Ω)")
        if R == 'QUIT':
            break

        try:
            missing_name, missing_value = compute_missing(I, V, R)
        except ZeroDivisionError as e:
            print("Error:", e)
            print()
            continue

        if missing_name is not None:
            print(f"Solved {missing_name} = {missing_value}")
            # fill in the computed value so S can be computed if desired
            if missing_name == "I":
                I = missing_value
            elif missing_name == "V":
                V = missing_value
            else:
                R = missing_value

            # Offer S automatically if possible
            try:
                S = compute_S(I, V, R)
                print(f"S = I + V/R = {S}")
            except ZeroDivisionError:
                print("Cannot compute S because R is zero.")
            print()
            continue

        provided = sum(1 for v in (I, V, R) if v is not None)
        if provided == 3:
            try:
                S = compute_S(I, V, R)
                print(f"All three provided. S = I + V/R = {S}")
            except ZeroDivisionError:
                print("Cannot compute S because R is zero.")
            print()
            continue

        print("Insufficient or ambiguous inputs.")
        print("- Provide exactly two of I, V, R to compute the third, or")
        print("- Provide all three to compute S = I + V/R.")
        print()

    print("Goodbye!")

if __name__ == "__main__":
    main()
