#!/usr/bin/env python3
"""
wave_theory_tk_repeat_quit.py

Interactive trig and hyperbolic plotter using only Python standard library.
Adds Repeat (auto-redraw) and Quit functionality.

- Repeat: toggles automatic re-drawing at a user-set interval (seconds).
- Quit: cleanly exits the application.
- All previous features retained: select functions, A, T, φ, D, units, samples, Save PostScript.

Save as: wave_theory_tk_repeat_quit.py
Run: python wave_theory_tk_repeat_quit.py
"""

import math
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# -------------------------
# Math helpers
# -------------------------

def to_radians(x, unit):
    return x if unit == 'radians' else math.radians(x)

def compute_omega(T, unit):
    # If T <= 0, fallback handled by caller
    if T is None or T <= 0:
        return 1.0
    T_rad = T if unit == 'radians' else math.radians(T)
    return 2 * math.pi / T_rad

# -------------------------
# Plotting on tkinter Canvas
# -------------------------

class WavePlotter(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Wave Theory Plotter — Repeat & Quit")
        self.geometry("1000x700")
        self._repeat_job = None
        self._build_ui()

    def _build_ui(self):
        # Left control frame
        ctrl = ttk.Frame(self)
        ctrl.pack(side='left', fill='y', padx=8, pady=8)

        # Function checkboxes
        ttk.Label(ctrl, text="Functions").pack(anchor='w')
        self.func_vars = {}
        funcs = ['sin', 'cos', 'tan', 'sinh', 'cosh', 'tanh']
        for f in funcs:
            var = tk.BooleanVar(value=(f in ('sin','cos','tan')))
            cb = ttk.Checkbutton(ctrl, text=f, variable=var)
            cb.pack(anchor='w')
            self.func_vars[f] = var

        # Parameters
        ttk.Separator(ctrl, orient='horizontal').pack(fill='x', pady=6)
        def labeled_entry(label, default):
            ttk.Label(ctrl, text=label).pack(anchor='w')
            e = ttk.Entry(ctrl)
            e.insert(0, str(default))
            e.pack(fill='x', pady=2)
            return e

        self.entry_A = labeled_entry("Amplitude A", 1.0)
        self.entry_T = labeled_entry("Period T", 2 * math.pi)
        self.entry_phi = labeled_entry("Phase φ", 0.0)
        self.entry_D = labeled_entry("Vertical offset D", 0.0)
        self.entry_samples = labeled_entry("Samples", 1000)

        # Units
        ttk.Label(ctrl, text="Angle unit").pack(anchor='w', pady=(6,0))
        self.unit_var = tk.StringVar(value='radians')
        unit_frame = ttk.Frame(ctrl)
        unit_frame.pack(anchor='w')
        ttk.Radiobutton(unit_frame, text='radians', variable=self.unit_var, value='radians').pack(side='left')
        ttk.Radiobutton(unit_frame, text='degrees', variable=self.unit_var, value='degrees').pack(side='left')

        # Repeat controls
        ttk.Separator(ctrl, orient='horizontal').pack(fill='x', pady=6)
        ttk.Label(ctrl, text="Repeat (auto-redraw)").pack(anchor='w')
        repeat_frame = ttk.Frame(ctrl)
        repeat_frame.pack(fill='x')
        self.repeat_var = tk.BooleanVar(value=False)
        self.repeat_interval_entry = ttk.Entry(repeat_frame, width=6)
        self.repeat_interval_entry.insert(0, "2.0")  # seconds
        ttk.Checkbutton(repeat_frame, text="Repeat", variable=self.repeat_var, command=self._on_repeat_toggle).pack(side='left')
        ttk.Label(repeat_frame, text="Interval (s):").pack(side='left', padx=(6,0))
        self.repeat_interval_entry.pack(side='left', padx=(2,0))

        # Buttons
        btn_frame = ttk.Frame(ctrl)
        btn_frame.pack(fill='x', pady=8)
        ttk.Button(btn_frame, text="Draw", command=self.on_draw).pack(side='left', expand=True, fill='x', padx=2)
        ttk.Button(btn_frame, text="Stop Repeat", command=self.stop_repeat).pack(side='left', expand=True, fill='x', padx=2)
        ttk.Button(btn_frame, text="Save PostScript", command=self.on_save).pack(side='left', expand=True, fill='x', padx=2)
        ttk.Button(btn_frame, text="Quit", command=self.on_quit).pack(side='left', expand=True, fill='x', padx=2)

        # Canvas for plotting
        self.canvas = tk.Canvas(self, bg='white')
        self.canvas.pack(side='right', expand=True, fill='both', padx=8, pady=8)

        # Legend area
        self.legend_frame = ttk.Frame(self)
        self.legend_frame.place(relx=0.02, rely=0.02)

        # Bind window close to clean quit
        self.protocol("WM_DELETE_WINDOW", self.on_quit)

    def _get_params(self):
        try:
            A = float(self.entry_A.get())
        except Exception:
            A = 1.0
        try:
            T = float(self.entry_T.get())
        except Exception:
            T = 2 * math.pi
        try:
            phi = float(self.entry_phi.get())
        except Exception:
            phi = 0.0
        try:
            D = float(self.entry_D.get())
        except Exception:
            D = 0.0
        try:
            samples = int(self.entry_samples.get())
            if samples < 10:
                samples = 1000
        except Exception:
            samples = 1000
        unit = self.unit_var.get()
        selected = [f for f, v in self.func_vars.items() if v.get()]
        return dict(A=A, T=T, phi=phi, D=D, samples=samples, unit=unit, funcs=selected)

    def on_draw(self):
        params = self._get_params()
        if not params['funcs']:
            messagebox.showinfo("No functions", "Please select at least one function to plot.")
            return
        self._draw_plot(params)

    def _draw_plot(self, params):
        # Clear canvas and legend
        self.canvas.delete('all')
        self.legend_frame.destroy()
        self.legend_frame = ttk.Frame(self)
        self.legend_frame.place(relx=0.02, rely=0.02)

        w = self.canvas.winfo_width() or 800
        h = self.canvas.winfo_height() or 600
        margin = 60

        # Determine period fallback
        T = params['T']
        if T <= 0:
            T = 2 * math.pi if params['unit'] == 'radians' else 360.0

        x_min = -2 * T
        x_max = 2 * T

        # Colors
        colors = {
            'sin': 'blue', 'cos': 'green', 'tan': 'red',
            'sinh': 'purple', 'cosh': 'orange', 'tanh': 'brown'
        }

        # Compute omega and phase in radians
        omega = compute_omega(T, params['unit'])
        phi_rad = to_radians(params['phi'], params['unit'])

        # Prepare x samples in chosen units
        xs = [x_min + (x_max - x_min) * i / (params['samples'] - 1) for i in range(params['samples'])]

        # Convert x to pixel
        def x_to_px(x):
            return margin + (x - x_min) / (x_max - x_min) * (w - 2 * margin)

        # Compute y values for range
        y_values = []
        func_y_map = {}
        for fname in params['funcs']:
            ys = []
            for x in xs:
                x_rad = to_radians(x, params['unit'])
                arg = omega * x_rad + phi_rad
                try:
                    if fname == 'sin':
                        y = params['A'] * math.sin(arg) + params['D']
                    elif fname == 'cos':
                        y = params['A'] * math.cos(arg) + params['D']
                    elif fname == 'tan':
                        y = params['A'] * math.tan(arg) + params['D']
                    elif fname == 'sinh':
                        y = params['A'] * math.sinh(arg) + params['D']
                    elif fname == 'cosh':
                        y = params['A'] * math.cosh(arg) + params['D']
                    elif fname == 'tanh':
                        y = params['A'] * math.tanh(arg) + params['D']
                    else:
                        y = 0.0
                except Exception:
                    y = float('nan')
                ys.append(y)
            func_y_map[fname] = ys
            finite = [v for v in ys if isinstance(v, float) and not math.isnan(v) and math.isfinite(v)]
            if finite:
                y_values.extend(finite)

        if not y_values:
            y_min, y_max = -1.0, 1.0
        else:
            y_min = min(y_values)
            y_max = max(y_values)
            span = y_max - y_min
            if span == 0:
                span = abs(y_max) if y_max != 0 else 1.0
            y_min -= 0.15 * span
            y_max += 0.15 * span

        # Clamp extreme ranges
        max_span = 1e6
        if y_max - y_min > max_span:
            D = params['D']
            y_min = D - 1e3
            y_max = D + 1e3

        def y_to_px(y):
            return margin + (y_max - y) / (y_max - y_min) * (h - 2 * margin)

        # Draw grid and axes
        self.canvas.create_rectangle(margin, margin, w - margin, h - margin, outline='#ddd')
        for i in range(5):
            yy = y_min + (y_max - y_min) * i / 4
            self.canvas.create_line(margin, y_to_px(yy), w - margin, y_to_px(yy), fill='#eee')
            self.canvas.create_text(margin - 8, y_to_px(yy), text=f"{yy:.2g}", anchor='e', fill='black', font=('TkDefaultFont', 8))
        for i in range(9):
            xx = x_min + (x_max - x_min) * i / 8
            self.canvas.create_line(x_to_px(xx), h - margin, x_to_px(xx), margin, fill='#f7f7f7')
            self.canvas.create_text(x_to_px(xx), h - margin + 12, text=f"{xx:.2g}", anchor='n', fill='black', font=('TkDefaultFont', 8))

        if y_min <= 0 <= y_max:
            self.canvas.create_line(margin, y_to_px(0), w - margin, y_to_px(0), fill='black', width=1)
        if x_min <= 0 <= x_max:
            self.canvas.create_line(x_to_px(0), margin, x_to_px(0), h - margin, fill='black', width=1)

        # Plot each function with asymptote handling
        for fname in params['funcs']:
            ys = func_y_map[fname]
            pts = []
            last_py = None
            break_threshold = max((y_max - y_min) * 0.25, 1e3)
            for x, y in zip(xs, ys):
                if not (isinstance(y, float) and math.isfinite(y)):
                    last_py = None
                    pts = []
                    continue
                px = x_to_px(x)
                py = y_to_px(y)
                if last_py is not None and abs(py - last_py) > break_threshold:
                    # break segment
                    if len(pts) >= 4:
                        self.canvas.create_line(pts, fill=colors.get(fname, 'black'), width=1.5, smooth=True)
                    pts = []
                pts.extend([px, py])
                # draw in chunks
                if len(pts) >= 200:
                    self.canvas.create_line(pts, fill=colors.get(fname, 'black'), width=1.5, smooth=True)
                    pts = []
                last_py = py
            if len(pts) >= 4:
                self.canvas.create_line(pts, fill=colors.get(fname, 'black'), width=1.5, smooth=True)

            # Legend entry
            lbl = ttk.Label(self.legend_frame, text=f"{fname}", foreground=colors.get(fname, 'black'))
            lbl.pack(anchor='w')

        # Title
        title = f"Funcs: {', '.join(params['funcs'])}  |  A={params['A']}  T={T} ({params['unit']})  φ={params['phi']}  D={params['D']}"
        self.canvas.create_text(w/2, margin/2, text=title, font=('TkDefaultFont', 10, 'bold'))

    # -------------------------
    # Repeat control methods
    # -------------------------

    def _on_repeat_toggle(self):
        if self.repeat_var.get():
            self.start_repeat()
        else:
            self.stop_repeat()

    def start_repeat(self):
        # Start auto-redraw using after; interval in seconds from entry
        try:
            interval = float(self.repeat_interval_entry.get())
            if interval <= 0:
                raise ValueError
        except Exception:
            messagebox.showinfo("Invalid interval", "Please enter a positive number of seconds for the repeat interval.")
            self.repeat_var.set(False)
            return

        # If already running, do nothing
        if self._repeat_job is not None:
            return

        def _repeat_action():
            if not self.repeat_var.get():
                self._repeat_job = None
                return
            # redraw once
            self.on_draw()
            # schedule next
            ms = int(max(0.05, interval) * 1000)
            self._repeat_job = self.after(ms, _repeat_action)

        # Kick off
        _repeat_action()

    def stop_repeat(self):
        if self._repeat_job is not None:
            try:
                self.after_cancel(self._repeat_job)
            except Exception:
                pass
            self._repeat_job = None
        self.repeat_var.set(False)

    # -------------------------
    # Save and Quit
    # -------------------------

    def on_save(self):
        file = filedialog.asksaveasfilename(defaultextension=".ps", filetypes=[("PostScript", "*.ps"), ("All files", "*.*")])
        if not file:
            return
        try:
            self.canvas.update()
            self.canvas.postscript(file=file)
            messagebox.showinfo("Saved", f"Canvas saved as PostScript: {file}\nConvert to PNG externally if needed.")
        except Exception as e:
            messagebox.showerror("Save failed", f"Failed to save PostScript: {e}")

    def on_quit(self):
        # Stop any repeating job and exit cleanly
        self.stop_repeat()
        try:
            self.destroy()
        except Exception:
            try:
                self.quit()
            except Exception:
                pass

# -------------------------
# Run the app
# -------------------------

def main():
    app = WavePlotter()
    app.mainloop()

if __name__ == "__main__":
    main()
