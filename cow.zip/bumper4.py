#!/usr/bin/env python3
"""
Interactive Bumper Sticker Generator with TTS (no pip required)

Usage:
  python bumper_gen_tts.py --count 1 --tts
  python bumper_gen_tts.py --count 20

Notes:
- macOS: uses `say`
- Windows: uses PowerShell + System.Speech.Synthesis
- Linux: tries `espeak` then `spd-say`
- If no system TTS is available, it will simply print the text.
"""

import random
import argparse
import subprocess
import sys
import shutil
from datetime import datetime
import shlex

ADJECTIVES = ["tiny","loud","quiet","brave","weird","proud","green","retro","honest","sly","gentle","wild","calm","bold","curious"]
NOUNS = ["planet","coffee","cat","dog","engineer","nerd","driver","road","future","idea","revolution","garden","library","battery","sun"]
VERBS = ["rocks","saves","resists","remembers","forgives","drives","hugs","builds","questions","pauses","reboots","whispers"]
CAUSES = ["boycott plastic","plant trees","vote local","read books","share kindness","support science","teach kids","fix potholes","save bees","repair, don't replace"]
SNARK = ["mean people suck","I brake for good ideas","not all who wander are lost","this car runs on coffee","my other ride is imagination","ask me about my cat","I paused my game for this","be kind or be quiet"]

TEMPLATES = [
    "{adj} {noun}",
    "{noun} {verbs}",
    "{verbs} the {noun}",
    "{cause}",
    "{snark}",
    "Keep calm and {verbs}",
    "{adj} but {verbs}",
    "{noun} > {noun}",
    "If lost return to {noun}",
    "Powered by {noun}",
    "{adj} ideas, {adj} roads",
    "Warning: {snark}"
]

def pick(lst):
    return random.choice(lst)

def generate_sticker():
    t = pick(TEMPLATES)
    mapping = {
        "adj": pick(ADJECTIVES),
        "noun": pick(NOUNS),
        "verbs": pick(VERBS),
        "cause": pick(CAUSES),
        "snark": pick(SNARK)
    }
    s = t.format(**mapping).replace("  ", " ").strip()
    return s[0].upper() + s[1:] if s else s

def generate_many(count):
    stickers = []
    attempts = 0
    max_attempts = count * 10
    while len(stickers) < count and attempts < max_attempts:
        attempts += 1
        s = generate_sticker()
        if s not in stickers:
            stickers.append(s)
    while len(stickers) < count:
        stickers.append(generate_sticker())
    return stickers

def speak_mac(text):
    # macOS 'say' is usually available
    try:
        subprocess.run(["say", text], check=False)
        return True
    except Exception:
        return False

def speak_windows(text):
    # Use PowerShell to call System.Speech.Synthesis
    # Use single-line PowerShell command; escape quotes
    # Try 'powershell' then 'pwsh'
    ps_cmd = (
        "Add-Type -AssemblyName System.Speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        "$s.Speak([Console]::In.ReadToEnd());"
    )
    # We'll pipe the text to PowerShell stdin to avoid complex escaping
    for exe in ("powershell", "pwsh"):
        path = shutil.which(exe)
        if not path:
            continue
        try:
            p = subprocess.Popen([path, "-NoProfile", "-Command", ps_cmd],
                                 stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 text=True)
            p.communicate(text)
            return True
        except Exception:
            continue
    return False

def speak_linux(text):
    # Try espeak, then spd-say
    if shutil.which("espeak"):
        try:
            subprocess.run(["espeak", text], check=False)
            return True
        except Exception:
            pass
    if shutil.which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=False)
            return True
        except Exception:
            pass
    return False

def speak(text):
    """Cross-platform TTS using system tools only. Returns True if spoken."""
    if not text:
        return False
    platform = sys.platform
    # Shorten very long text for TTS clarity
    max_len = 300
    if len(text) > max_len:
        text = text[:max_len].rsplit(" ", 1)[0] + "..."
    if platform == "darwin":
        return speak_mac(text)
    if platform.startswith("win"):
        return speak_windows(text)
    # Assume linux / unix
    return speak_linux(text)

def parse_args():
    p = argparse.ArgumentParser(description="Interactive bumper sticker generator with optional TTS")
    p.add_argument("--count", type=int, default=1, help="Stickers per batch")
    p.add_argument("--seed", type=int, default=None, help="Optional seed for reproducible output")
    p.add_argument("--out", type=str, default=None, help="Append batches to this file")
    p.add_argument("--tts", action="store_true", help="Speak each sticker using system TTS if available")
    return p.parse_args()

def print_batch(stickers):
    ts = datetime.now().isoformat(timespec='seconds')
    print(f"\n# Batch generated {ts}")
    for i, s in enumerate(stickers, 1):
        print(f"{i:02d}. {s}")

def append_to_file(path, stickers):
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"# Batch {datetime.now().isoformat(timespec='seconds')}\n")
        for s in stickers:
            f.write(s + "\n")
        f.write("\n")

def interactive_loop(count, seed, out_file, tts_enabled):
    iteration = 0
    base_seed = seed
    while True:
        iteration += 1
        if base_seed is not None:
            random.seed(base_seed + iteration - 1)
        else:
            random.seed()

        stickers = generate_many(count)
        print_batch(stickers)

        if out_file:
            append_to_file(out_file, stickers)
            print(f"(Appended batch to {out_file})")

        if tts_enabled:
            # Speak each sticker briefly; if TTS not available, notify once
            spoken_any = False
            for s in stickers:
                ok = speak(s)
                if ok:
                    spoken_any = True
                else:
                    # If one fails, we continue trying others (some systems may succeed later)
                    pass
            if not spoken_any:
                print("(TTS not available on this system; install espeak/spd-say or use macOS 'say' or Windows PowerShell.)")

        resp = input("\nPress Enter to generate again, type 'q' to quit, or 'c N' to change count, 's S' to set seed, 't' to toggle TTS: ").strip()
        if not resp:
            continue
        if resp.lower() in ("q", "quit", "exit"):
            print("Goodbye — bumper stickers parked.")
            break
        parts = resp.split()
        if parts[0].lower() == "c" and len(parts) >= 2 and parts[1].isdigit():
            count = max(1, int(parts[1]))
            print(f"Set count to {count}")
            continue
        if parts[0].lower() == "s":
            if len(parts) >= 2 and parts[1].lstrip("-").isdigit():
                base_seed = int(parts[1])
                print(f"Set seed to {base_seed}")
            else:
                base_seed = None
                print("Cleared seed (random mode).")
            continue
        if parts[0].lower() == "t":
            tts_enabled = not tts_enabled
            print(f"TTS {'enabled' if tts_enabled else 'disabled'}.")
            continue
        print("Unrecognized input; continuing with previous settings.")

def main():
    args = parse_args()
    try:
        interactive_loop(count=args.count, seed=args.seed, out_file=args.out, tts_enabled=args.tts)
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting.")

if __name__ == "__main__":
    main()
