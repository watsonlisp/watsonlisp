#!/usr/bin/env python3
"""
presidential_quotes_no_deps.py

- Writes a starter quotes.csv with properly quoted rows if it doesn't exist.
- Loads the CSV, filters by party (democrat, republican, independent, federalist,
  democratic-republican, or both), and prints one or more random quotes with attribution.
- Adds cross-platform text-to-speech using only the standard library and native system tools.
"""

import csv
import random
import sys
import os
import platform
import subprocess
import shlex
from collections import OrderedDict
import shutil

CSV_PATH = "quotes.csv"

STARTER_QUOTES = [
    {"speaker":"George Washington","party":"Independent","quote":"Observe good faith and justice towards all nations; cultivate peace and harmony with all.","source":"First Inaugural Address","year":"1789"},
    {"speaker":"John Adams","party":"Federalist","quote":"Liberty cannot be preserved without a general knowledge among the people.","source":"Letter","year":"1798"},
    {"speaker":"Thomas Jefferson","party":"Democratic-Republican","quote":"We hold these truths to be self-evident, that all men are created equal.","source":"Declaration of Independence (draft)","year":"1776"},
    {"speaker":"James Madison","party":"Democratic-Republican","quote":"If men were angels, no government would be necessary.","source":"Federalist Papers (No. 51)","year":"1788"},
    {"speaker":"Abraham Lincoln","party":"Republican","quote":"Government of the people, by the people, for the people, shall not perish from the earth.","source":"Gettysburg Address","year":"1863"},
    {"speaker":"Ulysses S. Grant","party":"Republican","quote":"Let us have peace.","source":"Remarks","year":"1868"},
    {"speaker":"Theodore Roosevelt","party":"Republican","quote":"Speak softly and carry a big stick; you will go far.","source":"Speech","year":"1901"},
    {"speaker":"Woodrow Wilson","party":"Democrat","quote":"The world must be made safe for democracy.","source":"War Message to Congress","year":"1917"},
    {"speaker":"Franklin D. Roosevelt","party":"Democrat","quote":"The only thing we have to fear is fear itself.","source":"First Inaugural Address","year":"1933"},
    {"speaker":"Harry S. Truman","party":"Democrat","quote":"The buck stops here.","source":"Remarks","year":"1945"},
    {"speaker":"Dwight D. Eisenhower","party":"Republican","quote":"Plans are worthless, but planning is everything.","source":"Speech","year":"1957"},
    {"speaker":"John F. Kennedy","party":"Democrat","quote":"Ask not what your country can do for you — ask what you can do for your country.","source":"Inaugural Address","year":"1961"},
    {"speaker":"Lyndon B. Johnson","party":"Democrat","quote":"We shall overcome.","source":"Speech","year":"1965"},
    {"speaker":"Richard Nixon","party":"Republican","quote":"The greatest honor history can bestow is the title of peacemaker.","source":"Remarks","year":"1970"},
    {"speaker":"Gerald Ford","party":"Republican","quote":"Our long national nightmare is over.","source":"Remarks","year":"1974"},
    {"speaker":"Jimmy Carter","party":"Democrat","quote":"We must adjust to changing times and still hold to unchanging principles.","source":"Inaugural Address","year":"1977"},
    {"speaker":"Ronald Reagan","party":"Republican","quote":"Mr. Gorbachev, tear down this wall!","source":"Speech at the Brandenburg Gate","year":"1987"},
    {"speaker":"George H. W. Bush","party":"Republican","quote":"Read my lips: no new taxes.","source":"Acceptance Speech","year":"1988"},
    {"speaker":"Bill Clinton","party":"Democrat","quote":"There is nothing wrong with America that cannot be cured by what is right with America.","source":"Remarks","year":"1996"},
    {"speaker":"George W. Bush","party":"Republican","quote":"Freedom itself was attacked this morning by a faceless coward.","source":"Remarks","year":"2001"},
    {"speaker":"Barack Obama","party":"Democrat","quote":"Yes we can.","source":"Campaign Speech","year":"2008"},
    {"speaker":"Donald Trump","party":"Republican","quote":"We will make America great again.","source":"Campaign Slogan","year":"2016"},
    {"speaker":"Joe Biden","party":"Democrat","quote":"This is a time to heal in America.","source":"Inaugural Address","year":"2021"},
    {"speaker":"James Monroe","party":"Democratic-Republican","quote":"The American continents are henceforth not to be considered as subjects for future colonization by any European powers.","source":"Monroe Doctrine","year":"1823"},
    {"speaker":"Andrew Jackson","party":"Democrat","quote":"One man with courage makes a majority.","source":"Speech","year":"1830"},
    {"speaker":"Martin Van Buren","party":"Democrat","quote":"It is easier to do a job right than to explain why you didn't.","source":"Aphorism","year":"1830s"},
    {"speaker":"William McKinley","party":"Republican","quote":"In the time of darkest defeat, victory may be nearest.","source":"Speech","year":"1897"},
    {"speaker":"Calvin Coolidge","party":"Republican","quote":"The business of America is business.","source":"Speech","year":"1925"},
    {"speaker":"Herbert Hoover","party":"Republican","quote":"Older men declare war. But it is youth that must fight and die.","source":"Address","year":"1932"},
    {"speaker":"Benjamin Harrison","party":"Republican","quote":"Great lives never go out; they go on.","source":"Remarks","year":"1893"},
    {"speaker":"Chester A. Arthur","party":"Republican","quote":"Men may die, but the nation lives.","source":"Remarks","year":"1882"},
    {"speaker":"Grover Cleveland","party":"Democrat","quote":"Public office is a public trust.","source":"Inaugural Address","year":"1885"},
    {"speaker":"William Howard Taft","party":"Republican","quote":"Don't write so that you can be understood, write so that you can't be misunderstood.","source":"Letter","year":"1909"},
    {"speaker":"Franklin D. Roosevelt","party":"Democrat","quote":"The only limit to our realization of tomorrow will be our doubts of today.","source":"Speech","year":"1939"},
    {"speaker":"Harry S. Truman","party":"Democrat","quote":"It is amazing what you can accomplish if you do not care who gets the credit.","source":"Remarks","year":"1948"},
    {"speaker":"Dwight D. Eisenhower","party":"Republican","quote":"Accomplishment will prove to be a journey, not a destination.","source":"Remarks","year":"1953"},
    {"speaker":"John F. Kennedy","party":"Democrat","quote":"Efforts and courage are not enough without purpose and direction.","source":"Speech","year":"1961"},
    {"speaker":"Lyndon B. Johnson","party":"Democrat","quote":"We must open the doors of opportunity.","source":"Remarks","year":"1964"},
    {"speaker":"Richard Nixon","party":"Republican","quote":"People react to fear, not love; they don't teach that in Sunday school.","source":"Remarks","year":"1972"},
    {"speaker":"Ronald Reagan","party":"Republican","quote":"Government is not the solution to our problem; government is the problem.","source":"Inaugural Address","year":"1981"},
    {"speaker":"George W. Bush","party":"Republican","quote":"I can hear you. The rest of the world hears you.","source":"Remarks","year":"2001"},
    {"speaker":"Barack Obama","party":"Democrat","quote":"The best way to not feel hopeless is to get up and do something.","source":"Remarks","year":"2008"},
]

FIELDNAMES = ["speaker", "party", "quote", "source", "year"]

def write_starter_csv(path=CSV_PATH, force=False):
    """Write starter CSV only if missing unless force=True."""
    if os.path.exists(path) and not force:
        return
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES, quoting=csv.QUOTE_MINIMAL)
        writer.writeheader()
        for row in STARTER_QUOTES:
            writer.writerow(row)

def load_quotes(path=CSV_PATH, dedupe=True):
    with open(path, newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    if not dedupe:
        return rows
    seen = set()
    out = []
    for r in rows:
        key = (r.get("speaker","").strip(), r.get("quote","").strip(), r.get("year","").strip())
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out

def normalize_party(party_str):
    """Normalize common variants to canonical short names but preserve historical parties."""
    p = (party_str or "").strip().lower()
    if not p:
        return ""
    if p in ("democrat", "democratic"):
        return "democrat"
    if p in ("republican",):
        return "republican"
    if p in ("independent",):
        return "independent"
    if p in ("federalist", "democratic-republican", "democratic republican"):
        return p
    return p

def filter_quotes(quotes, parties):
    """
    parties: list of strings like ['democrat'] or ['republican'] or ['both'].
    'both' returns all quotes from democrat and republican.
    """
    if not parties:
        return quotes
    parties_norm = [normalize_party(p) for p in parties]
    if "both" in parties_norm:
        return [q for q in quotes if normalize_party(q.get("party","")) in ("democrat","republican")]
    allowed = set(parties_norm)
    return [q for q in quotes if normalize_party(q.get("party","")) in allowed]

def random_quotes(quotes, n=1):
    if not quotes:
        return []
    try:
        n = int(n)
    except Exception:
        n = 1
    if n <= 0:
        return []
    n = min(n, len(quotes))
    return random.sample(quotes, n)

def format_quote(q, show_normalized_party=False):
    speaker = q.get("speaker", "Unknown")
    quote = q.get("quote", "").strip()
    source = q.get("source", "Unknown source")
    year = q.get("year", "")
    party = q.get("party", "")
    if show_normalized_party:
        party = normalize_party(party)
    return f"\"{quote}\" — {speaker} ({year}), {source} [{party}]"

# -------------------------
# Text-to-speech utilities
# -------------------------

def _run_cmd_list(cmd_list, input_bytes=None):
    try:
        subprocess.run(cmd_list, input=input_bytes, check=True)
        return True
    except Exception:
        return False

def speak_text(text):
    """
    Cross-platform TTS using only the standard library by invoking system tools.
    Returns True if speech was attempted, False if no backend was available.
    """
    if not text:
        return False
    system = platform.system().lower()

    # macOS: `say`
    if system == "darwin":
        say_path = shutil.which("say")
        if say_path:
            # pass text as argument list to avoid shell quoting issues
            return _run_cmd_list([say_path, text])
        return False

    # Windows: use PowerShell + System.Speech (reads stdin)
    if system == "windows":
        ps_path = shutil.which("powershell") or shutil.which("pwsh")
        if not ps_path:
            return False
        ps_script = (
            "Add-Type -AssemblyName System.Speech; "
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            "$s.Speak([Console]::In.ReadToEnd());"
        )
        try:
            proc = subprocess.run(
                [ps_path, "-NoProfile", "-Command", ps_script],
                input=text.encode("utf-8"),
                check=True
            )
            return proc.returncode == 0
        except Exception:
            return False

    # Linux / other Unix: try espeak, spd-say, festival
    if system in ("linux", "freebsd"):
        espeak = shutil.which("espeak")
        if espeak:
            return _run_cmd_list([espeak, text])
        spd = shutil.which("spd-say")
        if spd:
            return _run_cmd_list([spd, text])
        festival = shutil.which("festival")
        if festival:
            # festival reads from stdin
            try:
                proc = subprocess.run([festival, "--tts"], input=text.encode("utf-8"), check=True)
                return proc.returncode == 0
            except Exception:
                return False
        return False

    # Unknown platform: no TTS backend
    return False

def build_spoken_string(q):
    """
    Build a single spoken string with priority:
    quote -> speaker -> year -> source -> party
    Empty fields are omitted cleanly.
    """
    parts = []
    quote = q.get("quote", "").strip()
    if quote:
        # ensure the quote ends with punctuation for natural pause
        if quote[-1] not in ".!?":
            quote = quote + "."
        parts.append(quote)
    speaker = q.get("speaker", "").strip()
    if speaker:
        parts.append(f"Spoken by {speaker}.")
    year = q.get("year", "").strip()
    if year:
        parts.append(f"In {year}.")
    source = q.get("source", "").strip()
    if source:
        parts.append(f"Source: {source}.")
    party = q.get("party", "").strip()
    if party:
        parts.append(f"Party: {party}.")
    # join with spaces; punctuation added above gives natural pauses
    return " ".join(parts)

# -------------------------
# CLI and integration
# -------------------------

def interactive_cli():
    print("Presidential Quote Generator (no external packages)")
    print("A starter quotes.csv will be written to the current directory if it doesn't exist.")
    try:
        write_starter_csv()
    except Exception as e:
        print("Warning: could not write CSV:", e)
    quotes = load_quotes()
    while True:
        print("\nFilter by party: [democrat] [republican] [independent] [federalist] [democratic-republican] [both]")
        party_input = input("Enter party (default both): ").strip().lower() or "both"
        valid = {"democrat","republican","independent","federalist","democratic-republican","both"}
        if party_input not in valid:
            print("Invalid choice. Try again.")
            continue
        num_input = input("How many quotes to show? (default 1): ").strip() or "1"
        try:
            num = int(num_input)
            if num < 1:
                print("Enter a positive integer.")
                continue
        except ValueError:
            print("Invalid number; showing 1 quote.")
            num = 1
        tts_choice = input("Speak quotes aloud? (y/n, default n): ").strip().lower() or "n"
        tts_enabled = (tts_choice == "y")
        selected = filter_quotes(quotes, [party_input])
        if not selected:
            print("No quotes found for that filter.")
            continue
        for q in random_quotes(selected, num):
            formatted = format_quote(q)
            print("\n" + formatted)
            if tts_enabled:
                # build full prioritized spoken string
                spoken = build_spoken_string(q)
                ok = speak_text(spoken)
                if not ok:
                    print("(TTS backend not available on this system.)")
        again = input("\nShow more? (y/n): ").strip().lower()
        if again != "y":
            print("Goodbye.")
            break

def cli_args_mode(argv):
    # Usage: script.py [party] [num] [--force] [--tts]
    party_arg = argv[1] if len(argv) >= 2 else "both"
    num_arg = 1
    force = False
    tts_enabled = False
    if len(argv) >= 3:
        try:
            num_arg = int(argv[2])
        except ValueError:
            print("Second argument must be an integer for number of quotes. Using 1.")
            num_arg = 1
    if "--force" in argv:
        force = True
    if "--tts" in argv:
        tts_enabled = True

    write_starter_csv(force=force)
    quotes = load_quotes()
    selected = filter_quotes(quotes, [party_arg])
    if not selected:
        print("No quotes found for that filter.")
        return
    for q in random_quotes(selected, num_arg):
        formatted = format_quote(q)
        print(formatted)
        if tts_enabled:
            # build full prioritized spoken string
            spoken = build_spoken_string(q)
            ok = speak_text(spoken)
            if not ok:
                print("(TTS backend not available on this system.)")

if __name__ == "__main__":
    if len(sys.argv) >= 2:
        cli_args_mode(sys.argv)
    else:
        interactive_cli()
