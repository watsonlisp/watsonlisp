#!/usr/bin/env python3
"""
random_affirmations.py
Simple CLI tool that prints random self-affirmations.

Behavior:
- Runs the requested action (single run, loop, repeat-and-quit, etc.).
- After the action finishes, the program prompts:
    Press Enter to run again, type 't' then Enter to toggle TTS, or type 'q' then Enter to quit.
  Typing 'q' quits; pressing Enter repeats the program.
- Prompt is printed to stderr so plain output (quotes) remains clean.
- Optional TTS uses only system utilities (no pip required). TTS runs synchronously
  so speech finishes before the program continues.
"""

import argparse
import random
import time
import sys
import subprocess
import shutil
from pathlib import Path

# Optional desktop notifications (install plyer to enable)
try:
    from plyer import notification
    HAS_PLYER = True
except Exception:
    HAS_PLYER = False

# Expanded affirmations list
DEFAULT_AFFIRMATIONS = [
    "You are capable of more than you know.",
    "Small steps forward are still progress.",
    "You deserve kindness, especially from yourself.",
    "Your voice matters and your presence counts.",
    "You learn and grow with every experience.",
    "You are allowed to rest and recharge.",
    "Mistakes are proof you are trying.",
    "You bring something unique to the world.",
    "Today you can choose one thing that makes you proud.",
    "You are resilient, even when it feels hard.",
    "Tiny steward, mighty heart — you handle what comes.",
    "You are enough exactly as you are.",
    "Breathe. You are doing the best you can right now.",
    "Your worth is not tied to your productivity.",
    "You are learning; progress is not always visible.",
    "You can be gentle with yourself and still grow.",
    "Every small choice adds up to big change.",
    "You are allowed to set boundaries that protect your peace.",
    "You have survived hard days before; you will again.",
    "Your feelings are valid and deserve attention.",
    "You are creative in ways you haven't discovered yet.",
    "You are allowed to ask for help when you need it.",
    "You are more than your mistakes or setbacks.",
    "You are becoming the person you need to be.",
    "You make a difference in ways both big and small.",
    "You are learning to trust your own judgment.",
    "You are worthy of love and belonging.",
    "You can choose one kind thought about yourself today.",
    "You are brave for showing up, even when it's scary.",
    "You are allowed to change your mind and your plans.",
    "You are growing stronger with each challenge.",
    "You are allowed to celebrate small wins.",
    "You are patient with your own progress.",
    "You are allowed to take time to heal.",
    "You are allowed to enjoy simple pleasures.",
    "You are capable of calm and clarity.",
    "You are allowed to prioritize your needs.",
    "You are learning to trust the timing of your life.",
    "You are allowed to let go of what no longer serves you.",
    "You are worthy of rest without guilt.",
    "You are allowed to be imperfect and whole.",
    "You are allowed to be proud of how far you've come.",
    "You are allowed to protect your energy.",
    "You are allowed to say no without explaining yourself.",
    "You are allowed to be curious and explore.",
    "You are allowed to take breaks and come back refreshed.",
    "You are allowed to forgive yourself and move forward.",
    "You are allowed to be both strong and soft.",
    "You are allowed to make mistakes and learn from them.",
    "You are allowed to ask for what you need.",
    "You are allowed to rest even when there is more to do.",
    "You are allowed to be exactly who you are today.",
    "You are capable of handling uncertainty with grace.",
    "You are allowed to celebrate your uniqueness.",
    "You are allowed to create boundaries that feel right.",
    "You are allowed to be proud of small acts of courage.",
    "You are allowed to take up space in the world.",
    "You are allowed to be gentle with your inner critic.",
    "You are allowed to choose joy in small moments.",
    "You are allowed to trust your instincts.",
    "You are allowed to be patient with yourself.",
    "You are allowed to rest after giving your best.",
    "You are allowed to be both ambitious and content.",
    "You are allowed to let your curiosity lead you.",
    "You are allowed to celebrate progress, not perfection.",
    "You are allowed to be kind to yourself today.",
    "You are allowed to create a life that feels meaningful.",
    "You are allowed to take one step at a time.",
    "You are allowed to be proud of your resilience.",
    "You are allowed to choose peace over perfection.",
    "You are allowed to be gentle with your expectations.",
    "You are allowed to honor your limits and expand them slowly.",
    "You are allowed to rest when your body asks for it.",
    "You are allowed to be present with what is.",
    "You are allowed to trust that you are enough.",
    "You are allowed to celebrate your small victories.",
    "You are allowed to be patient with your healing.",
    "You are allowed to be kind to your future self.",
    "You are allowed to take time to reflect and reset.",
    "You are allowed to be proud of your consistency.",
    "You are allowed to choose compassion over criticism.",
    "You are allowed to be gentle with your expectations.",
    "You are allowed to be curious about your next step.",
    "You are allowed to rest and still be productive tomorrow.",
    "You are allowed to be a work in progress and still whole.",
    "You are allowed to trust your pace and your path.",
    "You are allowed to celebrate the courage in small acts.",
    "You are allowed to be present with your feelings without judgment.",
    "You are allowed to take imperfect action and learn.",
    "You are allowed to be kind to yourself in hard moments.",
    "You are allowed to choose what nourishes you today.",
    "You are allowed to be proud of trying again.",
    "You are allowed to be gentle with your inner voice.",
    "You are allowed to rest, reflect, and then continue.",
    "You are allowed to be both hopeful and realistic.",
    "You are allowed to create space for joy every day.",
    "You are allowed to be patient with your own timing.",
    "You are allowed to celebrate the small steps forward.",
    "You are allowed to be brave in quiet ways.",
    "You are allowed to trust that small habits build big change.",
    "You are allowed to be present with your breath right now.",
    "You are allowed to choose one thing that makes today better.",
    "You are allowed to be gentle with your expectations of others.",
    "You are allowed to be proud of your effort, not just outcomes.",
    "You are allowed to be kind to yourself when plans change.",
    "You are allowed to be curious about who you are becoming.",
    "You are allowed to rest and know that rest is productive.",
    "You are allowed to be patient with the process of growth.",
    "You are allowed to celebrate your courage to begin again.",
    "You are allowed to be tender with your heart and steady with your steps."
]

# File to store user favorites
FAV_FILE = Path.home() / ".affirmations_favorites.txt"

# ANSI color helpers
class Colors:
    GREEN = "\033[92m"
    CYAN = "\033[96m"
    YELLOW = "\033[93m"
    MAGENTA = "\033[95m"
    RESET = "\033[0m"
    BOLD = "\033[1m"

def load_favorites():
    if not FAV_FILE.exists():
        return []
    return [line.strip() for line in FAV_FILE.read_text(encoding="utf-8").splitlines() if line.strip()]

def save_favorite(text):
    FAV_FILE.parent.mkdir(parents=True, exist_ok=True)
    with FAV_FILE.open("a", encoding="utf-8") as f:
        f.write(text.strip() + "\n")

def choose_affirmation(all_affirmations):
    return random.choice(all_affirmations)

def pretty_print(affirmation, index=None, plain=False):
    """
    Print the affirmation.
    - If plain is True: print only the affirmation text to stdout.
    - If plain is False: print a colored prefix and the affirmation to stdout.
    """
    if plain:
        print(affirmation)
        return
    prefix = f"{Colors.BOLD}{Colors.CYAN}Affirmation{Colors.RESET}"
    if index is not None:
        prefix += f" {Colors.YELLOW}#{index}{Colors.RESET}"
    print(f"{prefix}: {Colors.GREEN}{affirmation}{Colors.RESET}")

def send_notification(title, message):
    if not HAS_PLYER:
        return
    try:
        notification.notify(title=title, message=message, timeout=6)
    except Exception:
        pass

def eprint(*args, **kwargs):
    """Print to stderr."""
    print(*args, file=sys.stderr, **kwargs)

# ---------------------------
# TTS: system-based, blocking (no pip)
# ---------------------------
def _which_tts_command():
    """
    Detect available system TTS command.
    Returns a tuple (platform_key, command_name) or (None, None) if none found.
    platform_key: 'mac', 'linux-spd', 'linux-espeak', 'win'
    """
    # macOS 'say'
    if shutil.which("say"):
        return ("mac", "say")
    # Linux: try spd-say then espeak
    if shutil.which("spd-say"):
        return ("linux-spd", "spd-say")
    if shutil.which("espeak"):
        return ("linux-espeak", "espeak")
    # Windows: check for powershell/pwsh
    if shutil.which("powershell") or shutil.which("pwsh"):
        return ("win", "powershell")
    return (None, None)

def speak_text_blocking(text):
    """
    Speak text using a system TTS command if available.
    This function runs the TTS command synchronously (blocking) so speech finishes
    before returning.
    """
    platform_key, cmd = _which_tts_command()
    if not platform_key:
        eprint("TTS unavailable on this system.")
        return

    # Log detected backend to stderr for debugging
    eprint(f"TTS backend detected: {platform_key} ({cmd})")

    try:
        if platform_key == "mac":
            # say <text> (blocking)
            subprocess.run([cmd, text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            return
        if platform_key == "linux-spd":
            # spd-say <text> (blocking)
            subprocess.run([cmd, text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            return
        if platform_key == "linux-espeak":
            # espeak "<text>" (blocking)
            subprocess.run([cmd, text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            return
        if platform_key == "win":
            # Use PowerShell to call System.Speech.Synthesis.SpeechSynthesizer synchronously
            pw = shutil.which("powershell") or shutil.which("pwsh")
            # Escape single quotes by doubling them for PowerShell single-quoted string
            escaped = text.replace("'", "''")
            ps_cmd = (
                "Add-Type -AssemblyName System.Speech;"
                f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{escaped}')"
            )
            subprocess.run([pw, "-NoProfile", "-Command", ps_cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            return
    except Exception as exc:
        eprint(f"TTS failed: {exc}")
        return

# ---------------------------
# Run logic
# ---------------------------
def run_once(args, pool, plain, tts_enabled):
    """
    Execute the requested action once.
    Returns after the action completes.
    """
    # If repeat-and-quit is used, pick one affirmation and print it that many times, then exit.
    if args.repeat_and_quit:
        a = choose_affirmation(pool)
        for r in range(args.repeat_and_quit):
            pretty_print(a, index=(r+1) if args.repeat_and_quit > 1 else None, plain=plain)
            if args.notify and HAS_PLYER:
                send_notification("Affirmation", a)
            if tts_enabled:
                speak_text_blocking(a)
            time.sleep(0.1)
        return

    # Non-loop mode: print count affirmations, each repeated args.repeat times
    if not args.loop:
        for i in range(1, max(1, args.count) + 1):
            a = choose_affirmation(pool)
            for r in range(args.repeat):
                idx_label = i if args.repeat == 1 else f"{i}.{r+1}"
                pretty_print(a, index=idx_label, plain=plain)
                if args.notify and HAS_PLYER:
                    send_notification("Affirmation", a)
                if tts_enabled:
                    speak_text_blocking(a)
        return

    # Loop mode: show affirmations until interrupted or until args.max reached
    idx = 1
    shown = 0
    try:
        while True:
            a = choose_affirmation(pool)
            for r in range(args.repeat):
                pretty_print(a, index=idx, plain=plain)
                if args.notify and HAS_PLYER:
                    send_notification("Affirmation", a)
                if tts_enabled:
                    speak_text_blocking(a)
                idx += 1
                shown += 1
                # If max is set and reached, quit gracefully
                if args.max and shown >= args.max:
                    if not plain:
                        eprint("\nFinished scheduled affirmations. Take a breath.")
                    return
                time.sleep(max(0.5, args.interval))
    except KeyboardInterrupt:
        if not plain:
            eprint("\nGood job showing up. Take a breath.")
        return

def main():
    parser = argparse.ArgumentParser(description="Random self-affirmations CLI")
    parser.add_argument("-n", "--count", type=int, default=1, help="Number of affirmations to show")
    parser.add_argument("--loop", action="store_true", help="Keep showing affirmations until interrupted")
    parser.add_argument("-i", "--interval", type=float, default=5.0, help="Seconds between affirmations when looping")
    parser.add_argument("--favorites", action="store_true", help="Show saved favorite affirmations")
    parser.add_argument("--add", type=str, help="Add a custom affirmation to favorites")
    parser.add_argument("--use-favorites", action="store_true", help="Pick affirmations from favorites if any")
    parser.add_argument("--notify", action="store_true", help="Send desktop notification if plyer is installed")

    # Existing options
    parser.add_argument("--repeat", type=int, default=1, help="Repeat each printed affirmation this many times")
    parser.add_argument("--max", type=int, default=0, help="When looping, quit after this many affirmations (0 = unlimited)")

    # Convenience option: pick one affirmation, repeat it N times, then quit
    parser.add_argument("--repeat-and-quit", type=int, default=0, help="Pick one affirmation, print it this many times, then exit (0 = disabled)")

    # Make plain output the default; provide --no-plain to show colors/prefixes and status messages.
    parser.add_argument("--plain", dest="plain", action="store_true", help="Print affirmation text only without colors or prefix")
    parser.add_argument("--no-plain", dest="plain", action="store_false", help="Show colors, prefix, and status messages")
    parser.set_defaults(plain=True)

    # New TTS option (system-based, no pip)
    parser.add_argument("--tts", dest="tts", action="store_true", help="Start with TTS enabled (system TTS, no pip required)")
    parser.add_argument("--no-tts", dest="tts", action="store_false", help="Start with TTS disabled")
    parser.set_defaults(tts=False)

    args = parser.parse_args()
    plain = args.plain
    tts_enabled = bool(args.tts)

    # Handle add/favorites quickly (these actions complete immediately)
    if args.add:
        save_favorite(args.add)
        if plain:
            print(args.add)
        else:
            eprint(f"{Colors.MAGENTA}Saved to favorites:{Colors.RESET} {args.add}")
        return

    favorites = load_favorites()
    if args.favorites:
        if not favorites:
            if plain:
                return
            else:
                eprint("No favorites saved yet. Use --add to save one.")
                return
        else:
            if plain:
                for f in favorites:
                    print(f)
            else:
                eprint(f"{Colors.BOLD}Saved favorites:{Colors.RESET}")
                for i, f in enumerate(favorites, 1):
                    eprint(f" {i}. {f}")
            return

    if args.use_favorites:
        pool = favorites if favorites else DEFAULT_AFFIRMATIONS
        if not favorites and not plain:
            eprint("No favorites found; falling back to default affirmations.")
    else:
        pool = DEFAULT_AFFIRMATIONS

    # Validate numeric options
    if args.repeat < 1:
        eprint("Error: --repeat must be >= 1")
        sys.exit(1)
    if args.max < 0:
        eprint("Error: --max must be >= 0")
        sys.exit(1)
    if args.repeat_and_quit < 0:
        eprint("Error: --repeat-and-quit must be >= 0")
        sys.exit(1)

    # Outer loop: run the requested action, then ask whether to repeat, toggle TTS, or quit.
    while True:
        run_once(args, pool, plain, tts_enabled)

        # After the run completes, prompt the user to repeat, toggle TTS, or quit.
        # Prompt goes to stderr so plain stdout remains only quotes.
        try:
            status = "ON" if tts_enabled else "OFF"
            eprint(f"\nTTS is currently: {status}")
            eprint("Press Enter to run again, type 't' then Enter to toggle TTS, or type 'q' then Enter to quit:")
            choice = input().strip().lower()
        except EOFError:
            # If input is not available (e.g., piped), exit.
            return

        if choice == 'q':
            return
        if choice == 't':
            tts_enabled = not tts_enabled
            eprint(f"TTS toggled to: {'ON' if tts_enabled else 'OFF'}")
            # loop and run again with new tts_enabled state
            continue
        # otherwise (empty or anything else) loop and run again

if __name__ == "__main__":
    main()
