import random
import sys
import subprocess
import shutil

def speak(text):
    """Cross-platform TTS using only system tools (no pyttsx3)."""
    platform = sys.platform

    # macOS: use built-in `say`
    if platform == "darwin":
        if shutil.which("say"):
            try:
                subprocess.run(["say", text], check=False)
            except Exception:
                pass
        return

    # Windows: use PowerShell System.Speech and pass text via stdin
    if platform.startswith("win"):
        try:
            ps_cmd = [
                "powershell",
                "-Command",
                "Add-Type -AssemblyName System.speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak([Console]::In.ReadToEnd())"
            ]
            subprocess.run(ps_cmd, input=text, text=True, check=False)
        except Exception:
            pass
        return

    # Linux / other Unix: try spd-say then espeak
    if shutil.which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=False)
            return
        except Exception:
            pass
    if shutil.which("espeak"):
        try:
            subprocess.run(["espeak", text], check=False)
            return
        except Exception:
            pass

    # No TTS available: silent fallback
    return

def generate_pet_name():
    prefixes = [
        "Fluffy", "Tiny", "Misty", "Biscuit", "Pumpkin", "Noodle", "Wiggle",
        "Snuggle", "Puddle", "Pebble", "Mocha", "Sprinkle", "Button", "Cuddle",
        "Pipsqueak", "Muffin", "Toffee", "Pickle", "Bubbles", "Doodle",
        "Shadow", "Blaze", "Ranger", "Storm", "Echo", "Nova", "Cosmo",
        "Rocket", "Turbo", "Phantom", "Vortex", "Drift", "Comet", "Rogue",
        "Wobble", "Goober", "Booper", "Zonko", "Fizzle", "Wompus", "Gizmo",
        "Bongo", "Zippy", "Chompy", "Snorkel", "Waffle", "Tater", "Bloop",
        "Sir", "Lady", "Count", "Duchess", "Baron", "Captain", "Professor",
        "Doctor", "Major", "Admiral", "Queen", "King", "Prince", "Dame",
        "Sunny", "River", "Maple", "Cedar", "Juniper", "Sable", "Indigo",
        "Pixel", "Byte", "Orbit", "Zephyr", "Mango", "Clover",
        "Sparrow", "Marble", "Nimbus", "Riddle", "Fable", "Jinx"
    ]

    animals = [
        "Paws", "Whiskers", "Tail", "Nose", "Claws", "Fur", "Bean",
        "Hopper", "Squeak", "Puff", "Barker", "Howler", "Chirp", "Wag",
        "Tiger", "Lion", "Panther", "Wolf", "Fox", "Bear", "Otter", "Badger",
        "Hedgehog", "Moose", "Falcon", "Eagle", "Hawk", "Raven", "Owl",
        "Penguin", "Dolphin", "Shark", "Turtle", "Lizard", "Frog", "Bunny",
        "Snout", "Fluffball", "Wiggleworm", "Pupper", "Kitty", "Chonker",
        "Sniffer", "Booper", "Chubster", "Fuzzbug", "Snoot", "Munchkin",
        "Dragon", "Griffin", "Phoenix", "Unicorn", "Hydra", "Sprite",
        "Goblin", "Troll", "Imp", "Golem", "Wisp", "Yeti",
        "Moth", "Cricket", "Skipper", "Mariner", "Rascal", "Bandit", "Voyager"
    ]

    endings = [
        "", "", "", " Jr.", " III", " the Brave", " the Tiny", " the Great",
        " the Swift", " the Fluffy", " the Loud", " the Wise", " of Legend",
        " of Mischief", " of Sunshine", " of Midnight"
    ]

    return f"{random.choice(prefixes)} {random.choice(animals)}{random.choice(endings)}"

def main():
    print("🐾 Mega Pet Name Generator with system TTS (no pyttsx3) 🐾")

    # Detect available TTS backend
    tts_available = False
    if sys.platform == "darwin" and shutil.which("say"):
        tts_available = True
    elif sys.platform.startswith("win"):
        tts_available = True  # PowerShell is expected on modern Windows
    elif shutil.which("spd-say") or shutil.which("espeak"):
        tts_available = True

    tts_default = "y" if tts_available else "n"
    enable_tts = input(f"Enable voice for names? (Y/n) [default {tts_default}]: ").strip().lower() or tts_default
    use_tts = (enable_tts == "y") and tts_available

    if enable_tts == "y" and not tts_available:
        print("No system TTS tool found. On macOS 'say' is built-in; on Linux install spd-say or espeak; Windows uses PowerShell.")

    while True:
        name = generate_pet_name()
        print("Your pet name:", name)
        if use_tts:
            speak(name)
        again = input("Generate another? (Y/n): ").strip().lower() or "y"
        if again != "y":
            break

    print("Goodbye!")

if __name__ == "__main__":
    main()
