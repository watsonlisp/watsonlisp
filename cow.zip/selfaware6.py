#!/usr/bin/env python3
"""
Self Awareness Quote Generator with TTS toggle and runtime count change.
Expanded built-in quote library.
Controls during interactive mode:
  - Enter : show another quote
  - t     : toggle TTS on/off
  - c N   : set count to N (e.g., "c 3")
  - q     : quit
  - Ctrl+C: interrupt and exit
"""

import argparse
import random
import json
import sys
import subprocess
import platform
import shutil
from typing import List, Dict, Optional

BUILT_IN_QUOTES: Dict[str, List[str]] = {
    "clarity": [
        "Notice the thought before you follow it.",
        "Clarity begins when you stop defending your story.",
        "Observe without judgment and the fog will lift.",
        "Name the feeling and it loses some of its power.",
        "When you simplify your questions, answers become clearer.",
        "Clear seeing starts with honest noticing.",
        "Ask: What is true right now?",
        "A single clear breath can reset a scattered mind.",
        "Distinguish fact from interpretation and you gain choice.",
        "Clarity is the quiet that follows honest attention.",
        "Let go of what you assume and see what remains.",
        "When you slow down, the outline of truth appears.",
        "Clarity is a practice, not a one-time event.",
        "The mind clears when you stop arguing with reality.",
        "Labeling a thought gives you distance from it.",
        "Clarity grows when curiosity replaces certainty.",
        "A clear question is the doorway to a useful answer.",
        "Notice the edges of your thinking before you act.",
        "Simplicity often hides the deepest clarity.",
        "Clarity asks you to look, not to fix."
    ],
    "growth": [
        "Growth asks for curiosity more than certainty.",
        "Mistakes are the tuition you pay for wisdom.",
        "Stretching is uncomfortable until it becomes strength.",
        "Small consistent steps beat occasional big leaps.",
        "Growth is the art of becoming comfortable with being uncomfortable.",
        "Every 'not yet' is a sign you're learning.",
        "Feedback is a gift when you choose to open it.",
        "Practice compounds in ways you rarely notice at first.",
        "Let failure be data, not identity.",
        "Growth requires leaving the safety of what you already know.",
        "Try, reflect, adjust, repeat.",
        "The path forward is often a series of tiny corrections.",
        "Curiosity is the engine of personal evolution.",
        "If it matters, do it imperfectly and keep going.",
        "Growth is choosing the long game over instant comfort.",
        "Ask what you can learn before you ask who is to blame.",
        "Progress is rarely linear; keep showing up.",
        "Change begins with a single honest choice.",
        "Your future self is built by today's small decisions.",
        "Be patient with the process; be relentless with the practice."
    ],
    "compassion": [
        "Treat your inner critic like a worried friend, not an enemy.",
        "Compassion for yourself opens the door to compassion for others.",
        "Gentleness is a radical act of self-awareness.",
        "Speak to yourself as you would to someone you love.",
        "Compassion begins with noticing your own pain.",
        "You are allowed to be both a work in progress and a whole person.",
        "Kindness toward yourself fuels resilience.",
        "Forgiveness is a practice that frees the forgiver.",
        "Hold your mistakes with curiosity, not contempt.",
        "Self-compassion is not indulgence; it is care.",
        "When you soften toward yourself, the world softens too.",
        "Be present with your struggle without making it permanent.",
        "A compassionate pause can change the course of a day.",
        "You deserve the same patience you give others.",
        "Compassion is a muscle; use it daily.",
        "Notice the harsh voice and offer a kinder alternative.",
        "Caring for yourself is an act of courage.",
        "Allow your limits without shame.",
        "Tenderness toward yourself is a foundation for strength.",
        "Start with one small act of kindness for yourself today."
    ],
    "presence": [
        "The present moment is the only place you can truly meet yourself.",
        "Breathe, notice, return — presence is a practice.",
        "Attention is the currency of inner life.",
        "Where attention goes, life grows.",
        "Presence is listening to what is, not what you wish it to be.",
        "A single breath anchors you to now.",
        "Notice the sensations before the story begins.",
        "Presence is the simplest form of courage.",
        "When you arrive in the moment, you stop chasing it.",
        "Presence turns ordinary moments into meaning.",
        "Slow down; the present is generous when you pay attention.",
        "The body knows what the mind forgets.",
        "Presence is a habit you can train like a muscle.",
        "Observe the breath and the mind will follow.",
        "Being here is the most radical thing you can do.",
        "Presence dissolves the tyranny of past and future.",
        "Meet your experience with open eyes and soft hands.",
        "The doorway to insight is often a quiet moment.",
        "Presence is noticing the small things before they become big.",
        "Show up for yourself in the simplest way: be here."
    ],
    "mindfulness": [
        "Notice thoughts as passing weather, not permanent terrain.",
        "Mindfulness is attention with kindness.",
        "Return to the breath as often as you need.",
        "Observe without fixing and wisdom will emerge.",
        "Mindfulness is the practice of befriending your experience.",
        "A moment of mindful pause can change a reaction.",
        "Watch the mind like you would watch a river flow.",
        "Mindfulness creates space between stimulus and response.",
        "Be curious about your inner life without judgment.",
        "The present is the only place where change can happen.",
        "Mindfulness is noticing the automatic and choosing otherwise.",
        "Start small: one mindful breath, one mindful step.",
        "The simplest practice is often the most transformative.",
        "Mindfulness is a lighthouse in stormy seas.",
        "Observe sensations before you narrate them.",
        "Gentle attention heals habitual reactivity.",
        "Mindfulness is a daily appointment with yourself.",
        "Notice the gap between thought and action.",
        "Practice noticing what you usually ignore.",
        "Mindfulness is the art of waking up to now."
    ],
    "resilience": [
        "Resilience is the quiet courage to keep going.",
        "Bend, don't break; adapt, don't surrender.",
        "Resilience grows from small recoveries, not single victories.",
        "You are stronger than the moment that challenges you.",
        "Collect small wins and they will carry you forward.",
        "Resilience is practiced in the ordinary moments of repair.",
        "When plans fail, curiosity becomes your compass.",
        "Hold steady; storms pass and you remain.",
        "Resilience is choosing to try again with what you learned.",
        "Softness and strength can coexist in the same heart.",
        "The comeback begins with one honest step.",
        "Resilience is built by facing difficulty with presence.",
        "Allow yourself to be imperfect and keep moving.",
        "Courage is resilience in action.",
        "Recoveries are the quiet architecture of a life well-lived.",
        "When you fall, notice how you rise.",
        "Resilience is the practice of returning to center.",
        "Keep the long view; small setbacks are not the whole story.",
        "Adaptation is resilience in motion.",
        "Trust that you can handle more than you imagine."
    ],
    "introspection": [
        "Ask better questions and your answers will deepen.",
        "What you resist reveals what you need to explore.",
        "Turn your attention inward with curiosity, not blame.",
        "Introspection is the lamp that lights your inner path.",
        "Sit with the question longer than you think you should.",
        "Your inner life is a landscape worth mapping.",
        "Notice the recurring themes in your reactions.",
        "Reflection without judgment is the seed of change.",
        "Ask: What is this trying to teach me?",
        "Introspection is a practice of gentle excavation.",
        "Listen to the quiet voice beneath the loud one.",
        "Your patterns are information, not condemnation.",
        "A single honest answer can shift a lifetime of habit.",
        "Make space for the feelings you usually avoid.",
        "Introspection is curiosity applied to the self.",
        "Write one sentence about how you feel right now.",
        "The mirror of introspection shows what action needs to follow.",
        "Be willing to be surprised by what you find.",
        "Reflection turns experience into wisdom.",
        "Introspection is the art of becoming known to yourself."
    ],
    "boundaries": [
        "Boundaries are how you love yourself and others honestly.",
        "Saying no is a way of saying yes to what matters.",
        "Clear limits create healthy connection.",
        "Boundaries are an act of self-respect, not selfishness.",
        "Protect your energy with gentle firmness.",
        "You can be kind and still keep your limits.",
        "Boundaries teach others how to treat you.",
        "A boundary is a statement, not a punishment.",
        "Practice saying no to small things to protect big things.",
        "Boundaries are the architecture of sustainable relationships.",
        "Respect your limits before you resent others.",
        "Boundaries are a practice, not a one-time speech.",
        "Set limits with clarity and compassion.",
        "Healthy boundaries free you to be fully present.",
        "Boundaries are a gift you give yourself.",
        "You do not need to explain every boundary you set.",
        "Firmness with kindness is a powerful combination.",
        "Boundaries protect your capacity to show up.",
        "Notice when you compromise your limits and learn from it.",
        "Boundaries are the soil where trust can grow."
    ],
    "default": [
        "Ask yourself what you need before you act.",
        "You are not your thoughts; you are the one who notices them.",
        "Small daily reflections compound into deep understanding.",
        "Start where you are with what you have.",
        "One mindful choice can change the tone of a day.",
        "Be present enough to notice what matters.",
        "Compassion and curiosity make a powerful pair.",
        "A single breath can change your next move.",
        "Notice one thing you are grateful for right now.",
        "Progress is built from tiny consistent actions.",
        "Be patient with yourself; growth takes time.",
        "Choose presence over perfection in small ways.",
        "Listen more than you react and learn more than you judge.",
        "Make room for rest as part of your practice.",
        "Celebrate small steps as evidence of change.",
        "When overwhelmed, return to the breath and the body.",
        "Clarity often arrives after a pause.",
        "Be kind to the part of you that is struggling.",
        "Reflection without action is only thinking; action without reflection is only motion.",
        "Keep showing up; the compound effect is real."
    ]
}

REFLECTIVE_TEMPLATES = [
    "What part of this quote resonates with you right now?",
    "When did you last feel this way? Describe the situation.",
    "What small action could you take today that aligns with this idea?",
    "How would your day change if you acted on this?",
    "Who could you share this insight with and why?"
]

def load_custom_quotes(path: str) -> List[str]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]
    except Exception as e:
        raise RuntimeError(f"Could not read file {path}: {e}")

def gather_quotes(theme: Optional[str], custom_file: Optional[str]) -> List[str]:
    if custom_file:
        quotes = load_custom_quotes(custom_file)
    else:
        if theme and theme in BUILT_IN_QUOTES:
            quotes = BUILT_IN_QUOTES[theme][:]
        elif theme:
            quotes = BUILT_IN_QUOTES.get("default", [])[:]
            for k, v in BUILT_IN_QUOTES.items():
                if theme.lower() in k.lower():
                    quotes.extend(v)
        else:
            quotes = []
            for v in BUILT_IN_QUOTES.values():
                quotes.extend(v)
    if not quotes:
        quotes = BUILT_IN_QUOTES["default"][:]
    return quotes

def pick_quotes(quotes: List[str], count: int, rng: random.Random) -> List[str]:
    if count >= len(quotes):
        rng.shuffle(quotes)
        return quotes[:count]
    return rng.sample(quotes, count)

def make_reflective_prompt(quote: str, rng: random.Random) -> str:
    template = rng.choice(REFLECTIVE_TEMPLATES)
    return f"{quote} — {template}"

def format_text(quotes: List[str], include_prompts: bool, rng: random.Random) -> str:
    lines = []
    for i, q in enumerate(quotes, 1):
        lines.append(f"{i}. {q}")
        if include_prompts:
            lines.append(f"   Prompt: {make_reflective_prompt(q, rng)}")
    return "\n".join(lines)

def format_json(quotes: List[str], include_prompts: bool, rng: random.Random) -> str:
    items = []
    for q in quotes:
        item = {"quote": q}
        if include_prompts:
            item["prompt"] = make_reflective_prompt(q, rng)
        items.append(item)
    return json.dumps({"results": items}, ensure_ascii=False, indent=2)

def speak(text: str, voice: Optional[str] = None) -> bool:
    system = platform.system()
    if system == "Darwin":
        cmd = ["say"]
        if voice:
            cmd += ["-v", voice]
        cmd.append(text)
        try:
            subprocess.run(cmd, check=False)
            return True
        except Exception:
            return False
    if system == "Windows":
        safe_text = text.replace("'", "''")
        ps_cmd = (
            "Add-Type -AssemblyName System.Speech;"
            f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        )
        if voice:
            ps_cmd += f"try {{$s.SelectVoice('{voice}')}} catch {{}};"
        ps_cmd += f"$s.Speak('{safe_text}');"
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return True
        except Exception:
            return False
    if system == "Linux":
        if shutil.which("spd-say"):
            cmd = ["spd-say"]
            if voice:
                cmd += ["-o", voice]
            cmd.append(text)
            try:
                subprocess.run(cmd, check=False)
                return True
            except Exception:
                pass
        if shutil.which("espeak"):
            cmd = ["espeak", text]
            try:
                subprocess.run(cmd, check=False)
                return True
            except Exception:
                pass
        return False
    return False

def parse_args():
    p = argparse.ArgumentParser(description="Self Awareness Quote Generator with TTS toggle and runtime count change")
    p.add_argument("--count", type=int, default=1, help="Number of quotes per iteration")
    p.add_argument("--theme", type=str, default=None, help="Theme to filter quotes")
    p.add_argument("--file", type=str, default=None, help="Path to custom quote file (one quote per line)")
    p.add_argument("--format", choices=["text", "json"], default="text", help="Output format")
    p.add_argument("--seed", type=int, default=None, help="Random seed for reproducible output")
    p.add_argument("--prompt", action="store_true", help="Include a short reflective prompt with each quote")
    p.add_argument("--once", action="store_true", help="Run one iteration and exit")
    p.add_argument("--tts", action="store_true", help="Start with TTS enabled")
    p.add_argument("--voice", type=str, default=None, help="Optional voice name for TTS if supported")
    return p.parse_args()

def run_iteration(quotes_pool: List[str], count: int, args, rng: random.Random, tts_enabled: bool):
    selected = pick_quotes(quotes_pool, max(1, count), rng)
    if args.format == "json":
        out = format_json(selected, args.prompt, rng)
    else:
        out = format_text(selected, args.prompt, rng)
    print(out)
    if tts_enabled:
        for q in selected:
            ok = speak(q, voice=args.voice)
            if not ok:
                print("TTS not available on this system or required command not found.")
                return False
            if args.prompt:
                prompt = make_reflective_prompt(q, rng)
                speak(prompt, voice=args.voice)
    return True

def interactive_loop(quotes_pool: List[str], args):
    rng = random.Random(args.seed)
    tts_enabled = bool(args.tts)
    current_count = max(1, args.count)
    try:
        while True:
            print(f"\n[TTS {'ON' if tts_enabled else 'OFF'}] Showing {current_count} quote(s)\n")
            ok = run_iteration(quotes_pool, current_count, args, rng, tts_enabled)
            if args.once:
                break
            try:
                user = input("\nPress Enter for another quote, 't' to toggle TTS, 'c N' to set count, or 'q' to quit: ").strip()
            except EOFError:
                print("\nNo input available. Exiting.")
                break
            if not user:
                continue
            cmd = user.lower().split()
            if cmd[0] == "q":
                print("Goodbye. Take care.")
                break
            if cmd[0] == "t":
                tts_enabled = not tts_enabled
                print(f"TTS toggled {'ON' if tts_enabled else 'OFF'}.")
                continue
            if cmd[0] == "c" or cmd[0] == "count":
                if len(cmd) >= 2:
                    try:
                        new_count = int(cmd[1])
                        if new_count < 1:
                            print("Count must be at least 1.")
                        else:
                            current_count = new_count
                            print(f"Count set to {current_count}.")
                    except ValueError:
                        print("Invalid number. Use: c N  (e.g., c 3)")
                else:
                    print("Specify a number. Use: c N  (e.g., c 3)")
                continue
    except KeyboardInterrupt:
        print("\nInterrupted. Goodbye.")
        sys.exit(0)

def main():
    args = parse_args()
    quotes_pool = gather_quotes(args.theme, args.file)
    interactive_loop(quotes_pool, args)

if __name__ == "__main__":
    main()
