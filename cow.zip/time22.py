import tkinter as tk
from datetime import datetime
import time
import threading
import os
import sys
import tempfile
import wave
import struct
import math
import subprocess

# Seven-segment mapping for digits 0-9
SEGMENTS = {
    '0': (1,1,1,1,1,1,0),
    '1': (0,1,1,0,0,0,0),
    '2': (1,1,0,1,1,0,1),
    '3': (1,1,1,1,0,0,1),
    '4': (0,1,1,0,0,1,1),
    '5': (1,0,1,1,0,1,1),
    '6': (1,0,1,1,1,1,1),
    '7': (1,1,1,0,0,0,0),
    '8': (1,1,1,1,1,1,1),
    '9': (1,1,1,1,0,1,1),
    '-': (0,0,0,0,0,0,1),
    ' ': (0,0,0,0,0,0,0)
}

# ----------------------------
# Sound utilities (cross-platform)
# ----------------------------
def _synthesize_tone(frequency_hz=440.0, duration_ms=300, volume=0.5, sample_rate=44100):
    """Return raw PCM frames (16-bit little endian) for a sine tone."""
    n_samples = int(sample_rate * (duration_ms / 1000.0))
    frames = bytearray()
    amplitude = int(32767 * max(0.0, min(1.0, volume)))
    for i in range(n_samples):
        t = float(i) / sample_rate
        sample = int(amplitude * math.sin(2.0 * math.pi * frequency_hz * t))
        frames += struct.pack('<h', sample)
    return bytes(frames), sample_rate

def _write_wav_file(path, pcm_bytes, sample_rate):
    """Write 16-bit mono WAV file to path."""
    with wave.open(path, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)  # 16-bit
        wf.setframerate(sample_rate)
        wf.writeframes(pcm_bytes)

def _play_wav_file(path):
    """Play a WAV file using platform-appropriate method. Blocks until finished."""
    if sys.platform.startswith('win'):
        try:
            import winsound
            winsound.PlaySound(path, winsound.SND_FILENAME)
            return True
        except Exception:
            return False
    elif sys.platform == 'darwin':
        # macOS: afplay
        try:
            subprocess.run(['afplay', path], check=True)
            return True
        except Exception:
            return False
    else:
        # Try common Linux players
        for cmd in (['aplay', path], ['paplay', path], ['play', path]):
            try:
                subprocess.run(cmd, check=True)
                return True
            except Exception:
                continue
        return False

def play_tone(frequency=440.0, duration_ms=300, volume=0.5, fallback_bell=None):
    """Generate a tone and play it asynchronously. Returns immediately."""
    def _worker():
        pcm, sr = _synthesize_tone(frequency, duration_ms, volume, sample_rate=44100)
        try:
            fd, path = tempfile.mkstemp(suffix='.wav')
            os.close(fd)
            _write_wav_file(path, pcm, sr)
            played = _play_wav_file(path)
            if not played and fallback_bell:
                # fallback to tkinter bell if available
                try:
                    fallback_bell()
                except Exception:
                    pass
        finally:
            try:
                os.remove(path)
            except Exception:
                pass
    threading.Thread(target=_worker, daemon=True).start()

def play_sweep(start_hz=300.0, end_hz=2000.0, duration_ms=800, steps=60, volume=0.6, fallback_bell=None):
    """Create a rising (or falling) sweep by concatenating short tones."""
    def _worker():
        chunk_ms = max(10, int(duration_ms / steps))
        for i in range(steps):
            frac = i / max(1, steps - 1)
            freq = start_hz + (end_hz - start_hz) * frac
            pcm, sr = _synthesize_tone(freq, chunk_ms, volume, sample_rate=44100)
            try:
                fd, path = tempfile.mkstemp(suffix='.wav')
                os.close(fd)
                _write_wav_file(path, pcm, sr)
                played = _play_wav_file(path)
                if not played and fallback_bell:
                    try:
                        fallback_bell()
                    except Exception:
                        pass
            finally:
                try:
                    os.remove(path)
                except Exception:
                    pass
    threading.Thread(target=_worker, daemon=True).start()

# ----------------------------
# Seven-segment display classes
# ----------------------------
class SevenSegment:
    def __init__(self, canvas, x, y, size=20, color_on="#FF3333", color_off="#330000"):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.size = size
        self.color_on = color_on
        self.color_off = color_off
        s = size
        w = max(2, s // 6)
        h = s
        self.coords = [
            (x+w, y, x+3*s-w, y, x+3*s-2*w, y+w, x+w+2*w, y+w),
            (x+3*s-w, y, x+3*s, y+w, x+3*s, y+h+w, x+3*s-w, y+h),
            (x+3*s-w, y+h, x+3*s, y+h+w, x+3*s, y+2*h+w, x+3*s-w, y+2*h),
            (x+w, y+2*h, x+3*s-w, y+2*h, x+3*s-2*w, y+2*h+w, x+w+2*w, y+2*h+w),
            (x, y+h, x+w, y+h+w, x+w, y+2*h+w, x, y+2*h),
            (x, y, x+w, y+w, x+w, y+h+w, x, y+h),
            (x+w, y+h, x+3*s-w, y+h, x+3*s-2*w, y+h+w, x+w+2*w, y+h+w)
        ]
        self.items = [self.canvas.create_polygon(c, fill=self.color_off, outline="#111111") for c in self.coords]

    def set_digit(self, ch, on_color=None, off_color=None):
        pattern = SEGMENTS.get(ch, SEGMENTS[' '])
        for i, seg_on in enumerate(pattern):
            color = on_color if seg_on and on_color else (self.color_on if seg_on else (off_color if off_color else self.color_off))
            self.canvas.itemconfig(self.items[i], fill=color)

class LEDDisplay:
    def __init__(self, root, x, y, digits=10, size=18, spacing=6, on_color="#FF3333", off_color="#220000", label_text=""):
        width = digits * (size*3 + spacing) + 20
        height = size*6 + 60
        self.canvas = tk.Canvas(root, width=width, height=height, bg="#000000", highlightthickness=0)
        self.canvas.place(x=x, y=y)
        self.digits = []
        self.size = size
        self.on_color = on_color
        self.off_color = off_color
        dx = 10
        for i in range(digits):
            seg = SevenSegment(self.canvas, dx, 20, size=size, color_on=on_color, color_off=off_color)
            self.digits.append(seg)
            dx += size*3 + spacing
        if label_text:
            self.canvas.create_text(width//2, 10, text=label_text, fill="#FFFFFF", font=("Helvetica", 10, "bold"))
        self.canvas.create_text(width//2, height-18, text="YYYY-MM-DD", fill="#AAAAAA", font=("Consolas", 9))
        self.current_text = " " * digits

    def set_text(self, text, color_on=None):
        text = text[:len(self.digits)].rjust(len(self.digits))
        for i, ch in enumerate(text):
            self.digits[i].set_digit(ch, on_color=color_on if color_on else self.on_color, off_color=self.off_color)

    def flash(self, times=6, interval=0.15, flash_color="#00FF00"):
        def _flash():
            for i in range(times):
                self.set_text(" " * len(self.digits), color_on=self.off_color)
                time.sleep(interval)
                self.set_text(self.current_text, color_on=flash_color)
                time.sleep(interval)
            self.set_text(self.current_text, color_on=self.on_color)
        threading.Thread(target=_flash, daemon=True).start()

    def show(self, text):
        self.current_text = text
        self.set_text(text, color_on=self.on_color)

# ----------------------------
# Main TimeConsole with sounds
# ----------------------------
class TimeConsole:
    def __init__(self, root):
        self.root = root
        root.title("Time Travel Console")
        root.configure(bg="#111111")
        # keep window size the same but slightly taller to accommodate keypad comfortably
        root.geometry("980x420")
        # Displays
        self.dest = LEDDisplay(root, 20, 20, digits=10, size=20, spacing=6, on_color="#FF3333", label_text="DESTINATION TIME")
        self.present = LEDDisplay(root, 20, 150, digits=10, size=20, spacing=6, on_color="#00FF00", label_text="PRESENT TIME")
        self.last = LEDDisplay(root, 20, 280, digits=10, size=20, spacing=6, on_color="#FFFF00", label_text="LAST TIME DEPARTED")
        # Controls
        # center the entry and make it slightly smaller so keypad fits
        self.entry = tk.Entry(root, width=12, font=("Consolas", 13), justify='center')
        self.entry.place(x=700, y=36)
        self.entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
        tk.Button(root, text="Set Destination", command=self.set_destination, bg="#222", fg="white").place(x=860, y=32)
        tk.Button(root, text="Engage", command=self.engage, bg="#880000", fg="white", width=12).place(x=700, y=72)
        tk.Button(root, text="Flash Test", command=self.flash_test, bg="#333", fg="white").place(x=860, y=72)
        tk.Button(root, text="Resume Time", command=self.resume_time, bg="#224", fg="white").place(x=700, y=108)

        # Keypad frame (buttons to type date)
        # place keypad a bit lower and use compact buttons so everything fits
        self._create_keypad(root, x=700, y=150)

        # initialize times
        self.destination_time = self.entry.get()
        self.present_time = datetime.now().strftime("%Y-%m-%d")
        self.last_time = "0000-00-00"
        self.update_displays()
        # update present time every second
        self._running = True
        threading.Thread(target=self._tick, daemon=True).start()

    # ----------------------------
    # Keypad helpers
    # ----------------------------
    def _create_keypad(self, root, x=700, y=150):
        """Create a compact keypad for entering date characters that fits the window."""
        frame = tk.Frame(root, bg="#111111")
        frame.place(x=x, y=y)
        # compact button configuration
        btn_cfg = {'width':3, 'height':1, 'bg':"#444", 'fg':"white", 'font':("Consolas", 10, "bold")}
        # layout: 3x4 grid for digits, then a row for -, Backspace, Clear, Enter
        keys = [
            ('1', 0, 0), ('2', 1, 0), ('3', 2, 0),
            ('4', 0, 1), ('5', 1, 1), ('6', 2, 1),
            ('7', 0, 2), ('8', 1, 2), ('9', 2, 2),
            ('-', 0, 3), ('0', 1, 3), ('⌫', 2, 3),
        ]
        for (label, col, row) in keys:
            action = (lambda ch=label: self._keypad_insert(ch))
            b = tk.Button(frame, text=label, command=action, **btn_cfg)
            b.grid(row=row, column=col, padx=3, pady=3)
        # bottom row: Clear and Enter spanning columns
        clear_btn = tk.Button(frame, text="Clear", command=self._keypad_clear, width=7, height=1, bg="#882222", fg="white", font=("Consolas", 10, "bold"))
        clear_btn.grid(row=4, column=0, columnspan=2, padx=3, pady=6, sticky="we")
        enter_btn = tk.Button(frame, text="Enter", command=self._keypad_enter, width=3, height=1, bg="#225522", fg="white", font=("Consolas", 10, "bold"))
        enter_btn.grid(row=4, column=2, padx=3, pady=6)

    def _keypad_insert(self, ch):
        """Insert character at current cursor position in the Entry."""
        try:
            if ch == '⌫':
                pos = self.entry.index(tk.INSERT)
                if pos > 0:
                    self.entry.delete(pos-1)
            else:
                idx = self.entry.index(tk.INSERT)
                self.entry.insert(idx, ch)
            # keep focus on entry
            self.entry.focus_set()
            # small click sound
            self._click()
        except Exception:
            pass

    def _keypad_clear(self):
        self.entry.delete(0, tk.END)
        self.entry.focus_set()
        play_tone(220.0, 120, 0.5, fallback_bell=self._bell)

    def _keypad_enter(self):
        # call the same action as Set Destination
        self.set_destination()

    # ----------------------------
    # Sound helpers bound to UI
    # ----------------------------
    def _bell(self):
        try:
            self.root.bell()
        except Exception:
            pass

    def _click(self):
        # short click
        play_tone(880.0, 80, 0.4, fallback_bell=self._bell)

    def _countdown_beep(self):
        # quick beep for countdown
        play_tone(880.0, 140, 0.6, fallback_bell=self._bell)

    def _low_beep(self):
        play_tone(440.0, 160, 0.5, fallback_bell=self._bell)

    def _final_sweep(self):
        # rising sweep for dramatic effect
        play_sweep(300.0, 2200.0, duration_ms=900, steps=80, volume=0.7, fallback_bell=self._bell)

    # ----------------------------
    # Display and control logic
    # ----------------------------
    def set_destination(self):
        val = self.entry.get().strip()
        try:
            datetime.strptime(val, "%Y-%m-%d")
            self.destination_time = val
            self.dest.show(self._format_date(val))
            self._click()
        except ValueError:
            self.entry.delete(0, tk.END)
            self.entry.insert(0, "Invalid format")
            # error beep
            play_tone(220.0, 300, 0.6, fallback_bell=self._bell)

    def _format_date(self, date_str):
        return date_str[:10].rjust(10)

    def update_displays(self):
        self.dest.show(self._format_date(self.destination_time))
        self.present.show(self._format_date(self.present_time))
        self.last.show(self._format_date(self.last_time))

    def _tick(self):
        while True:
            if not self._running:
                # sleep briefly to avoid busy loop while paused
                time.sleep(0.2)
                continue
            self.present_time = datetime.now().strftime("%Y-%m-%d")
            self.present.show(self._format_date(self.present_time))
            time.sleep(1)

    def flash_test(self):
        # visual flash + chime
        self.dest.flash(times=4, interval=0.12, flash_color="#FFAA00")
        self.present.flash(times=4, interval=0.12, flash_color="#00FFAA")
        self.last.flash(times=4, interval=0.12, flash_color="#AAAA00")
        # play a short arpeggio
        def _chime():
            play_tone(660.0, 120, 0.5, fallback_bell=self._bell)
            time.sleep(0.14)
            play_tone(880.0, 120, 0.5, fallback_bell=self._bell)
            time.sleep(0.14)
            play_tone(990.0, 200, 0.6, fallback_bell=self._bell)
        threading.Thread(target=_chime, daemon=True).start()

    def engage(self):
        threading.Thread(target=self._engage_sequence, daemon=True).start()

    def _engage_sequence(self):
        departure_time = self.present_time
        # countdown 10..1 with beeps
        for i in range(10, 0, -1):
            txt = f"{i:>10}"
            self.dest.show(txt)
            self.present.flash(times=1, interval=0.12, flash_color="#FF0000")
            self.last.flash(times=1, interval=0.12, flash_color="#FFAA00")
            # play countdown beep
            self._countdown_beep()
            time.sleep(0.8)
        # final dramatic sweep + rapid flashes
        for _ in range(6):
            self.dest.set_text(" " * 10, color_on=self.dest.off_color)
            time.sleep(0.08)
            self.dest.show(self._format_date(self.destination_time))
            time.sleep(0.08)
        # play final sweep and low thump
        self._final_sweep()
        time.sleep(0.12)
        self._low_beep()
        # update last and present times to simulate travel
        self.last_time = departure_time
        self.present_time = self.destination_time

        # stop live ticking so present date stays at destination
        self._running = False

        self.update_displays()

    def resume_time(self):
        """Resume live updating of Present time."""
        if not self._running:
            self._running = True
            threading.Thread(target=self._tick, daemon=True).start()

def main():
    root = tk.Tk()
    app = TimeConsole(root)
    root.mainloop()

if __name__ == "__main__":
    main()
