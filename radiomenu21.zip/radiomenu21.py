import tkinter as tk
import os

def execute_program():
    selected_program = var.get()
    if selected_program == "Program 1":
        os.system("c:/python/radio11.py")
    elif selected_program == "Program 2":
        os.system("c:/python/radio10.py")
    elif selected_program == "Program 3":
        os.system("c:/python/radio9.py")
    elif selected_program == "Program 4":
        os.system("c:/python/radio8.py")
    elif selected_program == "Program 5":
        os.system("c:/python/radio6.py")
    elif selected_program == "Program 6":
        os.system("c:/python/radio12.py")
    elif selected_program == "Program 7":
        os.system("c:/python/radio13.py")
    elif selected_program == "Program 8":
        os.system("c:/python/radio14.py")
    elif selected_program == "Program 9":
        os.system("c:/python/radio15.py")

    elif selected_program == "Program 10":
        os.system("c:/python/radio16.py")

    elif selected_program == "Program 11":
        os.system("c:/python/radio17.py")

    elif selected_program == "Program 12":
        os.system("c:/python/radio18.py")

    elif selected_program == "Program 13":
        os.system("c:/python/radio19.py")


    elif selected_program == "Program 14":
        os.system("c:/python/radio20.py")

    elif selected_program == "Program 15":
        os.system("c:/python/radio21.py")

    elif selected_program == "Program 16":
        os.system("c:/python/radio22.py")

    elif selected_program == "Program 17":
        os.system("c:/python/radio23.py")
        
    elif selected_program == "Program 18":
        os.system("c:/python/radio24.py")


    elif selected_program == "Program 19":
        os.system("c:/python/radio25.py")

    elif selected_program == "Program 20":
        os.system("c:/python/radio26.py")

    elif selected_program == "Program 21":
        os.system("c:/python/radio27.py")

    elif selected_program == "Program 22":
        os.system("c:/python/radio28.py")

    elif selected_program == "Program 23":
        os.system("c:/python/radio29.py")

    elif selected_program == "Program 24":
        os.system("c:/python/radio30.py")

        
# Create the main window
root = tk.Tk()
root.title("Program Selector")

# Create a Tkinter variable
var = tk.StringVar(value="Program 1")

# Create radio buttons
radio1 = tk.Radiobutton(root, text="quark        (RADIO11)                 ", variable=var, value="Program 1")
radio2 = tk.Radiobutton(root, text="cheese       (RADIO10)                ", variable=var, value="Program 2")
radio3 = tk.Radiobutton(root, text="mysticalley  (RADIO9)_____           ", variable=var, value="Program 3")
radio4 = tk.Radiobutton(root, text="aicasino     (RADIO8)           ", variable=var, value="Program 4")
radio5 = tk.Radiobutton(root, text="dandd        (RADIO6)       ", variable=var, value="Program 5")
radio6 = tk.Radiobutton(root, text="chuck        (RADIO12)       ", variable=var, value="Program 6")
radio7 = tk.Radiobutton(root, text="ninja        (RADIO13)       ", variable=var, value="Program 7")
radio8 = tk.Radiobutton(root, text="orange        (RADIO14)       ", variable=var, value="Program 8")
radio9 = tk.Radiobutton(root, text="repo        (RADIO15)       ", variable=var, value="Program 9")

radio10 = tk.Radiobutton(root,text="sushi        (RADIO16)       ", variable=var, value="Program 10")

radio11 = tk.Radiobutton(root,text="cake        (RADIO17)       ", variable=var, value="Program 11")

radio12 = tk.Radiobutton(root,text="cow        (RADIO18)       ", variable=var, value="Program 12")

radio13 = tk.Radiobutton(root,text="turtle        (RADIO19)       ", variable=var, value="Program 13")

radio14 = tk.Radiobutton(root,text="wraith        (RADIO20)       ", variable=var, value="Program 14")

radio15 = tk.Radiobutton(root,text="frog        (RADIO21)       ", variable=var, value="Program 15")

radio16 = tk.Radiobutton(root,text="engineer        (RADIO22)       ", variable=var, value="Program 16")

radio17 = tk.Radiobutton(root,text="icecream        (RADIO23)       ", variable=var, value="Program 17")

radio18 = tk.Radiobutton(root,text="pancake        (RADIO24)       ", variable=var, value="Program 18")

radio19 = tk.Radiobutton(root,text="captain        (RADIO25)       ", variable=var, value="Program 19")

radio20 = tk.Radiobutton(root,text="brother        (RADIO26)       ", variable=var, value="Program 20")

radio21 = tk.Radiobutton(root,text="chief        (RADIO27)       ", variable=var, value="Program 21")

radio22 = tk.Radiobutton(root,text="potato        (RADIO28)       ", variable=var, value="Program 22")

radio23 = tk.Radiobutton(root,text="bertha        (RADIO29)       ", variable=var, value="Program 23")

radio24 = tk.Radiobutton(root,text="ketchup        (RADIO30)       ", variable=var, value="Program 24")


# Pack the radio buttons
radio1.pack(anchor=tk.W)
radio2.pack(anchor=tk.W)
radio3.pack(anchor=tk.W)
radio4.pack(anchor=tk.W)
radio5.pack(anchor=tk.W)
radio6.pack(anchor=tk.W)
radio7.pack(anchor=tk.W)
radio8.pack(anchor=tk.W)
radio9.pack(anchor=tk.W)

radio10.pack(anchor=tk.W)

radio11.pack(anchor=tk.W)

radio12.pack(anchor=tk.W)

radio13.pack(anchor=tk.W)

radio14.pack(anchor=tk.W)

radio15.pack(anchor=tk.W)

radio16.pack(anchor=tk.W)

radio17.pack(anchor=tk.W)

radio18.pack(anchor=tk.W)

radio19.pack(anchor=tk.W)

radio20.pack(anchor=tk.W)

radio21.pack(anchor=tk.W)

radio22.pack(anchor=tk.W)

radio23.pack(anchor=tk.W)

radio24.pack(anchor=tk.W)

# Create a button to execute the selected program
execute_button = tk.Button(root, text="Execute", command=execute_program)
execute_button.pack()

# Run the main loop
root.mainloop()
