#!/usr/bin/env python3
"""
Grocery suggester with:
- very large built-in catalog (programmatic generation)
- interactive loop (repeat/quit)
- TTS enabled by default (uses system TTS tools; no pip)
- CSV and JSON export of final list
- interactive confirmation and ability to add items to the final list:
    * add custom items (name, price, category, brand, unit, dietary tags, quantity)
    * add items from the catalog by searching and selecting
- continual JSON append of runs
- interactive editing of the Final grocery list (add/remove)
- persistent accumulated list across runs until user types "clear"
- save the accumulated grocery list to a JSON file (--save-json)
- no external dependencies (standard library only)

Save as: grocery_suggester_continual_clearable_saved.py
Example:
  python grocery_suggester_continual_clearable_saved.py --base-size 1500 --max-items 20 --seed 42 --save-json grocery_list.json
"""

import csv
import json
import argparse
import random
import shutil
import subprocess
import platform
import os
import tempfile
import datetime
from collections import defaultdict, Counter
from typing import List, Tuple, Optional, Set

CatalogItem = Tuple[str, float, str, str, str, str]
# (name, price, category, brand, unit, dietary_tags)

# ---------------------------
# Catalog generation (programmatic large catalog)
# ---------------------------
GEN_BRANDS = ["Generic", "FarmFresh", "GreenLeaf", "PastaHouse", "BakeHouse", "OceanCatch",
              "Nutty", "BrewMaster", "Crunchy", "SweetCo", "CondimentCo", "Frosty",
              "DeliFresh", "PetMeals", "TropiFresh", "SpiceWorld", "TeaTime", "AquaPure",
              "BerryFarm", "CleanCo", "BabyCare", "BeefCo", "GrainGood", "PantryCo", "DairyFarm"]

GEN_CATEGORIES = ["Produce", "Dairy", "Dairy Alternatives", "Meat", "Seafood", "Pantry",
                  "Bakery", "Frozen", "Beverages", "Snacks", "Household", "Personal Care",
                  "Baby", "Pet", "International", "Deli", "Prepared", "Seasonal"]

# Expanded product types (kept from your larger catalog)
GEN_PRODUCT_TYPES = {
    "Produce": [
        "Apples", "Pears", "Peaches", "Plums", "Grapes", "Mango", "Pineapple", "Avocado",
        "Strawberries", "Blueberries", "Raspberries", "Blackberries", "Bananas", "Kiwifruit",
        "Oranges", "Clementines", "Lemons", "Limes", "Watermelon", "Cantaloupe", "Honeydew",
        "Tomatoes", "Cucumbers", "Bell Peppers", "Zucchini", "Eggplant", "Sweet Corn", "Garlic",
        "Ginger", "Green Onions", "Red Onions", "Yellow Onions", "Potatoes", "Sweet Potatoes",
        "Carrots", "Celery", "Broccoli", "Cauliflower", "Brussels Sprouts", "Spinach", "Kale",
        "Romaine Lettuce", "Mixed Greens", "Herb Pack"
    ],
    "Dairy": [
        "Whole Milk 1 gal", "Skim Milk 1 gal", "2% Milk 1 gal", "Greek Yogurt 32 oz",
        "Regular Yogurt 6 oz", "Cheddar Cheese 8 oz", "Mozzarella Shreds 8 oz", "Parmesan 8 oz",
        "Cream Cheese 8 oz", "Sour Cream 16 oz", "Butter 1 lb", "Whipping Cream 16 oz",
        "Cottage Cheese 16 oz", "Buttermilk 32 oz", "Half and Half 16 oz"
    ],
    "Dairy Alternatives": [
        "Almond Milk 64 oz", "Soy Milk 64 oz", "Oat Milk 64 oz", "Coconut Milk 64 oz",
        "Cashew Milk 64 oz", "Pea Protein Milk 64 oz", "Lactose Free Milk 64 oz"
    ],
    "Meat": [
        "Chicken Breast Boneless 1 lb", "Ground Beef 1 lb", "Sirloin Steak per lb",
        "Pork Chops per lb", "Bacon 12 oz", "Sausage Links 12 oz", "Turkey Breast per lb",
        "Ground Turkey 1 lb", "Beef Roast per lb", "Lamb Chops per lb"
    ],
    "Seafood": [
        "Salmon Fillet per lb", "Tilapia Fillet per lb", "Shrimp 1 lb", "Scallops 8 oz",
        "Tuna Steak per lb", "Cod Fillet per lb", "Canned Tuna 5 oz", "Smoked Salmon 4 oz"
    ],
    "Pantry": [
        "Pasta 16 oz", "Rice 2 lb", "Canned Beans 15 oz", "Olive Oil 16.9 oz", "Tomato Sauce 24 oz",
        "Canned Tomatoes 14 oz", "Peanut Butter 16 oz", "Jam 12 oz", "Honey 12 oz", "Flour 5 lb",
        "Sugar 4 lb", "Baking Powder 8 oz", "Baking Soda 8 oz", "Cereal 12 oz", "Oats 18 oz",
        "Granola 12 oz", "Broth Chicken 32 oz", "Broth Vegetable 32 oz", "Soy Sauce 10 oz",
        "Vinegar 16 oz", "Spaghetti 16 oz", "Macaroni 16 oz"
    ],
    "Bakery": [
        "Bread loaf", "Bagels 6 ct", "Croissant 2 ct", "English Muffins 6 ct", "Baguette",
        "Dinner Rolls 8 ct", "Muffins 4 ct", "Donuts 6 ct", "Sliced Bread White", "Sliced Bread Wheat"
    ],
    "Frozen": [
        "Frozen Pizza 12 inch", "Ice Cream 1.5 qt", "Frozen Fruit 16 oz", "Frozen Vegetables 12 oz",
        "Frozen Waffles 8 ct", "Frozen Burritos 4 ct", "Frozen Fries 20 oz", "Frozen Dumplings 12 oz"
    ],
    "Beverages": [
        "Orange Juice 64 oz", "Apple Juice 64 oz", "Coffee 12 oz", "Ground Coffee 12 oz",
        "Instant Coffee 8 oz", "Sparkling Water 12 pack", "Bottled Water 24 pack", "Soda 12 pack",
        "Energy Drink 16 oz", "Tea Bags 20 ct", "Iced Tea 64 oz", "Lemonade 64 oz"
    ],
    "Snacks": [
        "Potato Chips family", "Tortilla Chips 12 oz", "Pretzels 10 oz", "Granola Bars 6 ct",
        "Protein Bars 6 ct", "Trail Mix 10 oz", "Nuts 8 oz", "Popcorn 6 oz", "Crackers 8 oz",
        "Chocolate Bar 3.5 oz"
    ],
    "Household": [
        "Toilet Paper 12 rolls", "Paper Towels 6 rolls", "Dish Soap 24 oz", "Laundry Detergent 64 oz",
        "Trash Bags 30 ct", "Sponges 6 ct", "All Purpose Cleaner 32 oz", "Glass Cleaner 32 oz"
    ],
    "Personal Care": [
        "Toothpaste 6 oz", "Toothbrush", "Shampoo 12 oz", "Conditioner 12 oz", "Deodorant Stick",
        "Body Wash 16 oz", "Hand Soap 8 oz", "Razor Blades 4 ct", "Lotion 12 oz"
    ],
    "Baby": [
        "Diapers pack", "Baby Wipes 80 ct", "Baby Formula 12 oz", "Baby Food Jar 4 oz", "Baby Lotion 8 oz"
    ],
    "Pet": [
        "Dog Food 15 lb", "Cat Food 8 lb", "Dog Treats 8 oz", "Cat Treats 4 oz", "Cat Litter 20 lb"
    ],
    "International": [
        "Tortillas 12 ct", "Naan 2 ct", "Coconut Milk 13.5 oz", "Salsa 16 oz", "Curry Paste 8 oz",
        "Rice Noodles 8 oz", "Miso Paste 8 oz", "Kimchi 12 oz", "Soy Sauce 10 oz"
    ],
    "Deli": [
        "Sliced Turkey per lb", "Sliced Ham per lb", "Salami 8 oz", "Roast Beef per lb", "Deli Cheese 8 oz"
    ],
    "Prepared": [
        "Rotisserie Chicken", "Prepared Salad Bowl", "Sushi Tray", "Prepared Sandwich", "Prepared Soup 16 oz"
    ],
    "Seasonal": [
        "Pumpkin Pie 9 inch", "Hot Cocoa 10 oz", "Eggnog 1 qt", "Holiday Cookies 12 oz", "Candy Canes 8 oz"
    ]
}

PRICE_RANGES = {
    "Produce": (0.5, 6.0), "Dairy": (1.0, 12.0), "Dairy Alternatives": (2.0, 8.0),
    "Meat": (3.0, 25.0), "Seafood": (2.0, 30.0), "Pantry": (0.5, 20.0),
    "Bakery": (1.0, 8.0), "Frozen": (1.0, 15.0), "Beverages": (0.99, 20.0),
    "Snacks": (0.99, 12.0), "Household": (1.0, 40.0), "Personal Care": (1.0, 25.0),
    "Baby": (0.99, 40.0), "Pet": (2.0, 60.0), "International": (1.0, 15.0),
    "Deli": (3.0, 20.0), "Prepared": (3.0, 25.0), "Seasonal": (2.0, 25.0)
}

DESCRIPTORS = ["Classic", "Organic", "Value", "Premium", "Family", "Select", "Fresh", "Lite", "Original"]
UNITS = ["each", "per lb", "16 oz", "12 oz", "1 lb", "1 gal", "64 oz", "pack", "ct"]

# --- combinatorial extras to massively increase variety ---
from itertools import cycle

EXTRA_FLAVORS = ["Vanilla", "Chocolate", "Strawberry", "Garlic", "Herb", "Lemon", "Honey", "Maple", "Cinnamon", ""]
EXTRA_SIZES = ["8 oz", "12 oz", "16 oz", "1 lb", "2 lb", "4 lb", "500 ml", "1 L", "6 pack", "12 pack", "24 pack", ""]
EXTRA_FORMS = ["Ground", "Whole", "Sliced", "Shredded", "Chunks", "Frozen", "Canned", "Jarred", "Fresh", ""]
EXTRA_PREFIXES = ["Family", "Value", "Organic", "Premium", "Select", "Classic", "Lite", "Zero Sugar", "No Salt", ""]
GEN_BRANDS_EXT = GEN_BRANDS + ["SunValley", "HarvestGold", "UrbanFarm", "OceanBite", "Purely", "Heritage"]
DESCRIPTORS_EXT = DESCRIPTORS + ["Reserve", "Small Batch", "Artisan", "Glazed", "Smoked", "Spicy", "Limited"]

def _realistic_price(rng: random.Random, category: str) -> float:
    low, high = PRICE_RANGES.get(category, (1.0, 10.0))
    raw = rng.uniform(low, high)
    endings = [0.49, 0.99, 0.79, 0.29]
    ending = rng.choice(endings)
    return round(max(low, (int(raw) + ending)), 2)

def synthesize_item_combinatorial(category: str, idx: int, rng: random.Random) -> CatalogItem:
    # pick a base product name from GEN_PRODUCT_TYPES or fallback
    types = GEN_PRODUCT_TYPES.get(category, ["Item"])
    base = rng.choice(types)
    # choose flavor/size/form/descriptor/brand/prefix
    flavor = rng.choice(EXTRA_FLAVORS)
    size = rng.choice(EXTRA_SIZES)
    form = rng.choice(EXTRA_FORMS)
    prefix = rng.choice(EXTRA_PREFIXES)
    descriptor = rng.choice(DESCRIPTORS_EXT)
    brand = rng.choice(GEN_BRANDS_EXT)
    # build name parts, avoid duplicate spaces
    parts = [prefix, base, descriptor, flavor, form, size]
    name_core = " ".join([p for p in parts if p]).strip()
    # ensure uniqueness by appending index
    name = f"{name_core} #{idx}"
    price = _realistic_price(rng, category)
    # choose unit intelligently: if size contains digits use size as unit, else random unit
    unit = size if any(ch.isdigit() for ch in size) else (rng.choice(UNITS) if rng.random() > 0.4 else "")
    # dietary tags heuristics
    tags = []
    if category in ("Produce", "Pantry", "Bakery", "Frozen", "Beverages", "Snacks", "International"):
        tags.append("vegan")
    if category == "Dairy":
        tags.append("contains-dairy")
    if category == "Meat":
        tags.append("contains-meat")
    if category == "Seafood":
        tags.append("contains-fish")
    if rng.random() < 0.08:
        tags.append("gluten-free")
    if rng.random() < 0.03:
        tags.append("organic")
    dietary_tags = ";".join(tags) if tags else ""
    return (name, price, category, brand, unit, dietary_tags)

def generate_large_catalog(size: int = 1000, seed: Optional[int] = 42) -> List[CatalogItem]:
    rng = random.Random(seed)
    catalog: List[CatalogItem] = []
    curated = [
        ("Bananas", 0.69, "Produce", "Generic", "1 lb", "vegan;gluten-free"),
        ("Whole Milk 1 gal", 3.19, "Dairy", "FarmFresh", "1 gal", "contains-dairy"),
        ("Eggs Large Dozen", 2.99, "Dairy", "HappyHens", "dozen", "vegetarian"),
        ("Chicken Breast Boneless 1 lb", 5.49, "Meat", "PoultryFarm", "per lb", "contains-meat"),
        ("Pasta Spaghetti 16 oz", 1.19, "Pantry", "PastaHouse", "16 oz", "vegan"),
        ("Bread Whole Wheat loaf", 2.49, "Bakery", "BakeHouse", "loaf", "vegetarian"),
        ("Frozen Mixed Vegetables 12 oz", 1.99, "Frozen", "Frosty", "12 oz", "vegan;gluten-free"),
        ("Bottled Water 24 pack", 4.99, "Beverages", "AquaPure", "24 pack", "vegan;gluten-free"),
        ("Toilet Paper 12 rolls", 8.99, "Household", "PaperCo", "12 rolls", ""),
        ("Toothpaste 6 oz", 2.99, "Personal Care", "Smile", "6 oz", ""),
        ("Strawberries 1 lb", 3.99, "Produce", "BerryFarm", "1 lb", "vegan"),
        ("Blueberries 6 oz", 2.99, "Produce", "BerryFarm", "6 oz", "vegan"),
        ("Almond Milk 64 oz", 3.49, "Dairy Alternatives", "Nutty", "64 oz", "vegan"),
        ("Oat Milk 64 oz", 3.99, "Dairy Alternatives", "GrainGood", "64 oz", "vegan"),
        ("Ground Beef 1 lb", 4.99, "Meat", "BeefCo", "1 lb", "contains-meat"),
        ("Salmon Fillet per lb", 9.99, "Seafood", "OceanCatch", "per lb", "contains-fish"),
        ("Olive Oil 16.9 oz", 7.99, "Pantry", "CondimentCo", "16.9 oz", "vegan"),
        ("Peanut Butter 16 oz", 2.99, "Pantry", "Nutty", "16 oz", "vegan"),
        ("Cereal 12 oz", 3.49, "Pantry", "Crunchy", "12 oz", "vegetarian"),
        ("Bagels 6 ct", 1.79, "Bakery", "BakeHouse", "6 ct", "vegetarian"),
        ("Ice Cream 1.5 qt", 4.99, "Frozen", "Frosty", "1.5 qt", "vegetarian"),
        ("Coffee 12 oz", 7.79, "Beverages", "BrewMaster", "12 oz", ""),
        ("Potato Chips family", 3.99, "Snacks", "Crunchy", "family", ""),
        ("Laundry Detergent 64 oz", 12.99, "Household", "CleanCo", "64 oz", ""),
        ("Diapers pack", 26.99, "Baby", "BabyCare", "pack", ""),
        ("Dog Food 15 lb", 19.99, "Pet", "PetMeals", "15 lb", ""),
        ("Coconut Milk 13.5 oz", 1.99, "International", "TropiFresh", "13.5 oz", "vegan"),
        ("Pumpkin Pie 9 inch", 11.49, "Seasonal", "BakeHouse", "9 inch", ""),
        ("Hot Cocoa 10 oz", 6.49, "Seasonal", "Frosty", "10 oz", ""),
        ("Sliced Turkey per lb", 6.99, "Deli", "DeliFresh", "per lb", ""),
        ("Rotisserie Chicken", 8.99, "Prepared", "DeliFresh", "", ""),
        ("Tomato Sauce 24 oz", 1.49, "Pantry", "CondimentCo", "24 oz", "vegan"),
        ("Rice 2 lb", 2.49, "Pantry", "GrainGood", "2 lb", "vegan"),
        ("Granola Bars 6 ct", 3.49, "Snacks", "SweetCo", "6 ct", "vegetarian"),
        ("Salsa 16 oz", 2.49, "International", "SpiceWorld", "16 oz", "vegan"),
        ("Muffins 4 ct", 3.99, "Bakery", "BakeHouse", "4 ct", "vegetarian"),
        ("Toothbrush", 1.99, "Personal Care", "Smile", "", ""),
        ("Paper Towels 6 rolls", 9.49, "Household", "PaperCo", "6 rolls", ""),
        ("Canned Beans 15 oz", 0.99, "Pantry", "PantryCo", "15 oz", "vegan"),
        ("Sliced Ham per lb", 5.99, "Deli", "DeliFresh", "per lb", ""),
        ("Frozen Pizza 12 inch", 5.99, "Frozen", "Frosty", "12 inch", ""),
        ("Sparkling Water 12 pack", 6.99, "Beverages", "AquaPure", "12 pack", "vegan"),
        ("Chocolate Bar 3.5 oz", 1.49, "Snacks", "SweetCo", "3.5 oz", ""),
        ("Eggnog 1 qt", 4.99, "Seasonal", "DairyFarm", "1 qt", "contains-dairy"),
        ("Naan 2 ct", 2.49, "International", "PastaHouse", "2 ct", "vegetarian"),
        ("Kimchi 12 oz", 3.99, "International", "SpiceWorld", "12 oz", "vegan")
    ]
    catalog.extend(curated)
    idx = 1
    # shuffle categories to vary generation order
    cat_cycle = list(GEN_CATEGORIES)
    rng.shuffle(cat_cycle)
    cat_iter = cycle(cat_cycle)
    while len(catalog) < size:
        cat = next(cat_iter)
        item = synthesize_item_combinatorial(cat, idx, rng)
        catalog.append(item)
        idx += 1
    return catalog

# Default built-in catalog
DEFAULT_BASE_SIZE = 1000
BASE_CATALOG: List[CatalogItem] = generate_large_catalog(DEFAULT_BASE_SIZE, seed=42)

# ---------------------------
# Robust atomic write helper (centralized)
# ---------------------------
def _atomic_write(path: str, obj) -> Optional[Exception]:
    """
    Robust atomic JSON write:
      - ensures parent dir exists
      - converts common non-serializable types to JSON-safe forms
      - writes to a temp file, fsyncs, and atomically replaces the target
      - returns None on success or the exception instance on failure
    """
    try:
        dirpath = os.path.dirname(path) or "."
        os.makedirs(dirpath, exist_ok=True)
    except Exception as e:
        print(f"[_atomic_write] Could not ensure directory {dirpath}: {e}")
        return e

    def _make_json_safe(o):
        if isinstance(o, dict):
            return {k: _make_json_safe(v) for k, v in o.items()}
        if isinstance(o, (list, tuple, set)):
            return [_make_json_safe(v) for v in o]
        if isinstance(o, (str, int, float, bool)) or o is None:
            return o
        if isinstance(o, datetime.datetime):
            return o.isoformat()
        # fallback to string representation for unknown types
        return str(o)

    safe_obj = _make_json_safe(obj)

    try:
        fd, tmp_path = tempfile.mkstemp(prefix="tmp_grocery_write_", dir=dirpath, text=True)
    except Exception as e:
        print(f"[_atomic_write] mkstemp failed for dir {dirpath}: {e}")
        # fallback: try direct write
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(safe_obj, f, indent=2, ensure_ascii=False)
            return None
        except Exception as e2:
            print(f"[_atomic_write] direct write fallback also failed: {e2}")
            return e2

    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(safe_obj, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        try:
            os.replace(tmp_path, path)
        except Exception as e_replace:
            # fallback to shutil.move if replace fails (cross-filesystem or Windows locks)
            try:
                shutil.move(tmp_path, path)
            except Exception as e_move:
                print(f"[_atomic_write] os.replace failed: {e_replace}; shutil.move also failed: {e_move}")
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
                return e_move
        return None
    except TypeError as te:
        print(f"[_atomic_write] JSON serialization TypeError: {te}")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(json.dumps(safe_obj, indent=2, ensure_ascii=False))
            return None
        except Exception as e:
            print(f"[_atomic_write] fallback write failed: {e}")
            return e
    except Exception as e:
        print(f"[_atomic_write] Unexpected error while writing {path}: {e}")
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        return e

# ---------------------------
# CSV/JSON loader/exporter (use _atomic_write)
# ---------------------------
def parse_price(raw) -> float:
    if raw is None:
        return 0.0
    s = str(raw).strip()
    if not s:
        return 0.0
    s = s.replace("$", "").replace(",", "")
    try:
        return float(s)
    except Exception:
        return 0.0

def load_catalog_from_csv(path: str) -> List[CatalogItem]:
    items: List[CatalogItem] = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = (row.get("name") or "").strip() or "Unnamed Item"
            price = parse_price(row.get("price", "0"))
            category = (row.get("category") or "Pantry").strip() or "Pantry"
            brand = (row.get("brand") or "Generic").strip() or "Generic"
            unit = (row.get("unit") or "").strip()
            dietary_tags = (row.get("dietary_tags") or "").strip()
            items.append((name, price, category, brand, unit, dietary_tags))
    return items

def export_shopping_list_csv(path: str, selected: List[CatalogItem]):
    with open(path, "w", newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=["name", "price", "category", "brand", "unit", "dietary_tags", "quantity"])
        writer.writeheader()
        counts = Counter(selected)
        for (name, price, category, brand, unit, tags), qty in counts.items():
            writer.writerow({
                "name": name,
                "price": "{:.2f}".format(price),
                "category": category,
                "brand": brand,
                "unit": unit,
                "dietary_tags": tags,
                "quantity": qty
            })

def export_shopping_list_json(path: str, selected: List[CatalogItem]):
    counts = Counter(selected)
    items_out = []
    grand_total = 0.0
    for (name, price, category, brand, unit, tags), qty in counts.items():
        items_out.append({
            "name": name,
            "price": round(price, 2),
            "category": category,
            "brand": brand,
            "unit": unit,
            "dietary_tags": tags,
            "quantity": qty
        })
        grand_total += price * qty
    out = {
        "items": items_out,
        "total": round(grand_total, 2),
        "count": sum(item["quantity"] for item in items_out),
        "saved_at": datetime.datetime.utcnow().isoformat() + "Z"
    }
    err = _atomic_write(path, out)
    if err:
        raise err

# ---------------------------
# Save persistent accumulated list helper
# ---------------------------
def save_persistent_list_json(path: str, persistent_list: List[CatalogItem]):
    counts = Counter(persistent_list)
    items_out = []
    grand_total = 0.0
    for (name, price, category, brand, unit, tags), qty in counts.items():
        items_out.append({
            "name": name,
            "price": round(price, 2),
            "category": category,
            "brand": brand,
            "unit": unit,
            "dietary_tags": tags,
            "quantity": qty
        })
        grand_total += price * qty
    out = {
        "items": items_out,
        "total": round(grand_total, 2),
        "count": sum(item["quantity"] for item in items_out),
        "saved_at": datetime.datetime.utcnow().isoformat() + "Z"
    }
    err = _atomic_write(path, out)
    if err:
        raise err

# ---------------------------
# Continual JSON append helper
# ---------------------------
def append_to_continual_json(path: str, selected: List[CatalogItem], run_metadata: Optional[dict] = None):
    counts = Counter(selected)
    new_items = []
    new_total = 0.0
    for (name, price, category, brand, unit, tags), qty in counts.items():
        new_items.append({
            "name": name,
            "price": round(price, 2),
            "category": category,
            "brand": brand,
            "unit": unit,
            "dietary_tags": tags,
            "quantity": qty
        })
        new_total += price * qty

    existing = {"items": [], "total": 0.0, "count": 0, "runs": []}
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                existing = json.load(f)
                if not isinstance(existing, dict) or "items" not in existing:
                    existing = {"items": [], "total": 0.0, "count": 0, "runs": []}
                if "runs" not in existing or not isinstance(existing["runs"], list):
                    existing["runs"] = []
        except Exception:
            backup = path + ".bak"
            try:
                os.replace(path, backup)
                print(f"[append_to_continual_json] Backed up corrupted JSON to {backup}")
            except Exception:
                pass
            existing = {"items": [], "total": 0.0, "count": 0, "runs": []}

    run_entry = {
        "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
        "items": new_items,
        "total": round(new_total, 2),
        "count": sum(it["quantity"] for it in new_items),
        "meta": run_metadata or {}
    }
    existing_runs = existing.get("runs", [])
    existing_runs.append(run_entry)
    existing["runs"] = existing_runs

    existing_items = existing.get("items", []) + new_items

    agg = {}
    for it in existing_items:
        key = (it.get("name"), float(it.get("price", 0.0)), it.get("category"), it.get("brand"), it.get("unit"), it.get("dietary_tags", ""))
        qty = int(it.get("quantity", 1))
        if key in agg:
            agg[key]["quantity"] += qty
        else:
            agg[key] = {
                "name": key[0],
                "price": round(key[1], 2),
                "category": key[2],
                "brand": key[3],
                "unit": key[4],
                "dietary_tags": key[5],
                "quantity": qty
            }

    merged_items = list(agg.values())
    grand_total = sum(item["price"] * item["quantity"] for item in merged_items)
    out = {
        "items": merged_items,
        "total": round(grand_total, 2),
        "count": sum(item["quantity"] for item in merged_items),
        "runs": existing["runs"]
    }

    err = _atomic_write(path, out)
    if err:
        raise err

    print(f"Appended run at {run_entry['timestamp']} with {len(new_items)} distinct entries to continual JSON: {path}")

# ---------------------------
# Finalize and save run (uses _atomic_write)
# ---------------------------
def finalize_and_save_run(final_list: List[CatalogItem],
                          budget: float,
                          total_spent: float,
                          remaining: float,
                          grocery_path: str = "grocery_list.json",
                          continual_path: str = "continual_runs.json",
                          persistent_path: str = "persistent_list.json",
                          run_meta: Optional[dict] = None):
    run_meta = run_meta or {}
    timestamp = datetime.datetime.utcnow().isoformat() + "Z"

    counts = Counter(final_list)
    items_out = []
    for (name, price, category, brand, unit, tags), qty in counts.items():
        items_out.append({
            "name": name,
            "price": round(price, 2),
            "category": category,
            "brand": brand,
            "unit": unit,
            "dietary_tags": tags,
            "quantity": qty
        })

    final_run_obj = {
        "budget": round(budget, 2),
        "total_spent": round(total_spent, 2),
        "remaining": round(remaining, 2),
        "items": items_out,
        "saved_at": timestamp,
        "meta": run_meta
    }

    err = _atomic_write(grocery_path, final_run_obj)
    if err:
        print(f"[finalize_and_save_run] Failed to write final run file {grocery_path}: {err}")
    else:
        print(f"Saved final run to {grocery_path}")

    try:
        append_to_continual_json(continual_path, final_list, run_metadata={"saved_at": timestamp, **run_meta})
    except Exception as e:
        print(f"[finalize_and_save_run] append_to_continual_json raised: {e}")
        fallback = {
            "items": items_out,
            "total": round(total_spent, 2),
            "count": sum(it["quantity"] for it in items_out),
            "runs": [
                {
                    "timestamp": timestamp,
                    "items": items_out,
                    "total": round(total_spent, 2),
                    "count": sum(it["quantity"] for it in items_out),
                    "meta": run_meta
                }
            ]
        }
        _atomic_write(continual_path, fallback)
        print(f"Wrote fallback continual file to {continual_path}")

    try:
        save_persistent_list_json(persistent_path, final_list)
    except Exception as e:
        print(f"[finalize_and_save_run] save_persistent_list_json raised: {e}")
        persistent_fallback = {
            "items": items_out,
            "total": round(total_spent, 2),
            "count": sum(it["quantity"] for it in items_out),
            "saved_at": timestamp
        }
        _atomic_write(persistent_path, persistent_fallback)
        print(f"Wrote fallback persistent file to {persistent_path}")

    return {
        "grocery_path": os.path.abspath(grocery_path),
        "continual_path": os.path.abspath(continual_path),
        "persistent_path": os.path.abspath(persistent_path),
        "saved_at": timestamp
    }

# ---------------------------
# Text-to-Speech (TTS) helpers
# ---------------------------
def _speak_mac(text: str, voice: Optional[str], rate: Optional[int]):
    cmd = ["say"]
    if voice:
        cmd += ["-v", voice]
    if rate:
        cmd += ["-r", str(rate)]
    cmd.append(text)
    subprocess.run(cmd, check=False)

def _speak_windows(text: str, voice: Optional[str], rate: Optional[int]):
    safe_text = text.replace("'", "''")
    ps_lines = [
        "Add-Type -AssemblyName System.Speech;",
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
    ]
    if voice:
        ps_lines.append(f"$s.SelectVoice('{voice}');")
    if rate is not None:
        ps_lines.append(f"$s.Rate = {int(rate)};")
    ps_lines.append(f"$s.Speak('{safe_text}');")
    ps_cmd = " ".join(ps_lines)
    subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)

def _speak_linux(text: str, voice: Optional[str], rate: Optional[int]):
    if shutil.which("spd-say"):
        cmd = ["spd-say"]
        if voice:
            cmd += ["-o", voice]
        cmd.append(text)
        subprocess.run(cmd, check=False)
        return
    if shutil.which("espeak"):
        cmd = ["espeak"]
        if voice:
            cmd += ["-v", voice]
        if rate:
            cmd += ["-s", str(rate)]
        cmd += [text]
        subprocess.run(cmd, check=False)
        return
    print("[TTS] No system TTS engine found (spd-say or espeak). Skipping speech.")

def speak(text: str, voice: Optional[str] = None, rate: Optional[int] = None, enabled: bool = True):
    if not enabled or not text:
        return
    system = platform.system()
    try:
        if system == "Darwin":
            if shutil.which("say"):
                _speak_mac(text, voice, rate)
            else:
                print("[TTS] 'say' not found on macOS.")
        elif system == "Windows":
            _speak_windows(text, voice, rate)
        else:
            _speak_linux(text, voice, rate)
    except Exception as e:
        print(f"[TTS] Error while attempting to speak: {e}")

# ---------------------------
# Suggester core and interactive helpers (unchanged)
# ---------------------------
def catalog_to_pool(catalog: List[CatalogItem], prefer_categories: Optional[Set[str]] = None) -> List[CatalogItem]:
    pool: List[CatalogItem] = []
    prefer_lower = {c.lower() for c in prefer_categories} if prefer_categories else set()
    for entry in catalog:
        name, price, cat, brand, unit, tags = entry
        weight = 3 if cat.lower() in prefer_lower else 1
        pool.extend([entry] * weight)
    return pool

def suggest_groceries(catalog: List[CatalogItem], budget: float, max_items: Optional[int] = None,
                      seed: Optional[int] = None, prefer_categories: Optional[Set[str]] = None,
                      avoid_categories: Optional[Set[str]] = None) -> Tuple[List[CatalogItem], float, float]:
    rng = random.Random(seed)
    avoid_lower = {c.lower() for c in avoid_categories} if avoid_categories else set()
    filtered_catalog = [c for c in catalog if c[2].lower() not in avoid_lower]
    if not filtered_catalog:
        return [], 0.0, round(budget, 2)

    pool = catalog_to_pool(filtered_catalog, prefer_categories)
    remaining = round(budget, 2)
    selected: List[CatalogItem] = []
    attempts = 0
    while True:
        attempts += 1
        if max_items and len(selected) >= max_items:
            break
        affordable = [item for item in pool if item[1] <= remaining]
        if not affordable:
            break
        item = rng.choice(affordable)
        selected.append(item)
        remaining = round(remaining - item[1], 2)
        if attempts > 5000:
            break

    total_spent = round(budget - remaining, 2)
    return selected, total_spent, remaining

def format_shopping_list(selected: List[CatalogItem]) -> Tuple[str, float]:
    by_cat = defaultdict(list)
    for name, price, cat, brand, unit, tags in selected:
        by_cat[cat].append((name, price, brand, unit, tags))

    lines: List[str] = []
    grand_total = 0.0
    for cat in sorted(by_cat.keys()):
        lines.append(f"**{cat}**")
        cat_total = 0.0
        counts = Counter()
        for name, price, brand, unit, tags in by_cat[cat]:
            counts[(name, price, brand, unit, tags)] += 1
            cat_total += price
        for (name, price, brand, unit, tags), qty in counts.items():
            unit_text = f" ({unit})" if unit else ""
            brand_text = f" [{brand}]" if brand else ""
            tags_text = f" <{tags}>" if tags else ""
            lines.append(f"- {name}{unit_text}{brand_text} x{qty} — ${price:.2f}{tags_text}")
        lines.append(f"Category total: ${cat_total:.2f}")
        lines.append("")
        grand_total += cat_total

    return "\n".join(lines), round(grand_total, 2)

# ---------------------------
# Interactive add-to-list helpers
# ---------------------------
def prompt_float(prompt_text: str, default: Optional[float] = None) -> float:
    while True:
        raw = input(prompt_text).strip()
        if raw == "" and default is not None:
            return default
        try:
            val = float(raw)
            if val < 0:
                print("Please enter a non-negative number.")
                continue
            return round(val, 2)
        except ValueError:
            print("Enter a number like 3.49")

def prompt_int(prompt_text: str, default: Optional[int] = 1) -> int:
    while True:
        raw = input(prompt_text).strip()
        if raw == "" and default is not None:
            return default
        try:
            val = int(raw)
            if val <= 0:
                print("Enter a positive integer.")
                continue
            return val
        except ValueError:
            print("Enter an integer like 2")

def add_custom_item_interactive() -> List[CatalogItem]:
    """
    Prompt the user to add one or more custom items.
    Returns a list of CatalogItem entries (repeated according to quantity).
    """
    added: List[CatalogItem] = []
    print("\nAdd custom items. Leave name blank to stop adding.")
    while True:
        name = input("Item name (blank to finish): ").strip()
        if not name:
            break
        price = prompt_float("Price (e.g., 2.99): ")
        category = input("Category (e.g., Pantry) [default: Pantry]: ").strip() or "Pantry"
        brand = input("Brand [default: Generic]: ").strip() or "Generic"
        unit = input("Unit (e.g., 16 oz, each) [optional]: ").strip()
        tags = input("Dietary tags (semicolon-separated) [optional]: ").strip()
        qty = prompt_int("Quantity (integer) [default 1]: ", default=1)
        for _ in range(qty):
            added.append((name, price, category, brand, unit, tags))
        print(f"Added {qty} x {name} at ${price:.2f}")
    return added

def search_catalog(catalog: List[CatalogItem], term: str, max_results: int = 10) -> List[Tuple[int, CatalogItem]]:
    term_lower = term.lower()
    matches = []
    for idx, item in enumerate(catalog):
        name, price, cat, brand, unit, tags = item
        if term_lower in name.lower() or term_lower in cat.lower() or term_lower in brand.lower():
            matches.append((idx, item))
        if len(matches) >= max_results:
            break
    return matches

def add_from_catalog_interactive(catalog: List[CatalogItem]) -> List[CatalogItem]:
    """
    Allow the user to search the catalog and add selected items (with quantities).
    Returns a list of CatalogItem entries (repeated according to quantity).
    """
    added: List[CatalogItem] = []
    print("\nAdd items from catalog. Enter a search term (blank to finish).")
    while True:
        term = input("Search term (name/category/brand) (blank to finish): ").strip()
        if not term:
            break
        matches = search_catalog(catalog, term, max_results=20)
        if not matches:
            print("No matches found. Try a different term.")
            continue
        print("\nMatches:")
        for display_idx, (catalog_idx, (name, price, cat, brand, unit, tags)) in enumerate(matches, start=1):
            unit_text = f" ({unit})" if unit else ""
            brand_text = f" [{brand}]" if brand else ""
            tags_text = f" <{tags}>" if tags else ""
            print(f"{display_idx}. {name}{unit_text}{brand_text} — ${price:.2f}{tags_text} [{cat}] (catalog idx {catalog_idx})")
        sel = input("Enter comma-separated match numbers to add (e.g., 1,3) or 'none': ").strip().lower()
        if sel in ("none", ""):
            continue
        try:
            chosen = [int(x.strip()) for x in sel.split(",") if x.strip()]
            for cnum in chosen:
                if 1 <= cnum <= len(matches):
                    catalog_idx, item = matches[cnum - 1]
                    qty = prompt_int(f"Quantity for '{item[0]}' [default 1]: ", default=1)
                    for _ in range(qty):
                        added.append(item)
                    print(f"Added {qty} x {item[0]}")
                else:
                    print(f"Ignoring invalid selection {cnum}")
        except Exception:
            print("Couldn't parse selection. Try again.")
    return added

def add_items_menu(final_list: List[CatalogItem], catalog: List[CatalogItem]) -> List[CatalogItem]:
    """
    Present a small menu to let the user add custom items or add from catalog.
    Returns the updated final_list (with new items appended).
    """
    while True:
        print("\nAdd items menu:")
        print("  1) Add custom items")
        print("  2) Search catalog and add items")
        print("  3) Done adding")
        choice = input("Choose 1, 2, or 3: ").strip()
        if choice == "1":
            added = add_custom_item_interactive()
            final_list.extend(added)
        elif choice == "2":
            added = add_from_catalog_interactive(catalog)
            final_list.extend(added)
        elif choice == "3":
            break
        else:
            print("Enter 1, 2, or 3.")
    return final_list

# ---------------------------
# Interactive editing of final list (new)
# ---------------------------
def print_final_list(final_list: List[CatalogItem]):
    if not final_list:
        print("(empty)")
        return
    for i, (name, price, cat, brand, unit, tags) in enumerate(final_list, start=1):
        unit_text = f" ({unit})" if unit else ""
        brand_text = f" [{brand}]" if brand else ""
        tags_text = f" <{tags}>" if tags else ""
        print(f"{i}. {name}{unit_text}{brand_text} — ${price:.2f}{tags_text} [{cat}]")

def edit_final_list_interactive(final_list: List[CatalogItem], catalog: List[CatalogItem]) -> List[CatalogItem]:
    """
    Allow the user to edit the final list: add items (via add_items_menu), remove items by index,
    clear the list, or finish editing. Returns the updated final_list.
    """
    while True:
        print("\nCurrent Final grocery list:")
        print_final_list(final_list)
        total = round(sum(item[1] for item in final_list), 2)
        print(f"Current total: ${total:.2f}")
        print("\nEdit menu:")
        print("  1) Add items")
        print("  2) Remove items by index")
        print("  3) Remove items by name search")
        print("  4) Clear entire list")
        print("  5) Done editing")
        choice = input("Choose 1-5: ").strip()
        if choice == "1":
            final_list = add_items_menu(final_list, catalog)
        elif choice == "2":
            if not final_list:
                print("List is empty.")
                continue
            idxs = input("Enter comma-separated indices to remove (e.g., 2,5) or 'none': ").strip().lower()
            if idxs in ("none", ""):
                continue
            try:
                indices = sorted({int(x.strip()) for x in idxs.split(",") if x.strip()}, reverse=True)
                removed = 0
                for idx in indices:
                    if 1 <= idx <= len(final_list):
                        final_list.pop(idx - 1)
                        removed += 1
                    else:
                        print(f"Ignoring invalid index {idx}")
                print(f"Removed {removed} items.")
            except Exception:
                print("Couldn't parse indices. Try again.")
        elif choice == "3":
            term = input("Enter a search term to remove matching items by name (blank to cancel): ").strip().lower()
            if not term:
                continue
            to_keep = []
            removed = 0
            for item in final_list:
                if term in item[0].lower():
                    removed += 1
                else:
                    to_keep.append(item)
            final_list = to_keep
            print(f"Removed {removed} items matching '{term}'.")
        elif choice == "4":
            confirm = input("Are you sure you want to clear the entire list? (y/n): ").strip().lower()
            if confirm in ("y", "yes"):
                final_list = []
                print("List cleared.")
            else:
                print("Clear cancelled.")
        elif choice == "5":
            break
        else:
            print("Enter a number from 1 to 5.")
    return final_list

# ---------------------------
# Interactive helpers (existing)
# ---------------------------
def prompt_budget_if_missing(budget_arg: Optional[float]) -> float:
    if budget_arg is not None:
        return float(budget_arg)
    while True:
        raw = input("Enter your current balance (e.g., 25.00): ").strip()
        try:
            b = float(raw)
            if b < 0:
                print("Please enter a non-negative number.")
                continue
            return round(b, 2)
        except ValueError:
            print("Couldn't parse that. Enter a number like 25.00.")

def confirm_items_interactively(suggested: List[CatalogItem]) -> List[CatalogItem]:
    if not suggested:
        print("No suggested items to confirm.")
        return []

    print("\nSuggested items:")
    for i, (name, price, cat, brand, unit, tags) in enumerate(suggested, start=1):
        unit_text = f" ({unit})" if unit else ""
        brand_text = f" [{brand}]" if brand else ""
        tags_text = f" <{tags}>" if tags else ""
        print(f"{i}. {name}{unit_text}{brand_text} — ${price:.2f}{tags_text} [{cat}]")

    while True:
        ans = input("\nAccept all suggested items? (y/n): ").strip().lower()
        if ans in ("y", "yes"):
            return list(suggested)
        if ans in ("n", "no"):
            break
        print("Please answer 'y' or 'n'.")

    while True:
        mode = input("Choose mode: (a) add individually, (r) remove some, (c) cancel: ").strip().lower()
        if mode in ("c", "cancel"):
            return []
        if mode == "a":
            added = []
            for i, item in enumerate(suggested, start=1):
                yn = input(f"Add item {i} '{item[0]}'? (y/n): ").strip().lower()
                if yn in ("y", "yes"):
                    added.append(item)
            return added
        if mode == "r":
            print("Enter comma-separated indices to remove (e.g., 2,5) or 'none':")
            idxs = input().strip().lower()
            if idxs in ("none", ""):
                return list(suggested)
            try:
                remove_set = {int(x.strip()) for x in idxs.split(",") if x.strip()}
                kept = [item for i, item in enumerate(suggested, start=1) if i not in remove_set]
                return kept
            except Exception:
                print("Couldn't parse indices. Try again.")
        print("Enter 'a', 'r', or 'c'.")

# ---------------------------
# Main interactive loop and CLI
# ---------------------------
def load_persistent_list(path: str) -> List[CatalogItem]:
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            items = []
            for it in data.get("items", []):
                name = it.get("name", "Unnamed")
                price = float(it.get("price", 0.0))
                category = it.get("category", "Pantry")
                brand = it.get("brand", "Generic")
                unit = it.get("unit", "")
                tags = it.get("dietary_tags", "")
                qty = int(it.get("quantity", 1))
                for _ in range(qty):
                    items.append((name, price, category, brand, unit, tags))
            return items
    except Exception:
        return []

def main(argv=None):
    parser = argparse.ArgumentParser(description="Grocery suggester with large built-in catalog and persistent saves.")
    parser.add_argument("--base-size", type=int, default=DEFAULT_BASE_SIZE, help="Number of items to generate in the built-in catalog.")
    parser.add_argument("--max-items", type=int, default=20, help="Maximum number of suggested items per run.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducible suggestions.")
    parser.add_argument("--save-json", type=str, default="grocery_list.json", help="Path to save the final run JSON.")
    parser.add_argument("--save-continual", type=str, default="continual_runs.json", help="Path to append continual runs JSON.")
    parser.add_argument("--save-persistent", type=str, default="persistent_list.json", help="Path to save the persistent accumulated list.")
    parser.add_argument("--no-tts", action="store_true", help="Disable text-to-speech output.")
    parser.add_argument("--voice", type=str, default=None, help="TTS voice name (system dependent).")
    parser.add_argument("--rate", type=int, default=None, help="TTS rate (system dependent).")
    parser.add_argument("--catalog-csv", type=str, default=None, help="Optional CSV file to load additional catalog items from.")
    args = parser.parse_args(argv)

    # Build catalog
    print(f"[INFO] Generating catalog with base size {args.base_size} (seed {args.seed})...")
    catalog = generate_large_catalog(size=args.base_size, seed=args.seed)
    if args.catalog_csv:
        try:
            extra = load_catalog_from_csv(args.catalog_csv)
            catalog.extend(extra)
            print(f"[INFO] Loaded {len(extra)} items from CSV {args.catalog_csv}")
        except Exception as e:
            print(f"[WARN] Failed to load catalog CSV {args.catalog_csv}: {e}")

    # Load persistent accumulated list
    persistent_list = load_persistent_list(args.save_persistent)
    if persistent_list:
        print(f"[INFO] Loaded {len(persistent_list)} items from persistent list {args.save_persistent}")

    tts_enabled = not args.no_tts

    # Interactive loop
    while True:
        print("\n--- Grocery Suggester Run ---")
        budget = prompt_budget_if_missing(None)
        prefer = input("Prefer categories (comma-separated) [optional]: ").strip()
        prefer_set = {c.strip() for c in prefer.split(",") if c.strip()} if prefer else None
        avoid = input("Avoid categories (comma-separated) [optional]: ").strip()
        avoid_set = {c.strip() for c in avoid.split(",") if c.strip()} if avoid else None

        suggested, total_spent, remaining = suggest_groceries(
            catalog=catalog,
            budget=budget,
            max_items=args.max_items,
            seed=args.seed,
            prefer_categories=prefer_set,
            avoid_categories=avoid_set
        )

        if not suggested:
            print("No suggestions could be generated within your budget and constraints.")
            speak("No suggestions could be generated within your budget and constraints.", args.voice, args.rate, enabled=tts_enabled)
            cmd = input("Type 'retry' to try again, 'quit' to exit: ").strip().lower()
            if cmd in ("quit", "q", "exit"):
                break
            else:
                continue

        # Show summary and TTS
        summary_text, grand_total = format_shopping_list(suggested)
        print("\nSuggested shopping list:")
        print(summary_text)
        print(f"Total suggested cost: ${grand_total:.2f} (spent ${total_spent:.2f}, remaining ${remaining:.2f})")
        speak(f"I have a suggested list totaling {grand_total:.2f} dollars. Accept suggestions?", args.voice, args.rate, enabled=tts_enabled)

        # Confirm and allow edits
        accepted = confirm_items_interactively(suggested)
        final_list = accepted[:]
        if final_list:
            print("\nAccepted items added to final list.")
        else:
            print("\nNo suggested items accepted.")

        # Allow user to add custom or catalog items
        while True:
            add_more = input("Would you like to add or edit items? (y to edit / n to continue): ").strip().lower()
            if add_more in ("y", "yes"):
                final_list = edit_final_list_interactive(final_list, catalog)
                break
            if add_more in ("n", "no", ""):
                break
            print("Enter 'y' or 'n'.")

        # Merge into persistent list (accumulated across runs)
        persistent_list.extend(final_list)

        # Speak the final list (full formatted list) and a short summary
        if final_list:
            # Full formatted list (may be long)
            final_summary_text, final_total = format_shopping_list(final_list)
            # Speak a short summary first
            count = len(final_list)
            speak(f"You have {count} items totaling {final_total:.2f} dollars.", args.voice, args.rate, enabled=tts_enabled)
            # Then speak the detailed list (may be multi-line; some TTS engines handle newlines)
            speak(final_summary_text, args.voice, args.rate, enabled=tts_enabled)
        else:
            speak("Your final list is empty.", args.voice, args.rate, enabled=tts_enabled)

        # Finalize and save run
        try:
            saved_info = finalize_and_save_run(
                final_list=final_list,
                budget=budget,
                total_spent=total_spent,
                remaining=remaining,
                grocery_path=args.save_json,
                continual_path=args.save_continual,
                persistent_path=args.save_persistent,
                run_meta={"seed": args.seed, "prefer": list(prefer_set) if prefer_set else [], "avoid": list(avoid_set) if avoid_set else []}
            )
            print(f"[INFO] Saved run files: {saved_info}")
        except Exception as e:
            print(f"[ERROR] Failed to finalize and save run: {e}")

        # Save persistent list explicitly (atomic)
        try:
            save_persistent_list_json(args.save_persistent, persistent_list)
        except Exception as e:
            print(f"[WARN] Could not save persistent list: {e}")

        # Post-run options
        while True:
            cmd = input("\nType 'repeat' to run again, 'clear' to clear persistent list, 'show' to view persistent list, or 'quit' to exit: ").strip().lower()
            if cmd in ("repeat", "r", ""):
                break
            if cmd == "clear":
                confirm = input("Are you sure you want to clear the persistent accumulated list? (y/n): ").strip().lower()
                if confirm in ("y", "yes"):
                    persistent_list = []
                    try:
                        save_persistent_list_json(args.save_persistent, persistent_list)
                        print("[INFO] Persistent list cleared and saved.")
                    except Exception as e:
                        print(f"[WARN] Could not save cleared persistent list: {e}")
                else:
                    print("Clear cancelled.")
                continue
            if cmd == "show":
                print("\nPersistent accumulated list:")
                print_final_list(persistent_list)
                continue
            if cmd in ("quit", "q", "exit"):
                print("Goodbye.")
                return
            print("Unknown command. Enter 'repeat', 'clear', 'show', or 'quit'.")

if __name__ == "__main__":
    main()
