import platform
import shutil
import subprocess

def speak(text):
    """Cross-platform TTS using only the standard library and common system utilities."""
    if not text:
        return

    system = platform.system()

    # macOS: `say`
    if system == "Darwin" and shutil.which("say"):
        try:
            subprocess.run(["say", text], check=False)
            return
        except Exception:
            pass

    # Windows: PowerShell System.Speech
    if system == "Windows":
        safe = text.replace('"', '\\"')
        ps_cmd = (
            'Add-Type -AssemblyName System.Speech;'
            f'(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak("{safe}")'
        )
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
            return
        except Exception:
            pass

    # Linux/Unix: espeak then spd-say
    if shutil.which("espeak"):
        try:
            subprocess.run(["espeak", text], check=False)
            return
        except Exception:
            pass

    if shutil.which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=False)
            return
        except Exception:
            pass

    print("[TTS unavailable on this system]")

def calculate_tip(cost, percent):
    tip = cost * percent / 100.0
    total = cost + tip
    return tip, total

def prompt_float_or_quit(prompt_text):
    while True:
        raw = input(prompt_text).strip().lower()
        if raw in {"q", "quit"}:
            return None
        try:
            value = float(raw)
            if value < 0:
                print("Please enter a non-negative number.")
                continue
            return value
        except ValueError:
            print("Invalid number. Enter a number or 'q' to quit.")

def main():
    print("Tip Calculator — type 'q' at any prompt to quit\n")
    while True:
        cost = prompt_float_or_quit("Enter the bill amount: $")
        if cost is None:
            speak("Goodbye")
            print("Goodbye.")
            break

        percent = prompt_float_or_quit("Enter tip percentage (e.g., 15 for 15%): ")
        if percent is None:
            speak("Goodbye")
            print("Goodbye.")
            break

        tip, total = calculate_tip(cost, percent)
        print(f"\nBill: ${cost:.2f}")
        print(f"Tip ({percent:.2f}%): ${tip:.2f}")
        print(f"Total: ${total:.2f}\n")

        # Speak bill, tip, and total
        speak(f"The bill is {cost:.2f} dollars. The tip is {tip:.2f} dollars. The total is {total:.2f} dollars.")

        again = input("Calculate another tip? (y/n): ").strip().lower()
        if again not in {"y", "yes"}:
            speak("Done. Have a great day.")
            print("Done. Have a great day!")
            break

if __name__ == "__main__":
    main()
