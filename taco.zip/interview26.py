#!/usr/bin/env python3
"""
Interviewer that speaks prompts and assistant replies.
Modified behavior:
- Asks follow-ups immediately after each user input.
- If the user presses Enter on a blank line, the interviewer will SKIP that question
  (leave it unanswered) and move on to the next question in the QUESTIONS list.
- The interviewer iterates through QUESTIONS once (in order, starting at start_prompt_id)
  and then exits. This allows unanswered questions to remain unanswered.
- /tts on|off still works inline. /quit or /exit ends the session and saves progress.
- REPLY_TEMPLATES restored (full set).
Save as interviewer_build_on_responses_immediate_skip_blank_with_replies_full.py and run with Python 3.
"""

import json
import datetime
import sys
import platform
import subprocess
import shutil
import tempfile
import os
import argparse
import random
import time
from collections import deque
from typing import List, Dict, Optional

# --- CLI and TTS defaults ---
TTS_ENABLED = True   # ON by default
TTS_RATE = None      # platform-dependent integer if provided

def parse_cli_args():
    p = argparse.ArgumentParser(description="Run the interactive interviewer.")
    p.add_argument("--no-tts", action="store_true", help="Start with TTS disabled")
    p.add_argument("--tts-rate", type=int, default=None, help="Optional TTS rate (platform-dependent)")
    p.add_argument("--autosave-file", type=str, default="interview_latest.json", help="Autosave filename (overwritten each answer)")
    return p.parse_args()

# --- Questions (full set restored) ---
QUESTIONS = [
  {"id":"name","text":"What's your full name?","type":"text"},
  {"id":"preferred_name","text":"What name should I call you? (optional)","type":"text","optional":True},
  {"id":"pronouns","text":"What are your pronouns? (e.g., they/them, she/her, he/him)","type":"text","optional":True},
  {"id":"age","text":"How old are you?","type":"int","min":0,"max":120},
  {"id":"location","text":"What city and state do you live in?","type":"text"},
  {"id":"timezone","text":"What's your timezone or preferred time reference?","type":"text","optional":True},
  {"id":"email","text":"What's your email address? (optional)","type":"text","optional":True},
  {"id":"phone","text":"What's your phone number? (optional)","type":"text","optional":True},
  {"id":"occupation","text":"What's your current occupation or role?","type":"text","optional":True},
  {"id":"industry","text":"Which industry do you work in?","type":"choice","choices":["technology","education","healthcare","finance","arts","manufacturing","other"]},
  {"id":"experience_years","text":"How many years of professional experience do you have?","type":"int","min":0,"max":80},
  {"id":"skills","text":"List up to five key skills you have (comma separated).","type":"text","optional":True},
  {"id":"education_level","text":"Highest level of education completed","type":"choice","choices":["high school","associate","bachelor","master","doctorate","other"]},
  {"id":"languages","text":"Which languages do you speak fluently? (comma separated)","type":"text","optional":True},
  {"id":"hobbies","text":"What are your top hobbies or pastimes? (comma separated)","type":"text","optional":True},
  {"id":"music_genre","text":"What's your favorite music genre?","type":"choice","choices":["rock","pop","hip-hop","country","electronic","jazz","classical","other"]},
  {"id":"favorite_song","text":"Name a song you love to play loud","type":"text","optional":True},
  {"id":"plays_instrument","text":"Do you play a musical instrument? (yes/no)","type":"yesno"},
  {"id":"instrument","text":"Which instrument do you play?","type":"text","conditional":{"question_id":"plays_instrument","value":"yes"}},
  {"id":"car_owner","text":"Do you own a car? (yes/no)","type":"yesno"},
  {"id":"car_make_model","text":"What make and model is your car?","type":"text","conditional":{"question_id":"car_owner","value":"yes"}},
  {"id":"interested_in_hydraulics","text":"Would you consider adding hydraulic suspension to a show car? (yes/no)","type":"yesno"},
  {"id":"hydraulics_highway_use","text":"Would you ever use hydraulics on the highway? (yes/no)","type":"yesno","conditional":{"question_id":"interested_in_hydraulics","value":"yes"}},
  {"id":"car_mechanic_experience","text":"Do you have hands-on experience with car mechanics? (yes/no)","type":"yesno"},
  {"id":"mechanic_years","text":"How many years of mechanical experience do you have?","type":"int","min":0,"max":60,"conditional":{"question_id":"car_mechanic_experience","value":"yes"}},
  {"id":"project_interest","text":"Are you working on any vehicle or creative projects right now? (yes/no)","type":"yesno"},
  {"id":"project_description","text":"Briefly describe your current project","type":"text","conditional":{"question_id":"project_interest","value":"yes"}},
  {"id":"project_deadline","text":"Do you have a deadline for that project? (date or 'none')","type":"text","optional":True,"conditional":{"question_id":"project_interest","value":"yes"}},
  {"id":"availability_weekdays","text":"Which weekdays are you usually available? (e.g., Mon,Tue)","type":"text","optional":True},
  {"id":"availability_time","text":"What time of day works best for you? (morning/afternoon/evening)","type":"choice","choices":["morning","afternoon","evening","night","flexible"]},
  {"id":"remote_work","text":"Do you prefer remote or in-person collaboration?","type":"choice","choices":["remote","in-person","hybrid"]},
  {"id":"work_tools","text":"Which tools do you use regularly? (e.g., Git, Photoshop, Excel)","type":"text","optional":True},
  {"id":"github","text":"Do you have a GitHub or portfolio URL? (optional)","type":"text","optional":True},
  {"id":"social_media","text":"Which social platforms do you use? (comma separated)","type":"text","optional":True},
  {"id":"favorite_tech","text":"What's a tech gadget you can't live without?","type":"text","optional":True},
  {"id":"learning_goals","text":"What skills do you want to learn in the next year? (comma separated)","type":"text","optional":True},
  {"id":"mentorship_interest","text":"Are you interested in mentoring or being mentored? (mentor/mentee/none)","type":"choice","choices":["mentor","mentee","none"]},
  {"id":"volunteer","text":"Do you volunteer or support any causes? (yes/no)","type":"yesno"},
  {"id":"volunteer_details","text":"Which causes or organizations do you support?","type":"text","optional":True,"conditional":{"question_id":"volunteer","value":"yes"}},
  {"id":"travel_frequency","text":"How often do you travel for leisure?","type":"choice","choices":["never","rarely","a few times a year","monthly","weekly"]},
  {"id":"favorite_destination","text":"What's your favorite travel destination?","type":"text","optional":True},
  {"id":"pets","text":"Do you have pets? (yes/no)","type":"yesno"},
  {"id":"pet_details","text":"What kind of pet(s) do you have?","type":"text","optional":True,"conditional":{"question_id":"pets","value":"yes"}},
  {"id":"fitness","text":"How often do you exercise per week? (times)","type":"int","min":0,"max":21},
  {"id":"dietary_restrictions","text":"Any dietary restrictions? (optional)","type":"text","optional":True},
  {"id":"smoke","text":"Do you smoke or vape? (yes/no)","type":"yesno"},
  {"id":"alcohol","text":"Do you drink alcohol socially? (yes/no)","type":"yesno"},
  {"id":"sleep_hours","text":"How many hours of sleep do you usually get per night?","type":"int","min":0,"max":24},
  {"id":"stress_level","text":"On a scale of 1-10, how stressed do you feel on average?","type":"int","min":1,"max":10},
  {"id":"creative_medium","text":"Which creative medium do you prefer? (writing, music, visual art, film, other)","type":"choice","choices":["writing","music","visual art","film","other"]},
  {"id":"favorite_artist","text":"Name an artist or creator you admire","type":"text","optional":True},
  {"id":"reading_habit","text":"How many books do you read per year on average?","type":"int","min":0,"max":200},
  {"id":"podcast","text":"Do you listen to podcasts? If so, name a favorite (optional)","type":"text","optional":True},
  {"id":"movie_genre","text":"Favorite movie genre?","type":"choice","choices":["action","comedy","drama","sci-fi","horror","documentary","other"]},
  {"id":"favorite_movie","text":"Name a favorite movie (optional)","type":"text","optional":True},
  {"id":"gaming","text":"Do you play video games? (yes/no)","type":"yesno"},
  {"id":"gaming_platform","text":"Which gaming platform do you use? (PC/Console/Mobile)","type":"choice","choices":["PC","Console","Mobile","None"],"conditional":{"question_id":"gaming","value":"yes"}},
  {"id":"budget_monthly","text":"Roughly, what's your monthly personal budget for hobbies? (USD)","type":"int","min":0,"max":100000,"optional":True},
  {"id":"big_goal","text":"What's one big goal you want to achieve in the next 5 years?","type":"text","optional":True},
  {"id":"barriers","text":"What's the biggest barrier to that goal?","type":"text","optional":True},
  {"id":"support_needed","text":"What kind of support would help you most right now?","type":"choice","choices":["advice","accountability","funding","networking","skills training","other"]},
  {"id":"final_comments","text":"Any final comments or things you'd like me to remember?","type":"text","optional":True},

  # Many non-job-interview questions (lifestyle, reflective, fun)
  {"id":"favorite_food","text":"What's your favorite food or dish?","type":"text","optional":True},
  {"id":"comfort_food","text":"What food do you turn to when you need comfort?","type":"text","optional":True},
  {"id":"guilty_pleasure","text":"Do you have a guilty pleasure (song, show, snack)?","type":"text","optional":True},
  {"id":"ideal_weekend","text":"Describe your ideal weekend.","type":"text","optional":True},
  {"id":"perfect_vacation","text":"What's your perfect vacation like? (relaxing/adventurous/cultural)","type":"choice","choices":["relaxing","adventurous","cultural","mixed"],"optional":True},
  {"id":"bucket_list_item","text":"Name one item on your bucket list.","type":"text","optional":True},
  {"id":"favorite_childhood_memory","text":"What's a favorite memory from childhood?","type":"text","optional":True},
  {"id":"favorite_game_childhood","text":"What game did you love playing as a kid?","type":"text","optional":True},
  {"id":"favorite_season","text":"Which season do you prefer and why?","type":"text","optional":True},
  {"id":"morning_routine","text":"Do you have a morning routine? Briefly describe it.","type":"text","optional":True},
  {"id":"night_routine","text":"What's your evening or night routine like?","type":"text","optional":True},
  {"id":"sleep_chronotype","text":"Are you a morning person, night owl, or somewhere in between?","type":"choice","choices":["morning","night","in-between"],"optional":True},
  {"id":"favorite_smell","text":"What's a smell that instantly makes you happy?","type":"text","optional":True},
  {"id":"favorite_sound","text":"What's a sound you love (ocean, rain, vinyl crackle)?","type":"text","optional":True},
  {"id":"favorite_color","text":"What's your favorite color right now?","type":"text","optional":True},
  {"id":"favorite_place_local","text":"Name a local spot you love (park, cafe, trail).","type":"text","optional":True},
  {"id":"ideal_home_feature","text":"What's one feature your ideal home must have?","type":"text","optional":True},
  {"id":"pet_peeve","text":"What's a small thing that annoys you more than it should?","type":"text","optional":True},
  {"id":"best_advice_received","text":"What's the best piece of advice you've ever received?","type":"text","optional":True},
  {"id":"worst_advice_received","text":"What's the worst piece of advice you've followed?","type":"text","optional":True},
  {"id":"proudest_moment","text":"What's one moment you're proud of?","type":"text","optional":True},
  {"id":"biggest_regret","text":"What's a regret you learned from?","type":"text","optional":True},
  {"id":"secret_skill","text":"Do you have a secret skill or party trick?","type":"text","optional":True},
  {"id":"favorite_joke","text":"Tell me a joke you like (optional).","type":"text","optional":True},
  {"id":"favorite_quote","text":"Share a quote that resonates with you (optional).","type":"text","optional":True},
  {"id":"bookshelf_top","text":"What's the top book on your bookshelf right now?","type":"text","optional":True},
  {"id":"last_movie_seen","text":"What's the last movie you watched and liked?","type":"text","optional":True},
  {"id":"creative_habit","text":"Do you have a creative habit (writing, drawing, music)?","type":"text","optional":True},
  {"id":"daily_habit","text":"What's one small daily habit you try to keep?","type":"text","optional":True},
  {"id":"learned_recently","text":"What's something new you learned recently?","type":"text","optional":True},
  {"id":"language_interest","text":"Is there a language you'd like to learn?","type":"text","optional":True},
  {"id":"favorite_tech_hack","text":"Share a small tech trick or shortcut you love.","type":"text","optional":True},
  {"id":"phone_app_most_used","text":"Which phone app do you use most?","type":"text","optional":True},
  {"id":"social_media_feel","text":"How does social media make you feel most days?","type":"choice","choices":["energized","drained","neutral","inspired"],"optional":True},
  {"id":"favorite_local_food_spot","text":"Name a local restaurant or cafe you recommend.","type":"text","optional":True},
  {"id":"cooking_skill","text":"How comfortable are you cooking: beginner/intermediate/advanced?","type":"choice","choices":["beginner","intermediate","advanced"],"optional":True},
  {"id":"go_to_recipe","text":"What's a go-to recipe you make often?","type":"text","optional":True},
  {"id":"coffee_or_tea","text":"Coffee or tea (or neither)?","type":"choice","choices":["coffee","tea","neither"],"optional":True},
  {"id":"favorite_drink","text":"What's your favorite non-alcoholic drink?","type":"text","optional":True},
  {"id":"drink_alcohol_pref","text":"Do you prefer beer, wine, cocktails, or none?","type":"choice","choices":["beer","wine","cocktails","none"],"optional":True},
  {"id":"travel_style","text":"Do you prefer planning every detail or winging it when you travel?","type":"choice","choices":["plan","wing","mix"],"optional":True},
  {"id":"most_recent_trip","text":"Where did you travel most recently and what stood out?","type":"text","optional":True},
  {"id":"dream_dinner_guests","text":"If you could invite three people (alive or dead) to dinner, who would they be?","type":"text","optional":True},
  {"id":"superpower_choice","text":"If you could have one superpower for a day, what would it be?","type":"text","optional":True},
  {"id":"moral_dilemma","text":"Would you rather always tell the truth or always be kind even if it hides the truth?","type":"choice","choices":["always truth","always kind"],"optional":True},
  {"id":"favorite_memory_recent","text":"Share a small win or favorite moment from the last month.","type":"text","optional":True},
  {"id":"stress_relief","text":"What's your go-to way to relieve stress?","type":"text","optional":True},
  {"id":"self_care","text":"Name one self-care practice you try to keep.","type":"text","optional":True},
  {"id":"long_term_habit","text":"Is there a habit you'd like to build over the next year?","type":"text","optional":True},
  {"id":"daily_music","text":"What music do you play to get through the day?","type":"text","optional":True},
  {"id":"favorite_artist_live","text":"Have you seen a live performance that stuck with you? Who?","type":"text","optional":True},
  {"id":"nostalgic_item","text":"Is there an object you keep for nostalgia? What is it?","type":"text","optional":True},
  {"id":"favorite_smaller_goal","text":"What's a small goal you want to achieve this week?","type":"text","optional":True},
  {"id":"learning_style","text":"Do you learn best by reading, watching, doing, or listening?","type":"choice","choices":["reading","watching","doing","listening"],"optional":True},
  {"id":"favorite_board_game","text":"Do you have a favorite board or card game?","type":"text","optional":True},
  {"id":"favorite_app_for_focus","text":"Which app helps you focus or be productive?","type":"text","optional":True},
  {"id":"most_used_shortcut","text":"What's a keyboard shortcut you use all the time?","type":"text","optional":True},
  {"id":"favorite_local_event","text":"Is there a local event or festival you look forward to?","type":"text","optional":True},
  {"id":"favorite_smaller_habit","text":"What's one tiny habit that improves your day?","type":"text","optional":True},
  {"id":"favorite_scented_candle","text":"If you use candles, what's a scent you love?","type":"text","optional":True},
  {"id":"favorite_podcast_host","text":"Who is a podcast host you enjoy listening to?","type":"text","optional":True},
  {"id":"favorite_icebreaker","text":"What's an icebreaker question you like to ask?","type":"text","optional":True},
  {"id":"most_recent_learning_resource","text":"Share a course, book, or article that helped you recently.","type":"text","optional":True},
  {"id":"favorite_local_walk","text":"Do you have a favorite walking route or trail? Where is it?","type":"text","optional":True},
  {"id":"favorite_splurge","text":"What's a small splurge you treat yourself to?","type":"text","optional":True},
  {"id":"comfort_show","text":"Which TV show do you rewatch when you need comfort?","type":"text","optional":True},
  {"id":"favorite_podcast_genre","text":"What podcast genre do you prefer?","type":"choice","choices":["news","comedy","true crime","education","interviews","other"],"optional":True},
  {"id":"favorite_local_bookstore","text":"Do you have a favorite bookstore or library?","type":"text","optional":True},
  {"id":"favorite_tech_feature","text":"What's a small tech feature you wish more apps had?","type":"text","optional":True},
  {"id":"most_inspiring_person","text":"Who inspires you most right now and why?","type":"text","optional":True},
  {"id":"one_word_mood","text":"If you had to pick one word for your mood today, what is it?","type":"text","optional":True}
]

# --- Yes/No parsing sets ---
YES = {"yes","y","yeah","yep","sure","ok","true"}
NO = {"no","n","nope","nah","false"}

def parse_yesno(s):
    if s is None:
        return None
    s = str(s).strip().lower()
    if s in YES:
        return "yes"
    if s in NO:
        return "no"
    return None

# --- TTS backend detection and helpers ---
TTS_BACKEND = None  # 'macos_say','windows_ps','spd-say','espeak','text2wave', or None
AUTOSAVE_PATH = "interview_latest.json"  # default, may be overridden by CLI

def detect_tts_backend():
    global TTS_BACKEND
    system = platform.system()
    if system == "Darwin" and shutil.which("say"):
        TTS_BACKEND = "macos_say"
        return
    if system == "Windows":
        if shutil.which("powershell") or shutil.which("pwsh"):
            TTS_BACKEND = "windows_ps"
            return
    if shutil.which("spd-say"):
        TTS_BACKEND = "spd-say"
        return
    if shutil.which("espeak"):
        TTS_BACKEND = "espeak"
        return
    if shutil.which("text2wave"):
        if shutil.which("aplay") or shutil.which("afplay"):
            TTS_BACKEND = "text2wave"
            return
    TTS_BACKEND = None

def _run_subprocess(cmd):
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False

def tts(text, lang=None, rate=None):
    if not text:
        return False
    global TTS_BACKEND
    if TTS_BACKEND == "macos_say":
        cmd = ["say"]
        if rate is not None:
            cmd += ["-r", str(rate)]
        cmd += [text]
        return _run_subprocess(cmd)
    if TTS_BACKEND == "windows_ps":
        try:
            fd, path = tempfile.mkstemp(suffix=".ps1", text=True)
            os.close(fd)
            safe_text = text.replace("'", "''")
            rate_block = ""
            if rate is not None:
                rate_block = f"$sp.Rate = {int(rate)}"
            ps_contents = f"""
Add-Type -AssemblyName System.speech
$sp = New-Object System.Speech.Synthesis.SpeechSynthesizer
{rate_block}
$sp.Speak('{safe_text}')
"""
            with open(path, "w", encoding="utf-8") as f:
                f.write(ps_contents)
            exe = shutil.which("powershell") or shutil.which("pwsh") or "powershell"
            cmd = [exe, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", path]
            result = _run_subprocess(cmd)
            try:
                os.remove(path)
            except Exception:
                pass
            return result
        except Exception:
            return False
    if TTS_BACKEND == "spd-say":
        return _run_subprocess(["spd-say", text])
    if TTS_BACKEND == "espeak":
        cmd = ["espeak"]
        if rate is not None:
            cmd += ["-s", str(rate)]
        cmd += [text]
        return _run_subprocess(cmd)
    if TTS_BACKEND == "text2wave":
        try:
            fd, wav_path = tempfile.mkstemp(suffix=".wav")
            os.close(fd)
            p = subprocess.Popen(["text2wave", "-o", wav_path], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True)
            p.communicate(text)
            if p.returncode == 0:
                if shutil.which("aplay"):
                    _run_subprocess(["aplay", wav_path])
                    os.remove(wav_path)
                    return True
                if shutil.which("afplay"):
                    _run_subprocess(["afplay", wav_path])
                    os.remove(wav_path)
                    return True
            try:
                os.remove(wav_path)
            except Exception:
                pass
        except Exception:
            pass
    print("(TTS unavailable) " + text)
    return False

def speak_and_print(text, newline=True):
    if newline:
        print(text)
    else:
        sys.stdout.write(text)
        sys.stdout.flush()
    if TTS_ENABLED and TTS_BACKEND:
        try:
            return tts(text, rate=TTS_RATE)
        except Exception:
            return False
    return False

def report_tts_status():
    if TTS_BACKEND:
        speak_and_print(f"TTS backend detected: {TTS_BACKEND}. Speech is enabled.")
    else:
        speak_and_print("No TTS backend detected. Speech will be unavailable.")
        system = platform.system()
        if system == "Darwin":
            speak_and_print("macOS usually includes 'say'. If missing, ensure your system speech is available.")
        elif system == "Windows":
            speak_and_print("Windows uses PowerShell System.Speech. Ensure PowerShell is available.")
        else:
            speak_and_print("On Linux install one of: speech-dispatcher (spd-say), espeak, or festival/text2wave and aplay.")
        speak_and_print("You can still run the interviewer; responses will be printed.")

# --- Runtime TTS toggle handling ---
def handle_runtime_tts_command(s):
    global TTS_ENABLED
    if not isinstance(s, str):
        return False
    cmd = s.strip().lower()
    if not cmd.startswith("/tts"):
        return False
    parts = cmd.split()
    if len(parts) == 1:
        speak_and_print(f"TTS is {'ON' if TTS_ENABLED else 'OFF'}.")
        return True
    if parts[1] in ("on", "enable"):
        TTS_ENABLED = True
        speak_and_print("TTS enabled.")
        return True
    if parts[1] in ("off", "disable"):
        TTS_ENABLED = False
        print("TTS disabled.")
        return True
    speak_and_print("Unknown TTS command. Use '/tts on' or '/tts off'.")
    return True

# --- Autosave helpers ---
def autosave_answers(answers: Dict, path: str):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"timestamp": datetime.datetime.utcnow().isoformat() + "Z", "answers": answers}, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print("Autosave failed:", e)

# --- Follow-up generation (model hook + rule fallback) ---
def call_model_api(prompt: str, max_tokens: int = 64) -> Optional[str]:
    """
    Placeholder for model call. Replace with your LLM API call if desired.
    Return a single concise follow-up question string, or None to fall back to rules.
    """
    return None  # keep None to use rule-based fallback by default

def rule_based_followup(last_user_input: str, short_history: List[Dict]) -> str:
    text = (last_user_input or "").strip().lower()
    if text == "":
        return "You didn't say anything. Could you try again or say one short sentence?"
    if len(text) < 10:
        return "Can you expand on that a little bit?"
    if "habit" in text or "daily" in text:
        return "Why is that habit important to you?"
    if "language" in text:
        return "Which language would you like to learn first?"
    if "sleep" in text or "nap" in text:
        return "How long do you usually sleep and does it affect your day?"
    return "Tell me one specific example that illustrates that."

def generate_followup(last_user_input: str, short_history: List[Dict]) -> str:
    # Try model first
    ctx_lines = []
    for turn in short_history[-4:]:
        p = turn.get("prompt", "")
        r = turn.get("response", "")
        ctx_lines.append(f"Q: {p}\nA: {r}")
    ctx = "\n".join(ctx_lines)
    prompt = (
        "You are a concise interviewer. Given the conversation context and the user's last answer, "
        "produce exactly one short follow-up question to keep the interview going. "
        "Do not add commentary or multiple questions.\n\n"
        f"Context:\n{ctx}\n\n"
        f"Last answer: {last_user_input}\n\nFollow-up question:"
    )
    try:
        model_q = call_model_api(prompt)
        if model_q:
            return model_q.strip()
    except Exception:
        pass
    return rule_based_followup(last_user_input, short_history)

# --- Assistant reply templates (restored full set) ---
REPLY_TEMPLATES = {
    "name": ["Nice to meet you, {a}.","Great to meet you, {a}.","Pleasure to meet you, {a}."],
    "preferred_name": ["Got it — I'll call you {a}.","Thanks — {a} it is.","Perfect, {a}."],
    "pronouns": ["Thanks for sharing your pronouns: {a}.","Noted: {a}.","Understood — {a}."],
    "age": ["Thanks — {a} years noted.","{a} — got it.","Appreciate the number: {a}."],
    "location": ["{a} — nice area.","Got your location: {a}.","Thanks, I recorded {a}."],
    "occupation": ["Working as {a} — interesting.","Noted your role: {a}.","{a} sounds like a meaningful job."],
    "industry": ["Industry: {a} — good to know.","Thanks — you work in {a}.","{a} sector noted."],
    "experience_years": ["{a} years of experience — impressive.","Noted: {a} years.","{a} years — that gives good context."],
    "skills": ["Those skills are valuable: {a}.","Nice skillset: {a}.","Good mix of skills: {a}."],
    "education_level": ["Education level recorded: {a}.","Thanks — {a} noted.","{a} — got it."],
    "languages": ["Languages: {a} — useful to know.","Noted your languages: {a}.","{a} — thanks for sharing."],
    "hobbies": ["Hobbies: {a} — sounds fun.","Nice hobbies: {a}.","Thanks — {a} are great pastimes."],
    "music_genre": ["{a} — solid taste.","You like {a} — cool.","{a} noted as your favorite genre."],
    "favorite_song": ["'{a}' sounds like a blast to play loud.","Great pick — '{a}' is a banger.","Nice choice: '{a}'."],
    "plays_instrument": ["Playing an instrument is a great creative outlet.","Nice — being musical is rewarding.","Cool — music adds a lot to life."],
    "instrument": ["A {a} — lovely instrument.","{a} — nice choice of instrument.","Playing the {a} must be fun."],
    "car_owner": ["Car ownership noted: {a}.","Thanks — car owner: {a}.","{a} — got it."],
    "car_make_model": ["A {a} — nice choice.","{a} sounds like a solid ride.","Cool — {a} recorded."],
    "interested_in_hydraulics": ["Hydraulics interest: {a}.","Noted your stance on hydraulics: {a}.","{a} — interesting."],
    "hydraulics_highway_use": ["Using hydraulics on the highway: {a}.","Noted: {a}.","{a} — thanks."],
    "car_mechanic_experience": ["Hands-on mechanic experience: {a}.","Good to know — mechanic experience: {a}.","{a} — noted."],
    "mechanic_years": ["{a} years of mechanical experience — useful context.","Noted: {a} years.","{a} years — thanks."],
    "project_interest": ["Working on a project: {a}.","Project involvement: {a}.","{a} — noted."],
    "project_description": ["That project sounds interesting: {a}","Nice project — {a}","Thanks for describing it: {a}"],
    "project_deadline": ["Deadline noted: {a}.","{a} — thanks for the timeline.","Got it — deadline: {a}."],
    "availability_weekdays": ["Availability: {a}.","Thanks — you're available on {a}.","{a} noted."],
    "availability_time": ["{a} works best — noted.","Thanks — {a} is your preferred time.","{a} — got it."],
    "remote_work": ["Preference recorded: {a}.","{a} — noted for collaboration style.","Thanks — {a} preference saved."],
    "work_tools": ["Tools: {a} — useful to know.","Noted your tools: {a}.","{a} — thanks."],
    "github": ["GitHub/portfolio recorded: {a}.","Thanks — saved your URL: {a}.","{a} — noted."],
    "social_media": ["Social platforms: {a}.","Thanks — you use {a}.","{a} noted."],
    "favorite_tech": ["{a} — can't live without it, huh.","Nice gadget: {a}.","Noted: {a}."],
    "learning_goals": ["Learning goals: {a}.","Great — you want to learn {a}.","{a} — good targets."],
    "mentorship_interest": ["Mentorship preference: {a}.","Noted: {a}.","{a} — thanks."],
    "volunteer": ["Volunteer status: {a}.","Thanks — {a}.","{a} — noted."],
    "volunteer_details": ["You support: {a}.","Thanks — recorded: {a}.","{a} — appreciated."],
    "travel_frequency": ["Travel frequency: {a}.","Noted: {a}.","{a} — thanks."],
    "favorite_destination": ["{a} — lovely choice.","Nice — {a} sounds great.","{a} recorded."],
    "pets": ["Pets: {a}.","Thanks — {a}.","{a} — noted."],
    "pet_details": ["Pet details: {a}.","Cute — {a}.","{a} recorded."],
    "fitness": ["Exercise frequency: {a} times/week.","Noted: {a} workouts per week.","{a} — thanks."],
    "dietary_restrictions": ["Dietary restrictions: {a}.","Thanks — {a}.","{a} noted."],
    "smoke": ["Smoking/vaping: {a}.","Noted: {a}.","{a} — thanks."],
    "alcohol": ["Alcohol: {a}.","Noted: {a}.","{a} — thanks."],
    "sleep_hours": ["You sleep {a} hours — noted.","{a} hours of sleep recorded.","Thanks — {a} hours."],
    "stress_level": ["Stress level {a}/10 — thanks for sharing.","{a} on average — noted.","Got it — {a}/10."],
    "creative_medium": ["Creative medium: {a}.","Nice — you prefer {a}.","{a} — noted."],
    "favorite_artist": ["{a} — great artist.","Nice pick: {a}.","{a} recorded."],
    "reading_habit": ["{a} books/year — impressive.","Noted: {a} books per year.","{a} — thanks."],
    "podcast": ["Podcast: {a}.","Nice — {a} recorded.","{a} — thanks."],
    "movie_genre": ["Movie genre: {a}.","You like {a} — noted.","{a} — thanks."],
    "favorite_movie": ["{a} — great movie.","Nice choice: {a}.","{a} recorded."],
    "gaming": ["Gaming: {a}.","Noted: {a}.","{a} — thanks."],
    "gaming_platform": ["Platform: {a}.","You use {a} — noted.","{a} — thanks."],
    "budget_monthly": ["Monthly hobby budget: ${a} — noted.","Thanks — ${a} recorded.","{a} per month — got it."],
    "big_goal": ["Big goal noted: {a}.","Ambitious — {a} sounds great.","{a} — thanks for sharing."],
    "barriers": ["Barrier noted: {a}.","Thanks — that's helpful context.","{a} — understood."],
    "support_needed": ["Support needed: {a}.","Noted — {a} would help.","{a} — thanks."],
    "final_comments": ["Thanks for sharing that.","Final comments saved.","Appreciate the note: {a}."],
    "favorite_food": ["{a} — delicious choice.","Nice — {a} sounds tasty.","{a} recorded."],
    "comfort_food": ["Comfort food: {a} — I get that.","{a} — perfect for tough days.","Noted: {a}."],
    "guilty_pleasure": ["Guilty pleasure: {a} — no judgment.","Nice — {a} can be fun.","{a} — thanks for sharing."],
    "ideal_weekend": ["That sounds lovely: {a}.","Ideal weekend noted: {a}.","{a} — nice plan."],
    "perfect_vacation": ["{a} — sounds perfect.","Nice — {a} vacation noted.","{a} — great choice."],
    "bucket_list_item": ["Bucket list: {a} — inspiring.","{a} — added to your list.","Nice goal: {a}."],
    "favorite_childhood_memory": ["Lovely memory: {a}.","Thanks for sharing that memory: {a}.","{a} — sweet."],
    "favorite_game_childhood": ["{a} — classic pick.","Nice — {a} sounds fun.","{a} recorded."],
    "favorite_season": ["{a} — great season choice.","Nice reasons for {a}.","{a} — noted."],
    "morning_routine": ["Morning routine: {a} — sounds productive.","Thanks — {a} noted.","{a} — nice habit."],
    "night_routine": ["Night routine: {a} — relaxing.","{a} — good way to wind down.","Noted: {a}."],
    "sleep_chronotype": ["Chronotype: {a} — noted.","{a} — thanks for sharing.","Good to know — {a}."],
    "favorite_smell": ["{a} — that smell is lovely.","Nice — {a} makes you happy.","{a} recorded."],
    "favorite_sound": ["{a} — great sound choice.","Nice — {a} is soothing.","{a} — noted."],
    "favorite_color": ["{a} — nice color.","{a} — noted.","Thanks — {a}."],
    "favorite_place_local": ["{a} — sounds like a great spot.","Nice local pick: {a}.","{a} recorded."],
    "ideal_home_feature": ["Ideal feature: {a} — nice.","{a} — that would be great to have.","Noted: {a}."],
    "pet_peeve": ["Pet peeve: {a} — I hear you.","{a} — that can be annoying.","Noted: {a}."],
    "best_advice_received": ["Great advice: {a}.","Thanks for sharing that advice: {a}.","{a} — wise words."],
    "worst_advice_received": ["Ouch — {a} sounds rough.","Learned from that: {a}.","{a} — noted."],
    "proudest_moment": ["Proud moment: {a} — congrats.","Thanks for sharing: {a}.","{a} — well done."],
    "biggest_regret": ["Regret noted: {a}.","Thanks for sharing — {a} is meaningful.","{a} — learned from it."],
    "secret_skill": ["Secret skill: {a} — impressive.","Nice trick: {a}.","{a} — cool."],
    "favorite_joke": ["Nice joke: {a}.","That made me smile — {a}.","{a} — funny."],
    "favorite_quote": ["Quote noted: {a}.","Thanks — {a} is inspiring.","{a} — good one."],
    "bookshelf_top": ["Top book: {a} — nice pick.","{a} — added to the list.","Thanks — {a}."],
    "last_movie_seen": ["Last movie: {a} — good to know.","{a} — thanks for sharing.","Nice — {a}."],
    "creative_habit": ["Creative habit: {a} — great.","{a} — keep it up.","Noted: {a}."],
    "daily_habit": ["Nice — keeping a small habit helps.","Small habits add up — thanks for sharing.","Good to know — small routines matter."],
    "learned_recently": ["Nice — {a} is a useful thing to learn.","Thanks — {a} noted.","{a} — good to know."],
    "language_interest": ["Learning a language is rewarding — nice pick.","Language interest noted: {a}.","{a} — great choice to learn."],
    "favorite_tech_hack": ["Tech hack: {a} — handy.","Nice tip: {a}.","{a} — thanks for sharing."],
    "phone_app_most_used": ["App: {a} — noted.","{a} — thanks.","Nice — {a}."],
    "social_media_feel": ["You feel {a} about social media — noted.","Thanks — {a} recorded.","{a} — understood."],
    "favorite_local_food_spot": ["Local spot: {a} — thanks for the rec.","{a} — sounds tasty.","Noted: {a}."],
    "cooking_skill": ["Cooking level: {a} — nice.","{a} — noted.","Thanks — {a}."],
    "go_to_recipe": ["Recipe: {a} — sounds delicious.","{a} — thanks for sharing.","Noted: {a}."],
    "coffee_or_tea": ["{a} — good choice.","{a} — noted.","Thanks — {a}."],
    "favorite_drink": ["{a} — refreshing choice.","{a} — noted.","Thanks — {a}."],
    "drink_alcohol_pref": ["Preference: {a} — noted.","{a} — thanks.","Noted: {a}."],
    "travel_style": ["Travel style: {a} — good to know.","{a} — noted.","Thanks — {a}."],
    "most_recent_trip": ["Most recent trip: {a} — sounds great.","{a} — thanks for sharing.","Noted: {a}."],
    "dream_dinner_guests": ["Dinner guests: {a} — interesting list.","{a} — nice choices.","Thanks — {a}."],
    "superpower_choice": ["Superpower: {a} — fun pick.","{a} — noted.","Nice — {a}."],
    "moral_dilemma": ["Tough choice: {a}.","Thanks — {a} noted.","{a} — interesting."],
    "favorite_memory_recent": ["Small win: {a} — congrats.","{a} — nice moment.","Thanks for sharing: {a}."],
    "stress_relief": ["Stress relief: {a} — good strategy.","{a} — noted.","Thanks — {a}."],
    "self_care": ["Self-care: {a} — important.","{a} — noted.","Thanks — {a}."],
    "long_term_habit": ["Long-term habit: {a} — great goal.","{a} — noted.","Good luck with {a}."],
    "daily_music": ["Music: {a} — nice soundtrack.","{a} — noted.","Thanks — {a}."],
    "favorite_artist_live": ["Live performance: {a} — sounds memorable.","{a} — noted.","Thanks — {a}."],
    "nostalgic_item": ["Nostalgic item: {a} — meaningful.","{a} — thanks for sharing.","Noted: {a}."],
    "favorite_smaller_goal": ["Small goal: {a} — achievable.","{a} — good plan.","Noted: {a}."],
    "learning_style": ["Learning style: {a} — noted.","{a} — thanks.","Good to know — {a}."],
    "favorite_board_game": ["Board game: {a} — fun pick.","{a} — noted.","Thanks — {a}."],
    "favorite_app_for_focus": ["App for focus: {a} — useful tip.","{a} — noted.","Thanks — {a}."],
    "most_used_shortcut": ["Shortcut: {a} — handy.","{a} — noted.","Thanks — {a}."],
    "favorite_local_event": ["Local event: {a} — sounds fun.","{a} — noted.","Thanks — {a}."],
    "favorite_smaller_habit": ["Tiny habit: {a} — those add up.","{a} — noted.","Thanks — {a}."],
    "favorite_scented_candle": ["Scent: {a} — lovely.","{a} — noted.","Thanks — {a}."],
    "favorite_podcast_host": ["Host: {a} — nice pick.","{a} — noted.","Thanks — {a}."],
    "favorite_icebreaker": ["Icebreaker: {a} — good one.","{a} — noted.","Thanks — {a}."],
    "most_recent_learning_resource": ["Resource: {a} — useful.","{a} — noted.","Thanks — {a}."],
    "favorite_local_walk": ["Walk: {a} — sounds peaceful.","{a} — noted.","Thanks — {a}."],
    "favorite_splurge": ["Splurge: {a} — treat yourself.","{a} — noted."],
}

def choose_reply_template(qid, answer):
    templates = REPLY_TEMPLATES.get(qid, None)
    if not templates:
        return None
    t = random.choice(templates)
    return t.replace("{a}", str(answer))

# --- Prompt wrapper that speaks the prompt then reads input ---
def prompt_input(prompt, autosave_path):
    """
    Speak and print the prompt, read input, handle /tts commands inline.
    Returns the raw user input string (may be empty). If a TTS command was used,
    it toggles and re-prompts.
    """
    try:
        speak_and_print(prompt, newline=False)
        sys.stdout.write(" ")
        sys.stdout.flush()
        s = input()
        # If user typed a TTS command, handle it and re-prompt immediately
        if handle_runtime_tts_command(s):
            return prompt_input(prompt, autosave_path)
        return s  # raw string, may be empty
    except (EOFError, KeyboardInterrupt):
        speak_and_print("\nInput cancelled.")
        sys.exit(1)

# --- Main interview flow: allow unanswered questions (blank = skip) ---
def run_interview(start_prompt_id=None, autosave_path=AUTOSAVE_PATH):
    # Build a simple mapping from id -> question dict for quick lookup and index mapping
    qmap = {q["id"]: q for q in QUESTIONS}
    id_to_index = {q["id"]: i for i, q in enumerate(QUESTIONS)}

    # Determine starting index
    if start_prompt_id and start_prompt_id in id_to_index:
        idx = id_to_index[start_prompt_id]
    else:
        idx = 0

    answers = {}  # store answers by question id (only saved when user provides non-empty input)
    short_history = deque(maxlen=6)  # keep last few turns for followups

    detect_tts_backend()
    report_tts_status()

    # Iterate through QUESTIONS once in order starting at idx
    while idx < len(QUESTIONS):
        current_q = QUESTIONS[idx]
        prompt_text = current_q["text"]

        raw_input_value = prompt_input(prompt_text, autosave_path)
        if raw_input_value is None:
            raw_input_value = ""

        # Preserve exactly what user typed (including whitespace); treat empty string as unanswered
        user_input = raw_input_value

        # Quit commands
        if user_input.strip().lower() in ("/quit", "/exit"):
            speak_and_print("Exiting interviewer. Goodbye.")
            break

        # If blank, leave unanswered (do not save) and move to next question (no follow-up)
        if user_input == "":
            idx += 1
            continue

        # Save the non-empty answer as-is
        answers[current_q["id"]] = user_input
        autosave_answers(answers, autosave_path)

        # Log short history turn
        short_history.append({"prompt": prompt_text, "response": user_input, "ts": time.time()})

        # Optionally print an assistant reply using templates
        reply = choose_reply_template(current_q["id"], user_input)
        if reply:
            speak_and_print(reply)

        # Generate exactly one follow-up for this answer (no chaining)
        followup_text = generate_followup(user_input, list(short_history))

        # Try to match followup_text to an existing question text (case-insensitive)
        matched_q = None
        for q in QUESTIONS:
            if q.get("text", "").strip().lower() == followup_text.strip().lower():
                matched_q = q
                break

        if matched_q:
            # Ask the matched question as a single follow-up
            followup_prompt = matched_q["text"]
            raw_followup = prompt_input(followup_prompt, autosave_path)
            if raw_followup is None:
                raw_followup = ""
            followup_answer = raw_followup
            if followup_answer.strip().lower() in ("/quit", "/exit"):
                speak_and_print("Exiting interviewer. Goodbye.")
                break
            # Save follow-up answer only if non-empty (consistent with "allow unanswered")
            if followup_answer != "":
                answers[matched_q["id"]] = followup_answer
                autosave_answers(answers, autosave_path)
                short_history.append({"prompt": followup_prompt, "response": followup_answer, "ts": time.time()})
                reply2 = choose_reply_template(matched_q["id"], followup_answer)
                if reply2:
                    speak_and_print(reply2)
            # do not chain further follow-ups from this follow-up
        else:
            # Transient free-form follow-up: ask it once, save under generated id only if non-empty
            transient_prompt = followup_text
            raw_followup = prompt_input(transient_prompt, autosave_path)
            if raw_followup is None:
                raw_followup = ""
            followup_answer = raw_followup
            if followup_answer.strip().lower() in ("/quit", "/exit"):
                speak_and_print("Exiting interviewer. Goodbye.")
                break
            if followup_answer != "":
                fid = f"followup_{int(time.time())}"
                answers[fid] = followup_answer
                autosave_answers(answers, autosave_path)
                short_history.append({"prompt": transient_prompt, "response": followup_answer, "ts": time.time()})
            # no further chaining

        # Advance to next main question
        idx += 1

    # End of QUESTIONS iteration
    speak_and_print("Interview complete. Your saved answers (non-empty) have been written to the autosave file.")
    autosave_answers(answers, autosave_path)

# --- Run as script ---
if __name__ == "__main__":
    args = parse_cli_args()
    if args.no_tts:
        TTS_ENABLED = False
    if args.tts_rate is not None:
        TTS_RATE = args.tts_rate
    if args.autosave_file:
        AUTOSAVE_PATH = args.autosave_file

    print("Type /tts on or /tts off to toggle speech. Type /quit or /exit to stop.")
    try:
        run_interview(start_prompt_id=None, autosave_path=AUTOSAVE_PATH)
    except KeyboardInterrupt:
        print("\nGoodbye.")
