#!/usr/bin/env python3
"""
infinite_pi_stream.py

Continuously compute and stream digits of π. The script increases precision
in steps and prints only the newly computed fractional digits so the output
appears to grow forever. Stop with Ctrl+C.

Notes:
- Uses the Chudnovsky algorithm for fast convergence.
- For very large digit counts consider using gmpy2 or other big-int libraries.
"""

import time
import signal
from decimal import Decimal, getcontext

# --- Chudnovsky algorithm ---------------------------------------------------
def chudnovsky_pi(digits):
    """Compute pi to `digits` fractional digits (Decimal)."""
    if digits <= 0:
        return Decimal(3)
    extra = 10
    getcontext().prec = digits + extra

    C = Decimal(426880) * Decimal(10005).sqrt()
    M = Decimal(1)
    L = Decimal(13591409)
    X = Decimal(1)
    K = Decimal(6)
    S = L

    k = 1
    while True:
        M = (M * (K**3 - 16*K)) / (k**3)
        L = L + Decimal(545140134)
        X = X * Decimal(-262537412640768000)  # (-640320)^3
        term = (M * L) / X
        S += term
        # stop when term is tiny relative to desired precision
        if abs(term) < Decimal(10) ** (-(digits + extra - 2)):
            break
        k += 1
        K += 12

    pi = C / S
    # set final precision to requested digits + integer part
    getcontext().prec = digits + 1
    return +pi

# --- Formatting -------------------------------------------------------------
def format_pi_to_digits(pi_decimal, digits):
    """Return string '3.<digits>' with exactly `digits` fractional digits."""
    s = format(pi_decimal, 'f')
    if '.' in s:
        intpart, frac = s.split('.')
    else:
        intpart, frac = s, ''
    frac = (frac + '0' * digits)[:digits]
    return f"{intpart}.{frac}"

# --- Infinite streaming logic ----------------------------------------------
def infinite_stream(start_digits=100, step=1000, chunk_print=80, delay=0.0):
    """
    Continuously compute more digits and print only the new fractional digits.
    - start_digits: initial number of fractional digits to compute.
    - step: how many additional fractional digits to compute each iteration.
    - chunk_print: how many characters to print at once (for nicer output).
    - delay: seconds to wait after printing each chunk (0 for no delay).
    """
    # handle Ctrl+C as KeyboardInterrupt
    def _sigint_handler(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGINT, _sigint_handler)

    current_digits = max(10, start_digits)
    printed_frac_len = 0
    intpart_printed = False

    try:
        while True:
            # compute pi to current_digits fractional digits
            pi_dec = chudnovsky_pi(current_digits)
            pi_str = format_pi_to_digits(pi_dec, current_digits)  # "3.<frac>"

            # split into integer and fractional parts
            intpart, frac = pi_str.split('.')

            # print integer part once (with trailing dot)
            if not intpart_printed:
                print(intpart + '.', end='', flush=True)
                intpart_printed = True

            # determine new fractional digits that haven't been printed yet
            if printed_frac_len < len(frac):
                new_digits = frac[printed_frac_len:]
                # print in chunks for readability
                i = 0
                while i < len(new_digits):
                    chunk = new_digits[i:i+chunk_print]
                    print(chunk, end='', flush=True)
                    i += len(chunk)
                    if delay:
                        time.sleep(delay)
                printed_frac_len = len(frac)

            # increase precision for next iteration
            current_digits += step

    except KeyboardInterrupt:
        print("\n\nStreaming stopped by user. Goodbye.")

# --- CLI entry point -------------------------------------------------------
if __name__ == "__main__":
    print("Infinite Pi streamer. Press Ctrl+C to stop.")
    # You can tweak these parameters before running:
    START = 100        # initial fractional digits
    STEP  = 1000       # digits added each loop
    CHUNK = 80         # characters printed at once
    DELAY = 0.0        # seconds between chunk prints

    infinite_stream(start_digits=START, step=STEP, chunk_print=CHUNK, delay=DELAY)
