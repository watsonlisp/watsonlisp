#!/usr/bin/env python3
"""
Random error quotes with system sounds and simple TTS (no pip required).
Press Enter to show a new random error quote, play a sound, speak it, and print it in red.
Type 'q' + Enter to quit.
"""

import random
import platform
import subprocess
import sys
import time
import tempfile
import os
import shutil
import ctypes

# Toggle TTS on/off
TTS_ENABLED = True

QUOTES = [
    "An unknown error has occurred. Please try again later.",
    "Something went wrong. We're looking into it.",
    "Unexpected exception: NullReferenceException at line 42.",
    "Error 404: Resource not found.",
    "Permission denied. Contact your administrator.",
    "Operation timed out. The server took too long to respond.",
    "Disk full. Free up some space and retry.",
    "Failed to save changes. Please check your connection.",
    "Syntax error: unexpected token in expression.",
    "Fatal error: application will now close.",
    "Access violation at address 0x00000000.",
    "Segmentation fault (core dumped).",
    "I/O error: device not ready.",
    "Dependency missing: please install required package.",
    "Authentication failed. Invalid credentials provided.",
    "Connection refused by remote host.",
    "Network unreachable. Check your network settings.",
    "Service temporarily unavailable. Try again in a few minutes.",
    "Database error: could not establish a connection.",
    "Transaction aborted due to conflict.",
    "Resource limit exceeded. Try again later.",
    "Configuration error: invalid value detected.",
    "Checksum mismatch: file may be corrupted.",
    "Memory allocation failed.",
    "Stack overflow detected.",
    "Unhandled promise rejection.",
    "Protocol error: unexpected response format.",
    "SSL handshake failed. Certificate verification error.",
    "Rate limit exceeded. Slow down your requests.",
    "Session expired. Please log in again.",
    "Invalid input: value out of range.",
    "File not found: verify the path and try again.",
    "Permission revoked: operation not allowed.",
    "Service dependency failed to start.",
    "Hardware error: please restart your device.",
    "License validation failed.",
    "Feature not implemented.",
    "Operation cancelled by user.",
    "Data validation failed: required field missing.",
    "Encoding error: unsupported character set.",
    "Decoding error: malformed data stream.",
    "Resource locked by another process.",
    "Concurrent modification detected.",
    "Insufficient privileges to perform this action.",
    "Broken pipe: remote end closed connection.",
    "Gateway timeout: upstream server did not respond.",
    "Bad gateway: invalid response from upstream server.",
    "Bad request: malformed syntax.",
    "Conflict: resource already exists.",
    "Precondition failed: ETag mismatch.",
    "Unsupported media type.",
    "Too many redirects.",
    "Service degraded: partial functionality available.",
    "Internal server error: unexpected condition.",
    "Dependency version conflict detected.",
    "Invalid token: authentication required.",
    "Two-factor authentication required.",
    "Account locked due to suspicious activity.",
    "Quota exceeded: upgrade required to continue.",
    "Backup failed: insufficient storage.",
    "Restore failed: backup file invalid.",
    "Checksum verification failed during download.",
    "Installer error: missing installation files.",
    "Update failed: please retry the update.",
    "Rollback initiated due to failure.",
    "Configuration file parse error.",
    "Invalid certificate: expired or revoked.",
    "DNS lookup failed: host not found.",
    "Hostname resolution error.",
    "Port already in use.",
    "Service already running.",
    "Service not running.",
    "Invalid command syntax.",
    "Command not found.",
    "Module import failed: module not found.",
    "Plugin failed to initialize.",
    "Script execution error.",
    "Timeout waiting for resource lock.",
    "Resource allocation timed out.",
    "Input/output timeout.",
    "Device not responding.",
    "Peripheral error: device disconnected.",
    "Driver error: incompatible driver version.",
    "Firmware update failed.",
    "Boot error: missing bootloader.",
    "Kernel panic: system halted.",
    "Corrupt configuration detected; using defaults.",
    "Failed to mount filesystem.",
    "Read-only filesystem: cannot write.",
    "Write error: disk may be failing.",
    "Bad sector encountered on disk.",
    "RAID degraded: rebuild required.",
    "Network interface down.",
    "Link is down: check cable or Wi-Fi.",
    "Authentication timeout.",
    "Invalid session state.",
    "Malformed request body.",
    "Header too large.",
    "Cookie parsing error.",
    "Cross-site request forgery detected.",
    "Invalid redirect URI.",
    "OAuth error: invalid grant.",
    "SAML assertion invalid.",
    "Token expired: refresh required.",
    "Insufficient funds for transaction.",
    "Payment gateway error.",
    "Card declined by issuer.",
    "Fraud detection triggered: transaction blocked.",
    "Invoice generation failed.",
    "Email delivery failed: mailbox unavailable.",
    "SMTP error: unable to send message.",
    "Attachment too large to send.",
    "Template rendering error.",
    "Localization missing for requested language.",
    "Unsupported locale.",
    "Timezone conversion error.",
    "Date parsing failed.",
    "Cron job failed to execute.",
    "Scheduler error: task skipped.",
    "Deadlock detected: transaction aborted.",
    "Integrity constraint violation.",
    "Foreign key constraint failed.",
    "Unique constraint violation.",
    "Index out of bounds.",
    "Divide by zero error.",
    "Floating point exception.",
    "Arithmetic overflow.",
    "Underflow error.",
    "Invalid cast exception.",
    "Type mismatch error.",
    "Null pointer dereference.",
    "Object disposed: operation invalid.",
    "Resource leak detected.",
    "Garbage collector error.",
    "Thread aborted unexpectedly.",
    "Thread pool exhausted.",
    "Semaphore timeout.",
    "Lock acquisition failed.",
    "Permission change required to continue.",
    "Security policy violation.",
    "Sandbox violation: operation blocked.",
    "Unsafe operation prevented.",
    "Encryption error: unable to encrypt data.",
    "Decryption failed: wrong key or corrupted data.",
    "Key exchange failed.",
    "HMAC verification failed.",
    "Signature verification failed.",
    "Certificate chain incomplete.",
    "CRL check failed.",
    "OCSP responder unreachable.",
    "Secure channel could not be established.",
    "Insecure protocol version detected.",
    "Deprecated API used: update recommended.",
    "API version mismatch.",
    "Feature flag disabled.",
    "Configuration drift detected.",
    "Health check failed.",
    "Liveness probe failed.",
    "Readiness probe failed.",
    "Container crashed: restart scheduled.",
    "Pod evicted due to resource pressure.",
    "Cluster node not ready.",
    "Orchestration error: scheduling failed.",
    "Image pull failed: repository not found.",
    "Image signature verification failed.",
    "Container runtime error.",
    "Service discovery failed.",
    "Load balancer misconfiguration detected.",
    "SSL certificate not trusted.",
    "Mixed content blocked by browser.",
    "CORS policy blocked the request.",
    "WebSocket handshake failed.",
    "Streaming interrupted: reconnecting.",
    "Media decode error.",
    "Playback failed: unsupported codec.",
    "Buffer underrun detected.",
    "High latency detected: performance degraded.",
    "Slow query detected: optimize your indexes.",
    "Query cancelled by user.",
    "Query plan invalidated.",
    "Replication lag too high.",
    "Leader election failed.",
    "Cluster split-brain detected.",
    "Configuration sync failed.",
    "Secrets manager unavailable.",
    "Secret not found.",
    "Key rotation required.",
    "Audit log write failed.",
    "Monitoring agent not reporting.",
    "Alerting service unreachable.",
    "Metric ingestion failed.",
    "Telemetry disabled by policy.",
    "Debug mode required for more details.",
    "Verbose logging enabled: check logs for details.",
    "Log rotation failed.",
    "Archive failed: retention policy conflict.",
    "Search index corrupted.",
    "Index rebuild required.",
    "Cache miss rate high.",
    "Cache eviction in progress.",
    "Cache backend unavailable.",
    "Feature toggle inconsistency detected.",
    "Experiment rollout failed.",
    "A/B test assignment error.",
    "User profile incomplete.",
    "Profile update failed.",
    "Avatar upload failed.",
    "Password reset token invalid.",
    "Password complexity requirement not met.",
    "Email verification required.",
    "Phone verification failed.",
    "SMS gateway error.",
    "Push notification delivery failed.",
    "Webhook endpoint returned error.",
    "Callback URL unreachable.",
    "Integration handshake failed.",
    "Third-party API rate limited.",
    "Third-party service returned unexpected data.",
    "SDK initialization failed.",
    "Client library incompatible with server.",
    "Deprecated configuration key used.",
    "Migration failed: manual intervention required.",
    "Schema mismatch detected.",
    "Data loss prevented by safety check.",
    "Rollback completed successfully.",
    "Partial success: some items failed.",
    "Batch job failed for some records.",
    "Export aborted: destination unreachable.",
    "Import failed: invalid file format.",
    "CSV parse error: malformed row.",
    "JSON parse error: unexpected token.",
    "XML parse error: mismatched tag.",
    "YAML parse error: indentation problem.",
    "Template not found.",
    "Resource precondition not met.",
    "Operation not idempotent.",
    "Request body too large.",
    "Response too large to buffer.",
    "Streaming rate exceeded.",
    "Client disconnected prematurely.",
    "Server shutting down for maintenance.",
    "Maintenance window active: try later.",
    "Feature in preview: behavior may change.",
    "Experimental feature unstable.",
    "Unsupported platform.",
    "Hardware acceleration unavailable.",
    "Graphics driver crash detected.",
    "Display mode not supported.",
    "Audio device in use by another application.",
    "Microphone access denied.",
    "Camera access denied.",
    "Permission prompt dismissed.",
    "Privacy settings prevent this action.",
    "Parental controls block this content.",
    "Content rating restriction applied.",
    "Age verification required.",
    "Geolocation not available.",
    "Region restricted: content unavailable in your area.",
    "License expired: renew to continue.",
    "Trial period ended.",
    "Activation failed: product key invalid.",
    "Subscription required for this feature.",
    "Billing information incomplete.",
    "Invoice overdue: service suspended.",
    "Account deactivated.",
    "Account deletion in progress.",
    "Data export requested: preparing file.",
    "Data retention policy prevents deletion.",
    "Legal hold prevents modification.",
    "Compliance check failed.",
    "Policy violation detected: action blocked.",
    "Audit required before proceeding.",
    "Consent required to continue.",
    "User opted out of tracking.",
    "Telemetry consent not granted.",
    "Privacy mode enabled: limited functionality.",
    "Accessibility feature required for this operation.",
    "High memory usage detected: consider restarting.",
    "Low battery: operation paused.",
    "Thermal throttling active.",
    "Overcurrent detected on USB port.",
    "Bluetooth pairing failed.",
    "Wi-Fi authentication failed.",
    "Cellular network unavailable.",
    "SIM card error detected.",
    "Roaming disabled: cannot connect.",
    "VPN connection failed.",
    "Proxy authentication required.",
    "Proxy connection refused.",
    "Certificate pinning failed.",
    "Manifest validation failed.",
    "Package signature invalid.",
    "Installer checksum mismatch.",
    "Self-update failed: reverting to previous version.",
    "Crash report submission failed.",
    "Debug symbols not available.",
    "Symbolication failed.",
    "Minidump corrupted.",
    "Telemetry upload deferred.",
    "Feature rollout paused due to errors.",
    "Hotfix applied: restart required.",
    "Safe mode enabled: limited features.",
    "Recovery mode initiated.",
    "Factory reset required to resolve issue.",
    "Hardware diagnostic recommended.",
    "Contact support with error code: E-0001.",
    "Contact support with error code: E-0002.",
    "Contact support with error code: E-0003.",
    "Unhandled error: please report this issue.",
    "Critical failure: system integrity compromised.",
    "Emergency shutdown initiated to protect data.",
    "Please save your work and restart the application.",
    "Operation failed: unknown cause. Retry or contact support."
]


def enable_ansi_on_windows():
    """
    Enable ANSI escape sequence processing on Windows consoles (best-effort).
    This avoids requiring external packages like colorama.
    """
    if platform.system() != "Windows":
        return
    try:
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE = -11
        mode = ctypes.c_uint()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
            new_mode = mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING
            kernel32.SetConsoleMode(handle, new_mode)
    except Exception:
        # If anything fails, we silently continue; printing will still work in many terminals.
        pass


def color_red(text: str) -> str:
    """Wrap text in ANSI codes for red color and reset."""
    RED = "\033[31m"
    RESET = "\033[0m"
    return f"{RED}{text}{RESET}"


def play_system_error_sound():
    """Play a short system error sound where possible."""
    os_name = platform.system()
    try:
        if os_name == "Windows":
            import winsound
            winsound.MessageBeep(winsound.MB_ICONHAND)
            return
    except Exception:
        pass

    if os_name == "Darwin":
        mac_sounds = [
            "/System/Library/Sounds/Glass.aiff",
            "/System/Library/Sounds/Basso.aiff",
            "/System/Library/Sounds/Funk.aiff",
            "/System/Library/Sounds/Pop.aiff"
        ]
        for s in mac_sounds:
            if os.path.exists(s):
                try:
                    subprocess.run(["afplay", s], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return
                except Exception:
                    continue
        sys.stdout.write("\a")
        sys.stdout.flush()
        return

    if os_name == "Linux":
        linux_candidates = [
            "/usr/share/sounds/freedesktop/stereo/dialog-error.oga",
            "/usr/share/sounds/freedesktop/stereo/complete.oga",
            "/usr/share/sounds/ubuntu/stereo/dialog-error.ogg"
        ]
        for cmd in (["paplay"], ["aplay"]):
            if shutil.which(cmd[0]):
                for s in linux_candidates:
                    if os.path.exists(s):
                        try:
                            subprocess.run(cmd + [s], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                            return
                        except Exception:
                            continue
        sys.stdout.write("\a")
        sys.stdout.flush()
        return

    sys.stdout.write("\a")
    sys.stdout.flush()


def speak_text(text: str):
    """
    Speak the given text using platform-native tools without requiring pip.
    - Windows: uses PowerShell + System.Speech (writes text to a temp file to avoid quoting issues).
    - macOS: uses `say`.
    - Linux: tries `spd-say` then `espeak`; falls back to no-op.
    """
    if not TTS_ENABLED:
        return

    os_name = platform.system()

    # Short-circuit empty text
    if not text:
        return

    # macOS: use 'say'
    if os_name == "Darwin":
        if shutil.which("say"):
            try:
                subprocess.run(["say", text], check=False)
                return
            except Exception:
                pass
        return

    # Linux: try spd-say, then espeak
    if os_name == "Linux":
        if shutil.which("spd-say"):
            try:
                subprocess.run(["spd-say", text], check=False)
                return
            except Exception:
                pass
        if shutil.which("espeak"):
            try:
                subprocess.run(["espeak", text], check=False)
                return
            except Exception:
                pass
        # no TTS available
        return

    # Windows: use PowerShell + System.Speech
    if os_name == "Windows":
        # Write text to a temporary UTF-8 file and have PowerShell read it to avoid quoting issues.
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".txt") as tf:
                tf.write(text)
                temp_path = tf.name
            # Build PowerShell command to read the file and speak its contents.
            ps_command = (
                "Add-Type -AssemblyName System.Speech;"
                "$t = Get-Content -Raw -Encoding UTF8 -Path '{}' ;"
                "(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak($t)"
            ).format(temp_path.replace("'", "''"))
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_command],
                           check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        finally:
            try:
                if temp_path and os.path.exists(temp_path):
                    os.remove(temp_path)
            except Exception:
                pass
        return

    # Unknown OS: no-op
    return


def show_random_error():
    quote = random.choice(QUOTES)
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    message = f"[{timestamp}] ERROR: {quote}"
    # Print in red
    print("\n" + color_red(message))
    # Play sound (best-effort)
    play_system_error_sound()
    # Speak the quote (best-effort)
    speak_text(quote)


def main():
    enable_ansi_on_windows()
    print(color_red("Random Error Quotes — press Enter to generate, 'q' + Enter to quit."))
    print(color_red("TTS is " + ("enabled" if TTS_ENABLED else "disabled") + "."))
    try:
        while True:
            user = input()
            if user.strip().lower() == "q":
                print(color_red("Goodbye."))
                break
            show_random_error()
    except KeyboardInterrupt:
        print("\n" + color_red("Interrupted. Exiting."))


if __name__ == "__main__":
    main()
