#!/usr/bin/env python3
"""
Expanded IQ-style quiz with randomized questions and built-in TTS (no pip required).
Run: python iq_quiz.py            # TTS on, questions randomized
Run: python iq_quiz.py --no-tts  # disable text-to-speech
Run: python iq_quiz.py --no-random  # keep original question order
Run: python iq_quiz.py --num-questions 20  # ask 20 questions
"""

import sys
import platform
import subprocess
import shutil
import argparse
import time
import random

# -------------------------
# Questions (original + extra)
# -------------------------
questions = [
    {"q":"Which number completes the series 2, 6, 12, 20, ?","choices":["26","30","28","24"],"answer":3},
    {"q":"If ALL BLOPS are BLOPS and some BLOPS are BLOPSH, which is true?","choices":["All BLOPSH are BLOPS","Some BLOPS are BLOPSH","No BLOPS are BLOPSH","All BLOPS are BLOPSH"],"answer":2},
    {"q":"Find the odd one out: Apple, Banana, Carrot, Grape","choices":["Apple","Banana","Carrot","Grape"],"answer":3},
    {"q":"If 5 workers build 5 widgets in 5 hours, how many hours for 1 worker to build 1 widget?","choices":["1","5","25","None of these"],"answer":1},
    {"q":"Rotate the letter 'E' 90 degrees clockwise. Which letter does it resemble?","choices":["M","W","3","F"],"answer":3},
    {"q":"Which shape completes the pattern: square, triangle, square, triangle, ?","choices":["Square","Triangle","Circle","Hexagon"],"answer":1},
    {"q":"If CAT -> DBU (each letter +1), DOG -> ?","choices":["EPH","EPI","EPH","EPI"],"answer":1},
    {"q":"What is 15% of 200?","choices":["20","25","30","35"],"answer":3},
    {"q":"Complete the analogy: Book is to Reading as Fork is to ?","choices":["Drawing","Eating","Writing","Stirring"],"answer":2},
    {"q":"Which number is prime?","choices":["21","27","29","33"],"answer":3}
]

more_questions = [
    {"q":"Which number comes next in the sequence 1, 4, 9, 16, ?","choices":["20","24","25","30"],"answer":3},
    {"q":"If all FLOBs are GLOPs and some GLOPs are ZIPS, which is necessarily true?","choices":["All ZIPS are FLOBs","Some FLOBs are ZIPS","No FLOBs are ZIPS","All GLOPs are FLOBs"],"answer":4},
    {"q":"Find the odd one out: Dog, Cat, Hamster, Car","choices":["Dog","Cat","Hamster","Car"],"answer":4},
    {"q":"If 3x = 12, what is x?","choices":["2","3","4","6"],"answer":3},
    {"q":"Rotate the letter 'L' 180 degrees. Which character does it most resemble?","choices":["L","Γ","7","J"],"answer":4},
    {"q":"Which shape does not belong: circle, square, triangle, cylinder","choices":["Circle","Square","Triangle","Cylinder"],"answer":4},
    {"q":"If A -> Z, B -> Y, C -> X (reverse alphabet), what does M map to?","choices":["N","M","Z","L"],"answer":1},
    {"q":"What is 12% of 250?","choices":["20","25","30","40"],"answer":3},
    {"q":"Complete analogy: Pen is to Write as Knife is to ?","choices":["Cut","Sharpen","Hold","Draw"],"answer":1},
    {"q":"Which number is prime?","choices":["51","57","59","63"],"answer":3},
    {"q":"If the day after tomorrow is two days before Thursday, what day is today?","choices":["Sunday","Monday","Tuesday","Wednesday"],"answer":2},
    {"q":"Which word is most similar to 'abundant'?","choices":["Scarce","Plentiful","Tiny","Rare"],"answer":2},
    {"q":"If 7 people shake hands with each other once, how many handshakes occur?","choices":["21","14","28","35"],"answer":1},
    {"q":"Which completes the pattern: 2, 3, 5, 8, 13, ?","choices":["18","20","21","22"],"answer":3},
    {"q":"If RED -> 18 (R=18), what is the sum for 'CAT' (A=1, B=2, ...)?","choices":["24","26","28","30"],"answer":2},
    {"q":"Which of these is a synonym of 'candid'?","choices":["Secretive","Frank","Deceptive","Reserved"],"answer":2},
    {"q":"If a clock shows 3:15, what is the angle between hour and minute hands?","choices":["0 degrees","7.5 degrees","15 degrees","30 degrees"],"answer":2},
    {"q":"Which number is the largest?","choices":["0.5","1/3","0.75","2/3"],"answer":3},
    {"q":"Find the next in the series: Z, X, V, T, ?","choices":["R","S","Q","P"],"answer":1},
    {"q":"If you rearrange the letters 'LISTEN' you can form which word?","choices":["SILENT","TINSEL","ENLIST","All of the above"],"answer":4},
    {"q":"Which is the antonym of 'scarcity'?","choices":["Shortage","Plenty","Lack","Deficit"],"answer":2},
    {"q":"If 4 workers build 4 items in 4 hours, how many hours for 2 workers to build 2 items?","choices":["1","2","4","8"],"answer":3},
    {"q":"Which completes the analogy: Tree is to Forest as Star is to ?","choices":["Sky","Galaxy","Night","Constellation"],"answer":4},
    {"q":"What is the next number: 5, 10, 20, 40, ?","choices":["60","70","80","100"],"answer":3},
    {"q":"Which word does not belong: Sapphire, Ruby, Emerald, Marble","choices":["Sapphire","Ruby","Emerald","Marble"],"answer":4},
    {"q":"If the pattern is +2, +4, +6, +8, what is the 6th term starting from 1?","choices":["21","23","25","27"],"answer":2},
    {"q":"Which of these is a perfect square?","choices":["45","49","51","57"],"answer":2},
    {"q":"Complete the analogy: Finger is to Hand as Leaf is to ?","choices":["Branch","Tree","Stem","Root"],"answer":2},
    {"q":"If 9 people sit around a round table, how many distinct seating arrangements (fixing rotations) are there?","choices":["40320","362880","4032","40320/9"],"answer":4},
    {"q":"Which number is divisible by 3?","choices":["1001","1002","1004","1007"],"answer":2},
    {"q":"Which word best completes: He was known for his ______ honesty.","choices":["dubious","notorious","unwavering","fleeting"],"answer":3},
    {"q":"If you mix red and blue paint, what color do you get?","choices":["Green","Purple","Orange","Brown"],"answer":2},
    {"q":"Which of these is an anagram of 'REACT'?","choices":["CATER","TRACE","CRATE","All of the above"],"answer":4},
    {"q":"What is 7 squared minus 10?","choices":["39","40","49","59"],"answer":1},
    {"q":"Which completes the sequence: 3, 6, 11, 18, 27, ?","choices":["36","38","39","40"],"answer":3},
    {"q":"If a train travels 60 miles in 1.5 hours, what is its average speed in mph?","choices":["30","40","45","50"],"answer":2},
    {"q":"Which is the odd one out: Mercury, Venus, Earth, Pluto","choices":["Mercury","Venus","Earth","Pluto"],"answer":4},
    {"q":"If every square is a rectangle, and some rectangles are rhombuses, which is true?","choices":["All rhombuses are squares","Some squares are rhombuses","No rhombuses are squares","All rectangles are rhombuses"],"answer":2},
    {"q":"Which number completes: 2, 5, 10, 17, 26, ?","choices":["35","37","38","39"],"answer":2},
    {"q":"Which word is closest in meaning to 'ephemeral'?","choices":["Permanent","Short-lived","Large","Complex"],"answer":2},
    {"q":"If you flip a fair coin three times, probability of exactly two heads is:","choices":["1/8","3/8","1/2","3/4"],"answer":2},
    {"q":"Which of these is a composite number?","choices":["13","17","21","29"],"answer":3},
    {"q":"Complete the analogy: Smile is to Happy as Frown is to ?","choices":["Sad","Angry","Confused","Surprised"],"answer":1},
    {"q":"If the code A=1, B=2, ... Z=26, what is the value of 'DOG'?","choices":["26","41","34","37"],"answer":3},
    {"q":"Which geometric shape has exactly 4 equal sides and 4 right angles?","choices":["Rhombus","Square","Rectangle","Parallelogram"],"answer":2},
    {"q":"Which number is the smallest?","choices":["0.125","1/6","0.2","1/8"],"answer":2},
    {"q":"If you read the word 'NOON' upside down on a calculator, it still reads 'NOON'. This is an example of:","choices":["Palindrome","Ambigram","Anagram","Oxymoron"],"answer":2},
    {"q":"Which completes the series: 100, 90, 81, 73, 66, ?","choices":["60","59","58","57"],"answer":2},
    {"q":"Which of these is a homophone pair?","choices":["Sea and See","Read and Read","Lead and Lead","Wind and Wind"],"answer":1},
    {"q":"If a rectangle has length 10 and width 4, its diagonal length is:","choices":["sqrt(116)","sqrt(104)","sqrt(120)","sqrt(100)"],"answer":1}
]

questions.extend(more_questions)

# -------------------------
# TTS utilities (no pip)
# -------------------------
def platform_tts_available():
    system = platform.system()
    if system == "Darwin":
        return shutil.which("say") is not None
    if system == "Windows":
        return True
    return shutil.which("espeak") is not None or shutil.which("spd-say") is not None

def speak_text_windows(text):
    esc = text.replace('"', '\\"')
    ps_cmd = (
        'Add-Type -AssemblyName System.Speech;'
        f'$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;'
        f'$s.Speak("{esc}");'
    )
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], check=False)
    except Exception:
        pass

def speak_text_mac(text):
    try:
        subprocess.run(["say", text], check=False)
    except Exception:
        pass

def speak_text_linux(text):
    if shutil.which("espeak"):
        try:
            subprocess.run(["espeak", text], check=False)
            return
        except Exception:
            pass
    if shutil.which("spd-say"):
        try:
            subprocess.run(["spd-say", text], check=False)
            return
        except Exception:
            pass
    return

def make_speaker(enabled=True):
    system = platform.system()
    def speak(text):
        if not enabled:
            return
        time.sleep(0.05)
        if system == "Darwin" and shutil.which("say"):
            speak_text_mac(text)
        elif system == "Windows":
            speak_text_windows(text)
        else:
            speak_text_linux(text)
    return speak

# -------------------------
# Quiz logic
# -------------------------
def ask_question(index, qdata, speak):
    speak(f"Question {index+1}. {qdata['q']}")
    print(f"\nQuestion {index+1}: {qdata['q']}")
    for i, choice in enumerate(qdata['choices'], start=1):
        speak(f"Option {i}. {choice}")
        print(f"  {i}. {choice}")
    while True:
        try:
            resp = input("Your answer (1-4): ").strip()
            if resp == "":
                print("Please enter a number 1-4.")
                continue
            val = int(resp)
            if 1 <= val <= 4:
                return val
            print("Enter a number between 1 and 4.")
        except ValueError:
            print("Invalid input. Enter a number between 1 and 4.")

def score_quiz(questions, speak):
    score = 0
    for i, q in enumerate(questions):
        ans = ask_question(i, q, speak)
        if ans == q["answer"]:
            speak("Correct.")
            score += 1
        else:
            correct_text = q["choices"][q["answer"] - 1]
            speak(f"Incorrect. The correct answer was {correct_text}.")
    return score

def estimate_iq(score, max_score):
    min_iq, max_iq = 70, 130
    iq = min_iq + (score / max_score) * (max_iq - min_iq)
    return round(iq)

def interpret_iq(iq):
    if iq < 85:
        return "Below Average"
    if iq < 100:
        return "Average Low"
    if iq < 115:
        return "Average High"
    if iq < 130:
        return "Above Average"
    return "High"

# -------------------------
# Main
# -------------------------
def main():
    parser = argparse.ArgumentParser(description="IQ-style quiz with randomized questions and built-in TTS (no pip).")
    parser.add_argument("--no-tts", action="store_true", help="Disable text-to-speech")
    parser.add_argument("--no-random", action="store_true", help="Disable randomizing question order")
    parser.add_argument("--num-questions", type=int, default=None, help="Number of questions to ask (optional)")
    args = parser.parse_args()

    tts_enabled = not args.no_tts
    randomize = not args.no_random
    requested_num = args.num_questions

    speak = make_speaker(enabled=tts_enabled)

    # Announce start
    speak("Welcome to the expanded IQ style quiz. T T S is enabled." if tts_enabled else "Welcome to the expanded IQ style quiz. T T S is disabled.")
    print("Welcome to the expanded IQ-style quiz.")
    if tts_enabled and not platform_tts_available():
        print("Note: No system TTS engine detected; falling back to text only.")
        speak = make_speaker(enabled=False)

    # Randomize questions by default
    if randomize:
        random.shuffle(questions)

    # Ask user how many questions if not provided on CLI
    total_available = len(questions)
    if requested_num is None:
        while True:
            try:
                resp = input(f"How many questions would you like? (1-{total_available}, press Enter for all): ").strip()
                if resp == "":
                    num_to_ask = total_available
                    break
                val = int(resp)
                if 1 <= val <= total_available:
                    num_to_ask = val
                    break
                print(f"Please enter a number between 1 and {total_available}.")
            except ValueError:
                print("Invalid input. Enter a valid integer.")
    else:
        # Validate CLI-provided number
        if requested_num < 1:
            print("Requested number must be at least 1. Using 1 question.")
            num_to_ask = 1
        elif requested_num > total_available:
            print(f"Requested number exceeds available questions ({total_available}). Using {total_available}.")
            num_to_ask = total_available
        else:
            num_to_ask = requested_num

    # Trim the questions list to the requested number (keeps current order or shuffled order)
    questions_to_ask = questions[:num_to_ask]

    score = score_quiz(questions_to_ask, speak)
    iq = estimate_iq(score, num_to_ask)
    label = interpret_iq(iq)

    result_text = f"Score: {score} out of {num_to_ask}. Estimated IQ: {iq}. Interpretation: {label}."
    print("\n--- Results ---")
    print(f"Score: {score} out of {num_to_ask}")
    print(f"Estimated IQ: {iq}")
    print(f"Interpretation: {label}")
    speak(result_text)

if __name__ == "__main__":
    main()
