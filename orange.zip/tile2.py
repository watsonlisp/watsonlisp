# scrabble_scorer_loop.py
SCRABBLE_SCORES = {
    **dict.fromkeys(list("AEILNORSTU"), 1),
    **dict.fromkeys(list("DG"), 2),
    **dict.fromkeys(list("BCMP"), 3),
    **dict.fromkeys(list("FHVWY"), 4),
    "K": 5,
    **dict.fromkeys(list("JX"), 8),
    **dict.fromkeys(list("QZ"), 10),
}

def score_text(text: str) -> int:
    """Return total Scrabble score for text and print per-letter breakdown."""
    text = text.upper()
    total = 0
    breakdown = []

    for ch in text:
        if ch.isalpha():
            val = SCRABBLE_SCORES.get(ch, 0)
            breakdown.append(f"{ch}: {val}")
            total += val

    print("Letter values:")
    print(", ".join(breakdown) if breakdown else "(no letters found)")
    print(f"Total score: {total}")
    return total

def main():
    print("Scrabble scorer — type a word or phrase. Type 'exit' or 'quit' to stop.")
    while True:
        user_input = input("\nEnter a word or phrase: ").strip()
        if not user_input:
            print("No input detected. Try again or type 'exit' to quit.")
            continue
        if user_input.lower() in ("exit", "quit"):
            print("Goodbye.")
            break
        score_text(user_input)

if __name__ == "__main__":
    main()
