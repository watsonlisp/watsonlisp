"""
Pure-Tkinter ASL slicer + viewer
Layout: first row has 6 columns, remaining rows have 5 columns (total 5 rows).
Save your sheet as 'asl_sheet.png' (PNG or GIF recommended) in the same folder and run.
"""

import tkinter as tk
from tkinter import messagebox
import string
import os

# CONFIG
SHEET_FILE = "asl_sheet.gif"   # your sheet (PNG or GIF recommended)
FIRST_ROW_COLS = 6
OTHER_ROW_COLS = 5
TOTAL_ROWS = 5                 # 1 first row + 4 other rows -> 6 + 4*5 = 26
LETTERS = list(string.ascii_uppercase)

class ASLSlicerViewer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ASL Viewer (first row 6, others 5)")
        self.geometry("1000x420")
        self.resizable(True, True)

        top = tk.Frame(self)
        top.pack(fill="x", padx=8, pady=6)

        tk.Label(top, text="Enter text:", font=("Arial", 14)).pack(side="left", padx=6)
        self.entry = tk.Entry(top, font=("Arial", 16))
        self.entry.pack(side="left", fill="x", expand=True, padx=6)
        tk.Button(top, text="Show ASL", command=self.show_asl).pack(side="left", padx=6)
        tk.Button(top, text="Clear", command=self.clear).pack(side="left", padx=6)

        self.canvas_frame = tk.Frame(self)
        self.canvas_frame.pack(fill="both", expand=True, padx=8, pady=8)

        # load sheet as PhotoImage
        if not os.path.exists(SHEET_FILE):
            messagebox.showerror("Missing file", f"Place your sheet image named '{SHEET_FILE}' in this folder.")
            self.destroy()
            return

        try:
            self.sheet = tk.PhotoImage(file=SHEET_FILE)
        except tk.TclError:
            messagebox.showerror("Load error", f"Could not load '{SHEET_FILE}'. Ensure it's PNG or GIF and not corrupted.")
            self.destroy()
            return

        # sheet dimensions
        self.sheet_w = self.sheet.width()
        self.sheet_h = self.sheet.height()

        # compute uniform row heights (distribute any remainder to the last row)
        base_row_h = self.sheet_h // TOTAL_ROWS
        self.row_heights = [base_row_h] * TOTAL_ROWS
        remainder_h = self.sheet_h - base_row_h * TOTAL_ROWS
        if remainder_h > 0:
            self.row_heights[-1] += remainder_h

        # precompute subimages for each letter
        self.letter_images = {}
        idx = 0
        y = 0
        for r in range(TOTAL_ROWS):
            cols = FIRST_ROW_COLS if r == 0 else OTHER_ROW_COLS
            # compute base cell width for this row; last cell absorbs remainder
            base_cell_w = self.sheet_w // cols
            x = 0
            for c in range(cols):
                if idx >= len(LETTERS):
                    break
                x1 = x
                # last cell in the row takes remaining pixels to avoid gaps
                if c == cols - 1:
                    x2 = self.sheet_w - 1
                else:
                    x2 = x1 + base_cell_w - 1
                y1 = y
                y2 = y + self.row_heights[r] - 1
                cell_w = x2 - x1 + 1
                cell_h = y2 - y1 + 1

                # create a new PhotoImage and copy the region into it
                try:
                    sub = tk.PhotoImage(width=cell_w, height=cell_h)
                    sub.tk.call(sub, 'copy', self.sheet, '-from', x1, y1, x2, y2, '-to', 0, 0)
                    self.letter_images[LETTERS[idx]] = sub
                except tk.TclError:
                    # copy failed for this region; skip storing
                    pass

                x = x2 + 1
                idx += 1
            y += self.row_heights[r]
            if idx >= len(LETTERS):
                break

        # sanity check
        if len(self.letter_images) < len(LETTERS):
            missing = [L for L in LETTERS if L not in self.letter_images]
            print("Warning: some letters were not sliced. Missing:", missing)

        # bind Enter key
        self.entry.bind("<Return>", lambda e: self.show_asl())

    def clear(self):
        self.entry.delete(0, tk.END)
        for w in self.canvas_frame.winfo_children():
            w.destroy()

    def show_asl(self):
        for w in self.canvas_frame.winfo_children():
            w.destroy()

        text = self.entry.get()
        if not text:
            return

        # horizontal scrollable canvas in case of long text
        canvas = tk.Canvas(self.canvas_frame, height=max(self.row_heights) + 20)
        hbar = tk.Scrollbar(self.canvas_frame, orient="horizontal", command=canvas.xview)
        canvas.configure(xscrollcommand=hbar.set)
        hbar.pack(side="bottom", fill="x")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas)
        canvas.create_window((0,0), window=inner, anchor="nw")

        for ch in text:
            if not ch.isalpha():
                lbl = tk.Label(inner, text=ch, width=6, height=4, bg="#eee", font=("Arial", 14))
                lbl.pack(side="left", padx=4, pady=4)
                continue

            key = ch.upper()
            img = self.letter_images.get(key)
            if img:
                lbl = tk.Label(inner, image=img)
                lbl.image = img
                lbl.pack(side="left", padx=4, pady=4)
            else:
                lbl = tk.Label(inner, text=key, width=6, height=4, bg="#ccc", font=("Arial", 14))
                lbl.pack(side="left", padx=4, pady=4)

        # update scroll region
        inner.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))

if __name__ == "__main__":
    app = ASLSlicerViewer()
    if app.winfo_exists():
        app.mainloop()
