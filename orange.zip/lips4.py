import tkinter as tk
from tkinter import ttk
import os

# -------------------------
# Configuration
# -------------------------
LETTER_TO_GIF = {
    "A": "A.gif", "B": "B.gif", "C": "C.gif", "D": "D.gif", "E": "E.gif",
    "F": "F.gif", "G": "G.gif", "H": "H.gif", "I": "I.gif", "J": "J.gif",
    "K": "K.gif", "L": "L.gif", "M": "M.gif", "N": "N.gif", "O": "O.gif",
    "P": "P.gif", "Q": "Q.gif", "R": "R.gif", "S": "S.gif", "T": "T.gif",
    "U": "U.gif", "V": "V.gif", "W": "W.gif", "X": "X.gif", "Y": "Y.gif",
    "Z": "Z.gif",
}
GIF_FOLDER = ""  # e.g., "mouth_gifs"

# -------------------------
# GIF loader (extract frames)
# -------------------------
def load_gif_frames(path):
    if not os.path.exists(path):
        return []

    frames = []
    idx = 0
    try:
        while True:
            frame = tk.PhotoImage(file=path, format=f"gif -index {idx}")
            frames.append(frame)
            idx += 1
    except tk.TclError:
        pass
    return frames

# -------------------------
# Placeholder drawing
# -------------------------
def draw_placeholder(canvas, letter):
    canvas.delete("all")
    canvas.create_rectangle(5, 5, 115, 115, fill="#f0f0f0", outline="#888")
    canvas.create_text(60, 40, text=letter, font=("Arial", 20, "bold"))
    canvas.create_oval(30, 60, 90, 90, outline="black", width=3)
    canvas.create_text(60, 100, text="(missing GIF)", font=("Arial", 8))

# -------------------------
# GUI Application
# -------------------------
class GifMouthViewer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Letter → GIF Viewer")
        # wider window
        self.geometry("1280x360")
        self.resizable(True, True)

        self.input_var = tk.StringVar()

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=8)

        ttk.Label(top, text="Enter text:").pack(side="left")
        entry = ttk.Entry(top, textvariable=self.input_var, width=40)
        entry.pack(side="left", padx=6)
        entry.bind("<Return>", lambda e: self.show_shapes())

        ttk.Button(top, text="Show GIFs", command=self.show_shapes).pack(side="left", padx=6)
        ttk.Button(top, text="Clear", command=self.clear).pack(side="left")

        # -------------------------
        # Scrollable container setup
        # -------------------------
        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True, padx=10, pady=6)

        # Canvas that will hold an inner frame
        self._canvas = tk.Canvas(outer, borderwidth=0, highlightthickness=0)
        self._h_scroll = ttk.Scrollbar(outer, orient="horizontal", command=self._canvas.xview)
        self._v_scroll = ttk.Scrollbar(outer, orient="vertical", command=self._canvas.yview)
        self._canvas.configure(xscrollcommand=self._h_scroll.set, yscrollcommand=self._v_scroll.set)

        # Layout: canvas center, horizontal scrollbar bottom, vertical scrollbar right
        self._canvas.grid(row=0, column=0, sticky="nsew")
        self._h_scroll.grid(row=1, column=0, sticky="ew")
        self._v_scroll.grid(row=0, column=1, sticky="ns")
        outer.rowconfigure(0, weight=1)
        outer.columnconfigure(0, weight=1)

        # Inner frame inside canvas where widgets are packed
        self.inner_frame = ttk.Frame(self._canvas)
        self._inner_id = self._canvas.create_window((0, 0), window=self.inner_frame, anchor="nw")

        # Bind configure events to update scrollregion
        self.inner_frame.bind("<Configure>", self._on_frame_configure)
        self._canvas.bind("<Configure>", self._on_canvas_configure)

        # Mouse wheel support
        # Windows/macOS: <MouseWheel>, Linux: Button-4/5
        self._canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self._canvas.bind_all("<Button-4>", self._on_mousewheel)
        self._canvas.bind_all("<Button-5>", self._on_mousewheel)

        # keep references to frames and after ids to manage animations
        self._display_items = []  # list of dicts: { 'frames': [...], 'label': widget, 'idx': int, 'after_id': id }

    def _on_frame_configure(self, event=None):
        # update scrollregion to encompass inner frame
        self._canvas.configure(scrollregion=self._canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        # Match inner frame height to canvas height so the inner frame can expand horizontally.
        # Do NOT force inner frame width to canvas width; that allows horizontal scrolling.
        canvas_height = event.height
        try:
            self._canvas.itemconfig(self._inner_id, height=canvas_height)
        except Exception:
            pass

    def _on_mousewheel(self, event):
        # Cross-platform normalization
        num = getattr(event, "num", None)
        delta = 0
        if num == 4:      # Linux scroll up
            delta = -1
        elif num == 5:    # Linux scroll down
            delta = 1
        else:
            # Windows: event.delta is multiple of 120; macOS may be smaller
            d = getattr(event, "delta", 0)
            if d:
                delta = -1 * int(d / 120)

        # If Shift is held, scroll horizontally
        # Shift mask differs by platform; check common bit for Shift (0x0001)
        if (getattr(event, "state", 0) & 0x0001) != 0:
            self._canvas.xview_scroll(delta, "units")
        else:
            self._canvas.yview_scroll(delta, "units")

    def clear(self):
        # destroy children of inner_frame
        for widget in self.inner_frame.winfo_children():
            widget.destroy()
        # cancel any scheduled animation callbacks
        for item in self._display_items:
            if item.get("after_id"):
                try:
                    self.after_cancel(item["after_id"])
                except Exception:
                    pass
        self._display_items.clear()
        # reset scrollregion
        self._canvas.configure(scrollregion=self._canvas.bbox("all"))

    def show_shapes(self):
        self.clear()
        text = self.input_var.get().upper()

        for ch in text:
            if not ch.isalpha():
                continue

            gif_name = LETTER_TO_GIF.get(ch, f"{ch}.gif")
            path = os.path.join(GIF_FOLDER, gif_name) if GIF_FOLDER else gif_name
            frames = load_gif_frames(path)

            container = ttk.Frame(self.inner_frame, width=120)
            container.pack(side="left", padx=6, pady=6)

            if frames:
                lbl = ttk.Label(container)
                lbl.pack()
                item = {"frames": frames, "label": lbl, "idx": 0, "after_id": None}
                lbl.configure(image=frames[0])
                if len(frames) > 1:
                    self._animate(item)
                self._display_items.append(item)
            else:
                canvas = tk.Canvas(container, width=120, height=120, bg="#ddd", highlightthickness=0)
                canvas.pack()
                draw_placeholder(canvas, ch)

            ttk.Label(container, text=f"{ch}", anchor="center").pack(pady=4)

        # ensure scrollregion updated after adding widgets
        self._canvas.update_idletasks()
        self._canvas.configure(scrollregion=self._canvas.bbox("all"))

    def _animate(self, item):
        frames = item["frames"]
        lbl = item["label"]
        idx = (item["idx"] + 1) % len(frames)
        item["idx"] = idx
        lbl.configure(image=frames[idx])
        after_id = self.after(100, lambda: self._animate(item))
        item["after_id"] = after_id

if __name__ == "__main__":
    app = GifMouthViewer()
    app.mainloop()
