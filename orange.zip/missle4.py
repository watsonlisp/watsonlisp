import tkinter as tk
import random
import math
import time

# --- Configurable parameters (pixels per second) ---
WIDTH, HEIGHT = 900, 650
CITY_COUNT = 6
BASE_COUNT = 3

ENEMY_SPAWN_MS = 1400
INTERCEPTOR_SPEED = 900.0      # pixels per second (tweak to taste)
ENEMY_MIN_SPEED = 80.0         # pixels per second
ENEMY_MAX_SPEED = 140.0        # pixels per second

EXPLOSION_RADIUS = 55
EXPLOSION_DURATION = 0.45      # seconds

MAX_TRAIL_POINTS = 150
STAR_COUNT = 30

def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])

class City:
    def __init__(self, canvas, x):
        self.canvas = canvas
        self.x = x
        self.y = HEIGHT - 30
        self.alive = True
    def draw(self):
        color = "#c8c8ff" if self.alive else "#505050"
        self.canvas.create_rectangle(self.x-25, self.y-12, self.x+25, self.y+12, fill=color, outline="")
        self.canvas.create_rectangle(self.x-6, self.y-28, self.x+6, self.y-12, fill="#787878", outline="")

class Base:
    def __init__(self, canvas, x):
        self.canvas = canvas
        self.x = x
        self.y = HEIGHT - 8
    def draw(self):
        self.canvas.create_rectangle(self.x-18, self.y-8, self.x+18, self.y+8, fill="#9fb4ff", outline="")
        self.canvas.create_rectangle(self.x-4, self.y-28, self.x+4, self.y-8, fill="#6f8fbf", outline="")

class Enemy:
    def __init__(self, canvas, start, target, speed):
        self.canvas = canvas
        self.x, self.y = start
        self.tx, self.ty = target
        self.speed = speed
        ang = math.atan2(self.ty - self.y, self.tx - self.x)
        self.vx = math.cos(ang) * self.speed
        self.vy = math.sin(ang) * self.speed
        self.alive = True
        self.trail = []
    def update(self, dt):
        if not self.alive:
            return
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.trail.append((self.x, self.y, time.time()))
        if len(self.trail) > MAX_TRAIL_POINTS:
            self.trail.pop(0)
        if self.y >= self.ty:
            self.alive = False
    def draw(self):
        for (tx, ty, _) in self.trail:
            self.canvas.create_oval(tx-2, ty-2, tx+2, ty+2, fill="#ff8a4a", outline="")
        if self.alive:
            self.canvas.create_line(self.x, self.y, self.x - self.vx * 0.03, self.y - self.vy * 0.03, fill="#ff783c", width=2)
            self.canvas.create_oval(self.x-3, self.y-3, self.x+3, self.y+3, fill="#ffc850", outline="")

class Interceptor:
    def __init__(self, canvas, start, target):
        self.canvas = canvas
        self.x, self.y = start
        self.tx, self.ty = target
        ang = math.atan2(self.ty - self.y, self.tx - self.x)
        self.vx = math.cos(ang) * INTERCEPTOR_SPEED
        self.vy = math.sin(ang) * INTERCEPTOR_SPEED
        self.reached = False
    def update(self, dt):
        if self.reached:
            return
        self.x += self.vx * dt
        self.y += self.vy * dt
        # threshold based on speed (small fraction of speed) but at least a few pixels
        threshold = max(6.0, INTERCEPTOR_SPEED * 0.02)
        if dist((self.x, self.y), (self.tx, self.ty)) < threshold:
            self.reached = True
    def draw(self):
        self.canvas.create_oval(self.x-4, self.y-4, self.x+4, self.y+4, fill="#b4e0ff", outline="")

class Explosion:
    def __init__(self, canvas, pos):
        self.canvas = canvas
        self.x, self.y = pos
        self.start = time.time()
        self.alive = True
    def update(self):
        if time.time() - self.start > EXPLOSION_DURATION:
            self.alive = False
    def draw(self):
        t = (time.time() - self.start) / EXPLOSION_DURATION
        r = int(EXPLOSION_RADIUS * (0.6 + 0.8 * min(1, t)))
        self.canvas.create_oval(self.x-r, self.y-r, self.x+r, self.y+r, fill="#ffc850", outline="")

class Game:
    def __init__(self, root):
        self.root = root
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="#0c0c1c")
        self.canvas.pack()
        gap = WIDTH // (CITY_COUNT + 1)
        self.cities = [City(self.canvas, (i+1)*gap) for i in range(CITY_COUNT)]
        base_gap = WIDTH // (BASE_COUNT + 1)
        self.bases = [Base(self.canvas, (i+1)*base_gap) for i in range(BASE_COUNT)]
        self.enemies = []
        self.interceptors = []
        self.explosions = []
        self.score = 0
        self.level = 1
        self.last_spawn = time.time()
        self.spawn_interval = ENEMY_SPAWN_MS / 1000.0
        self.running = True
        self.mouse_x = WIDTH // 2
        self.mouse_y = HEIGHT // 2
        self.last_frame = time.time()
        self.canvas.bind("<Motion>", self.on_mouse_move)
        self.canvas.bind("<Button-1>", self.on_click)
        self.root.bind("r", self.restart)
        self.loop()

    def on_mouse_move(self, event):
        self.mouse_x, self.mouse_y = event.x, event.y

    def on_click(self, event):
        # fire directly to the exact mouse coordinates clicked
        bx = min(self.bases, key=lambda b: abs(b.x - event.x)).x
        start = (bx, HEIGHT - 10)
        target = (event.x, event.y)
        self.interceptors.append(Interceptor(self.canvas, start, target))

    def spawn_enemy(self):
        sx = random.randint(20, WIDTH-20)
        start = (sx, -10)
        alive = [c for c in self.cities if c.alive]
        if alive and random.random() < 0.7:
            target_city = random.choice(alive)
            tx = target_city.x + random.randint(-18, 18)
            ty = target_city.y - 6
        else:
            tx = random.randint(40, WIDTH-40)
            ty = HEIGHT - random.randint(10, 40)
        speed = random.uniform(ENEMY_MIN_SPEED + self.level * 0.08, ENEMY_MAX_SPEED + self.level * 0.12)
        self.enemies.append(Enemy(self.canvas, start, (tx, ty), speed))

    def loop(self):
        now = time.time()
        dt = now - self.last_frame
        # clamp dt to avoid huge jumps if the window was paused
        dt = min(dt, 0.05)
        self.last_frame = now

        if now - self.last_spawn > self.spawn_interval:
            self.spawn_enemy()
            self.last_spawn = now
            if random.random() < 0.12:
                self.level += 1
                self.spawn_interval = max(0.3, ENEMY_SPAWN_MS / 1000.0 - self.level * 0.06)

        self.canvas.delete("all")
        # stars (lightweight)
        for _ in range(STAR_COUNT):
            x = random.randint(0, WIDTH); y = random.randint(0, HEIGHT//2)
            self.canvas.create_oval(x, y, x+1, y+1, fill="#141424", outline="")

        # draw cities and bases
        for c in self.cities:
            c.draw()
        for b in self.bases:
            b.draw()

        # aiming preview from nearest base to current mouse position
        nearest_base = min(self.bases, key=lambda b: abs(b.x - self.mouse_x))
        self.canvas.create_line(nearest_base.x, HEIGHT-10, self.mouse_x, self.mouse_y, fill="#88c0ff", dash=(4,6))

        # update enemies
        for e in list(self.enemies):
            e.update(dt)
            e.draw()
            if not e.alive:
                if e.ty >= HEIGHT - 80:
                    nearest = min(self.cities, key=lambda cc: abs(cc.x - e.tx))
                    if nearest.alive:
                        nearest.alive = False
                        self.explosions.append(Explosion(self.canvas, (nearest.x, nearest.y - 6)))
                try:
                    self.enemies.remove(e)
                except ValueError:
                    pass

        # update interceptors
        for it in list(self.interceptors):
            it.update(dt)
            it.draw()
            if it.reached:
                self.explosions.append(Explosion(self.canvas, (it.x, it.y)))
                try:
                    self.interceptors.remove(it)
                except ValueError:
                    pass

        # explosions and collisions
        for ex in list(self.explosions):
            ex.update()
            ex.draw()
            for em in list(self.enemies):
                if dist((ex.x, ex.y), (em.x, em.y)) <= EXPLOSION_RADIUS:
                    try:
                        self.enemies.remove(em)
                        self.score += 100
                    except ValueError:
                        pass
            if not ex.alive:
                try:
                    self.explosions.remove(ex)
                except ValueError:
                    pass

        # HUD
        self.canvas.create_text(10, 10, anchor="nw", text=f"Score: {self.score}  Level: {self.level}", fill="#dcdcdc", font=("Arial", 14))
        self.canvas.create_text(10, 34, anchor="nw", text="Left-click to fire to the mouse coordinates. Press R to restart.", fill="#bdbdbd", font=("Arial", 10))

        if not any(c.alive for c in self.cities):
            self.canvas.create_text(WIDTH//2, HEIGHT//2, text="GAME OVER\nPress R to restart", fill="#ff5050", font=("Arial", 28))
            self.running = False

        self.root.update_idletasks()
        self.root.update()
        if self.running:
            self.root.after(int(1000/60), self.loop)

    def restart(self, event=None):
        self.canvas.delete("all")
        gap = WIDTH // (CITY_COUNT + 1)
        self.cities = [City(self.canvas, (i+1)*gap) for i in range(CITY_COUNT)]
        base_gap = WIDTH // (BASE_COUNT + 1)
        self.bases = [Base(self.canvas, (i+1)*base_gap) for i in range(BASE_COUNT)]
        self.enemies.clear(); self.interceptors.clear(); self.explosions.clear()
        self.score = 0; self.level = 1
        self.last_spawn = time.time()
        self.spawn_interval = ENEMY_SPAWN_MS / 1000.0
        self.running = True
        self.last_frame = time.time()
        self.loop()

if __name__ == "__main__":
    root = tk.Tk(); root.title("Missile Command — fire to mouse coordinates")
    Game(root)
    root.mainloop()
