#!/usr/bin/env python3
"""
88-Key Piano with a 16-step sequencer (pure Python, no pip).
Run: python piano_88_sequencer.py
"""

import math
import os
import sys
import tempfile
import threading
import wave
import struct
import platform
import subprocess
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox
import json
import time

# -----------------------
# Audio generation / playback (same approach as before)
# -----------------------
SAMPLE_RATE = 44100
DURATION = 0.9  # seconds per note
SYSTEM = platform.system().lower()

MIDI_START = 21
NUM_KEYS = 88

NOTE_NAMES_SHARP = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

def midi_to_freq(m):
    return 440.0 * (2 ** ((m - 69) / 12.0))

keys = []
for i in range(NUM_KEYS):
    midi = MIDI_START + i
    octave = (midi // 12) - 1
    name = NOTE_NAMES_SHARP[midi % 12] + str(octave)
    freq = midi_to_freq(midi)
    keys.append({'midi': midi, 'name': name, 'freq': freq})

tmpdir = tempfile.mkdtemp(prefix='piano88_')
wav_paths = {}

def make_sine_frames(freq, duration=DURATION, sample_rate=SAMPLE_RATE):
    n_samples = int(sample_rate * duration)
    attack = int(0.01 * sample_rate)
    release = int(0.05 * sample_rate)
    frames = bytearray()
    for i in range(n_samples):
        t = i / sample_rate
        value = 0.55 * math.sin(2 * math.pi * freq * t) + 0.12 * math.sin(2 * math.pi * freq * 2 * t)
        if i < attack:
            env = i / attack
        elif i > n_samples - release:
            env = (n_samples - i) / release
        else:
            env = 1.0
        sample = int(32767 * value * env)
        frames += struct.pack('<h', max(-32768, min(32767, sample)))
    return bytes(frames)

def write_wav(path, frames, sample_rate=SAMPLE_RATE):
    with wave.open(path, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(frames)

print("Generating audio for 88 keys (may take a few seconds)...")
for k in keys:
    name = k['name']
    freq = k['freq']
    path = os.path.join(tmpdir, f"{name}.wav")
    frames = make_sine_frames(freq)
    write_wav(path, frames)
    wav_paths[name] = path
print("Audio generation complete.")

def play_wav_path(path):
    if SYSTEM.startswith('win'):
        try:
            import winsound
            winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
            return
        except Exception:
            pass
    if SYSTEM.startswith('darwin') and shutil.which('afplay'):
        subprocess.Popen(['afplay', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return
    if SYSTEM.startswith('linux'):
        if shutil.which('aplay'):
            subprocess.Popen(['aplay', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        if shutil.which('paplay'):
            subprocess.Popen(['paplay', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
    try:
        subprocess.Popen(['aplay', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

def play_note_async(name):
    path = wav_paths.get(name)
    if not path:
        return
    t = threading.Thread(target=play_wav_path, args=(path,), daemon=True)
    t.start()

# -----------------------
# Sequencer data model
# -----------------------
NUM_STEPS = 16
# sequence: list of sets; each set contains note names scheduled at that step
sequence = [set() for _ in range(NUM_STEPS)]
is_playing = False
play_thread = None
play_lock = threading.Lock()
tempo_bpm = 120

# Selected note for editing the sequence (None if not selected)
selected_note = None

# -----------------------
# GUI
# -----------------------
root = tk.Tk()
root.title("88-Key Piano with 16-Step Sequencer")

# Top: sequencer controls
top_frame = tk.Frame(root)
top_frame.pack(side='top', fill='x', padx=6, pady=6)

# Tempo slider
tempo_label = tk.Label(top_frame, text="Tempo (BPM):")
tempo_label.pack(side='left')
tempo_var = tk.IntVar(value=120)
tempo_scale = tk.Scale(top_frame, from_=40, to=240, orient='horizontal', variable=tempo_var, length=220)
tempo_scale.pack(side='left', padx=6)

# Play / Stop / Clear / Save / Load
def start_sequencer():
    global is_playing, play_thread
    with play_lock:
        if is_playing:
            return
        is_playing = True
    play_thread = threading.Thread(target=sequencer_loop, daemon=True)
    play_thread.start()
    play_button.config(state='disabled')
    stop_button.config(state='normal')

def stop_sequencer():
    global is_playing
    with play_lock:
        is_playing = False
    play_button.config(state='normal')
    stop_button.config(state='disabled')

def clear_sequence():
    global sequence
    sequence = [set() for _ in range(NUM_STEPS)]
    refresh_step_buttons()

def save_sequence():
    path = filedialog.asksaveasfilename(defaultextension='.json', filetypes=[('JSON','*.json')])
    if not path:
        return
    data = {
        'tempo': tempo_var.get(),
        'steps': [sorted(list(s)) for s in sequence]
    }
    try:
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        messagebox.showerror("Save error", str(e))

def load_sequence():
    global sequence
    path = filedialog.askopenfilename(filetypes=[('JSON','*.json')])
    if not path:
        return
    try:
        with open(path, 'r') as f:
            data = json.load(f)
        loaded_steps = data.get('steps', [])
        new_seq = [set(s) for s in loaded_steps]
        # normalize length
        if len(new_seq) < NUM_STEPS:
            new_seq += [set() for _ in range(NUM_STEPS - len(new_seq))]
        sequence = new_seq[:NUM_STEPS]
        tempo_var.set(data.get('tempo', tempo_var.get()))
        refresh_step_buttons()
    except Exception as e:
        messagebox.showerror("Load error", str(e))

play_button = tk.Button(top_frame, text="Play", command=start_sequencer)
play_button.pack(side='left', padx=4)
stop_button = tk.Button(top_frame, text="Stop", command=stop_sequencer, state='disabled')
stop_button.pack(side='left', padx=4)
clear_button = tk.Button(top_frame, text="Clear", command=clear_sequence)
clear_button.pack(side='left', padx=4)
save_button = tk.Button(top_frame, text="Save", command=save_sequence)
save_button.pack(side='left', padx=4)
load_button = tk.Button(top_frame, text="Load", command=load_sequence)
load_button.pack(side='left', padx=4)

# Sequencer grid frame
seq_frame = tk.Frame(root)
seq_frame.pack(side='top', fill='x', padx=6, pady=6)

step_buttons = []  # list of lists: rows x steps (we'll show a compact set of rows for editing)
# For usability, show a vertical slice of notes (e.g., 12 notes around middle C) for quick sequencing,
# but allow selecting any key from the full 88-key keyboard to edit the sequence.
# We'll display 12 rows centered on middle C (C4..B4) by default.
DISPLAY_ROWS = 12
# find index of C4 in keys
center_index = next((i for i,k in enumerate(keys) if k['name'].startswith('C4')), len(keys)//2)
start_row_index = max(0, center_index - DISPLAY_ROWS//2)
display_notes = [k['name'] for k in keys[start_row_index:start_row_index + DISPLAY_ROWS]]

# Label for selected note
selected_label_var = tk.StringVar(value="Selected note: None")
selected_label = tk.Label(seq_frame, textvariable=selected_label_var)
selected_label.grid(row=0, column=0, columnspan=NUM_STEPS+1, sticky='w')

# Build grid: rows = display_notes, columns = steps
for r, note in enumerate(display_notes):
    row_buttons = []
    lbl = tk.Label(seq_frame, text=note, width=6)
    lbl.grid(row=r+1, column=0, padx=2, pady=2)
    for s in range(NUM_STEPS):
        b = tk.Button(seq_frame, text=str(s+1), width=3, relief='raised')
        b.grid(row=r+1, column=s+1, padx=1, pady=1)
        # bind with closure
        def make_toggle(n, step, btn):
            def toggle():
                # toggle note in sequence[step]
                if n in sequence[step]:
                    sequence[step].remove(n)
                else:
                    sequence[step].add(n)
                refresh_step_buttons()
            return toggle
        b.config(command=make_toggle(note, s, b))
        row_buttons.append(b)
    step_buttons.append(row_buttons)

def refresh_step_buttons():
    # update button appearance for displayed notes
    for r, note in enumerate(display_notes):
        for s in range(NUM_STEPS):
            btn = step_buttons[r][s]
            if note in sequence[s]:
                btn.config(relief='sunken', bg='lightgreen')
            else:
                btn.config(relief='raised', bg='SystemButtonFace')

# -----------------------
# Sequencer playback loop
# -----------------------
def sequencer_loop():
    global is_playing
    step = 0
    while True:
        with play_lock:
            if not is_playing:
                break
        bpm = tempo_var.get()
        interval = 60.0 / bpm / 4.0  # 16th-note steps (4 steps per beat)
        # play all notes scheduled at this step
        notes = list(sequence[step])
        for n in notes:
            play_note_async(n)
        # visual step indicator: highlight column
        highlight_step(step)
        time.sleep(interval)
        unhighlight_step(step)
        step = (step + 1) % NUM_STEPS

# Visual step indicator helpers
highlight_rects = []
def highlight_step(step_index):
    # draw a translucent rectangle over the step column in the sequencer grid
    for r in range(len(display_notes)):
        btn = step_buttons[r][step_index]
        btn.config(bg='orange')
def unhighlight_step(step_index):
    for r, note in enumerate(display_notes):
        btn = step_buttons[r][step_index]
        if note in sequence[step_index]:
            btn.config(bg='lightgreen')
        else:
            btn.config(bg='SystemButtonFace')

# -----------------------
# Piano keyboard UI (scrollable)
# -----------------------
piano_frame = tk.Frame(root)
piano_frame.pack(side='top', fill='both', expand=True, padx=6, pady=6)

h_scroll = tk.Scrollbar(piano_frame, orient='horizontal')
h_scroll.pack(side='bottom', fill='x')

canvas = tk.Canvas(piano_frame, height=260, bg='gray80', xscrollcommand=h_scroll.set)
canvas.pack(side='top', fill='both', expand=True)
h_scroll.config(command=canvas.xview)

white_key_width = 24
white_key_height = 220
black_key_width = int(white_key_width * 0.6)
black_key_height = 140

white_positions = []
black_positions = []

x = 0
for k in keys:
    note = k['name']
    base = note[:-1]
    if '#' in base:
        bx = x - black_key_width // 2
        black_positions.append((bx, note))
    else:
        white_positions.append((x, note))
        x += white_key_width

total_width = max(1000, x + 20)
canvas.config(scrollregion=(0,0,total_width,260), width=min(total_width, 1000))

white_rects = {}
for pos, name in white_positions:
    rect = canvas.create_rectangle(pos, 0, pos + white_key_width, white_key_height, fill='white', outline='black')
    text = canvas.create_text(pos + white_key_width//2, white_key_height - 20, text=name, font=('Arial',8))
    overlay = canvas.create_rectangle(pos, 0, pos + white_key_width, white_key_height, fill='', outline='')
    # bind click: play and select for sequencing
    def make_on_click(n):
        def on_click(e=None):
            global selected_note
            selected_note = n
            selected_label_var.set(f"Selected note: {n}")
            play_note_async(n)
        return on_click
    canvas.tag_bind(overlay, '<Button-1>', make_on_click(name))
    white_rects[name] = rect

for pos, name in black_positions:
    if pos < 0 or pos + black_key_width > total_width:
        continue
    rect = canvas.create_rectangle(pos, 0, pos + black_key_width, black_key_height, fill='black', outline='black')
    canvas.tag_bind(rect, '<Button-1>', make_on_click(name))
    canvas.create_text(pos + black_key_width//2, black_key_height - 20, text=name, fill='white', font=('Arial',7))

# Keyboard mapping for quick play (middle region)
KEY_MAP = {
    'z':'C4','s':'C#4','x':'D4','d':'D#4','c':'E4','v':'F4','g':'F#4','b':'G4','h':'G#4','n':'A4','j':'A#4','m':'B4',',':'C5'
}
def on_key(e):
    k = e.char.lower()
    if k in KEY_MAP:
        name = KEY_MAP[k]
        # select note for sequencing and play
        global selected_note
        selected_note = name
        selected_label_var.set(f"Selected note: {name}")
        play_note_async(name)

root.bind('<Key>', on_key)

# Instruction label
instr = tk.Label(root, text="Click keys to play. Select a key, then click steps to add/remove it from the sequence.")
instr.pack(side='top', pady=4)

# -----------------------
# Cleanup on exit
# -----------------------
def on_close():
    try:
        stop_sequencer()
        # remove generated wav files and temp dir
        for p in wav_paths.values():
            try:
                os.remove(p)
            except Exception:
                pass
        try:
            os.rmdir(tmpdir)
        except Exception:
            pass
    finally:
        root.destroy()

root.protocol("WM_DELETE_WINDOW", on_close)

# -----------------------
# Start GUI
# -----------------------
refresh_step_buttons()
root.mainloop()
