"""
Home Remedies Finder — Full updated version
- Large REMEDIES dictionary with many symptoms and practical tips
- SYNONYMS for better matching
- Fuzzy matching using difflib
- Severity hints and RED_FLAGS for urgent signs
- Repeats until user types 'exit', 'quit', or 'q'
- Graceful handling of KeyboardInterrupt
Disclaimer: This tool provides general self-care ideas and is NOT medical advice.
"""

import difflib

REMEDIES = {
    "sore throat": [
        "Gargle warm salt water (1/4-1/2 tsp salt in 8 oz water) several times daily",
        "Warm tea with honey and lemon; honey soothes throat"
    ],
    "cough": [
        "Honey for cough (adults and children over 1 year): 1 tsp before bed",
        "Steam inhalation or humidifier to ease airway irritation; stay hydrated"
    ],
    "congestion": [
        "Saline nasal rinse or spray; steam inhalation",
        "Elevate head while sleeping; warm broths and extra fluids"
    ],
    "cold": [
        "Rest, fluids, warm broths, humidified air, throat lozenges",
        "Vitamin C and zinc may slightly shorten duration for some people"
    ],
    "fever": [
        "Rest, fluids, light clothing; monitor temperature regularly",
        "Use fever-reducing medication only per label or clinician advice"
    ],
    "headache": [
        "Rest in a dark, quiet room; cold pack to forehead",
        "Hydration; small amount of caffeine can help some tension headaches"
    ],
    "migraine": [
        "Rest in a dark, quiet room; cold compress to the head",
        "Hydration and avoidance of known triggers; seek care if severe or new"
    ],
    "nausea": [
        "Sip clear fluids slowly; try ginger tea or candied ginger",
        "BRAT diet (bananas, rice, applesauce, toast) until settled"
    ],
    "vomiting": [
        "Small sips of oral rehydration solution; avoid solid food until settled",
        "Rest and avoid strong odors; seek care if persistent or bloody"
    ],
    "diarrhea": [
        "Oral rehydration solutions; small frequent sips of clear fluids",
        "BRAT diet; avoid dairy and high-fat foods until recovered"
    ],
    "constipation": [
        "Increase fiber (prunes, whole grains, psyllium), drink more water",
        "Gentle exercise and warm liquids like prune juice"
    ],
    "bloating/gas": [
        "Peppermint tea; walk after meals; avoid gas-producing foods",
        "Eat slowly and avoid carbonated drinks"
    ],
    "acid reflux": [
        "Elevate head of bed; avoid late meals and trigger foods",
        "Smaller meals and antacids per label if appropriate"
    ],
    "stomach cramp": [
        "Warm compress on abdomen; sip clear fluids",
        "Gentle walking and rest; avoid heavy meals"
    ],
    "tummy ache": [
        "Ginger; BRAT diet; rest; avoid greasy or spicy foods"
    ],
    "earache": [
        "Warm compress to the affected ear; lie with ear up",
        "Avoid inserting objects into the ear; seek care if severe or drainage"
    ],
    "toothache": [
        "Rinse with warm salt water; cold compress for swelling",
        "See a dentist if pain persists or there is fever"
    ],
    "minor cut": [
        "Clean with running water, apply pressure to stop bleeding, cover with sterile dressing",
        "Watch for signs of infection: increasing redness, warmth, pus"
    ],
    "minor burn": [
        "Cool running water for 10–20 minutes; cover with sterile non-adhesive dressing",
        "Avoid ice directly on skin and do not break blisters"
    ],
    "sprain": [
        "RICE: rest, ice, compression, elevation for first 48–72 hours",
        "Gentle range-of-motion after acute pain decreases"
    ],
    "muscle strain": [
        "Ice initially, then heat after 48 hours; gentle stretching",
        "Over-the-counter pain relief per label if appropriate"
    ],
    "sore muscles after exercise": [
        "Light activity, stretching, warm bath, and hydration",
        "Massage or foam rolling as tolerated"
    ],
    "menstrual cramps": [
        "Heat pad on lower abdomen; ibuprofen if appropriate",
        "Gentle exercise, yoga, or stretching"
    ],
    "insomnia": [
        "Reduce screens before bed; maintain consistent sleep schedule",
        "Warm bath, chamomile tea, and a dark, cool bedroom"
    ],
    "anxiety (mild)": [
        "Deep breathing, grounding exercises, short walk, limit caffeine",
        "Progressive muscle relaxation or brief mindfulness practice"
    ],
    "acne": [
        "Gentle cleansing twice daily; spot treatment with benzoyl peroxide",
        "Avoid picking; patch test tea tree oil before use"
    ],
    "sunburn": [
        "Cool compresses; aloe vera gel; hydration; avoid further sun",
        "Loose clothing and avoid harsh soaps"
    ],
    "allergic rhinitis": [
        "Saline nasal rinse; remove triggers (pets, dust); cool compress for itchy eyes",
        "Consider OTC antihistamine per label if appropriate"
    ],
    "hives": [
        "Cool compress; OTC antihistamine per label for itching",
        "Avoid known triggers and seek care if swelling of face or throat occurs"
    ],
    "dehydration (mild)": [
        "Oral rehydration solutions or electrolyte drinks; small frequent sips",
        "Rest and cool environment; seek care if unable to keep fluids down"
    ],
    "minor cut infection": [
        "Keep area clean, warm compress, seek medical care for antibiotics if spreading",
        "Tetanus update if wound is deep and immunization status is uncertain"
    ],
    "blister (minor)": [
        "Clean, protect with blister pad; avoid popping unless painful or infected",
        "Keep area dry and change dressing as needed"
    ],
    "eye irritation": [
        "Rinse with clean water or saline; avoid rubbing",
        "Remove contact lenses and seek care if vision changes or severe pain"
    ],
    "chapped lips": [
        "Apply petroleum jelly or lip balm; avoid licking lips",
        "Use gentle exfoliation if needed and protect from sun"
    ],
    "insect bite (minor)": [
        "Cold compress, topical hydrocortisone, oral antihistamine per label if itchy",
        "Avoid scratching and watch for spreading redness or infection"
    ],
    "cold sore (early)": [
        "Topical antiviral if available; keep area clean and avoid touching",
        "Use lip balm and avoid sharing utensils or lip products"
    ],
    "dandruff": [
        "Use anti-dandruff shampoo with zinc pyrithione or ketoconazole",
        "Avoid harsh hair products and rinse thoroughly"
    ],
    "hemorrhoids (mild)": [
        "Warm sitz baths, fiber, stool softener if needed, topical soothing creams",
        "Avoid straining during bowel movements"
    ],
    "minor allergic reaction": [
        "Antihistamine per label; cool compress for localized swelling",
        "Seek care if breathing or swallowing becomes difficult"
    ],
    "menstrual irregular cramps": [
        "Track cycle, heat, NSAIDs per label, consult clinician if irregular or heavy bleeding"
    ],
    "sore throat with cough": [
        "Saltwater gargles, honey for cough (age >1), humidifier, rest"
    ],
    "general fatigue (mild)": [
        "Short naps, hydration, balanced meals, light exercise, check sleep hygiene"
    ],
    "loss of appetite (short term)": [
        "Small nutrient-dense meals, smoothies, ginger for nausea, monitor weight"
    ]
}

SYNONYMS = {
    "throat pain": "sore throat",
    "scratchy throat": "sore throat",
    "runny nose": "congestion",
    "stuffy nose": "congestion",
    "blocked nose": "congestion",
    "upset stomach": "nausea",
    "stomach ache": "tummy ache",
    "belly pain": "tummy ache",
    "tummy ache": "tummy ache",
    "throwing up": "vomiting",
    "throw up": "vomiting",
    "can't sleep": "insomnia",
    "sleeplessness": "insomnia",
    "sun burn": "sunburn",
    "ear pain": "earache",
    "ear infection": "earache",
    "muscle pain": "muscle strain",
    "sprained ankle": "sprain",
    "cut": "minor cut",
    "bleeding": "minor cut",
    "dehydrated": "dehydration (mild)",
    "poop problems": "diarrhea",
    "constipated": "constipation",
    "heartburn": "acid reflux",
    "indigestion": "acid reflux",
    "gas": "bloating/gas",
    "belching": "bloating/gas",
    "lightheaded": "general fatigue (mild)"
}

RED_FLAGS = [
    "difficulty breathing",
    "shortness of breath",
    "chest pain",
    "fainting",
    "severe dizziness",
    "very high fever",
    "rapid heartbeat",
    "severe dehydration",
    "confusion",
    "loss of consciousness",
    "blood in vomit",
    "blood in stool",
    "uncontrolled bleeding",
    "sudden severe abdominal pain"
]

SEVERITY_HINTS = {
    "fever": "If fever is very high or persistent, seek medical care.",
    "earache": "Severe ear pain, high fever, or drainage requires evaluation.",
    "minor burn": "If burn is larger than 3 inches, on face/hands/genitals, or deep, seek care.",
    "dehydration (mild)": "If unable to drink, very low urine output, or confusion, seek urgent care.",
    "vomiting": "Seek care if vomiting is persistent, bloody, or you cannot keep fluids down.",
    "diarrhea": "Seek care if diarrhea is bloody, severe, or causing dehydration."
}

def normalize_input(text):
    return text.lower().strip()

def detect_red_flag(text):
    s = normalize_input(text)
    for flag in RED_FLAGS:
        if flag in s:
            return True, flag
    return False, None

def map_synonym(text):
    s = normalize_input(text)
    if s in SYNONYMS:
        return SYNONYMS[s]
    for k, v in SYNONYMS.items():
        if k in s:
            return v
    return None

def fuzzy_match(text, cutoff=0.6):
    s = normalize_input(text)
    keys = list(REMEDIES.keys())
    matches = difflib.get_close_matches(s, keys, n=1, cutoff=cutoff)
    if matches:
        return matches[0]
    words = s.split()
    for w in words:
        matches = difflib.get_close_matches(w, keys, n=1, cutoff=cutoff)
        if matches:
            return matches[0]
    return None

def find_remedies_for_input(user_input):
    s = normalize_input(user_input)
    # direct key
    if s in REMEDIES:
        return s, REMEDIES[s]
    # synonyms
    syn = map_synonym(s)
    if syn:
        return syn, REMEDIES.get(syn, [])
    # substring match
    for key in REMEDIES:
        if key in s or any(word in s for word in key.split()):
            return key, REMEDIES[key]
    # fuzzy match
    fuzzy = fuzzy_match(s)
    if fuzzy:
        return fuzzy, REMEDIES[fuzzy]
    return None, []

def print_results(symptom_key, tips, user_input):
    if symptom_key:
        print(f"\nSymptom matched: {symptom_key}")
        for tip in tips:
            print(f"- {tip}")
        hint = SEVERITY_HINTS.get(symptom_key)
        if hint:
            print(f"\n**Note:** {hint}")
    else:
        print("\nNo clear match found. Try a simpler symptom word (e.g., 'sore throat', 'cough', 'congestion', 'cold', 'fever', 'headache', 'migraine', 'nausea', 'vomiting', 'diarrhea', 'constipation', 'bloating/gas', 'acid reflux', 'stomach cramp', 'tummy ache', 'earache', 'toothache', 'minor cut', 'minor burn', 'sprain', 'muscle strain', 'sore muscles after exercise', 'menstrual cramps', 'insomnia', 'anxiety (mild)', 'acne', 'sunburn', 'allergic rhinitis', 'hives', 'dehydration (mild)', 'minor cut infection', 'blister (minor)', 'eye irritation','chapped lips', 'insect bite (minor)', 'cold sore (early)',  'dandruff', 'hemorrhoids (mild)', 'minor allergic reaction', 'menstrual irregular cramps', 'sore throat with cough', 'general fatigue (mild)', 'loss of appetite (short term)').")
        suggestion = fuzzy_match(user_input, cutoff=0.4)
        if suggestion:
            print(f"Closest suggestion: {suggestion}")

def main():
    print("Home Remedies Finder — type a symptom or short description.")
    print("Type 'exit', 'quit', or 'q' to leave.\n")
    try:
        while True:
            user_input = input("> ").strip()
            if not user_input:
                print("No input provided. Type a symptom or 'exit' to quit.")
                continue
            if user_input.lower() in ("exit", "quit", "q"):
                print("Exiting Home Remedies Finder. Take care.")
                break
            urgent, flag = detect_red_flag(user_input)
            if urgent:
                print(f"\n**Red flag detected:** {flag}. Seek immediate medical attention.")
                continue
            symptom_key, tips = find_remedies_for_input(user_input)
            print_results(symptom_key, tips, user_input)
            print("\n(You can enter another symptom or type 'exit' to quit.)\n")
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting Home Remedies Finder. Take care.")

if __name__ == "__main__":
    main()
