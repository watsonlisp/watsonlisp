#!/usr/bin/env python3
"""
flasher_display.py

Fast, multi-source, query-based image flasher.

General sources:
- LoremFlickr
- Openverse
- Wikimedia Commons

Science, nature, and museum sources:
- NASA Image Library
- iNaturalist
- Metropolitan Museum of Art
- Art Institute of Chicago
- Cleveland Museum of Art

Query-aware animal sources:
- Dog CEO
- The Cat API
- RandomFox
- Random Duck

Features:
- Five simultaneous download workers
- Twenty-four-image prefetch buffer
- Query and direct-URL modes
- Optional synonym expansion
- Query-aware specialty providers
- Fast provider fallback
- Start, pause, resume, stop, previous, and next
- One-shot retrieval
- In-memory history
- Automatic image resizing
- In-window Pillow display
- External-viewer fallback
- Fullscreen mode
- Provider name displayed in the status bar

Install Pillow:

    python -m pip install pillow

Keyboard shortcuts:

    Space       Pause or resume
    Left Arrow  Previous image
    Right Arrow Next image
    F11         Toggle fullscreen
    Escape      Exit fullscreen
"""

import base64
import hashlib
import json
import os
import queue
import random
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import tkinter as tk
import tkinter.ttk as ttk
import urllib.parse
import urllib.request

from io import BytesIO
from urllib.error import HTTPError, URLError


# ------------------------------------------------------------
# Optional Pillow support
# ------------------------------------------------------------

try:
    from PIL import Image, ImageOps, ImageTk

    PIL_AVAILABLE = True
except Exception:
    Image = None
    ImageOps = None
    ImageTk = None
    PIL_AVAILABLE = False


# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------

PREFETCH_SIZE = 24
PREFETCH_WORKERS = 5

FETCH_TIMEOUT = 8
MAX_RETRIES = 0

MIN_INTERVAL_MS = 50
HISTORY_MAX = 100
MAX_IMAGE_BYTES = 25 * 1024 * 1024

IMAGE_WIDTH = 1000
IMAGE_HEIGHT = 667


# ------------------------------------------------------------
# Query synonyms
# ------------------------------------------------------------

SYNONYMS = {
    "nature": [
        "outdoors",
        "landscape",
        "scenery",
        "wilderness",
    ],
    "forest": [
        "woods",
        "woodland",
        "grove",
        "jungle",
    ],
    "tree": [
        "oak",
        "pine",
        "fir",
        "sapling",
    ],
    "mountain": [
        "peak",
        "hill",
        "range",
        "summit",
    ],
    "river": [
        "stream",
        "creek",
        "brook",
        "waterway",
    ],
    "lake": [
        "pond",
        "reservoir",
        "loch",
        "waterbody",
    ],
    "ocean": [
        "sea",
        "marine",
        "coast",
        "blue",
    ],
    "beach": [
        "coast",
        "seashore",
        "shore",
        "sand",
    ],
    "sunset": [
        "dusk",
        "twilight",
        "sundown",
        "evening",
    ],
    "sunrise": [
        "dawn",
        "daybreak",
        "morning",
        "aurora",
    ],
    "flower": [
        "blossom",
        "bloom",
        "floral",
        "petal",
    ],
    "animal": [
        "creature",
        "fauna",
        "wildlife",
    ],
    "cat": [
        "kitten",
        "feline",
        "cats",
    ],
    "dog": [
        "puppy",
        "canine",
        "hound",
        "dogs",
    ],
    "bird": [
        "avian",
        "songbird",
        "raptor",
    ],
    "city": [
        "urban",
        "metropolis",
        "downtown",
    ],
    "car": [
        "automobile",
        "vehicle",
        "sedan",
    ],
    "food": [
        "cuisine",
        "dish",
        "meal",
    ],
    "travel": [
        "journey",
        "trip",
        "adventure",
    ],
    "music": [
        "song",
        "melody",
        "concert",
    ],
    "art": [
        "painting",
        "drawing",
        "illustration",
    ],
    "technology": [
        "tech",
        "gadget",
        "electronics",
    ],
    "space": [
        "astronomy",
        "cosmos",
        "galaxy",
        "universe",
    ],
    "winter": [
        "snow",
        "cold",
        "frost",
        "ice",
    ],
    "spring": [
        "bloom",
        "fresh",
        "green",
        "blossom",
    ],
    "summer": [
        "sunny",
        "warm",
        "beach",
        "vacation",
    ],
    "autumn": [
        "fall",
        "leaves",
        "harvest",
        "golden",
    ],
}


def expand_query(query, enabled):
    """Add known synonyms to the entered query."""

    query = query.strip()

    if not enabled:
        return query

    tokens = [
        token.strip().lower()
        for token in query.replace(",", " ").split()
        if token.strip()
    ]

    extras = []

    for token in tokens:
        for synonym in SYNONYMS.get(token, []):
            if synonym not in tokens and synonym not in extras:
                extras.append(synonym)

    return ",".join(tokens + extras)


# ------------------------------------------------------------
# HTTP helpers
# ------------------------------------------------------------

def request_bytes(
    url,
    accept,
    timeout=FETCH_TIMEOUT,
    limit=MAX_IMAGE_BYTES,
):
    """Download a size-limited response."""

    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": (
                "FastQueryImageFlasher/7.0 "
                "(Tkinter desktop image viewer)"
            ),
            "Accept": accept,
            "Accept-Encoding": "identity",
            "Connection": "close",
        },
    )

    with urllib.request.urlopen(
        request,
        timeout=timeout,
    ) as response:
        data = response.read(limit + 1)

        if len(data) > limit:
            raise ValueError(
                "Response exceeded the allowed size"
            )

        content_type = (
            response.headers
            .get("Content-Type", "")
            .split(";", 1)[0]
            .strip()
            .lower()
        )

        final_url = response.geturl()

    if not data:
        raise ValueError(
            "The server returned an empty response"
        )

    return data, content_type, final_url


def http_get_bytes(url, timeout=FETCH_TIMEOUT):
    """Download an image."""

    data, content_type, final_url = request_bytes(
        url,
        "image/*",
        timeout,
    )

    if content_type and not content_type.startswith("image/"):
        raise ValueError(
            f"Not an image response: {content_type}"
        )

    return data, content_type, final_url


def http_get_json(url, timeout=FETCH_TIMEOUT):
    """Download and decode JSON."""

    data, content_type, _ = request_bytes(
        url,
        "application/json",
        timeout,
        5 * 1024 * 1024,
    )

    if content_type and "json" not in content_type:
        raise ValueError(
            f"Expected JSON but received: {content_type}"
        )

    return json.loads(
        data.decode("utf-8")
    )


def stable_seed(text):
    """Generate a repeatable numeric seed."""

    digest = hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()

    return int(digest[:12], 16) % 999_999_999


def normalized_query(source):
    """Convert expanded query text into readable search text."""

    return (
        " ".join(
            source.replace(",", " ").split()
        )
        or "nature"
    )


def valid_http_url(value):
    """Return True for a normal HTTP or HTTPS URL."""

    return (
        isinstance(value, str)
        and value.lower().startswith(
            ("http://", "https://")
        )
    )


def first_http_url(*values):
    """Return the first usable URL."""

    for value in values:
        if valid_http_url(value):
            return value

    return None


def shuffled_or_rotated(
    items,
    source,
    provider_name,
    randomize,
):
    """Shuffle or repeatably rotate a result list."""

    items = list(items)

    if not items:
        return items

    if randomize:
        random.shuffle(items)
        return items

    start = (
        stable_seed(provider_name + ":" + source)
        % len(items)
    )

    return items[start:] + items[:start]


def download_from_results(
    provider_name,
    urls,
    source,
    randomize,
    timeout,
    maximum_attempts=6,
):
    """Try multiple image URLs from a provider."""

    clean_urls = []

    for url in urls:
        if valid_http_url(url) and url not in clean_urls:
            clean_urls.append(url)

    if not clean_urls:
        raise ValueError(
            f"{provider_name} returned no usable images"
        )

    clean_urls = shuffled_or_rotated(
        clean_urls,
        source,
        provider_name,
        randomize,
    )

    errors = []

    for url in clean_urls[:maximum_attempts]:
        try:
            return http_get_bytes(
                url,
                timeout,
            )

        except Exception as error:
            errors.append(
                f"{type(error).__name__}: {error}"
            )

    detail = (
        errors[-1]
        if errors
        else "no downloadable results"
    )

    raise RuntimeError(
        f"{provider_name} results could not be downloaded. "
        f"Last error: {detail}"
    )


# ------------------------------------------------------------
# LoremFlickr
# ------------------------------------------------------------

def fetch_loremflickr(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Download a query-based image from LoremFlickr."""

    tags = ",".join(
        normalized_query(source).split()
    )

    tags = urllib.parse.quote(
        tags,
        safe=",",
    )

    if randomize:
        lock = random.randint(
            1,
            999_999_999,
        )
    else:
        lock = stable_seed(
            "loremflickr:" + source
        )

    url = (
        f"https://loremflickr.com/"
        f"{IMAGE_WIDTH}/{IMAGE_HEIGHT}/"
        f"{tags}?lock={lock}"
    )

    return http_get_bytes(
        url,
        timeout,
    )


# ------------------------------------------------------------
# Openverse
# ------------------------------------------------------------

def openverse_urls(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Search Openverse."""

    parameters = {
        "q": normalized_query(source),
        "page": random.randint(1, 3) if randomize else 1,
        "page_size": 20,
        "mature": "false",
    }

    api_url = (
        "https://api.openverse.org/v1/images/?"
        + urllib.parse.urlencode(parameters)
    )

    payload = http_get_json(
        api_url,
        timeout,
    )

    urls = []

    for result in payload.get("results", []):
        for candidate in (
            result.get("thumbnail"),
            result.get("url"),
        ):
            if (
                valid_http_url(candidate)
                and candidate not in urls
            ):
                urls.append(candidate)

    return urls


def fetch_openverse(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    return download_from_results(
        "Openverse",
        openverse_urls(
            source,
            randomize,
            timeout,
        ),
        source,
        randomize,
        timeout,
    )


# ------------------------------------------------------------
# Wikimedia Commons
# ------------------------------------------------------------

def wikimedia_urls(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Search Wikimedia Commons."""

    parameters = {
        "action": "query",
        "format": "json",
        "formatversion": 2,
        "generator": "search",
        "gsrsearch": normalized_query(source),
        "gsrnamespace": 6,
        "gsrlimit": 20,
        "prop": "imageinfo",
        "iiprop": "url|mime",
        "iiurlwidth": IMAGE_WIDTH,
        "origin": "*",
    }

    api_url = (
        "https://commons.wikimedia.org/w/api.php?"
        + urllib.parse.urlencode(parameters)
    )

    payload = http_get_json(
        api_url,
        timeout,
    )

    pages = (
        payload
        .get("query", {})
        .get("pages", [])
    )

    urls = []

    for page in pages:
        image_info = page.get(
            "imageinfo",
            [],
        )

        if not image_info:
            continue

        info = image_info[0]
        mime = info.get("mime", "").lower()

        if mime and not mime.startswith("image/"):
            continue

        for candidate in (
            info.get("thumburl"),
            info.get("url"),
        ):
            if (
                valid_http_url(candidate)
                and candidate not in urls
            ):
                urls.append(candidate)

    return urls


def fetch_wikimedia(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    return download_from_results(
        "Wikimedia Commons",
        wikimedia_urls(
            source,
            randomize,
            timeout,
        ),
        source,
        randomize,
        timeout,
    )


# ------------------------------------------------------------
# NASA Image Library
# ------------------------------------------------------------

def nasa_urls(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Search NASA's public image library."""

    parameters = {
        "q": normalized_query(source),
        "media_type": "image",
        "page_size": 100,
    }

    if randomize:
        parameters["page"] = random.randint(1, 3)

    api_url = (
        "https://images-api.nasa.gov/search?"
        + urllib.parse.urlencode(parameters)
    )

    payload = http_get_json(
        api_url,
        timeout,
    )

    items = (
        payload
        .get("collection", {})
        .get("items", [])
    )

    urls = []

    for item in items:
        for link in item.get("links", []):
            candidate = link.get("href")

            if (
                link.get("render") == "image"
                and valid_http_url(candidate)
                and candidate not in urls
            ):
                urls.append(candidate)

    return urls


def fetch_nasa(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    return download_from_results(
        "NASA",
        nasa_urls(
            source,
            randomize,
            timeout,
        ),
        source,
        randomize,
        timeout,
    )


# ------------------------------------------------------------
# Metropolitan Museum of Art
# ------------------------------------------------------------

def metmuseum_urls(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Search The Metropolitan Museum of Art."""

    parameters = {
        "q": normalized_query(source),
        "hasImages": "true",
    }

    search_url = (
        "https://collectionapi.metmuseum.org/"
        "public/collection/v1/search?"
        + urllib.parse.urlencode(parameters)
    )

    payload = http_get_json(
        search_url,
        timeout,
    )

    object_ids = payload.get(
        "objectIDs",
        [],
    ) or []

    object_ids = shuffled_or_rotated(
        object_ids[:80],
        source,
        "The Met Museum",
        randomize,
    )

    urls = []

    for object_id in object_ids[:8]:
        try:
            object_url = (
                "https://collectionapi.metmuseum.org/"
                "public/collection/v1/objects/"
                f"{object_id}"
            )

            item = http_get_json(
                object_url,
                timeout,
            )

            candidate = first_http_url(
                item.get("primaryImageSmall"),
                item.get("primaryImage"),
            )

            if candidate and candidate not in urls:
                urls.append(candidate)

        except Exception:
            continue

    return urls


def fetch_metmuseum(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    return download_from_results(
        "The Met Museum",
        metmuseum_urls(
            source,
            randomize,
            timeout,
        ),
        source,
        randomize,
        timeout,
    )


# ------------------------------------------------------------
# Art Institute of Chicago
# ------------------------------------------------------------

def art_institute_urls(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Search the Art Institute of Chicago."""

    parameters = {
        "q": normalized_query(source),
        "limit": 30,
        "fields": "id,title,image_id,is_public_domain",
    }

    api_url = (
        "https://api.artic.edu/api/v1/artworks/search?"
        + urllib.parse.urlencode(parameters)
    )

    payload = http_get_json(
        api_url,
        timeout,
    )

    iiif_url = (
        payload
        .get("config", {})
        .get(
            "iiif_url",
            "https://www.artic.edu/iiif/2",
        )
    )

    urls = []

    for artwork in payload.get("data", []):
        image_id = artwork.get("image_id")

        if not image_id:
            continue

        candidate = (
            f"{iiif_url}/{image_id}/"
            f"full/{IMAGE_WIDTH},/0/default.jpg"
        )

        if candidate not in urls:
            urls.append(candidate)

    return urls


def fetch_art_institute(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    return download_from_results(
        "Art Institute of Chicago",
        art_institute_urls(
            source,
            randomize,
            timeout,
        ),
        source,
        randomize,
        timeout,
    )


# ------------------------------------------------------------
# Cleveland Museum of Art
# ------------------------------------------------------------

def cleveland_art_urls(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Search Cleveland Museum of Art."""

    parameters = {
        "q": normalized_query(source),
        "has_image": 1,
        "limit": 40,
    }

    if randomize:
        parameters["skip"] = random.randint(0, 40)

    api_url = (
        "https://openaccess-api.clevelandart.org/"
        "api/artworks/?"
        + urllib.parse.urlencode(parameters)
    )

    payload = http_get_json(
        api_url,
        timeout,
    )

    urls = []

    for artwork in payload.get("data", []):
        images = artwork.get("images") or {}
        web_image = images.get("web") or {}
        print_image = images.get("print") or {}
        full_image = images.get("full") or {}

        candidate = first_http_url(
            web_image.get("url"),
            print_image.get("url"),
            full_image.get("url"),
        )

        if candidate and candidate not in urls:
            urls.append(candidate)

    return urls


def fetch_cleveland_art(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    return download_from_results(
        "Cleveland Museum of Art",
        cleveland_art_urls(
            source,
            randomize,
            timeout,
        ),
        source,
        randomize,
        timeout,
    )


# ------------------------------------------------------------
# iNaturalist
# ------------------------------------------------------------

def inaturalist_urls(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Search iNaturalist wildlife observations."""

    parameters = {
        "q": normalized_query(source),
        "photos": "true",
        "quality_grade": "research",
        "per_page": 30,
        "order_by": (
            "random"
            if randomize
            else "observed_on"
        ),
    }

    api_url = (
        "https://api.inaturalist.org/v1/observations?"
        + urllib.parse.urlencode(parameters)
    )

    payload = http_get_json(
        api_url,
        timeout,
    )

    urls = []

    for observation in payload.get("results", []):
        for photo in observation.get("photos", []):
            candidate = photo.get("url")

            if not valid_http_url(candidate):
                continue

            candidate = candidate.replace(
                "/square.",
                "/large.",
            )

            candidate = candidate.replace(
                "/small.",
                "/large.",
            )

            candidate = candidate.replace(
                "/medium.",
                "/large.",
            )

            if candidate not in urls:
                urls.append(candidate)

    return urls


def fetch_inaturalist(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    return download_from_results(
        "iNaturalist",
        inaturalist_urls(
            source,
            randomize,
            timeout,
        ),
        source,
        randomize,
        timeout,
    )


# ------------------------------------------------------------
# Animal APIs
# ------------------------------------------------------------

def fetch_dog_api(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Download a random dog image."""

    payload = http_get_json(
        "https://dog.ceo/api/breeds/image/random",
        timeout,
    )

    image_url = payload.get("message")

    if not valid_http_url(image_url):
        raise ValueError(
            "Dog CEO returned no usable image"
        )

    return http_get_bytes(
        image_url,
        timeout,
    )


def fetch_cat_api(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Download a random cat image."""

    parameters = {
        "limit": 10,
        "size": "med",
        "mime_types": "jpg,png",
    }

    api_url = (
        "https://api.thecatapi.com/v1/images/search?"
        + urllib.parse.urlencode(parameters)
    )

    payload = http_get_json(
        api_url,
        timeout,
    )

    urls = [
        item.get("url")
        for item in payload
        if valid_http_url(item.get("url"))
    ]

    return download_from_results(
        "The Cat API",
        urls,
        source,
        randomize,
        timeout,
    )


def fetch_fox_api(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Download a random fox image."""

    payload = http_get_json(
        "https://randomfox.ca/floof/",
        timeout,
    )

    image_url = payload.get("image")

    if not valid_http_url(image_url):
        raise ValueError(
            "RandomFox returned no usable image"
        )

    return http_get_bytes(
        image_url,
        timeout,
    )


def fetch_duck_api(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
):
    """Download a random duck image."""

    payload = http_get_json(
        "https://random-d.uk/api/v2/random",
        timeout,
    )

    image_url = payload.get("url")

    if not valid_http_url(image_url):
        raise ValueError(
            "Random Duck returned no usable image"
        )

    return http_get_bytes(
        image_url,
        timeout,
    )


# ------------------------------------------------------------
# Query-aware provider selection
# ------------------------------------------------------------

def source_words(source):
    """Convert the query into a lowercase word set."""

    cleaned = normalized_query(source).lower()

    for character in ",;:/\\-_":
        cleaned = cleaned.replace(
            character,
            " ",
        )

    return set(cleaned.split())


def query_matches(source, keywords):
    return bool(
        source_words(source).intersection(keywords)
    )


ANIMAL_WORDS = {
    "animal",
    "animals",
    "wildlife",
    "creature",
    "creatures",
    "fauna",
    "pet",
    "pets",
}

DOG_WORDS = ANIMAL_WORDS | {
    "dog",
    "dogs",
    "puppy",
    "puppies",
    "canine",
    "hound",
}

CAT_WORDS = ANIMAL_WORDS | {
    "cat",
    "cats",
    "kitten",
    "kittens",
    "feline",
}

FOX_WORDS = ANIMAL_WORDS | {
    "fox",
    "foxes",
    "vulpine",
}

DUCK_WORDS = ANIMAL_WORDS | {
    "duck",
    "ducks",
    "waterfowl",
}

SPACE_WORDS = {
    "space",
    "nasa",
    "rocket",
    "rockets",
    "planet",
    "planets",
    "moon",
    "solar",
    "star",
    "stars",
    "galaxy",
    "galaxies",
    "astronomy",
    "astronaut",
    "astronauts",
    "nebula",
    "cosmos",
    "universe",
    "satellite",
    "satellites",
    "earth",
    "mars",
    "jupiter",
    "saturn",
}

NATURE_WORDS = {
    "nature",
    "animal",
    "animals",
    "wildlife",
    "bird",
    "birds",
    "plant",
    "plants",
    "flower",
    "flowers",
    "insect",
    "insects",
    "tree",
    "trees",
    "forest",
    "ocean",
    "fish",
}

ART_WORDS = {
    "art",
    "artist",
    "artists",
    "painting",
    "paintings",
    "sculpture",
    "sculptures",
    "drawing",
    "drawings",
    "museum",
    "museums",
    "portrait",
    "portraits",
    "history",
    "historical",
    "ancient",
    "artifact",
    "artifacts",
    "antique",
    "antiques",
}


def provider_functions(source, randomize):
    """Return providers in a varied, query-aware order."""

    broad_providers = [
        (
            "LoremFlickr",
            fetch_loremflickr,
        ),
        (
            "Openverse",
            fetch_openverse,
        ),
        (
            "Wikimedia Commons",
            fetch_wikimedia,
        ),
    ]

    collection_providers = [
        (
            "NASA",
            fetch_nasa,
        ),
        (
            "iNaturalist",
            fetch_inaturalist,
        ),
        (
            "The Met Museum",
            fetch_metmuseum,
        ),
        (
            "Art Institute of Chicago",
            fetch_art_institute,
        ),
        (
            "Cleveland Museum of Art",
            fetch_cleveland_art,
        ),
    ]

    specialty_providers = []

    if query_matches(source, DOG_WORDS):
        specialty_providers.append(
            ("Dog CEO", fetch_dog_api)
        )

    if query_matches(source, CAT_WORDS):
        specialty_providers.append(
            ("The Cat API", fetch_cat_api)
        )

    if query_matches(source, FOX_WORDS):
        specialty_providers.append(
            ("RandomFox", fetch_fox_api)
        )

    if query_matches(source, DUCK_WORDS):
        specialty_providers.append(
            ("Random Duck", fetch_duck_api)
        )

    prioritized = []

    if query_matches(source, SPACE_WORDS):
        prioritized.append(
            ("NASA", fetch_nasa)
        )

    if query_matches(source, NATURE_WORDS):
        prioritized.append(
            ("iNaturalist", fetch_inaturalist)
        )

    if query_matches(source, ART_WORDS):
        prioritized.extend(
            [
                (
                    "The Met Museum",
                    fetch_metmuseum,
                ),
                (
                    "Art Institute of Chicago",
                    fetch_art_institute,
                ),
                (
                    "Cleveland Museum of Art",
                    fetch_cleveland_art,
                ),
            ]
        )

    if randomize:
        random.shuffle(broad_providers)
        random.shuffle(collection_providers)
        random.shuffle(specialty_providers)

        if specialty_providers and random.random() < 0.65:
            providers = (
                specialty_providers
                + prioritized
                + broad_providers
                + collection_providers
            )
        else:
            providers = (
                prioritized
                + broad_providers
                + collection_providers
                + specialty_providers
            )
    else:
        providers = (
            prioritized
            + specialty_providers
            + broad_providers
            + collection_providers
        )

    unique = []
    seen = set()

    for provider_name, provider in providers:
        if provider_name not in seen:
            seen.add(provider_name)
            unique.append(
                (provider_name, provider)
            )

    if not unique:
        return []

    if randomize:
        return unique

    start = (
        stable_seed("provider:" + source)
        % len(unique)
    )

    return unique[start:] + unique[:start]


def robust_fetch(
    source,
    randomize,
    timeout=FETCH_TIMEOUT,
    max_retries=MAX_RETRIES,
):
    """Try all relevant image sources."""

    source = (source or "nature").strip()

    if source.lower().startswith(
        ("http://", "https://")
    ):
        data, content_type, final_url = (
            http_get_bytes(
                source,
                timeout,
            )
        )

        return (
            data,
            content_type,
            final_url,
            "Direct URL",
        )

    errors = []

    for provider_name, provider in provider_functions(
        source,
        randomize,
    ):
        for attempt in range(max_retries + 1):
            try:
                if attempt:
                    time.sleep(0.15)

                data, content_type, final_url = (
                    provider(
                        source,
                        randomize,
                        timeout,
                    )
                )

                return (
                    data,
                    content_type,
                    final_url,
                    provider_name,
                )

            except (
                HTTPError,
                URLError,
                TimeoutError,
                ValueError,
                RuntimeError,
                OSError,
                KeyError,
                IndexError,
                TypeError,
                json.JSONDecodeError,
            ) as error:
                errors.append(
                    f"{provider_name}: "
                    f"{type(error).__name__}: {error}"
                )

    detail = (
        " | ".join(errors[-4:])
        if errors
        else "unknown error"
    )

    raise RuntimeError(
        "All image sources failed. "
        f"Recent errors: {detail}"
    )


# ------------------------------------------------------------
# Background prefetcher
# ------------------------------------------------------------

class Prefetcher(threading.Thread):
    """Download images without blocking Tkinter."""

    def __init__(
        self,
        config_getter,
        output_queue,
        stop_event,
    ):
        super().__init__(daemon=True)

        self.config_getter = config_getter
        self.output_queue = output_queue
        self.stop_event = stop_event

    def run(self):
        while not self.stop_event.is_set():
            if self.output_queue.full():
                self.stop_event.wait(0.05)
                continue

            source, randomize = self.config_getter()

            try:
                item = robust_fetch(
                    source,
                    randomize,
                )

            except Exception as error:
                item = (
                    None,
                    None,
                    None,
                    str(error),
                )

            if self.stop_event.is_set():
                return

            try:
                self.output_queue.put(
                    item,
                    timeout=0.1,
                )
            except queue.Full:
                pass

            if item[0] is None:
                self.stop_event.wait(0.2)


# ------------------------------------------------------------
# Application
# ------------------------------------------------------------

class ImageFlasher(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title(
            "Fast Multi-Source Image Flasher"
        )

        self.geometry("1200x760")
        self.minsize(820, 520)

        try:
            self.state("zoomed")
        except tk.TclError:
            pass

        self.protocol(
            "WM_DELETE_WINDOW",
            self.on_close,
        )

        self.interval = tk.IntVar(value=2000)
        self.query = tk.StringVar(value="nature")

        self.viewer_auto_close_ms = tk.IntVar(
            value=2000
        )

        self.randomize = tk.BooleanVar(
            value=True
        )

        self.include_synonyms = tk.BooleanVar(
            value=False
        )

        self.mode = tk.StringVar(
            value="query"
        )

        self.running = False
        self.paused = False
        self.fullscreen = False
        self.after_id = None
        self.fetch_in_progress = False
        self.closing = False

        self.buffer = queue.Queue(
            maxsize=PREFETCH_SIZE
        )

        self.fetch_results = queue.Queue()

        self.stop_event = None
        self.prefetchers = []

        self.config_lock = threading.Lock()
        self.worker_source = "nature"
        self.worker_randomize = True

        self.history = []
        self.history_index = -1
        self.current_item = None

        self.current_pil_image = None
        self.current_photo = None
        self.resize_job = None

        self.viewer_proc = None
        self.viewer_timer = None
        self.temp_paths = set()

        self.build_ui()
        self.bind_shortcuts()
        self.sync_worker_config()

        self.after(
            40,
            self.poll_background_work,
        )

    # --------------------------------------------------------
    # UI
    # --------------------------------------------------------

    def build_ui(self):
        controls = ttk.Frame(
            self,
            padding=8,
        )

        controls.pack(fill="x")

        first_row = ttk.Frame(controls)

        first_row.pack(
            fill="x",
            pady=(0, 5),
        )

        ttk.Label(
            first_row,
            text="Mode",
        ).pack(side="left")

        ttk.Radiobutton(
            first_row,
            text="Query",
            variable=self.mode,
            value="query",
            command=self.settings_changed,
        ).pack(
            side="left",
            padx=4,
        )

        ttk.Radiobutton(
            first_row,
            text="Direct URL",
            variable=self.mode,
            value="url",
            command=self.settings_changed,
        ).pack(
            side="left",
            padx=4,
        )

        ttk.Label(
            first_row,
            text="Input",
        ).pack(
            side="left",
            padx=(10, 0),
        )

        self.query_entry = ttk.Entry(
            first_row,
            textvariable=self.query,
        )

        self.query_entry.pack(
            side="left",
            padx=6,
            fill="x",
            expand=True,
        )

        self.query_entry.bind(
            "<Return>",
            lambda event: self.next_image(),
        )

        self.query_entry.bind(
            "<FocusOut>",
            lambda event: self.settings_changed(),
        )

        ttk.Checkbutton(
            first_row,
            text="Randomize",
            variable=self.randomize,
            command=self.settings_changed,
        ).pack(
            side="left",
            padx=6,
        )

        ttk.Checkbutton(
            first_row,
            text="Add synonyms",
            variable=self.include_synonyms,
            command=self.settings_changed,
        ).pack(
            side="left",
            padx=6,
        )

        second_row = ttk.Frame(controls)
        second_row.pack(fill="x")

        ttk.Label(
            second_row,
            text="Interval (ms)",
        ).pack(side="left")

        ttk.Spinbox(
            second_row,
            from_=MIN_INTERVAL_MS,
            to=60000,
            increment=50,
            textvariable=self.interval,
            width=8,
        ).pack(
            side="left",
            padx=6,
        )

        ttk.Label(
            second_row,
            text="Viewer auto-off (ms)",
        ).pack(
            side="left",
            padx=(10, 0),
        )

        ttk.Spinbox(
            second_row,
            from_=100,
            to=60000,
            increment=100,
            textvariable=self.viewer_auto_close_ms,
            width=8,
        ).pack(
            side="left",
            padx=6,
        )

        self.start_btn = ttk.Button(
            second_row,
            text="Start",
            command=self.start,
        )

        self.start_btn.pack(
            side="left",
            padx=(15, 4),
        )

        self.pause_btn = ttk.Button(
            second_row,
            text="Pause",
            command=self.toggle_pause,
        )

        self.pause_btn.pack(
            side="left",
            padx=4,
        )

        ttk.Button(
            second_row,
            text="Stop",
            command=self.stop,
        ).pack(
            side="left",
            padx=4,
        )

        ttk.Button(
            second_row,
            text="One-shot",
            command=self.one_shot,
        ).pack(
            side="left",
            padx=4,
        )

        ttk.Button(
            second_row,
            text="Previous",
            command=self.previous_image,
        ).pack(
            side="left",
            padx=4,
        )

        ttk.Button(
            second_row,
            text="Next",
            command=self.next_image,
        ).pack(
            side="left",
            padx=4,
        )

        ttk.Button(
            second_row,
            text="Fullscreen",
            command=self.toggle_fullscreen,
        ).pack(
            side="left",
            padx=4,
        )

        self.display = tk.Label(
            self,
            background="black",
            foreground="white",
            anchor="center",
            justify="center",
            relief="sunken",
            borderwidth=1,
            text=(
                "Enter a search query.\n\n"
                "Five parallel download workers are enabled.\n"
                "Up to twenty-four images are prepared in advance.\n\n"
                "General sources:\n"
                "LoremFlickr, Openverse, Wikimedia Commons\n\n"
                "Special collections:\n"
                "NASA, iNaturalist, The Met Museum,\n"
                "Art Institute of Chicago,\n"
                "Cleveland Museum of Art\n\n"
                "Animal sources:\n"
                "Dog CEO, The Cat API, RandomFox, Random Duck\n\n"
                "Press Start or One-shot."
            ),
        )

        self.display.pack(
            expand=True,
            fill="both",
        )

        self.display.bind(
            "<Configure>",
            self.redraw_current,
        )

        initial_status = (
            "Ready | Expanded provider system enabled"
        )

        if not PIL_AVAILABLE:
            initial_status = (
                "Install Pillow for reliable in-window display"
            )

        self.status = ttk.Label(
            self,
            text=initial_status,
            anchor="w",
            padding=(8, 4),
        )

        self.status.pack(fill="x")

    # --------------------------------------------------------
    # Keyboard and fullscreen
    # --------------------------------------------------------

    def bind_shortcuts(self):
        self.bind(
            "<space>",
            self.keyboard_pause,
        )

        self.bind(
            "<Left>",
            self.keyboard_previous,
        )

        self.bind(
            "<Right>",
            self.keyboard_next,
        )

        self.bind(
            "<F11>",
            self.toggle_fullscreen,
        )

        self.bind(
            "<Escape>",
            self.exit_fullscreen,
        )

    def keyboard_pause(self, event=None):
        if self.focus_get() != self.query_entry:
            self.toggle_pause()
            return "break"

    def keyboard_previous(self, event=None):
        if self.focus_get() != self.query_entry:
            self.previous_image()
            return "break"

    def keyboard_next(self, event=None):
        if self.focus_get() != self.query_entry:
            self.next_image()
            return "break"

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen

        try:
            self.attributes(
                "-fullscreen",
                self.fullscreen,
            )
        except tk.TclError:
            self.fullscreen = False

        return "break"

    def exit_fullscreen(self, event=None):
        self.fullscreen = False

        try:
            self.attributes(
                "-fullscreen",
                False,
            )
        except tk.TclError:
            pass

        return "break"

    # --------------------------------------------------------
    # Settings
    # --------------------------------------------------------

    def safe_int(
        self,
        variable,
        default,
        minimum,
        maximum,
    ):
        try:
            value = int(variable.get())
        except (ValueError, tk.TclError):
            value = default

        value = max(
            minimum,
            min(maximum, value),
        )

        try:
            variable.set(value)
        except tk.TclError:
            pass

        return value

    def current_source(self):
        raw = self.query.get().strip()

        if self.mode.get() == "url":
            return raw

        return expand_query(
            raw or "nature",
            self.include_synonyms.get(),
        )

    def display_query(self):
        if self.mode.get() == "url":
            return "direct URL"

        return self.current_source().replace(
            ",",
            ", ",
        )

    def valid_source(self):
        source = self.current_source()

        if self.mode.get() == "url":
            if not source:
                self.status.configure(
                    text="Enter a direct image URL"
                )
                return False

            if not source.lower().startswith(
                ("http://", "https://")
            ):
                self.status.configure(
                    text=(
                        "Direct URL mode requires an "
                        "http:// or https:// address"
                    )
                )
                return False

        return True

    def sync_worker_config(self):
        with self.config_lock:
            self.worker_source = self.current_source()

            self.worker_randomize = (
                self.randomize.get()
                and self.mode.get() == "query"
            )

    def worker_config(self):
        with self.config_lock:
            return (
                self.worker_source,
                self.worker_randomize,
            )

    def settings_changed(self):
        self.sync_worker_config()
        self.clear_buffer()

        self.status.configure(
            text=(
                "Search set to: "
                f"{self.display_query()}"
            )
        )

    def clear_buffer(self):
        while True:
            try:
                self.buffer.get_nowait()
            except queue.Empty:
                break

    # --------------------------------------------------------
    # Parallel prefetch workers
    # --------------------------------------------------------

    def start_prefetcher(self):
        self.sync_worker_config()

        if any(
            worker.is_alive()
            for worker in self.prefetchers
        ):
            return

        self.stop_event = threading.Event()
        self.prefetchers = []

        for _ in range(PREFETCH_WORKERS):
            worker = Prefetcher(
                self.worker_config,
                self.buffer,
                self.stop_event,
            )

            worker.start()
            self.prefetchers.append(worker)

    def stop_prefetcher(self):
        if self.stop_event is not None:
            self.stop_event.set()

        self.prefetchers = []
        self.stop_event = None

    # --------------------------------------------------------
    # Background polling
    # --------------------------------------------------------

    def poll_background_work(self):
        if self.closing:
            return

        while True:
            try:
                item, error = self.fetch_results.get_nowait()
            except queue.Empty:
                break

            self.fetch_done(
                item,
                error,
            )

        if self.running and self.after_id is None:
            self.show_next_buffered()

        self.after(
            40,
            self.poll_background_work,
        )

    # --------------------------------------------------------
    # Playback
    # --------------------------------------------------------

    def show_next_buffered(self):
        if not self.running:
            return

        try:
            item = self.buffer.get_nowait()

        except queue.Empty:
            self.status.configure(
                text=(
                    "Downloading images for: "
                    f"{self.display_query()}"
                )
            )
            return

        if item[0] is None:
            self.status.configure(
                text=item[3]
            )
            return

        self.show_item(
            item,
            add_history=True,
        )

        delay = self.safe_int(
            self.interval,
            2000,
            MIN_INTERVAL_MS,
            60000,
        )

        provider = item[3]

        self.status.configure(
            text=(
                f"{provider} | "
                f"Showing: {self.display_query()} | "
                f"Buffered: {self.buffer.qsize()}/"
                f"{PREFETCH_SIZE} | "
                f"Next in {delay} ms"
            )
        )

        self.after_id = self.after(
            delay,
            self.scheduled_next,
        )

    def scheduled_next(self):
        self.after_id = None
        self.show_next_buffered()

    def restart_playback_timer(self):
        if not self.running:
            return

        if self.after_id is not None:
            try:
                self.after_cancel(
                    self.after_id
                )
            except tk.TclError:
                pass

            self.after_id = None

        delay = self.safe_int(
            self.interval,
            2000,
            MIN_INTERVAL_MS,
            60000,
        )

        self.after_id = self.after(
            delay,
            self.scheduled_next,
        )

    # --------------------------------------------------------
    # History
    # --------------------------------------------------------

    def append_history(self, item):
        if self.history_index < len(self.history) - 1:
            del self.history[
                self.history_index + 1:
            ]

        self.history.append(item)

        if len(self.history) > HISTORY_MAX:
            self.history.pop(0)

        self.history_index = len(self.history) - 1

    def previous_image(self):
        if self.history_index <= 0:
            self.status.configure(
                text="At the oldest image"
            )
            return

        self.history_index -= 1

        self.show_item(
            self.history[self.history_index]
        )

        self.show_history_status()
        self.restart_playback_timer()

    def next_image(self):
        if not self.valid_source():
            return

        self.sync_worker_config()

        if self.history_index < len(self.history) - 1:
            self.history_index += 1

            self.show_item(
                self.history[self.history_index]
            )

            self.show_history_status()
            self.restart_playback_timer()
            return

        try:
            item = self.buffer.get_nowait()

            if item[0] is None:
                raise RuntimeError(item[3])

            self.show_item(
                item,
                add_history=True,
            )

            self.show_history_status()
            self.restart_playback_timer()

        except queue.Empty:
            self.fetch_async("Next image")

        except RuntimeError as error:
            self.status.configure(
                text=str(error)
            )

    def show_history_status(self):
        if not self.history:
            self.status.configure(
                text="History is empty"
            )
            return

        provider = self.history[
            self.history_index
        ][3]

        self.status.configure(
            text=(
                f"{provider} | "
                f"{self.display_query()} | "
                f"History {self.history_index + 1}/"
                f"{len(self.history)} | "
                f"Buffered: {self.buffer.qsize()}/"
                f"{PREFETCH_SIZE}"
            )
        )

    # --------------------------------------------------------
    # Image display
    # --------------------------------------------------------

    def show_item(
        self,
        item,
        add_history=False,
    ):
        self.current_item = item

        if add_history:
            self.append_history(item)

        (
            data,
            content_type,
            final_url,
            _provider,
        ) = item

        if self.display_in_tk(data):
            return

        self.display_external(
            data,
            content_type,
            final_url,
            hold=self.paused,
        )

    def load_pil_image(self, data):
        image = Image.open(
            BytesIO(data)
        )

        image.load()
        image = ImageOps.exif_transpose(image)

        if image.mode not in ("RGB", "RGBA"):
            image = image.convert("RGBA")

        return image

    def fit_image(self, image):
        width = max(
            100,
            self.display.winfo_width(),
        )

        height = max(
            100,
            self.display.winfo_height(),
        )

        fitted = image.copy()

        fitted.thumbnail(
            (width, height),
            Image.Resampling.LANCZOS,
        )

        return fitted

    def display_in_tk(self, data):
        if not PIL_AVAILABLE:
            try:
                encoded = base64.b64encode(
                    data
                ).decode("ascii")

                photo = tk.PhotoImage(
                    data=encoded
                )

                self.display.configure(
                    image=photo,
                    text="",
                )

                self.current_photo = photo
                self.display.image = photo
                return True

            except Exception:
                return False

        try:
            self.current_pil_image = (
                self.load_pil_image(data)
            )

            fitted = self.fit_image(
                self.current_pil_image
            )

            photo = ImageTk.PhotoImage(fitted)

            self.display.configure(
                image=photo,
                text="",
            )

            self.current_photo = photo
            self.display.image = photo
            return True

        except Exception as error:
            self.status.configure(
                text=(
                    "In-window display error: "
                    f"{error}"
                )
            )
            return False

    def redraw_current(self, event=None):
        if (
            not PIL_AVAILABLE
            or self.current_pil_image is None
            or self.closing
        ):
            return

        if self.resize_job is not None:
            try:
                self.after_cancel(
                    self.resize_job
                )
            except tk.TclError:
                pass

        self.resize_job = self.after(
            100,
            self.finish_resize,
        )

    def finish_resize(self):
        self.resize_job = None

        if self.current_pil_image is None:
            return

        try:
            fitted = self.fit_image(
                self.current_pil_image
            )

            photo = ImageTk.PhotoImage(fitted)

            self.display.configure(
                image=photo,
                text="",
            )

            self.current_photo = photo
            self.display.image = photo

        except Exception as error:
            self.status.configure(
                text=f"Resize error: {error}"
            )

    # --------------------------------------------------------
    # External-viewer fallback
    # --------------------------------------------------------

    def display_external(
        self,
        data,
        content_type,
        final_url,
        hold=False,
    ):
        suffixes = {
            "image/jpeg": ".jpg",
            "image/png": ".png",
            "image/gif": ".gif",
            "image/bmp": ".bmp",
            "image/webp": ".webp",
            "image/tiff": ".tiff",
        }

        suffix = suffixes.get(
            content_type,
            ".jpg",
        )

        extension = os.path.splitext(
            urllib.parse.urlsplit(
                final_url or ""
            ).path
        )[1].lower()

        valid_extensions = {
            ".jpg",
            ".jpeg",
            ".png",
            ".gif",
            ".bmp",
            ".webp",
            ".tif",
            ".tiff",
        }

        if extension in valid_extensions:
            suffix = extension

        descriptor, path = tempfile.mkstemp(
            suffix=suffix
        )

        os.close(descriptor)

        with open(path, "wb") as file:
            file.write(data)

        self.temp_paths.add(path)
        self.cancel_viewer_timer()

        command = None

        if os.name == "nt":
            paint = shutil.which("mspaint")

            if paint:
                command = [paint, path]

        elif sys.platform == "darwin":
            opener = shutil.which("open")

            if opener:
                command = [opener, path]

        else:
            for viewer_name in (
                "eog",
                "feh",
                "display",
            ):
                viewer = shutil.which(
                    viewer_name
                )

                if viewer:
                    command = [viewer, path]
                    break

        if command is None:
            self.status.configure(
                text=(
                    "Install Pillow with: "
                    "python -m pip install pillow"
                )
            )

            self.remove_temp(path)
            return

        try:
            self.viewer_proc = subprocess.Popen(
                command
            )

            if not hold:
                delay = self.safe_int(
                    self.viewer_auto_close_ms,
                    2000,
                    100,
                    60000,
                ) / 1000.0

                self.viewer_timer = threading.Timer(
                    delay,
                    self.terminate_viewer,
                )

                self.viewer_timer.daemon = True
                self.viewer_timer.start()

            self.after(
                65000,
                lambda file_path=path:
                    self.remove_temp(file_path),
            )

        except OSError as error:
            self.status.configure(
                text=f"Viewer error: {error}"
            )

            self.remove_temp(path)

    def terminate_viewer(self):
        process = self.viewer_proc

        if (
            process is not None
            and process.poll() is None
        ):
            try:
                process.terminate()
            except OSError:
                pass

        self.viewer_proc = None
        self.viewer_timer = None

    def cancel_viewer_timer(self):
        if self.viewer_timer:
            self.viewer_timer.cancel()
            self.viewer_timer = None

    def remove_temp(self, path):
        try:
            os.remove(path)
        except OSError:
            pass

        self.temp_paths.discard(path)

    # --------------------------------------------------------
    # One-shot fetching
    # --------------------------------------------------------

    def fetch_async(self, label):
        if not self.valid_source():
            return

        if self.fetch_in_progress:
            self.status.configure(
                text="A fetch is already in progress"
            )
            return

        self.fetch_in_progress = True
        self.sync_worker_config()

        source, randomize = self.worker_config()

        self.status.configure(
            text=(
                f"{label}: searching for "
                f"{self.display_query()}..."
            )
        )

        def worker():
            try:
                result = robust_fetch(
                    source,
                    randomize,
                )

                self.fetch_results.put(
                    (result, None)
                )

            except Exception as error:
                self.fetch_results.put(
                    (None, str(error))
                )

        threading.Thread(
            target=worker,
            daemon=True,
        ).start()

    def fetch_done(self, item, error):
        self.fetch_in_progress = False

        if self.closing:
            return

        if error:
            self.status.configure(
                text=f"Fetch error: {error}"
            )
            return

        self.show_item(
            item,
            add_history=True,
        )

        provider = item[3]

        self.status.configure(
            text=(
                f"{provider} | "
                f"Showing: {self.display_query()} | "
                f"Buffered: {self.buffer.qsize()}/"
                f"{PREFETCH_SIZE}"
            )
        )

        self.restart_playback_timer()

    def one_shot(self):
        self.fetch_async("One-shot")

    # --------------------------------------------------------
    # Playback controls
    # --------------------------------------------------------

    def start(self):
        if self.running:
            return

        if not self.valid_source():
            return

        self.sync_worker_config()

        self.running = True
        self.paused = False

        self.start_btn.configure(
            text="Running"
        )

        self.pause_btn.configure(
            text="Pause"
        )

        self.start_prefetcher()

        self.status.configure(
            text=(
                f"Running with {PREFETCH_WORKERS} workers | "
                f"Searching for: {self.display_query()}"
            )
        )

        self.show_next_buffered()

    def toggle_pause(self):
        if not self.running and not self.paused:
            self.start()
            return

        if self.running:
            self.running = False
            self.paused = True

            if self.after_id is not None:
                try:
                    self.after_cancel(
                        self.after_id
                    )
                except tk.TclError:
                    pass

                self.after_id = None

            self.cancel_viewer_timer()

            self.pause_btn.configure(
                text="Resume"
            )

            self.start_btn.configure(
                text="Start"
            )

            self.status.configure(
                text=(
                    "Paused; current image held | "
                    f"Buffered: {self.buffer.qsize()}/"
                    f"{PREFETCH_SIZE}"
                )
            )

        else:
            self.start()

    def stop(self):
        self.running = False
        self.paused = False

        if self.after_id is not None:
            try:
                self.after_cancel(
                    self.after_id
                )
            except tk.TclError:
                pass

            self.after_id = None

        self.stop_prefetcher()

        self.start_btn.configure(
            text="Start"
        )

        self.pause_btn.configure(
            text="Pause"
        )

        if not self.closing:
            self.status.configure(
                text=(
                    "Stopped; current image "
                    "remains visible"
                )
            )

    # --------------------------------------------------------
    # Shutdown
    # --------------------------------------------------------

    def on_close(self):
        self.closing = True

        self.stop()
        self.cancel_viewer_timer()
        self.terminate_viewer()

        if self.resize_job is not None:
            try:
                self.after_cancel(
                    self.resize_job
                )
            except tk.TclError:
                pass

            self.resize_job = None

        for path in tuple(self.temp_paths):
            self.remove_temp(path)

        self.destroy()


if __name__ == "__main__":
    app = ImageFlasher()
    app.mainloop()
