from datetime import datetime


def to_julian_date(dt):
    year = dt.year
    month = dt.month
    day = dt.day + (
        dt.hour / 24.0 +
        dt.minute / 1440.0 +
        dt.second / 86400.0
    )

    if month <= 2:
        year -= 1
        month += 12

    A = year // 100
    B = 2 - A + (A // 4)

    jd = (
        int(365.25 * (year + 4716))
        + int(30.6001 * (month + 1))
        + day
        + B
        - 1524.5
    )

    return jd


def from_julian_date(jd):
    jd += 0.5

    Z = int(jd)
    F = jd - Z

    if Z < 2299161:
        A = Z
    else:
        alpha = int((Z - 1867216.25) / 36524.25)
        A = Z + 1 + alpha - int(alpha / 4)

    B = A + 1524
    C = int((B - 122.1) / 365.25)
    D = int(365.25 * C)
    E = int((B - D) / 30.6001)

    day = B - D - int(30.6001 * E) + F

    if E < 14:
        month = E - 1
    else:
        month = E - 13

    if month > 2:
        year = C - 4716
    else:
        year = C - 4715

    whole_day = int(day)
    frac_day = day - whole_day

    hour = int(frac_day * 24)
    minute = int((frac_day * 24 - hour) * 60)
    second = int(round((((frac_day * 24 - hour) * 60) - minute) * 60))

    if second >= 60:
        second = 0
        minute += 1

    if minute >= 60:
        minute = 0
        hour += 1

    return datetime(
        year,
        month,
        whole_day,
        hour,
        minute,
        second
    )


while True:
    print("\n=== JULIAN ===")
    print("1) Current date/time -> Julian")
    print("2) Enter date/time -> Julian")
    print("3) Julian -> Date/time")
    print("Q) Quit")
    print()

    choice = input("Choice: ").strip().lower()

    if choice == "q":
        print("\nGoodbye!")
        break

    elif choice == "1":
        dt = datetime.now()
        jd = to_julian_date(dt)

        print("\nGregorian Date :", dt.strftime("%Y-%m-%d %H:%M:%S"))
        print("Julian Date    :", f"{jd:.6f}")

    elif choice == "2":
        date_str = input(
            "\nEnter date and time "
            "(YYYY-MM-DD HH:MM:SS): "
        ).strip()

        try:
            dt = datetime.strptime(
                date_str,
                "%Y-%m-%d %H:%M:%S"
            )

            jd = to_julian_date(dt)

            print("\nGregorian Date :", dt.strftime("%Y-%m-%d %H:%M:%S"))
            print("Julian Date    :", f"{jd:.6f}")

        except ValueError:
            print("\nInvalid format.")
            print("Example: 2026-11-06 12:30:00")

    elif choice == "3":
        try:
            jd = float(
                input("\nEnter Julian Date: ").strip()
            )

            dt = from_julian_date(jd)

            print("\nJulian Date    :", jd)
            print(
                "Gregorian Date :",
                dt.strftime("%Y-%m-%d %H:%M:%S")
            )

        except ValueError:
            print("\nInvalid Julian Date.")

    else:
        print("\nInvalid choice.")

    while True:
        again = input(
            "\n(R)epeat or (Q)uit? "
        ).strip().lower()

        if again == "r":
            break

        if again == "q":
            print("\nGoodbye!")
            raise SystemExit

        print("Please enter R or Q.")
