import tkinter as tk
from tkinter import messagebox
import random

BOARD_SIZE = 8
SQUARE_SIZE = 80

EMPTY = "."
RED = "r"
RED_KING = "R"
BLACK = "b"
BLACK_KING = "B"


class CheckersGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Checkers")

        self.canvas = tk.Canvas(
            root,
            width=BOARD_SIZE * SQUARE_SIZE,
            height=BOARD_SIZE * SQUARE_SIZE
        )
        self.canvas.pack()

        self.board = self.create_board()
        self.selected = None
        self.valid_moves = []

        self.canvas.bind("<Button-1>", self.click)

        self.draw()

    def create_board(self):
        board = [[EMPTY for _ in range(8)] for _ in range(8)]

        for r in range(3):
            for c in range(8):
                if (r + c) % 2:
                    board[r][c] = BLACK

        for r in range(5, 8):
            for c in range(8):
                if (r + c) % 2:
                    board[r][c] = RED

        return board

    def draw(self):
        self.canvas.delete("all")

        for r in range(8):
            for c in range(8):
                x1 = c * SQUARE_SIZE
                y1 = r * SQUARE_SIZE
                x2 = x1 + SQUARE_SIZE
                y2 = y1 + SQUARE_SIZE

                color = "#DDB88C" if (r + c) % 2 == 0 else "#A66D4F"

                self.canvas.create_rectangle(
                    x1, y1, x2, y2,
                    fill=color,
                    outline="black"
                )

                piece = self.board[r][c]

                if piece != EMPTY:
                    fill = "red" if piece in [RED, RED_KING] else "black"

                    self.canvas.create_oval(
                        x1 + 10, y1 + 10,
                        x2 - 10, y2 - 10,
                        fill=fill
                    )

                    if piece in [RED_KING, BLACK_KING]:
                        self.canvas.create_text(
                            (x1 + x2) // 2,
                            (y1 + y2) // 2,
                            text="K",
                            fill="gold",
                            font=("Arial", 24, "bold")
                        )

        for move in self.valid_moves:
            _, _, r, c = move

            x = c * SQUARE_SIZE + SQUARE_SIZE // 2
            y = r * SQUARE_SIZE + SQUARE_SIZE // 2

            self.canvas.create_oval(
                x - 10,
                y - 10,
                x + 10,
                y + 10,
                fill="yellow"
            )

    def click(self, event):
        col = event.x // SQUARE_SIZE
        row = event.y // SQUARE_SIZE

        if self.selected:
            for move in self.valid_moves:
                sr, sc, er, ec = move

                if er == row and ec == col:
                    self.make_move(move)

                    self.selected = None
                    self.valid_moves = []

                    self.draw()

                    if self.check_game_over():
                        return

                    self.root.after(500, self.computer_turn)
                    return

        piece = self.board[row][col]

        if piece in [RED, RED_KING]:
            self.selected = (row, col)

            self.valid_moves = [
                m for m in self.get_moves(RED)
                if m[0] == row and m[1] == col
            ]

        self.draw()

    def inside(self, r, c):
        return 0 <= r < 8 and 0 <= c < 8

    def get_piece_moves(self, r, c):
        piece = self.board[r][c]

        dirs = []

        if piece in [RED, RED_KING]:
            dirs += [(-1, -1), (-1, 1)]

        if piece in [BLACK, BLACK_KING]:
            dirs += [(1, -1), (1, 1)]

        if piece in [RED_KING, BLACK_KING]:
            dirs = [(-1, -1), (-1, 1), (1, -1), (1, 1)]

        moves = []

        for dr, dc in dirs:
            nr = r + dr
            nc = c + dc

            if self.inside(nr, nc):
                if self.board[nr][nc] == EMPTY:
                    moves.append((r, c, nr, nc))

        return moves

    def get_piece_captures(self, r, c):
        piece = self.board[r][c]

        dirs = []

        if piece in [RED, RED_KING]:
            dirs += [(-1, -1), (-1, 1)]

        if piece in [BLACK, BLACK_KING]:
            dirs += [(1, -1), (1, 1)]

        if piece in [RED_KING, BLACK_KING]:
            dirs = [(-1, -1), (-1, 1), (1, -1), (1, 1)]

        captures = []

        for dr, dc in dirs:
            mr = r + dr
            mc = c + dc

            nr = r + dr * 2
            nc = c + dc * 2

            if not self.inside(nr, nc):
                continue

            if self.board[nr][nc] != EMPTY:
                continue

            middle = self.board[mr][mc]

            if piece in [RED, RED_KING]:
                if middle in [BLACK, BLACK_KING]:
                    captures.append((r, c, nr, nc))

            elif piece in [BLACK, BLACK_KING]:
                if middle in [RED, RED_KING]:
                    captures.append((r, c, nr, nc))

        return captures

    def get_moves(self, player):
        captures = []
        moves = []

        for r in range(8):
            for c in range(8):
                piece = self.board[r][c]

                if player == RED and piece not in [RED, RED_KING]:
                    continue

                if player == BLACK and piece not in [BLACK, BLACK_KING]:
                    continue

                captures.extend(
                    self.get_piece_captures(r, c)
                )

                moves.extend(
                    self.get_piece_moves(r, c)
                )

        return captures if captures else moves

    def make_move(self, move):
        r1, c1, r2, c2 = move

        piece = self.board[r1][c1]

        self.board[r1][c1] = EMPTY
        self.board[r2][c2] = piece

        if abs(r2 - r1) == 2:
            mr = (r1 + r2) // 2
            mc = (c1 + c2) // 2
            self.board[mr][mc] = EMPTY

        if piece == RED and r2 == 0:
            self.board[r2][c2] = RED_KING

        if piece == BLACK and r2 == 7:
            self.board[r2][c2] = BLACK_KING

    def get_winner(self):
        red_count = 0
        black_count = 0

        for row in self.board:
            for piece in row:
                if piece in [RED, RED_KING]:
                    red_count += 1
                elif piece in [BLACK, BLACK_KING]:
                    black_count += 1

        if red_count == 0:
            return "Computer"

        if black_count == 0:
            return "Player"

        if not self.get_moves(RED):
            return "Computer"

        if not self.get_moves(BLACK):
            return "Player"

        return None

    def check_game_over(self):
        winner = self.get_winner()

        if winner:
            messagebox.showinfo(
                "🏆 Game Over",
                f"{winner} wins!"
            )

            self.canvas.unbind("<Button-1>")
            self.root.destroy()
            return True

        return False

    def computer_turn(self):
        moves = self.get_moves(BLACK)

        if not moves:
            self.check_game_over()
            return

        captures = [
            m for m in moves
            if abs(m[2] - m[0]) == 2
        ]

        move = random.choice(
            captures if captures else moves
        )

        self.make_move(move)

        self.draw()

        self.check_game_over()


root = tk.Tk()
game = CheckersGUI(root)
root.mainloop()
