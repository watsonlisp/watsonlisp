import random
import re
import subprocess


WEIRD_WORDS = {
    # Greetings and conversation
    "hello": ["blorp", "snazzle", "greetingsoid", "glimbop", "howdywump"],
    "hi": ["glorp", "beeble", "snork", "yoink", "salutotron"],
    "hey": ["hoy", "blep", "yargle", "heyoid", "gloopday"],
    "goodbye": ["vanishwell", "departle", "byezoid", "floofwell", "latergator"],
    "bye": ["zoop", "departicus", "vanish", "bye-blorp", "lateroid"],
    "please": ["plizz", "kindly-doink", "pleasium", "if-you-wibble", "beggity"],
    "thanks": ["gratitude-noise", "thankle", "much-obliglooped", "cheersnort"],
    "thank": ["gratify", "thankle", "appreciatoid", "gratitude-blast"],
    "yes": ["yarp", "affirmatron", "yupnoodle", "correctamundo", "indeedle"],
    "no": ["narp", "negatory", "nopefish", "denialoid", "absolutely-notato"],
    "maybe": ["perhapsicle", "mayhaps", "possibly-wibly", "uncertainoid"],
    "okay": ["okeydokium", "acceptable-blorp", "finezoid", "alrightle"],
    "sorry": ["apologloopies", "regretamundo", "my-badular", "forgivify"],
    "welcome": ["welcomenoodle", "enter freely", "greetification", "come-on-inzoid"],

    # People
    "person": ["flesh unit", "humanoid", "walk creature", "thought mammal"],
    "people": ["human collection", "flesh committee", "biped swarm", "personoids"],
    "man": ["dude organism", "mancuboid", "beard-capable humanoid", "sir unit"],
    "woman": ["lady organism", "womanzoid", "madam unit", "her excellency"],
    "boy": ["young dudelet", "lad particle", "boyling", "junior humanoid"],
    "girl": ["young dudette", "lass particle", "girlzoid", "junior human"],
    "friend": ["fren", "companionoid", "buddy creature", "pal unit", "allygator"],
    "family": ["relative swarm", "kin collection", "home tribe", "gene team"],
    "baby": ["tiny human", "giggle potato", "infantling", "miniature screamer"],
    "child": ["small humanoid", "kidlet", "youth creature", "tiny citizen"],
    "mother": ["maternal commander", "mom unit", "birth captain", "mominator"],
    "father": ["paternal commander", "dad unit", "fathertron", "pop organism"],
    "brother": ["bro-unit", "sibling gentleman", "brotheroid", "male kinling"],
    "sister": ["sis-unit", "sibling lady", "sisteroid", "female kinling"],
    "teacher": ["knowledge wizard", "learn captain", "brain gardener", "teachoid"],
    "student": ["knowledge sponge", "learnling", "desk creature", "study unit"],
    "doctor": ["health wizard", "body mechanic", "medicoid", "healing human"],
    "boss": ["command human", "work overlord", "chiefling", "bossatron"],

    # Animals
    "dog": ["floofbeast", "barkotron", "woofling", "canine noodle", "sniff wolf"],
    "dogs": ["floofbeasts", "bark brigade", "wooflings", "sniff wolves"],
    "cat": ["meowgle", "fuzzgoblin", "purrbeast", "whisker loaf", "scratch wizard"],
    "cats": ["meowgles", "fuzzgoblins", "purr committee", "whisker loaves"],
    "bird": ["sky nugget", "feather missile", "chirp unit", "wing bean"],
    "fish": ["water noodle", "bubble creature", "swim biscuit", "gill unit"],
    "horse": ["gallop beast", "hay motorcycle", "hoof machine", "neigh wagon"],
    "cow": ["moo unit", "milk beast", "grass processor", "bovine appliance"],
    "pig": ["oink potato", "mud loaf", "porkling", "snout unit"],
    "chicken": ["cluck nugget", "egg machine", "feather blob", "yard dinosaur"],
    "duck": ["quack boat", "pond honker", "water chicken", "bill creature"],
    "mouse": ["squeak bean", "cheese thief", "tiny scurrier", "rodent nugget"],
    "rabbit": ["hop noodle", "ear beast", "bunny unit", "carrot goblin"],
    "bear": ["forest floof", "honey tank", "roar loaf", "claw potato"],
    "lion": ["roar monarch", "mane beast", "savanna kinglet", "cat deluxe"],
    "tiger": ["stripe goblin", "danger kitty", "orange ambush", "roar noodle"],
    "monkey": ["banana agent", "tree humanoid", "swing goblin", "primate prankster"],
    "snake": ["danger noodle", "hiss rope", "slither tube", "legless surprise"],
    "spider": ["eight-leg creep", "web wizard", "ceiling goblin", "bug octopus"],
    "bug": ["tiny crawler", "insectoid", "micro beast", "skitter unit"],

    # Places
    "house": ["dwellingoid", "boxnest", "habicube", "human storage unit"],
    "home": ["comfort cube", "sleep headquarters", "domicile noodle", "nest zone"],
    "room": ["inside box", "wall pocket", "chamberoid", "space cube"],
    "school": ["knowledge factory", "learnatorium", "brain gym", "desk kingdom"],
    "office": ["work cave", "productivity cube", "desk farm", "paper habitat"],
    "store": ["purchase cave", "stuff depot", "money-removal zone", "shopatorium"],
    "restaurant": ["food temple", "munch station", "chew palace", "meal factory"],
    "hospital": ["healing fortress", "medical maze", "body repair shop"],
    "city": ["building forest", "concrete swarm", "urban blob", "people hive"],
    "town": ["small citylet", "villageoid", "human cluster", "road collection"],
    "country": ["nation blob", "land kingdom", "flag zone", "map chunk"],
    "world": ["planet neighborhood", "earth ball", "global biscuit", "existence orb"],
    "space": ["cosmic nothing", "star soup", "voidatorium", "upward darkness"],
    "moon": ["night rock", "sky cheese", "lunar biscuit", "orbit potato"],
    "sun": ["sky furnace", "day orb", "solar fireball", "giant glow bean"],
    "park": ["tree zone", "grass kingdom", "outdoor lounge", "squirrel district"],
    "road": ["car ribbon", "travel stripe", "wheel path", "asphalt noodle"],
    "street": ["building canyon", "city roadling", "traffic trench", "walkway zone"],

    # Objects and technology
    "computer": ["thinkbox", "click machine", "silicon goblin", "electronic brain"],
    "phone": ["pocket rectangle", "talk brick", "notification slab", "hand computer"],
    "television": ["glow box", "picture wall", "entertainment rectangle", "screen beast"],
    "tv": ["glow box", "vision slab", "channel portal", "moving-picture brick"],
    "radio": ["sound catcher", "wave whisperer", "audio brick", "music receiver"],
    "internet": ["global noodle network", "meme highway", "digital web soup"],
    "keyboard": ["letter piano", "button field", "typing plank", "word grid"],
    "mouse": ["click potato", "cursor rodent", "hand scurrier", "pointer bean"],
    "screen": ["pixel window", "glow rectangle", "visual portal", "display slab"],
    "camera": ["memory eyeball", "picture trap", "image gobbler", "photo box"],
    "book": ["paper knowledge brick", "word sandwich", "story slab", "page cube"],
    "pen": ["ink stick", "word wand", "scribble spear", "writing noodle"],
    "pencil": ["graphite twig", "erase stick", "scribble wand", "wooden word tool"],
    "table": ["object platform", "legged slab", "stuff altar", "horizontal board"],
    "chair": ["sitting device", "butt platform", "rest throne", "legged seat"],
    "door": ["wall flap", "room portal", "entry rectangle", "hinged passage"],
    "window": ["wall eye", "outside viewer", "glass portal", "sunlight rectangle"],
    "car": ["vroombox", "wheelbeast", "zoomwagon", "road capsule", "metal horse"],
    "truck": ["giant vroombox", "cargo beast", "road elephant", "haul wagon"],
    "bus": ["people wagon", "public road whale", "seat serpent", "commute beast"],
    "train": ["rail snake", "track caterpillar", "choo machine", "metal centipede"],
    "airplane": ["sky bus", "flying tube", "cloud torpedo", "winged people can"],
    "boat": ["water car", "float box", "ocean wagon", "wave biscuit"],
    "bicycle": ["pedal horse", "two-wheel noodle", "leg-powered zoomer"],
    "money": ["purchase confetti", "currency noodles", "trade paper", "wallet fuel"],
    "key": ["lock tickler", "door password", "metal unlocker", "pocket tooth"],
    "clock": ["time circle", "tick machine", "hour goblin", "moment counter"],
    "lamp": ["light mushroom", "glow stick deluxe", "darkness remover"],

    # Food and drink
    "food": ["munchmatter", "chewbits", "snackonium", "belly fuel"],
    "water": ["splashjuice", "hydrogloop", "wetness essence", "thirst remover"],
    "coffee": ["bean potion", "wake-up mud", "caffeine soup", "morning fuel"],
    "tea": ["leaf water", "steep juice", "hot plant potion", "calm brew"],
    "milk": ["cow juice", "calcium potion", "white beverage", "cereal lubricant"],
    "juice": ["fruit blood", "squeeze potion", "liquid produce", "sweet splash"],
    "bread": ["wheat sponge", "toast material", "carb brick", "sandwich walls"],
    "cheese": ["milk brick", "dairy gold", "aged moo", "yellow flavor slab"],
    "pizza": ["cheese disc", "sauce wheel", "triangle generator", "Italian frisbee"],
    "hamburger": ["meat sandwich", "beef puck", "bun beast", "grill disc"],
    "hotdog": ["meat tube", "bun sausage", "mystery cylinder", "mustard vehicle"],
    "sandwich": ["bread package", "lunch stack", "food folder", "edible envelope"],
    "egg": ["breakfast orb", "chicken capsule", "yolk grenade", "shell nugget"],
    "apple": ["tree ball", "crunch orb", "fruit sphere", "doctor repellent"],
    "banana": ["yellow moon", "peel noodle", "monkey snack", "fruit boomerang"],
    "orange": ["citrus planet", "juice orb", "peel sphere", "vitamin ball"],
    "potato": ["dirt apple", "starch rock", "underground loaf", "fry ancestor"],
    "cake": ["frosting brick", "celebration sponge", "sugar tower", "birthday fuel"],
    "cookie": ["sweet disc", "crumb coin", "baked circle", "snack puck"],
    "candy": ["sugar pebble", "sweet nugget", "tooth villain", "flavor jewel"],
    "soup": ["hot food water", "spoon ocean", "ingredient bath", "bowl potion"],
    "breakfast": ["morning munch", "sunrise fuel", "wake-up feast"],
    "lunch": ["midday munch", "noon fuel", "afternoon chew session"],
    "dinner": ["evening feast", "night munch", "sunset food ritual"],

    # Actions
    "run": ["speed-wobble", "leg-zoom", "rapidly relocate", "sprintify"],
    "running": ["speed-wobbling", "leg-zooming", "rapidly relocating", "sprintifying"],
    "walk": ["leg shuffle", "foot travel", "slow zoom", "strollify"],
    "walking": ["leg shuffling", "foot traveling", "slow zooming", "strollifying"],
    "jump": ["gravity argue", "floor escape", "upward boing", "leapify"],
    "jumping": ["gravity arguing", "floor escaping", "boingulating", "leapifying"],
    "eat": ["munchify", "consume chunks", "belly-load", "chewulate"],
    "eating": ["munchifying", "consuming chunks", "belly-loading", "chewulating"],
    "drink": ["sipulate", "liquid-load", "gulpify", "beverage inward"],
    "drinking": ["sipulating", "liquid-loading", "gulpifying", "beverage absorbing"],
    "sleep": ["unconscious recharge", "dreamify", "bed hibernate", "napulate"],
    "sleeping": ["dreamifying", "bed hibernating", "recharging horizontally"],
    "talk": ["mouth-noise", "wordify aloud", "speechulate", "jaw broadcast"],
    "talking": ["mouth-noising", "wordifying aloud", "jaw broadcasting"],
    "say": ["mouth-launch", "word eject", "utterify", "speech-blast"],
    "said": ["mouth-launched", "word-ejected", "utterified", "speech-blasted"],
    "think": ["brain-wiggle", "thoughtify", "mind crunch", "idea simmer"],
    "thinking": ["brain-wiggling", "thoughtifying", "idea simmering"],
    "look": ["eyeball", "visionify", "gaze-launch", "optically inspect"],
    "see": ["eyeball-detect", "vision receive", "lookify", "optically notice"],
    "watch": ["eyeball continuously", "gaze-lock", "vision monitor"],
    "hear": ["ear-detect", "sound receive", "listenify", "audio notice"],
    "listen": ["ear-focus", "sound absorb", "audio attend", "noise inspect"],
    "write": ["scribblecode", "word-draw", "inkify", "text manufacture"],
    "read": ["word absorb", "page decode", "eyeball text", "knowledge inhale"],
    "work": ["laborate", "taskify", "productivity wobble", "jobulate"],
    "play": ["funulate", "gameify", "recreation wobble", "joy-operate"],
    "laugh": ["giggle explode", "ha-ha discharge", "chuckleblast", "joy wheeze"],
    "cry": ["eye leak", "sadness drip", "tearify", "emotion rain"],
    "sing": ["melody eject", "voice music", "tune-launch", "songify"],
    "dance": ["rhythm wobble", "body boogie", "music wiggle", "grooveulate"],
    "drive": ["wheel command", "road pilot", "vroombox operate", "steerify"],
    "stop": ["haltify", "cease wobbling", "freeze action", "no-more-go"],
    "go": ["departify", "move forth", "commence zoom", "travelize"],
    "come": ["approachify", "arrive toward", "move hither", "incoming wobble"],
    "make": ["constructify", "create-a-doodle", "manufacture", "buildulate"],
    "get": ["obtainify", "acquire blob", "receive-a-doink", "grabulate"],
    "give": ["hand-overify", "transfer blob", "donate-a-doink", "sendulate"],
    "open": ["unclose", "portalize", "revealify", "make accessible"],
    "close": ["unopen", "sealify", "shutulate", "portal cancel"],
    "help": ["assistify", "rescue-wobble", "aidulate", "support-a-doink"],
    "find": ["discoverify", "locate blob", "seek-success", "detectulate"],
    "lose": ["misplaceify", "unfind", "vanish ownership", "forget-location"],
    "love": ["heartify", "adorulate", "emotion maximum", "affection blast"],
    "hate": ["dislike supreme", "anti-love", "rageify", "nope emotionally"],

    # Descriptions
    "good": ["splendidly weird", "glorious", "top-notchular", "excellentoid"],
    "bad": ["crumby", "awfuloid", "no-goodnik", "disaster flavored"],
    "big": ["mega-chonky", "enormo", "gigantular", "large-a-rooni"],
    "small": ["micro-tiny", "smol", "miniature-ish", "littlebean"],
    "fast": ["zoomtastic", "speedy-doink", "rapidular", "turbo flavored"],
    "slow": ["snailish", "unfast", "delay-flavored", "molasses powered"],
    "hot": ["spicy-temperatured", "heatular", "sun-flavored", "toasty maximum"],
    "cold": ["brrr-shaped", "ice flavored", "chillular", "freeze-adjacent"],
    "happy": ["joy-wobbly", "smile-powered", "delightified", "gleefulish"],
    "sad": ["frown-flavored", "gloomulated", "unhappy noodle", "sorrow-shaped"],
    "angry": ["rage crispy", "madular", "fury-powered", "grumble charged"],
    "funny": ["giggle-shaped", "comedy flavored", "ha-ha worthy", "silly deluxe"],
    "weird": ["strange-o-riffic", "oddular", "bizarro", "unusually noodly"],
    "strange": ["weirdified", "peculiarish", "odd-a-doodle", "bizarre flavored"],
    "beautiful": ["eye-delicious", "pretty maximum", "glamorized", "splendiferous"],
    "ugly": ["beauty-inverted", "goblin chic", "face-confusing", "unpretty deluxe"],
    "smart": ["brainy deluxe", "knowledge powered", "cleveroid", "thinky"],
    "stupid": ["brain buffering", "thought-challenged", "confusified", "silly-brained"],
    "old": ["time-seasoned", "ancientish", "many-yesterdayed", "vintage organism"],
    "new": ["freshly spawned", "recentoid", "unused-ish", "brand-spankling"],
    "loud": ["ear explosive", "volume enormous", "noise maximum", "boom flavored"],
    "quiet": ["whisper-sized", "noise minimal", "hushular", "sound tiny"],
    "clean": ["dirtless", "sparkle sanitized", "grime-free-ish", "scrubulated"],
    "dirty": ["grime flavored", "mudular", "unclean deluxe", "filthified"],
    "easy": ["effort-light", "simple-dimple", "difficulty tiny", "breezular"],
    "hard": ["difficulty crunchy", "effort maximum", "tricklewicky", "toughular"],
    "crazy": ["bananular", "wild-brained", "chaos flavored", "bonkers deluxe"],
    "nice": ["pleasantoid", "kind-flavored", "friendly deluxe", "sweetular"],
    "cool": ["frosty awesome", "neat-a-rooni", "chill excellent", "radular"],

    # Time
    "today": ["this particular sun-cycle", "now-day", "current daytime"],
    "tomorrow": ["next sun-cycle", "future-day", "after-sleep time"],
    "yesterday": ["previous sun-cycle", "before-day", "recent pastland"],
    "morning": ["sunrise zone", "wake-up hours", "early light time"],
    "afternoon": ["post-lunch zone", "middle sun time", "day part two"],
    "evening": ["sunset zone", "pre-night time", "dim hours"],
    "night": ["darkness shift", "moon hours", "sleep zone", "sunless interval"],
    "day": ["sun cycle", "light interval", "twenty-four-hour blob"],
    "week": ["seven-day sandwich", "calendar chunk", "day bundle"],
    "year": ["season collection", "annual loop", "twelve-month noodle"],
    "time": ["clock juice", "moment stream", "reality progression", "tick sauce"],
    "now": ["this instanticle", "current moment blob", "immediately-ish"],
    "later": ["future-ish", "after now", "subsequent moment", "eventually noodle"],

    # Common words
    "the": ["da", "zee", "tharg", "yon"],
    "a": ["one-ish", "a singular", "some kinda", "uno"],
    "an": ["one-ish", "a certain", "singularly", "uno"],
    "and": ["plusoid", "with-a-doink", "also noodle", "as well as blorp"],
    "or": ["alternatively-ish", "otherwise noodle", "orbly", "choice-a-doink"],
    "but": ["howeveroid", "except-a-doink", "yet noodle", "contrarywise"],
    "because": ["due to blorp", "on account of wobble", "cuzoid", "reason being"],
    "if": ["supposingly", "in the eventicle", "perhaps when", "conditional blorp"],
    "then": ["subsequentoid", "afterwardly", "next-a-doink", "thereuponish"],
    "this": ["this here blob", "yon nearby thing", "current object", "dis-a-doink"],
    "that": ["yon blob", "that there thing", "distant object", "dat-a-doink"],
    "these": ["these here blobs", "nearby thingies", "current multiples"],
    "those": ["yon blobs", "distant thingies", "them-a-doinks"],
    "it": ["the blob", "that entity", "thingoid", "objectling"],
    "its": ["the blob's", "that entity's", "thingoid's", "objectling's"],
    "i": ["this humanoid", "me-unit", "the speaker creature", "I-blorp"],
    "me": ["this humanoid", "myself unit", "speaker creature", "me-oid"],
    "my": ["this humanoid's", "my-ownish", "speaker-owned", "me-unit's"],
    "you": ["u", "humanoid", "fren", "listener unit"],
    "your": ["ur", "humanoid's", "listener-owned", "yourish"],
    "he": ["that dude unit", "himanoid", "male humanoid", "sir-blob"],
    "she": ["that lady unit", "heranoid", "female humanoid", "madam-blob"],
    "we": ["the collective us", "our humanoid team", "we-units", "us swarm"],
    "they": ["those entities", "the other units", "them creatures", "they-blobs"],
    "who": ["which humanoid", "identity creature", "what personoid"],
    "what": ["which blob", "what-a-doink", "thing-query", "object mystery"],
    "where": ["at which zone", "location-query", "what placeoid"],
    "when": ["at what moment", "time-query", "which clock point"],
    "why": ["for what reasonoid", "cause-query", "how come-a-doink"],
    "how": ["by what methodoid", "method-query", "in what mannerish"],
    "is": ["be", "existsly", "am-ish", "currently be"],
    "are": ["beings", "existify", "are-ish", "currently exist"],
    "was": ["previously be", "used-to-exist", "pastly existed"],
    "were": ["previously beings", "pastly existed", "used-to-be-ified"],
    "am": ["be currently", "exist as", "am-a-doink", "currently humanoid"],
    "have": ["possessify", "own a blob", "be equipped with", "containulate"],
    "has": ["possessifies", "owns a blob", "be equipped-ish", "containulates"],
    "had": ["previously possessed", "used to own", "formerly contained"],
    "can": ["is able-ish", "capabilify", "has the power to", "can-a-doink"],
    "will": ["future-do", "shallify", "eventually must", "will-a-wobble"],
    "do": ["performify", "actionate", "make happen", "do-a-doink"],
    "not": ["nope-ly", "un-", "absolutely not-ish", "negative noodle"],
    "very": ["extremely-ish", "mega", "super-duper", "intensely noodly"],
    "really": ["truly-doink", "actually-ish", "for-realular", "seriously noodle"],
    "more": ["additional blob", "extra-ish", "increased noodle", "more-a-doink"],
    "less": ["reduced blob", "smaller amountish", "unmore", "decreased noodle"],
    "all": ["every blob", "the whole swarm", "totalized", "everythingular"],
    "some": ["a blobful", "several-ish", "partial swarm", "some-a-doinks"],
    "nothing": ["zero blobs", "void nugget", "absence deluxe", "empty everything"],
    "something": ["mystery blob", "unspecified thingoid", "a certain noodle"],
    "everything": ["all the blobs", "total existence", "the entire thing-swarm"],

    # Feelings and ideas
    "love": ["heart explosion", "adoration beam", "affection soup", "lovular"],
    "fear": ["spook juice", "scare feeling", "terror sprinkles", "frightoid"],
    "hope": ["future sparkle", "wish fuel", "optimism noodle", "hopeium"],
    "idea": ["brain sparkle", "thought nugget", "mind bean", "concept blob"],
    "dream": ["sleep movie", "brain cinema", "night thought", "imagination fog"],
    "problem": ["trouble nugget", "difficulty blob", "error beast", "issue goblin"],
    "answer": ["solution noise", "response nugget", "question antidote"],
    "question": ["wonder sentence", "mystery request", "answer summoner"],
    "name": ["identity noise", "human label", "word tag", "personal title"],
    "word": ["language nugget", "mouth symbol", "text bean", "meaning packet"],
    "words": ["language nuggets", "mouth symbols", "text beans", "meaning packets"],
    "thing": ["blob", "objectoid", "mystery item", "stuff nugget"],
    "stuff": ["assorted blobs", "thing collection", "miscellaneous noodles"],
    "life": ["existence adventure", "living noodle", "reality subscription"],
    "death": ["existence cancellation", "final nap", "life logout"],
}


SYLLABLES = [
    "blorp", "snazz", "glim", "zorg", "wibble", "floof", "krunk", "gloop",
    "splat", "boing", "zibble", "flarn", "quonk", "mlem", "grunk", "plonk",
    "snoof", "zorp", "bleb", "frizzle", "wonk", "dingle", "squib", "thwomp",
    "narg", "bloop", "skronk", "floop", "glorp", "brumble", "zoink", "mungo",
    "crungle", "shmeep", "twonk", "vlorp", "splingle", "gribble", "noodle"
]

ENDINGS = [
    "oid", "otron", "arium", "ification", "ishly", "ular", "ling",
    "beast", "goblin", "noodle", "unit", "blob", "machine", "wizard",
    "deluxe", "maximum", "a-doink", "amundo", "tastic"
]


def invent_weird_word():
    """Create a random nonsense word."""
    if random.random() < 0.5:
        return random.choice(SYLLABLES) + random.choice(ENDINGS)

    return (
        random.choice(SYLLABLES)
        + random.choice(SYLLABLES)
        + random.choice(ENDINGS)
    )


def match_capitalization(original, replacement):
    """Apply the original word's capitalization to its replacement."""
    if original.isupper():
        return replacement.upper()

    if original.istitle():
        return replacement.capitalize()

    return replacement


def replace_word(match):
    """Replace one word while preserving capitalization."""
    original = match.group(0)
    lowercase = original.lower()

    if lowercase in WEIRD_WORDS:
        replacement = random.choice(WEIRD_WORDS[lowercase])
    else:
        # Unknown words are sometimes kept so sentences remain recognizable.
        if random.random() < 0.35:
            replacement = original
        else:
            replacement = invent_weird_word()

    return match_capitalization(original, replacement)


def weird_translate(text):
    """
    Translate words while preserving spaces and punctuation.
    Apostrophes inside words are supported.
    """
    translated = re.sub(r"[A-Za-z]+(?:'[A-Za-z]+)?", replace_word, text)

    # Occasionally decorate the completed sentence.
    if translated and random.random() < 0.35:
        translated += random.choice([
            " ...probably.",
            " BLORP!",
            " Quite peculiar.",
            " *confused goblin noises*",
            " [translation unstable]",
            " HONK.",
            " Somehow.",
            " For mysterious reasons."
        ])

    return translated


def speak_text(text):
    """Speak text using Windows built-in TTS."""
    powershell_code = (
        "Add-Type -AssemblyName System.Speech; "
        "$speaker = New-Object "
        "System.Speech.Synthesis.SpeechSynthesizer; "
        "$speaker.SetOutputToDefaultAudioDevice(); "
        "$text = $input | Out-String; "
        "$speaker.Speak($text); "
        "$speaker.Dispose()"
    )

    try:
        subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                powershell_code
            ],
            input=text,
            text=True,
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )
    except OSError:
        pass


def main():
    tts_enabled = True

    print("=" * 60)
    print("              MASSIVE WEIRD WORD TRANSLATOR")
    print("=" * 60)
    print("Enter a sentence and its words will be weirdified.")
    print("Type tts to toggle text-to-speech.")
    print("Type quit, exit, or q to stop.")

    while True:
        text = input("\nNormal text: ").strip()

        if text.lower() in {"quit", "exit", "q"}:
            print("\nGoodbye, language creature!")
            break

        if text.lower() == "tts":
            tts_enabled = not tts_enabled
            print("TTS:", "ON" if tts_enabled else "OFF")
            continue

        if not text:
            print("Please enter some words.")
            continue

        translated = weird_translate(text)
        print("Weird text:", translated)

        if tts_enabled:
            speak_text(translated)


if __name__ == "__main__":
    main()
