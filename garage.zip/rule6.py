import os
import platform
import random
import shutil
import subprocess
import tempfile


TOPICS = [
    "hall", "lunchroom", "water", "bedroom", "office",
    "school", "library", "kitchen", "garage", "yard",
    "computer", "phone", "cat", "dog", "television",
    "space station", "moon", "banana", "elevator", "park",

    "toaster", "microwave", "refrigerator", "socks", "shoes",
    "backpack", "locker", "mailbox", "pencil", "eraser",
    "desk", "chair", "couch", "window", "door",
    "ceiling", "floor", "attic", "basement", "roof",

    "cloud", "rain", "snow", "thunder", "lightning",
    "river", "ocean", "lake", "pond", "stream",
    "mountain", "hill", "valley", "forest", "desert",

    "submarine", "airplane", "helicopter", "train", "bus",
    "taxi", "bicycle", "motorcycle", "spaceship", "rocket",

    "robot", "android", "drone", "satellite", "telescope",
    "laser", "calculator", "keyboard", "mouse", "headphones",

    "sandwich", "pizza", "hamburger", "hotdog", "spaghetti",
    "apple", "orange", "watermelon", "pickle", "broccoli",

    "hamster", "goldfish", "parrot", "penguin", "giraffe",
    "elephant", "raccoon", "squirrel", "octopus", "dragon",

    "pirate ship", "castle", "treasure", "crown", "throne",
    "knight", "wizard", "potion", "spellbook", "dungeon",

    "planet", "galaxy", "asteroid", "comet", "black hole",
    "time machine", "parallel universe", "wormhole", "timeline",

    "blanket", "pillow", "alarm clock", "calendar", "notebook",
    "bookmark", "newspaper", "magazine", "dictionary", "map",

    "shoehorn", "flashlight", "hammer", "wrench", "ladder",
    "garden hose", "watering can", "birdhouse", "mail truck",

    "vending machine", "shopping cart", "cash register",
    "movie theater", "arcade", "bowling alley",

    "rubber duck", "whoopee cushion", "kazoo", "yo-yo",
    "bubble machine", "confetti cannon",

    "pancake", "waffle", "cupcake", "cookie", "donut",
    "ice cream", "milkshake", "pretzel", "popcorn",

    "remote control", "light switch", "extension cord",
    "USB cable", "battery", "power outlet",

    "sidewalk", "crosswalk", "parking lot", "driveway",
    "streetlight", "traffic cone", "billboard",

    "museum", "aquarium", "zoo", "observatory",
    "stadium", "concert hall", "cafeteria",

    "mustache", "eyebrow", "shoelace", "left sock",
    "right sock", "hat", "belt", "jacket",

    "mystery box", "secret tunnel", "ancient potato",
    "department of bananas", "official squirrel committee",

    "the internet", "email", "homework", "vacation",
    "Monday", "Friday", "weekend", "birthday",

    "nothing", "everything", "something", "whatever",
    "the situation", "that thing", "the incident",
    "the paperwork", "the meeting", "the memo"
]


RULE_TEMPLATES = [
    "Rule #{n}: No unnecessary discussion about {topic}.",
    "Rule #{n}: Always approach {topic} with caution.",
    "Rule #{n}: Do not leave {topic} unattended.",
    "Rule #{n}: Respect the established procedures regarding {topic}.",
    "Rule #{n}: Report suspicious activity involving {topic}.",
    "Rule #{n}: Keep all {topic} operations orderly.",
    "Rule #{n}: Refrain from dramatic behavior around {topic}.",
    "Rule #{n}: Obtain approval before modifying {topic}.",
    "Rule #{n}: Excessive enthusiasm concerning {topic} is discouraged.",
    "Rule #{n}: Maintain a reasonable distance from {topic}.",

    "Rule #{n}: Unauthorized juggling of {topic} is prohibited.",
    "Rule #{n}: Never challenge {topic} to a contest.",
    "Rule #{n}: {topic} must not be referred to as the thing.",
    "Rule #{n}: Avoid eye contact with {topic} during inspections.",
    "Rule #{n}: The official stance on {topic} remains complicated.",
    "Rule #{n}: No running toward {topic}.",
    "Rule #{n}: No running away from {topic}.",
    "Rule #{n}: No interpretive dance involving {topic}.",
    "Rule #{n}: Please remain calm in the presence of {topic}.",
    "Rule #{n}: Discussions about {topic} may be recorded for future confusion.",

    "Rule #{n}: Anyone mentioning {topic} inherits temporary responsibility for it.",
    "Rule #{n}: The emergency use of {topic} requires paperwork.",
    "Rule #{n}: Additional paperwork regarding {topic} requires additional paperwork.",
    "Rule #{n}: Do not speculate about the true purpose of {topic}.",
    "Rule #{n}: Questions about {topic} create more questions.",
    "Rule #{n}: The committee has reviewed {topic} and remains concerned.",
    "Rule #{n}: The committee refuses to explain {topic}.",
    "Rule #{n}: A subcommittee now supervises {topic}.",
    "Rule #{n}: No singing directly at {topic}.",
    "Rule #{n}: Never tap on {topic} to see what happens.",

    "Rule #{n}: The use of {topic} for racing purposes is forbidden.",
    "Rule #{n}: Advanced {topic} privileges may be revoked without notice.",
    "Rule #{n}: Respect senior members of the {topic} community.",
    "Rule #{n}: Do not stack {topic} beyond recommended levels.",
    "Rule #{n}: Never assume {topic} understands your intentions.",
    "Rule #{n}: Any disagreement with {topic} must remain professional.",
    "Rule #{n}: Avoid discussing sports with {topic}.",
    "Rule #{n}: Avoid discussing politics with {topic}.",
    "Rule #{n}: Avoid discussing sandwiches with {topic}.",
    "Rule #{n}: If {topic} becomes self-aware, notify management.",

    "Rule #{n}: {topic} should not be balanced on other {topic}.",
    "Rule #{n}: Excessive confidence around {topic} is discouraged.",
    "Rule #{n}: No nicknames for {topic} without authorization.",
    "Rule #{n}: The phrase how hard can it be is banned near {topic}.",
    "Rule #{n}: Keep {topic} away from experimental ideas.",
    "Rule #{n}: Keep experimental ideas away from {topic}.",
    "Rule #{n}: If {topic} begins sparkling unexpectedly, document it.",
    "Rule #{n}: If {topic} begins talking, document it twice.",
    "Rule #{n}: Never blame {topic} unless evidence exists.",
    "Rule #{n}: Never trust evidence supplied by {topic}.",

    "Rule #{n}: Respect local customs regarding {topic}.",
    "Rule #{n}: Every {topic} deserves a fair hearing.",
    "Rule #{n}: Unauthorized improvements to {topic} are not improvements.",
    "Rule #{n}: Only trained professionals may ignore this rule about {topic}.",
    "Rule #{n}: Never compare {topic} to a banana.",
    "Rule #{n}: Especially never compare {topic} to two bananas.",
    "Rule #{n}: The maximum allowable excitement level for {topic} is moderate.",
    "Rule #{n}: Please queue in an orderly fashion for {topic}.",
    "Rule #{n}: Queueing again for {topic} requires justification.",
    "Rule #{n}: There is probably another rule about {topic}.",

    "Rule #{n}: Any attempt to simplify {topic} will complicate it.",
    "Rule #{n}: Do not lend {topic} ideas it cannot return.",
    "Rule #{n}: The annual review of {topic} has been delayed.",
    "Rule #{n}: Nobody remembers why this rule about {topic} exists.",
    "Rule #{n}: Historical incidents involving {topic} shall remain historical.",
    "Rule #{n}: Never ask what is the worst that could happen near {topic}.",
    "Rule #{n}: Maintain proper respect for the mysterious nature of {topic}.",
    "Rule #{n}: Additional rules regarding {topic} are pending.",
    "Rule #{n}: Rule creation related to {topic} is creating too many rules.",
    "Rule #{n}: Attempts to remove rules about {topic} require more rules.",

    "Rule #{n}: No dramatic pointing at {topic}.",
    "Rule #{n}: No suspicious whistling around {topic}.",
    "Rule #{n}: No mysterious laughter near {topic}.",
    "Rule #{n}: Always pretend you read the handbook section on {topic}.",
    "Rule #{n}: Never reveal the secret backup plan for {topic}.",
    "Rule #{n}: The backup plan for {topic} has been misplaced.",
    "Rule #{n}: Please ignore previous rumors involving {topic}.",
    "Rule #{n}: Please ignore future rumors involving {topic}.",
    "Rule #{n}: The department neither confirms nor denies {topic}.",
    "Rule #{n}: Do not attempt to train {topic}.",

    "Rule #{n}: If {topic} appears twice, remain calm.",
    "Rule #{n}: If {topic} appears three times, fill out Form 27-B.",
    "Rule #{n}: Always walk confidently past {topic}.",
    "Rule #{n}: Running a survey on {topic} requires approval.",
    "Rule #{n}: Approval for surveys about {topic} requires another survey.",
    "Rule #{n}: Friendly competition involving {topic} must remain friendly.",
    "Rule #{n}: There shall be no championships related to {topic}.",
    "Rule #{n}: Emergency meetings about {topic} should not become routine.",
    "Rule #{n}: Do not ask where the {topic} budget went.",
    "Rule #{n}: The {topic} budget knows what it did.",

    "Rule #{n}: Do not introduce {topic} without a proper announcement.",
    "Rule #{n}: Never allow {topic} to chair a committee.",
    "Rule #{n}: Treat all rumors concerning {topic} as mildly interesting.",
    "Rule #{n}: Do not wave at {topic} unless it waves first.",
    "Rule #{n}: All official references to {topic} must sound important.",
    "Rule #{n}: Do not photograph {topic} from its bad side.",
    "Rule #{n}: Never wake {topic} before noon.",
    "Rule #{n}: Do not permit {topic} to reorganize the furniture.",
    "Rule #{n}: Keep unofficial snacks away from {topic}.",
    "Rule #{n}: Never ask {topic} to explain itself.",

    "Rule #{n}: A minimum of three witnesses is required to confirm unusual {topic}.",
    "Rule #{n}: Do not interrupt {topic} during business hours.",
    "Rule #{n}: Weekend regulations concerning {topic} remain unclear.",
    "Rule #{n}: Casual Fridays do not apply to {topic}.",
    "Rule #{n}: Do not permit {topic} to control the thermostat.",
    "Rule #{n}: All emergency {topic} must remain clearly labeled.",
    "Rule #{n}: Do not confuse ordinary {topic} with executive {topic}.",
    "Rule #{n}: Never place {topic} in charge of refreshments.",
    "Rule #{n}: Management accepts no responsibility for musical {topic}.",
    "Rule #{n}: Compliments directed at {topic} should be sincere but brief.",

    "Rule #{n}: Never allow {topic} to select its own password.",
    "Rule #{n}: If {topic} requests a meeting, check the calendar twice.",
    "Rule #{n}: Do not permit {topic} to invent new holidays.",
    "Rule #{n}: All ceremonial {topic} must be returned by closing time.",
    "Rule #{n}: Never leave {topic} alone with the photocopier.",
    "Rule #{n}: Do not invite {topic} to an unlimited buffet.",
    "Rule #{n}: No spontaneous parades involving {topic}.",
    "Rule #{n}: Do not assign {topic} a parking space.",
    "Rule #{n}: Never give {topic} access to the announcement system.",
    "Rule #{n}: All unofficial versions of {topic} must wear name tags.",

    "Rule #{n}: Do not ask {topic} what happened last Tuesday.",
    "Rule #{n}: Never attempt to alphabetize {topic}.",
    "Rule #{n}: Do not permit {topic} to become a motivational speaker.",
    "Rule #{n}: Keep receipts for all authorized {topic}.",
    "Rule #{n}: Never allow {topic} to explain the dress code.",
    "Rule #{n}: Do not leave snacks where {topic} can negotiate for them.",
    "Rule #{n}: Any singing performed by {topic} must end before sunset.",
    "Rule #{n}: Never discuss the secret ingredient with {topic}.",
    "Rule #{n}: Complaints from {topic} must be submitted in triplicate.",
    "Rule #{n}: All meetings concerning {topic} must include an unnecessary chart.",

    "Rule #{n}: Never tell {topic} that the rules are optional.",
    "Rule #{n}: Do not allow {topic} to count the votes.",
    "Rule #{n}: Avoid sudden movements when discussing {topic}.",
    "Rule #{n}: Never whisper the name of {topic} near an open window.",
    "Rule #{n}: All borrowed {topic} must be returned in approximately the same condition.",
    "Rule #{n}: Do not permit unscheduled applause for {topic}.",
    "Rule #{n}: Anyone claiming expertise in {topic} must prove it with a certificate.",
    "Rule #{n}: Certificates about {topic} must be signed by someone important.",
    "Rule #{n}: Nobody may declare themselves important solely because of {topic}.",
    "Rule #{n}: Do not ask why the handbook contains fourteen chapters about {topic}.",

    "Rule #{n}: {topic} must remain inside clearly marked boundaries.",
    "Rule #{n}: Never allow {topic} to operate heavy office machinery.",
    "Rule #{n}: Do not encourage {topic} after 9 p.m.",
    "Rule #{n}: All leftover {topic} becomes property of the committee.",
    "Rule #{n}: Do not permit {topic} to make long-distance calls.",
    "Rule #{n}: Never ask {topic} to hold your place in line.",
    "Rule #{n}: Do not mention the previous {topic} incident.",
    "Rule #{n}: Any future {topic} incident will be called a misunderstanding.",
    "Rule #{n}: Never add wheels to {topic} without written approval.",
    "Rule #{n}: Do not ask {topic} to supervise itself.",

    "Rule #{n}: All ceremonial references to {topic} require a serious voice.",
    "Rule #{n}: Never allow {topic} to become the official mascot.",
    "Rule #{n}: Do not exchange personal information with {topic}.",
    "Rule #{n}: If {topic} offers advice, write it down and do the opposite.",
    "Rule #{n}: Nobody may reserve {topic} for the entire afternoon.",
    "Rule #{n}: Never allow {topic} to make the final decision.",
    "Rule #{n}: Do not store confidential paperwork underneath {topic}.",
    "Rule #{n}: All accidental {topic} must be reported before lunch.",
    "Rule #{n}: Deliberate {topic} requires two forms of identification.",
    "Rule #{n}: Anyone laughing at {topic} must explain the joke.",

    "Rule #{n}: Do not let {topic} hear you discussing replacement plans.",
    "Rule #{n}: Never attempt to repair {topic} using motivational phrases.",
    "Rule #{n}: Do not allow {topic} to select the background music.",
    "Rule #{n}: Any unusual noise from {topic} should be treated as official.",
    "Rule #{n}: Normal noises from {topic} should also be treated as suspicious.",
    "Rule #{n}: Do not feed {topic} after midnight.",
    "Rule #{n}: Never place {topic} near an open container of glitter.",
    "Rule #{n}: Do not permit {topic} to borrow your favorite pen.",
    "Rule #{n}: All debates about {topic} must end in a polite draw.",
    "Rule #{n}: When in doubt, create another rule about {topic}."
]


TTS_ENABLED = True
TTS_ERROR_SHOWN = False


def find_powershell():
    """Find Windows PowerShell or PowerShell 7."""
    candidates = [
        "powershell.exe",
        "powershell",
        "pwsh.exe",
        "pwsh"
    ]

    for candidate in candidates:
        executable = shutil.which(candidate)

        if executable:
            return executable

    return None


def speak_windows(text):
    """
    Speak using the built-in Windows SAPI voice.

    The text is written to a temporary UTF-8 file. PowerShell then reads
    that file and sends its contents to SAPI. This prevents punctuation,
    quotations, apostrophes, and long sets of rules from breaking the
    PowerShell command.
    """
    powershell = find_powershell()

    if not powershell:
        print(
            "\nWindows TTS error: PowerShell could not be found."
        )
        return False

    temporary_path = None

    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            suffix=".txt",
            prefix="rule_generator_tts_",
            delete=False
        ) as temporary_file:
            temporary_file.write(text)
            temporary_path = temporary_file.name

        environment = os.environ.copy()
        environment["RULE_GENERATOR_TTS_FILE"] = temporary_path

        powershell_command = (
            "$ErrorActionPreference = 'Stop'; "
            "$path = $env:RULE_GENERATOR_TTS_FILE; "
            "$text = [System.IO.File]::ReadAllText("
            "$path, [System.Text.Encoding]::UTF8); "
            "$voice = New-Object -ComObject SAPI.SpVoice; "
            "$voice.Volume = 100; "
            "$voice.Rate = 0; "
            "[void]$voice.Speak($text);"
        )

        creation_flags = getattr(
            subprocess,
            "CREATE_NO_WINDOW",
            0
        )

        result = subprocess.run(
            [
                powershell,
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                powershell_command
            ],
            env=environment,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creation_flags,
            check=False
        )

        if result.returncode != 0:
            error_message = result.stderr.strip()

            if not error_message:
                error_message = (
                    "PowerShell returned an unknown TTS error."
                )

            print("\nWindows TTS error:")
            print(error_message)
            return False

        return True

    except FileNotFoundError:
        print(
            "\nWindows TTS error: PowerShell could not be started."
        )
        return False

    except Exception as error:
        print(f"\nWindows TTS error: {error}")
        return False

    finally:
        if temporary_path:
            try:
                os.remove(temporary_path)
            except OSError:
                pass


def speak_macos(text):
    """
    Speak using the built-in macOS say command.

    No external Python package is required.
    """
    say_command = shutil.which("say")

    if not say_command:
        print(
            "\nmacOS TTS error: The say command "
            "could not be found."
        )
        return False

    try:
        result = subprocess.run(
            [say_command, text],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False
        )

        if result.returncode != 0:
            error_message = result.stderr.strip()

            if not error_message:
                error_message = (
                    "The say command returned an unknown error."
                )

            print("\nmacOS TTS error:")
            print(error_message)
            return False

        return True

    except FileNotFoundError:
        print(
            "\nmacOS TTS error: The say command "
            "could not be started."
        )
        return False

    except Exception as error:
        print(f"\nmacOS TTS error: {error}")
        return False


def speak_linux(text):
    """
    Speak using an existing Linux speech command.

    Nothing is installed by this program. It uses spd-say or espeak
    only when one of those commands is already installed.
    """
    spd_say = shutil.which("spd-say")

    if spd_say:
        try:
            result = subprocess.run(
                [spd_say, "--wait", text],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False
            )

            if result.returncode != 0:
                error_message = result.stderr.strip()

                if not error_message:
                    error_message = (
                        "spd-say returned an unknown error."
                    )

                print("\nLinux spd-say error:")
                print(error_message)
                return False

            return True

        except Exception as error:
            print(f"\nLinux spd-say error: {error}")
            return False

    espeak = shutil.which("espeak")

    if espeak:
        try:
            result = subprocess.run(
                [espeak, text],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False
            )

            if result.returncode != 0:
                error_message = result.stderr.strip()

                if not error_message:
                    error_message = (
                        "espeak returned an unknown error."
                    )

                print("\nLinux espeak error:")
                print(error_message)
                return False

            return True

        except Exception as error:
            print(f"\nLinux espeak error: {error}")
            return False

    print(
        "\nLinux TTS is unavailable because neither "
        "spd-say nor espeak is already installed."
    )
    return False


def speak(text):
    """
    Speak text using the current operating system.

    Return True when speech completes successfully.
    Return False if TTS is disabled, the text is empty, or speech fails.
    """
    global TTS_ERROR_SHOWN

    if not TTS_ENABLED:
        return False

    if not isinstance(text, str):
        text = str(text)

    text = text.strip()

    if not text:
        return False

    operating_system = platform.system()

    if operating_system == "Windows":
        success = speak_windows(text)

    elif operating_system == "Darwin":
        success = speak_macos(text)

    elif operating_system == "Linux":
        success = speak_linux(text)

    else:
        print(
            "\nTTS is not configured for this operating system: "
            f"{operating_system}"
        )
        success = False

    if success:
        TTS_ERROR_SHOWN = False

    elif not TTS_ERROR_SHOWN:
        print(
            "\nText-to-speech could not play. "
            "Check the error above, your system volume, "
            "and the selected audio-output device."
        )
        TTS_ERROR_SHOWN = True

    return success


def toggle_tts():
    """Turn text-to-speech on or off."""
    global TTS_ENABLED
    global TTS_ERROR_SHOWN

    TTS_ENABLED = not TTS_ENABLED
    TTS_ERROR_SHOWN = False

    state = "ON" if TTS_ENABLED else "OFF"
    print(f"\nTTS is now {state}.")

    if TTS_ENABLED:
        speak("Text to speech is now on.")


def test_tts():
    """Speak a short test message."""
    if not TTS_ENABLED:
        print("\nTTS is off. Enter TTS to turn it on.")
        return

    print("\nTesting text-to-speech...")

    success = speak(
        "This is a text to speech test. "
        "The unnecessarily official rule generator is speaking."
    )

    if success:
        print("TTS test completed successfully.")
    else:
        print("TTS test failed.")


def show_help():
    """Display the available commands."""
    print("\nCOMMANDS")
    print("-" * 40)
    print("Press Enter : Choose a random topic")
    print("TTS         : Turn speech on or off")
    print("TEST        : Test the speech system")
    print("HELP        : Display these commands")
    print("QUIT        : Exit the program")
    print("Other text  : Use that text as the topic")


def get_rule_count():
    """Ask how many unique rules should be generated."""
    while True:
        answer = input(
            "\nHow many rules should be generated? "
            "Press Enter for 10: "
        ).strip()

        command = answer.lower()

        if not answer:
            return 10

        if command in ("tts", "voice", "speech"):
            toggle_tts()
            continue

        if command in ("test", "test tts", "test voice"):
            test_tts()
            continue

        if command in ("help", "commands", "?"):
            show_help()
            continue

        if command in ("q", "quit", "exit"):
            return None

        try:
            count = int(answer)

            if count < 1:
                print(
                    "Please enter a number greater than zero."
                )

            elif count > len(RULE_TEMPLATES):
                print(
                    f"Please enter {len(RULE_TEMPLATES)} or less "
                    "so every rule remains unique."
                )

            else:
                return count

        except ValueError:
            print(
                "Please enter a whole number, TTS, TEST, "
                "HELP, or QUIT."
            )


def generate_rules(topic, count):
    """Generate, display, and speak a set of rules."""
    selected_templates = random.sample(
        RULE_TEMPLATES,
        count
    )

    generated_rules = [
        template.format(
            n=number,
            topic=topic
        )
        for number, template in enumerate(
            selected_templates,
            start=1
        )
    ]

    print("\n" + "=" * 70)
    print("OFFICIAL RULES")
    print("=" * 70)
    print(f"TOPIC: {topic.upper()}")
    print("=" * 70)
    print()

    for rule in generated_rules:
        print(rule)

    print()
    print("=" * 70)

    speech_text = (
        f"Official rules for {topic}. "
        + " ".join(generated_rules)
        + " End of official rules."
    )

    speak(speech_text)


def say_goodbye():
    """Display and speak the closing message."""
    goodbye = (
        "Remember: There is probably a rule about that."
    )

    print(f"\n{goodbye}")
    speak(goodbye)


def main():
    """Run the unnecessarily official rule generator."""
    print("=" * 70)
    print("THE UNNECESSARILY OFFICIAL RULE GENERATOR")
    print("=" * 70)
    print("Enter any word or subject to generate rules about it.")
    print("Press Enter for a random topic.")
    print("Enter TTS to toggle speech.")
    print("Enter TEST to test speech.")
    print("Enter HELP to see the commands.")
    print("Enter QUIT to exit.")
    print("\nTTS is ON by default.")

    speak(
        "Welcome to the unnecessarily official rule generator. "
        "Text to speech is on."
    )

    while True:
        topic = input("\nTopic: ").strip()
        command = topic.lower()

        if command in ("q", "quit", "exit"):
            say_goodbye()
            break

        if command in ("tts", "voice", "speech"):
            toggle_tts()
            continue

        if command in ("test", "test tts", "test voice"):
            test_tts()
            continue

        if command in ("help", "commands", "?"):
            show_help()
            continue

        if not topic:
            topic = random.choice(TOPICS)
            print(f"Random topic selected: {topic}")

        count = get_rule_count()

        if count is None:
            say_goodbye()
            break

        generate_rules(topic, count)

        while True:
            again = input(
                "\nGenerate more rules? "
                "[Enter/Y = yes, TTS = toggle, "
                "TEST = test, HELP = commands, N = quit]: "
            ).strip().lower()

            if again in ("", "y", "yes"):
                break

            if again in ("tts", "voice", "speech"):
                toggle_tts()
                continue

            if again in ("test", "test tts", "test voice"):
                test_tts()
                continue

            if again in ("help", "commands", "?"):
                show_help()
                continue

            if again in ("n", "no", "q", "quit", "exit"):
                say_goodbye()
                return

            print(
                "Please enter Y, N, TTS, TEST, or HELP."
            )


if __name__ == "__main__":
    main()
