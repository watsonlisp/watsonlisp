import random
import subprocess

SPELLS = [
    "Moonlight Charm",
    "Whispering Wind Spell",
    "Starfire Invocation",
    "Crystal Vision",
    "Silver Raven Call",
    "Eclipse Aura",
    "Shadow Lantern",
    "Mystic Lighthouse",
    "Dragon Tongue",
    "Clockwork Familiar",
    "Frost Bloom",
    "Thunder Whisper",
    "Aurora Dance",
    "Wandering Comet",
    "Celestial Harmony",
    "Glimmerdust Burst",
    "Forest Echo",
    "Ghost Lantern",
    "Phoenix Spark",
    "Rune of Insight",
    "Emerald Veil",
    "Obsidian Mirror",
    "Twilight Beacon",
    "Sunlit Shield",
    "Moonbeam Bridge",
    "Dancing Fireflies",
    "River Song",
    "Secret Path",
    "Mystic Compass",
    "Skybound Feather",
    "Golden Acorn",
    "Sapphire Storm",
    "Cloud Walker",
    "Spirit Bell",
    "Dreamcatcher Spell",
    "Archmage's Greeting",
    "Fairy Circle",
    "Silent Owl",
    "Witchlight Glow",
    "Shimmering Tides",
    "Eternal Campfire",
    "Wizard's Wink",
    "Crescent Blessing",
    "Lucky Lantern",
    "Spectral Waltz",
    "Enchanted Ink",
    "Magic Pocket",
    "Rainbow Invocation",
    "Sunrise Whisper",
    "Moonlit Voyage"
]

HEXES = [
    "Sock Mismatch Hex",
    "Lost Remote Hex",
    "Crooked Picture Hex",
    "Squeaky Chair Hex",
    "Flat Soda Hex",
    "Weak WiFi Hex",
    "Slow Elevator Hex",
    "Endless Red Lights Hex",
    "Cold Coffee Hex",
    "Missing Pen Hex",
    "Tangled Earbud Hex",
    "Sticky Keyboard Hex",
    "Mystery Crumb Hex",
    "Uncharged Phone Hex",
    "Dropped Spoon Hex",
    "Empty Milk Hex",
    "Itchy Sweater Hex",
    "Foggy Glasses Hex",
    "Wrong Elevator Hex",
    "Left Sock Missing Hex",
    "Leaky Umbrella Hex",
    "Wobbly Table Hex",
    "Bent Straw Hex",
    "Crushed Chip Hex",
    "Awkward Silence Hex",
    "Mild Inconvenience Hex",
    "Incorrect Change Hex",
    "Late Alarm Hex",
    "Spilled Popcorn Hex",
    "Lost Bookmark Hex",
    "Knotty Shoelace Hex",
    "Toothpaste Disaster Hex",
    "Broken Pencil Hex",
    "Confusing Instructions Hex",
    "Lag Spike Hex",
    "Forgot Password Hex",
    "Paper Cut Hex",
    "Endless Loading Hex",
    "Blown Lightbulb Hex",
    "Wet Sleeve Hex",
    "Sticky Doorknob Hex",
    "Mysterious Beeping Hex",
    "Prankster Goblin Hex",
    "Crinkled Receipt Hex",
    "Wrong Checkout Line Hex",
    "Misplaced Glasses Hex",
    "Annoying Ad Hex",
    "Noisy Neighbor Hex",
    "Cold French Fry Hex",
    "Faded Marker Hex"
]

CURSES = [
    "May your toast always land upside down.",
    "May every chair squeak dramatically.",
    "May your batteries die at 2%.",
    "May your shoelaces untie themselves.",
    "May your popcorn contain many unpopped kernels.",
    "May every elevator stop on every floor.",
    "May your favorite pen vanish.",
    "May your ice cream drip immediately.",
    "May your cereal become slightly soggy.",
    "May your charger disappear temporarily.",
    "May your cookies crumble unexpectedly.",
    "May your sleeves slide down while washing your hands.",
    "May every sandwich be cut unevenly.",
    "May your remote hide in plain sight.",
    "May every line move slowly.",
    "May your phone autocorrect oddly.",
    "May your socks slide into your shoes.",
    "May your bookmarks fall out.",
    "May your pizza cool too quickly.",
    "May your pencil break repeatedly.",
    "May your ice cubes melt instantly.",
    "May your playlist skip your favorite song.",
    "May your headphones tangle overnight.",
    "May every receipt fade quickly.",
    "May every blanket have one cold corner.",
    "May every burrito leak slightly.",
    "May every cookie break in the milk.",
    "May your popcorn bowl crack.",
    "May your flashlight flicker.",
    "May every page stick together.",
    "May your bookmarks hide from you.",
    "May every zipper hesitate.",
    "May your cereal box open poorly.",
    "May your burger drip on your shirt.",
    "May every soup spoon sink.",
    "May your pancakes stick to the pan.",
    "May your keyboard attract crumbs.",
    "May every sticker peel unevenly.",
    "May every shopping cart squeak.",
    "May your naps be interrupted."
]

BLESSINGS = [
    "A pleasant surprise awaits you.",
    "You shall discover forgotten treasure.",
    "Good fortune follows your footsteps.",
    "A friend will brighten your day.",
    "You will find exactly what you need.",
    "Today will bring unexpected laughter.",
    "Your coffee shall remain hot.",
    "Your batteries shall stay charged.",
    "Your path shall be clear.",
    "Fortune smiles upon you.",
    "The stars favor your endeavors.",
    "Good weather greets your journey.",
    "A lucky coincidence approaches.",
    "Your dreams bring inspiration.",
    "Your confidence grows stronger.",
    "Peace fills your thoughts.",
    "Creativity flows freely.",
    "Your next meal will be excellent.",
    "A happy memory returns.",
    "Unexpected kindness finds you.",
    "Success greets your effort.",
    "Your planning pays off.",
    "Joy visits often.",
    "The winds favor your travels.",
    "Your friends remain loyal.",
    "Your garden flourishes.",
    "Your projects succeed.",
    "Your spirits remain high.",
    "You discover hidden opportunity.",
    "Your music sounds even better.",
    "Your luck improves steadily.",
    "The moon smiles upon your evening.",
    "The sun brightens your path.",
    "Prosperity visits your home.",
    "Your future looks bright.",
    "A wonderful adventure awaits.",
    "Great stories come your way.",
    "Your wishes draw nearer.",
    "Magic finds your imagination.",
    "Happiness lingers all day."
]

POTIONS = [
    "Potion of Courage",
    "Potion of Happiness",
    "Potion of Focus",
    "Potion of Luck",
    "Potion of Energy",
    "Potion of Wisdom",
    "Potion of Adventure",
    "Potion of Good Dreams",
    "Potion of Inspiration",
    "Potion of Calm",
    "Potion of Friendship",
    "Potion of Creativity",
    "Potion of Laughter",
    "Potion of Bright Ideas",
    "Potion of Determination",
    "Potion of Patience",
    "Potion of Charisma",
    "Potion of Clear Thinking",
    "Potion of Confidence",
    "Potion of Motivation",
    "Potion of Swift Running",
    "Potion of Excellent Timing",
    "Potion of Cat Communication",
    "Potion of Dragon Diplomacy",
    "Potion of Star Gazing",
    "Potion of Forest Walking",
    "Potion of Storytelling",
    "Potion of Sailing",
    "Potion of Moon Watching",
    "Potion of Puzzle Solving",
    "Potion of Memory",
    "Potion of Treasure Finding",
    "Potion of Campfire Tales",
    "Potion of Music",
    "Potion of Sunshine",
    "Potion of Ancient Knowledge",
    "Potion of Cosmic Awareness",
    "Potion of Rainbow Vision",
    "Potion of Crystal Dreams",
    "Potion of Midnight Wonder",
    "Potion of Arcane Insight",
    "Potion of Endless Curiosity",
    "Potion of Boundless Imagination",
    "Potion of Gentle Sleep",
    "Potion of Golden Fortune",
    "Potion of Mystic Sight",
    "Potion of Heroic Spirit",
    "Potion of Lucky Chances",
    "Potion of Strange Adventures",
    "Potion of Magical Discovery"
]


def speak(text):
    safe_text = text.replace("'", "''")

    command = (
        "Add-Type -AssemblyName System.Speech; "
        "$voice = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        f"$voice.Speak('{safe_text}')"
    )

    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", command],
            check=False,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
    except Exception:
        pass


def cast_spell():
    result = random.choice(SPELLS)
    print("\n=== SPELL ===")
    print(result)
    speak(result)


def cast_hex():
    result = random.choice(HEXES)
    print("\n=== HEX ===")
    print(result)
    speak(result)


def cast_curse():
    result = random.choice(CURSES)
    print("\n=== CURSE ===")
    print(result)
    speak(result)


def cast_blessing():
    result = random.choice(BLESSINGS)
    print("\n=== BLESSING ===")
    print(result)
    speak(result)


def brew_potion():
    result = random.choice(POTIONS)
    print("\n=== POTION ===")
    print(result)
    speak(result)


def random_magic():
    magic_functions = [
        cast_spell,
        cast_hex,
        cast_curse,
        cast_blessing,
        brew_potion
    ]

    random.choice(magic_functions)()


def show_collection_counts():
    print("\n=== SPELLBOOK COLLECTION ===")
    print("Spells:", len(SPELLS))
    print("Hexes:", len(HEXES))
    print("Curses:", len(CURSES))
    print("Blessings:", len(BLESSINGS))
    print("Potions:", len(POTIONS))

    total = (
        len(SPELLS)
        + len(HEXES)
        + len(CURSES)
        + len(BLESSINGS)
        + len(POTIONS)
    )

    print("Total magical entries:", total)


def main():
    while True:
        print("\n" + "=" * 34)
        print("       WITCHCRAFT GENERATOR")
        print("=" * 34)
        print("1. Cast Spell")
        print("2. Cast Hex")
        print("3. Cast Curse")
        print("4. Cast Blessing")
        print("5. Brew Potion")
        print("6. Random Magic")
        print("7. Show Collection Counts")
        print("Q. Close the Spellbook")

        choice = input("\nChoose an incantation: ").strip().lower()

        if choice == "1":
            cast_spell()

        elif choice == "2":
            cast_hex()

        elif choice == "3":
            cast_curse()

        elif choice == "4":
            cast_blessing()

        elif choice == "5":
            brew_potion()

        elif choice == "6":
            random_magic()

        elif choice == "7":
            show_collection_counts()

        elif choice in ("q", "quit", "exit"):
            print("\nThe candles fade...")
            print("The spellbook closes.")
            break

        else:
            print("\nUnknown incantation. Choose 1 through 7, or Q.")


if __name__ == "__main__":
    main()
